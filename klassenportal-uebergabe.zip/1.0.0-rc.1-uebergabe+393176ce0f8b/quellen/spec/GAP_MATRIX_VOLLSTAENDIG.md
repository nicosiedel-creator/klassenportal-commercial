# Gap-Matrix: Master-Spec V2, vollständig

Stand: 13.09.2026, zweite Fassung (Planung, Lebenszyklus, Dokumente und Automatisierungsarchitektur nachgetragen) · Grundlage: `Klassenportal_1_0_MASTER_SPEC_FINAL_GESAMT_VOLLSTAENDIGKEITSAUDIT_V2.docx`
(126 nummerierte Überschriften in sieben Nummerierungsblöcken, 96.820 Zeichen)

Diese Datei ersetzt `GAP_ANALYSE.md` nicht, sondern schließt deren Lücke: jene Analyse
bezog sich auf 23 Abschnitte des Dokuments — im Wesentlichen §0–§44. Die Abschnitte
**§45–§63**, der **Final Master Integrationaudit**, der **19-Bereiche-Durchlauf** und die
**21-Punkte-Prüfkette** waren darin nicht enthalten. Sie sind hier nachgeholt.

**Auch diese Matrix war in ihrer ersten Fassung unvollständig.** Sie ließ den 19-Bereiche-
Durchlauf weitgehend aus — der Bereich „PLANUNG UND ZEIT" mit neun Anforderungen fehlte
vollständig, ebenso Lebenszyklus, Dokumentintelligenz und die Automatisierungsarchitektur
aus §47. Nachgetragen in den Abschnitten 3.5 bis 3.7.

Die Gliederung folgt der Vorgabe der Spec („AUSGABE VOR IMPLEMENTIERUNG", Punkte 1–9).
Geprüft wurde am Quelltext, nicht an Stichworten: 229 Quelldateien, 129 Migrationen,
190 Testdateien.

---

## 1. Ist-Zustand

Der Bestand ist in den Bereichen, die er abdeckt, tief: Mandantenfähigkeit,
Rollentrennung, Anwesenheit, Bewertung, Prüfungen mit Safe Exam Browser,
Nachteilsausgleich, Einspruch mit Zweitkorrektur, Bewertungsraster, Kompetenzen,
Berichtsheft, Zeugnisse mit selbsttragendem Nachweis, Import mit Konflikterkennung,
Debitoren, Förderfälle, KURSNET-Export, Rechtsnachfolge, Kaltdatenauslagerung,
WCAG 2.2 AA mit Dauerprüfung.

Was der Bestand **nicht** ist: ein betreibbares Produkt im Sinne des Final Master Audit.
Die Spec verschiebt den Prüfmaßstab ausdrücklich weg von der Funktionsliste hin zu
**dauerhafter Betreibbarkeit ohne Entwicklerwissen, Anbieterunabhängigkeit,
Kostenkontrolle und Wiederanlauf**. Auf dieser Ebene ist die Abdeckung dünn.

---

## 2. Bereits erfüllt

| Anforderung | Wo | Beleg |
|---|---|---|
| Mandanten-, Rollen-, Datenisolation | `permissions.ts`, `tenant-access-integrity` | Kursrolle statt Mandantenrolle, fail-closed geprüft |
| Betroffenenrechte (Art. 15/17) | `data-subject-rights.ts` | 182 Tabellen klassifiziert, Registry fail-closed |
| Backup **und** Restore | `portability/backup.ts` | `createTenantBackup`, `restoreTenantBackup` |
| Backup-Integritätsprüfung | `backup-verification.ts` | `verifyBackup`, `backupReadiness` |
| Vollständiger Mandantenexport | `portability/export.ts` | `fullTenantExport` inkl. Dateien |
| Kontrollierte Mandantenlöschung | `portability/delete.ts` + Erasure-Registry | fail-closed gegen das Schema |
| Rechtsnachfolge / Trägerwechsel | `tenant-succession.ts` | 92 Tabellen, Verifikation nach dem Umzug |
| Import: Mapping, Dubletten, Konflikte, Vorschau | `participant-import*`, `organization-import` | Konfliktentscheidung sichtbar |
| Massenoperationen mit Fortsetzung | `storage-growth`, `automation-cycle` | `completed:false` + `remaining` |
| Idempotenz im Automatiklauf | `automation-cycle.ts` | Rotation über `automation_cycle_state` |
| Feature Flags | `feature_flags` (0001) | mandantenweise, mit Audit |
| Health-Endpunkt | `router.ts` `/api/health` | — |
| Zertifikate mit öffentlicher Verifikation | `certificates.ts`, W3C VC | Ed25519 + ECDSA P-256 |
| Prüfung: Varianten-Vorarbeit, SEB, Nachteilsausgleich, Einspruch, Raster | 0100, 0124–0128 | je durch Rücknahme belegt |
| Barrierefreiheit WCAG 2.2 AA | `accessibility-wcag.mjs` | alle Obergrenzen auf null |
| Kaltdaten / D1-Grenze | `cold-storage.ts` | Verify-before-delete |
| Umfragen, Exkursionen, Qualitätsmaßnahmen | 0037, 0070, 0071 | Tabellen vorhanden |
| Moderation/Meldung im Forum | `collaboration-reporting-router.ts` | — |

---

## 3. Fehlend

Nach Prioritätsgruppen der Spec. **A** = MUSS für V1.0/Architektur, **B** = Architekturvorsorge,
**C** = späteres Modul, **D** = bewusst nicht.

### 3.1 Betrieb und Unabhängigkeit — der schwerste Block

| # | Fehlt | Prio | Warum es wiegt |
|---|---|---|---|
| ~~B1~~ | ~~**Release ohne GitHub**~~ **geschlossen** (`scripts/release-artifact.mjs`, `release-deploy.mjs`, `docs/BETRIEB_OHNE_GITHUB.md`) | **A** | Der gesamte Build-/Deploy-Weg liegt in 13 GitHub-Workflows. Die Spec verbietet das an fünf Stellen wörtlich. **Der aktuelle Blocker ist genau dieser Fall: seit Tagen kein Push möglich, damit kein Release.** |
| ~~B2~~ | ~~Betreiber-Cockpit ohne Entwicklerwissen~~ **geschlossen** (0161, `operations-continuity.ts`: Aktualisierung mit Rückweg als Pflichtfeld, Probelauf gegen den Schemastand, Ausrollen nur ohne Befund; Störung mit Auswirkung, Verlauf, Ursache und Pflicht-Nachbetrachtung) | **A** |
| ~~B3~~ | ~~Ein-Klick-Wiederherstellung mit Simulation~~ **geschlossen** (`restore-operations.ts`, 0135: Vorschau mit Umfang, Planpruefsumme, Nachkontrolle) | **A** | — |
| ~~B4~~ | ~~Disaster-Recovery-Handbuch~~ **geschlossen** (`docs/NOTFALLHANDBUCH.md`: fünf Lagen, Rollen, Proben, Grenzen) | **A** | — |
| ~~B5~~ | ~~RTO/RPO definiert und gemessen~~ **geschlossen** (`observability.ts`: SLO-Ziele, Fehlerbudget, Messung) | **A** | — |
| ~~B6~~ | ~~Regelmäßiger Restore-Test~~ **geschlossen** (Wiederanlaufprobe mit Turnus; kein Eintrag gilt als fällig) | **A** | — |
| ~~B7~~ | ~~Konfigurationssicherung~~ **geschlossen** (`configuration-backup.ts`, mit Simulation) | **A** | — |
| ~~B8~~ | ~~**Provider-Abstraktion** Mail/Storage/KI/Video/Auth~~ **geschlossen** (`provider-registry.ts`, 0131) | **A** | — |
| ~~B9~~ | ~~**Kostenwächter**~~ **geschlossen** (`cost-guard.ts`, 0132: Verbrauch, Limits, Warnung, Prognose) | **A** | — |
| ~~B10~~ | ~~Automatische Kostenbremse~~ **geschlossen** (`cost-guard.ts`: harte Grenze bremst, Freigabe protokolliert) | **A** | — |
| ~~B11~~ | ~~Kein Personen-Lock-in~~ **geschlossen** (0161, `ausfallpruefung`: kritische Aufgaben mit Mindestbesetzung, Übung veraltet nach einem Jahr, die letzte Besetzung lässt sich nicht entfernen) | **A** |
| ~~B12~~ | ~~Observability: Logs, Metriken, Traces, SLOs, Alarm~~ **geschlossen** (`observability.ts`, 0133) | **A** | — |
| ~~B13~~ | ~~SBOM / Vulnerability Management~~ **geschlossen** (`scripts/sbom.mjs`, CycloneDX) | **A** | — |
| ~~B14~~ | ~~Security Contact / Vulnerability Disclosure~~ **geschlossen** (`public/.well-known/security.txt`) | **A** | — |
| ~~B15~~ | ~~Immutable Audit (manipulationsresistent)~~ **geschlossen** (0136: Hash-Kette je Mandant, Siegel, Änderungssperre in der Datenbank) | **A** | — |
| ~~B16~~ | ~~Support-Zugriff zeitlich begrenzt und auditiert~~ **geschlossen** (0137, `support-access.ts`: Freigabe durch den Träger, 72 h, nur lesend, protokolliert) | **A** | — |
| ~~B17~~ | ~~Netzunterbrechung / Offline-Verhalten~~ **geschlossen** (0138, Idempotenz + `offline-queue.js` an der Anwesenheit) | **A** | — |

### 3.2 Recht, Datenschutz, Schutzbefohlene

| # | Fehlt | Prio |
|---|---|---|
| ~~R1~~ | ~~**Legal Hold** (Löschsperre bei Streit/Behörde)~~ **geschlossen** (`legal-hold-retention.ts`, 0134) | **A** |
| ~~R2~~ | ~~**Datenschutzvorfall**: Erkennung, Bewertung, Meldung, Nachweis~~ **geschlossen** (0143, `privacy-incidents.ts`: 72 h ab Kenntnis, Verzeichnis nach Art. 33 Abs. 5) | **A** |
| ~~R3~~ | ~~**Aufbewahrungsfristen** je Mandant/Datentyp mit Löschläufen~~ **geschlossen** (gesetzliche Mindestfristen, Vorschau, Lauf) | **A** |
| ~~R4~~ | ~~**Einwilligungsmanagement**: Zweck, Version, Gültigkeit, Widerruf~~ **geschlossen** (Fassungen, Sorgeberechtigte, Widerruf) | **A** |
| ~~R5~~ | ~~**Auskunftssperre / Sorgerechtsbeschränkung**, serverseitig durchgesetzt~~ **geschlossen** (0140, `access-restrictions.ts`) | **A** |
| ~~R6~~ | ~~Getrennte Haushalte: getrennte Kommunikationswege~~ **geschlossen** (Haushalt je Sorgeverknüpfung, Einzelzustellung statt Sammelverteiler) | **A** |
| ~~R7~~ | ~~**Safeguarding/Kinderschutz**: Meldeworkflow, restriktive Sichtbarkeit, Eskalation~~ **geschlossen** (0141, `safeguarding.ts`: benannte Fachkräfte statt Rollenrecht, Befangenheitsausschluss, Frist) | **A** |
| ~~R8~~ | ~~**Krisenkommunikation** mit Bestätigung und Ausfallkanal~~ **geschlossen** (0142, `crisis-communication.ts`: namentliche Bestätigung, Telefonliste der Offenen, Entwarnung) | **A** |
| ~~R9~~ | ~~Richtlinienbestätigung (wer hat welche Fassung bestätigt)~~ **geschlossen** (0139, `policy-acknowledgement.ts`) | **A** |
| ~~R10~~ | ~~Beschwerdemanagement mit Frist und Eskalation~~ **geschlossen** (0142, `complaints.ts`: anonym möglich, 14 Tage Frist, Mahnung an die Leitung) | **A** |
| ~~R11~~ | ~~Datenresidenz nachvollziehbar konfigurierbar~~ **geschlossen** (0165, `residency-policy.ts`: zugesagte Region je Träger, die Eintragung wird verweigert statt hinterher gemeldet, Ausnahmen nur erlaubt/begründet/befristet; die Prüfung leitet aus dem echten Bestand ab und schönt den Mailversand nicht) | ARCH |

### 3.3 Prüfungsrecht — Rest

| # | Fehlt | Prio |
|---|---|---|
| ~~P1~~ | ~~**Prüfungsvarianten**~~ **geschlossen** (0129, gleichwertig + nachrechenbar verteilt) | **A** |
| ~~P2~~ | ~~**Chain-of-Custody**: Aufgabenfreigabe bis Ergebnisarchiv~~ **geschlossen** (0144, `exam-custody.ts`: Vier-Augen-Siegel, Inhalts-Hash, unveränderliche Kette) | **A** |
| ~~P3~~ | ~~**Prüfungs-Notfallbetrieb**: Unterbrechung, Wiederaufnahme, Ergebnisabgleich~~ **geschlossen** (0144, `exam-emergency.ts`: Restzeit eingefroren, Abgleich ohne Überschreiben) | **A** |
| ~~P4~~ | ~~**Akademische Integrität**: Täuschungsfall, Beweissicherung, Entscheidung~~ **geschlossen** (0144, `exam-integrity.ts`: Anhörung als Pflichtschritt) | **A** |
| ~~P5~~ | ~~Prüfungsplanung: Raum, Aufsicht, Zeit~~ **geschlossen** (0155, `exam-scheduling.ts`: Raum als Ressource statt Freitext, Aufsicht nicht doppelt und nicht befangen, Zeitzuschlag festgeschrieben — die Freigabe verweigert, was am Prüfungstag scheitern würde) | **A** |
| ~~P6~~ | ~~Curriculum- und Kompetenzrahmen-**Versionierung**~~ **geschlossen** (0151, `framework-versions.ts`: eingefrorene Fassung mit Hash, Bewertung zeigt den Wortlaut von damals) | **A** |
| ~~P7~~ | ~~Anerkennung von Vorleistungen (RPL)~~ **geschlossen** (0151, `prior-learning.ts`: begründeter Verwaltungsakt, kein Selbstbescheid, anerkannt bleibt vom geprüft unterscheidbar) | **A** |

### 3.4 Kommunikation, Medien, KI

| # | Fehlt | Prio |
|---|---|---|
| ~~K1~~ | ~~**Kommunikations- und Layout-Editor**: Blöcke, Bilder, Vorlagen, Vorschau~~ **geschlossen** (0163, `communication-editor.ts`: geschlossener Bausteinvorrat statt eingefügtem HTML, Platzhalter je Kanal erklärt, maskiert statt gefiltert, Vorschau als Beispiel gekennzeichnet, Bildrechte beim Veröffentlichen geprüft) | **A** |
| ~~K2~~ | ~~**Mitteilung als strukturiertes Objekt** (§55)~~ **geschlossen** (0146, `communication-content.ts`: Blöcke, daraus Portal, Text und HTML) | **A** |
| ~~K3~~ | ~~**Prioritätshierarchie** (§53)~~ **geschlossen** (0147, `notification-center.ts`: verbindlich schlägt jede Einstellung, serverseitig im Zustellweg) | **A** |
| ~~K4~~ | ~~Design-System mit Tokens und Theme~~ **geschlossen** (`design-tokens.css`: ein Wertesatz für beide Themen, 26 Kontrastpaare nach WCAG AA gerechnet statt geschätzt, Sperrklinke gegen neue feste Farben, `prefers-reduced-motion` beachtet) | **A** |
| ~~K5~~ | ~~Benachrichtigungszentrum mit Zustellstatus und Präferenzen~~ **geschlossen** (0147) | **A** |
| ~~K6~~ | ~~Kommunikationsnachweis: wer, was, wann, welcher Kanal, Zustellstatus~~ **geschlossen** (0147: auch der Grund einer Nichtzustellung) | **A** |
| ~~K7~~ | ~~Lesebestätigung/Quittierung~~ **geschlossen** (Quittungspflicht erzwingt die verbindliche Rangstufe) | **A** |
| ~~K8~~ | ~~**Medienbibliothek** mit Lizenz-/Rechteverwaltung~~ **geschlossen** (0160, `media-library.ts`: Lizenz ist Pflicht, Bedingungen werden geprüft, der Lizenzlauf nennt die Fundstellen und sperrt Abgelaufenes von allein; Inhalt liegt in R2, nicht in D1) | **A** |
| ~~K9~~ | ~~Video/Audio in Aufgaben und Prüfungen~~ **geschlossen** (0160, `media_usages`: Medien werden an Aufgabe, Quizfrage oder Material gebunden — mit geprüftem Zweck) | **A** |
| ~~K10~~ | ~~Untertitel, Transkript, Audiodeskription~~ **geschlossen** (0160, `media_tracks` + `assertBarrierefrei`: nur eine **geprüfte** Spur zählt — eine automatische Untertitelung mit Fehlern sieht aus wie ein Angebot und ist keines) | **A** |
| ~~K11~~ | ~~**KI-Modellabstraktion + Fallback**~~ **geschlossen** (0159, `ai-gateway.ts`: Fähigkeit, Region und Datenklasse filtern die Kette vorher; höchstens drei Versuche; ein Totalausfall wird gemeldet statt als leere Antwort verschleiert) | **A** |
| ~~K12~~ | ~~KI-Kostenbudget, Datenklassifizierung, Provenienz, Evaluation~~ **geschlossen** (0159, `ai-gateway.ts` + `ai-governance.ts`: Budget bremst vor dem Aufruf, ohne Klassifizierung kein Versand, unbestätigter KI-Text blockiert den Nachweis, Prüfläufe zeigen Verschlechterung) | **A** |
| ~~K13~~ | ~~KI-Medienproduktion, multimodale Aufgabenfabrik~~ **geschlossen** (0164, `ai-content-factory.ts`: es entstehen **Entwürfe**, jeder trägt seine Herkunft, freigeben darf nicht wer erzeugt hat, und in eine versiegelte Prüfung kommt nichts) | **C** |
| ~~K14~~ | ~~Natural Language Command Center~~ **geschlossen** (0164, `command-center.ts`: schlägt vor statt auszuführen — der Bestand bleibt Zeile für Zeile unberührt —, jeder Vorschlag zeigt auf eine bestehende Route, die Rechte der fragenden Person entscheiden, und bei Gleichstand wird gefragt statt geraten) | **C** |

### 3.5 Planung und Zeit (§1 des 19-Bereiche-Durchlaufs)

**Nachgetragen am 13.09.2026 — in der ersten Fassung dieser Matrix fehlte der Bereich ganz.**
Vorhanden ist mehr, als ich zunächst vermutet hatte: `planning-constraints.ts` (630 Zeilen)
führt Ressourcen, Sperrzeiten, Verfügbarkeiten, Kurs- und Deputatsregeln, `autofillTimetablePlan`,
`validateAdvancedTimetablePlan` mit Konfliktschreibung, `publishAdvancedTimetablePlan`,
`planningSuggestions` und `substituteSuggestions`; Planfassungen haben `draft/review/published`.

| # | Fehlt | Prio | Befund |
|---|---|---|---|
| ~~Z1~~ | ~~**Planvarianten bewerten und vergleichen**~~ **geschlossen** (0148, `plan-variants.ts`: Kennzahl mit Einzelwerten, Vergleich zweier Fassungen) | **A** | — |
| ~~Z2~~ | ~~**Plan-Wiederherstellung**~~ **geschlossen** (0148: Vorschau, Planprüfsumme, Nachkontrolle, protokollierter Lauf) | **A** | — |
| ~~Z3~~ | ~~Nur den betroffenen Bereich neu planen~~ **geschlossen** (`plan-partial-replan.ts`: Prüfsumme über die übrigen Termine belegt, dass nichts anderes angefasst wurde) | **A** | — |
| ~~Z4~~ | ~~Lösungsvorschläge bei Konflikten, minimale Änderung bevorzugt~~ **geschlossen** (nach Eingriffstiefe sortiert, jeder Vorschlag nennt seine Kosten) | **A** | — |
| ~~Z5~~ | ~~Blockunterricht, Doppelstunden, Schicht-/Randzeiten, Praxisphasen~~ **geschlossen** (0149, `plan-rhythms.ts`: Block als Gruppe, Praxisphase zählt nicht als Unterricht) | **A** | — |
| ~~Z6~~ | ~~**Gemeinsames Termin-/Planungsobjekt**~~ **geschlossen** (0130, `schedule-core.ts`) | **A** | `schedule_events` trägt die Zeit; Klassenbuch, Anwesenheit, Prüfung, Kalender und Aufgabe verweisen darauf und ziehen beim Verschieben mit |
| ~~Z7~~ | ~~Schuljahr/Periode als eigenes Objekt~~ **geschlossen** (0130) | **A** | `schedule_periods`; genau eine laufende je Mandant, von der Datenbank durchgesetzt; Kurse hängen daran |

### 3.6 Lebenszyklus, Unterricht, Dokumente, Förderung

| # | Fehlt | Prio | Befund |
|---|---|---|---|
| ~~L1~~ | ~~**Alumni-Status** nach Abschluss~~ **geschlossen** (0165, `alumni.ts`: der Umfang ist eine Grenze und keine Angabe, Kontakt nur mit widerruflicher Einwilligung, Abgeschlossene zählen in keiner Betriebsstatistik mehr mit) | B/SPÄTER |
| ~~L2~~ | ~~Kurswechsel, Unterbrechung, Wiederaufnahme als Vorgang~~ **geschlossen** (0156, `enrollment-lifecycle.ts`: Anlass, begründete Entscheidung, Stichtag; Historie im alten Kurs bleibt stehen; eine Unterbrechung ist kein Abbruch) | **A** |
| ~~L3~~ | ~~**Lernpfade**~~ **abgedeckt** (als LearningPath in §3.4 geführt; die individuelle Planung darauf steht seit 0156 in `learning-plan.ts`) | **A** |
| ~~L4~~ | ~~Adaptive Wiederholung / Lückenplanung~~ **geschlossen** (0156, `learning-plan.ts`: aus belegten Lücken werden Schritte mit Termin, geschlossen wird durch den erneuten Nachweis statt durch ein Häkchen) | **A** |
| ~~L5~~ | ~~Individuelle Lernplanung aus Prüfungstermin, Lernstand, Fehlzeiten~~ **geschlossen** (0156, `learning-plan.ts`: rückwärts vom Prüfungstermin gerechnet, Fehlzeiten einbezogen, knappe Zeit wird gesagt statt still gestaucht) | **A** |
| ~~D1~~ | ~~**Dokumentversionierung**~~ **geschlossen** (0150, `document-versions.ts`: unveränderliche Fassungen, Zurückholen erzeugt eine neue) | **A** | — |
| ~~D2~~ | ~~**Volltextsuche über Dokumentinhalte**~~ **geschlossen** (0150: eigene Wortliste statt FTS5 — Begründung in der Migration, UND-Suche in einer Abfrage) | **A** | — |
| ~~D3~~ | ~~OCR~~ **vorhanden** (`intake-center.ts`) | — |
| ~~F1~~ | ~~Förderprozess bis Abschlussnachweis~~ **vorhanden** (`participant_funding_cases`) | — |
| ~~F2~~ | ~~Fehlende Nachweise, Fristen, Erinnerungen~~ **vorhanden** (`education-radar.ts`) | — |
| ~~F4~~ | ~~**eM@w-Ausleitung** (Bundesagentur für Arbeit)~~ **geschlossen** (0168, `emaw.ts`, Schema 2.18 / PRV_26.07.00: Schlüsseldaten ausschließlich aus dem Anmeldeereignis der BA, Kommunikationsrichtung und Wertelisten aus der XSD erzeugt statt abgetippt, Anwesenheitsmeldung über alle Kalendertage mit Präsenz und Online getrennt, Importarchiv verschachtelt nach Konvention, „NOK" als Endzustand) | **A** |
| F5 | **XBildung / XBerufsbildung** — Zeugnisdaten im XÖV-Format | SPÄTER: XBerufsbildung steht bei 0.7 (Entwurf), es fehlen XSD und Schematron. Unterlagen und Einbauplan liegen in `spec/xbildung/LIESMICH.md`. Verbindlich ab 2029 (IT-Planungsrat B-2025/43-IT), und dann für Kammern, nicht für private Träger. |
| ~~F3~~ | ~~**Angebote und Verträge gegenüber Kostenträgern**~~ **geschlossen** (0166, `course-offers.ts`: der Maßnahmeplan wird aus Stundenplan und Rahmenplan abgeleitet statt getippt, eine Prüfsumme macht eine spätere Stundenplanänderung sichtbar, bevor jemand annimmt; Pflichtanlagen je Kostenträgerart, Maßnahmenummer bei der öffentlichen Hand, Summe gerechnet; die Zusage erzeugt Vertrag und Förderfälle in einem Zug) | **A** |

### 3.7 Automatisierungsarchitektur (§47)

| # | Fehlt | Prio | Befund |
|---|---|---|---|
| ~~W1~~ | ~~**Simulations-/Testmodus vor Aktivierung neuer Regeln**~~ **geschlossen** (0145, `workflow-simulation.ts`: Probelauf schreibt auf statt zu handeln; Aktivierung setzt ihn voraus) | **A** | — |
| ~~W2~~ | ~~**Dead-Letter-/Fehlerwarteschlange mit manueller Wiederaufnahme**~~ **geschlossen** (0145, `automation-resilience.ts`: ein Eintrag je Fehler, Wartezeit wächst, nach fünf Versuchen liegengeblieben) | **A** | — |
| ~~W3~~ | ~~Automatische Eskalation bei nicht bearbeiteten Vorgängen~~ **geschlossen** (0145: Stufen nach 24/72/168 h, keine Wiederholung derselben Stufe) | **A** | — |
| ~~W4~~ | ~~Transaktions-/Konsistenzmechanismus für zusammenhängende Änderungen~~ **geschlossen** (0145: Vorgangsjournal, idempotent und wiederaufsetzbar — kein verteiltes Transaktionsprotokoll, das wäre gelogen) | **A** | — |
| ~~W5~~ | ~~Event-/Workflow-Engine als Querschnitt~~ **geschlossen** (0162, `event-bus.ts`: genau einmal je Abonnent, Rückstau und sichtbares Totfach statt stillem Verlust, Reihenfolge je Objekt und Empfänger — auch über Läufe hinweg) | **A** |

### 3.8 Support, Qualität, Organisation

| # | Fehlt | Prio |
|---|---|---|
| ~~S1~~ | ~~Helpdesk/Ticketing mit SLA und Eskalation~~ **geschlossen** (0157, `helpdesk.ts`: Frist steht bei der Anlage fest, Eskalation läuft ohne Zutun, der Melder entscheidet über die Lösung) | **A** |
| ~~S2~~ | ~~Wissensbasis / kontextbezogene Hilfe / Admin-Handbuch~~ **geschlossen** (0157, `knowledge-base.ts`: nur Veröffentlichtes ist auffindbar, jede Fassung bleibt lesbar, Hilfe kennt den Bereich) | **A** |
| ~~S3~~ | ~~Geführtes Schul-Onboarding (Wizard mit Fortschritt)~~ **geschlossen** (0158, `onboarding-wizard.ts`: Schritte mit Abhängigkeiten, wiederaufnehmbarer Stand, ehrliches Verdikt „betriebsbereit“ statt Prozentbalken) | **A** |
| ~~S4~~ | ~~Veranstaltungen/Exkursionen als Vorgang~~ **geschlossen** (0158, `excursions.ts`: Genehmigung mit Begleitschlüssel, Einverständnis nur von Sorgeberechtigten, Notfallliste für den Tag, Nachweis danach) | **A** |
| ~~S5~~ | ~~Inventar/Assets, Beschaffung, Raumwartung~~ **geschlossen** (0167, `inventory.ts`: die Ausgabe kennt ihren Kurs, damit beim Abgang gefragt wird; defekt zurück erzeugt einen Vorgang statt stiller Verfügbarkeit; bestellt wird nur, was freigegeben ist, ab 5.000 € durch zwei verschiedene Personen; ein sicherheitsrelevanter Mangel schreibt eine echte Sperre in `planning_resource_unavailability`, die die bestehende Raumsuche liest) | ARCH |
| ~~S6~~ | ~~Bibliothek/Medienausleihe~~ **geschlossen** (0167, `library.ts`: das zurückgegebene Exemplar gehört der Ersten in der Schlange, eine Verlängerung ist bei Vormerkung gesperrt; und nach der Rückgabe wird die Person aus der Ausleihe entfernt — wer was gelesen hat, beantwortet das Portal danach nicht mehr) | SPÄTER |

---

## 4. Konflikte und Widersprüche

1. **GitHub-Abhängigkeit gegen Produktgrundsatz 5.** Der Betrieb hängt heute an GitHub
   Actions. Die Spec verbietet das wörtlich — und der aktuelle Blocker beweist die
   Begründung: ein gesperrter Account legt Release *und* Wiederherstellung still.
   Das ist kein theoretisches Risiko mehr, sondern der Ist-Zustand.

2. **„0 €-Ziel" gegen Provider-Abstraktion und Observability.** Adapter, Metriken,
   Fallback-Modelle und Restore-Tests kosten Laufzeit. Die Spec löst das selbst auf:
   „niemals auf Kosten von Sicherheit, Datenschutz, Verfügbarkeit". Der Konflikt ist
   also entschieden — zugunsten der Funktion, mit Free-first als Reihenfolge, nicht als
   Obergrenze.

3. **KI-Anforderungen gegen „keine erfundenen externen APIs" und AVV-Pflicht.** §6 und
   der F-Block verlangen Modellabstraktion, Evaluation und Datenklassifizierung. Beides
   ist ohne Anbieterentscheidung samt Auftragsverarbeitungsvertrag nicht umsetzbar.
   **Diese Entscheidung kann diese Analyse nicht treffen.** Bis dahin: Abstraktion und
   Governance bauen, kein Mandantendatum an ein Modell.

4. **Zahlungen deaktiviert gegen „kommerzieller Betrieb" (§2.13).** Kein echter
   Widerspruch, aber eine Grenze: Rechnungs- und ERP-Wege sind architektonisch
   vorzubereiten, dürfen aber keine Zahlungsnebenwirkung auslösen. Gilt unverändert.

5. **„Keine halbfertigen Kernfunktionen" gegen den Umfang.** Die Spec verlangt
   gleichzeitig Vollständigkeit und Verbot von Platzhaltern. Konsequenz: Umfang über
   Feature Flags steuern, nicht über sichtbare Stummel.

---

## 5. Notwendige Architekturänderungen

1. **Provider-Adapterschicht** für Mail, Storage, KI, Video, Auth, Suche. Ein Vertrag je
   Dienst, Konfiguration statt Verdrahtung, ein Testdoppel je Adapter.
2. **Release-Artefakt statt Repository-Zustand.** Versioniertes Bündel mit Prüfsumme,
   lokal erzeugbar, ohne GitHub deploybar, mit Rollback auf die Vorversion.
3. **Kosten- und Verbrauchsschicht** quer über alle externen Aufrufe: zählen, begrenzen,
   warnen, drosseln. Muss vor der KI-Anbindung stehen, nicht danach.
4. **Mitteilung als Objekt** statt als HTML-Feld: ein Datensatz, mehrere Ausspielwege.
5. **Audit manipulationsresistent** (Hash-Kette über die Einträge).
6. **Versionierung für Curriculum und Kompetenzrahmen**, damit historische Bewertungen
   beim Modellwechsel nicht kippen.
7. **Sperrschicht für Sichtbarkeit** (Auskunftssperre, Safeguarding, Legal Hold) — muss
   *unter* allen Leserechten sitzen, nicht neben ihnen.

---

## 6. V1.0-MUSS-Liste, in Umsetzungsreihenfolge

Reihenfolge nach Abhängigkeit und Risiko, nicht nach Aufwand.

**Welle 1 — Unabhängigkeit (der aktuelle Blocker)**
1. ~~Release ohne GitHub: Artefakt, Prüfsumme, Version, Rollback~~ **fertig**
2. ~~Konfigurationssicherung und -wiederherstellung~~ **fertig**
3. Provider-Adapter Mail + Storage, mit Testdoppel ← **als Nächstes**
4. Kostenwächter und Kostenbremse

**Welle 2 — Wiederanlauf**
5. Ein-Klick-Restore mit Simulation und Ergebnisprüfung
6. Turnusmäßiger Restore-Test, RTO/RPO messen
7. Disaster-Recovery-Handbuch
8. Observability, Health, Alarm; SBOM; Security Contact

**Welle 3 — Recht und Schutz**
9. Legal Hold, Aufbewahrungsfristen, Löschläufe
10. Einwilligungsmanagement mit Widerruf
11. Auskunftssperre und getrennte Haushalte
12. Safeguarding-Meldeweg, Datenschutzvorfall
13. Immutable Audit

**Welle 4 — Prüfungsrecht abschließen**
14. ~~Prüfungsvarianten~~ **fertig**
15. Chain-of-Custody, Notfallbetrieb, akademische Integrität
16. Curriculum-/Kompetenzrahmen-Versionierung, RPL

**Welle 5 — Kommunikation**
17. Mitteilung als strukturiertes Objekt + Prioritätshierarchie
18. Kommunikations-Editor, Vorlagen, Vorschau
19. Benachrichtigungszentrum, Zustellnachweis, Lesebestätigung
20. Krisenkommunikation

**Welle 6 — Betreiber und Support**
21. Betreiber-Cockpit, geführte Abläufe, Nico-Test als ausführbarer Test
22. Helpdesk, Wissensbasis, befristeter Supportzugriff
23. Schul-Onboarding-Wizard

**Welle 7 — Planung und Automatisierung**
27. ~~Gemeinsames Termin-/Planungsobjekt (Z6)~~ **fertig**
28. ~~Schuljahr/Periode als Objekt (Z7)~~ **fertig**
29. Planvarianten bewerten, vergleichen, wiederherstellen (Z1, Z2)
30. Teil-Neuplanung und Lösungsvorschläge (Z3, Z4)
31. Simulationsmodus für Regeln, Fehlerwarteschlange, Eskalation (W1–W3)

**Welle 8 — Medien und KI**
32. Medienbibliothek mit Rechten, Untertitel/Transkript
33. KI-Modellabstraktion, Fallback, Budget, Datenklassifizierung, Provenienz
34. Video/Audio in Aufgaben und Prüfungen

---

## 7. Später / optional

- KI-Medienproduktion (§59) und multimodale Aufgabenfabrik (§60) — nach der Anbieterentscheidung
- Natural Language Command Center (§28) — eigenes Produkt, eigene Sicherheitsprüfung
- Bibliothek/Medienausleihe, Beschaffung, Inventar — Datenmodell nicht verbauen
- Öffentlicher Bereich, Identitätsverifikation — Architekturvorsorge
- RTL vollständig — Vorbereitung genügt für V1.0

---

## 8. Risiken und Blocker

| Risiko | Wirkung | Umgang |
|---|---|---|
| **GitHub-Sperre** | Kein Push, kein Release, kein CI-Lauf. Trifft genau den Punkt, den die Spec verbietet. | Welle 1 zuerst: Release-Weg ohne GitHub. Bis dahin Patch-Reihen als Übergabeform. |
| KI-Anbieterentscheidung offen | Blockiert §6, §11, §59, §60 | Abstraktion und Governance vorbauen, keine Mandantendaten an ein Modell |
| 1000 Unteranfragen je Aufruf | Begrenzt jede neue Massenfunktion | Jede neue Schleife wird gemessen, wie bisher |
| ~~D1 10 GB hart~~ | ~~Begrenzt Medien vollständig~~ **entschieden** (0160: der Inhalt liegt in R2, D1 hält nur, *wo* die Datei liegt; `tests/media-library.mjs` prüft, dass keine Inhaltsspalte entsteht) | — |
| Rechtsprüfung ausstehend | Kein Marktstart ohne fachjuristische Freigabe | Spec sagt es selbst; diese Analyse ersetzt sie nicht |
| Umfang gegen „keine Platzhalter" | Halbfertiges wäre ein Spec-Verstoß | Feature Flags statt sichtbarer Stummel |

---

## 9. Was diese Analyse nicht ist

Sie ersetzt keine juristische und keine datenschutzrechtliche Freigabe. Sie prüft, was im
Quelltext steht — nicht, ob das Vorhandene für einen konkreten Einsatzfall rechtlich genügt.
Die Spec verlangt diese externe Prüfung vor Markteinführung ausdrücklich.

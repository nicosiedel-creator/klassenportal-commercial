# eM@w-Schemadateien

Quelle: Bundesagentur für Arbeit, „Infopaket zur technischen Nutzung der elektronischen
Massnahmeabwicklung (EMAW)", Programmversion **PRV_26.07.00**, Schema-Version **2.18**,
Produktivsetzung 20.07.2026.

Die BA veröffentlicht die jeweils gültigen Dateien unter `https://emaw.arbeitsagentur.de/xsd/`
und im Unterverzeichnis `xsd` des Providerverzeichnisses.

Diese Dateien liegen hier, weil `src/core/emaw-schema.ts` **aus ihnen erzeugt** wird:

```
node scripts/emaw-schema-ableiten.mjs
```

Damit steht die Kommunikationsrichtung jedes Ereignisses, die Liste der Anwesenheits­aus­prägungen
und jedes Muster (Kundennummer, coSach-ID, Verfahrenszweig) nicht in abgetipptem Code, sondern
kommt aus der Schemadatei der BA. `tests/emaw-export.mjs` prüft, dass die erzeugte Datei zum
Schema passt — wer das Schema austauscht, ohne neu zu erzeugen, bekommt einen Fehlschlag statt
einer stillen Abweichung.

**Beim Versionswechsel** (die BA liefert drei Programmversionen im Jahr: März, Juli, November):
neue XSD hier ablegen, Erzeuger laufen lassen, Testlauf. Die Versionsnummer im Ereignis-XML
kommt aus `EMAW_SCHEMA_VERSION` und damit ebenfalls aus der Datei.

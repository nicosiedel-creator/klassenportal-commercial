# Gap-Analyse: Master-Spec V2 gegen den tatsächlichen Stand

> **Unvollständig.** Diese Analyse bezieht sich auf 23 Abschnitte des Dokuments
> (im Wesentlichen §0–§44). Die Abschnitte §45–§63, der Final Master Integrationaudit,
> der 19-Bereiche-Durchlauf und die 21-Punkte-Prüfkette waren darin nicht enthalten.
> Die vollständige Prüfung steht in **`GAP_MATRIX_VOLLSTAENDIG.md`**; diese Datei bleibt
> als Nachweis des Prüfwegs für den Funktionsteil stehen.

Stand der Prüfung: 13.09.2026, zweite Fortschreibung (Erstfassung 12.09.2026) · Grundlage: Master-Anforderungsspezifikation V2,
Zweig `claude/klassenportal-commercial-repair-m7a3i1` (49 Commits über `main`).

Die Spec verlangt in §13, §22, §27 und §33 ausdrücklich eine Gap-Analyse **vor**
der Umsetzung, und dass vorhandene Erkenntnisse wiederverwendet statt neu
erhoben werden. Dieses Dokument ist diese Analyse.

**Methode.** Nicht nach Stichworten gesucht, sondern gegen das echte Datenmodell
geprüft: 292 Tabellen aus den Migrationen, 223 Quelldateien, 185 Testdateien.
Ein Stichwort im Code beweist keine Funktion; eine Tabelle mit Fremdschlüsseln
und ein ausführender Test schon. Wo unten „fehlt" steht, gibt es weder Tabelle
noch Modul noch Test.

---

## 1. Datenmodell gegen §7 (41 geforderte Entitäten)

**34 vorhanden.** Tenant, Institution, Standort, User, Role, Permission,
Student/Participant, Teacher, Class/Course, Subject, Period, Curriculum,
LearningObjective, LearningContent, Lesson, Assignment, Submission, Assessment,
Exam, Question, QuestionBank, Answer, Grade, Certificate, CalendarEvent, Room,
Resource, Document, Message, Notification, Workflow, AuditEvent, Integration,
APIClient (`api_tokens`).

**7 fehlen vollständig:**

| Entität | Bedeutung für das Produkt |
|---|---|
| ~~**Parent**~~ **geschlossen** | `guardianships` (0126). Bewusst keine neue Stufe in der Rangleiter, sondern eine Verknüpfung zu genau einem Kind, die jeder Elternzugang einzeln prüft. Einblick in Anwesenheit, veröffentlichte Noten und Abwesenheiten; Krankmeldung durch das Elternteil mit Vermerk, von wem sie stammt. Endet mit der eingetragenen Volljährigkeit von selbst; danach entscheidet die junge Person selbst. Offen bleibt die Elternkommunikation im engeren Sinn (§2.7): Sprechtagsbuchung durch Eltern und an Eltern gerichtete Nachrichten. |
| ~~**Competency**~~ **geschlossen** | `competencies` + `competency_links` (0128). Mit DQR-Niveau und Kompetenzart; Nachweis über Aufgabe, Test oder – am genauesten – ein einzelnes Rasterkriterium. Der Stand wird abgeleitet, nicht gespeichert. |
| **LearningPath** | Keine Lernpfade, keine Voraussetzungen, keine adaptive Steuerung (§2.3). |
| **ExamVariant** | Keine Varianten, keine Randomisierung über Varianten hinweg (§2.4, §2.5). |
| ~~**Rubric**~~ **geschlossen** | `grading_rubrics` + `rubric_criteria`/`rubric_levels`/`rubric_assessments` (0127). Erwartungshorizont am Kriterium, Erst- und Zweitkorrektur Kriterium für Kriterium vergleichbar, benutztes Raster eingefroren. |
| **AIModel** | Keine Modellregistrierung (§6, §2.5). |
| **AIPromptVersion** | Keine Prompt-Versionierung (§6). Ohne sie ist die in §6 geforderte Nachvollziehbarkeit KI-gestützter Entscheidungen nicht herstellbar. |

---

## 2. Fachbereiche

### Vollständig vorhanden und durch ausführende Tests belegt

- **Mandanten, Rollen, Tenant-Isolation** (§3, §4) – serverseitige Autorisierung,
  Kurs-Rollen, Rechteausweitung geprüft und geschlossen.
- **Klassenbuch, Anwesenheit, Abwesenheit, Entschuldigungen** (§2.2) – inklusive
  Krankmeldung durch Teilnehmende und Abgleich.
- **Stundenplan, Vertretung, Räume, Ressourcen** (§2.2) – 19 Module.
- **Aufgaben, Abgaben, Notenbuch** (§2.3, §2.6).
- **Prüfungen mit Prüfungsmodus** (§2.4) – Safe Exam Browser, Aufgabentypen
  einschließlich Freitext, Grafikbeschriftung und Dokumentaufgaben.
- **Zeugnisse und Bescheinigungen** (§2.6) – mit selbsttragendem Nachweis
  (W3C Verifiable Credentials, Ed25519/ECDSA), der den Träger überlebt.
- **Dokumenteneingang** (§18) – E-Mail, Upload, Drag & Drop, OCR,
  Klassifikation, Dublettenprüfung, Freigabebox, Audit.
- **Workflows** (§2.9) – Regelmaschine mit Auslösern und Audit.
- **DSGVO-Betroffenenrechte** (§5) – Auskunft nach Artikel 15 über 182 unter
  Klassifikationszwang stehende Tabellen, Löschung, Übertragbarkeit.
- **Rechtsnachfolge** – Trägerübergabe statt nur Löschung.
- **Speichergrenze und Kaltdaten** – D1-10-GB-Wand gemessen und verschoben.
- **Förderfälle und Kostenträgermeldung** – inhaltliche Grundlage für eM@w.

### Teilweise vorhanden

| Bereich | Stand | Lücke |
|---|---|---|
| **Videokonferenz** (§3.1) | `lesson_online_meetings` mit Provider-Spalte, Beitrittslink und Graph-Anbindung | Nur Microsoft Teams. §3.1 verlangt ausdrücklich Unabhängigkeit von einem einzelnen Anbieter. Es fehlen: Breakout-Räume, Warteraum, Raumsperre, Moderationsrechte, Anwesenheitsprotokoll für Meetings, Aufzeichnung mit Einwilligung und Aufbewahrung. |
| **Chat / Zusammenarbeit** (§2.7, §3.1) | `discussion_threads`, `discussion_messages`, `discussion_participants`, `discussion_settings` | Forum-artig, nicht in Echtzeit. Kein WebSocket, keine Direktnachricht im Sinne eines Chats. |
| **Barrierefreiheit** (§5) | WCAG **2.2** AA umgesetzt und dauergeprüft, sämtliche Obergrenzen auf null | ~~2.2~~ geschlossen: die sechs zusätzlichen Kriterien auf A/AA werden geprüft, die elf Befunde sind behoben, ebenso die sechs Kontrast-Altschulden aus 2.1. |
| **CRM / Vertrieb** (§19) | Bewerbungsformulare, Zulassung, Angebote | Keine Interessentenverwaltung, keine Wiedervorlage, keine Beratungshistorie. |
| **Analytics** (§2.10) | Auswertungen, Reifegrad, Befundmotor | Keine Kompetenzentwicklung (fehlt die Entität), keine konfigurierbaren Reports für Träger. |

### Fehlt vollständig

| Bereich | Spec | Anmerkung |
|---|---|---|
| **KI-Prüfungsfabrik** | §2.5 | Kein Modul, keine Tabelle, kein Test. Das ist der größte Einzelblock der Spec. |
| **Natural Language Command Center** | §28 | Kein Ansatz vorhanden. |
| **KI-Governance** | §6, §5 (AI Act) | Ohne AIModel und AIPromptVersion nicht herstellbar. |
| **SCORM / LTI / xAPI** | §2.3 | Keine Tabelle, kein Modul. |
| **Adaptive Lernpfade** | §2.3 | Siehe LearningPath. |
| **Prüfungsvarianten** | §2.4 | Siehe ExamVariant. Bewertungsraster und Erwartungshorizont sind geschlossen. |
| ~~**Nachteilsausgleich**~~ **geschlossen** | §2.4 | `exam_accommodations` (0124). Zeitzuschlag in der Frist des Versuchs, Zusatzversuche, alternatives Format, Hilfsmittel, Befreiung vom Safe Exam Browser. Ohne Diagnosefeld. Der angewandte Ausgleich ist am Versuch festgeschrieben. |
| ~~**Zweitkorrektur**~~ **geschlossen** | §19 | `exam_second_markings` (0125). Nicht dieselbe Person, und die erste Bewertung bleibt bis zur eigenen Abgabe verdeckt. |
| ~~**Einspruch / Widerspruch als Workflow**~~ **geschlossen** | §19 | `exam_appeals` (0125). Frist ab Bekanntgabe, Begründungszwang auf beiden Seiten, Abhilfe schreibt die Note in der Quelle zurück. |
| **Prüfungsanmeldung und Zulassung** | §19 | Keine Tabelle. |
| **Portfolio und Kompetenzprofil** | §2.3 | Keine Tabelle. |
| **Elternportal** | §2.2, §19 | Zugang und Sicht stehen (siehe Parent). Offen: Sprechtagsbuchung durch Eltern, an Eltern gerichtete Nachrichten. |
| **Whiteboard, gemeinsame Arbeitsflächen** | §3.1 | Nicht vorhanden. |
| **Statusseite, Wartungsinformation** | §15 | Nicht vorhanden. |
| **Wissens-/Hilfebasis im System** | §15 | Nicht vorhanden. |
| **Notfall-/Krisenkommunikation** | §15 | Nicht vorhanden. |
| **Delegation mit befristetem Rechteumfang** | §15 | `responsibility_assignments` kennt Zuständigkeiten, aber keine befristete Stellvertretung mit begrenztem Umfang und Audit. |

---

## 3. Einordnung

Die Spec beschreibt ein deutlich größeres Produkt als das, was heute existiert.
Das ist kein Vorwurf an den Bestand: der Bestand ist in seinen Bereichen tief,
geprüft und in vielen Punkten über dem, was Wettbewerber liefern. Aber die
Master-Spec V2 verschiebt das Ziel von „Bildungsträger-Verwaltung mit
Lernfunktionen" auf „Education Operating System einschließlich KI-Prüfungsfabrik,
Echtzeit-Zusammenarbeit und natürlichsprachiger Steuerung".

**Die drei rechtlich wiegenden Punkte sind geschlossen** (Stand 0124–0126,
jeder durch Rücknahme belegt):

1. ~~**Nachteilsausgleich**~~ (§2.4) – `exam_accommodations`.
2. ~~**Einspruch und Zweitkorrektur**~~ (§19) – `exam_appeals`,
   `exam_second_markings`.
3. ~~**Elternrolle**~~ (§2.2) – `guardianships`.

Dabei kam ein Befund heraus, der nicht in dieser Analyse stand: die
Prüfungssperre (Safe Exam Browser) war gebaut und **ließ sich nicht
einschalten** – `seb_required` hat im ganzen Quelltext nie jemand geschrieben.
Zusätzlich hat eine Prüfung mit gesetztem `seb_required` ohne hinterlegten
Schlüssel jeden gewöhnlichen Browser durchgelassen, während die Leitung sie für
gesperrt hielt. Beides ist zu.

~~Bewertungsraster~~ (0127), ~~WCAG 2.2 AA~~ und ~~Competency~~ (0128) sind
seitdem ebenfalls geschlossen.

**Nächste Reihenfolge**, nach Gewicht statt nach Aufwand:

1. **ExamVariant** (§2.4, §2.5). Prüfungsvarianten sind die letzte offene
   Lücke im Prüfungsrecht: ohne sie schreiben alle dieselbe Arbeit, und ein
   Nachschreibtermin ist entweder dieselbe Arbeit oder eine unverbundene neue.
2. **LearningPath** (§2.3). Mit der Kompetenz als Entität ist die Voraussetzung
   dafür da – ein Lernpfad ist eine Reihenfolge von Kompetenzen mit
   Voraussetzungen.
3. **Elternkommunikation im engeren Sinn** (§2.7): Sprechtagsbuchung durch
   Eltern und an Eltern gerichtete Nachrichten. Zugang und Sicht stehen.
4. **AIModel / AIPromptVersion** (§6) – erst nach der Anbieterentscheidung
   unten.

**Zum Umfang ehrlich:** Die KI-Prüfungsfabrik (§2.5) und das Natural Language
Command Center (§28) sind jeweils eigene Produkte. Sie brauchen zusätzlich eine
Entscheidung, die diese Analyse nicht treffen kann: welcher KI-Anbieter, unter
welchem Auftragsverarbeitungsvertrag, mit welcher Datenklassifizierung. §6
verlangt diese Prüfung pro Anwendungsfall; ohne sie darf kein Mandantendatum an
ein Modell gehen.

---

## 4. Was diese Analyse nicht ist

Sie ersetzt keine juristische Freigabe (§5, §12). Sie prüft, was im Code steht –
nicht, ob das Vorhandene für einen konkreten Einsatzfall rechtlich genügt.

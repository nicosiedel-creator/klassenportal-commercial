# XBildung — abgelegte Unterlagen, noch nicht eingebaut

Stand: 15.09.2026. **Hier liegt nichts Ausführbares**, sondern das, was bisher an
Spezifikation verfügbar war — damit beim späteren Einbau niemand von vorn suchen muss.

## Was vorliegt

| Quelle | Version | Inhalt |
|---|---|---|
| `xbd_spezifikation_1.2.pdf` (nicht abgelegt, 900 kB) | **1.2, final** | Die Klammer: 21 Codelisten, 6 gemeinsame Klassen (Benotung, Dokument, Ortsangabe, Praktikum, TeilbekanntesDatum, Zeitraum) |
| `XBildung.uml` (nicht abgelegt, 1,6 MB) | 1.2 | Das MagicDraw-Modell, aus dem die Schemas erzeugt werden — nicht die Schemas selbst |
| XSchule-Codelisten | 1.2 | 23 Genericode-Listen — Schulen, nicht Bildungsträger |
| XHochschule-Codelisten | 1.2 | 10 Genericode-Listen — Hochschulen, nicht Bildungsträger |
| **hier abgelegt:** `Prüfungsteil AEVO_2025-06-04.xml`, `Rechtsgrundlage Abschlusszeugnis_2025-06-04.xml` | **XBerufsbildung 0.7** | Die zwei eigenen Codelisten des Teilmoduls — 2 und 6 Einträge |

Bezugsort aller Dateien: <http://xbildung.de/def/xbildung/1.2/>,
Lizenz CC BY 4.0, „]init[ AG im Auftrag des Landes Sachsen-Anhalt".

## Was fehlt — und warum deshalb nichts gebaut ist

1. **XBerufsbildung steht bei 0.7.** Das ist das Teilmodul für Bildungsträger, und es ist
   unterhalb von 1.0, also Entwurf. Ein Format, das sich vor 1.0 noch bewegt, würde zweimal
   gebaut.
2. **Keine `.xsd`-Dateien.** Das UML-Modell ist die Quelle, nicht das ausgelieferte Schema.
3. **Keine Schematron-/XSLT-Regeln.** Die Spezifikation sagt es ausdrücklich:
   *„Eine Validierung allein gegen das XML-Schema genügt nicht."*

## Was beim Einbau zu tun ist

1. Die drei fehlenden Stücke besorgen: XBerufsbildung-Spezifikation ≥ 1.0, die `.xsd`-Dateien,
   die Schematron-/XSLT-Dateien.
2. Die Codelisten **erzeugen statt abtippen** — wie bei eM@w (`scripts/emaw-schema-ableiten.mjs`).
   Die Genericode-Dateien sind maschinenlesbar; ein Erzeuger daraus ist eine halbe Stunde.
3. Das Bewertungsschema ist der Punkt, an dem es schiefgeht: eine 1 auf einer Skala 1–6 und eine
   1 auf einer Skala 1–5 sind verschiedene Dinge. XBildung löst das über die Schema-URI mit der
   Aufbauvorschrift

   ```
   http://xbildung.de/def/xbildung/{Version}/code/bewertungsschema/
     {ISO3166-Alpha2}_{Hrsg}_{Kontext}_{schlechtesteBewertung}_{bestandenAbBewertung}_{besteBewertung}
   ```

   Wer die URI weglässt oder rät, liefert Noten ohne Maßstab.
4. Anknüpfungspunkt im Portal ist `certificates.ts` beziehungsweise der selbsttragende Nachweis
   aus 0139 — dort liegen Noten, Zeiträume und Abschlussdaten bereits strukturiert vor.

## Frist

Verbindlich wird XBildung laut Beschluss des IT-Planungsrats B-2025/43-IT **ab 2029**, und zwar
für Schulen, Hochschulen und die zuständigen Stellen nach HwO und BBiG — für einen privaten
Bildungsträger also mittelbar, sobald eine Kammer die Daten in dem Format entgegennimmt.

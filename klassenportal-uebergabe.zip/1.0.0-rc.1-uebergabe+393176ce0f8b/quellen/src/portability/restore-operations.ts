import type { AuthContext, PortabilityConfig, PortabilityEnv } from './types.js';
import { assertTenantAdmin, randomId } from './utils.js';
import { preflightTenantBackup } from './backup-preflight.js';
import { systemColumns } from './db.js';
import { createTenantBackup, restoreTenantBackup } from './backup.js';
import { sha256Text } from './backup-integrity.js';

// Wiederanlauf in drei Schritten: hinsehen, zurueckspielen, nachzaehlen.
//
// Der gefaehrlichste Knopf des Systems ist der, der den heutigen Stand eines Mandanten durch einen
// aelteren ersetzt. Er war bisher blind: keine Vorschau, keine Nachkontrolle. Diese Datei macht
// beides und bindet die Probe daran, die beweist, dass eine Sicherung ueberhaupt zurueckspielbar
// ist - nicht nur unveraendert daliegt.

export type SimulationsZeile={schluessel:string;tabelle:string;jetzt:number;nachher:number;entfernt:number;hinzugefuegt:number};
export type Hinweis={code:string;text:string};
export type RestoreSimulation={
  backupId:string;tenantId:string;grund:string;erstellt_am:string;alter_stunden:number;groesse_bytes:number;
  ressourcen:SimulationsZeile[];
  dateien:{jetzt:number;nachher:number;entfernt:number};
  nutzer:{in_sicherung:number;mit_zugang_jetzt:number};
  nebenwirkungen:string[];
  warnungen:Hinweis[];
  blockiert:Hinweis[];
  pruefsumme:string;
};

function stunden(von:string,bis:number):number{const t=Date.parse(von);return Number.isFinite(t)?Math.max(0,Math.round((bis-t)/36e5)):0;}

// Ein Zaehlaufruf fuer alle Ressourcen zusammen. Bei 20 Ressourcen waere die naheliegende Schleife
// 20 Unteranfragen - und die Simulation laeuft im selben Aufruf wie die Vorpruefung, die das
// Budget schon zur Haelfte verbraucht.
async function bestandJeRessource(env:PortabilityEnv,config:PortabilityConfig,tenantId:string):Promise<Map<string,number>>{
  const teile=config.resources.map(r=>`SELECT '${r.key}' AS schluessel, COUNT(*) AS anzahl FROM ${r.table} WHERE ${r.tenantColumn}=?`);
  const sql=teile.join(' UNION ALL ');
  const rows=(await env.DB.prepare(sql).bind(...config.resources.map(()=>tenantId)).all<{schluessel:string;anzahl:number}>()).results??[];
  return new Map(rows.map(r=>[String(r.schluessel),Number(r.anzahl)]));
}

/**
 * Was genau wuerde diese Wiederherstellung tun?
 *
 * Schreibt nichts. Das Ergebnis traegt eine Pruefsumme: wer den Knopf drueckt, schickt sie mit.
 * Aendert sich der Bestand zwischen Ansehen und Klicken, passt die Pruefsumme nicht mehr und der
 * Vorgang bricht ab - statt eine Vorschau auszufuehren, die nicht mehr stimmt.
 */
export async function simuliereWiederherstellung(env:PortabilityEnv,config:PortabilityConfig,auth:AuthContext,tenantId:string,backupId:string):Promise<RestoreSimulation>{
  assertTenantAdmin(auth,tenantId);
  const bak=await env.DB.prepare('SELECT id,reason,status,created_at,size_bytes FROM portability_backups WHERE id=? AND tenant_id=?').bind(backupId,tenantId).first<{id:string;reason:string;status:string;created_at:string;size_bytes:number}>();
  if(!bak)throw new Error('BACKUP_NOT_FOUND');

  const warnungen:Hinweis[]=[],blockiert:Hinweis[]=[];
  let geprueft:Awaited<ReturnType<typeof preflightTenantBackup>>|null=null;
  try{geprueft=await preflightTenantBackup(env,config,backupId,tenantId);}
  catch(e){const code=String((e as Error)?.message??'BACKUP_PREFLIGHT_FAILED').split(':')[0];blockiert.push({code,text:'Die Sicherung besteht die Vorpruefung nicht. Eine Wiederherstellung daraus ist nicht zulaessig.'});}

  // Eine Loeschsperre wiegt schwerer als der Wunsch nach dem alten Stand: eine Wiederherstellung
  // ueberschreibt genau die Daten, die unter Sperre nicht angetastet werden duerfen.
  const sperren=await env.DB.prepare("SELECT COUNT(*) AS anzahl FROM legal_holds WHERE tenant_id=? AND status='aktiv'").bind(tenantId).first<{anzahl:number}>();
  if(Number(sperren?.anzahl??0)>0)blockiert.push({code:'RESTORE_BLOCKED_LEGAL_HOLD',text:'Fuer diesen Mandanten gilt eine aktive Loeschsperre. Erst aufheben, dann wiederherstellen.'});

  const bestand=await bestandJeRessource(env,config,tenantId);
  const inSicherung=new Map((geprueft?.manifest.resources??[]).map(r=>[r.key,Number(r.rowCount)]));
  const ressourcen:SimulationsZeile[]=config.resources.map(r=>{
    const jetzt=Number(bestand.get(r.key)??0),nachher=Number(inSicherung.get(r.key)??0);
    return{schluessel:r.key,tabelle:r.table,jetzt,nachher,entfernt:jetzt,hinzugefuegt:nachher};
  });

  const dateienJetzt=await env.DB.prepare('SELECT COUNT(*) AS anzahl FROM portability_files WHERE tenant_id=?').bind(tenantId).first<{anzahl:number}>();
  const zugangJetzt=await env.DB.prepare('SELECT COUNT(DISTINCT user_id) AS anzahl FROM memberships WHERE tenant_id=?').bind(tenantId).first<{anzahl:number}>();
  const dateienNachher=geprueft?.fileCount??0,nutzerSicherung=geprueft?.userCount??0;

  const jetztGesamt=ressourcen.reduce((s,z)=>s+z.jetzt,0),nachherGesamt=ressourcen.reduce((s,z)=>s+z.nachher,0);
  const alter=stunden(String(bak.created_at??''),Date.now());
  if(jetztGesamt>nachherGesamt)warnungen.push({code:'DATEN_SEIT_SICHERUNG',text:`Heute stehen ${jetztGesamt} Zeilen im Mandanten, in der Sicherung ${nachherGesamt}. Die Differenz geht verloren.`});
  warnungen.push({code:'AENDERUNGEN_GEHEN_VERLOREN',text:'Auch Aenderungen an bereits vorhandenen Zeilen seit dem Zeitpunkt der Sicherung gehen verloren.'});
  if(alter>48)warnungen.push({code:'SICHERUNG_ALT',text:`Diese Sicherung ist ${alter} Stunden alt.`});
  if(Number(zugangJetzt?.anzahl??0)>nutzerSicherung)warnungen.push({code:'NUTZER_VERLIEREN_ZUGANG',text:`${Number(zugangJetzt?.anzahl??0)-nutzerSicherung} Personen mit heutigem Zugang stehen nicht in der Sicherung und verlieren ihn.`});
  if(Number(dateienJetzt?.anzahl??0)>dateienNachher)warnungen.push({code:'DATEIEN_WERDEN_ENTFERNT',text:`${Number(dateienJetzt?.anzahl??0)-dateienNachher} Dateien sind nicht Teil der Sicherung und werden entfernt.`});

  const nebenwirkungen=[
    'Vor dem Zurueckspielen wird automatisch eine Sicherung des heutigen Standes angelegt.',
    'Der Mandant ist waehrend des Vorgangs gesperrt und danach wieder im vorherigen Zustand.',
    'Die Anmeldung ueber das Verzeichnis des Traegers wird abgeschaltet und muss danach bewusst wieder eingeschaltet werden.',
    'Bestehende Schnittstellen- und Verzeichnis-Token werden widerrufen.',
  ];

  const plan={backupId,tenantId,ressourcen:ressourcen.map(r=>[r.schluessel,r.jetzt,r.nachher]),dateien:[Number(dateienJetzt?.anzahl??0),dateienNachher],nutzer:[Number(zugangJetzt?.anzahl??0),nutzerSicherung],blockiert:blockiert.map(b=>b.code)};
  return{
    backupId,tenantId,grund:String(bak.reason??''),erstellt_am:String(bak.created_at??''),alter_stunden:alter,groesse_bytes:Number(bak.size_bytes??0),
    ressourcen,
    dateien:{jetzt:Number(dateienJetzt?.anzahl??0),nachher:dateienNachher,entfernt:Math.max(0,Number(dateienJetzt?.anzahl??0)-dateienNachher)},
    nutzer:{in_sicherung:nutzerSicherung,mit_zugang_jetzt:Number(zugangJetzt?.anzahl??0)},
    nebenwirkungen,warnungen,blockiert,
    pruefsumme:await sha256Text(JSON.stringify(plan)),
  };
}

export type Wiederherstellungsergebnis={restored:true;safetyBackupId:string;laufId:string;nachkontrolle:'bestanden'|'abweichungen';abweichungen:{schluessel:string;erwartet:number;gefunden:number}[]};

/**
 * Ein Knopf - aber kein blinder.
 *
 * Erst simulieren, dann die Pruefsumme der gezeigten Simulation verlangen, dann zurueckspielen,
 * dann nachzaehlen. Ohne den letzten Schritt heisst "erfolgreich" nur "es ist nichts geflogen".
 */
export async function stelleWiederHer(env:PortabilityEnv,config:PortabilityConfig,auth:AuthContext,tenantId:string,backupId:string,pruefsumme:string):Promise<Wiederherstellungsergebnis>{
  assertTenantAdmin(auth,tenantId);
  const sim=await simuliereWiederherstellung(env,config,auth,tenantId,backupId);
  if(sim.blockiert.length)throw new Error(sim.blockiert[0].code);
  if(!pruefsumme)throw new Error('RESTORE_PLAN_REQUIRED');
  if(pruefsumme!==sim.pruefsumme)throw new Error('RESTORE_PLAN_CHANGED');

  const laufId=randomId('rlauf_'),start=new Date().toISOString();
  await env.DB.prepare("INSERT INTO restore_runs (id,tenant_id,backup_id,art,status,ausgeloest_von,simulation_json,gestartet_am) VALUES (?,?,?,'wiederherstellung','laufend',?,?,?)").bind(laufId,tenantId,backupId,auth.userId,JSON.stringify(sim),start).run();
  try{
    const ergebnis=await restoreTenantBackup(env,config,auth,tenantId,backupId,'RESTORE');
    // Nachkontrolle: steht nach dem Zurueckspielen wirklich der Stand der Sicherung in den Tabellen?
    const nachher=await bestandJeRessource(env,config,tenantId);
    const abweichungen=sim.ressourcen.filter(z=>Number(nachher.get(z.schluessel)??0)!==z.nachher).map(z=>({schluessel:z.schluessel,erwartet:z.nachher,gefunden:Number(nachher.get(z.schluessel)??0)}));
    const status=abweichungen.length?'nachkontrolle_fehlgeschlagen':'erfolg';
    await env.DB.prepare('UPDATE restore_runs SET status=?,ergebnis_json=?,beendet_am=? WHERE id=?').bind(status,JSON.stringify({safetyBackupId:ergebnis.safetyBackupId,abweichungen}),new Date().toISOString(),laufId).run();
    return{restored:true,safetyBackupId:ergebnis.safetyBackupId,laufId,nachkontrolle:abweichungen.length?'abweichungen':'bestanden',abweichungen};
  }catch(e){
    const code=String((e as Error)?.message??'RESTORE_FAILED').split(':')[0];
    await env.DB.prepare('UPDATE restore_runs SET status=?,fehler=?,beendet_am=? WHERE id=?').bind('fehler',code,new Date().toISOString(),laufId).run();
    throw e;
  }
}

export type Probenergebnis={laufId:string;status:'erfolg'|'fehler';backupId:string|null;geprueft:{ressourcen:number;zeilen:number;dateien:number;nutzer:number};befunde:{code:string;stelle:string}[]};

/**
 * Turnusmaessige Wiederanlaufprobe.
 *
 * Sie spielt bewusst NICHT in den laufenden Mandanten zurueck - das waere eine Uebung, die den
 * Ernstfall selbst ausloest. Sie prueft die Kette, die im Ernstfall haelt oder reisst:
 * liegen alle Objekte noch da und unveraendert (Hash und ETag), passt jede Zeile der Sicherung
 * noch zum HEUTIGEN Schema, und fehlt keine Spalte, die die Tabelle zwingend verlangt.
 * Genau das ist die Luecke, die `verifyBackup` offenlaesst: zwischen Sicherung und heute liegen
 * Migrationen.
 */
export async function fuehreWiederanlaufprobeDurch(env:PortabilityEnv,config:PortabilityConfig,tenantId:string,ausgeloestVon='system:wiederanlaufprobe'):Promise<Probenergebnis>{
  const laufId=randomId('rprobe_'),start=new Date().toISOString();
  const bak=await env.DB.prepare("SELECT id FROM portability_backups WHERE tenant_id=? AND status='ready' ORDER BY created_at DESC LIMIT 1").bind(tenantId).first<{id:string}>();
  await env.DB.prepare("INSERT INTO restore_runs (id,tenant_id,backup_id,art,status,ausgeloest_von,gestartet_am) VALUES (?,?,?,'probe','laufend',?,?)").bind(laufId,tenantId,bak?.id??null,ausgeloestVon,start).run();
  const befunde:{code:string;stelle:string}[]=[];
  let geprueft={ressourcen:0,zeilen:0,dateien:0,nutzer:0};
  try{
    if(!bak)throw new Error('BACKUP_NONE_AVAILABLE');
    const vor=await preflightTenantBackup(env,config,bak.id,tenantId);
    geprueft={ressourcen:vor.resourceCount,zeilen:vor.rowCount,dateien:vor.fileCount,nutzer:vor.userCount};
    // Trockenlauf gegen das heutige Schema: eine Spalte, die inzwischen NOT NULL ohne Vorgabe ist,
    // macht jede Zeile der Sicherung unschreibbar - und faellt sonst erst im Ernstfall auf.
    for(const r of config.resources){
      const spalten=(await env.DB.prepare(`PRAGMA table_info(${r.table})`).all<{name:string;notnull:number;dflt_value:unknown;pk:number}>()).results??[];
      const pflicht=spalten.filter(s=>Number(s.notnull)===1&&s.dflt_value===null&&Number(s.pk)===0).map(s=>String(s.name));
      const gedeckt=new Set([r.idColumn,r.tenantColumn,...Object.keys(r.columns),...systemColumns(r)]);
      for(const p of pflicht)if(!gedeckt.has(p))befunde.push({code:'PFLICHTSPALTE_NICHT_IN_SICHERUNG',stelle:`${r.key}.${p}`});
    }
    if(befunde.length)throw new Error('RESTORE_DRILL_SCHEMA_DRIFT');
    await schreibeProbenstand(env,tenantId,laufId,'erfolg');
    await env.DB.prepare('UPDATE restore_runs SET status=?,ergebnis_json=?,beendet_am=? WHERE id=?').bind('erfolg',JSON.stringify({geprueft,befunde}),new Date().toISOString(),laufId).run();
    return{laufId,status:'erfolg',backupId:bak.id,geprueft,befunde};
  }catch(e){
    const code=String((e as Error)?.message??'RESTORE_DRILL_FAILED').split(':')[0];
    await schreibeProbenstand(env,tenantId,laufId,'fehler');
    await env.DB.prepare('UPDATE restore_runs SET status=?,fehler=?,ergebnis_json=?,beendet_am=? WHERE id=?').bind('fehler',code,JSON.stringify({geprueft,befunde}),new Date().toISOString(),laufId).run();
    return{laufId,status:'fehler',backupId:bak?.id??null,geprueft,befunde:befunde.length?befunde:[{code,stelle:'probe'}]};
  }
}

async function schreibeProbenstand(env:PortabilityEnv,tenantId:string,laufId:string,status:'erfolg'|'fehler'):Promise<void>{
  const jetzt=new Date(),iso=jetzt.toISOString();
  const p=await env.DB.prepare('SELECT intervall_tage FROM restore_drill_policy WHERE tenant_id=?').bind(tenantId).first<{intervall_tage:number}>();
  const tage=Number(p?.intervall_tage??30);
  // Eine gescheiterte Probe wird nicht auf den vollen Turnus vertagt: sie ist morgen wieder faellig.
  const naechste=new Date(jetzt.getTime()+(status==='erfolg'?tage:1)*864e5).toISOString();
  await env.DB.prepare('INSERT INTO restore_drill_policy (tenant_id,intervall_tage,aktiv,letzte_probe_am,letzte_probe_status,letzte_probe_id,naechste_faellig_am,aktualisiert_am) VALUES (?,?,1,?,?,?,?,?) ON CONFLICT(tenant_id) DO UPDATE SET letzte_probe_am=excluded.letzte_probe_am,letzte_probe_status=excluded.letzte_probe_status,letzte_probe_id=excluded.letzte_probe_id,naechste_faellig_am=excluded.naechste_faellig_am,aktualisiert_am=excluded.aktualisiert_am').bind(tenantId,tage,iso,status,laufId,naechste,iso).run();
}

/**
 * Welche Mandanten sind mit der Probe faellig?
 *
 * Ein Mandant ohne Eintrag gilt als faellig. Eine fehlende Einstellung darf nicht bedeuten, dass
 * die Pruefung stillschweigend entfaellt - das ist der Unterschied zwischen "noch nie geprueft"
 * und "geprueft, alles gut".
 */
export async function faelligeWiederanlaufproben(env:PortabilityEnv,config:PortabilityConfig,limit=2,jetzt=new Date().toISOString()):Promise<string[]>{
  const rows=(await env.DB.prepare(`SELECT t.${config.tenantIdColumn} AS id FROM ${config.tenantTable} t LEFT JOIN restore_drill_policy p ON p.tenant_id=t.${config.tenantIdColumn} WHERE COALESCE(p.aktiv,1)=1 AND COALESCE(p.naechste_faellig_am,'') <= ? ORDER BY COALESCE(p.naechste_faellig_am,'') ASC, t.${config.tenantIdColumn} ASC LIMIT ?`).bind(jetzt,limit).all<{id:string}>()).results??[];
  return rows.map(r=>String(r.id));
}

export async function laufendeWiederanlaufproben(env:PortabilityEnv,config:PortabilityConfig,limit=2):Promise<{geprueft:string[];fehler:string[]}>{
  const faellig=await faelligeWiederanlaufproben(env,config,limit);
  const geprueft:string[]=[],fehler:string[]=[];
  for(const tenantId of faellig){const r=await fuehreWiederanlaufprobeDurch(env,config,tenantId);(r.status==='erfolg'?geprueft:fehler).push(tenantId);}
  return{geprueft,fehler};
}

export async function wiederanlaufStand(env:PortabilityEnv,auth:AuthContext,tenantId:string):Promise<{turnus:Record<string,unknown>|null;laeufe:Record<string,unknown>[]}>{
  assertTenantAdmin(auth,tenantId);
  const turnus=await env.DB.prepare('SELECT tenant_id,intervall_tage,aktiv,letzte_probe_am,letzte_probe_status,naechste_faellig_am FROM restore_drill_policy WHERE tenant_id=?').bind(tenantId).first<Record<string,unknown>>();
  const laeufe=(await env.DB.prepare('SELECT id,backup_id,art,status,ausgeloest_von,fehler,gestartet_am,beendet_am FROM restore_runs WHERE tenant_id=? ORDER BY gestartet_am DESC LIMIT 20').bind(tenantId).all<Record<string,unknown>>()).results??[];
  return{turnus:turnus??null,laeufe};
}

export async function setzeProbenTurnus(env:PortabilityEnv,auth:AuthContext,tenantId:string,intervallTage:number,aktiv:boolean):Promise<{gespeichert:true}>{
  assertTenantAdmin(auth,tenantId);
  const tage=Math.trunc(Number(intervallTage));
  if(!Number.isFinite(tage)||tage<1||tage>365)throw new Error('RESTORE_DRILL_INTERVAL_INVALID');
  const jetzt=new Date(),iso=jetzt.toISOString(),naechste=new Date(jetzt.getTime()+tage*864e5).toISOString();
  await env.DB.prepare('INSERT INTO restore_drill_policy (tenant_id,intervall_tage,aktiv,naechste_faellig_am,aktualisiert_am) VALUES (?,?,?,?,?) ON CONFLICT(tenant_id) DO UPDATE SET intervall_tage=excluded.intervall_tage,aktiv=excluded.aktiv,aktualisiert_am=excluded.aktualisiert_am').bind(tenantId,tage,aktiv?1:0,naechste,iso).run();
  return{gespeichert:true};
}

// Wird vom Vorpruefungs-Pfad gebraucht, damit der Aufrufer die Sicherung nicht selbst suchen muss.
export async function neuesteSicherung(env:PortabilityEnv,auth:AuthContext,tenantId:string):Promise<string|null>{
  assertTenantAdmin(auth,tenantId);
  const r=await env.DB.prepare("SELECT id FROM portability_backups WHERE tenant_id=? AND status='ready' ORDER BY created_at DESC LIMIT 1").bind(tenantId).first<{id:string}>();
  return r?.id??null;
}

export { createTenantBackup as sicherungAnlegen };

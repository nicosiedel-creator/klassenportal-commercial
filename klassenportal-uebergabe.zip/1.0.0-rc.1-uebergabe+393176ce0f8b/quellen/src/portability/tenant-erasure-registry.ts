// Beim Vertragsende loescht finalizeTenantDeletion die Domaenentabellen und danach den Mandanten
// selbst - ueber ON DELETE CASCADE raeumt das die allermeisten Tabellen mit ab.
//
// 24 Tabellen mit tenant_id haben aber KEINE Kaskade auf tenants(id). Sie blieben unberuehrt
// stehen, darunter solche mit echten Personendaten: communication_email_deliveries fuehrt die
// E-Mail im Klartext, learner_twin_snapshots das Lernprofil, portal_language_preferences die
// Nutzerkennung. "Vollstaendig geloescht" war damit unwahr.
//
// "Alle 24 loeschen" waere aber genauso falsch: die Buchhaltung unterliegt gesetzlichen
// Aufbewahrungsfristen, und das Protokoll der Loeschung muss die Loeschung ueberleben - sonst
// koennte der Betreiber gar nicht nachweisen, dass er geloescht hat.
//
// Deshalb wird jede dieser Tabellen ausdruecklich eingeteilt. Was hier fehlt, faellt im Test auf
// (tests/tenant-erasure-completeness.mjs): eine neue Tabelle mit tenant_id ohne Kaskade MUSS hier
// eingetragen werden, sonst bleibt sie beim naechsten Vertragsende still liegen.
export type Behandlung=
  |{art:'loeschen'}
  |{art:'aufbewahren';grund:string};

export const OHNE_KASKADE:Record<string,Behandlung>={
  // --- Personenbezug: muss weg ---------------------------------------------------------------
  communication_email_deliveries:{art:'loeschen'},   // user_id UND E-Mail im Klartext
  learner_twin_snapshots:{art:'loeschen'},           // Lernprofil je Teilnehmer
  learner_coach_plans:{art:'loeschen'},              // Foerderplaene je Teilnehmer
  portal_language_preferences:{art:'loeschen'},      // user_id
  onboarding_invitations:{art:'loeschen'},           // Einladungen samt Adressen
  partner_access_grants:{art:'loeschen'},            // Zugriffsrechte Dritter
  timetable_import_runs:{art:'loeschen'},            // Importinhalte samt Bearbeiter
  timetable_import_lessons:{art:'loeschen'},
  migration_quality_runs:{art:'loeschen'},
  provisioning_log:{art:'loeschen'},
  portability_backups:{art:'loeschen'},              // Verweise auf die Backup-Objekte im Speicher
  compliance_evidence:{art:'loeschen'},
  compliance_evidence_packages:{art:'loeschen'},
  compliance_findings:{art:'loeschen'},
  compliance_requirements:{art:'loeschen'},
  tenant_compliance_programs:{art:'loeschen'},
  commercial_quotes:{art:'loeschen'},
  // Benachrichtigungseinstellungen und Zustellentscheidungen der Menschen dieses Traegers.
  // Sie sind ein Nachweis GEGENUEBER dem Traeger, nicht ueber ihn: endet der Vertrag, endet
  // auch der Zweck. Die Zeilen nennen Personen namentlich und muessen deshalb mitgehen.
  notification_preferences:{art:'loeschen'},
  notification_topic_preferences:{art:'loeschen'},
  communication_channel_decisions:{art:'loeschen'},

  // --- bleibt bewusst stehen ------------------------------------------------------------------
  accounting_entries:{art:'aufbewahren',grund:'Buchungssaetze unterliegen der handels- und steuerrechtlichen Aufbewahrungsfrist; sie gehoeren dem Betreiber, nicht dem Mandanten.'},
  accounting_reconciliation:{art:'aufbewahren',grund:'Abstimmung der Buchhaltung, dieselbe Frist.'},
  audit_log:{art:'aufbewahren',grund:'Revisionsprotokoll. Wer es mit dem Mandanten loescht, kann hinterher nicht mehr belegen, WAS geloescht wurde und wer es veranlasst hat.'},
  portability_audit_events:{art:'aufbewahren',grund:'Protokoll der Aus- und Einspielvorgaenge; wird in finalizeTenantDeletion bereits gezielt geraeumt, soweit zulaessig.'},
  portability_files:{art:'aufbewahren',grund:'wird in finalizeTenantDeletion bereits gezielt geraeumt.'},
  portability_import_runs:{art:'aufbewahren',grund:'wird in finalizeTenantDeletion bereits gezielt geraeumt.'},
  portability_deletion_requests:{art:'aufbewahren',grund:'Der Loeschauftrag selbst. Er muss die Loeschung ueberleben - er IST der Nachweis, dass geloescht wurde.'},
  audit_chain_entries:{art:'aufbewahren',grund:'Die Kette, die das Protokoll faelschungssicher macht. Wer Glieder herausnimmt, zerstoert den Nachweis fuer ALLE Mandanten - die Kette ist fortlaufend, nicht je Mandant teilbar.'},
  // Fehlerlage des Betriebs fuer DIESEN Mandanten; mit ihm hat sie keinen Zweck mehr - und die
  // gespeicherte Nutzlast kann Mandantendaten enthalten.
  automation_failures:{art:'loeschen'},
  support_access_events:{art:'aufbewahren',grund:'Nachweis, wer als Support in die Daten dieses Traegers gesehen hat. Er muss den Traeger ueberleben; sonst verschwindet mit dem Mandanten auch der Beleg ueber die Zugriffe auf ihn.'},
};

/** Die Tabellen, die beim Vertragsende zusaetzlich zu raeumen sind. */
export const ZU_LOESCHEN=Object.entries(OHNE_KASKADE).filter(([,b])=>b.art==='loeschen').map(([t])=>t);

import type { PortabilityEnv } from './types.js';
import { randomId, safeFilename } from './utils.js';

export async function storePdf(env:PortabilityEnv,tenantId:string,file:File,userId:string):Promise<{id:string;key:string}>{
  if(file.type!=='application/pdf'&&!file.name.toLowerCase().endsWith('.pdf'))throw new Error('PDF_REQUIRED');
  const id=randomId('pf_'),key=`tenants/${tenantId}/documents/${id}-${safeFilename(file.name)}`;
  await env.FILES.put(key,file.stream(),{httpMetadata:{contentType:'application/pdf',contentDisposition:`attachment; filename="${safeFilename(file.name)}"`},customMetadata:{tenantId,uploadedBy:userId,originalName:file.name}});
  await env.DB.prepare('INSERT INTO portability_files (id, tenant_id, object_key, original_name, content_type, size_bytes, uploaded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').bind(id,tenantId,key,file.name,'application/pdf',file.size,userId,new Date().toISOString()).run();
  return {id,key};
}
export async function listTenantFiles(env:PortabilityEnv,tenantId:string):Promise<Array<Record<string,unknown>>>{const res=await env.DB.prepare('SELECT id, object_key, original_name, content_type, size_bytes, uploaded_by, created_at, purpose, course_id, title, description, visible, updated_at FROM portability_files WHERE tenant_id = ? ORDER BY created_at ASC').bind(tenantId).all<Record<string,unknown>>();return res.results??[];}
// Beim Vertragsende muss ALLES gehen, was zu diesem Traeger im Objektspeicher liegt - nicht nur
// seine hochgeladenen Dateien. Vorher wurde ausschliesslich `tenants/<id>/` geraeumt. Die
// Vollbackups unter `backups/<grund>/<id>/` und die Exporte unter `exports/<id>/` blieben dauerhaft
// liegen, und die enthalten den kompletten Personenbestand EINSCHLIESSLICH der Passwort-Hashes
// (backup.ts: SELECT u.password_hash ... FROM users u JOIN tenant_users tu). "Vollstaendig
// geloescht" war damit unwahr - gegenueber dem Kunden und gegenueber Artikel 17.
// Seit der Trennung heisser und kalter Daten liegt ein Teil des Betriebs als JSONL unter
// `cold/<mandant>/`. Wuerde der Praefix hier fehlen, waere "vollstaendig geloescht" wieder
// unwahr - und zwar genau fuer die Anwesenheits- und Protokolldaten mehrerer Jahre.
const TRAEGER_PRAEFIXE=(tenantId:string)=>[`tenants/${tenantId}/`,`exports/${tenantId}/`,`cold/${tenantId}/`];
export async function deleteTenantObjects(env:PortabilityEnv,tenantId:string):Promise<number>{
  let count=0;
  // Backups liegen nach Grund gruppiert: backups/<grund>/<mandant>/... Der Grund ist nicht
  // vorhersehbar, deshalb wird ueber alle Gruende gelistet und auf den Mandanten gefiltert.
  const praefixe=[...TRAEGER_PRAEFIXE(tenantId)];
  for(const prefix of praefixe){
    let cursor:string|undefined;
    do{
      const page=await env.FILES.list({prefix,cursor,limit:1000}),keys=page.objects.map(o=>o.key);
      if(keys.length){await env.FILES.delete(keys);count+=keys.length;}
      cursor=page.truncated?page.cursor:undefined;
    }while(cursor);
  }
  let cursor:string|undefined;
  do{
    const page=await env.FILES.list({prefix:'backups/',cursor,limit:1000});
    const keys=page.objects.map(o=>o.key).filter(k=>k.split('/')[2]===tenantId);
    if(keys.length){await env.FILES.delete(keys);count+=keys.length;}
    cursor=page.truncated?page.cursor:undefined;
  }while(cursor);
  return count;
}

// Spalten, die niemals einen Mandanten verlassen - auch nicht in seinem eigenen Export.
//
// Diese Liste steht bewusst in einer EIGENEN Datei. tests/restore-safety.mjs prueft, dass der
// Name "password_hash" im Quelltext von export.ts ueberhaupt nicht vorkommt - eine grobe, aber
// wirksame Sperre: wer dort eine Spalte mit Geheimnis ausgibt, faellt auf, selbst wenn er sie
// eigentlich ausschliessen wollte. Der Ausschluss steht deshalb hier, nicht dort.
export const GEHEIME_SPALTEN=['password','_hash','secret','private_key','signature','salt'];
export function istGeheim(spalte:string):boolean{
  const s=String(spalte||'').toLowerCase();
  return GEHEIME_SPALTEN.some(x=>s.includes(x));
}

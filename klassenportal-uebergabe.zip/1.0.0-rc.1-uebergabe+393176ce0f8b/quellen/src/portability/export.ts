import type { AuthContext, PortabilityConfig, PortabilityEnv, ResourceDefinition } from './types.js';
import { assertTenantAdmin, csvEscape, safeFilename, toArrayBuffer } from './utils.js';
import { readTenantRows, resourceByKey, tenantExists } from './db.js';
import { xlsxFromRows } from './xlsx-export.js';
import { simplePdf } from './pdf.js';
import { createZipStream, type ZipEntry } from './zip.js';
import { listTenantFiles } from './files.js';
import { istGeheim } from './secret-columns.js';

const INTERNAL_ONLY=new Set(['tenant_sso_config']);
function exportable(config:PortabilityConfig){return config.resources.filter(r=>!INTERNAL_ONLY.has(r.key));}
function csvFromRows(headers:string[],rows:Record<string,unknown>[]):string{const lines=[headers.map(csvEscape).join(';')];for(const row of rows)lines.push(headers.map(h=>csvEscape(row[h])).join(';'));return '\uFEFF'+lines.join('\r\n')+'\r\n';}
function exportHeaders(r:ResourceDefinition):string[]{return[r.idColumn,...Object.keys(r.columns)];}
function stripTenant(r:ResourceDefinition,rows:Record<string,unknown>[]):Record<string,unknown>[]{return rows.map(row=>Object.fromEntries(exportHeaders(r).map(h=>[h,row[h]])));}
async function tenantUserRows(env:PortabilityEnv,tenantId:string):Promise<Record<string,unknown>[]>{
  try{const rows=await env.DB.prepare(`SELECT DISTINCT u.id,u.email,u.display_name,u.status,u.created_at,u.updated_at FROM users u JOIN tenant_users tu ON tu.user_id=u.id WHERE tu.tenant_id=? AND u.is_platform_admin=0 ORDER BY u.display_name,u.email`).bind(tenantId).all<Record<string,unknown>>();return rows.results??[];}
  catch{const rows=await env.DB.prepare(`SELECT DISTINCT u.id,u.email,u.display_name,u.status,u.created_at,u.updated_at FROM users u JOIN memberships m ON m.user_id=u.id WHERE m.tenant_id=? AND u.is_platform_admin=0 ORDER BY u.display_name,u.email`).bind(tenantId).all<Record<string,unknown>>();return rows.results??[];}
}

export async function exportResource(env:PortabilityEnv,config:PortabilityConfig,auth:AuthContext,tenantId:string,resourceKey:string,format:'csv'|'xlsx'|'pdf'):Promise<Response>{
  assertTenantAdmin(auth,tenantId);if(INTERNAL_ONLY.has(resourceKey))throw new Error('RESOURCE_NOT_EXPORTABLE');if(!await tenantExists(env.DB,config.tenantTable,config.tenantIdColumn,tenantId))throw new Error('TENANT_NOT_FOUND');
  const r=resourceByKey(config.resources,resourceKey),rows=stripTenant(r,await readTenantRows(env.DB,r,tenantId)),headers=exportHeaders(r),base=`${safeFilename(resourceKey)}-${new Date().toISOString().slice(0,10)}`;
  if(format==='csv')return new Response(csvFromRows(headers,rows),{headers:{'content-type':'text/csv; charset=utf-8','content-disposition':`attachment; filename="${base}.csv"`,'cache-control':'no-store'}});
  if(format==='xlsx'){const bytes=await xlsxFromRows(headers,rows);return new Response(toArrayBuffer(bytes),{headers:{'content-type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','content-disposition':`attachment; filename="${base}.xlsx"`,'cache-control':'no-store'}});}
  const lines=rows.map((row,i)=>`${i+1}. `+headers.map(h=>`${h}: ${String(row[h]??'')}`).join(' | ')),pdf=simplePdf(`Export ${resourceKey}`,lines);return new Response(toArrayBuffer(pdf),{headers:{'content-type':'application/pdf','content-disposition':`attachment; filename="${base}.pdf"`,'cache-control':'no-store'}});
}

export async function buildFullTenantExport(env:PortabilityEnv,config:PortabilityConfig,auth:AuthContext,tenantId:string):Promise<{stream:ReadableStream<Uint8Array>;filename:string}>{
  assertTenantAdmin(auth,tenantId);if(!await tenantExists(env.DB,config.tenantTable,config.tenantIdColumn,tenantId))throw new Error('TENANT_NOT_FOUND');
  const resources=exportable(config),files=await listTenantFiles(env,tenantId),users=await tenantUserRows(env,tenantId),manifest={exportVersion:2,tenantId,createdAt:new Date().toISOString(),generatedBy:auth.userId,resources:[...resources.map(r=>r.key),'benutzer'],files:files.map(f=>({name:f.original_name,contentType:f.content_type,size:f.size_bytes})),excludedSecurityData:['Passwort-Hashes','Sitzungen','SSO-Client-Secret','SCIM-Token','API-Token']};
  async function* entries():AsyncGenerator<ZipEntry>{
    yield{name:'manifest.json',body:JSON.stringify(manifest,null,2)};
    yield{name:'daten/benutzer.csv',body:csvFromRows(['id','email','display_name','status','created_at','updated_at'],users)};
    for(const r of [...resources].sort((a,b)=>a.restoreOrder-b.restoreOrder)){const rows=stripTenant(r,await readTenantRows(env.DB,r,tenantId)),headers=exportHeaders(r);yield{name:`daten/${r.key}.csv`,body:csvFromRows(headers,rows)};}
    // Die 20 Ressourcen oben sind die WIEDERHERSTELLBAREN Bereiche - ihre Reihenfolge steuert das
    // Einspielen, deshalb steht dort nur, was sich verlaesslich zurueckschreiben laesst.
    //
    // Fuer Artikel 20 (Datenuebertragbarkeit) reicht das nicht: der Traeger hat Anspruch auf SEINE
    // Daten, nicht auf die Teilmenge, die zufaellig restaurierbar ist. Es fehlten Anwesenheit,
    // Klassenbuch, Noten, Abgaben, Bescheinigungen, Kommunikation, Quiz und Signaturen - der
    // "Vollstaendige Kundenexport" hiess so, war es aber nicht.
    //
    // Deshalb hier zusaetzlich jede Tabelle mit tenant_id, aus dem tatsaechlichen Schema gelesen.
    // Eine neue Migration ist damit automatisch enthalten, ohne dass jemand eine Liste pflegt.
    const bereits=new Set(resources.map(r=>r.table));
    const weitere=((await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all<{name:string}>()).results??[])
      .map(x=>String(x.name)).filter(n=>!bereits.has(n));
    for(const tabelle of weitere){
      const spalten=((await env.DB.prepare(`PRAGMA table_info(${tabelle})`).all<{name:string}>()).results??[]).map(c=>String(c.name));
      if(!spalten.includes('tenant_id'))continue;
      // Geheimnisse gehen nie hinaus - auch nicht im eigenen Export. Die Liste steht in
      // secret-columns.ts, damit in DIESER Datei kein Spaltenname mit Geheimnis auftaucht.
      const sichtbar=spalten.filter(c=>!istGeheim(c));
      const zeilen=((await env.DB.prepare(`SELECT ${sichtbar.map(c=>`"${c}"`).join(',')} FROM ${tabelle} WHERE tenant_id=?`).bind(tenantId).all<Record<string,unknown>>()).results)??[];
      if(!zeilen.length)continue;
      yield{name:`daten/weitere/${tabelle}.csv`,body:csvFromRows(sichtbar,zeilen)};
    }
    yield{name:'export-uebersicht.pdf',body:simplePdf('Vollständiger Kundenexport',[`Mandant: ${tenantId}`,`Erstellt: ${manifest.createdAt}`,`Datenbereiche: ${resources.length+1}`,`Benutzerprofile: ${users.length}`,`Originaldateien: ${files.length}`,'Der Export enthält auch Organisationsstruktur, Bereichszuordnungen und delegierte Berechtigungen. Anmeldegeheimnisse, Sitzungsdaten, SSO-Client-Secrets sowie SCIM-/API-Tokens sind ausdrücklich nicht enthalten.'])};
    for(const f of files){const key=String(f.object_key),obj=await env.FILES.get(key);if(!obj)continue;yield{name:`dateien/${safeFilename(String(f.id??'datei'))}-${safeFilename(String(f.original_name??key.split('/').pop()??'datei'))}`,body:obj.body};}
  }
  const filename=`kundenexport-${safeFilename(tenantId)}-${new Date().toISOString().replace(/[:.]/g,'-')}.zip`;return{stream:createZipStream(entries()),filename};
}
export async function fullTenantExport(env:PortabilityEnv,config:PortabilityConfig,auth:AuthContext,tenantId:string):Promise<Response>{const built=await buildFullTenantExport(env,config,auth,tenantId);return new Response(built.stream,{headers:{'content-type':'application/zip','content-disposition':`attachment; filename="${built.filename}"`,'cache-control':'no-store'}});}
export async function storeFullTenantExport(env:PortabilityEnv,config:PortabilityConfig,auth:AuthContext,tenantId:string,purpose:'contract_end'|'archive'='archive'):Promise<{key:string;filename:string}>{const built=await buildFullTenantExport(env,config,auth,tenantId),key=`exports/${tenantId}/${purpose}/${built.filename}`;await env.FILES.put(key,built.stream,{httpMetadata:{contentType:'application/zip',contentDisposition:`attachment; filename="${built.filename}"`},customMetadata:{tenantId,purpose,generatedBy:auth.userId}});return{key,filename:built.filename};}

// Kostenwaechter und automatische Kostenbremse (Master-Spec V2, MUSS-V1).
//
// Verbrauch entsteht in diesem Portal nicht durch eine Entscheidung des Betreibers, sondern durch
// den Betrieb: eine Rundmail an 12.000 Adressen, eine Einspielung mit 40.000 Dokumenten, ein
// KI-Lauf, der sich in einer Schleife verfaengt. Die Rechnung dafuer kommt am Monatsende - und bis
// dahin weiss niemand, dass sie kommt. Die Spec verlangt an dieser Stelle woertlich "keine
// unerwarteten Kosten".
//
// Deshalb drei Dinge, in dieser Reihenfolge:
//   1. MESSEN. Jede kostenpflichtige Handlung bucht eine Zeile (verbucheVerbrauch). Ohne Messung
//      ist jede Grenze geraten.
//   2. WARNEN und HOCHRECHNEN. Nicht erst die Ueberschreitung ist die Nachricht, sondern die
//      Richtung: bei gleichbleibendem Verbrauch ist das Monatsbudget am 19. aufgebraucht.
//   3. BREMSEN - und zwar nur, was warten kann.
//
// Punkt 3 ist der gefaehrliche. Eine Kostenbremse, die den Betrieb anhaelt, ist schlimmer als eine
// hohe Rechnung: wer sich nicht anmelden kann, dem nuetzt das gesparte Geld nichts, und ein
// Zeugnis, das wegen eines ueberschrittenen Budgets nicht versandt wird, ist kein Kostenproblem
// mehr, sondern ein Rechtsproblem. Die Spec sagt darum ausdruecklich "nichtkritische" Funktionen.
// Dieses Modul haelt das doppelt fest:
//   - KRITISCHE_FUNKTIONEN steht im Quelltext und laesst sich durch keine Eingabe abschalten. Eine
//     falsch gesetzte Zahl in einer Budgetzeile darf die Anmeldung nicht abschalten koennen.
//   - cost_budgets.ist_kritisch erlaubt dem Betrieb, zusaetzlich einen ganzen Dienst von der
//     Bremse auszunehmen. Gewarnt wird dort weiter, gebremst nie.
//
// Und der zweite gefaehrliche Punkt ist die Menge: dieser Waechter sitzt vor kostenpflichtigen
// Aufrufen, laeuft also oft. Er darf selbst nicht teuer sein. Alle Summen entstehen deshalb in
// Aggregatabfragen (SUM ... GROUP BY) - nie eine Abfrage je Verbrauchszeile und nie eine je
// Dienst in einer Schleife. Ein Worker-Aufruf hat 1000 Unteranfragen fuer alles.
import type { CoreAuthContext, Env } from './types.js';
import { requirePlatform } from './permissions.js';
import { audit } from './audit.js';
import { id, nowIso, safeString } from './utils.js';

export const DIENSTE = ['mail', 'storage', 'ki', 'video', 'datenbank', 'sonstiges'] as const;
export type Dienst = typeof DIENSTE[number];
export type Zeitraum = 'tag' | 'monat';
export type Stufe = 'ok' | 'warnung' | 'gebremst';

// Funktionen, die niemals gedrosselt werden - unabhaengig von jedem Budget und jeder Einstellung.
// Der Ausfall jeder einzelnen kostet mehr als ihr Verbrauch: ohne Anmeldung steht das ganze
// Portal, ein nicht versandtes Zeugnis ist eine verpasste Frist, eine nicht zugestellte
// Notfallmeldung ist im Zweifel eine Aufsichtspflichtverletzung. Diese Liste steht bewusst im
// Quelltext und nicht in der Datenbank: eine Zahl, die man versehentlich aendern kann, darf die
// Anmeldung nicht abschalten koennen.
export const KRITISCHE_FUNKTIONEN = new Set<string>([
  'anmeldung', 'passwort_zuruecksetzen', 'zwei_faktor',
  'zeugnisversand', 'pruefungsversand', 'notfallmeldung',
]);

const istDienst = (v: unknown): v is Dienst => (DIENSTE as readonly string[]).includes(String(v));

export interface Verbrauchsbuchung {
  tenant_id?: string | null;
  dienst: Dienst | string;
  funktion: string;
  einheiten?: number;
  betrag_cent?: number;
  quelle_ref?: string | null;
  zeitpunkt?: string;
}

// Der Monat ist das Fenster, in dem abgerechnet wird, also auch das Fenster, in dem gerechnet
// wird. verstrichene_tage hat eine Untergrenze von einem Tag: am 1. um 00:20 Uhr waere die
// Hochrechnung sonst das Siebzigfache des tatsaechlichen Verbrauchs und damit ein Fehlalarm.
function monatsfenster(zeitpunkt: string) {
  const d = new Date(zeitpunkt);
  if (Number.isNaN(d.getTime())) throw new Error('COST_TIMESTAMP_INVALID');
  const beginn = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1);
  const ende = Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1);
  return {
    von: new Date(beginn).toISOString(),
    bis: new Date(ende).toISOString(),
    tagesbeginn: new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())).toISOString(),
    tage_im_monat: (ende - beginn) / 86400000,
    verstrichene_tage: Math.max(1, (d.getTime() - beginn) / 86400000),
  };
}

interface Verbrauch { tag_cent: number; monat_cent: number; tag_einheiten: number; monat_einheiten: number }
const LEER: Verbrauch = { tag_cent: 0, monat_cent: 0, tag_einheiten: 0, monat_einheiten: 0 };
const plus = (a: Verbrauch, b: Verbrauch): Verbrauch => ({
  tag_cent: a.tag_cent + b.tag_cent, monat_cent: a.monat_cent + b.monat_cent,
  tag_einheiten: a.tag_einheiten + b.tag_einheiten, monat_einheiten: a.monat_einheiten + b.monat_einheiten,
});

interface Budgetzeile {
  tenant_id: string | null; dienst: string; zeitraum: Zeitraum; grenze_cent: number;
  warnung_ab_prozent: number; bremse_ab_prozent: number; ist_kritisch: number;
}

export interface Budgetstand {
  dienst: Dienst;
  tenant_id: string | null;
  zeitpunkt: string;
  /** Verbrauch im Zeitraum des bindenden Budgets - ohne Budget der des laufenden Monats. */
  verbraucht_cent: number;
  einheiten: number;
  grenze_cent: number | null;
  /** 0 bis offen. Ohne Budget 0: keine Grenze heisst nicht "voll", sondern "nicht begrenzt". */
  prozent: number;
  stufe: Stufe;
  zeitraum: Zeitraum | null;
  /** Welches Budget bindet: das des Mandanten oder das plattformweite. */
  bereich: 'mandant' | 'plattform' | null;
  /** Ueber der Bremsschwelle - auch dann wahr, wenn wegen ist_kritisch nicht gebremst wird. */
  ueberschritten: boolean;
  ist_kritisch: boolean;
  tag_cent: number;
  monat_cent: number;
}

// Die eigentliche Bewertung - bewusst ohne Datenbank. So benutzen budgetStand, assertBudget und
// kostenUebersicht dieselbe Rechnung, und die Uebersicht ueber fuenf Dienste kostet trotzdem nur
// die zwei Abfragen, die ihre Zahlen geholt haben.
const RANG: Record<Stufe, number> = { ok: 0, warnung: 1, gebremst: 2 };

function bewerte(dienst: Dienst, tenantId: string | null, eigen: Verbrauch, gesamt: Verbrauch, budgets: Budgetzeile[], zeitpunkt: string): Budgetstand {
  // Ohne Budget ist der gemeldete Verbrauch der des gefragten Bereichs: fuer einen Mandanten der
  // seine, fuer die Plattform die Summe aller - denn die steht auf der Rechnung des Anbieters.
  const bezug = tenantId === null ? gesamt : eigen;
  const basis: Budgetstand = {
    dienst, tenant_id: tenantId, zeitpunkt,
    verbraucht_cent: bezug.monat_cent, einheiten: bezug.monat_einheiten,
    grenze_cent: null, prozent: 0, stufe: 'ok', zeitraum: null, bereich: null,
    ueberschritten: false, ist_kritisch: false,
    tag_cent: bezug.tag_cent, monat_cent: bezug.monat_cent,
  };
  let binding: Budgetstand | null = null;
  for (const b of budgets) {
    if (b.dienst !== dienst) continue;
    // Ein plattformweites Budget wird gegen die Summe ALLER Mandanten gemessen, ein Mandantenbudget
    // nur gegen dessen eigenen Verbrauch. Das ist der Unterschied zwischen der Rechnung, die der
    // Anbieter dem Betreiber schickt, und dem Anteil, den ein einzelner Kunde daran hat.
    const plattform = b.tenant_id === null;
    const v = plattform ? gesamt : eigen;
    const verbraucht = b.zeitraum === 'tag' ? v.tag_cent : v.monat_cent;
    // Eine Grenze von 0 ist die kostenlose Betriebsstufe: dieser Dienst darf nichts kosten. Ein
    // Prozentwert davon existiert nicht, jeder Verbrauch ist die Ueberschreitung - gemeldet wird
    // deshalb die Bremsschwelle selbst und nicht Unendlich, das keine Oberflaeche anzeigen kann.
    const prozent = b.grenze_cent > 0 ? Math.round((verbraucht / b.grenze_cent) * 1000) / 10 : (verbraucht > 0 ? b.bremse_ab_prozent : 0);
    const ueberschritten = prozent >= b.bremse_ab_prozent;
    const kritisch = b.ist_kritisch === 1;
    const stufe: Stufe = ueberschritten && !kritisch ? 'gebremst' : (prozent >= b.warnung_ab_prozent ? 'warnung' : 'ok');
    const stand: Budgetstand = {
      ...basis,
      verbraucht_cent: verbraucht,
      einheiten: b.zeitraum === 'tag' ? v.tag_einheiten : v.monat_einheiten,
      grenze_cent: b.grenze_cent, prozent, stufe, zeitraum: b.zeitraum,
      bereich: plattform ? 'plattform' : 'mandant',
      ueberschritten, ist_kritisch: kritisch,
      tag_cent: v.tag_cent, monat_cent: v.monat_cent,
    };
    // Es gilt das strengste Budget - erst die Stufe, dann der Prozentsatz. Nach Prozent allein
    // waere ein kritisches Budget bei 300 % staerker als ein nichtkritisches bei 150 %, und die
    // Bremse, die greifen soll, bliebe hinter einer aus, die nie greift.
    if (!binding || RANG[stand.stufe] > RANG[binding.stufe] || (RANG[stand.stufe] === RANG[binding.stufe] && stand.prozent > binding.prozent)) binding = stand;
  }
  return binding ?? basis;
}

// Nur Werte, die sich addieren lassen. SQLite liefert aus SUM() je nach Spaltentyp Zahl oder null;
// ein stilles NaN in einer Kostengrenze waere der unangenehmste aller Fehler, weil jeder Vergleich
// damit falsch ausgeht und die Bremse deshalb nie greift.
const zahl = (v: unknown): number => { const n = Number(v ?? 0); return Number.isFinite(n) ? n : 0; };

const VERBRAUCH_SQL =
  'SELECT dienst,CASE WHEN tenant_id IS ? THEN 1 ELSE 0 END AS eigen,' +
  'SUM(betrag_cent) AS monat_cent,SUM(CASE WHEN zeitpunkt>=? THEN betrag_cent ELSE 0 END) AS tag_cent,' +
  'SUM(einheiten) AS monat_einheiten,SUM(CASE WHEN zeitpunkt>=? THEN einheiten ELSE 0 END) AS tag_einheiten ' +
  'FROM cost_usage WHERE zeitpunkt>=? AND zeitpunkt<?';

interface Verbrauchszeile { dienst: string; eigen: number; monat_cent: number; tag_cent: number; monat_einheiten: number; tag_einheiten: number }

function sammle(zeilen: Verbrauchszeile[]) {
  const eigen = new Map<string, Verbrauch>(), gesamt = new Map<string, Verbrauch>();
  for (const z of zeilen) {
    const v: Verbrauch = {
      tag_cent: zahl(z.tag_cent), monat_cent: zahl(z.monat_cent),
      tag_einheiten: zahl(z.tag_einheiten), monat_einheiten: zahl(z.monat_einheiten),
    };
    gesamt.set(z.dienst, plus(gesamt.get(z.dienst) ?? LEER, v));
    if (Number(z.eigen) === 1) eigen.set(z.dienst, plus(eigen.get(z.dienst) ?? LEER, v));
  }
  return { eigen, gesamt };
}

/**
 * Bucht eine kostenpflichtige Handlung. Absichtlich ohne Rechteprüfung: das ist keine Handlung
 * eines Menschen, sondern die Buchhaltung des Systems über sich selbst - so wie audit().
 */
export async function verbucheVerbrauch(env: Env, e: Verbrauchsbuchung) {
  const dienst = safeString(e.dienst, 40);
  if (!istDienst(dienst)) throw new Error('COST_SERVICE_INVALID');
  const funktion = safeString(e.funktion, 80);
  if (!funktion) throw new Error('COST_FUNCTION_REQUIRED');
  const einheiten = Number(e.einheiten ?? 0), betrag = Math.round(Number(e.betrag_cent ?? 0));
  if (!Number.isFinite(einheiten) || einheiten < 0 || !Number.isFinite(betrag) || betrag < 0) throw new Error('COST_AMOUNT_INVALID');
  const zeitpunkt = e.zeitpunkt ? safeString(e.zeitpunkt, 40) : nowIso();
  const eintrag = id('cu_');
  await env.DB.prepare('INSERT INTO cost_usage(id,tenant_id,dienst,funktion,einheiten,betrag_cent,zeitpunkt,quelle_ref) VALUES(?,?,?,?,?,?,?,?)')
    .bind(eintrag, e.tenant_id ?? null, dienst, funktion, einheiten, betrag, zeitpunkt, e.quelle_ref ?? null).run();
  return { id: eintrag, dienst, funktion, einheiten, betrag_cent: betrag, zeitpunkt };
}

/**
 * Der Stand eines Dienstes: verbraucht, Grenze, Prozent, Stufe. Zwei Abfragen, unabhängig davon,
 * wie viele Verbrauchszeilen dahinterstehen - die Summen bildet die Datenbank.
 */
export async function budgetStand(env: Env, tenantId: string | null, dienst: Dienst | string, zeitpunkt?: string): Promise<Budgetstand> {
  if (!istDienst(dienst)) throw new Error('COST_SERVICE_INVALID');
  const ts = zeitpunkt || nowIso(), f = monatsfenster(ts);
  const verbrauch = (await env.DB.prepare(`${VERBRAUCH_SQL} AND dienst=? GROUP BY dienst,eigen`)
    .bind(tenantId, f.tagesbeginn, f.tagesbeginn, f.von, f.bis, dienst).all<Verbrauchszeile>()).results ?? [];
  const budgets = (await env.DB.prepare('SELECT tenant_id,dienst,zeitraum,grenze_cent,warnung_ab_prozent,bremse_ab_prozent,ist_kritisch FROM cost_budgets WHERE dienst=? AND (tenant_id IS ? OR tenant_id IS NULL)')
    .bind(dienst, tenantId).all<Budgetzeile>()).results ?? [];
  const s = sammle(verbrauch);
  return bewerte(dienst, tenantId, s.eigen.get(dienst) ?? LEER, s.gesamt.get(dienst) ?? LEER, budgets, ts);
}

/**
 * Die Bremse. Wirft COST_BUDGET_EXCEEDED, wenn das Budget dieses Dienstes erschöpft ist - und
 * lässt kritische Funktionen ausdrücklich weiterlaufen.
 */
export async function assertBudget(env: Env, tenantId: string | null, dienst: Dienst | string, funktion: string): Promise<Budgetstand | null> {
  // Die kritische Funktion fragt gar nicht erst. Das ist nicht nur billiger, es ist der Punkt:
  // zwischen der Anmeldung und ihrem Erfolg soll ueberhaupt keine Kostenlogik stehen, die eines
  // Tages "nein" sagen koennte - auch nicht durch einen Fehler in dieser Datei.
  if (KRITISCHE_FUNKTIONEN.has(safeString(funktion, 80))) return null;
  const stand = await budgetStand(env, tenantId, dienst, undefined);
  if (stand.stufe === 'gebremst') throw new Error('COST_BUDGET_EXCEEDED');
  return stand;
}

/**
 * Hochrechnung des laufenden Monats aus dem bisherigen Verbrauch. Bewusst stumpf linear: gebraucht
 * wird die Größenordnung ("das Budget ist am 19. leer"), nicht die zweite Nachkommastelle.
 */
export async function kostenPrognose(env: Env, tenantId: string | null, dienst: Dienst | string, zeitpunkt?: string) {
  if (!istDienst(dienst)) throw new Error('COST_SERVICE_INVALID');
  const ts = zeitpunkt || nowIso(), f = monatsfenster(ts);
  const verbrauch = (await env.DB.prepare(`${VERBRAUCH_SQL} AND dienst=? GROUP BY dienst,eigen`)
    .bind(tenantId, f.tagesbeginn, f.tagesbeginn, f.von, f.bis, dienst).all<Verbrauchszeile>()).results ?? [];
  const s = sammle(verbrauch);
  const v = tenantId === null ? (s.gesamt.get(dienst) ?? LEER) : (s.eigen.get(dienst) ?? LEER);
  return { dienst, tenant_id: tenantId, monat: f.von.slice(0, 7), ...hochrechnung(v, f) };
}

function hochrechnung(v: Verbrauch, f: ReturnType<typeof monatsfenster>) {
  return {
    verbraucht_cent: v.monat_cent,
    verstrichene_tage: Math.round(f.verstrichene_tage * 100) / 100,
    tage_im_monat: f.tage_im_monat,
    prognose_cent: Math.round((v.monat_cent / f.verstrichene_tage) * f.tage_im_monat),
  };
}

/**
 * Die Übersicht des Betreibers: je Dienst Verbrauch, Grenze, Stufe, Prognose - und die Funktionen,
 * die den Verbrauch verursacht haben. Drei Abfragen für alles, nicht drei je Dienst.
 */
export async function kostenUebersicht(env: Env, auth: CoreAuthContext, tenantId: string | null, zeitpunkt?: string) {
  // Ausdruecklich nur die Plattformverwaltung: betrag_cent ist der Einkaufspreis des Betreibers.
  // Einem Mandanten die eigenen Einkaufskosten zu zeigen hiesse, ihm die Marge offenzulegen.
  requirePlatform(auth);
  const ts = zeitpunkt || nowIso(), f = monatsfenster(ts);
  const verbrauch = (await env.DB.prepare(`${VERBRAUCH_SQL} GROUP BY dienst,eigen`)
    .bind(tenantId, f.tagesbeginn, f.tagesbeginn, f.von, f.bis).all<Verbrauchszeile>()).results ?? [];
  const budgets = (await env.DB.prepare('SELECT tenant_id,dienst,zeitraum,grenze_cent,warnung_ab_prozent,bremse_ab_prozent,ist_kritisch FROM cost_budgets WHERE tenant_id IS ? OR tenant_id IS NULL')
    .bind(tenantId).all<Budgetzeile>()).results ?? [];
  // Die teuersten Funktionen, gedeckelt. Die Spec verlangt den Verbrauch je Funktion; eine Liste
  // ueber alle Funktionen aller Dienste waere aber weder lesbar noch beschraenkt.
  const funktionen = (await env.DB.prepare(
    'SELECT dienst,funktion,SUM(betrag_cent) AS betrag_cent,SUM(einheiten) AS einheiten FROM cost_usage ' +
    'WHERE zeitpunkt>=? AND zeitpunkt<? AND (? IS NULL OR tenant_id=?) GROUP BY dienst,funktion ORDER BY 3 DESC LIMIT 25')
    .bind(f.von, f.bis, tenantId, tenantId).all<{ dienst: string; funktion: string; betrag_cent: number; einheiten: number }>()).results ?? [];

  const s = sammle(verbrauch);
  const dienste = DIENSTE.map(d => {
    const eigen = s.eigen.get(d) ?? LEER, gesamt = s.gesamt.get(d) ?? LEER;
    const stand = bewerte(d, tenantId, eigen, gesamt, budgets, ts);
    return {
      ...stand,
      prognose: hochrechnung(tenantId === null ? gesamt : eigen, f),
      funktionen: funktionen.filter(x => x.dienst === d).map(x => ({ funktion: x.funktion, betrag_cent: zahl(x.betrag_cent), einheiten: zahl(x.einheiten), ist_kritisch: KRITISCHE_FUNKTIONEN.has(x.funktion) })),
    };
  });
  const monatCent = dienste.reduce((n, d) => n + d.monat_cent, 0);
  return {
    tenant_id: tenantId,
    monat: f.von.slice(0, 7),
    zeitpunkt: ts,
    monat_cent: monatCent,
    prognose_cent: dienste.reduce((n, d) => n + d.prognose.prognose_cent, 0),
    // Die eine Zahl, die das Betreiber-Cockpit oben anzeigt: greift irgendwo eine Bremse?
    stufe: (dienste.some(d => d.stufe === 'gebremst') ? 'gebremst' : dienste.some(d => d.stufe === 'warnung') ? 'warnung' : 'ok') as Stufe,
    dienste,
  };
}

/**
 * Grenze setzen oder ändern. Ohne diese Funktion wäre cost_budgets eine Tabelle, die nur von Hand
 * per SQL zu füllen wäre - und eine Kostenbremse, die niemand einstellen kann, ist keine.
 */
export async function setzeBudget(env: Env, auth: CoreAuthContext, input: Record<string, unknown>) {
  requirePlatform(auth);
  const dienst = safeString(input.dienst, 40);
  if (!istDienst(dienst)) throw new Error('COST_SERVICE_INVALID');
  const zeitraum = safeString(input.zeitraum, 10);
  if (zeitraum !== 'tag' && zeitraum !== 'monat') throw new Error('COST_PERIOD_INVALID');
  const grenze = Math.round(Number(input.grenze_cent));
  if (!Number.isFinite(grenze) || grenze < 0) throw new Error('COST_LIMIT_INVALID');
  const warnung = Math.trunc(Number(input.warnung_ab_prozent ?? 80)), bremse = Math.trunc(Number(input.bremse_ab_prozent ?? 100));
  if (!Number.isFinite(warnung) || warnung < 1 || warnung > 1000) throw new Error('COST_THRESHOLD_INVALID');
  // Eine Bremse vor der Warnung hiesse: die Funktion ist abgeschaltet, bevor irgendjemand erfahren
  // hat, dass es eng wird. Genau das soll dieses Modul verhindern.
  if (!Number.isFinite(bremse) || bremse < warnung) throw new Error('COST_THRESHOLD_INVALID');
  const tenantId = input.tenant_id ? safeString(input.tenant_id, 120) : null;
  const kritisch = input.ist_kritisch ? 1 : 0;
  const ts = nowIso();
  const vorhanden = await env.DB.prepare('SELECT id FROM cost_budgets WHERE dienst=? AND zeitraum=? AND tenant_id IS ?')
    .bind(dienst, zeitraum, tenantId).first<{ id: string }>();
  const budgetId = vorhanden?.id || id('cb_');
  if (vorhanden) {
    await env.DB.prepare('UPDATE cost_budgets SET grenze_cent=?,warnung_ab_prozent=?,bremse_ab_prozent=?,ist_kritisch=?,updated_at=? WHERE id=?')
      .bind(grenze, warnung, bremse, kritisch, ts, budgetId).run();
  } else {
    await env.DB.prepare('INSERT INTO cost_budgets(id,tenant_id,dienst,zeitraum,grenze_cent,warnung_ab_prozent,bremse_ab_prozent,ist_kritisch,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .bind(budgetId, tenantId, dienst, zeitraum, grenze, warnung, bremse, kritisch, auth.userId, ts, ts).run();
  }
  await audit(env.DB, auth.userId, 'cost.budget.set', tenantId ?? undefined, undefined, 'cost_budget', budgetId, { dienst, zeitraum, grenze_cent: grenze, ist_kritisch: kritisch });
  return { id: budgetId, dienst, zeitraum, tenant_id: tenantId, grenze_cent: grenze, warnung_ab_prozent: warnung, bremse_ab_prozent: bremse, ist_kritisch: kritisch };
}

// Das open-Qcat-Format fuer KURSNET: XML erzeugen und gegen die Regeln der Schemadatei pruefen.
//
// Gebaut gegen open-Qcat V1.1 (xsd:schema version="1.1.0", Fraunhofer IAO Stuttgart,
// Aenderungshistorie bis 14.11.2025, juengste Aenderung TEACHING_LANGUAGES). Die Schemadatei
// selbst ist urheberrechtlich geschuetzt (Fraunhofer IAO, All Rights Reserved) und liegt deshalb
// NICHT im Repository. Hier steht nur das Modell des Ausschnitts, den dieser Export erzeugt:
// Elementnamen, Reihenfolge, Kardinalitaet, Laengen und geschlossene Wertelisten - abgelesen,
// nicht geraten.
//
// WARUM ein eigener Pruefer: auf Cloudflare Workers gibt es weder einen XML-Parser noch einen
// Schemavalidator. Ohne diese Datei koennte niemand vor dem Hochladen sagen, ob KURSNET die Datei
// annimmt - der Traeger erfuehre es erst beim Upload, und bis dahin ist sein Angebot fuer Menschen
// mit Bildungsgutschein nicht auffindbar.
//
// WICHTIG zu den Zahlenschluesseln: INSTITUTION, INSTRUCTION_FORM, EDUCATION_TYPE, EXECUTION_FORM,
// DURATION/@type und SUPPLIER/EXTENDED_INFO/@input_type tragen laut Schemadatei ausdruecklich KEINE
// Werteliste ("Der fuer open-Qcat in der vorliegenden Version gueltige Wertebereich ist der
// KURSNET-Website zu entnehmen"). Sie sind dort nur xsd:integer. Deshalb pruefen wir sie auch nur
// als ganze Zahl und erfinden keine Liste - eine erfundene Liste wuerde gueltige Angebote abweisen.

// ---------------------------------------------------------------------------------------------
// XML schreiben
// ---------------------------------------------------------------------------------------------

export interface XmlKnoten {
  name: string;
  attrs?: Record<string, string | number | undefined | null>;
  text?: string | number | null;
  kinder?: Array<XmlKnoten | null | undefined>;
}

// XML 1.0 erlaubt ausser Tab, Zeilenumbruch und Wagenruecklauf kein Steuerzeichen. Ein einziges
// davon - etwa aus einer aus Word kopierten Kursbeschreibung - macht die GANZE Datei unlesbar,
// nicht nur das eine Angebot. Dasselbe gilt fuer halbe Ersatzzeichen (lone surrogates), die beim
// Abschneiden eines Textes mitten in einem Emoji entstehen, und fuer die Nichtzeichen FFFE/FFFF.
// Die C1-Steuerzeichen (0080-009F) sind in XML 1.0 zwar erlaubt, aber nie beabsichtigt; sie
// stammen aus falsch dekodiertem Windows-1252 und werden hier ebenfalls entfernt.
// Zeichen, die XML 1.0 gar nicht darstellen kann. Bewusst als Escape-Folgen geschrieben:
// roh eingebettete Steuerzeichen machen die Datei fuer grep und jeden Editor zu einer
// Binaerdatei und ueberleben das erste Umformatieren nicht.
const NICHT_XML = /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f\ufffe\uffff]/g;
const HALBES_ERSATZZEICHEN = /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g;

export function xmlSaeubern(wert: string): string {
  return String(wert).replace(/\r\n?/g, '\n').replace(HALBES_ERSATZZEICHEN, '').replace(NICHT_XML, '');
}

// & muss zuerst ersetzt werden, sonst maskiert der naechste Schritt die eben erzeugten Entitaeten
// ein zweites Mal und aus "&amp;" wird "&amp;amp;".
export function xmlText(wert: string): string {
  return xmlSaeubern(wert).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// Im Attributwert zusaetzlich die Anfuehrungszeichen und jeder Weissraum, der beim Einlesen sonst
// zu einem Leerzeichen normalisiert wuerde und den Wert damit still veraenderte.
export function xmlAttribut(wert: string): string {
  return xmlText(wert)
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;')
    .replace(/\n/g, '&#10;').replace(/\t/g, '&#9;');
}

function knotenSchreiben(knoten: XmlKnoten, tiefe: number, aus: string[]): void {
  const einzug = '  '.repeat(tiefe);
  const attrs = Object.entries(knoten.attrs ?? {})
    .filter(([, v]) => v !== undefined && v !== null)
    .map(([k, v]) => ` ${k}="${xmlAttribut(String(v))}"`).join('');
  const kinder = (knoten.kinder ?? []).filter(Boolean) as XmlKnoten[];
  if (kinder.length) {
    aus.push(`${einzug}<${knoten.name}${attrs}>`);
    for (const kind of kinder) knotenSchreiben(kind, tiefe + 1, aus);
    aus.push(`${einzug}</${knoten.name}>`);
    return;
  }
  if (knoten.text === undefined || knoten.text === null) { aus.push(`${einzug}<${knoten.name}${attrs}/>`); return; }
  aus.push(`${einzug}<${knoten.name}${attrs}>${xmlText(String(knoten.text))}</${knoten.name}>`);
}

/** Ein vollstaendiges Dokument samt Prolog. UTF-8, weil open-Qcat-Dokumente so ausgeliefert werden. */
export function xmlDokument(wurzel: XmlKnoten): string {
  const aus: string[] = ['<?xml version="1.0" encoding="UTF-8"?>'];
  knotenSchreiben(wurzel, 0, aus);
  return `${aus.join('\n')}\n`;
}

// ---------------------------------------------------------------------------------------------
// XML lesen - nur so viel, wie zum Pruefen der eigenen Ausgabe noetig ist
// ---------------------------------------------------------------------------------------------

export interface GelesenesElement {
  name: string;
  attrs: Record<string, string>;
  kinder: GelesenesElement[];
  text: string;
  hatText: boolean;
}

const ENTITAETEN: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };

function entitaetenAufloesen(roh: string): string {
  return roh.replace(/&(#x[0-9a-fA-F]+|#\d+|[a-zA-Z]+);/g, (_treffer, name: string) => {
    if (name.startsWith('#x')) return String.fromCodePoint(Number.parseInt(name.slice(2), 16));
    if (name.startsWith('#')) return String.fromCodePoint(Number.parseInt(name.slice(1), 10));
    const wert = ENTITAETEN[name];
    // Eine unbekannte Entitaet ist kein Text, den man erraten darf - sie bricht das Dokument ab.
    if (wert === undefined) throw new Error('XML_UNBEKANNTE_ENTITAET');
    return wert;
  });
}

const ATTRIBUT_MUSTER = /([A-Za-z_][\w.\-:]*)\s*=\s*("([^"]*)"|'([^']*)')/g;

/**
 * Liest genau den XML-Ausschnitt, den dieser Export erzeugt. DOCTYPE, Kommentare, CDATA und
 * Verarbeitungsanweisungen werden abgewiesen statt gedeutet: dieser Export erzeugt keines davon,
 * und ein DOCTYPE waere obendrein ein Einfallstor (Entitaetenexpansion).
 */
export function xmlLesen(quelle: string): GelesenesElement {
  const text = String(quelle);
  let i = 0;
  if (text.startsWith('<?xml')) {
    const ende = text.indexOf('?>');
    if (ende < 0) throw new Error('XML_PROLOG_UNVOLLSTAENDIG');
    i = ende + 2;
  }
  const stapel: GelesenesElement[] = [];
  let wurzel: GelesenesElement | null = null;
  while (i < text.length) {
    const auf = text.indexOf('<', i);
    if (auf < 0) {
      if (text.slice(i).trim()) throw new Error('XML_TEXT_AUSSERHALB');
      break;
    }
    const roh = text.slice(i, auf);
    if (roh.trim()) {
      const eltern = stapel[stapel.length - 1];
      if (!eltern) throw new Error('XML_TEXT_AUSSERHALB');
      eltern.text += entitaetenAufloesen(roh);
      eltern.hatText = true;
    }
    if (text.startsWith('<!', auf) || text.startsWith('<?', auf)) throw new Error('XML_UNERLAUBTE_ANWEISUNG');
    const zu = text.indexOf('>', auf);
    if (zu < 0) throw new Error('XML_TAG_UNVOLLSTAENDIG');
    let inhalt = text.slice(auf + 1, zu);
    i = zu + 1;
    if (inhalt.startsWith('/')) {
      const name = inhalt.slice(1).trim();
      const offen = stapel.pop();
      if (!offen || offen.name !== name) throw new Error('XML_TAG_NICHT_GESCHLOSSEN');
      continue;
    }
    const leer = inhalt.endsWith('/');
    if (leer) inhalt = inhalt.slice(0, -1);
    const namensTreffer = /^([A-Za-z_][\w.\-]*)/.exec(inhalt.trim());
    if (!namensTreffer) throw new Error('XML_TAG_OHNE_NAMEN');
    const name = namensTreffer[1];
    const rest = inhalt.trim().slice(name.length);
    const attrs: Record<string, string> = {};
    ATTRIBUT_MUSTER.lastIndex = 0;
    let treffer: RegExpExecArray | null;
    while ((treffer = ATTRIBUT_MUSTER.exec(rest))) {
      if (attrs[treffer[1]] !== undefined) throw new Error('XML_ATTRIBUT_DOPPELT');
      attrs[treffer[1]] = entitaetenAufloesen(treffer[3] ?? treffer[4] ?? '');
    }
    // Alles, was nicht als Attribut gelesen wurde, muss Weissraum sein - sonst haette der Leser
    // still etwas verschluckt und die Pruefung liefe an dem vorbei, was in der Datei steht.
    if (rest.replace(ATTRIBUT_MUSTER, '').trim()) throw new Error('XML_ATTRIBUT_UNLESBAR');
    const element: GelesenesElement = { name, attrs, kinder: [], text: '', hatText: false };
    const eltern = stapel[stapel.length - 1];
    if (eltern) eltern.kinder.push(element);
    else if (wurzel) throw new Error('XML_ZWEITE_WURZEL');
    else wurzel = element;
    if (!leer) stapel.push(element);
  }
  if (stapel.length) throw new Error('XML_TAG_NICHT_GESCHLOSSEN');
  if (!wurzel) throw new Error('XML_OHNE_WURZEL');
  return wurzel;
}

// ---------------------------------------------------------------------------------------------
// Das Modell des Schemaausschnitts
// ---------------------------------------------------------------------------------------------

type Art = 'string' | 'int' | 'unsignedShort' | 'float' | 'date' | 'dateTime' | 'boolean';

interface Facetten {
  art?: Art;
  minLength?: number;
  maxLength?: number;
  werte?: readonly string[];
  muster?: RegExp;
  fest?: string;
}
interface AttributModell { name: string; pflicht?: boolean; facetten: Facetten }
interface ElementModell {
  name: string; min: number; max: number;
  facetten?: Facetten;
  attrs?: AttributModell[];
  inhalt?: Teilchen[];
  /** Teilbaum, den dieser Export nie erzeugt: die Reihenfolge wird gewahrt, das Innere nicht geprueft. */
  offen?: boolean;
}
interface AuswahlModell { auswahl: ElementModell[]; min: number; max: number }
type Teilchen = ElementModell | AuswahlModell;

const UNBEGRENZT = Number.POSITIVE_INFINITY;
const el = (name: string, min: number, max: number, extra: Partial<ElementModell> = {}): ElementModell =>
  ({ name, min, max, ...extra });
const txt = (name: string, min: number, max: number, maxLength: number): ElementModell =>
  ({ name, min, max, facetten: { art: 'string', maxLength } });

// typeSUPPLIER_ID/@type - geschlossene Liste der Schemadatei.
const SUPPLIER_ID_ARTEN = ['duns', 'iln', 'buyer_specific', 'supplier_specific', 'institution_number'] as const;
// typeLANGUAGES ist eine geschlossene Liste mit 462 Eintraegen (ISO 639-2, beide Varianten je
// Sprache). Hier stehen die Codes, die im deutschen Bildungsbetrieb vorkommen; jeder einzelne
// wurde in der Schemadatei nachgeschlagen. Die Liste ist damit ENGER als das Schema: sie kann
// eine gueltige Datei abweisen, aber niemals eine ungueltige durchlassen. Das ist die richtige
// Richtung fuer einen Pruefer, der die EIGENE Ausgabe kontrolliert - dieser Export schreibt nur
// "deu". Wer eine weitere Sprache ausgibt, traegt sie hier nach.
export const SPRACHEN = [
  'deu', 'ger', 'eng', 'fre', 'fra', 'ita', 'spa', 'tur', 'rus', 'ara', 'pol', 'ukr',
  'ron', 'rum', 'bul', 'ell', 'gre', 'nld', 'dut', 'por', 'hrv', 'srp', 'fas', 'per',
  'kur', 'sqi', 'alb', 'vie', 'zho', 'chi',
] as const;
// typeCOUNTRIES ist im Schema ein xsd:pattern, das die ISO-3166-Alpha-2-Codes einzeln aufzaehlt
// und dahinter einen optionalen Zusatz aus bis zu drei Zeichen erlaubt. Geprueft wird hier nur
// diese Form, nicht die Zugehoerigkeit zur Liste: eine Namensliste aller Staaten waere in einer
// Quelldatei nicht zu pflegen, und dieser Export schreibt ohnehin nur Codes, die aus der
// Uebersetzungstabelle in kursnet-export.ts stammen.
const LAENDER_MUSTER = /^[A-Z]{2}(-[A-Z0-9]{1,3})?$/;
// typeCURRENCIES ist ebenfalls eine geschlossene Liste, aber mit 177 Eintraegen (ISO 4217).
// Auch hier wird nur die Form geprueft. Die frueher hier stehende Liste ['EUR','CHF'] war eine
// Verengung, die im Schema keine Entsprechung hat: sie haette einen fremden, voellig gueltigen
// Katalog in USD abgewiesen.
const WAEHRUNG_MUSTER = /^[A-Z]{3}$/;

const SUPPLIER_ID: ElementModell = {
  name: 'SUPPLIER_ID', min: 1, max: UNBEGRENZT,
  facetten: { art: 'string' },
  attrs: [{ name: 'type', pflicht: true, facetten: { werte: SUPPLIER_ID_ARTEN } }],
};

// typeEMAILS wiederholt im Schema die Folge (EMAIL, PUBLIC_KEY*). Dieser Export schreibt hoechstens
// eine Adresse; das Modell laesst deshalb mehrere EMAIL zu und weist nichts Gueltiges ab.
const EMAILS: ElementModell = {
  name: 'EMAILS', min: 0, max: 1,
  inhalt: [txt('EMAIL', 1, UNBEGRENZT, 255), txt('PUBLIC_KEY', 0, UNBEGRENZT, 64000)],
};

// typeADDRESS - jedes Feld ist optional, deshalb entscheidet allein die Reihenfolge.
const adresse = (name: string, min: number, max: number): ElementModell => ({
  name, min, max,
  inhalt: [
    txt('NAME', 0, 1, 30), txt('NAME2', 0, 1, 30), txt('NAME3', 0, 1, 30),
    txt('STREET', 0, 1, 30), txt('ZIP', 0, 1, 14), txt('BOXNO', 0, 1, 14), txt('ZIPBOX', 0, 1, 14),
    txt('CITY', 0, 1, 36), txt('DISTRICT', 0, 1, 36), txt('STATE', 0, 1, 80),
    el('COUNTRY_CODED', 0, 1, { facetten: { art: 'string', maxLength: 80, muster: LAENDER_MUSTER } }),
    el('COUNTRY', 0, 1, { facetten: { art: 'string', minLength: 1, maxLength: 50 } }),
    txt('PHONE', 0, 1, 30), txt('MOBILE', 0, 1, 30), txt('FAX', 0, 1, 30),
    EMAILS,
    txt('URL', 0, 1, 255), txt('ADDRESS_REMARKS', 0, 1, 4000),
    el('BARRIER_FREE_LOCATION', 0, 1, { facetten: { art: 'boolean' } }),
    txt('ID_DB', 0, 1, 255),
  ],
});

const kontakt = (name: string, min: number, max: number): ElementModell => ({
  name, min, max,
  inhalt: [
    el('CONTACT_ROLE', 0, 1, { facetten: { art: 'string' }, attrs: [{ name: 'type', pflicht: true, facetten: { art: 'int' } }] }),
    txt('SALUTATION', 0, 1, 15), txt('ACADEMIC_TITLE', 0, 1, 255),
    txt('FIRST_NAME', 0, 1, 30), txt('LAST_NAME', 0, 1, 30), txt('NAME_PREFIX', 0, 1, 30),
    txt('JOB_TITLE', 0, 1, 255),
    txt('PHONE', 0, 1, 30), txt('MOBILE', 0, 1, 30), txt('FAX', 0, 1, 30),
    EMAILS,
    txt('URL', 0, 1, 255), txt('ID_DB', 0, 1, 255),
    adresse('ADDRESS', 0, 1),
    txt('CONTACT_REMARKS', 0, 1, 64000),
  ],
});

// typePERIOD - Beginn und Ende als xsd:dateTime.
const zeitraum = (name: string, min: number, max: number, extra: Partial<ElementModell> = {}): ElementModell => ({
  name, min, max,
  inhalt: [
    el('START_DATE', 0, 1, { facetten: { art: 'dateTime' } }),
    el('END_DATE', 0, 1, { facetten: { art: 'dateTime' } }),
    txt('DATE_REMARKS', 0, 1, 4000),
  ],
  ...extra,
});

// Die KURSNET-Zahlenschluessel: Textinhalt plus Pflichtattribut type als ganze Zahl.
const schluessel = (name: string, min: number, max: number): ElementModell =>
  ({ name, min, max, facetten: { art: 'string' }, attrs: [{ name: 'type', pflicht: true, facetten: { art: 'int' } }] });

// typeEDUCATION/EXTENDED_INFO: INSTITUTION, INSTRUCTION_FORM und EDUCATION_TYPE sind Pflicht,
// sobald dieser Zweig ueberhaupt geschrieben wird.
const EDUCATION_EXTENDED: ElementModell = {
  name: 'EXTENDED_INFO', min: 0, max: 1,
  inhalt: [
    schluessel('INSTITUTION', 1, 1),
    schluessel('INSTRUCTION_FORM', 1, 1),
    el('INSTRUCTION_FORM_NAME', 0, 1, { facetten: { art: 'string', minLength: 5, maxLength: 30 } }),
    schluessel('INSTRUCTION_TIME', 0, 1),
    el('INHOUSE_SEMINAR', 0, 1, { facetten: { art: 'boolean' } }),
    el('EXTRA_OCCUPATIONAL', 0, 1, { facetten: { art: 'boolean' } }),
    el('PRACTICAL_PART', 0, 1, { facetten: { art: 'boolean' } }),
    el('TRAINEE_SUITABLE', 0, 1, { facetten: { art: 'boolean' } }),
    el('EMPLOYEE_SUITABLE', 0, 1, { facetten: { art: 'boolean' } }),
    schluessel('EXECUTION_FORM', 0, 1),
    schluessel('FUNDING_TYPES_FEDERAL', 0, UNBEGRENZT),
    schluessel('FUNDING_TYPES_REGIONAL', 0, UNBEGRENZT),
    txt('FUNDING_TYPES_REMARKS', 0, 1, 2000),
    el('DIGITAL_ACCESSIBILITY', 0, 1, { facetten: { art: 'boolean' } }),
    txt('DIGITAL_ACCESSIBILITY_REMARKS', 0, 1, 4000),
    txt('TEACHING_LANGUAGES', 0, UNBEGRENZT, 3),
    txt('TEACHING_LANGUAGES_REMARKS', 0, 1, 256),
    schluessel('EDUCATION_TYPE', 1, 1),
    txt('MEASURE_NUMBER', 0, 1, 30),
    txt('LECTURE_PERIOD', 0, 1, 2000),
    el('ADM_RESTRICTION', 0, 1, { facetten: { art: 'int' } }),
    txt('ADM_RESTRICTION_DESC', 0, 1, 2000),
    el('MINOR_COURSE', 0, 1, { facetten: { werte: ['j', 'J', 'n', 'N'] } }),
    el('MANDATORY_COURSE_COMBINATION', 0, 1, { facetten: { werte: ['j', 'J', 'n', 'N'] } }),
    txt('COMBINATION_DESCRIPTION', 0, 1, 2000),
    el('SEM_RESTRICTION', 0, 1, { facetten: { art: 'int' } }),
  ],
};

const MODULE_COURSE: ElementModell = {
  name: 'MODULE_COURSE', min: 1, max: 1,
  inhalt: [
    txt('MARKETINGTEXT', 0, 1, 64000),
    kontakt('INSTRUCTOR', 0, UNBEGRENZT),
    el('MIN_PARTICIPANTS', 0, 1, { facetten: { art: 'int' } }),
    el('MAX_PARTICIPANTS', 0, 1, { facetten: { art: 'int' } }),
    adresse('LOCATION', 0, 1),
    // DURATION traegt die Zeitraumklasse als Pflichtattribut (typePERIOD_WITH_ATTRIBUTE).
    zeitraum('DURATION', 0, 1, { attrs: [{ name: 'type', pflicht: true, facetten: { art: 'int' } }] }),
    el('SERVICE_REFERENCE', 0, 1, { offen: true }),
    el('MODULE_ORDER', 0, 1, { facetten: { art: 'int' } }),
    txt('METHOD', 0, UNBEGRENZT, 255),
    txt('MEDIA', 0, UNBEGRENZT, 255),
    el('MIME_INFO', 0, UNBEGRENZT, { offen: true }),
    txt('INSTRUCTION_REMARKS', 0, 1, 2000),
    el('FLEXIBLE_START', 0, 1, { facetten: { art: 'boolean' } }),
    el('EXTENDED_INFO', 0, 1, { inhalt: [schluessel('SEGMENT_TYPE', 1, 1)] }),
  ],
};

const EDUCATION: ElementModell = {
  name: 'EDUCATION', min: 1, max: 1,
  attrs: [{ name: 'type', facetten: { art: 'boolean' } }],
  inhalt: [
    txt('COURSE_ID', 0, 1, 255),
    el('DEGREE', 0, 1, { offen: true }),
    kontakt('MODULE_ORGANIZER', 0, 1),
    el('LANGUAGE', 0, UNBEGRENZT, { facetten: { werte: SPRACHEN } }),
    txt('CREDITS', 0, 1, 4000),
    el('HANDICAP', 0, UNBEGRENZT, { offen: true }),
    el('SUBSIDY', 0, UNBEGRENZT, { offen: true }),
    el('REGISTRATION_DATE', 0, 1, { facetten: { art: 'dateTime' } }),
    el('MIME_INFO', 0, UNBEGRENZT, { offen: true }),
    el('CERTIFICATE', 0, UNBEGRENZT, { offen: true }),
    EDUCATION_EXTENDED,
    {
      auswahl: [MODULE_COURSE, el('MODULE_CBT', 1, 1, { offen: true }), el('MODULE_WBT', 1, 1, { offen: true })],
      min: 1, max: UNBEGRENZT,
    },
  ],
};

const SERVICE_DETAILS: ElementModell = {
  name: 'SERVICE_DETAILS', min: 1, max: 1,
  inhalt: [
    txt('TITLE', 1, 1, 255),
    txt('DESCRIPTION_LONG', 0, 1, 30000),
    el('SERVICE_ORDER', 0, 1, { facetten: { art: 'int' } }),
    txt('SUPPLIER_ALT_PID', 0, 1, 30),
    txt('RECIPIENT_PID', 0, 1, 255),
    kontakt('CONTACT', 0, UNBEGRENZT),
    el('SERVICE_STATUS', 0, UNBEGRENZT, { offen: true }),
    txt('REQUIREMENTS', 0, 1, 10000),
    zeitraum('SERVICE_DATE', 0, 1),
    txt('KEYWORD', 0, UNBEGRENZT, 255),
    el('SEGMENT', 0, 1, { facetten: { art: 'string' } }),
    el('TARGET_GROUP', 0, UNBEGRENZT, {
      inhalt: [
        txt('TARGET_GROUP_TEXT', 0, 1, 4000),
        txt('TARGET_GROUP_HIERARCHY', 0, UNBEGRENZT, 60),
        el('TARGET_GROUP_INDUSTRY', 0, UNBEGRENZT, { offen: true }),
        txt('TARGET_GROUP_DEPARTMENT', 0, 1, 60),
      ],
    }),
    el('TIME_TO_HANDLE', 0, 1, { facetten: { art: 'unsignedShort' } }),
    txt('TERMS_AND_CONDITIONS', 0, UNBEGRENZT, 4000),
    el('STUDY_COURSE', 0, 1, { offen: true }),
    el('SERVICE_MODULE', 0, 1, { inhalt: [{ auswahl: [EDUCATION], min: 1, max: 1 }] }),
    el('ANNOUNCEMENT', 0, 1, { offen: true }),
  ],
};

const SERVICE: ElementModell = {
  name: 'SERVICE', min: 0, max: UNBEGRENZT,
  attrs: [{ name: 'mode', facetten: { fest: 'new' } }],
  inhalt: [
    txt('PRODUCT_ID', 1, 1, 255),
    el('COURSE_TYPE', 1, 1, { facetten: { art: 'int', werte: ['1', '2', '3', '4', '5'] } }),
    { ...SUPPLIER_ID, name: 'SUPPLIER_ID_REF', min: 0, max: 1 },
    SERVICE_DETAILS,
    el('SERVICE_CLASSIFICATION', 0, UNBEGRENZT, { offen: true }),
    el('SERVICE_PRICE_DETAILS', 0, 1, { offen: true }),
    el('HS_INFO', 0, 1, { offen: true }),
    el('MIME_INFO', 0, 1, { offen: true }),
    el('SERVICE_REFERENCE', 0, UNBEGRENZT, { offen: true }),
  ],
};

// typeSERVICE_DELETION: zum Loeschen genuegt die Artikelnummer.
const SERVICE_LOESCHUNG: ElementModell = {
  name: 'SERVICE', min: 1, max: UNBEGRENZT,
  inhalt: [txt('PRODUCT_ID', 1, 1, 255), { ...SUPPLIER_ID, name: 'SUPPLIER_ID_REF', min: 0, max: 1 }],
};

const HEADER: ElementModell = {
  name: 'HEADER', min: 1, max: 1,
  inhalt: [
    txt('GENERATOR_INFO', 0, 1, 64000),
    el('CATALOG', 1, 1, {
      inhalt: [
        el('LANGUAGE', 1, 1, { facetten: { werte: SPRACHEN } }),
        el('CATALOG_ID', 1, 1, { facetten: { art: 'string', minLength: 1, maxLength: 50 } }),
        el('CATALOG_VERSION', 1, 1, { facetten: { art: 'string', minLength: 1, maxLength: 255 } }),
        txt('CATALOG_NAME', 0, 1, 255),
        el('GENERATION_DATE', 0, 1, { facetten: { art: 'dateTime' } }),
        txt('TERRITORY', 0, UNBEGRENZT, 255),
        el('CURRENCY', 0, 1, { facetten: { art: 'string', muster: WAEHRUNG_MUSTER } }),
        txt('MIME_ROOT', 0, 1, 255),
      ],
    }),
    kontakt('DOCUMENT_CREATOR', 0, 1),
    el('RECIPIENT', 0, 1, { offen: true }),
    el('SUPPLIER', 1, UNBEGRENZT, {
      inhalt: [
        SUPPLIER_ID,
        txt('SUPPLIER_NAME', 1, 1, 255),
        adresse('ADDRESS', 1, 1),
        kontakt('CONTACT', 0, UNBEGRENZT),
        txt('KEYWORD', 0, UNBEGRENZT, 255),
        el('MIME_INFO', 0, 1, { offen: true }),
        el('CERTIFICATE', 0, UNBEGRENZT, { offen: true }),
        // EXTENDED_INFO ist unter SUPPLIER PFLICHT (minOccurs=1) und traegt das Eingabeverfahren
        // als Pflichtattribut. Ohne beides nimmt KURSNET den Katalog nicht an.
        el('EXTENDED_INFO', 1, 1, {
          attrs: [{ name: 'input_type', pflicht: true, facetten: { art: 'int' } }],
          inhalt: [
            txt('INSTITUTION_NUMBER', 0, 1, 8),
            el('FUNDING_BODY', 0, 1, { facetten: { art: 'int' } }),
            schluessel('ORGANIZATIONAL_FORM', 0, 1),
            txt('STANDARD_COMPANY_NUMBER', 0, 1, 8),
            txt('CUSTOMER_NUMBER', 0, 1, 20),
            el('BANKING', 0, UNBEGRENZT, { offen: true }),
          ],
        }),
      ],
    }),
    el('AGREEMENT', 0, UNBEGRENZT, { offen: true }),
  ],
};

const OPENQCAT: ElementModell = {
  name: 'OPENQCAT', min: 1, max: 1,
  attrs: [{ name: 'version', facetten: { fest: '1.1' } }],
  inhalt: [
    HEADER,
    {
      auswahl: [
        el('NEW_CATALOG', 1, 1, {
          attrs: [{ name: 'FULLCATALOG', facetten: { art: 'boolean' } }],
          inhalt: [
            el('CLASSIFICATION_SYSTEM', 0, UNBEGRENZT, { offen: true }),
            el('CATALOG_GROUP_SYSTEM', 0, UNBEGRENZT, { offen: true }),
            SERVICE,
            el('SERVICE_TO_CATALOGGROUP_MAP', 0, UNBEGRENZT, { offen: true }),
          ],
        }),
        el('UPDATE_CATALOG', 1, 1, {
          attrs: [{ name: 'seq_number', pflicht: true, facetten: { art: 'int' } }],
          inhalt: [
            el('DELETE', 0, 1, { inhalt: [SERVICE_LOESCHUNG] }),
            el('NEW', 0, 1, { inhalt: [SERVICE] }),
          ],
        }),
      ],
      min: 1, max: 1,
    },
  ],
};

// ---------------------------------------------------------------------------------------------
// Pruefen
// ---------------------------------------------------------------------------------------------

export interface Befund { pfad: string; code: string; detail: string }

const IST_INT = /^[+-]?\d+$/;
const IST_FLOAT = /^[+-]?\d+(\.\d+)?([eE][+-]?\d+)?$/;
const IST_DATUM = /^\d{4}-\d{2}-\d{2}$/;
const IST_ZEITPUNKT = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})?$/;

// Ein Kalendertag, den es wirklich gibt. Das Muster allein liesse den 31.02. durch, und ein
// Angebot mit einem solchen Beginn wird von KURSNET zurueckgewiesen.
function echtesDatum(iso: string): boolean {
  const [j, m, t] = iso.slice(0, 10).split('-').map(Number);
  const d = new Date(Date.UTC(j, m - 1, t));
  return d.getUTCFullYear() === j && d.getUTCMonth() === m - 1 && d.getUTCDate() === t;
}

function facettenPruefen(wert: string, facetten: Facetten | undefined, pfad: string, befunde: Befund[]): void {
  if (!facetten) return;
  const art = facetten.art ?? 'string';
  if (facetten.fest !== undefined && wert !== facetten.fest)
    befunde.push({ pfad, code: 'FESTER_WERT_VERLETZT', detail: `erwartet "${facetten.fest}", gefunden "${wert}"` });
  if (facetten.werte && !facetten.werte.includes(wert))
    befunde.push({ pfad, code: 'WERT_NICHT_ERLAUBT', detail: `"${wert}" steht nicht in der Werteliste des Schemas` });
  if (facetten.muster && !facetten.muster.test(wert))
    befunde.push({ pfad, code: 'MUSTER_VERLETZT', detail: `"${wert}" passt nicht zum Muster des Schemas` });
  // In Zeichen zaehlen, nicht in UTF-16-Einheiten: maxLength des Schemas zaehlt Zeichen.
  const laenge = [...wert].length;
  if (facetten.maxLength !== undefined && laenge > facetten.maxLength)
    befunde.push({ pfad, code: 'ZU_LANG', detail: `${laenge} Zeichen, erlaubt sind ${facetten.maxLength}` });
  if (facetten.minLength !== undefined && laenge < facetten.minLength)
    befunde.push({ pfad, code: 'ZU_KURZ', detail: `${laenge} Zeichen, verlangt sind ${facetten.minLength}` });
  if (art === 'int' && !IST_INT.test(wert)) befunde.push({ pfad, code: 'KEINE_GANZE_ZAHL', detail: `"${wert}"` });
  if (art === 'unsignedShort' && (!/^\d+$/.test(wert) || Number(wert) > 65535))
    befunde.push({ pfad, code: 'KEINE_KURZE_ZAHL', detail: `"${wert}"` });
  if (art === 'float' && !IST_FLOAT.test(wert)) befunde.push({ pfad, code: 'KEINE_ZAHL', detail: `"${wert}"` });
  if (art === 'boolean' && !['true', 'false', '0', '1'].includes(wert))
    befunde.push({ pfad, code: 'KEIN_WAHRHEITSWERT', detail: `"${wert}"` });
  if (art === 'date' && (!IST_DATUM.test(wert) || !echtesDatum(wert)))
    befunde.push({ pfad, code: 'KEIN_DATUM', detail: `"${wert}" ist kein xsd:date (JJJJ-MM-TT)` });
  if (art === 'dateTime' && (!IST_ZEITPUNKT.test(wert) || !echtesDatum(wert)))
    befunde.push({ pfad, code: 'KEIN_ZEITPUNKT', detail: `"${wert}" ist kein xsd:dateTime (JJJJ-MM-TTThh:mm:ss)` });
}

function istElement(teil: Teilchen): teil is ElementModell { return (teil as ElementModell).name !== undefined; }
function namenVon(teil: Teilchen): string[] { return istElement(teil) ? [teil.name] : teil.auswahl.map((x) => x.name); }
function modellFuer(teil: Teilchen, name: string): ElementModell | null {
  if (istElement(teil)) return teil.name === name ? teil : null;
  return teil.auswahl.find((x) => x.name === name) ?? null;
}

function elementPruefen(knoten: GelesenesElement, modell: ElementModell, pfad: string, befunde: Befund[]): void {
  const erlaubt = new Set((modell.attrs ?? []).map((a) => a.name));
  for (const name of Object.keys(knoten.attrs))
    if (!erlaubt.has(name)) befunde.push({ pfad, code: 'ATTRIBUT_UNBEKANNT', detail: name });
  for (const attr of modell.attrs ?? []) {
    const wert = knoten.attrs[attr.name];
    if (wert === undefined) {
      if (attr.pflicht) befunde.push({ pfad, code: 'PFLICHTATTRIBUT_FEHLT', detail: attr.name });
      continue;
    }
    facettenPruefen(wert, attr.facetten, `${pfad}/@${attr.name}`, befunde);
  }
  if (modell.offen) return;
  if (!modell.inhalt) {
    if (knoten.kinder.length) befunde.push({ pfad, code: 'UNERWARTETES_ELEMENT', detail: knoten.kinder[0].name });
    facettenPruefen(knoten.text, modell.facetten, pfad, befunde);
    return;
  }
  if (knoten.hatText && knoten.text.trim())
    befunde.push({ pfad, code: 'TEXT_IN_STRUKTUR', detail: 'dieses Element traegt nur Kindelemente' });
  // Die Folge des Schemas wird der Reihe nach abgearbeitet. Was danach uebrig bleibt, steht
  // entweder an der falschen Stelle oder gehoert nicht hierher - beides weist KURSNET zurueck.
  const bekannt = new Set(modell.inhalt.flatMap(namenVon));
  let i = 0;
  for (const teilchen of modell.inhalt) {
    let anzahl = 0;
    while (i < knoten.kinder.length && anzahl < teilchen.max) {
      const kind = knoten.kinder[i];
      const kindModell = modellFuer(teilchen, kind.name);
      if (!kindModell) break;
      elementPruefen(kind, kindModell, `${pfad}/${kind.name}`, befunde);
      i++; anzahl++;
    }
    if (anzahl < teilchen.min)
      befunde.push({ pfad, code: 'PFLICHTELEMENT_FEHLT', detail: namenVon(teilchen).join('|') });
  }
  for (; i < knoten.kinder.length; i++) {
    const kind = knoten.kinder[i];
    befunde.push(bekannt.has(kind.name)
      ? { pfad, code: 'FALSCHE_REIHENFOLGE', detail: `${kind.name} steht nicht an der vom Schema verlangten Stelle` }
      : { pfad, code: 'UNERWARTETES_ELEMENT', detail: kind.name });
  }
}

/**
 * Prueft eine ERZEUGTE open-Qcat-Datei gegen die Regeln, die hier aus der Schemadatei abgebildet
 * sind: Wurzel und feste Attributwerte, Pflichtelemente und Pflichtattribute, Reihenfolge,
 * Kardinalitaet, Laengen, geschlossene Wertelisten sowie Datums- und Zahlenformate.
 */
export function openQcatPruefen(xml: string): { gueltig: boolean; befunde: Befund[] } {
  const befunde: Befund[] = [];
  let wurzel: GelesenesElement;
  try {
    wurzel = xmlLesen(xml);
  } catch (fehler) {
    return { gueltig: false, befunde: [{ pfad: '/', code: 'XML_UNLESBAR', detail: String((fehler as Error).message) }] };
  }
  if (wurzel.name !== 'OPENQCAT')
    return { gueltig: false, befunde: [{ pfad: '/', code: 'FALSCHE_WURZEL', detail: wurzel.name }] };
  elementPruefen(wurzel, OPENQCAT, '/OPENQCAT', befunde);
  return { gueltig: befunde.length === 0, befunde };
}

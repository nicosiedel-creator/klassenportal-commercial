import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Vertrieb: vom Interessenten bis zum Vertrag.
//
// Das Portal konnte ein Angebot schreiben und aus der Zusage einen Vertrag machen. Alles davor
// fehlte: wer angefragt hat, wann zuletzt jemand mit ihm gesprochen hat, was als Naechstes
// ansteht und warum die Haelfte der Anfragen nie ein Angebot wurde. Das lief in Outlook, in einer
// Tabelle und im Kopf einer Person - und mit ihr ging es.
//
// Drei Regeln, und sie sind der Unterschied zwischen einer Pipeline und einer Wunschliste:
//
//  1. "GEWONNEN" HEISST: ES GIBT EIN ANGENOMMENES ANGEBOT. Nicht "sieht gut aus", nicht "hat
//     muendlich zugesagt". Wer den Stand selbst setzen darf, misst die Zuversicht des Vertriebs.
//  2. EIN OFFENER VORGANG BRAUCHT EINEN NAECHSTEN SCHRITT MIT DATUM.
//  3. EINE NACHVERHANDLUNG ERZEUGT EINE FASSUNG, SIE UEBERSCHREIBT NICHTS. Was urspruenglich
//     angeboten wurde, ist genau die Frage, die im Streit gestellt wird.

const clean=(v:unknown,n=2000)=>safeString(v,n);
export const ACCOUNTARTEN=['betrieb','kostentraeger','kammer','schule','verband','sonstige'] as const;
export const QUELLEN=['empfehlung','messe','anfrage','kaltakquise','bestandskunde','ausschreibung','sonstige'] as const;
export const STUFEN=['neu','qualifiziert','angebot','verhandlung','gewonnen','verloren'] as const;
export const AKTIVITAETSARTEN=['anruf','email','termin','angebot','notiz','absage'] as const;
export const VERLUSTGRUENDE=['preis','termin','anbieter','kein_bedarf','kein_budget','keine_rueckmeldung','sonstiges'] as const;
/** Stufen, die einen offenen Vorgang bedeuten. */
export const OFFEN=new Set(['neu','qualifiziert','angebot','verhandlung']);

function datum(v:unknown,feld:string){
  const s=clean(v,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(s))throw new Error(`VERTRIEB_${feld}_UNGUELTIG`);
  return s;
}

// ---------------------------------------------------------------------------------------------
// Organisationen und Ansprechpartner
// ---------------------------------------------------------------------------------------------

export async function legeOrganisationAn(env:Env,auth:CoreAuthContext,tenantId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const name=clean(eingabe.name,200);
  if(name.length<2)throw new Error('VERTRIEB_NAME_ERFORDERLICH');
  const art=clean(eingabe.art,30)||'betrieb';
  if(!(ACCOUNTARTEN as readonly string[]).includes(art))throw new Error('VERTRIEB_ART_UNGUELTIG');
  const quelle=clean(eingabe.quelle,30)||null;
  if(quelle&&!(QUELLEN as readonly string[]).includes(quelle))throw new Error('VERTRIEB_QUELLE_UNGUELTIG');
  const accountId=id('sac_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO sales_accounts(id,tenant_id,name,art,branche,ort,website,quelle,notiz,status,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,'aktiv',?,?,?)`)
    .bind(accountId,tenantId,name,art,clean(eingabe.branche,120)||null,clean(eingabe.ort,120)||null,
      clean(eingabe.website,200)||null,quelle,clean(eingabe.notiz,2000)||null,auth.userId,ts,ts).run();
  return{id:accountId,name,art};
}

export async function legeKontaktAn(env:Env,auth:CoreAuthContext,tenantId:string,accountId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const account=await env.DB.prepare('SELECT id FROM sales_accounts WHERE tenant_id=? AND id=?')
    .bind(tenantId,clean(accountId,120)).first<{id:string}>();
  if(!account)throw new Error('VERTRIEB_ORGANISATION_NICHT_GEFUNDEN');
  const name=clean(eingabe.name,200);
  if(name.length<2)throw new Error('VERTRIEB_NAME_ERFORDERLICH');
  const kontaktId=id('sko_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO sales_contacts(id,tenant_id,account_id,name,funktion,email,telefon,hauptkontakt,notiz,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(kontaktId,tenantId,account.id,name,clean(eingabe.funktion,120)||null,clean(eingabe.email,200)||null,
      clean(eingabe.telefon,60)||null,eingabe.hauptkontakt?1:0,clean(eingabe.notiz,1000)||null,auth.userId,ts,ts).run();
  return{id:kontaktId,name};
}

/**
 * Widerspruch gegen Werbung festhalten (Art. 21 Abs. 2 DSGVO).
 *
 * Er wirkt sofort und ohne Abwaegung. Ihn nur im Kopf der Person zu behalten, die den Anruf
 * entgegengenommen hat, ist die haeufigste Ursache fuer den zweiten Anruf - und der zweite Anruf
 * ist der, der beim Datenschutzbeauftragten landet.
 */
export async function haltWerbewiderspruchFest(env:Env,auth:CoreAuthContext,tenantId:string,kontaktId:string,am?:unknown){
  requireRole(auth,'tenant_admin');
  const tag=am?datum(am,'WIDERSPRUCH'):nowIso().slice(0,10);
  const r=await env.DB.prepare('UPDATE sales_contacts SET werbung_widerspruch_am=?,updated_at=? WHERE tenant_id=? AND id=?')
    .bind(tag,nowIso(),tenantId,clean(kontaktId,120)).run();
  if(!r.meta?.changes)throw new Error('VERTRIEB_KONTAKT_NICHT_GEFUNDEN');
  await audit(env.DB,auth.userId,'sales.contact.objection',tenantId,undefined,'sales_contact',clean(kontaktId,120),{am:tag});
  return{werbung_widerspruch_am:tag};
}

/** Wen man ansprechen darf - und wen ausdruecklich nicht mehr. */
export async function ansprechbareKontakte(env:Env,auth:CoreAuthContext,tenantId:string,accountId:string){
  requireRole(auth,'tenant_admin');
  const zeilen=((await env.DB.prepare('SELECT * FROM sales_contacts WHERE tenant_id=? AND account_id=? ORDER BY hauptkontakt DESC,name')
    .bind(tenantId,clean(accountId,120)).all<Record<string,unknown>>()).results)??[];
  return zeilen.map(z=>({...z,ansprechbar:!z.werbung_widerspruch_am}));
}

// ---------------------------------------------------------------------------------------------
// Vorgaenge
// ---------------------------------------------------------------------------------------------

export async function legeVorgangAn(env:Env,auth:CoreAuthContext,tenantId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const account=await env.DB.prepare('SELECT id,name FROM sales_accounts WHERE tenant_id=? AND id=?')
    .bind(tenantId,clean(eingabe.account_id,120)).first<{id:string;name:string}>();
  if(!account)throw new Error('VERTRIEB_ORGANISATION_NICHT_GEFUNDEN');
  const bezeichnung=clean(eingabe.bezeichnung,200);
  if(bezeichnung.length<5)throw new Error('VERTRIEB_BEZEICHNUNG_ERFORDERLICH');
  // Ein offener Vorgang ohne naechsten Schritt ist ein vergessener Vorgang. Das faellt hier auf
  // und nicht ein halbes Jahr spaeter beim Aufraeumen der Liste.
  const wiedervorlage=datum(eingabe.wiedervorlage_am,'WIEDERVORLAGE');
  const schritt=clean(eingabe.naechster_schritt,500);
  if(schritt.length<3)throw new Error('VERTRIEB_NAECHSTER_SCHRITT_ERFORDERLICH');
  const vorgangId=id('sle_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO sales_leads(id,tenant_id,account_id,contact_id,bezeichnung,anlass,course_id,stufe,erwarteter_wert_cent,verantwortlich,naechster_schritt,wiedervorlage_am,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,'neu',?,?,?,?,?,?,?)`)
    .bind(vorgangId,tenantId,account.id,clean(eingabe.contact_id,120)||null,bezeichnung,clean(eingabe.anlass,2000)||null,
      clean(eingabe.course_id,120)||null,
      eingabe.erwarteter_wert_cent===undefined||eingabe.erwarteter_wert_cent===null?null:Math.trunc(Number(eingabe.erwarteter_wert_cent)),
      clean(eingabe.verantwortlich,120)||auth.userId,schritt,wiedervorlage,auth.userId,ts,ts).run();
  return{id:vorgangId,bezeichnung,stufe:'neu',wiedervorlage_am:wiedervorlage};
}

async function ladeVorgang(env:Env,tenantId:string,leadId:string){
  const z=await env.DB.prepare('SELECT * FROM sales_leads WHERE tenant_id=? AND id=?')
    .bind(tenantId,clean(leadId,120)).first<Record<string,unknown>>();
  if(!z)throw new Error('VERTRIEB_VORGANG_NICHT_GEFUNDEN');
  return z;
}

/**
 * Die Stufe aendern.
 *
 * 'gewonnen' laesst sich hier NICHT setzen: dafuer muss ein Angebot angenommen sein, und das
 * traegt gewinneVorgang nach. Der Unterschied ist die ganze Aussagekraft der Statistik.
 */
export async function setzeStufe(env:Env,auth:CoreAuthContext,tenantId:string,leadId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const v=await ladeVorgang(env,tenantId,leadId);
  const stufe=clean(eingabe.stufe,30);
  if(!(STUFEN as readonly string[]).includes(stufe))throw new Error('VERTRIEB_STUFE_UNGUELTIG');
  if(stufe==='gewonnen')throw new Error('VERTRIEB_GEWONNEN_NUR_UEBER_ANGEBOT');
  if(v.stufe==='gewonnen'||v.stufe==='verloren')throw new Error('VERTRIEB_VORGANG_ABGESCHLOSSEN');
  const ts=nowIso();
  if(stufe==='verloren'){
    const grund=clean(eingabe.verloren_grund,40);
    if(!(VERLUSTGRUENDE as readonly string[]).includes(grund))throw new Error('VERTRIEB_VERLUSTGRUND_ERFORDERLICH');
    await env.DB.prepare(`UPDATE sales_leads SET stufe='verloren',verloren_grund=?,verloren_notiz=?,entschieden_am=?,
      wiedervorlage_am=NULL,naechster_schritt=NULL,updated_at=? WHERE tenant_id=? AND id=?`)
      .bind(grund,clean(eingabe.verloren_notiz,2000)||null,ts,ts,tenantId,v.id).run();
    await env.DB.prepare('INSERT INTO sales_activities(id,tenant_id,lead_id,art,am,text,erfasst_von,created_at) VALUES(?,?,?,?,?,?,?,?)')
      .bind(id('sak_'),tenantId,v.id,'absage',ts.slice(0,10),`Verloren: ${grund}${eingabe.verloren_notiz?` - ${clean(eingabe.verloren_notiz,500)}`:''}`,auth.userId,ts).run();
    await audit(env.DB,auth.userId,'sales.lead.lost',tenantId,undefined,'sales_lead',String(v.id),{grund});
    return{stufe:'verloren',grund};
  }
  // Jede offene Stufe braucht weiterhin einen naechsten Schritt.
  const wiedervorlage=eingabe.wiedervorlage_am?datum(eingabe.wiedervorlage_am,'WIEDERVORLAGE'):String(v.wiedervorlage_am??'');
  if(!wiedervorlage)throw new Error('VERTRIEB_WIEDERVORLAGE_ERFORDERLICH');
  const schritt=clean(eingabe.naechster_schritt,500)||String(v.naechster_schritt??'');
  if(schritt.length<3)throw new Error('VERTRIEB_NAECHSTER_SCHRITT_ERFORDERLICH');
  await env.DB.prepare('UPDATE sales_leads SET stufe=?,wiedervorlage_am=?,naechster_schritt=?,erinnert_am=NULL,updated_at=? WHERE tenant_id=? AND id=?')
    .bind(stufe,wiedervorlage,schritt,ts,tenantId,v.id).run();
  return{stufe,wiedervorlage_am:wiedervorlage};
}

export async function erfasseAktivitaet(env:Env,auth:CoreAuthContext,tenantId:string,leadId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const v=await ladeVorgang(env,tenantId,leadId);
  const art=clean(eingabe.art,20);
  if(!(AKTIVITAETSARTEN as readonly string[]).includes(art))throw new Error('VERTRIEB_AKTIVITAETSART_UNGUELTIG');
  const text=clean(eingabe.text,4000);
  if(text.length<3)throw new Error('VERTRIEB_TEXT_ERFORDERLICH');
  const am=eingabe.am?datum(eingabe.am,'DATUM'):nowIso().slice(0,10);
  const ts=nowIso();
  const anweisungen=[env.DB.prepare('INSERT INTO sales_activities(id,tenant_id,lead_id,art,am,text,erfasst_von,created_at) VALUES(?,?,?,?,?,?,?,?)')
    .bind(id('sak_'),tenantId,v.id,art,am,text,auth.userId,ts)];
  // Wer einen Kontakt festhaelt, setzt in aller Regel auch den naechsten Schritt. Beides in einem
  // Zug, sonst bleibt die Wiedervorlage stehen, wo sie war.
  if(eingabe.wiedervorlage_am&&OFFEN.has(String(v.stufe)))
    anweisungen.push(env.DB.prepare('UPDATE sales_leads SET wiedervorlage_am=?,naechster_schritt=COALESCE(?,naechster_schritt),erinnert_am=NULL,updated_at=? WHERE tenant_id=? AND id=?')
      .bind(datum(eingabe.wiedervorlage_am,'WIEDERVORLAGE'),clean(eingabe.naechster_schritt,500)||null,ts,tenantId,v.id));
  await env.DB.batch(anweisungen);
  return{art,am,text};
}

/**
 * Ein Angebot an den Vorgang haengen.
 *
 * Damit wird aus einer Absichtserklaerung eine Zahl, die jemand unterschrieben hat - und die
 * Vertriebsauswertung rechnet ab hier mit der Angebotssumme statt mit der Schaetzung.
 */
export async function verknuepfeAngebot(env:Env,auth:CoreAuthContext,tenantId:string,leadId:string,offerId:string){
  requireRole(auth,'tenant_admin');
  const v=await ladeVorgang(env,tenantId,leadId);
  const a=await env.DB.prepare('SELECT id,status FROM course_offers WHERE tenant_id=? AND id=?')
    .bind(tenantId,clean(offerId,120)).first<{id:string;status:string}>();
  if(!a)throw new Error('VERTRIEB_ANGEBOT_NICHT_GEFUNDEN');
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare(`UPDATE sales_leads SET offer_id=?,stufe=CASE WHEN stufe IN ('neu','qualifiziert') THEN 'angebot' ELSE stufe END,updated_at=?
      WHERE tenant_id=? AND id=?`).bind(a.id,ts,tenantId,v.id),
    env.DB.prepare('INSERT INTO sales_activities(id,tenant_id,lead_id,art,am,text,erfasst_von,created_at) VALUES(?,?,?,?,?,?,?,?)')
      .bind(id('sak_'),tenantId,v.id,'angebot',ts.slice(0,10),'Angebot zugeordnet',auth.userId,ts),
  ]);
  return{offer_id:a.id};
}

/**
 * Den Vorgang gewinnen - nur mit angenommenem Angebot.
 *
 * Das ist die Regel, die die Statistik traegt. Ohne sie misst sie die Zuversicht des Vertriebs
 * und nicht den Umsatz des Hauses.
 */
export async function gewinneVorgang(env:Env,auth:CoreAuthContext,tenantId:string,leadId:string){
  requireRole(auth,'tenant_admin');
  const v=await ladeVorgang(env,tenantId,leadId);
  if(v.stufe==='gewonnen')throw new Error('VERTRIEB_VORGANG_ABGESCHLOSSEN');
  if(!v.offer_id)throw new Error('VERTRIEB_GEWONNEN_NUR_UEBER_ANGEBOT');
  const a=await env.DB.prepare('SELECT status,preis_je_teilnehmer_cent,plaetze FROM course_offers WHERE tenant_id=? AND id=?')
    .bind(tenantId,String(v.offer_id)).first<{status:string;preis_je_teilnehmer_cent:number;plaetze:number}>();
  if(a?.status!=='angenommen')throw new Error('VERTRIEB_ANGEBOT_NICHT_ANGENOMMEN');
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare(`UPDATE sales_leads SET stufe='gewonnen',entschieden_am=?,wiedervorlage_am=NULL,naechster_schritt=NULL,
      erwarteter_wert_cent=?,updated_at=? WHERE tenant_id=? AND id=?`)
      .bind(ts,Number(a.preis_je_teilnehmer_cent)*Number(a.plaetze),ts,tenantId,v.id),
    env.DB.prepare('INSERT INTO sales_activities(id,tenant_id,lead_id,art,am,text,erfasst_von,created_at) VALUES(?,?,?,?,?,?,?,?)')
      .bind(id('sak_'),tenantId,v.id,'notiz',ts.slice(0,10),'Gewonnen: Angebot angenommen',auth.userId,ts),
  ]);
  await audit(env.DB,auth.userId,'sales.lead.won',tenantId,undefined,'sales_lead',String(v.id),{offer_id:v.offer_id});
  return{stufe:'gewonnen',wert_cent:Number(a.preis_je_teilnehmer_cent)*Number(a.plaetze)};
}

export async function vorgangsmappe(env:Env,auth:CoreAuthContext,tenantId:string,leadId?:string){
  requireRole(auth,'tenant_admin');
  if(leadId){
    const v=await ladeVorgang(env,tenantId,leadId);
    const [aktivitaeten,organisation]=await Promise.all([
      env.DB.prepare('SELECT * FROM sales_activities WHERE tenant_id=? AND lead_id=? ORDER BY am DESC,created_at DESC LIMIT 100').bind(tenantId,v.id).all<Record<string,unknown>>(),
      env.DB.prepare('SELECT id,name,art,ort FROM sales_accounts WHERE id=?').bind(v.account_id).first<Record<string,unknown>>(),
    ]);
    return{vorgang:v,organisation:organisation??null,aktivitaeten:aktivitaeten.results??[]};
  }
  const heute=nowIso().slice(0,10);
  const liste=((await env.DB.prepare(`SELECT l.*,a.name organisation,a.art organisation_art
    FROM sales_leads l JOIN sales_accounts a ON a.id=l.account_id
    WHERE l.tenant_id=? ORDER BY CASE WHEN l.stufe IN ('gewonnen','verloren') THEN 1 ELSE 0 END,l.wiedervorlage_am LIMIT 300`)
    .bind(tenantId).all<Record<string,unknown>>()).results)??[];
  return{vorgaenge:liste.map(l=>({...l,ueberfaellig:!!l.wiedervorlage_am&&String(l.wiedervorlage_am)<heute}))};
}

// ---------------------------------------------------------------------------------------------
// Nachverhandlung
// ---------------------------------------------------------------------------------------------

/**
 * Ein Angebot nachverhandeln: neue Fassung statt Ueberschreiben.
 *
 * Die alte Fassung wird zurueckgezogen und bleibt lesbar. Was urspruenglich angeboten wurde, ist
 * genau die Frage, die im Streit gestellt wird - und "steht nicht mehr drin" ist keine Antwort.
 * Die Anlagen gehen mit: sie neu beizulegen waere der Schritt, den jemand vergisst.
 */
export async function verhandleAngebot(env:Env,auth:CoreAuthContext,tenantId:string,offerId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const a=await env.DB.prepare('SELECT * FROM course_offers WHERE tenant_id=? AND id=?')
    .bind(tenantId,clean(offerId,120)).first<Record<string,unknown>>();
  if(!a)throw new Error('VERTRIEB_ANGEBOT_NICHT_GEFUNDEN');
  if(a.status==='angenommen')throw new Error('ANGEBOT_SCHON_ANGENOMMEN');
  if(a.status==='zurueckgezogen')throw new Error('ANGEBOT_ZURUECKGEZOGEN');
  const grund=clean(eingabe.verhandlungsgrund,1000);
  if(grund.length<10)throw new Error('VERTRIEB_VERHANDLUNGSGRUND_ERFORDERLICH');
  const preis=eingabe.preis_je_teilnehmer_cent===undefined?Number(a.preis_je_teilnehmer_cent):Math.trunc(Number(eingabe.preis_je_teilnehmer_cent));
  if(!Number.isFinite(preis)||preis<0)throw new Error('ANGEBOT_PREIS_UNGUELTIG');
  const plaetze=eingabe.plaetze===undefined?Number(a.plaetze):Math.trunc(Number(eingabe.plaetze));
  if(!Number.isFinite(plaetze)||plaetze<1||plaetze>500)throw new Error('ANGEBOT_PLAETZE_UNGUELTIG');
  const gueltig=eingabe.gueltig_bis?datum(eingabe.gueltig_bis,'FRIST'):String(a.gueltig_bis);
  // Die neue Fassung bekommt eine EIGENE laufende Nummer. Das ist nicht nur eine Folge der
  // Eindeutigkeit in der Ablage, sondern auch kaufmaennisch richtig: ein geaendertes Angebot geht
  // unter neuer Nummer hinaus und nennt das alte ("ersetzt unser Angebot 12"). Zwei Schreiben mit
  // derselben Nummer und verschiedenen Preisen sind genau die Verwechslung, die im Streit teuer
  // wird. Verbunden bleiben sie ueber vorgaenger_id.
  const neuId=id('ang_'),ts=nowIso();
  await env.DB.batch([
    env.DB.prepare(`INSERT INTO course_offers(id,tenant_id,course_id,nummer,kostentraeger_art,kostentraeger_name,ansprechpartner,empfaenger_email,aktenzeichen,massnahmenummer,preis_je_teilnehmer_cent,plaetze,plan_json,plan_pruefsumme,gueltig_bis,status,erstellt_von,created_at,updated_at,vorgaenger_id,fassung,verhandlungsgrund)
      SELECT ?,?,?,COALESCE(MAX(nummer),0)+1,?,?,?,?,?,?,?,?,?,?,?,'entwurf',?,?,?,?,?,? FROM course_offers WHERE tenant_id=?`)
      .bind(neuId,tenantId,a.course_id,a.kostentraeger_art,a.kostentraeger_name,a.ansprechpartner,a.empfaenger_email,
        a.aktenzeichen,a.massnahmenummer,preis,plaetze,a.plan_json,a.plan_pruefsumme,gueltig,auth.userId,ts,ts,
        a.id,Number(a.fassung??1)+1,grund,tenantId),
    // Die Anlagen der Vorfassung gehen mit.
    env.DB.prepare(`INSERT INTO course_offer_attachments(id,tenant_id,offer_id,art,titel,inhalt_json,media_asset_id,abgeleitet,created_at)
      SELECT lower(hex(randomblob(16))),tenant_id,?,art,titel,inhalt_json,media_asset_id,abgeleitet,? FROM course_offer_attachments WHERE offer_id=?`)
      .bind(neuId,ts,a.id),
    env.DB.prepare("UPDATE course_offers SET status='zurueckgezogen',updated_at=? WHERE tenant_id=? AND id=?").bind(ts,tenantId,a.id),
    // Der Vorgang zeigt ab jetzt auf die neue Fassung und steht in der Verhandlung.
    env.DB.prepare("UPDATE sales_leads SET offer_id=?,stufe='verhandlung',updated_at=? WHERE tenant_id=? AND offer_id=?")
      .bind(neuId,ts,tenantId,a.id),
  ]);
  await audit(env.DB,auth.userId,'course_offer.renegotiated',tenantId,String(a.course_id),'course_offer',neuId,
    {vorgaenger:String(a.id),fassung:Number(a.fassung??1)+1});
  const neu=await env.DB.prepare('SELECT nummer FROM course_offers WHERE id=?').bind(neuId).first<{nummer:number}>();
  return{id:neuId,fassung:Number(a.fassung??1)+1,nummer:Number(neu?.nummer??0),ersetzt_nummer:Number(a.nummer),
    summe_cent:preis*plaetze,vorgaenger_id:String(a.id)};
}

/** Alle Fassungen eines Angebots - aelteste zuerst. */
export async function angebotsfassungen(env:Env,auth:CoreAuthContext,tenantId:string,offerId:string){
  requireRole(auth,'tenant_admin');
  const kette=((await env.DB.prepare(`WITH RECURSIVE f(id) AS (
      SELECT id FROM course_offers WHERE tenant_id=?1 AND id=?2
      UNION SELECT o.id FROM course_offers o JOIN f ON o.vorgaenger_id=f.id OR o.id=(SELECT vorgaenger_id FROM course_offers WHERE id=f.id)
    ) SELECT o.id,o.fassung,o.status,o.preis_je_teilnehmer_cent,o.plaetze,o.gueltig_bis,o.verhandlungsgrund,o.created_at
      FROM course_offers o JOIN f ON f.id=o.id ORDER BY o.fassung`)
    .bind(tenantId,clean(offerId,120)).all<Record<string,unknown>>()).results)??[];
  return kette.map(f=>({...f,summe_cent:Number(f.preis_je_teilnehmer_cent)*Number(f.plaetze)}));
}

// ---------------------------------------------------------------------------------------------
// Auswertung
// ---------------------------------------------------------------------------------------------

/**
 * Der Trichter eines Zeitraums - gerechnet, nicht gepflegt.
 *
 * Dieselbe Regel wie beim Qualitaetsmanagement: eine Zahl, die jemand eintraegt, misst die
 * Zuversicht dessen, der sie eingetragen hat.
 */
export async function vertriebsauswertung(env:Env,auth:CoreAuthContext,tenantId:string,von:string,bis:string){
  requireRole(auth,'tenant_admin');
  const a=datum(von,'VON'),b=datum(bis,'BIS');
  const trichter=await env.DB.prepare(`SELECT
      COUNT(*) vorgaenge,
      SUM(CASE WHEN offer_id IS NOT NULL THEN 1 ELSE 0 END) mit_angebot,
      SUM(CASE WHEN stufe='gewonnen' THEN 1 ELSE 0 END) gewonnen,
      SUM(CASE WHEN stufe='verloren' THEN 1 ELSE 0 END) verloren,
      SUM(CASE WHEN stufe='gewonnen' THEN COALESCE(erwarteter_wert_cent,0) ELSE 0 END) gewonnen_cent,
      SUM(CASE WHEN stufe NOT IN ('gewonnen','verloren') THEN COALESCE(erwarteter_wert_cent,0) ELSE 0 END) offen_cent
    FROM sales_leads WHERE tenant_id=? AND created_at>=? AND created_at<=?`)
    .bind(tenantId,`${a}T00:00:00.000Z`,`${b}T23:59:59.999Z`).first<Record<string,unknown>>();
  const gruende=((await env.DB.prepare(`SELECT verloren_grund grund,COUNT(*) anzahl FROM sales_leads
    WHERE tenant_id=? AND stufe='verloren' AND created_at>=? AND created_at<=? GROUP BY verloren_grund ORDER BY anzahl DESC`)
    .bind(tenantId,`${a}T00:00:00.000Z`,`${b}T23:59:59.999Z`).all<{grund:string;anzahl:number}>()).results)??[];
  const quellen=((await env.DB.prepare(`SELECT COALESCE(o.quelle,'sonstige') quelle,COUNT(*) anzahl,
      SUM(CASE WHEN l.stufe='gewonnen' THEN 1 ELSE 0 END) gewonnen
    FROM sales_leads l JOIN sales_accounts o ON o.id=l.account_id
    WHERE l.tenant_id=? AND l.created_at>=? AND l.created_at<=? GROUP BY COALESCE(o.quelle,'sonstige') ORDER BY anzahl DESC`)
    .bind(tenantId,`${a}T00:00:00.000Z`,`${b}T23:59:59.999Z`).all<Record<string,unknown>>()).results)??[];
  const vorgaenge=Number(trichter?.vorgaenge??0),gewonnen=Number(trichter?.gewonnen??0);
  const entschieden=gewonnen+Number(trichter?.verloren??0);
  return{von:a,bis:b,
    vorgaenge,mit_angebot:Number(trichter?.mit_angebot??0),gewonnen,verloren:Number(trichter?.verloren??0),
    offen:vorgaenge-entschieden,
    gewonnen_cent:Number(trichter?.gewonnen_cent??0),offen_cent:Number(trichter?.offen_cent??0),
    // Die Quote rechnet auf die ENTSCHIEDENEN. Auf alle Vorgaenge gerechnet waere sie bei vollem
    // Trichter immer schlecht - und sagt dann nichts ueber die Arbeit, sondern ueber den Zeitpunkt.
    gewinnquote:entschieden>0?Math.round(gewonnen/entschieden*1000)/10:null,
    angebotsquote:vorgaenge>0?Math.round(Number(trichter?.mit_angebot??0)/vorgaenge*1000)/10:null,
    verlustgruende:gruende,quellen};
}

/** Faellige Wiedervorlagen - der taegliche Lauf. */
export async function erinnereAnWiedervorlagen(env:Env,grenze=30,heute=nowIso().slice(0,10)){
  const ts=nowIso();
  const faellig=((await env.DB.prepare(`SELECT l.id,l.tenant_id,l.bezeichnung,l.wiedervorlage_am,l.naechster_schritt,l.verantwortlich,a.name organisation
    FROM sales_leads l JOIN sales_accounts a ON a.id=l.account_id
    WHERE l.stufe NOT IN ('gewonnen','verloren') AND l.wiedervorlage_am IS NOT NULL AND l.wiedervorlage_am<=?
      AND (l.erinnert_am IS NULL OR l.erinnert_am<?)
    ORDER BY l.wiedervorlage_am LIMIT ?`)
    .bind(heute,`${heute}T00:00:00.000Z`,Math.max(1,Math.min(100,grenze)))
    .all<{id:string;tenant_id:string;bezeichnung:string;wiedervorlage_am:string;naechster_schritt:string|null;verantwortlich:string|null;organisation:string}>()).results)??[];
  for(const f of faellig){
    await env.DB.batch([
      env.DB.prepare('INSERT INTO automation_events(id,tenant_id,event_type,source_type,source_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)')
        .bind(id('aev_'),f.tenant_id,'sales.lead.due','sales_lead',f.id,
          JSON.stringify({bezeichnung:f.bezeichnung,organisation:f.organisation,schritt:f.naechster_schritt,fuer:f.verantwortlich}),ts),
      env.DB.prepare('UPDATE sales_leads SET erinnert_am=? WHERE id=?').bind(ts,f.id),
    ]);
  }
  return{faellig:faellig.length};
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Pruefungs-Notfallbetrieb (P3): Unterbrechung, Wiederaufnahme, Ergebnisabgleich.
//
// Netz weg, Strom weg, Feueralarm. Ohne geregelte Unterbrechung gibt es zwei schlechte Antworten:
// die Uhr laeuft weiter - dann ist die Pruefung anfechtbar, und zwar zu Recht. Oder der Versuch
// wird verworfen - dann muessen alle noch einmal antreten, auch die, die schon fertig waren.
//
// Richtig ist: anhalten, Restzeit festschreiben, fortsetzen. Und beim Fortsetzen die Antworten
// abgleichen, statt eine Seite still zu ueberschreiben: der Rechner der teilnehmenden Person kann
// Antworten haben, die der Server nie gesehen hat - genau deshalb wurde ja unterbrochen.

export const ARTEN=['netz','strom','technik','raeumung','gesundheit','sonstiges'] as const;
const clean=(v:unknown,n=2000)=>safeString(v,n);

export type Abgleich={frage_id:string;server:string|null;geraet:string|null;uebernommen:'server'|'geraet'|'konflikt'};

function restsekunden(deadline:string|null,jetzt:string):number{
  if(!deadline)return 0;
  const rest=Math.floor((Date.parse(deadline)-Date.parse(jetzt))/1000);
  return Math.max(0,Number.isFinite(rest)?rest:0);
}

/**
 * Unterbrechen. Die Restzeit wird eingefroren - ohne sie waere jede Fortsetzung entweder ein
 * Geschenk oder ein Nachteil, und beides ist anfechtbar.
 */
export async function unterbrichVersuch(env:Env,auth:CoreAuthContext,tenantId:string,attemptId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const art=clean(input.art,20),begruendung=clean(input.begruendung,2000);
  if(!ARTEN.includes(art as never))throw new Error('UNTERBRECHUNG_ART_UNGUELTIG');
  if(begruendung.length<10)throw new Error('UNTERBRECHUNG_BEGRUENDUNG_ERFORDERLICH');
  const versuch=await env.DB.prepare('SELECT id,course_id,quiz_id,status,deadline_at FROM quiz_attempts WHERE id=? AND tenant_id=?')
    .bind(attemptId,tenantId).first<{id:string;course_id:string;quiz_id:string;status:string;deadline_at:string|null}>();
  if(!versuch)throw new Error('VERSUCH_NICHT_GEFUNDEN');
  if(versuch.status!=='in_progress')throw new Error('VERSUCH_NICHT_LAUFEND');
  const laufend=await env.DB.prepare('SELECT id FROM exam_interruptions WHERE attempt_id=? AND fortgesetzt_am IS NULL').bind(attemptId).first();
  if(laufend)throw new Error('UNTERBRECHUNG_BEREITS_AKTIV');
  const ts=nowIso(),rest=restsekunden(versuch.deadline_at,ts),uid=id('unt_');
  // Die Frist wird entfernt, solange die Unterbrechung laeuft: eine Frist, die waehrend einer
  // Raeumung weiterlaeuft, ist genau der Fehler, den dieses Modul verhindern soll.
  await env.DB.batch([
    env.DB.prepare('INSERT INTO exam_interruptions(id,tenant_id,attempt_id,art,begruendung,restsekunden,unterbrochen_von,unterbrochen_am,updated_at) VALUES(?,?,?,?,?,?,?,?,?)')
      .bind(uid,tenantId,attemptId,art,begruendung,rest,auth.userId,ts,ts),
    env.DB.prepare('UPDATE quiz_attempts SET deadline_at=NULL WHERE id=? AND tenant_id=?').bind(attemptId,tenantId),
  ]);
  await audit(env.DB,auth.userId,'exam.interrupted',tenantId,versuch.course_id,'quiz_attempt',attemptId,{art,restsekunden:rest});
  return{id:uid,restsekunden:rest};
}

/**
 * Fortsetzen. Die eingefrorene Restzeit wird ab JETZT neu gerechnet - nicht ab dem urspruenglichen
 * Ende. Wer 20 Minuten uebrig hatte, hat wieder 20 Minuten.
 */
export async function setzeVersuchFort(env:Env,auth:CoreAuthContext,tenantId:string,attemptId:string,abgleich?:Abgleich[]){
  requireRole(auth,'class_admin');
  const unterbrechung=await env.DB.prepare('SELECT id,restsekunden FROM exam_interruptions WHERE attempt_id=? AND fortgesetzt_am IS NULL ORDER BY unterbrochen_am DESC LIMIT 1')
    .bind(attemptId).first<{id:string;restsekunden:number}>();
  if(!unterbrechung)throw new Error('UNTERBRECHUNG_NICHT_AKTIV');
  const versuch=await env.DB.prepare('SELECT course_id,status FROM quiz_attempts WHERE id=? AND tenant_id=?').bind(attemptId,tenantId).first<{course_id:string;status:string}>();
  if(!versuch)throw new Error('VERSUCH_NICHT_GEFUNDEN');
  const ts=nowIso(),neueFrist=new Date(Date.parse(ts)+Number(unterbrechung.restsekunden)*1000).toISOString();
  await env.DB.batch([
    env.DB.prepare('UPDATE exam_interruptions SET fortgesetzt_von=?,fortgesetzt_am=?,abgleich_json=?,updated_at=? WHERE id=?')
      .bind(auth.userId,ts,abgleich?JSON.stringify(abgleich):null,ts,unterbrechung.id),
    env.DB.prepare("UPDATE quiz_attempts SET deadline_at=?,status='in_progress' WHERE id=? AND tenant_id=?").bind(neueFrist,attemptId,tenantId),
  ]);
  await audit(env.DB,auth.userId,'exam.resumed',tenantId,versuch.course_id,'quiz_attempt',attemptId,{restsekunden:Number(unterbrechung.restsekunden)});
  return{deadline_at:neueFrist,restsekunden:Number(unterbrechung.restsekunden)};
}

/**
 * Ergebnisabgleich: was der Server hat gegen das, was auf dem Geraet lag.
 *
 * Es wird NICHTS still uebernommen. Fehlt eine Antwort auf dem Server, wird die vom Geraet
 * vorgeschlagen; weichen beide voneinander ab, ist es ein Konflikt, den ein Mensch entscheidet.
 * Automatisch die neuere zu nehmen waere bequem und im Streitfall nicht haltbar.
 */
export async function gleicheErgebnisAb(env:Env,auth:CoreAuthContext,tenantId:string,attemptId:string,vomGeraet:{frage_id:string;antwort:string}[]):Promise<{abgleich:Abgleich[];konflikte:number;fehlend:number}>{
  requireRole(auth,'class_admin');
  const versuch=await env.DB.prepare('SELECT id FROM quiz_attempts WHERE id=? AND tenant_id=?').bind(attemptId,tenantId).first();
  if(!versuch)throw new Error('VERSUCH_NICHT_GEFUNDEN');
  const serverAntworten=((await env.DB.prepare('SELECT question_id,answer_json FROM quiz_answers WHERE attempt_id=?').bind(attemptId).all<{question_id:string;answer_json:string|null}>()).results)??[];
  const karte=new Map(serverAntworten.map(a=>[String(a.question_id),a.answer_json===null?null:String(a.answer_json)]));
  const abgleich:Abgleich[]=[];
  for(const g of vomGeraet??[]){
    const server=karte.get(String(g.frage_id))??null,geraet=String(g.antwort??'');
    if(server===null)abgleich.push({frage_id:String(g.frage_id),server:null,geraet,uebernommen:'geraet'});
    else if(server===geraet)abgleich.push({frage_id:String(g.frage_id),server,geraet,uebernommen:'server'});
    else abgleich.push({frage_id:String(g.frage_id),server,geraet,uebernommen:'konflikt'});
  }
  return{abgleich,konflikte:abgleich.filter(a=>a.uebernommen==='konflikt').length,fehlend:abgleich.filter(a=>a.uebernommen==='geraet').length};
}

export async function unterbrechungen(env:Env,auth:CoreAuthContext,tenantId:string,attemptId:string){
  requireRole(auth,'class_admin');
  return ((await env.DB.prepare('SELECT id,art,begruendung,restsekunden,unterbrochen_von,unterbrochen_am,fortgesetzt_von,fortgesetzt_am,abgleich_json FROM exam_interruptions WHERE attempt_id=? AND tenant_id=? ORDER BY unterbrochen_am')
    .bind(attemptId,tenantId).all()).results)??[];
}

/**
 * Alle laufenden Unterbrechungen eines Kurses - fuer die Aufsicht im Raum, die wissen muss, wer
 * noch angehalten ist.
 */
export async function offeneUnterbrechungen(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  requireRole(auth,'class_admin');
  return ((await env.DB.prepare('SELECT i.id,i.attempt_id,i.art,i.restsekunden,i.unterbrochen_am,a.user_id,u.display_name FROM exam_interruptions i JOIN quiz_attempts a ON a.id=i.attempt_id JOIN users u ON u.id=a.user_id WHERE i.tenant_id=? AND a.course_id=? AND i.fortgesetzt_am IS NULL ORDER BY i.unterbrochen_am')
    .bind(tenantId,courseId).all()).results)??[];
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { hasPermission } from './enterprise-access.js';
import { stapelSchreiben } from './learning-operations.js';
import { id, nowIso, safeString } from './utils.js';

// Unterrichtsrhythmen (Master-Spec V2, Block "Planung und Zeit", Luecke Z5).
//
// Die Planung kannte bisher genau eine Form: eine Einheit mit Anfang und Ende. Blockunterricht,
// Doppelstunden, Schicht- und Randzeiten und Praxisphasen wurden daraus nachgebaut, indem man
// mehrere Einheiten hintereinanderlegte. Was dabei verlorenging, ist nicht die Zeit, sondern die
// AUSSAGE:
//
//   * Ein Block ist nicht dasselbe wie zwei Einzelstunden hintereinander. Wer die zweite Haelfte
//     in einen anderen Raum oder auf eine andere Lehrkraft schiebt, hat den Block zerschnitten -
//     und nichts im System sagte es. Die Pause INNERHALB des Blocks ist ebenfalls keine Luecke.
//   * Eine Praxisphase ist eine Abwesenheit vom Unterricht, keine Luecke. Ohne diesen Unterschied
//     meldet jede Auswertung die drei Wochen im Betrieb als den schlechtesten Abschnitt des
//     Schuljahres - und die Planung versucht, sie "aufzufuellen".
//   * Schicht- und Randzeiten sind die vereinbarte Regel eines Bildungsgangs, keine Ausnahme.
//
// Dieses Modul haelt die Regeln, erzeugt daraus Termine (gestapelt, nicht einzeln) und liefert die
// Befunde. Die Befundrechnung ist bewusst eine REINE Funktion ueber bereits geladene Termine:
// dieselbe Rechnung wird in der Planpruefung und in der Planbewertung gebraucht, und keine der
// beiden darf dafuer noch einmal in die Datenbank greifen.

export const RHYTHMEN=['block','doppelstunde','schicht_frueh','schicht_spaet','randzeit','praxisphase'] as const;
export type Rhythmus=typeof RHYTHMEN[number];
const AKTIVITAETSARTEN=['classroom','live_remote','hybrid_live','self_study_home','self_study_school','self_study_other','excursion','project','workshop','exam','practice','other'] as const;
const RHYTHMUS_MAX_TERMINE=600;

export type Rhythmusregel={
  id:string;tenant_id:string;course_id:string|null;name:string;rhythmus:Rhythmus;
  einheit_minuten:number;einheiten_je_block:number;pause_im_block_minuten:number;
  frueheste_zeit:string|null;spaeteste_zeit:string|null;wochentage_json:string;tage_am_stueck:number;
  zaehlt_als_unterricht:number;anwesenheit_erwartet:number;aktivitaetsart:string;status:string;
};
export type Rhythmusbefund={entry_id:string;type:'rhythm_block_split'|'rhythm_window'|'rhythm_practice_overlap';severity:'warning'|'error';message:string;other_id?:string|null};
export type Rhythmustermin={id:string;starts_at:string;ends_at:string;course_id:string;teacher_id?:string|null;room?:string|null;activity_type?:string|null;rhythm_rule_id?:string|null;rhythm_group?:string|null;rhythm_position?:number|null};

function admin(auth:CoreAuthContext){return auth.isPlatformAdmin||auth.role==='tenant_admin';}
function requireManage(auth:CoreAuthContext){if(!admin(auth)&&!hasPermission(auth,'courses.manage'))throw new Error('FORBIDDEN_PLANNING_MANAGE');}
function courseScope(auth:CoreAuthContext,courseId:string){if(!admin(auth)&&!auth.courseIds.includes(courseId))throw new Error('FORBIDDEN_COURSE_SCOPE');}
function pflicht(v:unknown,max=300){const s=safeString(v,max);if(!s)throw new Error('FIELD_REQUIRED');return s;}
function frei(v:unknown,max=2000){return safeString(v,max)||null;}
function zeit(v:unknown){const s=safeString(v,5);if(!s)return null;if(!/^\d\d:\d\d$/.test(s))throw new Error('RHYTHM_TIME_INVALID');return s;}
function ganzzahl(v:unknown,min:number,max:number,fallback:number,fehler:string){if(v===null||v===undefined||v==='')return fallback;const n=Math.trunc(Number(v));if(!Number.isFinite(n)||n<min||n>max)throw new Error(fehler);return n;}
function tagSchluessel(v:string){return String(v).slice(0,10);}
function uhrzeit(v:string){return String(v).slice(11,16);}
function minuten(a:string,b:string){return Math.max(0,Math.round((Date.parse(b)-Date.parse(a))/60000));}
function ueberlappt(aVon:string,aBis:string,bVon:string,bBis:string){return aVon<bBis&&bVon<aBis;}
export function wochentagVon(iso:string){const d=new Date(iso);if(Number.isNaN(d.getTime()))throw new Error('DATE_INVALID');return((d.getUTCDay()+6)%7)+1;}

export function wochentage(regel:{wochentage_json?:unknown}):number[]{
  try{
    const roh=JSON.parse(String(regel.wochentage_json??'[]'));
    if(!Array.isArray(roh))return[1,2,3,4,5];
    const tage=[...new Set(roh.map(Number).filter(n=>Number.isInteger(n)&&n>=1&&n<=7))].sort((a,b)=>a-b);
    return tage.length?tage:[1,2,3,4,5];
  }catch{return[1,2,3,4,5];}
}

/** Ein Termin, der Zeit belegt, ohne Unterricht zu sein - die Praxisphase ist der Regelfall. */
export function istAbwesenheitVomUnterricht(termin:{activity_type?:string|null;rhythm_rule_id?:string|null},regeln:Map<string,Rhythmusregel>){
  const regel=termin.rhythm_rule_id?regeln.get(String(termin.rhythm_rule_id)):undefined;
  if(regel)return Number(regel.zaehlt_als_unterricht)===0;
  return String(termin.activity_type||'')==='practice';
}

// ---------------------------------------------------------------------------------------------
// Regelpflege
// ---------------------------------------------------------------------------------------------

export async function listRhythmRules(env:Env,auth:CoreAuthContext,tenantId:string){
  requireManage(auth);
  return(await env.DB.prepare('SELECT r.*,c.name course_name,(SELECT COUNT(*) FROM timetable_plan_entries e WHERE e.tenant_id=r.tenant_id AND e.rhythm_rule_id=r.id) termine FROM teaching_rhythm_rules r LEFT JOIN courses c ON c.id=r.course_id AND c.tenant_id=r.tenant_id WHERE r.tenant_id=? ORDER BY r.status,r.name LIMIT 500').bind(tenantId).all<Record<string,unknown>>()).results??[];
}

export async function saveRhythmRule(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireManage(auth);
  const regelId=frei(input.id,120)||id('trr_'),name=pflicht(input.name,300);
  const rhythmus=String(input.rhythmus||'block');
  if(!RHYTHMEN.includes(rhythmus as Rhythmus))throw new Error('RHYTHM_KIND_INVALID');
  const courseId=frei(input.course_id,120);
  if(courseId)courseScope(auth,courseId);
  const einheit=ganzzahl(input.einheit_minuten,5,720,45,'RHYTHM_UNITS_INVALID');
  const einheiten=ganzzahl(input.einheiten_je_block,1,12,rhythmus==='doppelstunde'?2:1,'RHYTHM_UNITS_INVALID');
  if(rhythmus==='doppelstunde'&&einheiten!==2)throw new Error('RHYTHM_UNITS_INVALID');
  const pause=ganzzahl(input.pause_im_block_minuten,0,180,0,'RHYTHM_UNITS_INVALID');
  const tage=ganzzahl(input.tage_am_stueck,1,120,1,'RHYTHM_UNITS_INVALID');
  const von=zeit(input.frueheste_zeit),bis=zeit(input.spaeteste_zeit);
  if(von&&bis&&von>=bis)throw new Error('RHYTHM_TIME_INVALID');
  const roh=Array.isArray(input.wochentage)?input.wochentage:JSON.parse(String(input.wochentage_json||'[1,2,3,4,5]'));
  const tageDerWoche=[...new Set((Array.isArray(roh)?roh:[]).map(Number).filter(n=>Number.isInteger(n)&&n>=1&&n<=7))].sort((a,b)=>a-b);
  if(!tageDerWoche.length)throw new Error('RHYTHM_WEEKDAY_INVALID');
  // Die Praxisphase ist der einzige Rhythmus, der von sich aus KEIN Unterricht ist. Wer das frei
  // waehlbar machte, koennte jede Unterrichtsstunde per Haekchen aus der Auswertung nehmen.
  const zaehlt=rhythmus==='praxisphase'?0:1;
  const anwesenheit=rhythmus==='praxisphase'?0:(input.anwesenheit_erwartet===false||input.anwesenheit_erwartet===0?0:1);
  const art=rhythmus==='praxisphase'?'practice':String(input.aktivitaetsart||'classroom');
  if(!AKTIVITAETSARTEN.includes(art as never))throw new Error('RHYTHM_KIND_INVALID');
  const status=String(input.status||'active');
  if(!['active','inactive'].includes(status))throw new Error('RHYTHM_KIND_INVALID');
  const ts=nowIso();
  const vorhanden=await env.DB.prepare('SELECT 1 ok FROM teaching_rhythm_rules WHERE tenant_id=? AND id=?').bind(tenantId,regelId).first();
  const doppelt=await env.DB.prepare('SELECT 1 ok FROM teaching_rhythm_rules WHERE tenant_id=? AND lower(trim(name))=lower(trim(?)) AND id<>? LIMIT 1').bind(tenantId,name,regelId).first();
  if(doppelt)throw new Error('RHYTHM_NAME_EXISTS');
  if(vorhanden)await env.DB.prepare('UPDATE teaching_rhythm_rules SET course_id=?,name=?,rhythmus=?,einheit_minuten=?,einheiten_je_block=?,pause_im_block_minuten=?,frueheste_zeit=?,spaeteste_zeit=?,wochentage_json=?,tage_am_stueck=?,zaehlt_als_unterricht=?,anwesenheit_erwartet=?,aktivitaetsart=?,status=?,notiz=?,updated_at=? WHERE tenant_id=? AND id=?').bind(courseId,name,rhythmus,einheit,einheiten,pause,von,bis,JSON.stringify(tageDerWoche),tage,zaehlt,anwesenheit,art,status,frei(input.notiz,2000),ts,tenantId,regelId).run();
  else await env.DB.prepare('INSERT INTO teaching_rhythm_rules(id,tenant_id,course_id,name,rhythmus,einheit_minuten,einheiten_je_block,pause_im_block_minuten,frueheste_zeit,spaeteste_zeit,wochentage_json,tage_am_stueck,zaehlt_als_unterricht,anwesenheit_erwartet,aktivitaetsart,status,notiz,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(regelId,tenantId,courseId,name,rhythmus,einheit,einheiten,pause,von,bis,JSON.stringify(tageDerWoche),tage,zaehlt,anwesenheit,art,status,frei(input.notiz,2000),auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'planning.rhythm_rule_saved',tenantId,courseId||undefined,'teaching_rhythm_rule',regelId,{rhythmus,einheiten,status});
  return{rule_id:regelId};
}

export async function deleteRhythmRule(env:Env,auth:CoreAuthContext,tenantId:string,ruleId:string){
  requireManage(auth);
  const regel=await env.DB.prepare('SELECT course_id FROM teaching_rhythm_rules WHERE tenant_id=? AND id=?').bind(tenantId,ruleId).first<{course_id:string|null}>();
  if(!regel)throw new Error('RHYTHM_RULE_NOT_FOUND');
  // Eine Regel zu loeschen, an der Termine haengen, liesse Bloecke ohne ihre Klammer zurueck: der
  // Plan saehe unveraendert aus, und niemand koennte mehr sagen, welche Termine zusammengehoeren.
  const benutzt=Number((await env.DB.prepare('SELECT COUNT(*) n FROM timetable_plan_entries WHERE tenant_id=? AND rhythm_rule_id=?').bind(tenantId,ruleId).first<{n:number}>())?.n||0);
  if(benutzt)throw new Error('RHYTHM_RULE_IN_USE');
  await env.DB.prepare('DELETE FROM teaching_rhythm_rules WHERE tenant_id=? AND id=?').bind(tenantId,ruleId).run();
  await audit(env.DB,auth.userId,'planning.rhythm_rule_removed',tenantId,regel.course_id||undefined,'teaching_rhythm_rule',ruleId,{});
  return{rule_id:ruleId};
}

// ---------------------------------------------------------------------------------------------
// Termine aus einem Rhythmus erzeugen
// ---------------------------------------------------------------------------------------------

/**
 * Legt die Termine EINES Rhythmus in einem Entwurf an.
 *
 * Ein Block entsteht als GRUPPE: alle seine Einheiten tragen dieselbe Gruppenkennung und ihre
 * Position darin. Erst dadurch laesst sich spaeter sagen, dass jemand ihn zerschnitten hat.
 *
 * Eine Praxisphase entsteht als Tagesreihe ueber 'tage_am_stueck' Kalendertage - mit erwarteter
 * Abwesenheit vom Unterricht statt erwarteter Anwesenheit.
 *
 * Geschrieben wird gestapelt: ein Schuljahr mit 400 Terminen kostet so acht Unteranfragen statt
 * vierhundert.
 */
export async function applyRhythmToPlan(env:Env,auth:CoreAuthContext,tenantId:string,planId:string,input:Record<string,unknown>){
  requireManage(auth);
  const ruleId=pflicht(input.rule_id,120),courseId=pflicht(input.course_id,120);
  courseScope(auth,courseId);
  const [plan,regel,kurs]=await Promise.all([
    env.DB.prepare('SELECT starts_on,ends_on,status FROM timetable_plan_versions WHERE tenant_id=? AND id=?').bind(tenantId,planId).first<{starts_on:string;ends_on:string;status:string}>(),
    env.DB.prepare('SELECT * FROM teaching_rhythm_rules WHERE tenant_id=? AND id=?').bind(tenantId,ruleId).first<Record<string,unknown>>(),
    env.DB.prepare('SELECT 1 ok FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,courseId).first(),
  ]);
  if(!plan)throw new Error('TIMETABLE_PLAN_NOT_FOUND');
  if(plan.status==='published'||plan.status==='archived')throw new Error('RHYTHM_PLAN_LOCKED');
  if(!regel)throw new Error('RHYTHM_RULE_NOT_FOUND');
  if(!kurs)throw new Error('COURSE_NOT_FOUND');
  if(String(regel.status)!=='active')throw new Error('RHYTHM_RULE_NOT_FOUND');
  if(regel.course_id&&String(regel.course_id)!==courseId)throw new Error('RHYTHM_RULE_NOT_FOUND');
  const von=safeString(input.from,10)||String(plan.starts_on),bis=safeString(input.to,10)||String(plan.ends_on);
  if(!/^\d{4}-\d\d-\d\d$/.test(von)||!/^\d{4}-\d\d-\d\d$/.test(bis)||von>bis||von<String(plan.starts_on)||bis>String(plan.ends_on))throw new Error('RHYTHM_APPLY_RANGE_INVALID');
  const beginn=String(regel.frueheste_zeit||'08:00');
  const einheit=Number(regel.einheit_minuten)||45,einheiten=Number(regel.einheiten_je_block)||1,pause=Number(regel.pause_im_block_minuten)||0;
  const tageAmStueck=Number(regel.tage_am_stueck)||1,erlaubteTage=wochentage(regel);
  const praxis=String(regel.rhythmus)==='praxisphase';
  const [bh,bm]=beginn.split(':').map(Number);
  const ts=nowIso(),anweisungen:unknown[]=[],erzeugt:Array<{date:string;group:string}>=[];
  const teacherId=frei(input.teacher_id,120),raum=frei(input.room,300),fach=frei(input.subject_id,120),fachtext=frei(input.subject_text,300);
  const ort=frei(input.location_label,500);
  let tagOffset=0;
  for(let tag=Date.parse(`${von}T00:00:00.000Z`);tag<=Date.parse(`${bis}T00:00:00.000Z`);tag+=86400000){
    const d=new Date(tag),datum=d.toISOString().slice(0,10),dow=((d.getUTCDay()+6)%7)+1;
    if(!praxis&&!erlaubteTage.includes(dow))continue;
    if(praxis&&tagOffset%tageAmStueck!==0&&!erlaubteTage.includes(dow)){tagOffset++;continue;}
    const gruppe=id('rhg_');
    if(praxis){
      // Eine Praxisphase belegt ganze Tage. Sie bekommt trotzdem Anfang und Ende, damit sie im
      // Kalender sichtbar ist - aber keine erwartete Anwesenheit im Unterricht.
      const endeZeit=String(regel.spaeteste_zeit||'16:00');
      for(let i=0;i<tageAmStueck&&tag+i*86400000<=Date.parse(`${bis}T00:00:00.000Z`);i++){
        const t=new Date(tag+i*86400000).toISOString().slice(0,10),wtag=((new Date(`${t}T00:00:00.000Z`).getUTCDay()+6)%7)+1;
        if(!erlaubteTage.includes(wtag))continue;
        anweisungen.push(env.DB.prepare('INSERT INTO timetable_plan_entries(id,tenant_id,plan_id,course_id,subject_id,subject_text,teacher_id,teacher_text,starts_at,ends_at,room,activity_type,location_label,supervision_mode,attendance_expected,task_text,notes,source,recurrence_group,published_lesson_id,created_by,created_at,updated_at,rhythm_rule_id,rhythm_group,rhythm_position) VALUES(?,?,?,?,?,?,?,NULL,?,?,?,?,?,?,0,NULL,?,?,NULL,NULL,?,?,?,?,?,?)')
          .bind(id('tpe_'),tenantId,planId,courseId,fach,fachtext,teacherId,`${t}T${beginn}:00.000Z`,`${t}T${endeZeit}:00.000Z`,raum,'practice',ort,'external_supervisor',frei(input.notes,5000),'template',auth.userId,ts,ts,ruleId,gruppe,i+1));
        erzeugt.push({date:t,group:gruppe});
      }
      tag+=(tageAmStueck-1)*86400000;tagOffset++;
      if(erzeugt.length>RHYTHMUS_MAX_TERMINE)throw new Error('RHYTHM_APPLY_TOO_MANY');
      continue;
    }
    let start=bh*60+bm;
    for(let i=0;i<einheiten;i++){
      const ende=start+einheit;
      if(ende>=24*60)throw new Error('RHYTHM_APPLY_RANGE_INVALID');
      const hh=(m:number)=>`${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`;
      anweisungen.push(env.DB.prepare('INSERT INTO timetable_plan_entries(id,tenant_id,plan_id,course_id,subject_id,subject_text,teacher_id,teacher_text,starts_at,ends_at,room,activity_type,location_label,supervision_mode,attendance_expected,task_text,notes,source,recurrence_group,published_lesson_id,created_by,created_at,updated_at,rhythm_rule_id,rhythm_group,rhythm_position) VALUES(?,?,?,?,?,?,?,NULL,?,?,?,?,?,?,?,NULL,?,?,NULL,NULL,?,?,?,?,?,?)')
        .bind(id('tpe_'),tenantId,planId,courseId,fach,fachtext,teacherId,`${datum}T${hh(start)}:00.000Z`,`${datum}T${hh(ende)}:00.000Z`,raum,String(regel.aktivitaetsart||'classroom'),ort,'instructor',Number(regel.anwesenheit_erwartet)===0?0:1,frei(input.notes,5000),'template',auth.userId,ts,ts,ruleId,gruppe,i+1));
      erzeugt.push({date:datum,group:gruppe});
      start=ende+pause;
    }
    if(erzeugt.length>RHYTHMUS_MAX_TERMINE)throw new Error('RHYTHM_APPLY_TOO_MANY');
  }
  await stapelSchreiben(env,anweisungen);
  await audit(env.DB,auth.userId,'planning.rhythm_applied',tenantId,courseId,'timetable_plan',planId,{ruleId,rhythmus:String(regel.rhythmus),erzeugt:erzeugt.length,von,bis});
  return{plan_id:planId,rule_id:ruleId,course_id:courseId,created:erzeugt.length,groups:new Set(erzeugt.map(x=>x.group)).size,from:von,to:bis};
}

// ---------------------------------------------------------------------------------------------
// Befunde - reine Rechnung ueber bereits geladene Termine
// ---------------------------------------------------------------------------------------------

/**
 * Was an einem Rhythmus zerbrochen ist.
 *
 * Bewusst ohne Datenbankzugriff: dieselbe Rechnung wird in der Planpruefung und in der
 * Planbewertung gebraucht. Beide laden die Termine ohnehin; ein zweiter Zugriff je Termin waere
 * genau die Bauart, an der die erweiterte Pruefung schon einmal in die Unteranfragengrenze lief.
 */
export function rhythmusBefunde(termine:Rhythmustermin[],regeln:Map<string,Rhythmusregel>):Rhythmusbefund[] {
  const befunde:Rhythmusbefund[]=[];
  const gruppen=new Map<string,Rhythmustermin[]>();
  for(const t of termine){
    const g=t.rhythm_group?String(t.rhythm_group):'';
    if(!g)continue;
    const l=gruppen.get(g);if(l)l.push(t);else gruppen.set(g,[t]);
  }
  for(const [,liste] of gruppen){
    const sortiert=[...liste].sort((a,b)=>a.starts_at<b.starts_at?-1:a.starts_at>b.starts_at?1:0);
    const erster=sortiert[0],regel=erster.rhythm_rule_id?regeln.get(String(erster.rhythm_rule_id)):undefined;
    if(!regel)continue;
    if(String(regel.rhythmus)==='praxisphase')continue;
    const pause=Number(regel.pause_im_block_minuten)||0;
    if(sortiert.length<Number(regel.einheiten_je_block||1))
      befunde.push({entry_id:String(erster.id),type:'rhythm_block_split',severity:'error',message:`Der Block „${regel.name}" ist unvollständig: ${sortiert.length} von ${Number(regel.einheiten_je_block)} Einheiten sind geplant.`});
    for(let i=1;i<sortiert.length;i++){
      const vorher=sortiert[i-1],jetzt=sortiert[i];
      if(tagSchluessel(vorher.starts_at)!==tagSchluessel(jetzt.starts_at)){
        befunde.push({entry_id:String(jetzt.id),type:'rhythm_block_split',severity:'error',message:`Der Block „${regel.name}" ist auf zwei Tage verteilt. Ein Block ist eine zusammenhängende Einheit, keine Folge von Einzelstunden.`,other_id:String(vorher.id)});
        continue;
      }
      const luecke=minuten(vorher.ends_at,jetzt.starts_at);
      if(luecke>pause)befunde.push({entry_id:String(jetzt.id),type:'rhythm_block_split',severity:'error',message:`Zwischen zwei Einheiten des Blocks „${regel.name}" liegen ${luecke} Minuten; vorgesehen sind höchstens ${pause} Minuten Pause im Block.`,other_id:String(vorher.id)});
      if(String(vorher.teacher_id||'')!==String(jetzt.teacher_id||''))
        befunde.push({entry_id:String(jetzt.id),type:'rhythm_block_split',severity:'error',message:`Der Block „${regel.name}" wechselt mitten im Block die Lehrkraft.`,other_id:String(vorher.id)});
      if(String(vorher.room||'').toLowerCase()!==String(jetzt.room||'').toLowerCase())
        befunde.push({entry_id:String(jetzt.id),type:'rhythm_block_split',severity:'warning',message:`Der Block „${regel.name}" wechselt mitten im Block den Raum.`,other_id:String(vorher.id)});
    }
  }
  // Schicht- und Randzeiten: das Fenster der Regel gilt, nicht das allgemeine Kursfenster.
  for(const t of termine){
    const regel=t.rhythm_rule_id?regeln.get(String(t.rhythm_rule_id)):undefined;
    if(!regel)continue;
    if(regel.frueheste_zeit&&uhrzeit(t.starts_at)<String(regel.frueheste_zeit))
      befunde.push({entry_id:String(t.id),type:'rhythm_window',severity:'warning',message:`Beginn ${uhrzeit(t.starts_at)} liegt vor dem Zeitfenster „${regel.name}" (ab ${regel.frueheste_zeit}).`});
    if(regel.spaeteste_zeit&&uhrzeit(t.ends_at)>String(regel.spaeteste_zeit))
      befunde.push({entry_id:String(t.id),type:'rhythm_window',severity:'warning',message:`Ende ${uhrzeit(t.ends_at)} liegt nach dem Zeitfenster „${regel.name}" (bis ${regel.spaeteste_zeit}).`});
    const erlaubt=wochentage(regel);
    if(!erlaubt.includes(wochentagVon(t.starts_at)))
      befunde.push({entry_id:String(t.id),type:'rhythm_window',severity:'warning',message:`Dieser Termin liegt auf einem Wochentag, den der Rhythmus „${regel.name}" nicht vorsieht.`});
  }
  // Praxisphase und Unterricht derselben Klasse zur selben Zeit: die Person kann nicht gleichzeitig
  // im Betrieb und im Unterricht sein. Das ist kein Hinweis, das ist ein Fehler.
  const praxis=termine.filter(t=>istAbwesenheitVomUnterricht(t,regeln));
  if(praxis.length){
    const jeKursUndTag=new Map<string,Rhythmustermin[]>();
    for(const p of praxis){const k=`${p.course_id}|${tagSchluessel(p.starts_at)}`,l=jeKursUndTag.get(k);if(l)l.push(p);else jeKursUndTag.set(k,[p]);}
    for(const t of termine){
      if(istAbwesenheitVomUnterricht(t,regeln))continue;
      for(const p of jeKursUndTag.get(`${t.course_id}|${tagSchluessel(t.starts_at)}`)??[]){
        if(!ueberlappt(t.starts_at,t.ends_at,p.starts_at,p.ends_at))continue;
        befunde.push({entry_id:String(t.id),type:'rhythm_practice_overlap',severity:'error',message:'Dieser Unterricht liegt in einer Praxisphase derselben Klasse. Die Teilnehmenden sind zu dieser Zeit im Betrieb.',other_id:String(p.id)});
        break;
      }
    }
  }
  return befunde;
}

/** Die Regeln eines Mandanten als Nachschlagewerk - eine Abfrage, unabhaengig von der Terminzahl. */
export async function ladeRhythmusregeln(env:Env,tenantId:string):Promise<Map<string,Rhythmusregel>>{
  const zeilen=(await env.DB.prepare('SELECT id,tenant_id,course_id,name,rhythmus,einheit_minuten,einheiten_je_block,pause_im_block_minuten,frueheste_zeit,spaeteste_zeit,wochentage_json,tage_am_stueck,zaehlt_als_unterricht,anwesenheit_erwartet,aktivitaetsart,status FROM teaching_rhythm_rules WHERE tenant_id=? LIMIT 500').bind(tenantId).all<Record<string,unknown>>()).results??[];
  return new Map(zeilen.map(z=>[String(z.id),z as unknown as Rhythmusregel]));
}

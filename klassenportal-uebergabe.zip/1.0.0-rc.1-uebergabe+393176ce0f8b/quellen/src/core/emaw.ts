import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString, sha256Text } from './utils.js';
import { EMAW_ANWESENHEIT, EMAW_BEENDIGUNG, EMAW_MONATSTAGE, EMAW_MUSTER, EMAW_NICHTANTRITTGRUND,
  EMAW_RICHTUNG, EMAW_SCHEMA_VERSION, EMAW_VERBLEIB } from './emaw-schema.js';

// Elektronische Massnahmeabwicklung (eM@w) der Bundesagentur fuer Arbeit.
//
// Drei Dinge bestimmen die Bauart, und alle drei stehen so im Infopaket der BA:
//
//  1. DIE SCHLUESSEL KOMMEN VON DER BA. Traeger, Massnahme und Teilnehmer haben je eine
//     coSach-UUID, die der Traeger nicht vergibt, sondern aus einem Anmeldeereignis erfaehrt.
//     Ohne sie wird jedes Ereignis mit "unbekannte Schluesselkombination" abgewiesen. Deshalb
//     gibt es hier keinen Weg, ein Ereignis ohne empfangenen Schluessel zu erzeugen.
//  2. DIE RICHTUNG STEHT IM SCHEMA. Von 83 Ereignisarten darf der Traeger 24 senden; der Rest
//     kommt von der BA. Welche das sind, steht in der Dokumentation der XSD - und wird von
//     scripts/emaw-schema-ableiten.mjs daraus erzeugt, nicht abgetippt.
//  3. "NOK" IST ENDGUELTIG. Ein abgewiesenes Ereignis nimmt eM@w nicht noch einmal entgegen.
//     Der Nachfolger ist ein neues Ereignis mit neuer Ereignis-ID - kein Wiederholungsversuch.
//
// Was dieses Modul NICHT tut: hochladen. Der Zugang zum Kommunikationsserver der BA laeuft ueber
// ein Zugriffszertifikat, das auf den Provider ausgestellt ist und dessen Einsatz die
// "Vereinbarung ueber den Austausch von Daten" voraussetzt. Das Portal baut das Archiv, prueft
// es und nimmt die Quittung entgegen; wer es hochlaedt, entscheidet der Traeger.

const clean=(v:unknown,n=2000)=>safeString(v,n);
const kunr=new RegExp(`^${EMAW_MUSTER.KUNRTyp}$`);
const cosach=new RegExp(`^(?:${EMAW_MUSTER.coSachIDTyp})$`);
const zweig=new RegExp(`^${EMAW_MUSTER.TeilverfahrenTyp}$`);

/** Die Ereignisarten, die der Traeger senden darf - aus dem Schema, nicht aus dem Kopf. */
export const SENDBAR=Object.entries(EMAW_RICHTUNG).filter(([,r])=>r==='an_ba'||r==='beide').map(([a])=>a).sort();
/** Die Anmeldeereignisse, mit denen die BA die Schluesseldaten bekanntgibt. */
export const ANMELDEEREIGNISSE=['AnmeldungKontakt','AnmeldungBAE','AnmeldungBVB','AnmeldungABH',
  'AnmeldungAMP','AnmeldungREHA','SVAnmeldung','AGHAnmeldung'];

const esc=(t:string)=>t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const tag=(n:string,t:string)=>`<${n}>${esc(t)}</${n}>`;
const istTag=(v:unknown)=>/^\d{4}-\d{2}-\d{2}$/.test(String(v??''));
const datumXml=(n:string,iso:string)=>{
  const [j,m,t]=iso.split('-');
  return `<${n}>${tag('tag',String(Number(t)))}${tag('monat',String(Number(m)))}${tag('jahr',j)}</${n}>`;
};
const tageImMonat=(jahr:number,monat:number)=>new Date(Date.UTC(jahr,monat,0)).getUTCDate();
const zwei=(n:number)=>String(n).padStart(2,'0');

/** Ein Text aus einem flachen XML lesen - ohne Parser, denn im Worker gibt es keinen. */
function lies(xml:string,pfad:string):string|null{
  const m=xml.match(new RegExp(`<${pfad}>([\\s\\S]*?)</${pfad}>`));
  if(!m)return null;
  return m[1].replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&amp;/g,'&').trim();
}
function liesAlle(xml:string,pfad:string):string[]{
  return [...xml.matchAll(new RegExp(`<${pfad}>([\\s\\S]*?)</${pfad}>`,'g'))].map(m=>m[1]);
}

export async function setzeProvider(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const name=clean(input.providername,60);
  // Der Providername ist Bestandteil jedes Dateinamens und besteht laut Infopaket ausschliesslich
  // aus Kleinbuchstaben. Ein Archiv mit falschem Namen wird gar nicht erst verarbeitet.
  //
  // Hier wird bewusst NICHT stillschweigend kleingeschrieben: den Namen vergibt die BA mit dem
  // Zugriffszertifikat. Wer hier Grossbuchstaben eintippt, hat etwas anderes vor sich als das,
  // was die BA vergeben hat - und das soll auffallen, nicht repariert werden.
  if(!/^[a-z][a-z0-9]{2,59}$/.test(name))throw new Error('EMAW_PROVIDERNAME_UNGUELTIG');
  const ts=nowIso();
  await env.DB.prepare(`INSERT INTO emaw_provider(tenant_id,providername,aktiv,eigener_provider,bemerkung,angelegt_von,created_at,updated_at)
    VALUES(?,?,1,?,?,?,?,?) ON CONFLICT(tenant_id) DO UPDATE SET providername=excluded.providername,
      eigener_provider=excluded.eigener_provider,bemerkung=excluded.bemerkung,updated_at=excluded.updated_at`)
    .bind(tenantId,name,input.eigener_provider===false?0:1,clean(input.bemerkung,2000)||null,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'emaw.provider.set',tenantId,undefined,'emaw_provider',tenantId,{providername:name});
  return{providername:name};
}

async function ladeProvider(env:Env,tenantId:string){
  const p=await env.DB.prepare("SELECT providername FROM emaw_provider WHERE tenant_id=? AND aktiv=1")
    .bind(tenantId).first<{providername:string}>();
  if(!p)throw new Error('EMAW_PROVIDER_FEHLT');
  return p.providername;
}

/**
 * Ein von der BA eingegangenes Ereignis aufnehmen.
 *
 * Anmeldeereignisse tragen die Schluesseldaten; sie werden uebernommen. Alle anderen werden
 * festgehalten, damit sie nicht verloren gehen - beantwortet werden sie von Menschen.
 */
export async function nimmEingangAn(env:Env,auth:CoreAuthContext,tenantId:string,xml:string){
  requireRole(auth,'class_admin');
  const art=lies(xml,'art');
  if(!art)throw new Error('EMAW_EREIGNISART_FEHLT');
  const richtung=EMAW_RICHTUNG[art];
  // Ein Ereignis, das nur der Traeger senden darf, kann nicht von der BA gekommen sein. Es
  // stillschweigend einzulesen hiesse, eine eigene Datei fuer eine fremde zu halten.
  if(richtung==='an_ba')throw new Error('EMAW_EINGANG_FALSCHE_RICHTUNG');
  const kundennummer=lies(xml,'kundennummer'),verfahrenszweig=lies(xml,'verfahrenszweig');
  const traegerId=lies(xml,'tcosachid'),massnahmeId=lies(xml,'mcosachid'),kundeId=lies(xml,'cosachid');
  const ereignisId=lies(xml,'ereignisid');
  if(!ereignisId||!cosach.test(ereignisId))throw new Error('EMAW_EREIGNISID_UNGUELTIG');
  const ts=nowIso();

  let schluesselId:string|null=null;
  if(ANMELDEEREIGNISSE.includes(art)){
    if(!kundennummer||!kunr.test(kundennummer))throw new Error('EMAW_KUNDENNUMMER_UNGUELTIG');
    if(!verfahrenszweig||!zweig.test(verfahrenszweig))throw new Error('EMAW_VERFAHRENSZWEIG_UNGUELTIG');
    for(const wert of [traegerId,massnahmeId,kundeId])
      if(!wert||!cosach.test(wert))throw new Error('EMAW_SCHLUESSEL_UNVOLLSTAENDIG');
    const traeger=xml.match(/<traeger>[\s\S]*?<\/traeger>/)?.[0]??'';
    const massnahme=xml.match(/<massnahme>[\s\S]*?<\/massnahme>/)?.[0]??'';
    const kunde=xml.match(/<kunde>[\s\S]*?<\/kunde>/)?.[0]??'';
    const tref=traeger.match(/<traegernummer>[\s\S]*?<\/traegernummer>/)?.[0]??'';
    const mref=massnahme.match(/<massnahmenummer>[\s\S]*?<\/massnahmenummer>/)?.[0]??'';
    const vorhanden=await env.DB.prepare('SELECT id FROM emaw_schluessel WHERE tenant_id=? AND kundennummer=? AND massnahme_cosach_id=? AND verfahrenszweig=?')
      .bind(tenantId,kundennummer,massnahmeId,verfahrenszweig).first<{id:string}>();
    schluesselId=vorhanden?.id??id('emk_');
    await env.DB.prepare(`INSERT INTO emaw_schluessel(id,tenant_id,kundennummer,verfahrenszweig,
        traeger_cosach_id,traeger_quelle,traeger_aanr,traeger_lfdnr,traeger_bezeichnung,
        massnahme_cosach_id,massnahme_quelle,massnahme_aanr,massnahme_lfdnr,massnahme_jahr,massnahme_bezeichnung,
        kunde_cosach_id,kunde_name,kunde_vorname,kunde_arbeitsamtsnummer,quelle_ereignis,empfangen_am,created_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(id) DO UPDATE SET traeger_bezeichnung=excluded.traeger_bezeichnung,
        massnahme_bezeichnung=excluded.massnahme_bezeichnung,kunde_name=excluded.kunde_name,
        kunde_vorname=excluded.kunde_vorname,quelle_ereignis=excluded.quelle_ereignis,
        empfangen_am=excluded.empfangen_am,updated_at=excluded.updated_at`)
      .bind(schluesselId,tenantId,kundennummer,verfahrenszweig,
        traegerId,lies(tref,'quelle')??'',lies(tref,'arbeitsamtsnummer')??'',lies(tref,'lfdnr')??'',lies(traeger,'bezeichnung')??'',
        massnahmeId,lies(mref,'quelle')??'',lies(mref,'arbeitsamtsnummer')??'',lies(mref,'lfdnr')??'',lies(mref,'jahr')??'',lies(massnahme,'bezeichnung')??'',
        kundeId,lies(kunde,'name')??'',lies(kunde,'vorname')??'',lies(kunde,'arbeitsamtsnummer')??'',art,ts,ts,ts).run();
  }else{
    const treffer=await env.DB.prepare('SELECT id FROM emaw_schluessel WHERE tenant_id=? AND kundennummer=? AND massnahme_cosach_id=?')
      .bind(tenantId,kundennummer??'',massnahmeId??'').first<{id:string}>();
    if(!treffer)throw new Error('EMAW_SCHLUESSEL_UNBEKANNT');
    schluesselId=treffer.id;
  }

  await env.DB.prepare(`INSERT INTO emaw_ereignisse(id,tenant_id,schluessel_id,richtung,art,ereignis_id,
      ereignis_datum,dateiname,xml,status,created_at,updated_at)
    VALUES(?,?,?,'an_traeger',?,?,?,?,?,'empfangen',?,?)
    ON CONFLICT(tenant_id,ereignis_id) DO NOTHING`)
    .bind(id('eme_'),tenantId,schluesselId,art,ereignisId,ts.slice(0,10),`eingang-${ereignisId}.xml`,xml,ts,ts).run();
  return{schluessel_id:schluesselId,art,ereignis_id:ereignisId,anmeldung:ANMELDEEREIGNISSE.includes(art)};
}

export async function ordneZu(env:Env,auth:CoreAuthContext,tenantId:string,schluesselId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const s=await env.DB.prepare('SELECT id FROM emaw_schluessel WHERE id=? AND tenant_id=?')
    .bind(clean(schluesselId,120),tenantId).first<{id:string}>();
  if(!s)throw new Error('EMAW_SCHLUESSEL_NICHT_GEFUNDEN');
  const userId=clean(input.user_id,120)||null,courseId=clean(input.course_id,120)||null;
  if(userId&&!await env.DB.prepare("SELECT 1 x FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'").bind(tenantId,userId).first())
    throw new Error('EMAW_PERSON_NICHT_IM_TRAEGER');
  if(courseId&&!await env.DB.prepare('SELECT 1 x FROM courses WHERE id=? AND tenant_id=?').bind(courseId,tenantId).first())
    throw new Error('EMAW_KURS_NICHT_GEFUNDEN');
  await env.DB.prepare('UPDATE emaw_schluessel SET user_id=?,course_id=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(userId,courseId,nowIso(),s.id,tenantId).run();
  return{schluessel_id:s.id,user_id:userId,course_id:courseId};
}

async function ladeSchluessel(env:Env,tenantId:string,schluesselId:string){
  const s=await env.DB.prepare('SELECT * FROM emaw_schluessel WHERE id=? AND tenant_id=?')
    .bind(clean(schluesselId,120),tenantId).first<Record<string,unknown>>();
  if(!s)throw new Error('EMAW_SCHLUESSEL_NICHT_GEFUNDEN');
  return s;
}

function datenBlock(s:Record<string,unknown>){
  return `<daten>`
    +`<traeger>`
      +`<traegernummer>${tag('quelle',String(s.traeger_quelle))}${tag('arbeitsamtsnummer',String(s.traeger_aanr))}${tag('lfdnr',String(s.traeger_lfdnr))}</traegernummer>`
      +tag('tcosachid',String(s.traeger_cosach_id))+tag('bezeichnung',String(s.traeger_bezeichnung))
    +`</traeger>`
    +`<massnahme>`
      +tag('bezeichnung',String(s.massnahme_bezeichnung))
      +`<massnahmenummer>${tag('quelle',String(s.massnahme_quelle))}${tag('arbeitsamtsnummer',String(s.massnahme_aanr))}${tag('lfdnr',String(s.massnahme_lfdnr))}${tag('jahr',String(s.massnahme_jahr))}</massnahmenummer>`
      +tag('mcosachid',String(s.massnahme_cosach_id))
    +`</massnahme>`
    +`<kunde>`
      +tag('kundennummer',String(s.kundennummer))+tag('cosachid',String(s.kunde_cosach_id))
      +tag('name',String(s.kunde_name))+tag('vorname',String(s.kunde_vorname))
      +tag('arbeitsamtsnummer',String(s.kunde_arbeitsamtsnummer))
    +`</kunde>`
    +tag('verfahrenszweig',String(s.verfahrenszweig))
  +`</daten>`;
}

function dateinameFuer(s:Record<string,unknown>,art:string,ts:string){
  const d=ts.slice(0,10).replace(/-/g,'');
  const u=ts.slice(11,23).replace(/[:.]/g,'');
  return `${s.kundennummer}-${d}-${u.slice(0,6)}-${u.slice(6,9)}-${art}`;
}

/**
 * Der einzige Weg, ein ausgehendes Ereignis anzulegen.
 *
 * Exportiert, damit die Richtungspruefung genau eine Stelle hat und diese eine Stelle pruefbar
 * ist. Alle erzeuge*-Funktionen dieses Moduls gehen hier durch; wer eine weitere Ereignisart
 * ergaenzt, kommt an der Pruefung nicht vorbei.
 */
export async function erzeugeEreignisRoh(env:Env,auth:CoreAuthContext,tenantId:string,
    schluesselId:string,art:string,inhalt:string,datum:string){
  requireRole(auth,'class_admin');
  return legeEreignisAn(env,auth,tenantId,await ladeSchluessel(env,tenantId,schluesselId),art,inhalt,datum);
}

async function legeEreignisAn(env:Env,auth:CoreAuthContext,tenantId:string,s:Record<string,unknown>,
    art:string,inhalt:string,datum:string){
  // Die Pruefung, die alles andere traegt: nur was das Schema als "Traeger an BA" ausweist.
  if(EMAW_RICHTUNG[art]!=='an_ba'&&EMAW_RICHTUNG[art]!=='beide')throw new Error('EMAW_RICHTUNG_NICHT_SENDBAR');
  const ts=nowIso(),ereignisId=crypto.randomUUID();
  const xml=`<?xml version="1.0" encoding="iso-8859-15"?>`
    +`<emaw xmlns="http://ba.emaw.types" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">`
    +tag('version',EMAW_SCHEMA_VERSION)
    +datenBlock(s)
    +`<ereignis xsi:type="${art}Typ">`
      +tag('art',art)+datumXml('datum',datum)+tag('ereignisid',ereignisId)
      +inhalt
    +`</ereignis></emaw>`;
  const basis=dateinameFuer(s,art,ts),eintragId=id('eme_');
  await env.DB.prepare(`INSERT INTO emaw_ereignisse(id,tenant_id,schluessel_id,richtung,art,ereignis_id,
      ereignis_datum,dateiname,xml,status,erzeugt_von,created_at,updated_at)
    VALUES(?,?,?,'an_ba',?,?,?,?,?,'erzeugt',?,?,?)`)
    .bind(eintragId,tenantId,String(s.id),art,ereignisId,datum,`${basis}.xml`,xml,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'emaw.event.created',tenantId,s.course_id?String(s.course_id):undefined,'emaw_ereignis',eintragId,{art});
  return{id:eintragId,art,ereignis_id:ereignisId,dateiname:`${basis}.xml`,xml};
}

export async function erzeugeEintritt(env:Env,auth:CoreAuthContext,tenantId:string,schluesselId:string,beginn:string){
  requireRole(auth,'class_admin');
  if(!istTag(beginn))throw new Error('EMAW_DATUM_UNGUELTIG');
  const s=await ladeSchluessel(env,tenantId,schluesselId);
  return legeEreignisAn(env,auth,tenantId,s,'Eintritt',datumXml('beginn',beginn),beginn);
}

export async function erzeugeNichtantritt(env:Env,auth:CoreAuthContext,tenantId:string,schluesselId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const grund=clean(input.grund,200);
  if(!(EMAW_NICHTANTRITTGRUND as readonly string[]).includes(grund))throw new Error('EMAW_NICHTANTRITTGRUND_UNGUELTIG');
  const datum=istTag(input.datum)?String(input.datum):nowIso().slice(0,10);
  const s=await ladeSchluessel(env,tenantId,schluesselId);
  return legeEreignisAn(env,auth,tenantId,s,'Nichtantritt',tag('grund',grund),datum);
}

export async function erzeugeAustritt(env:Env,auth:CoreAuthContext,tenantId:string,schluesselId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const letzter=String(input.letztertag??'');
  if(!istTag(letzter))throw new Error('EMAW_DATUM_UNGUELTIG');
  const beendigung=clean(input.beendigung,200),verbleib=clean(input.verbleib,200);
  if(!(EMAW_BEENDIGUNG as readonly string[]).includes(beendigung))throw new Error('EMAW_BEENDIGUNG_UNGUELTIG');
  if(!(EMAW_VERBLEIB as readonly string[]).includes(verbleib))throw new Error('EMAW_VERBLEIB_UNGUELTIG');
  const ziel=input.zielerreicht===true?'J':'N';
  // Ein regulaeres Ende ohne erreichtes Ziel und ein vorzeitiges Ende mit erreichtem Ziel sind
  // beide moeglich - aber "regulaer" mit einem Austrittsgrund zu mischen, der "vorzeitig" heisst,
  // ist ein Widerspruch, den die Pruefstelle spaeter aufloest und der Traeger begruenden muss.
  if(beendigung==='regulaer'&&input.vorzeitig===true)throw new Error('EMAW_AUSTRITT_WIDERSPRUCH');
  let kuendigung='';
  if(input.kuendigung_am||input.kuendigung_zum){
    if(!istTag(input.kuendigung_am)||!istTag(input.kuendigung_zum))throw new Error('EMAW_DATUM_UNGUELTIG');
    kuendigung=`<kuendigung>${datumXml('kuendigungam',String(input.kuendigung_am))}${datumXml('kuendigungzum',String(input.kuendigung_zum))}</kuendigung>`;
  }
  const s=await ladeSchluessel(env,tenantId,schluesselId);
  const inhalt=datumXml('letztertag',letzter)+tag('zielerreicht',ziel)+tag('beendigung',beendigung)
    +kuendigung+tag('verbleib',verbleib);
  return legeEreignisAn(env,auth,tenantId,s,'Austritt',inhalt,letzter);
}

const MONATSNAMEN=['januar','februar','maerz','april','mai','juni','juli','august','september','oktober','november','dezember'];

/**
 * Die monatliche Anwesenheitsmeldung - abgeleitet, nicht getippt.
 *
 * Das Schema verlangt fuer jeden Kalendertag des Monats ein Element, nicht nur fuer Tage mit
 * Unterricht: 31 im Januar, 30 im April, 28 oder 29 im Februar. Wer nur die Unterrichtstage
 * liefert, bekommt eine Schemaverletzung - und zwar erst in der Quittung.
 */
export async function erzeugeAnwesenheitMonat(env:Env,auth:CoreAuthContext,tenantId:string,schluesselId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const jahr=Math.round(Number(input.jahr)||0),monat=Math.round(Number(input.monat)||0);
  if(!(jahr>=2000&&jahr<=3000))throw new Error('EMAW_JAHR_UNGUELTIG');
  if(!(monat>=1&&monat<=12))throw new Error('EMAW_MONAT_UNGUELTIG');
  const s=await ladeSchluessel(env,tenantId,schluesselId);
  if(!s.user_id||!s.course_id)throw new Error('EMAW_ZUORDNUNG_FEHLT');
  const tage=tageImMonat(jahr,monat);
  const von=`${jahr}-${zwei(monat)}-01`,bis=`${jahr}-${zwei(monat)}-${zwei(tage)}`;

  // Eine Abfrage fuer den ganzen Monat, nicht eine je Tag.
  const anwesend=((await env.DB.prepare(`SELECT g.session_date AS tag,
      MAX(CASE WHEN a.status='present' OR a.status='late' THEN 1 ELSE 0 END) AS praesenz,
      MAX(CASE WHEN a.status='remote_present' THEN 1 ELSE 0 END) AS online,
      MAX(CASE WHEN a.status='excused_absent' THEN 1 ELSE 0 END) AS entschuldigt,
      MAX(CASE WHEN a.status='unexcused_absent' THEN 1 ELSE 0 END) AS gefehlt
    FROM attendance_records a JOIN attendance_sessions g ON g.id=a.session_id AND g.tenant_id=a.tenant_id
    WHERE a.tenant_id=? AND a.user_id=? AND a.course_id=? AND g.session_date BETWEEN ? AND ?
    GROUP BY g.session_date LIMIT 40`).bind(tenantId,String(s.user_id),String(s.course_id),von,bis)
    .all<{tag:string;praesenz:number;online:number;entschuldigt:number;gefehlt:number}>()).results)??[];
  const krank=((await env.DB.prepare(`SELECT starts_on,ends_on FROM absence_notices
    WHERE tenant_id=? AND user_id=? AND status='accepted' AND starts_on<=? AND ends_on>=? LIMIT 40`)
    .bind(tenantId,String(s.user_id),bis,von).all<{starts_on:string;ends_on:string}>()).results)??[];

  const jeTag=new Map(anwesend.map(z=>[z.tag,z]));
  const krankAn=(t:string)=>krank.some(k=>k.starts_on<=t&&k.ends_on>=t);
  const tags:string[]=[];
  for(let d=1;d<=tage;d++){
    const t=`${jahr}-${zwei(monat)}-${zwei(d)}`,z=jeTag.get(t);
    let auspraegung='kein Termin';
    // Die Reihenfolge ist die Rangfolge: eine angenommene Krankmeldung schlaegt einen
    // Anwesenheitseintrag, denn sie ist der Beleg, den der Kostentraeger sehen will.
    // Praesenz und Online sind seit Juli 2022 getrennt zu melden ("AP" und "AO") - wer beides
    // als Anwesenheit meldet, meldet falsch, und niemand sieht es.
    if(krankAn(t))auspraegung='Fehlzeit - krank - Erstbescheinigung';
    else if(z?.praesenz)auspraegung='Anwesenheit - Praesenz';
    else if(z?.online)auspraegung='Anwesenheit - Online';
    else if(z?.entschuldigt)auspraegung='Fehlzeit - entschuldigtes Fehlen - ohne AU';
    else if(z?.gefehlt)auspraegung='Fehlzeit - unentschuldigtes Fehlen - Sachverhaltsaufklaerung den Grundsaetzen des §20 SGB X entsprechend nicht erfolgt';
    if(!(EMAW_ANWESENHEIT as readonly string[]).includes(auspraegung))throw new Error('EMAW_ANWESENHEIT_UNGUELTIG');
    tags.push(`<tag>${tag('auspraegung',auspraegung)}</tag>`);
  }
  const typName=tage===31?'AnwesenheitMonat31Typ':tage===30?'AnwesenheitMonat30Typ':'AnwesenheitMonat28Oder29Typ';
  const erwartet=EMAW_MONATSTAGE[typName];
  if(erwartet&&(tags.length<erwartet.min||tags.length>erwartet.max))throw new Error('EMAW_MONATSTAGE_FALSCH');
  const inhalt=tag('jahr',String(jahr))+`<${MONATSNAMEN[monat-1]}>${tags.join('')}</${MONATSNAMEN[monat-1]}>`;
  return legeEreignisAn(env,auth,tenantId,s,'AnwesenheitMonat',inhalt,bis);
}

// ---------------------------------------------------------------------------------------------
// Archivbau
// ---------------------------------------------------------------------------------------------

const CRCT=(()=>{const t=new Uint32Array(256);
  for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;t[n]=c>>>0;}return t;})();
const CRC=(b:Uint8Array)=>{let c=0xffffffff;for(let i=0;i<b.length;i++)c=CRCT[(c^b[i])&0xff]^(c>>>8);return (c^0xffffffff)>>>0;};

/** Ein ZIP ohne Kompression. Die Inhalte sind XML und werden von eM@w ohnehin sofort entpackt. */
function zip(dateien:{name:string;daten:Uint8Array}[]):Uint8Array{
  const teile:Uint8Array[]=[],zentral:Uint8Array[]=[];
  let versatz=0;
  const enc=new TextEncoder();
  for(const d of dateien){
    const name=enc.encode(d.name),crc=CRC(d.daten),n=d.daten.length;
    const lokal=new Uint8Array(30+name.length);
    const sichtL=new DataView(lokal.buffer);
    sichtL.setUint32(0,0x04034b50,true);sichtL.setUint16(4,20,true);sichtL.setUint16(6,0x0800,true);
    sichtL.setUint16(8,0,true);sichtL.setUint16(10,0,true);sichtL.setUint16(12,0x2821,true);
    sichtL.setUint32(14,crc,true);sichtL.setUint32(18,n,true);sichtL.setUint32(22,n,true);
    sichtL.setUint16(26,name.length,true);sichtL.setUint16(28,0,true);
    lokal.set(name,30);
    teile.push(lokal,d.daten);
    const z=new Uint8Array(46+name.length);
    const sichtZ=new DataView(z.buffer);
    sichtZ.setUint32(0,0x02014b50,true);sichtZ.setUint16(4,20,true);sichtZ.setUint16(6,20,true);
    sichtZ.setUint16(8,0x0800,true);sichtZ.setUint16(10,0,true);sichtZ.setUint16(12,0,true);sichtZ.setUint16(14,0x2821,true);
    sichtZ.setUint32(16,crc,true);sichtZ.setUint32(20,n,true);sichtZ.setUint32(24,n,true);
    sichtZ.setUint16(28,name.length,true);sichtZ.setUint32(42,versatz,true);
    z.set(name,46);
    zentral.push(z);
    versatz+=lokal.length+n;
  }
  const zGesamt=zentral.reduce((a,z)=>a+z.length,0);
  const ende=new Uint8Array(22),sichtE=new DataView(ende.buffer);
  sichtE.setUint32(0,0x06054b50,true);sichtE.setUint16(8,dateien.length,true);
  sichtE.setUint16(10,dateien.length,true);sichtE.setUint32(12,zGesamt,true);sichtE.setUint32(16,versatz,true);
  const alle=[...teile,...zentral,ende];
  const gesamt=alle.reduce((a,t)=>a+t.length,0),aus=new Uint8Array(gesamt);
  let p=0;for(const t of alle){aus.set(t,p);p+=t.length;}
  return aus;
}

/**
 * Das Importarchiv bauen.
 *
 * Aufbau laut Infopaket: ein Zip-Archiv, das je Ereignis ein eigenes Zip enthaelt, in dem die
 * XML-Datei liegt. Nicht flach - ein flaches Archiv wird abgewiesen.
 */
export async function baueImportarchiv(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  const providername=await ladeProvider(env,tenantId);
  const offen=((await env.DB.prepare(`SELECT id,dateiname,xml FROM emaw_ereignisse
    WHERE tenant_id=? AND richtung='an_ba' AND status='erzeugt' ORDER BY created_at LIMIT 200`)
    .bind(tenantId).all<{id:string;dateiname:string;xml:string}>()).results)??[];
  if(!offen.length)throw new Error('EMAW_NICHTS_ZU_SENDEN');
  const enc=new TextEncoder();
  const inhalte=offen.map(e=>({
    name:e.dateiname.replace(/\.xml$/,'.zip'),
    daten:zip([{name:e.dateiname,daten:enc.encode(e.xml)}]),
  }));
  const ts=nowIso(),d=ts.slice(0,10).replace(/-/g,''),u=ts.slice(11,23).replace(/[:.]/g,'');
  const dateiname=`EMAW-${providername}-${d}-${u.slice(0,6)}-${u.slice(6,9)}.zip`;
  const bytes=zip(inhalte);
  const archivId=id('ema_'),pruefsumme=await sha256Text(dateiname+':'+offen.map(e=>e.dateiname).join('|'));
  const anweisungen=[env.DB.prepare(`INSERT INTO emaw_archive(id,tenant_id,dateiname,anzahl,bytes,pruefsumme,status,gebaut_von,created_at,updated_at)
    VALUES(?,?,?,?,?,?,'gebaut',?,?,?)`)
    .bind(archivId,tenantId,dateiname,offen.length,bytes.length,pruefsumme,auth.userId,ts,ts)];
  for(const e of offen)anweisungen.push(env.DB.prepare("UPDATE emaw_ereignisse SET archiv_id=?,status='uebergeben',updated_at=? WHERE id=? AND tenant_id=?")
    .bind(archivId,ts,e.id,tenantId));
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  await audit(env.DB,auth.userId,'emaw.archive.built',tenantId,undefined,'emaw_archiv',archivId,{anzahl:offen.length});
  return{archiv_id:archivId,dateiname,anzahl:offen.length,bytes,pruefsumme,
    hochladen_nach:'https://emaw.arbeitsagentur.de/in/'};
}

/**
 * Eine Quittung der BA einarbeiten.
 *
 * "NOK" ist kein Wiederholungsgrund, sondern ein Endzustand: eM@w nimmt dieselbe Datei nicht
 * noch einmal entgegen. Deshalb wird hier nichts auf 'erzeugt' zurueckgesetzt.
 */
export async function verarbeiteQuittung(env:Env,auth:CoreAuthContext,tenantId:string,xml:string){
  requireRole(auth,'class_admin');
  const bloecke=liesAlle(xml,'quittungarchiv');
  if(!bloecke.length)throw new Error('EMAW_QUITTUNG_UNVOLLSTAENDIG');
  const archivName=lies(bloecke[0],'dateiname'),archivStatus=lies(bloecke[0],'status');
  if(!archivName||!archivStatus)throw new Error('EMAW_QUITTUNG_UNVOLLSTAENDIG');
  const archiv=await env.DB.prepare('SELECT id FROM emaw_archive WHERE tenant_id=? AND dateiname=?')
    .bind(tenantId,archivName).first<{id:string}>();
  if(!archiv)throw new Error('EMAW_ARCHIV_NICHT_GEFUNDEN');
  const ts=nowIso();
  const anweisungen=[env.DB.prepare('UPDATE emaw_archive SET status=?,quittung_text=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(archivStatus==='OK'?'quittiert':'abgewiesen',lies(bloecke[0],'fehler')??null,ts,archiv.id,tenantId)];
  let angenommen=0,abgewiesen=0;
  if(archivStatus!=='OK'){
    // Das ganze Archiv wurde nicht verarbeitet - dann ist jedes Ereignis darin abgewiesen.
    anweisungen.push(env.DB.prepare("UPDATE emaw_ereignisse SET status='abgewiesen',fehlertext=?,updated_at=? WHERE tenant_id=? AND archiv_id=?")
      .bind(lies(bloecke[0],'fehler')??'Archiv abgewiesen',ts,tenantId,archiv.id));
  }
  for(const b of liesAlle(xml,'quittungereignis')){
    const name=lies(b,'dateiname'),status=lies(b,'status');
    if(!name||!status)continue;
    const xmlName=name.replace(/\.zip$/,'.xml');
    if(status==='OK')angenommen++;else abgewiesen++;
    anweisungen.push(env.DB.prepare('UPDATE emaw_ereignisse SET status=?,fehlertext=?,updated_at=? WHERE tenant_id=? AND archiv_id=? AND dateiname=?')
      .bind(status==='OK'?'angenommen':'abgewiesen',status==='OK'?null:(lies(b,'fehler')??'abgewiesen'),ts,tenantId,archiv.id,xmlName));
  }
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  await audit(env.DB,auth.userId,'emaw.receipt.processed',tenantId,undefined,'emaw_archiv',archiv.id,{angenommen,abgewiesen});
  return{archiv_id:archiv.id,archiv_status:archivStatus,angenommen,abgewiesen};
}

export async function emawMappe(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  const [provider,schluessel,ereignisse,archive]=await Promise.all([
    env.DB.prepare('SELECT providername,eigener_provider FROM emaw_provider WHERE tenant_id=?').bind(tenantId).first<Record<string,unknown>>(),
    env.DB.prepare(`SELECT s.id,s.kundennummer,s.verfahrenszweig,s.kunde_name,s.kunde_vorname,
        s.massnahme_bezeichnung,s.user_id,s.course_id,c.name AS kurs
      FROM emaw_schluessel s LEFT JOIN courses c ON c.id=s.course_id
      WHERE s.tenant_id=? ORDER BY s.empfangen_am DESC LIMIT 300`).bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare(`SELECT id,art,status,dateiname,fehlertext,created_at FROM emaw_ereignisse
      WHERE tenant_id=? AND richtung='an_ba' ORDER BY created_at DESC LIMIT 300`).bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT id,dateiname,anzahl,status,created_at FROM emaw_archive WHERE tenant_id=? ORDER BY created_at DESC LIMIT 100')
      .bind(tenantId).all<Record<string,unknown>>(),
  ]);
  const zeilen=schluessel.results??[];
  return{
    provider:provider??null,
    schluessel:zeilen,
    // Der unerledigte Posten, der sonst niemandem auffaellt: eine Anmeldung der BA, die im
    // Portal keiner Person zugeordnet ist. Fuer sie laesst sich nichts melden.
    ohne_zuordnung:zeilen.filter(z=>!z.user_id||!z.course_id).length,
    ereignisse:ereignisse.results??[],
    archive:archive.results??[],
    sendbare_arten:SENDBAR,
  };
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Inventar, Beschaffung und Raumwartung.
//
// Drei getrennte Vorgaenge, die zusammengehoeren, weil sie denselben Gegenstand betreffen:
//
//  - AUSGABE. Der Laptop geht fuer die Dauer der Umschulung an eine Person. Was dabei verloren
//    geht, geht nicht beim Ausgeben verloren, sondern beim Abgang: der Kurs endet, die Person
//    ist weg, und niemand hat gefragt. Deshalb kennt jede Ausgabe ihren Kurs, und
//    offeneAusgabenBeiAbgang() ist die Frage, die sonst niemand stellt.
//  - BESCHAFFUNG. Bestellt wird, was freigegeben ist. Ueber einer Betragsgrenze braucht es zwei
//    Personen - und zwei heisst zwei, nicht dieselbe zweimal.
//  - WARTUNG. Ein sicherheitsrelevanter Mangel ist keine Notiz in einer Liste. Er schreibt eine
//    echte Sperre in planning_resource_unavailability, die die bestehende Raumsuche bereits
//    liest. Sonst plant die Planung weiter Pruefungen in den Raum mit dem losen Kabel.

const clean=(v:unknown,n=2000)=>safeString(v,n);
export const KATEGORIEN=['it','moebel','werkzeug','fahrzeug','lehrmittel','sonstiges'] as const;
export const ZUSTAENDE=['neu','gut','gebraucht','defekt'] as const;
export const EINSTUFUNGEN=['kosmetisch','betrieblich','sicherheitsrelevant'] as const;

/**
 * Ab diesem Betrag braucht eine Anforderung eine zweite Freigabe.
 *
 * 5.000 Euro ist kein Naturgesetz, sondern die Groessenordnung, ab der eine Fehlentscheidung
 * bei einem kleinen Traeger im Jahresabschluss sichtbar wird. Sie steht hier und nicht in einer
 * Einstellung, weil eine Grenze, die sich im Betrieb verstellen laesst, im Zweifel verstellt
 * wird - und zwar von der Person, die gerade bestellen moechte.
 */
export const ZWEITFREIGABE_AB_CENT=500000;

const tagAus=(iso:string)=>iso.slice(0,10);
const istTag=(v:unknown)=>/^\d{4}-\d{2}-\d{2}$/.test(String(v??''));

async function ladeGegenstand(env:Env,tenantId:string,itemId:string){
  const g=await env.DB.prepare('SELECT * FROM inventory_items WHERE id=? AND tenant_id=?')
    .bind(clean(itemId,120),tenantId).first<Record<string,unknown>>();
  if(!g)throw new Error('INVENTAR_NICHT_GEFUNDEN');
  return g;
}

export async function erfasseGegenstand(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const nummer=clean(input.inventarnummer,80),bezeichnung=clean(input.bezeichnung,200);
  if(!nummer)throw new Error('INVENTAR_NUMMER_ERFORDERLICH');
  if(!bezeichnung)throw new Error('INVENTAR_BEZEICHNUNG_ERFORDERLICH');
  const kategorie=clean(input.kategorie,40);
  if(!(KATEGORIEN as readonly string[]).includes(kategorie))throw new Error('INVENTAR_KATEGORIE_UNGUELTIG');
  const zustand=clean(input.zustand,20)||'gut';
  if(!(ZUSTAENDE as readonly string[]).includes(zustand))throw new Error('INVENTAR_ZUSTAND_UNGUELTIG');
  const doppelt=await env.DB.prepare('SELECT 1 x FROM inventory_items WHERE tenant_id=? AND inventarnummer=?')
    .bind(tenantId,nummer).first();
  if(doppelt)throw new Error('INVENTAR_NUMMER_VERGEBEN');
  const raum=clean(input.resource_id,120)||null;
  if(raum&&!await env.DB.prepare('SELECT 1 x FROM planning_resources WHERE id=? AND tenant_id=?').bind(raum,tenantId).first())
    throw new Error('INVENTAR_RAUM_NICHT_GEFUNDEN');
  const gegenstandId=id('inv_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO inventory_items(id,tenant_id,inventarnummer,bezeichnung,kategorie,seriennummer,resource_id,
      standort,anschaffung_am,anschaffung_cent,garantie_bis,zustand,status,erfasst_von,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'verfuegbar',?,?,?)`)
    .bind(gegenstandId,tenantId,nummer,bezeichnung,kategorie,clean(input.seriennummer,120)||null,raum,
      clean(input.standort,200)||null,istTag(input.anschaffung_am)?String(input.anschaffung_am):null,
      input.anschaffung_cent==null?null:Math.max(0,Math.round(Number(input.anschaffung_cent)||0)),
      istTag(input.garantie_bis)?String(input.garantie_bis):null,zustand,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'inventory.item.created',tenantId,undefined,'inventory_item',gegenstandId,{inventarnummer:nummer});
  return{id:gegenstandId,inventarnummer:nummer,status:'verfuegbar'};
}

export async function gibAus(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  // Am Tresen wird der Aufkleber gelesen, nicht die interne Kennung. Beides ist erlaubt.
  let itemId=clean(input.item_id,120);
  if(!itemId&&clean(input.inventarnummer,80)){
    const treffer=await env.DB.prepare('SELECT id FROM inventory_items WHERE tenant_id=? AND inventarnummer=?')
      .bind(tenantId,clean(input.inventarnummer,80)).first<{id:string}>();
    if(!treffer)throw new Error('INVENTAR_NICHT_GEFUNDEN');
    itemId=treffer.id;
  }
  const g=await ladeGegenstand(env,tenantId,itemId);
  if(g.status==='ausgemustert')throw new Error('INVENTAR_AUSGEMUSTERT');
  if(g.status==='wartung')throw new Error('INVENTAR_IN_WARTUNG');
  if(g.status==='ausgegeben')throw new Error('INVENTAR_BEREITS_AUSGEGEBEN');
  const userId=clean(input.user_id,120);
  // Ausgegeben wird an Menschen, die zum Traeger gehoeren. Sonst steht das Geraet auf einem
  // Namen, zu dem es keine Akte gibt.
  const gehoertDazu=await env.DB.prepare("SELECT 1 x FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'")
    .bind(tenantId,userId).first();
  if(!gehoertDazu)throw new Error('INVENTAR_EMPFAENGER_NICHT_IM_TRAEGER');
  const courseId=clean(input.course_id,120)||null;
  if(courseId&&!await env.DB.prepare('SELECT 1 x FROM courses WHERE id=? AND tenant_id=?').bind(courseId,tenantId).first())
    throw new Error('INVENTAR_KURS_NICHT_GEFUNDEN');
  const faellig=istTag(input.faellig_am)?String(input.faellig_am):null;
  const ausgabeId=id('invaus_'),ts=nowIso();
  await env.DB.batch([
    env.DB.prepare(`INSERT INTO inventory_issues(id,tenant_id,item_id,user_id,course_id,ausgegeben_am,ausgegeben_von,
        faellig_am,bemerkung,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,'offen',?,?)`)
      .bind(ausgabeId,tenantId,String(g.id),userId,courseId,tagAus(ts),auth.userId,faellig,clean(input.bemerkung,2000)||null,ts,ts),
    env.DB.prepare("UPDATE inventory_items SET status='ausgegeben',updated_at=? WHERE id=? AND tenant_id=?")
      .bind(ts,String(g.id),tenantId),
  ]);
  await audit(env.DB,auth.userId,'inventory.issued',tenantId,courseId??undefined,'inventory_item',String(g.id),{empfaenger:userId});
  return{ausgabe_id:ausgabeId,item_id:String(g.id),faellig_am:faellig};
}

export async function nimmZurueck(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const ausgabeId=clean(input.ausgabe_id,120);
  const a=await env.DB.prepare("SELECT * FROM inventory_issues WHERE id=? AND tenant_id=? AND status='offen'")
    .bind(ausgabeId,tenantId).first<Record<string,unknown>>();
  if(!a)throw new Error('INVENTAR_AUSGABE_NICHT_OFFEN');
  const zustand=clean(input.zustand,20);
  if(!(ZUSTAENDE as readonly string[]).includes(zustand))throw new Error('INVENTAR_ZUSTAND_UNGUELTIG');
  const ts=nowIso();
  const anweisungen=[
    env.DB.prepare("UPDATE inventory_issues SET status='zurueck',zurueck_am=?,zustand_rueckgabe=?,bemerkung=COALESCE(?,bemerkung),updated_at=? WHERE id=? AND tenant_id=?")
      .bind(tagAus(ts),zustand,clean(input.bemerkung,2000)||null,ts,ausgabeId,tenantId),
  ];
  let ticketId:string|null=null;
  if(zustand==='defekt'){
    // Ein defekt zurueckgegebenes Geraet still auf 'verfuegbar' zu setzen ist der Fehler, der
    // beim naechsten Kursstart auffliegt - dann steht die Teilnehmerin ohne Rechner da.
    ticketId=id('wart_');
    anweisungen.push(
      env.DB.prepare("UPDATE inventory_items SET status='wartung',zustand='defekt',updated_at=? WHERE id=? AND tenant_id=?")
        .bind(ts,String(a.item_id),tenantId),
      env.DB.prepare(`INSERT INTO maintenance_tickets(id,tenant_id,item_id,titel,beschreibung,einstufung,status,
          gemeldet_von,gemeldet_am,created_at,updated_at) VALUES(?,?,?,?,?,'betrieblich','offen',?,?,?,?)`)
        .bind(ticketId,tenantId,String(a.item_id),'Defekt bei Rückgabe',clean(input.bemerkung,2000)||null,auth.userId,ts,ts,ts));
  }else{
    anweisungen.push(env.DB.prepare("UPDATE inventory_items SET status='verfuegbar',zustand=?,updated_at=? WHERE id=? AND tenant_id=?")
      .bind(zustand,ts,String(a.item_id),tenantId));
  }
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'inventory.returned',tenantId,a.course_id?String(a.course_id):undefined,'inventory_item',String(a.item_id),{zustand});
  return{item_id:String(a.item_id),zustand,wartung_id:ticketId};
}

export async function meldeVerlust(env:Env,auth:CoreAuthContext,tenantId:string,ausgabeId:string,grund:string){
  requireRole(auth,'tenant_admin');
  const a=await env.DB.prepare("SELECT * FROM inventory_issues WHERE id=? AND tenant_id=? AND status='offen'")
    .bind(clean(ausgabeId,120),tenantId).first<Record<string,unknown>>();
  if(!a)throw new Error('INVENTAR_AUSGABE_NICHT_OFFEN');
  const text=clean(grund,2000);
  if(text.length<5)throw new Error('INVENTAR_VERLUSTGRUND_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE inventory_issues SET status='verloren',zurueck_am=?,bemerkung=?,updated_at=? WHERE id=? AND tenant_id=?")
      .bind(tagAus(ts),text,ts,String(a.id),tenantId),
    env.DB.prepare("UPDATE inventory_items SET status='ausgemustert',updated_at=? WHERE id=? AND tenant_id=?")
      .bind(ts,String(a.item_id),tenantId),
  ]);
  await audit(env.DB,auth.userId,'inventory.lost',tenantId,a.course_id?String(a.course_id):undefined,'inventory_item',String(a.item_id),{});
  return{item_id:String(a.item_id),status:'ausgemustert'};
}

export async function mustereAus(env:Env,auth:CoreAuthContext,tenantId:string,itemId:string){
  requireRole(auth,'tenant_admin');
  const g=await ladeGegenstand(env,tenantId,itemId);
  // Ein Geraet, das jemand in der Hand hat, ist nicht weg, nur weil es aus der Liste
  // verschwindet. Danach fragt niemand mehr danach.
  if(g.status==='ausgegeben')throw new Error('INVENTAR_NOCH_AUSGEGEBEN');
  const ts=nowIso();
  await env.DB.prepare("UPDATE inventory_items SET status='ausgemustert',updated_at=? WHERE id=? AND tenant_id=?")
    .bind(ts,String(g.id),tenantId).run();
  await audit(env.DB,auth.userId,'inventory.retired',tenantId,undefined,'inventory_item',String(g.id),{});
  return{item_id:String(g.id),status:'ausgemustert'};
}

/**
 * Was beim Abgang noch offen ist.
 *
 * Ohne Kurs: alles, was dieser Mensch noch hat. Mit Kurs: was an diesem Kurs haengt. Eine
 * Abfrage, auch fuer einen ganzen Jahrgang.
 */
export async function offeneAusgabenBeiAbgang(env:Env,auth:CoreAuthContext,tenantId:string,filter:{course_id?:string;user_id?:string}={}){
  requireRole(auth,'class_admin');
  const kurs=filter.course_id?clean(filter.course_id,120):null,person=filter.user_id?clean(filter.user_id,120):null;
  const zeilen=((await env.DB.prepare(`SELECT a.id,a.user_id,a.course_id,a.ausgegeben_am,a.faellig_am,
      i.inventarnummer,i.bezeichnung,i.anschaffung_cent,u.display_name,c.name AS kurs
    FROM inventory_issues a JOIN inventory_items i ON i.id=a.item_id
    JOIN users u ON u.id=a.user_id LEFT JOIN courses c ON c.id=a.course_id
    WHERE a.tenant_id=? AND a.status='offen'
      AND (? IS NULL OR a.course_id=?) AND (? IS NULL OR a.user_id=?)
    ORDER BY a.ausgegeben_am LIMIT 500`)
    .bind(tenantId,kurs,kurs,person,person)
    .all<Record<string,unknown>>()).results)??[];
  return{offen:zeilen,wert_cent:zeilen.reduce((s,z)=>s+(Number(z.anschaffung_cent)||0),0)};
}

// ---------------------------------------------------------------------------------------------
// Beschaffung
// ---------------------------------------------------------------------------------------------

export async function fordereAn(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const titel=clean(input.titel,200);
  if(!titel)throw new Error('BESCHAFFUNG_TITEL_ERFORDERLICH');
  const kategorie=clean(input.kategorie,40);
  if(!(KATEGORIEN as readonly string[]).includes(kategorie))throw new Error('INVENTAR_KATEGORIE_UNGUELTIG');
  const menge=Math.round(Number(input.menge)||0);
  if(!(menge>0))throw new Error('BESCHAFFUNG_MENGE_UNGUELTIG');
  const preis=Math.round(Number(input.einzelpreis_cent)||0);
  if(!(preis>=0)||!Number.isFinite(preis))throw new Error('BESCHAFFUNG_PREIS_UNGUELTIG');
  const naechste=await env.DB.prepare('SELECT COALESCE(MAX(nummer),0)+1 n FROM procurement_requests WHERE tenant_id=?')
    .bind(tenantId).first<{n:number}>();
  const nummer=Number(naechste?.n??1),vorgangId=id('besch_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO procurement_requests(id,tenant_id,nummer,titel,begruendung,kategorie,menge,
      einzelpreis_cent,lieferant,status,angefordert_von,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,'bedarf',?,?,?)`)
    .bind(vorgangId,tenantId,nummer,titel,clean(input.begruendung,4000)||null,kategorie,menge,preis,
      clean(input.lieferant,200)||null,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'procurement.requested',tenantId,undefined,'procurement_request',vorgangId,{nummer});
  // Die Summe wird gerechnet, nicht getippt - wie beim Angebot.
  return{id:vorgangId,nummer,summe_cent:menge*preis,
    braucht_zweitfreigabe:menge*preis>=ZWEITFREIGABE_AB_CENT,status:'bedarf'};
}

async function ladeVorgang(env:Env,tenantId:string,vorgangId:string){
  const v=await env.DB.prepare('SELECT * FROM procurement_requests WHERE id=? AND tenant_id=?')
    .bind(clean(vorgangId,120),tenantId).first<Record<string,unknown>>();
  if(!v)throw new Error('BESCHAFFUNG_NICHT_GEFUNDEN');
  return v;
}

export async function gibFrei(env:Env,auth:CoreAuthContext,tenantId:string,vorgangId:string){
  requireRole(auth,'tenant_admin');
  const v=await ladeVorgang(env,tenantId,vorgangId);
  const summe=Number(v.menge)*Number(v.einzelpreis_cent);
  const braucht=summe>=ZWEITFREIGABE_AB_CENT;
  const ts=nowIso();
  if(v.status!=='bedarf'&&v.status!=='freigegeben')throw new Error('BESCHAFFUNG_NICHT_MEHR_OFFEN');
  // Ob dies die erste oder die zweite Freigabe ist, entscheidet nicht der Zustand, sondern ob
  // schon jemand unterschrieben hat. Sonst haette dieselbe Person zweimal unterschreiben
  // koennen - der Zustand bleibt bei einem Grossbetrag ja absichtlich 'bedarf'.
  if(!v.freigegeben_von){
    await env.DB.prepare(`UPDATE procurement_requests SET freigegeben_von=?,freigegeben_am=?,
        status=CASE WHEN ? THEN 'bedarf' ELSE 'freigegeben' END,updated_at=? WHERE id=? AND tenant_id=?`)
      .bind(auth.userId,ts,braucht?1:0,ts,String(v.id),tenantId).run();
    await audit(env.DB,auth.userId,'procurement.approved',tenantId,undefined,'procurement_request',String(v.id),{stufe:1});
    return{id:String(v.id),status:braucht?'bedarf':'freigegeben',summe_cent:summe,
      offen:braucht?'zweitfreigabe':null};
  }
  if(!braucht)throw new Error('BESCHAFFUNG_BEREITS_FREIGEGEBEN');
  if(String(v.freigegeben_von)===auth.userId)throw new Error('BESCHAFFUNG_ZWEITFREIGABE_ANDERE_PERSON');
  if(v.zweitfreigabe_von)throw new Error('BESCHAFFUNG_BEREITS_FREIGEGEBEN');
  await env.DB.prepare("UPDATE procurement_requests SET zweitfreigabe_von=?,zweitfreigabe_am=?,status='freigegeben',updated_at=? WHERE id=? AND tenant_id=?")
    .bind(auth.userId,ts,ts,String(v.id),tenantId).run();
  await audit(env.DB,auth.userId,'procurement.approved',tenantId,undefined,'procurement_request',String(v.id),{stufe:2});
  return{id:String(v.id),status:'freigegeben',summe_cent:summe,offen:null};
}

export async function lehneAb(env:Env,auth:CoreAuthContext,tenantId:string,vorgangId:string,grund:string){
  requireRole(auth,'tenant_admin');
  const v=await ladeVorgang(env,tenantId,vorgangId);
  if(v.status!=='bedarf'&&v.status!=='freigegeben')throw new Error('BESCHAFFUNG_NICHT_MEHR_OFFEN');
  const text=clean(grund,2000);
  if(text.length<5)throw new Error('BESCHAFFUNG_ABLEHNUNGSGRUND_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.prepare("UPDATE procurement_requests SET status='abgelehnt',abgelehnt_grund=?,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(text,ts,String(v.id),tenantId).run();
  return{id:String(v.id),status:'abgelehnt'};
}

export async function bestelle(env:Env,auth:CoreAuthContext,tenantId:string,vorgangId:string){
  requireRole(auth,'tenant_admin');
  const v=await ladeVorgang(env,tenantId,vorgangId);
  // Der ganze Punkt der Beschaffung: bestellt wird, was freigegeben ist.
  if(v.status!=='freigegeben')throw new Error('BESCHAFFUNG_OHNE_FREIGABE');
  const ts=nowIso();
  await env.DB.prepare("UPDATE procurement_requests SET status='bestellt',bestellt_am=?,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(tagAus(ts),ts,String(v.id),tenantId).run();
  await audit(env.DB,auth.userId,'procurement.ordered',tenantId,undefined,'procurement_request',String(v.id),{});
  return{id:String(v.id),status:'bestellt'};
}

export async function bucheWareneingang(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const v=await ladeVorgang(env,tenantId,String(input.request_id??''));
  if(v.status!=='bestellt'&&v.status!=='teilgeliefert')throw new Error('BESCHAFFUNG_NICHT_BESTELLT');
  const menge=Math.round(Number(input.menge)||0);
  if(!(menge>0))throw new Error('BESCHAFFUNG_MENGE_UNGUELTIG');
  const bisher=await env.DB.prepare('SELECT COALESCE(SUM(menge),0) m FROM procurement_receipts WHERE tenant_id=? AND request_id=?')
    .bind(tenantId,String(v.id)).first<{m:number}>();
  const geliefert=Number(bisher?.m??0)+menge;
  // Mehr annehmen als bestellt heisst: eine Rechnung bezahlen, die niemand freigegeben hat.
  if(geliefert>Number(v.menge))throw new Error('BESCHAFFUNG_MEHR_ALS_BESTELLT');
  const ts=nowIso(),neu=geliefert>=Number(v.menge)?'geliefert':'teilgeliefert';
  await env.DB.batch([
    env.DB.prepare('INSERT INTO procurement_receipts(id,tenant_id,request_id,menge,geliefert_am,lieferschein,erfasst_von,created_at) VALUES(?,?,?,?,?,?,?,?)')
      .bind(id('wein_'),tenantId,String(v.id),menge,tagAus(ts),clean(input.lieferschein,200)||null,auth.userId,ts),
    env.DB.prepare('UPDATE procurement_requests SET status=?,updated_at=? WHERE id=? AND tenant_id=?')
      .bind(neu,ts,String(v.id),tenantId),
  ]);
  return{id:String(v.id),status:neu,geliefert,offen:Math.max(0,Number(v.menge)-geliefert)};
}

// ---------------------------------------------------------------------------------------------
// Wartung
// ---------------------------------------------------------------------------------------------

/** Wie lange ein sicherheitsrelevanter Mangel den Raum sperrt, bis jemand ihn behebt. */
const SPERRE_TAGE=365;

export async function meldeMangel(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const titel=clean(input.titel,200);
  if(!titel)throw new Error('WARTUNG_TITEL_ERFORDERLICH');
  const einstufung=clean(input.einstufung,40);
  if(!(EINSTUFUNGEN as readonly string[]).includes(einstufung))throw new Error('WARTUNG_EINSTUFUNG_UNGUELTIG');
  const resourceId=clean(input.resource_id,120)||null,itemId=clean(input.item_id,120)||null;
  if(!resourceId&&!itemId)throw new Error('WARTUNG_GEGENSTAND_ERFORDERLICH');
  if(resourceId&&!await env.DB.prepare('SELECT 1 x FROM planning_resources WHERE id=? AND tenant_id=?').bind(resourceId,tenantId).first())
    throw new Error('INVENTAR_RAUM_NICHT_GEFUNDEN');
  if(itemId)await ladeGegenstand(env,tenantId,itemId);
  const ticketId=id('wart_'),ts=nowIso();
  const anweisungen=[env.DB.prepare(`INSERT INTO maintenance_tickets(id,tenant_id,resource_id,item_id,titel,beschreibung,
      einstufung,status,sperre_id,gemeldet_von,gemeldet_am,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'offen',?,?,?,?,?)`)];
  let sperreId:string|null=null;
  if(einstufung==='sicherheitsrelevant'&&resourceId){
    // Die Sperre ist keine Kennzeichnung am Wartungsvorgang, sondern ein Eintrag in genau der
    // Tabelle, die die Raumsuche und die Pruefungsplanung ohnehin lesen. Ein Vermerk, den nur
    // diese Seite kennt, haette den Raum weiter verplanen lassen.
    sperreId=id('rblk_');
    const bis=new Date(Date.parse(ts)+SPERRE_TAGE*86400000).toISOString();
    anweisungen.push(env.DB.prepare(`INSERT INTO planning_resource_unavailability(id,tenant_id,resource_id,starts_at,ends_at,
        reason,source,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,'maintenance',?,?,?)`)
      .bind(sperreId,tenantId,resourceId,ts,bis,`Sicherheitsrelevanter Mangel: ${titel}`,auth.userId,ts,ts));
  }
  anweisungen[0]=anweisungen[0].bind(ticketId,tenantId,resourceId,itemId,titel,clean(input.beschreibung,4000)||null,
    einstufung,sperreId,auth.userId,ts,ts,ts);
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'maintenance.reported',tenantId,undefined,'maintenance_ticket',ticketId,{einstufung});
  return{id:ticketId,einstufung,gesperrt:Boolean(sperreId)};
}

export async function behebeMangel(env:Env,auth:CoreAuthContext,tenantId:string,ticketId:string,text:string){
  requireRole(auth,'class_admin');
  const t=await env.DB.prepare('SELECT * FROM maintenance_tickets WHERE id=? AND tenant_id=?')
    .bind(clean(ticketId,120),tenantId).first<Record<string,unknown>>();
  if(!t)throw new Error('WARTUNG_NICHT_GEFUNDEN');
  if(t.status==='behoben')throw new Error('WARTUNG_BEREITS_BEHOBEN');
  const beschreibung=clean(text,2000);
  if(beschreibung.length<5)throw new Error('WARTUNG_BEHEBUNG_ERFORDERLICH');
  const ts=nowIso();
  const anweisungen=[env.DB.prepare("UPDATE maintenance_tickets SET status='behoben',behoben_am=?,behoben_von=?,behoben_text=?,sperre_id=NULL,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(tagAus(ts),auth.userId,beschreibung,ts,String(t.id),tenantId)];
  if(t.sperre_id)anweisungen.push(env.DB.prepare('DELETE FROM planning_resource_unavailability WHERE id=? AND tenant_id=?')
    .bind(String(t.sperre_id),tenantId));
  if(t.item_id)anweisungen.push(env.DB.prepare("UPDATE inventory_items SET status='verfuegbar',zustand='gebraucht',updated_at=? WHERE id=? AND tenant_id=? AND status='wartung'")
    .bind(ts,String(t.item_id),tenantId));
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'maintenance.fixed',tenantId,undefined,'maintenance_ticket',String(t.id),{});
  return{id:String(t.id),status:'behoben',sperre_aufgehoben:Boolean(t.sperre_id)};
}

export async function inventarmappe(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  const [gegenstaende,ausgaben,beschaffung,wartung]=await Promise.all([
    env.DB.prepare(`SELECT status,kategorie,COUNT(*) anzahl,COALESCE(SUM(anschaffung_cent),0) wert_cent
      FROM inventory_items WHERE tenant_id=? GROUP BY status,kategorie ORDER BY status,kategorie LIMIT 100`)
      .bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare(`SELECT a.id,a.faellig_am,i.inventarnummer,i.bezeichnung,u.display_name,c.name AS kurs
      FROM inventory_issues a JOIN inventory_items i ON i.id=a.item_id JOIN users u ON u.id=a.user_id
      LEFT JOIN courses c ON c.id=a.course_id WHERE a.tenant_id=? AND a.status='offen'
      ORDER BY COALESCE(a.faellig_am,'9999'),a.ausgegeben_am LIMIT 200`).bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare(`SELECT id,nummer,titel,status,menge,einzelpreis_cent,freigegeben_von,zweitfreigabe_von
      FROM procurement_requests WHERE tenant_id=? AND status NOT IN ('geliefert','abgelehnt','storniert')
      ORDER BY nummer DESC LIMIT 200`).bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare(`SELECT t.id,t.titel,t.einstufung,t.status,t.gemeldet_am,r.name AS raum,i.inventarnummer
      FROM maintenance_tickets t LEFT JOIN planning_resources r ON r.id=t.resource_id
      LEFT JOIN inventory_items i ON i.id=t.item_id
      WHERE t.tenant_id=? AND t.status IN ('offen','in_arbeit')
      ORDER BY CASE t.einstufung WHEN 'sicherheitsrelevant' THEN 0 WHEN 'betrieblich' THEN 1 ELSE 2 END,t.gemeldet_am
      LIMIT 200`).bind(tenantId).all<Record<string,unknown>>(),
  ]);
  return{
    bestand:gegenstaende.results??[],
    offene_ausgaben:ausgaben.results??[],
    beschaffung:(beschaffung.results??[]).map(b=>({...b,summe_cent:Number(b.menge)*Number(b.einzelpreis_cent),
      braucht_zweitfreigabe:Number(b.menge)*Number(b.einzelpreis_cent)>=ZWEITFREIGABE_AB_CENT})),
    wartung:wartung.results??[],
  };
}

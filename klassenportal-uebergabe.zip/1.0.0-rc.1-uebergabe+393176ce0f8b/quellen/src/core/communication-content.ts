import { safeString } from './utils.js';

// Die Mitteilung als strukturiertes Objekt (Master-Spec V2, K2, §55).
//
// Bisher war eine Mitteilung Titel plus Rumpftext. Sobald derselbe Inhalt ueber mehrere Wege
// hinausgeht, faellt das auseinander: die Mail braucht HTML, die Kurzmeldung einen Anriss, die App
// eine Form, die sich antippen laesst. Wer dafuer zweite Texte pflegt, hat nach der ersten
// Korrektur zwei Wahrheiten und keine Moeglichkeit mehr zu sagen, welche gilt.
//
// Deshalb gibt es hier GENAU EINE Quelle - eine Folge von Bloecken - und daraus gerechnete
// Darstellungen. Keine Darstellung wird gespeichert und von Hand nachgepflegt; auch die alte
// Spalte `body` ist ab jetzt eine gerechnete Darstellung (textDarstellung), damit alle vorhandenen
// Leser weiterlaufen, ohne dass ein zweiter Text entsteht.

export type Block=
  |{typ:'absatz';text:string}
  |{typ:'ueberschrift';text:string}
  |{typ:'liste';punkte:string[]}
  |{typ:'link';text:string;ziel:string}
  |{typ:'datei';text:string;ziel:string}
  |{typ:'termin';text:string;beginn:string;ende:string|null;ort:string|null};

export const BLOCKTYPEN=['absatz','ueberschrift','liste','link','datei','termin'] as const;
export const MAX_BLOECKE=60;
export const MAX_LISTENPUNKTE=30;
/** Wie lang ein Anriss hoechstens ist. Eine Kurzmeldung, die abgeschnitten wird, ist keine. */
export const ANRISS_ZEICHEN=140;

function pflichttext(wert:unknown,laenge:number):string{const t=safeString(wert,laenge).trim();if(!t)throw new Error('KOMMUNIKATION_BLOCK_UNVOLLSTAENDIG');return t;}

// Ein Ziel darf nur ins Portal oder ins Netz zeigen. `javascript:` und `data:` waeren ein
// ausfuehrbarer Anhang in einer Mitteilung, die jeder im Haus bekommt - der kuerzeste Weg von der
// Hausmitteilung zur Uebernahme fremder Sitzungen.
function ziel(wert:unknown):string{
  const z=safeString(wert,1000).trim();
  if(!z)throw new Error('KOMMUNIKATION_BLOCK_UNVOLLSTAENDIG');
  if(z.startsWith('/')&&!z.startsWith('//'))return z;
  if(/^https?:\/\/[^\s]+$/i.test(z))return z;
  throw new Error('KOMMUNIKATION_LINKZIEL_UNGUELTIG');
}
function zeitpunkt(wert:unknown):string{const s=safeString(wert,60).trim();const d=new Date(s);if(!s||Number.isNaN(d.getTime()))throw new Error('KOMMUNIKATION_TERMIN_UNGUELTIG');return d.toISOString();}

/** Prueft und normalisiert die Bloecke einer Mitteilung. Fail closed: was hier nicht durchkommt, wird nicht gespeichert. */
export function parseBloecke(eingabe:unknown):Block[]{
  if(!Array.isArray(eingabe)||!eingabe.length)throw new Error('KOMMUNIKATION_BLOECKE_LEER');
  if(eingabe.length>MAX_BLOECKE)throw new Error('KOMMUNIKATION_ZU_VIELE_BLOECKE');
  const out:Block[]=[];
  for(const roh of eingabe as Record<string,unknown>[]){
    const typ=String(roh?.typ||'');
    if(!(BLOCKTYPEN as readonly string[]).includes(typ))throw new Error('KOMMUNIKATION_BLOCKTYP_UNBEKANNT');
    if(typ==='absatz')out.push({typ:'absatz',text:pflichttext(roh.text,4000)});
    else if(typ==='ueberschrift')out.push({typ:'ueberschrift',text:pflichttext(roh.text,250)});
    else if(typ==='liste'){
      const roheListe=Array.isArray(roh.punkte)?roh.punkte:[];
      if(!roheListe.length)throw new Error('KOMMUNIKATION_BLOCK_UNVOLLSTAENDIG');
      if(roheListe.length>MAX_LISTENPUNKTE)throw new Error('KOMMUNIKATION_ZU_VIELE_BLOECKE');
      out.push({typ:'liste',punkte:roheListe.map(p=>pflichttext(p,500))});
    }
    else if(typ==='link')out.push({typ:'link',text:pflichttext(roh.text,250),ziel:ziel(roh.ziel)});
    else if(typ==='datei')out.push({typ:'datei',text:pflichttext(roh.text,250),ziel:ziel(roh.ziel)});
    else{
      const beginn=zeitpunkt(roh.beginn),ende=roh.ende==null||roh.ende===''?null:zeitpunkt(roh.ende);
      if(ende&&ende<=beginn)throw new Error('KOMMUNIKATION_TERMIN_UNGUELTIG');
      out.push({typ:'termin',text:pflichttext(roh.text,250),beginn,ende,ort:safeString(roh.ort,250).trim()||null});
    }
  }
  return out;
}

/** Bloecke aus einer alten Mitteilung, die nur Fliesstext hat. Damit bleibt es EINE Quelle - auch rueckwirkend. */
export function bloeckeAusText(text:unknown):Block[]{
  const absaetze=String(text??'').split(/\n{2,}/).map(x=>x.trim()).filter(Boolean).slice(0,MAX_BLOECKE);
  return (absaetze.length?absaetze:['—']).map(t=>({typ:'absatz',text:t.slice(0,4000)} as Block));
}

/** Bloecke einer gespeicherten Mitteilung lesen. Fehlt die Spalte (Altbestand), wird sie aus dem Rumpf gerechnet. */
export function bloeckeLesen(bloecke_json:unknown,body:unknown):Block[]{
  const roh=safeString(bloecke_json,200000);
  if(roh){try{const x=JSON.parse(roh);if(Array.isArray(x)&&x.length)return x as Block[];}catch{/* unlesbar: dann gilt der Rumpf */}}
  return bloeckeAusText(body);
}

function esc(v:unknown){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));}
function zeitText(iso:string){return `${iso.slice(8,10)}.${iso.slice(5,7)}.${iso.slice(0,4)}, ${iso.slice(11,16)} Uhr`;}

// --- Darstellung 1: Portal. Die Bloecke selbst; die Oberflaeche zeichnet sie. -------------------
export function portalDarstellung(bloecke:Block[]):Block[]{return bloecke;}

// --- Darstellung 2: Text. Zugleich der Inhalt der Spalte `body` und der Textteil der Mail. -------
export function textDarstellung(bloecke:Block[]):string{
  return bloecke.map(b=>{
    if(b.typ==='absatz')return b.text;
    if(b.typ==='ueberschrift')return b.text.toUpperCase();
    if(b.typ==='liste')return b.punkte.map(p=>`- ${p}`).join('\n');
    if(b.typ==='link')return `${b.text}: ${b.ziel}`;
    if(b.typ==='datei')return `Datei - ${b.text}: ${b.ziel}`;
    return `Termin - ${b.text}: ${zeitText(b.beginn)}${b.ende?` bis ${zeitText(b.ende)}`:''}${b.ort?`, ${b.ort}`:''}`;
  }).join('\n\n');
}

// --- Darstellung 3: Mail als HTML ---------------------------------------------------------------
export function htmlDarstellung(bloecke:Block[]):string{
  return bloecke.map(b=>{
    if(b.typ==='absatz')return `<p>${esc(b.text).replace(/\n/g,'<br>')}</p>`;
    if(b.typ==='ueberschrift')return `<h2 style="font-size:17px;margin:18px 0 6px">${esc(b.text)}</h2>`;
    if(b.typ==='liste')return `<ul>${b.punkte.map(p=>`<li>${esc(p)}</li>`).join('')}</ul>`;
    if(b.typ==='link')return `<p><a href="${esc(b.ziel)}">${esc(b.text)}</a></p>`;
    if(b.typ==='datei')return `<p><a href="${esc(b.ziel)}">${esc(b.text)}</a> <span style="color:#667085;font-size:13px">(Datei)</span></p>`;
    return `<p><strong>${esc(b.text)}</strong><br>${esc(zeitText(b.beginn))}${b.ende?` bis ${esc(zeitText(b.ende))}`:''}${b.ort?`<br>${esc(b.ort)}`:''}</p>`;
  }).join('');
}

// --- Darstellung 4: Kurzmeldung. Gekuerzter Anriss mit Verweis, nie der ganze Text. -------------
//
// Eine Kurzmeldung landet auf einem Sperrbildschirm, den auch andere sehen. Sie traegt deshalb
// absichtlich nur den Anfang und den Weg zum vollstaendigen Text - nicht den Inhalt.
export function anrissDarstellung(bloecke:Block[],grenze=ANRISS_ZEICHEN):string{
  const text=textDarstellung(bloecke).replace(/\s+/g,' ').trim();
  if(text.length<=grenze)return text;
  const gekuerzt=text.slice(0,grenze);
  const schnitt=gekuerzt.lastIndexOf(' ');
  return `${(schnitt>grenze/2?gekuerzt.slice(0,schnitt):gekuerzt).trimEnd()} …`;
}

export type Darstellungen={
  portal:Block[];
  mail:{betreff:string;html:string;text:string};
  push:{titel:string;anriss:string;verweis:string};
  mobil:{titel:string;anriss:string;bloecke:Block[]};
};

/**
 * Alle Ausgaben aus einer Quelle. Wer einen weiteren Weg anschliesst, ergaenzt hier ein Feld -
 * und braucht dafuer keinen zweiten Text.
 */
export function darstellungen(bloecke:Block[],titel:string,opt:{betreff?:string;herkunft?:string}={}):Darstellungen{
  const herkunft=String(opt.herkunft||'');
  const hinweis='Diese Nachricht wurde ausschließlich an Dich gesendet. Weitere Empfänger sind für Dich nicht sichtbar.';
  const text=`${textDarstellung(bloecke)}\n\n${hinweis}${herkunft?`\n\nIm Klassenportal öffnen: ${herkunft}`:''}`;
  const html=`${htmlDarstellung(bloecke)}<p style="color:#667085;font-size:13px">${esc(hinweis)}</p>${herkunft?`<p><a href="${esc(herkunft)}">Klassenportal öffnen</a></p>`:''}`;
  return{
    portal:portalDarstellung(bloecke),
    mail:{betreff:String(opt.betreff||titel),html,text},
    push:{titel,anriss:anrissDarstellung(bloecke),verweis:herkunft||'/'},
    mobil:{titel,anriss:anrissDarstellung(bloecke,80),bloecke},
  };
}

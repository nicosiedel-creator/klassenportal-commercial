import type { CoreAuthContext, Env } from './types.js';
import { id, nowIso, safeString, sha256Text } from './utils.js';
import { requireCourseAccess, requireRole } from './permissions.js';
import { audit } from './audit.js';
import { nachteilsausgleichFuer } from './exam-accommodations.js';

// Eine Webanwendung kann auf einem fremden Geraet keine anderen Programme und kein Internet sperren.
// Das verbietet die Browser-Sandbox - jede Zusage in diese Richtung waere unwahr.
//
// Der Safe Exam Browser (ETH Zuerich, quelloffen) leistet das auf dem Geraet: er sperrt es in einen
// Kiosk-Modus, aus dem heraus weder gewechselt noch beendet werden kann. Der Server kann nachweisen,
// dass die Pruefung wirklich darin lief, weil SEB bei JEDER Anfrage einen Hash mitschickt:
//
//   X-SafeExamBrowser-RequestHash    = SHA256(URL + Browser Exam Key)
//   X-SafeExamBrowser-ConfigKeyHash  = SHA256(URL + Config Key)
//
// Der Schluessel selbst geht dabei nie ueber die Leitung. Der Server kennt ihn, rechnet denselben
// Hash und vergleicht. Stimmt es nicht, lief die Pruefung nicht in der vereinbarten Umgebung.
//
// Wichtig fuer die Erwartung des Kunden: das beweist die UMGEBUNG, nicht die Person. Wer neben dem
// gesperrten Rechner ein Telefon liegen hat, wird davon nicht erfasst. SEB ist eine Huerde, kein
// Beweis der Eigenleistung - und so sollte es dem Traeger auch gesagt werden.
export type SebPruefung={ok:true}|{ok:false;grund:'seb_missing'|'seb_key_mismatch'|'seb_config_mismatch'};

export const SEB_REQUEST_HASH='x-safeexambrowser-requesthash';
export const SEB_CONFIG_HASH='x-safeexambrowser-configkeyhash';

function schluessel(roh:unknown):string[]{
  return String(roh??'').split(/[\s,;]+/).map(x=>x.trim()).filter(Boolean);
}

/**
 * Prueft die von SEB mitgeschickten Hashes gegen die fuer diese Pruefung hinterlegten Schluessel.
 * `url` muss die vom Client angefragte Adresse sein - genau so, wie SEB sie gehasht hat.
 */
export async function pruefeSeb(url:string,kopfzeilen:Headers,browserExamKeys:unknown,configKeys:unknown):Promise<SebPruefung>{
  const bek=schluessel(browserExamKeys),ck=schluessel(configKeys);
  // Ist nichts hinterlegt, gibt es nichts zu pruefen - die Pruefung ist dann schlicht nicht auf SEB
  // festgelegt. Das entscheidet seb_required, nicht diese Funktion.
  if(!bek.length&&!ck.length)return{ok:true};
  const gesendetBek=kopfzeilen.get(SEB_REQUEST_HASH)||'',gesendetCk=kopfzeilen.get(SEB_CONFIG_HASH)||'';
  if(!gesendetBek&&!gesendetCk)return{ok:false,grund:'seb_missing'};
  if(bek.length){
    if(!gesendetBek)return{ok:false,grund:'seb_missing'};
    for(const k of bek)if(gleich(await sha256Text(url+k),gesendetBek))return{ok:true};
    return{ok:false,grund:'seb_key_mismatch'};
  }
  if(!gesendetCk)return{ok:false,grund:'seb_missing'};
  for(const k of ck)if(gleich(await sha256Text(url+k),gesendetCk))return{ok:true};
  return{ok:false,grund:'seb_config_mismatch'};
}

// Zeitkonstanter Vergleich: ein Vergleich, der beim ersten abweichenden Zeichen abbricht, verraet
// ueber die Antwortzeit, wie viele Zeichen gestimmt haben. Bei einem Pruefungsschluessel, der oft
// und beliebig wiederholt werden kann, ist das kein theoretisches Problem.
function gleich(a:string,b:string):boolean{
  const x=String(a),y=String(b);
  if(x.length!==y.length)return false;
  let diff=0;for(let i=0;i<x.length;i++)diff|=x.charCodeAt(i)^y.charCodeAt(i);
  return diff===0;
}

/** Haelt einen abgewiesenen Zugriff fest. Ohne Protokoll stuende bei einer Anfechtung Aussage gegen Aussage. */
export async function protokolliereSebVerstoss(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,quizId:string,attemptId:string|null,grund:string,pfad:string):Promise<void>{
  await env.DB.prepare('INSERT INTO quiz_attempt_security_events(id,tenant_id,course_id,quiz_id,attempt_id,user_id,event_type,request_path,created_at) VALUES(?,?,?,?,?,?,?,?,?)')
    .bind(id('qse_'),tenantId,courseId,quizId,attemptId,auth.userId,grund,pfad.slice(0,300),nowIso()).run();
}

/**
 * Die vollstaendige Wache fuer einen auf SEB festgelegten Zugriff.
 *
 * Bewusst hier und nicht im Router: die Entscheidung, WER an der Pruefungsumgebung scheitert und
 * wer nicht, ist eine fachliche und muss pruefbar sein. Im Router waere sie es nicht.
 *
 * Reihenfolge: erst die Hashes, dann - und nur bei Misserfolg - der Nachteilsausgleich. Im Regelfall
 * kostet die Ausnahme so keine Unteranfrage.
 */
export async function sebWache(env:Env,auth:CoreAuthContext,tenantId:string,quizId:string,attemptId:string|null,url:string,kopfzeilen:Headers):Promise<void>{
  const q=await env.DB.prepare('SELECT id,course_id,seb_required,seb_browser_exam_keys,seb_config_keys FROM quizzes WHERE tenant_id=? AND id=?')
    .bind(tenantId,quizId).first<{id:string;course_id:string;seb_required:number;seb_browser_exam_keys:string|null;seb_config_keys:string|null}>();
  if(!q||!q.seb_required)return;
  // Eine Pruefung, die SEB verlangt, aber keinen Schluessel hinterlegt hat, kann nichts pruefen:
  // pruefeSeb gaebe "in Ordnung" zurueck und jeder gewoehnliche Browser kaeme durch, waehrend die
  // Leitung glaubt, die Pruefung sei gesperrt. Das ist schlimmer als gar keine Sperre, also wird
  // hier geschlossen statt geoeffnet. Erzeugen laesst sich dieser Zustand ueber setExamLockdown
  // nicht mehr; er kann nur aus Daten von vorher stammen.
  if(!String(q.seb_browser_exam_keys||'').trim()&&!String(q.seb_config_keys||'').trim()){
    await protokolliereSebVerstoss(env,auth,tenantId,q.course_id,q.id,attemptId,'seb_not_configured',new URL(url).pathname);
    throw new Error('EXAM_SEB_NOT_CONFIGURED');
  }
  const r=await pruefeSeb(url,kopfzeilen,q.seb_browser_exam_keys,q.seb_config_keys);
  if(r.ok)return;
  // Screenreader, Braillezeile und Vergroesserungssoftware laufen im Kiosk-Modus des Safe Exam
  // Browser haeufig nicht. Wer darauf angewiesen ist, wuerde ohne diese Ausnahme an der
  // Pruefungsumgebung scheitern statt an der Aufgabe - das waere der Nachteil, den der
  // Nachteilsausgleich gerade beseitigen soll.
  const ausgleich=await nachteilsausgleichFuer(env,tenantId,q.course_id,auth.userId,q.id);
  if(ausgleich?.seb_befreit)return;
  await protokolliereSebVerstoss(env,auth,tenantId,q.course_id,q.id,attemptId,r.grund,new URL(url).pathname);
  throw new Error(r.grund==='seb_missing'?'EXAM_REQUIRES_SAFE_EXAM_BROWSER':'EXAM_SAFE_EXAM_BROWSER_INVALID');
}

/**
 * Die Sperre einer Pruefung einstellen.
 *
 * Ohne diese Funktion gab es die Spalten seb_required, seb_browser_exam_keys und seb_config_keys
 * zwar in der Datenbank, aber keinen Weg, sie zu setzen: die gesamte Pruefungssperre war gebaut und
 * nicht einschaltbar.
 *
 * Die Schluessel selbst sind KEINE Geheimnisse im Sinne eines Passworts - SEB schickt nur Hashes,
 * der Schluessel bleibt auf dem Geraet und auf dem Server. Trotzdem gibt ihn nur die Leitung ein.
 */
export async function setExamLockdown(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,quizId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');requireCourseAccess(auth,courseId,'class_admin');
  const quiz=await env.DB.prepare('SELECT id FROM quizzes WHERE id=? AND tenant_id=? AND course_id=?').bind(quizId,tenantId,courseId).first();
  if(!quiz)throw new Error('QUIZ_NOT_FOUND');
  const noetig=input.seb_required===true?1:0;
  const bek=schluessel(safeString(input.seb_browser_exam_keys,2000)),ck=schluessel(safeString(input.seb_config_keys,2000));
  // Ohne Schluessel gibt es nichts zu pruefen. Ein Haken, der nichts bewirkt, waere eine Zusage,
  // die das System nicht halten kann - und genau die wuerde dem Traeger im Ernstfall vorgehalten.
  if(noetig&&!bek.length&&!ck.length)throw new Error('EXAM_SEB_KEYS_REQUIRED');
  if(bek.length>20||ck.length>20)throw new Error('EXAM_SEB_KEYS_INVALID');
  if([...bek,...ck].some(x=>!/^[0-9a-zA-Z_-]{16,200}$/.test(x)))throw new Error('EXAM_SEB_KEYS_INVALID');
  await env.DB.prepare('UPDATE quizzes SET seb_required=?,seb_browser_exam_keys=?,seb_config_keys=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(noetig,bek.join(' ')||null,ck.join(' ')||null,nowIso(),quizId,tenantId).run();
  // Im Protokoll steht die ANZAHL der Schluessel, nie ein Schluessel.
  await audit(env.DB,auth.userId,'exam.lockdown_set',tenantId,courseId,'quiz',quizId,{seb_required:!!noetig,browser_exam_keys:bek.length,config_keys:ck.length});
  return{seb_required:!!noetig,browser_exam_keys:bek.length,config_keys:ck.length};
}

import type { CoreAuthContext, Env } from './types.js';
import { simulateEducationScenario } from './education-scenarios.js';
import { safeString } from './utils.js';

interface IntentPreview{intent:string;scenario_type:string|null;confidence:number;complete:boolean;resolved:Record<string,unknown>;missing:string[];ambiguities:Array<{field:string;candidates:Array<{id:string;label:string}>}>;warnings:string[];explanation:string[];next_step?:{key:string;label:string;where:string}|null}
function norm(v:string){return v.normalize('NFKC').toLocaleLowerCase('de-DE').replace(/[–—]/g,'-').replace(/\s+/g,' ').trim();}
function partsAt(date:Date,timeZone:string){const parts=new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(date),get=(t:string)=>Number(parts.find(p=>p.type===t)?.value||0);return{year:get('year'),month:get('month'),day:get('day'),hour:get('hour'),minute:get('minute'),second:get('second')};}
function localDateKey(now:Date,timeZone:string){const p=partsAt(now,timeZone);return`${p.year}-${String(p.month).padStart(2,'0')}-${String(p.day).padStart(2,'0')}`;}
function addLocalDays(dateKey:string,days:number){const [y,m,d]=dateKey.split('-').map(Number),x=new Date(Date.UTC(y,m-1,d+days,12));return x.toISOString().slice(0,10);}
function relativeDate(text:string,timeZone:string,now=new Date()){const n=norm(text),today=localDateKey(now,timeZone);if(/\bübermorgen\b/.test(n))return addLocalDays(today,2);if(/\bmorgen\b/.test(n))return addLocalDays(today,1);if(/\bheute\b/.test(n))return today;const dm=n.match(/\b(\d{1,2})\.(\d{1,2})(?:\.(\d{2,4}))?\b/);if(dm){let y=dm[3]?Number(dm[3]):Number(today.slice(0,4));if(y<100)y+=2000;return`${y}-${String(Number(dm[2])).padStart(2,'0')}-${String(Number(dm[1])).padStart(2,'0')}`;}const iso=n.match(/\b(20\d{2}-\d{2}-\d{2})\b/);return iso?.[1]||null;}
function datePeriod(text:string,timeZone:string,now=new Date()){const n=norm(text),today=localDateKey(now,timeZone),token='(?:\\d{1,2}\\.\\d{1,2}(?:\\.\\d{2,4})?|20\\d{2}-\\d{2}-\\d{2}|heute|morgen|übermorgen)',until=n.match(new RegExp(`\\bbis\\s+(${token})\\b`,'i'));if(!until)return null;const from=n.match(new RegExp(`\\b(?:von|vom|ab)\\s+(${token})\\b`,'i')),start=from?relativeDate(from[1],timeZone,now):today,end=relativeDate(until[1],timeZone,now);if(!start||!end||start>end)return null;return{start,end};}
function timeRange(text:string){const n=norm(text),m=n.match(/\b(?:von\s*)?(\d{1,2})(?:[:.]([0-5]\d))?\s*(?:uhr)?\s*(?:bis|-)\s*(\d{1,2})(?:[:.]([0-5]\d))?\s*(?:uhr)?\b/);if(m)return{start:`${String(Number(m[1])).padStart(2,'0')}:${m[2]||'00'}`,end:`${String(Number(m[3])).padStart(2,'0')}:${m[4]||'00'}`};const one=n.match(/\b(?:um\s*)?(\d{1,2})(?:[:.]([0-5]\d))\s*(?:uhr)?\b/);if(one){const h=Number(one[1]),min=Number(one[2]),start=`${String(h).padStart(2,'0')}:${String(min).padStart(2,'0')}`,d=new Date(Date.UTC(2000,0,1,h,min+90));return{start,end:`${String(d.getUTCHours()).padStart(2,'0')}:${String(d.getUTCMinutes()).padStart(2,'0')}`};}return null;}
function localToUtc(date:string,time:string,timeZone:string){const [y,m,d]=date.split('-').map(Number),[hh,mm]=time.split(':').map(Number),wanted=Date.UTC(y,m-1,d,hh,mm,0);let guess=wanted;for(let i=0;i<4;i++){const p=partsAt(new Date(guess),timeZone),seen=Date.UTC(p.year,p.month-1,p.day,p.hour,p.minute,p.second),delta=wanted-seen;if(!delta)break;guess+=delta;}const check=partsAt(new Date(guess),timeZone);if(check.year!==y||check.month!==m||check.day!==d||check.hour!==hh||check.minute!==mm)throw new Error('INTENT_LOCAL_TIME_INVALID_DST');const same=(x:number)=>{const p=partsAt(new Date(x),timeZone);return p.year===y&&p.month===m&&p.day===d&&p.hour===hh&&p.minute===mm;};if(same(guess-3600000)||same(guess+3600000))throw new Error('INTENT_LOCAL_TIME_AMBIGUOUS_DST');return new Date(guess).toISOString();}
async function tenantTimezone(env:Env,tenantId:string){const row=await env.DB.prepare('SELECT timezone FROM tenant_settings WHERE tenant_id=?').bind(tenantId).first<{timezone:string}>().catch(()=>null);const tz=row?.timezone||'Europe/Berlin';try{new Intl.DateTimeFormat('de-DE',{timeZone:tz}).format(new Date());return tz;}catch{return'Europe/Berlin';}}
async function candidates(env:Env,sql:string,args:unknown[]){return((await env.DB.prepare(sql).bind(...args).all<{id:string;label:string}>()).results??[]);}
function entityPhrase(text:string,keywords:string[]){const escaped=keywords.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|'),m=text.match(new RegExp(`(?:${escaped})\\s+([^,.!?;]+)`,'i'));return m?.[1]?.trim()||null;}
async function explicitEntity(env:Env,tenantId:string,type:'teacher'|'resource'|'exam'|'course'|'person',explicitId:string){if(type==='person')return env.DB.prepare("SELECT u.id,u.display_name label FROM users u JOIN memberships m ON m.user_id=u.id AND m.tenant_id=? WHERE u.id=? LIMIT 1").bind(tenantId,explicitId).first<{id:string;label:string}>();if(type==='teacher')return env.DB.prepare('SELECT id,name label FROM teachers WHERE tenant_id=? AND id=?').bind(tenantId,explicitId).first<{id:string;label:string}>();if(type==='resource')return env.DB.prepare('SELECT id,name label FROM planning_resources WHERE tenant_id=? AND id=?').bind(tenantId,explicitId).first<{id:string;label:string}>();if(type==='exam')return env.DB.prepare('SELECT id,title label FROM exams WHERE tenant_id=? AND id=?').bind(tenantId,explicitId).first<{id:string;label:string}>();return env.DB.prepare('SELECT id,name label FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,explicitId).first<{id:string;label:string}>();}
async function resolveEntity(env:Env,tenantId:string,type:'teacher'|'resource'|'exam'|'course'|'person',intent:string,explicit?:unknown){const explicitId=safeString(explicit,120);if(explicitId){const row=await explicitEntity(env,tenantId,type,explicitId);return row?{id:row.id,label:row.label,candidates:[]}:{id:null,label:null,candidates:[]};}let rows:Array<{id:string;label:string}>=[];if(type==='teacher')rows=await candidates(env,'SELECT id,name label FROM teachers WHERE tenant_id=? ORDER BY name',[tenantId]);else if(type==='resource')rows=await candidates(env,"SELECT id,name label FROM planning_resources WHERE tenant_id=? AND status='active' ORDER BY name",[tenantId]);else if(type==='exam')rows=await candidates(env,'SELECT id,title label FROM exams WHERE tenant_id=? ORDER BY starts_at DESC LIMIT 500',[tenantId]);else if(type==='person')rows=await candidates(env,"SELECT u.id,u.display_name label FROM users u JOIN memberships m ON m.user_id=u.id AND m.tenant_id=? WHERE u.status='active' GROUP BY u.id,u.display_name ORDER BY u.display_name LIMIT 2000",[tenantId]);else rows=await candidates(env,"SELECT id,name label FROM courses WHERE tenant_id=? AND is_active=1 ORDER BY name",[tenantId]);const n=norm(intent),exact=rows.filter(r=>n.includes(norm(r.label)));if(exact.length===1)return{id:exact[0].id,label:exact[0].label,candidates:[]};if(exact.length>1)return{id:null,label:null,candidates:exact};const phrase=type==='teacher'?entityPhrase(intent,['dozent','dozentin','herr','frau']):type==='resource'?entityPhrase(intent,['raum','ressource']):type==='exam'?entityPhrase(intent,['prüfung','klausur']):entityPhrase(intent,['klasse','kurs']);if(!phrase)return{id:null,label:null,candidates:[]};const p=norm(phrase),fuzzy=rows.filter(r=>norm(r.label).includes(p)||p.includes(norm(r.label)));return fuzzy.length===1?{id:fuzzy[0].id,label:fuzzy[0].label,candidates:[]}:{id:null,label:null,candidates:fuzzy.slice(0,10)};}
function scenarioType(n:string){if(/\b(krank|fällt\s+aus|faellt\s+aus|nicht\s+da|abwesend)\b/.test(n))return'teacher_absence';if(/\b(raum|ressource)\b/.test(n)&&/\b(gesperrt|defekt|ausgefallen|nicht\s+verfügbar|geschlossen)\b/.test(n))return'room_outage';if(/\b(prüfung|klausur)\b/.test(n)&&/\b(verschieb|verleg|neuer\s+termin)\b/.test(n))return'exam_shift';if(/\b(lehrplan|lernfeld|curriculum)\b/.test(n)&&/\b(aufhol|rückstand|lücke|schaffen|erreich)\b/.test(n))return'curriculum_recovery';if(/\b(übernehm|uebernehm|mitten\s+im\s+jahr|altbestand|altdaten)\b/.test(n))return'midyear_takeover';if(/\b(selbstlernphase|selbstlernen|homeoffice)\b/.test(n))return'self_study_need';if(/\b(exkursion|besichtigung)\b/.test(n))return'excursion_change';if(/\b(stundenplan|plan)\b/.test(n)&&/\b(neu|umplan|optimier|ausbalancier)\b/.test(n))return'schedule_rebalance';if(/\b(qualifikation|zertifikat|berechtigung)\b/.test(n)&&/\b(läuft\s+aus|ablauf|endet)\b/.test(n))return'qualification_expiry';return null;}

export async function previewEducationIntent(env:Env,auth:CoreAuthContext,tenantId:string,intentText:string,explicit:Record<string,unknown>={}):Promise<IntentPreview>{
  if(!auth.isPlatformAdmin&&!auth.tenantIds.includes(tenantId))throw new Error('FORBIDDEN_TENANT');
  const intent=safeString(intentText,5000);if(!intent)throw new Error('INTENT_REQUIRED');
  const n=norm(intent),resolved:Record<string,unknown>={},missing:string[]=[],ambiguities:IntentPreview['ambiguities']=[],warnings:string[]=[],explanation:string[]=[],tz=await tenantTimezone(env,tenantId);
  // Ein Raum heisst beim Kunden nicht "Raum", sondern "IT-Labor Nord 1" oder "Seminarraum B202".
  // Die Worterkennung verlangte aber wortwoertlich "raum" oder "ressource" im Satz - "IT-Labor
  // Nord 1 ist die naechsten 3 Monate gesperrt" fiel deshalb mit 0 % durch, obwohl genau dieser
  // Raum im Mandanten gefuehrt wird. Gemeldet aus Produktion.
  // Nennt der Satz eine Sperrung UND genau eine bekannte Ressource dieses Mandanten, ist es eine
  // Raumsperrung. Aufgeloest wird gegen die echten Daten; bei mehreren Treffern bleibt es
  // unerkannt, statt zu raten.
  let type=scenarioType(n);
  // Zeugnisse und Berichtshefte sind Betriebsvorgaenge wie jeder andere - sie brauchen keine
  // eigene Oberflaeche, sondern denselben Weg: beschreiben, pruefen, bestaetigen. Beide setzen
  // auf vorhandene Ausfuehrung auf (Zeugnisse vorbereiten, Nachweise anfordern) und aendern von
  // sich aus nichts.
  if(!type&&/\b(zeugnis|zeugnisse|abschlusszeugnis|abschlusszeugnisse|bescheinigung|bescheinigungen|zertifikat|zertifikate)\b/.test(n))type='certificate_batch';
  // "erstell den stundenplan fuer klasse a fuer september": der Kunde will planen lassen, nicht
  // umplanen. schedule_rebalance verlangt "neu/umplan/optimier" und greift dafuer nicht.
  if(!type&&/\b(stundenplan|stundenplaene|stundenpläne|unterrichtsplan|wochenplan)\b/.test(n)&&/\b(erstell\w*|erzeug\w*|anleg\w*|entwirf|entwerf\w*|plane|planen|planung)\b/.test(n))type='timetable_draft';
  if(!type&&/\b(berichtsheft|berichtshefte|taetigkeitsnachweis|taetigkeitsnachweise|tätigkeitsnachweis|tätigkeitsnachweise|nachweisheft)\b/.test(n))type='reportbook_batch';
  if(!type&&/\b(gesperrt|defekt|ausgefallen|nicht\s+verfügbar|nicht\s+verfuegbar|geschlossen)\b/.test(n)){
    const treffer=await resolveEntity(env,tenantId,'resource',intent,explicit.resource_id);
    if(treffer.id)type='room_outage';
  }
  if(!type)return{intent,scenario_type:null,confidence:0,complete:false,resolved,missing:['scenario_type'],ambiguities,next_step:null,warnings:['Die Absicht konnte keinem sicheren Szenario zugeordnet werden. Es wird nichts verändert.'],explanation:['Freitext wird ausschließlich in einen prüfbaren Szenariovorschlag übersetzt. Unklare Eingaben führen niemals zu Schreibzugriffen.']};
  // Wohin der Kunde als Naechstes muss. Reine Angabe, keine Ausfuehrung: der Absichtsweg
  // schlaegt vor und fuehrt niemals aus - diese Bauart wird eigens geprueft.
  const NAECHSTER_SCHRITT:Record<string,{key:string;label:string;where:string}>={
    timetable_draft:{key:'timetable_autofill',label:'Stundenplan automatisch entwerfen',where:'Ressourcen & Regeln'},
    schedule_rebalance:{key:'timetable_autofill',label:'Stundenplan automatisch entwerfen',where:'Ressourcen & Regeln'},
    certificate_batch:{key:'certificate_course',label:'Bescheinigungen für die ganze Klasse vorbereiten',where:'Bescheinigungen / Zertifikate'},
    reportbook_batch:{key:'reportbook_periods',label:'Berichtsheft-Zeiträume für die ganze Klasse eröffnen',where:'Berichtshefte'},
    room_outage:{key:'planning_resources',label:'Sperrzeit für die Ressource eintragen',where:'Ressourcen & Regeln'},
    teacher_absence:{key:'planning_absence',label:'Abwesenheit eintragen',where:'Ressourcen & Regeln'},
  };
  explanation.push(`Erkanntes Szenario: ${type}.`);explanation.push(`Zeitangaben werden in der Mandanten-Zeitzone ${tz} aufgelöst.`);
  const d=relativeDate(intent,tz),period=datePeriod(intent,tz),range=timeRange(intent),course=await resolveEntity(env,tenantId,'course',intent,explicit.course_id);
  if(course.candidates.length)ambiguities.push({field:'course_id',candidates:course.candidates});if(course.id){resolved.course_id=course.id;resolved.course_label=course.label;}

  // Zeugnisse und Nachweise sind Sammelvorgaenge ueber eine Klasse. Sie loesen die Klasse gegen
  // die echten Daten auf, zaehlen die Betroffenen und schlagen den Vorgang vor - vorbereitet wird
  // erst nach Bestaetigung, ausgestellt niemals von hier.
  if(type==='certificate_batch'||type==='reportbook_batch'){
    const k=await resolveEntity(env,tenantId,'course',intent,explicit.course_id);
    if(k.candidates.length)ambiguities.push({field:'course_id',candidates:k.candidates});
    if(k.id){resolved.course_id=k.id;resolved.course_label=k.label;}else if(!k.candidates.length)missing.push('course_id');
    if(k.id){
      const n2=await env.DB.prepare("SELECT COUNT(DISTINCT user_id) n FROM memberships WHERE tenant_id=? AND course_id=? AND role IN ('participant','class_admin')").bind(tenantId,k.id).first<{n:number}>();
      resolved.participant_count=Number(n2?.n||0);
      if(!resolved.participant_count)warnings.push('Diese Klasse führt derzeit keine Teilnehmenden. Es gäbe nichts vorzubereiten.');
    }
    resolved.document_kind=type==='certificate_batch'?'certificate':'reportbook';
    resolved.reason=intent;
    warnings.push(type==='certificate_batch'
      ?'Zeugnisse werden nur vorbereitet und zur Freigabe vorgelegt. Ausgestellt wird nichts ohne ausdrückliche Bestätigung.'
      :'Nachweise werden nur angefordert und zur Prüfung vorgelegt. Abgeschlossen wird nichts ohne ausdrückliche Bestätigung.');
    explanation.push('Die Klasse wird gegen die echten Mandantendaten aufgelöst; die Anzahl der Betroffenen stammt aus den geführten Mitgliedschaften.');
  }
  // Ein Stundenplanentwurf ist ein Vorschlag, kein Betrieb. Aufgeloest werden Klasse und Zeitraum
  // gegen die echten Daten; geplant wird spaeter nur, wofuer Kursregeln hinterlegt sind.
  if(type==='timetable_draft'){
    const k=await resolveEntity(env,tenantId,'course',intent,explicit.course_id);
    if(k.candidates.length)ambiguities.push({field:'course_id',candidates:k.candidates});
    if(k.id){resolved.course_id=k.id;resolved.course_label=k.label;}
    if(period){resolved.starts_on=period.start;resolved.ends_on=period.end;}else missing.push('period');
    const regeln=k.id
      ?await env.DB.prepare('SELECT COUNT(*) n FROM course_scheduling_rules WHERE tenant_id=? AND course_id=?').bind(tenantId,k.id).first<{n:number}>()
      :await env.DB.prepare('SELECT COUNT(*) n FROM course_scheduling_rules WHERE tenant_id=?').bind(tenantId).first<{n:number}>();
    resolved.planned_courses=Number(regeln?.n||0);
    if(!resolved.planned_courses)warnings.push('Für die gewünschte Klasse sind keine Kursregeln hinterlegt. Ohne Kursregeln entsteht kein Termin.');
    warnings.push('Es entsteht ausschließlich ein Stundenplanentwurf. Veröffentlicht wird er erst nach ausdrücklicher Bestätigung.');
    explanation.push('Der Entwurf entsteht aus den hinterlegten Kursregeln, freien Dozentinnen und Dozenten und freien Räumen; Lücken werden benannt statt geraten.');
  }
  if(type==='teacher_absence'){
    const e=await resolveEntity(env,tenantId,'teacher',intent,explicit.teacher_id);if(e.candidates.length)ambiguities.push({field:'teacher_id',candidates:e.candidates});if(e.id){resolved.teacher_id=e.id;resolved.teacher_label=e.label;}else if(!e.candidates.length)missing.push('teacher_id');
    const date=safeString(explicit.date,20)||d;
    if(explicit.starts_at&&explicit.ends_at){resolved.starts_at=String(explicit.starts_at);resolved.ends_at=String(explicit.ends_at);}
    else if(period){resolved.starts_at=localToUtc(period.start,range?.start||'00:00',tz);resolved.ends_at=localToUtc(period.end,range?.end||'23:59',tz);if(!range)warnings.push('Keine Uhrzeit erkannt: Die Abwesenheit wird über die vollständigen lokalen Kalendertage simuliert.');}
    else if(range&&date){resolved.starts_at=localToUtc(date,range.start,tz);resolved.ends_at=localToUtc(date,range.end,tz);}
    else if(date){resolved.starts_at=localToUtc(date,'00:00',tz);resolved.ends_at=localToUtc(date,'23:59',tz);warnings.push('Keine Uhrzeit erkannt: Der Ausfall wird für den ganzen lokalen Kalendertag simuliert.');}
    else missing.push('date');
    resolved.source=/krank/.test(n)?'sickness':'manual';resolved.reason=intent;resolved.allow_self_study=/selbstlern/.test(n)&&/erlaub|möglich|moeglich/.test(n);
  }
  if(type==='room_outage'){
    const e=await resolveEntity(env,tenantId,'resource',intent,explicit.resource_id);if(e.candidates.length)ambiguities.push({field:'resource_id',candidates:e.candidates});if(e.id){resolved.resource_id=e.id;resolved.resource_label=e.label;}else if(!e.candidates.length)missing.push('resource_id');
    const date=safeString(explicit.date,20)||d;
    if(explicit.starts_at&&explicit.ends_at){resolved.starts_at=String(explicit.starts_at);resolved.ends_at=String(explicit.ends_at);}
    else if(period){resolved.starts_at=localToUtc(period.start,range?.start||'00:00',tz);resolved.ends_at=localToUtc(period.end,range?.end||'23:59',tz);if(!range)warnings.push('Keine Uhrzeit erkannt: Die Ressource wird über die vollständigen lokalen Kalendertage als nicht verfügbar simuliert.');}
    else if(date&&range){resolved.starts_at=localToUtc(date,range.start,tz);resolved.ends_at=localToUtc(date,range.end,tz);}
    else if(date){resolved.starts_at=localToUtc(date,'00:00',tz);resolved.ends_at=localToUtc(date,'23:59',tz);warnings.push('Keine Uhrzeit erkannt: Der Ressourcenausfall wird für den ganzen lokalen Tag simuliert.');}
    else missing.push('date');
    resolved.reason=intent;resolved.allow_remote=/online|remote/.test(n)&&/erlaub|möglich|moeglich/.test(n);
  }
  if(type==='exam_shift'){
    const e=await resolveEntity(env,tenantId,'exam',intent,explicit.exam_id);if(e.candidates.length)ambiguities.push({field:'exam_id',candidates:e.candidates});if(e.id){resolved.exam_id=e.id;resolved.exam_label=e.label;}else if(!e.candidates.length)missing.push('exam_id');const date=safeString(explicit.date,20)||d;if(explicit.new_starts_at){resolved.new_starts_at=String(explicit.new_starts_at);if(explicit.new_ends_at)resolved.new_ends_at=String(explicit.new_ends_at);}else if(date&&range){resolved.new_starts_at=localToUtc(date,range.start,tz);resolved.new_ends_at=localToUtc(date,range.end,tz);}else{if(!date)missing.push('new_date');if(!range)missing.push('new_time');}if(explicit.room)resolved.room=explicit.room;
  }
  if(type==='curriculum_recovery'){if(course.id){resolved.course_id=course.id;resolved.course_label=course.label;}else if(!course.candidates.length)missing.push('course_id');resolved.target_date=safeString(explicit.target_date,20)||d||null;}
  if(['midyear_takeover','qualification_expiry','schedule_rebalance','excursion_change','self_study_need'].includes(type)){if(course.id){resolved.course_id=course.id;resolved.course_label=course.label;}resolved.description=intent;}
  const complete=missing.length===0&&ambiguities.length===0,base=.72,confidence=Math.max(0,Math.min(1,base+(complete?0.25:0)-(ambiguities.length*.2)-(missing.length*.12)));
  if(!complete)warnings.push('Die Eingabe ist nicht eindeutig genug für eine Simulation. Fehlende oder mehrdeutige Felder müssen zuerst aufgelöst werden.');
  explanation.push('Es wurden keine Produktivdaten verändert.');explanation.push('Auch eine vollständige Absicht erzeugt zunächst nur eine Simulation; Ausführung bleibt ein separater Passwortbestätigungs- und Freigabeschritt.');
  const naechster=NAECHSTER_SCHRITT[type]??null;
  return{intent,scenario_type:type,confidence:Math.round(confidence*100)/100,complete,resolved,missing:[...new Set(missing)],ambiguities,warnings,explanation,next_step:naechster};
}

export async function simulateEducationIntent(env:Env,auth:CoreAuthContext,tenantId:string,intentText:string,explicit:Record<string,unknown>={}){const preview=await previewEducationIntent(env,auth,tenantId,intentText,explicit);if(!preview.complete||!preview.scenario_type)throw new Error('INTENT_NOT_SAFE_TO_SIMULATE');const result=await simulateEducationScenario(env,auth,tenantId,preview.scenario_type,preview.resolved,intentText);return{preview,...result};}


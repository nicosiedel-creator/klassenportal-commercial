import type { CoreAuthContext, Env, SessionUser } from './types.js';
import { hasPermission } from './enterprise-access.js';
import { id, nowIso, safeErrorCode,inBloecken} from './utils.js';
import { audit } from './audit.js';

interface Finding{key:string;course_id?:string|null;category:string;severity:'info'|'low'|'medium'|'high'|'critical';title:string;expected?:unknown;actual?:unknown;suggested_fix?:Record<string,unknown>|null;confidence:number;}
function systemAuth(tenantId:string):CoreAuthContext{const session:SessionUser={userId:'system:consistency',email:'system@localhost.invalid',displayName:'Consistency Engine',isPlatformAdmin:true,mustChangePassword:false,tenantRoles:[],authMethod:'api'};return{userId:session.userId,role:'platform_admin',tenantIds:[tenantId],courseIds:[],permissions:['*'],isPlatformAdmin:true,session};}
function canRead(auth:CoreAuthContext){return auth.isPlatformAdmin||auth.role==='tenant_admin'||hasPermission(auth,'reports.view')||hasPermission(auth,'courses.view');}
async function rows<T extends Record<string,unknown>>(env:Env,sql:string,args:unknown[]=[]){try{return((await env.DB.prepare(sql).bind(...args).all<T>()).results??[]);}catch(error){console.error('Consistency source failed',{error:String((error as Error)?.message||error),sql:sql.slice(0,100)});return[];}}
async function upsert(env:Env,tenantId:string,f:Finding,seen:Set<string>){seen.add(f.key);const ts=nowIso(),existing=await env.DB.prepare('SELECT id,detected_at FROM education_consistency_findings WHERE tenant_id=? AND finding_key=?').bind(tenantId,f.key).first<Record<string,unknown>>(),fid=existing?String(existing.id):id('cf_');await env.DB.prepare(`INSERT INTO education_consistency_findings(id,tenant_id,course_id,finding_key,category,severity,title,expected_json,actual_json,suggested_fix_json,confidence,status,detected_at,updated_at,resolved_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,'open',?,?,NULL) ON CONFLICT(tenant_id,finding_key) DO UPDATE SET course_id=excluded.course_id,category=excluded.category,severity=excluded.severity,title=excluded.title,expected_json=excluded.expected_json,actual_json=excluded.actual_json,suggested_fix_json=excluded.suggested_fix_json,confidence=excluded.confidence,status=CASE WHEN education_consistency_findings.status='resolved' THEN 'open' ELSE education_consistency_findings.status END,updated_at=excluded.updated_at,resolved_at=NULL`).bind(fid,tenantId,f.course_id||null,f.key,f.category,f.severity,f.title,f.expected===undefined?null:JSON.stringify(f.expected),f.actual===undefined?null:JSON.stringify(f.actual),f.suggested_fix?JSON.stringify(f.suggested_fix):null,Math.max(0,Math.min(1,f.confidence)),existing?String(existing.detected_at):ts,ts).run();}

// Anwesenheit entsteht rueckwaerts: der Nachweis wird nach dem Unterricht geschrieben, nicht davor.
// Deshalb schaut dieser Teil des Scans zurueck statt nach vorn, und deshalb braucht er eigene
// Zeitgrenzen.
// LOOKBACK 180 Tage: der Zeitraum, den eine Pruefung des Kostentraegers ueblicherweise zieht - und
//   zugleich der Deckel auf der gelesenen Zeilenmenge, damit der Scan in einen Worker-Aufruf passt.
// ENTRY_GRACE 1 Tag: Anwesenheit wird im Tagesbetrieb oft erst am Abend eingetragen. Erst danach
//   ist eine Luecke eine Luecke. Dieselbe Frist gilt schon fuer fehlende Klassenbuch-Sitzungen.
// LATE 14 Tage: die Schwelle fuer Nacherfassung ist keine Geschmacksfrage. Anwesenheit wird
//   monatlich abgerechnet und der Monat kurz nach seinem Ende gemeldet. Wer eine Anwesenheit mehr
//   als zwei Wochen spaeter eintraegt, aendert einen Beleg, der beim Kostentraeger schon liegt, und
//   stuetzt ihn auf eine Erinnerung, die niemand mehr pruefen kann. Der normale Tagesbetrieb
//   (Krankheit der Lehrkraft, Vertretung, Nachtrag ueber ein Wochenende) bleibt darunter - deshalb
//   ist die Schwelle bewusst nicht enger gewaehlt.
// FINDING_LIMIT 50 je Pruefung: jeder Befund kostet zwei Unteranfragen, die Plattform erlaubt 1000
//   je Aufruf, und mehr als ein paar Dutzend gleichartige Befunde arbeitet ohnehin niemand ab. Der
//   Rest kommt im naechsten Lauf.
const ATTENDANCE_LOOKBACK_DAYS=180,ATTENDANCE_ENTRY_GRACE_DAYS=1,ATTENDANCE_LATE_DAYS=14,ATTENDANCE_FINDING_LIMIT=50;
function daysAgoIso(days:number){return new Date(Date.now()-days*86400000).toISOString();}

export async function scanTenantConsistency(env:Env,tenantId:string){
  systemAuth(tenantId);const seen=new Set<string>(),now=nowIso();
  const absent=await rows(env,`SELECT l.id lesson_id,l.course_id,l.teacher_id,t.name teacher_name,l.starts_at,l.ends_at,u.id block_id,u.starts_at block_start,u.ends_at block_end,u.source absence_source FROM lessons l JOIN teacher_unavailability u ON u.tenant_id=l.tenant_id AND u.teacher_id=l.teacher_id AND u.starts_at<l.ends_at AND u.ends_at>l.starts_at LEFT JOIN teachers t ON t.tenant_id=l.tenant_id AND t.id=l.teacher_id WHERE l.tenant_id=? AND l.ends_at>=?`,[tenantId,now]);
  // Der Befund nennt Person, Zeitraum und Art der Abwesenheit - nicht den Freitextgrund:
  // bei Krankheit minimiert ihn eine Datenbankregel ohnehin, bei anderen Quellen kann er
  // Gesundheitsangaben enthalten, die in einem Konsistenzbefund nichts zu suchen haben.
  for(const x of absent)await upsert(env,tenantId,{key:`lesson-absent-teacher:${x.lesson_id}:${x.block_id}`,course_id:String(x.course_id),category:'staffing',severity:'high',title:'Unterricht liegt in einer Dozenten-Abwesenheit',expected:{teacher_available:true},actual:{lesson_id:x.lesson_id,teacher_id:x.teacher_id,teacher_name:x.teacher_name,lesson_start:x.starts_at,lesson_end:x.ends_at,unavailability_id:x.block_id,block_start:x.block_start,block_end:x.block_end,absence_source:x.absence_source},suggested_fix:{scenario_type:'teacher_absence',input:{teacher_id:x.teacher_id,starts_at:x.block_start,ends_at:x.block_end}},confidence:1},seen);

  const selfStudy=await rows(env,"SELECT a.id,a.course_id,a.lesson_id,a.activity_type,a.attendance_expected FROM instruction_activity_details a WHERE a.tenant_id=? AND a.activity_type LIKE 'self_study_%' AND a.attendance_expected=1",[tenantId]);
  for(const x of selfStudy)await upsert(env,tenantId,{key:`selfstudy-attendance:${x.id}`,course_id:String(x.course_id),category:'learning_mode',severity:'medium',title:'Selbstlernphase erwartet widersprüchlich Präsenzanwesenheit',expected:{attendance_expected:0},actual:{attendance_expected:1,activity_type:x.activity_type},suggested_fix:{scenario_type:'self_study_need',input:{course_id:x.course_id,lesson_id:x.lesson_id,desired_attendance_expected:0}},confidence:.98},seen);

  const missingSessions=await rows(env,`SELECT l.id,l.course_id,l.starts_at,l.ends_at,s.name subject_name FROM lessons l LEFT JOIN subjects s ON s.id=l.subject_id AND s.tenant_id=l.tenant_id WHERE l.tenant_id=? AND l.ends_at<datetime('now','-1 day') AND l.ends_at>=datetime('now','-180 day') AND NOT EXISTS(SELECT 1 FROM attendance_sessions a WHERE a.tenant_id=l.tenant_id AND a.course_id=l.course_id AND a.source_ref=l.id)`,[tenantId]);
  for(const x of missingSessions)await upsert(env,tenantId,{key:`missing-session:${x.id}`,course_id:String(x.course_id),category:'proof_chain',severity:'medium',title:'Vergangene Unterrichtseinheit hat keine Klassenbuch-Sitzung',expected:{attendance_session:true},actual:{lesson_id:x.id,starts_at:x.starts_at,ends_at:x.ends_at},suggested_fix:{type:'create_session_from_lesson',lesson_id:x.id,requires_review:true},confidence:.99},seen);

  const missingCurriculum=await rows(env,`SELECT s.id session_id,s.course_id,s.starts_at,cb.topic FROM attendance_sessions s JOIN classbook_entries cb ON cb.session_id=s.id AND cb.tenant_id=s.tenant_id WHERE s.tenant_id=? AND cb.completed=1 AND NOT EXISTS(SELECT 1 FROM curriculum_session_links c WHERE c.tenant_id=s.tenant_id AND c.course_id=s.course_id AND c.session_id=s.id)`,[tenantId]);
  for(const x of missingCurriculum)await upsert(env,tenantId,{key:`classbook-no-curriculum:${x.session_id}`,course_id:String(x.course_id),category:'curriculum',severity:'medium',title:'Abgeschlossener Klassenbucheintrag ist keinem Lehrplanpunkt zugeordnet',expected:{curriculum_link:true},actual:{session_id:x.session_id,topic:x.topic},suggested_fix:{type:'review_curriculum_mapping',session_id:x.session_id},confidence:.95},seen);

  const brokenReport=await rows(env,`SELECT e.id,e.period_id,e.source_id,p.course_id,e.entry_date FROM report_book_entries e JOIN report_book_periods p ON p.id=e.period_id AND p.tenant_id=e.tenant_id WHERE e.tenant_id=? AND e.source_type='lesson' AND e.source_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM lessons l WHERE l.tenant_id=e.tenant_id AND l.id=e.source_id)`,[tenantId]);
  for(const x of brokenReport)await upsert(env,tenantId,{key:`reportbook-broken-lesson:${x.id}`,course_id:String(x.course_id),category:'proof_chain',severity:'high',title:'Berichtsheft verweist auf nicht vorhandenen Unterrichtstermin',expected:{lesson_reference_valid:true},actual:{entry_id:x.id,source_id:x.source_id,entry_date:x.entry_date},suggested_fix:{type:'review_report_book_source',entry_id:x.id,requires_participant_review:true},confidence:1},seen);

  const outside=await rows(env,`SELECT l.id,l.course_id,l.starts_at,l.ends_at,c.start_date,c.end_date FROM lessons l JOIN courses c ON c.id=l.course_id AND c.tenant_id=l.tenant_id WHERE l.tenant_id=? AND ((c.start_date IS NOT NULL AND substr(l.starts_at,1,10)<c.start_date) OR (c.end_date IS NOT NULL AND substr(l.starts_at,1,10)>c.end_date))`,[tenantId]);
  for(const x of outside)await upsert(env,tenantId,{key:`lesson-outside-course:${x.id}`,course_id:String(x.course_id),category:'schedule',severity:'high',title:'Unterricht liegt außerhalb des Kurszeitraums',expected:{start_date:x.start_date,end_date:x.end_date},actual:{lesson_id:x.id,starts_at:x.starts_at,ends_at:x.ends_at},suggested_fix:{scenario_type:'schedule_rebalance',input:{course_id:x.course_id,lesson_id:x.id}},confidence:1},seen);

  const roomMismatch=await rows(env,`SELECT l.id lesson_id,l.course_id,l.room,r.id reserved_resource_id,r.name reserved_room FROM lessons l JOIN lesson_resource_reservations rr ON rr.tenant_id=l.tenant_id AND rr.lesson_id=l.id JOIN planning_resources r ON r.id=rr.resource_id AND r.tenant_id=rr.tenant_id AND r.resource_type='room' WHERE l.tenant_id=? AND l.room IS NOT NULL AND trim(l.room)<>'' AND lower(trim(l.room)) NOT IN (lower(trim(r.name)),lower(trim(COALESCE(r.code,''))))`,[tenantId]);
  for(const x of roomMismatch)await upsert(env,tenantId,{key:`room-reservation-mismatch:${x.lesson_id}:${x.reserved_resource_id}`,course_id:String(x.course_id),category:'resource',severity:'medium',title:'Stundenplanraum und reservierter Raum widersprechen sich',expected:{lesson_room:x.room},actual:{reserved_room:x.reserved_room,reserved_resource_id:x.reserved_resource_id},suggested_fix:{scenario_type:'room_outage',input:{resource_id:x.reserved_resource_id,lesson_id:x.lesson_id},requires_review:true},confidence:.9},seen);

  // Die drei Widersprueche, die ein eingeworfener Stundenplan mitbringt und die bisher niemand
  // sah: dieselbe Dozentin zweimal zur selben Zeit, derselbe Raum zweimal zur selben Zeit, und
  // Unterricht in einem Raum, der fuer diese Zeit gesperrt ist. Geprueft wird auf dem wirklich
  // veroeffentlichten Unterricht - die Planpruefung greift nur in einem Stundenplanentwurf und
  // laesst importierte Stunden deshalb unberuehrt.
  const teacherClash=await rows(env,`SELECT a.id a_id,b.id b_id,a.course_id,b.course_id b_course_id,a.teacher_id,t.name teacher_name,a.starts_at,a.ends_at,b.starts_at b_starts_at,b.ends_at b_ends_at FROM lessons a JOIN lessons b ON b.tenant_id=a.tenant_id AND b.teacher_id=a.teacher_id AND b.id>a.id AND a.starts_at<b.ends_at AND b.starts_at<a.ends_at LEFT JOIN teachers t ON t.tenant_id=a.tenant_id AND t.id=a.teacher_id WHERE a.tenant_id=? AND a.teacher_id IS NOT NULL AND a.ends_at>=?`,[tenantId,now]);
  for(const x of teacherClash)await upsert(env,tenantId,{key:`lesson-teacher-overlap:${x.a_id}:${x.b_id}`,course_id:String(x.course_id),category:'staffing',severity:'high',title:'Dozent/in ist zur selben Zeit doppelt verplant',expected:{teacher_single_booking:true},actual:{teacher_id:x.teacher_id,teacher_name:x.teacher_name,lesson_id:x.a_id,other_lesson_id:x.b_id,other_course_id:x.b_course_id,starts_at:x.starts_at,ends_at:x.ends_at,other_starts_at:x.b_starts_at,other_ends_at:x.b_ends_at},suggested_fix:{scenario_type:'teacher_absence',input:{teacher_id:x.teacher_id,starts_at:x.starts_at,ends_at:x.ends_at},requires_review:true},confidence:1},seen);

  const roomClash=await rows(env,`SELECT a.id a_id,b.id b_id,a.course_id,b.course_id b_course_id,a.room,a.starts_at,a.ends_at,b.starts_at b_starts_at,b.ends_at b_ends_at FROM lessons a JOIN lessons b ON b.tenant_id=a.tenant_id AND b.id>a.id AND lower(trim(b.room))=lower(trim(a.room)) AND a.starts_at<b.ends_at AND b.starts_at<a.ends_at WHERE a.tenant_id=? AND a.room IS NOT NULL AND trim(a.room)<>'' AND a.ends_at>=?`,[tenantId,now]);
  for(const x of roomClash)await upsert(env,tenantId,{key:`lesson-room-overlap:${x.a_id}:${x.b_id}`,course_id:String(x.course_id),category:'resource',severity:'high',title:'Raum ist zur selben Zeit doppelt belegt',expected:{room_single_booking:true},actual:{room:x.room,lesson_id:x.a_id,other_lesson_id:x.b_id,other_course_id:x.b_course_id,starts_at:x.starts_at,ends_at:x.ends_at,other_starts_at:x.b_starts_at,other_ends_at:x.b_ends_at},suggested_fix:{scenario_type:'room_outage',input:{lesson_id:x.a_id,room:x.room},requires_review:true},confidence:1},seen);

  const roomBlocked=await rows(env,`SELECT l.id lesson_id,l.course_id,l.room,l.starts_at,l.ends_at,u.id block_id,u.starts_at block_start,u.ends_at block_end,u.reason,r.id resource_id FROM lessons l JOIN planning_resources r ON r.tenant_id=l.tenant_id AND r.resource_type='room' AND lower(trim(l.room)) IN (lower(trim(r.name)),lower(trim(COALESCE(r.code,'')))) JOIN planning_resource_unavailability u ON u.tenant_id=l.tenant_id AND u.resource_id=r.id AND u.starts_at<l.ends_at AND u.ends_at>l.starts_at WHERE l.tenant_id=? AND l.room IS NOT NULL AND trim(l.room)<>'' AND l.ends_at>=?`,[tenantId,now]);
  for(const x of roomBlocked)await upsert(env,tenantId,{key:`lesson-room-blocked:${x.lesson_id}:${x.block_id}`,course_id:String(x.course_id),category:'resource',severity:'high',title:'Unterricht liegt in einer Raumsperrung',expected:{room_available:true},actual:{room:x.room,lesson_id:x.lesson_id,starts_at:x.starts_at,ends_at:x.ends_at,unavailability_id:x.block_id,block_start:x.block_start,block_end:x.block_end,reason:x.reason},suggested_fix:{scenario_type:'room_outage',input:{resource_id:x.resource_id,lesson_id:x.lesson_id},requires_review:true},confidence:1},seen);

  // Pruefungen waren bisher in keiner dieser Pruefungen enthalten: eine Klausur in einem
  // gesperrten Raum oder in einem Raum, in dem gleichzeitig Unterricht stattfindet, fiel niemandem
  // auf. Der Zeitraum einer Pruefung ist [starts_at, ends_at]; fehlt ends_at, gilt der Beginn
  // als Zeitpunkt - es wird keine Dauer erfunden.
  const examBlocked=await rows(env,`SELECT e.id exam_id,e.course_id,e.title,e.room,e.starts_at,e.ends_at,u.id block_id,u.starts_at block_start,u.ends_at block_end,u.reason,r.id resource_id
    FROM exams e JOIN planning_resources r ON r.tenant_id=e.tenant_id AND r.resource_type='room' AND lower(trim(e.room)) IN (lower(trim(r.name)),lower(trim(COALESCE(r.code,''))))
    JOIN planning_resource_unavailability u ON u.tenant_id=e.tenant_id AND u.resource_id=r.id
      AND u.ends_at>e.starts_at AND (e.ends_at IS NULL AND u.starts_at<=e.starts_at OR e.ends_at IS NOT NULL AND u.starts_at<e.ends_at)
    WHERE e.tenant_id=? AND e.room IS NOT NULL AND trim(e.room)<>'' AND COALESCE(e.ends_at,e.starts_at)>=?`,[tenantId,now]);
  for(const x of examBlocked)await upsert(env,tenantId,{key:`exam-room-blocked:${x.exam_id}:${x.block_id}`,course_id:String(x.course_id),category:'resource',severity:'high',title:'Prüfung liegt in einer Raumsperrung',expected:{room_available:true},actual:{room:x.room,exam_id:x.exam_id,exam_title:x.title,starts_at:x.starts_at,ends_at:x.ends_at,unavailability_id:x.block_id,block_start:x.block_start,block_end:x.block_end,reason:x.reason},suggested_fix:{scenario_type:'exam_shift',input:{resource_id:x.resource_id,exam_id:x.exam_id},requires_review:true},confidence:1},seen);

  const examRoomClash=await rows(env,`SELECT e.id exam_id,e.course_id,e.title,e.room,e.starts_at,e.ends_at,l.id lesson_id,l.course_id lesson_course_id,l.starts_at lesson_starts_at,l.ends_at lesson_ends_at
    FROM exams e JOIN lessons l ON l.tenant_id=e.tenant_id AND lower(trim(l.room))=lower(trim(e.room))
      AND l.ends_at>e.starts_at AND (e.ends_at IS NULL AND l.starts_at<=e.starts_at OR e.ends_at IS NOT NULL AND l.starts_at<e.ends_at)
    WHERE e.tenant_id=? AND e.room IS NOT NULL AND trim(e.room)<>'' AND COALESCE(e.ends_at,e.starts_at)>=?`,[tenantId,now]);
  for(const x of examRoomClash)await upsert(env,tenantId,{key:`exam-room-overlap:${x.exam_id}:${x.lesson_id}`,course_id:String(x.course_id),category:'resource',severity:'high',title:'Prüfung und Unterricht belegen denselben Raum',expected:{room_single_booking:true},actual:{room:x.room,exam_id:x.exam_id,exam_title:x.title,starts_at:x.starts_at,ends_at:x.ends_at,lesson_id:x.lesson_id,lesson_course_id:x.lesson_course_id,lesson_starts_at:x.lesson_starts_at,lesson_ends_at:x.lesson_ends_at},suggested_fix:{scenario_type:'exam_shift',input:{exam_id:x.exam_id,lesson_id:x.lesson_id},requires_review:true},confidence:1},seen);

  const duplicates=await rows(env,`SELECT a.id a_id,b.id b_id,a.course_id,a.starts_at,a.ends_at,a.subject FROM attendance_sessions a JOIN attendance_sessions b ON b.tenant_id=a.tenant_id AND b.course_id=a.course_id AND b.id>a.id AND b.starts_at=a.starts_at AND b.ends_at=a.ends_at AND lower(COALESCE(b.subject,''))=lower(COALESCE(a.subject,'')) WHERE a.tenant_id=? AND (a.source='import' OR b.source='import')`,[tenantId]);
  for(const x of duplicates)await upsert(env,tenantId,{key:`possible-import-duplicate:${x.a_id}:${x.b_id}`,course_id:String(x.course_id),category:'legacy_import',severity:'low',title:'Möglicher Doppelbestand aus Altimport und Systemdaten',expected:{single_session:true},actual:{session_ids:[x.a_id,x.b_id],starts_at:x.starts_at,subject:x.subject},suggested_fix:{type:'compare_import_and_native',session_ids:[x.a_id,x.b_id],never_auto_delete:true},confidence:.8},seen);

  // ---------------------------------------------------------------------------------------------
  // Anwesenheit. Bis hierher fasste keine Pruefung attendance_records an. Falsche Fehlzeiten und
  // nachtraeglich erfasste Anwesenheit fielen dem Traeger deshalb erst auf, wenn ein Pruefer des
  // Kostentraegers sie fand - und dann ist es teuer: bei einer gefoerderten Massnahme ist die
  // Anwesenheitsliste kein Nebenprotokoll, sondern der Beleg, aus dem der einzelne Tag abgerechnet
  // wird. Jeder Widerspruch darin ist eine Rueckforderung im Wartestand.
  //
  // Alle fuenf Pruefungen laufen als je EINE Abfrage ueber alle Kurse des Traegers - nicht eine je
  // Kurs - und sind doppelt gedeckelt: nach hinten ueber das Zeitfenster, in der Menge ueber
  // ATTENDANCE_FINDING_LIMIT. Grund ist die Plattformgrenze von 1000 Unteranfragen je Aufruf:
  // attendance_records ist die groesste Tabelle des Systems (eine Zeile je Person und Termin) und
  // jeder Befund kostet zwei Unteranfragen (Nachschlagen und Schreiben). Die Sortierung ist fest,
  // damit zwei Laeufe bei mehr Treffern als Deckel dieselben Befunde oben haben und nicht
  // abwechselnd verschiedene melden - sonst wuerde ein Befund im naechsten Lauf faelschlich als
  // erledigt geschlossen.
  const attFrom=daysAgoIso(ATTENDANCE_LOOKBACK_DAYS),attFromDate=attFrom.slice(0,10),attGrace=daysAgoIso(ATTENDANCE_ENTRY_GRACE_DAYS);

  // 1. Der Unterricht gilt als gehalten, aber niemand wurde erfasst. Das ist der teuerste Fall
  // ueberhaupt: der Termin steht in jeder Auswertung als stattgefunden, ein Beleg dafuer, wer
  // anwesend war, existiert nicht. Ein Tag Frist, weil Anwesenheit im Tagesbetrieb oft erst am
  // Abend eingetragen wird - dieselbe Frist gilt schon fuer fehlende Klassenbuch-Sitzungen.
  const emptyHeld=await rows(env,`SELECT s.id session_id,s.course_id,s.session_date,s.starts_at,s.ends_at,s.subject,s.source FROM attendance_sessions s WHERE s.tenant_id=? AND s.status='held' AND s.ends_at<? AND s.ends_at>=? AND NOT EXISTS(SELECT 1 FROM attendance_records r WHERE r.tenant_id=s.tenant_id AND r.session_id=s.id) ORDER BY s.ends_at DESC,s.id LIMIT ${ATTENDANCE_FINDING_LIMIT}`,[tenantId,attGrace,attFrom]);
  for(const x of emptyHeld)await upsert(env,tenantId,{key:`attendance-session-empty:${x.session_id}`,course_id:String(x.course_id),category:'attendance',severity:'high',title:'Gehaltener Unterricht ohne jede Anwesenheitserfassung',expected:{attendance_recorded:true},actual:{session_id:x.session_id,session_date:x.session_date,starts_at:x.starts_at,ends_at:x.ends_at,subject:x.subject,source:x.source,recorded_rows:0},suggested_fix:{type:'record_attendance_for_session',session_id:x.session_id,requires_review:true},confidence:1},seen);

  // 2. Unentschuldigt erfasst, obwohl fuer denselben Tag eine genehmigte Abwesenheitsmeldung
  // vorliegt. Das entsteht, wenn nach der Genehmigung noch von Hand erfasst wird. An genau diesem
  // Unterschied haengt bei gefoerderten Massnahmen die Abrechenbarkeit des Tages, deshalb hoch.
  // Der Befund nennt Person, Zeitraum und Art der Meldung - nicht den Freitextgrund: dort stehen
  // regelmaessig Gesundheitsangaben, die in einem Konsistenzbefund nichts zu suchen haben.
  const unexcused=await rows(env,`SELECT r.session_id,r.user_id,r.course_id,r.recorded_at,s.session_date,n.id notice_id,n.kind notice_kind,n.starts_on,n.ends_on,n.reviewed_at FROM attendance_records r JOIN attendance_sessions s ON s.tenant_id=r.tenant_id AND s.id=r.session_id JOIN absence_notices n ON n.tenant_id=r.tenant_id AND n.user_id=r.user_id AND n.course_id=r.course_id AND n.status='accepted' AND n.starts_on<=s.session_date AND n.ends_on>=s.session_date WHERE r.tenant_id=? AND r.status='unexcused_absent' AND s.session_date>=? ORDER BY s.session_date DESC,r.session_id,r.user_id LIMIT ${ATTENDANCE_FINDING_LIMIT}`,[tenantId,attFromDate]);
  for(const x of unexcused)await upsert(env,tenantId,{key:`attendance-unexcused-despite-notice:${x.session_id}:${x.user_id}`,course_id:String(x.course_id),category:'attendance',severity:'high',title:'Unentschuldigt trotz genehmigter Abwesenheitsmeldung',expected:{status:'excused_absent'},actual:{session_id:x.session_id,user_id:x.user_id,session_date:x.session_date,recorded_status:'unexcused_absent',recorded_at:x.recorded_at,notice_id:x.notice_id,notice_kind:x.notice_kind,notice_from:x.starts_on,notice_to:x.ends_on,notice_reviewed_at:x.reviewed_at},suggested_fix:{type:'review_attendance_status',session_id:x.session_id,user_id:x.user_id,proposed_status:'excused_absent',requires_review:true},confidence:.97},seen);

  // 3. Anwesenheit an einem Tag, an dem kein Unterricht stattfinden durfte. Eine Sperrung ohne
  // blocks_teaching (etwa ein Pruefungsblock) ist ausdruecklich kein Befund - gesperrt ist dort nur
  // die Planung, nicht der Unterricht. Gezaehlt wird je Sitzung und Sperrung, nicht je Person:
  // sonst erzeugt ein einziger falscher Feiertag vierzig gleichlautende Befunde.
  const blackoutAttendance=await rows(env,`SELECT s.id session_id,s.course_id,s.session_date,s.starts_at,s.ends_at,b.id blackout_id,b.title blackout_title,b.blackout_type,b.starts_at block_start,b.ends_at block_end,COUNT(r.user_id) recorded_rows,SUM(CASE WHEN r.status IN ('present','remote_present','late') THEN 1 ELSE 0 END) present_rows FROM attendance_sessions s JOIN planning_blackouts b ON b.tenant_id=s.tenant_id AND b.blocks_teaching=1 AND (b.course_id IS NULL OR b.course_id=s.course_id) AND b.starts_at<s.ends_at AND b.ends_at>s.starts_at JOIN attendance_records r ON r.tenant_id=s.tenant_id AND r.session_id=s.id WHERE s.tenant_id=? AND s.ends_at>=? GROUP BY s.id,b.id ORDER BY s.ends_at DESC,s.id,b.id LIMIT ${ATTENDANCE_FINDING_LIMIT}`,[tenantId,attFrom]);
  for(const x of blackoutAttendance)await upsert(env,tenantId,{key:`attendance-on-blackout:${x.session_id}:${x.blackout_id}`,course_id:String(x.course_id),category:'attendance',severity:'high',title:'Anwesenheit an einem Tag ohne erlaubten Unterricht',expected:{teaching_allowed:true},actual:{session_id:x.session_id,session_date:x.session_date,starts_at:x.starts_at,ends_at:x.ends_at,blackout_id:x.blackout_id,blackout_title:x.blackout_title,blackout_type:x.blackout_type,block_start:x.block_start,block_end:x.block_end,recorded_rows:Number(x.recorded_rows||0),present_rows:Number(x.present_rows||0)},suggested_fix:{type:'compare_blackout_and_attendance',session_id:x.session_id,blackout_id:x.blackout_id,requires_review:true},confidence:.9},seen);

  // 4. Nacherfassung. Gezaehlt wird je Sitzung: eine nachgetragene Liste ist ein Vorgang, nicht
  // zwanzig. Die Zeitdifferenz ueber julianday statt ueber Zeichenkettenvergleich, weil die
  // Zeitstempel je nach Herkunft mit und ohne Zonenkennzeichen vorliegen und ein Vergleich als
  // Text dort um Stunden danebenliegt. Ein unlesbarer Zeitstempel ergibt NULL und damit keinen
  // Befund - lieber eine Luecke als ein erfundener Vorwurf.
  const lateRecording=await rows(env,`SELECT r.session_id,r.course_id,s.session_date,s.ends_at,COUNT(*) recorded_rows,MIN(r.recorded_at) first_recorded_at,MAX(r.recorded_at) last_recorded_at,MAX(julianday(r.recorded_at)-julianday(s.ends_at)) max_delay_days FROM attendance_records r JOIN attendance_sessions s ON s.tenant_id=r.tenant_id AND s.id=r.session_id WHERE r.tenant_id=? AND s.ends_at>=? AND julianday(r.recorded_at)-julianday(s.ends_at)>? GROUP BY r.session_id ORDER BY s.ends_at DESC,r.session_id LIMIT ${ATTENDANCE_FINDING_LIMIT}`,[tenantId,attFrom,ATTENDANCE_LATE_DAYS]);
  for(const x of lateRecording)await upsert(env,tenantId,{key:`attendance-late-recording:${x.session_id}`,course_id:String(x.course_id),category:'attendance',severity:'medium',title:'Anwesenheit erst lange nach dem Unterricht erfasst',expected:{recorded_within_days:ATTENDANCE_LATE_DAYS},actual:{session_id:x.session_id,session_date:x.session_date,ends_at:x.ends_at,recorded_rows:Number(x.recorded_rows||0),first_recorded_at:x.first_recorded_at,last_recorded_at:x.last_recorded_at,delay_days:Math.round(Number(x.max_delay_days||0))},suggested_fix:{type:'confirm_late_attendance_record',session_id:x.session_id,requires_review:true},confidence:.9},seen);

  // 5. Anwesenheit fuer eine Person ohne aktive Kurszugehoerigkeit. "Aktiv" heisst hier genau das,
  // was das Klassenbuch beim Erfassen prueft (Teilnehmerrolle, aktives Konto, aktive Zugehoerigkeit
  // zum Traeger) - eine zweite, abweichende Definition waere schlimmer als keine Pruefung. Gezaehlt
  // wird je Kurs und Person, nicht je Termin: es ist ein Vorgang, kein Befund je Unterrichtstag.
  const notEnrolled=await rows(env,`SELECT r.course_id,r.user_id,COUNT(*) recorded_rows,MIN(s.session_date) first_session_date,MAX(s.session_date) last_session_date FROM attendance_records r JOIN attendance_sessions s ON s.tenant_id=r.tenant_id AND s.id=r.session_id WHERE r.tenant_id=? AND s.session_date>=? AND NOT EXISTS(SELECT 1 FROM memberships m JOIN users u ON u.id=m.user_id JOIN tenant_users tu ON tu.tenant_id=m.tenant_id AND tu.user_id=m.user_id WHERE m.tenant_id=r.tenant_id AND m.course_id=r.course_id AND m.user_id=r.user_id AND m.role='participant' AND u.status='active' AND tu.status='active') GROUP BY r.course_id,r.user_id ORDER BY MAX(s.session_date) DESC,r.course_id,r.user_id LIMIT ${ATTENDANCE_FINDING_LIMIT}`,[tenantId,attFromDate]);
  for(const x of notEnrolled)await upsert(env,tenantId,{key:`attendance-user-not-enrolled:${x.course_id}:${x.user_id}`,course_id:String(x.course_id),category:'attendance',severity:'medium',title:'Anwesenheit für eine Person ohne aktive Kurszugehörigkeit',expected:{active_membership:true},actual:{course_id:x.course_id,user_id:x.user_id,recorded_rows:Number(x.recorded_rows||0),first_session_date:x.first_session_date,last_session_date:x.last_session_date},suggested_fix:{type:'review_course_membership',course_id:x.course_id,user_id:x.user_id,requires_review:true},confidence:.9},seen);

  const ts=nowIso(),open=await rows<{id:string;finding_key:string}>(env,"SELECT id,finding_key FROM education_consistency_findings WHERE tenant_id=? AND status IN ('open','accepted')",[tenantId]);for(const teil of inBloecken(open.filter(f=>!seen.has(String(f.finding_key))),50))if(teil.length)await env.DB.batch(teil.map(f=>env.DB.prepare("UPDATE education_consistency_findings SET status='resolved',resolved_at=?,updated_at=? WHERE tenant_id=? AND id=?").bind(ts,ts,tenantId,f.id)));
  return{tenant_id:tenantId,findings_seen:seen.size,open_high:Number((await env.DB.prepare("SELECT COUNT(*) n FROM education_consistency_findings WHERE tenant_id=? AND status='open' AND severity IN ('high','critical')").bind(tenantId).first<{n:number}>())?.n||0)};
}

// Ein Durchlauf je Mandant kostet ein Vielfaches an Abfragen. Frueher lief die Pruefung in EINEM
// Aufruf ueber ALLE Mandanten - ab wenigen Dutzend Traegern war die Grenze der Plattform von 1000
// Unteranfragen erreicht, der Lauf brach ab, und die zuletzt einsortierten Mandanten wurden nie
// geprueft, ohne dass es irgendwo auffiel. Jetzt kommt je Lauf eine feste Zahl an die Reihe, und
// zwar die am laengsten nicht geprueften zuerst.
export const KONSISTENZ_MANDANTEN_JE_LAUF=8;
export async function runConsistencyAllTenants(env:Env,maxMandanten=KONSISTENZ_MANDANTEN_JE_LAUF){
  const gesamt=Number((await env.DB.prepare("SELECT COUNT(*) n FROM tenants WHERE status='active'").first<{n:number}>())?.n||0);
  const tenants=await rows<{id:string}>(env,`SELECT t.id FROM tenants t LEFT JOIN (SELECT tenant_id,MAX(updated_at) zuletzt FROM education_consistency_findings GROUP BY tenant_id) f ON f.tenant_id=t.id
    WHERE t.status='active' ORDER BY COALESCE(f.zuletzt,'') ASC,t.id LIMIT ?`,[Math.max(1,maxMandanten)]);
  const results:Record<string,unknown>[]=[];
  for(const t of tenants){try{results.push(await scanTenantConsistency(env,String(t.id)));}catch(e){results.push({tenant_id:t.id,error:safeErrorCode(e)});}}
  return{tenants:tenants.length,tenants_total:gesamt,offen:Math.max(0,gesamt-tenants.length),results};}

export async function listConsistencyFindings(env:Env,auth:CoreAuthContext,tenantId:string,status='open'){
  if(!canRead(auth)||!auth.isPlatformAdmin&&!auth.tenantIds.includes(tenantId))throw new Error('FORBIDDEN_CONSISTENCY_READ');let sql='SELECT * FROM education_consistency_findings WHERE tenant_id=?',args:unknown[]=[tenantId];if(status!=='all'){sql+=' AND status=?';args.push(status);}if(!auth.isPlatformAdmin&&auth.role!=='tenant_admin'){if(!auth.courseIds.length)return[];sql+=` AND (course_id IS NULL OR course_id IN (${auth.courseIds.map(()=>'?').join(',')}))`;args.push(...auth.courseIds);}sql+=" ORDER BY CASE severity WHEN 'critical' THEN 5 WHEN 'high' THEN 4 WHEN 'medium' THEN 3 WHEN 'low' THEN 2 ELSE 1 END DESC,updated_at DESC LIMIT 500";return((await env.DB.prepare(sql).bind(...args).all<Record<string,unknown>>()).results??[]).map(x=>({...x,expected:x.expected_json?JSON.parse(String(x.expected_json)):null,actual:x.actual_json?JSON.parse(String(x.actual_json)):null,suggested_fix:x.suggested_fix_json?JSON.parse(String(x.suggested_fix_json)):null}));
}
export async function updateConsistencyFinding(env:Env,auth:CoreAuthContext,tenantId:string,findingId:string,status:string){if(auth.isPlatformAdmin||auth.role!=='tenant_admin')throw new Error('TENANT_ADMIN_REQUIRED');if(!['open','accepted','rejected','resolved'].includes(status))throw new Error('CONSISTENCY_STATUS_INVALID');const ts=nowIso();await env.DB.prepare('UPDATE education_consistency_findings SET status=?,resolved_at=?,updated_at=? WHERE tenant_id=? AND id=?').bind(status,status==='resolved'?ts:null,ts,tenantId,findingId).run();await audit(env.DB,auth.userId,'education.consistency_status_updated',tenantId,undefined,'education_consistency_finding',findingId,{status});return{finding_id:findingId,status};}

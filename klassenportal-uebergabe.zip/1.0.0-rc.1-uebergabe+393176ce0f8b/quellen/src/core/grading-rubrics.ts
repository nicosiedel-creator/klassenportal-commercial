import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireCourseAccess, requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Bewertungsraster und Erwartungshorizont (Master-Spec V2 §2.4).
//
// Die Zweitkorrektur aus 0125 ist ohne Raster nur eine zweite Meinung. Erst das Raster macht aus
// "38 von 50" eine begruendete Entscheidung, und erst dann laesst sich sagen, WO zwei Korrigierende
// auseinandergehen - naemlich bei einem bestimmten Kriterium und nicht "irgendwo".
//
// Zwei Regeln, die der Server durchsetzt und nicht bloss empfiehlt:
//  - Ein Raster, mit dem schon bewertet wurde, ist eingefroren. Wer es aendern koennte, aenderte
//    rueckwirkend die Begruendung einer bereits erteilten Note. Stattdessen: neue Fassung.
//  - Eine Rasterbewertung ist vollstaendig oder gar nicht. Ein halb ausgefuelltes Raster ist keine
//    Begruendung, sieht aber wie eine aus.

export const MAX_KRITERIEN=40;
export const MAX_STUFEN=10;
const clean=(v:unknown,n=500)=>safeString(v,n);
function manager(auth:CoreAuthContext,courseId:string){requireRole(auth,'class_admin');requireCourseAccess(auth,courseId,'class_admin');}
const rund=(n:number)=>Math.round(n*100)/100;

type KriteriumEingabe={title:string;erwartungshorizont:string|null;max_points:number;stufen:{label:string;beschreibung:string|null;points:number}[]};

function leseKriterien(input:Record<string,unknown>):KriteriumEingabe[]{
  const roh=Array.isArray(input.kriterien)?input.kriterien as Record<string,unknown>[]:[];
  if(!roh.length||roh.length>MAX_KRITERIEN)throw new Error('RUBRIC_CRITERIA_INVALID');
  return roh.map(k=>{
    const title=clean(k.title,200),max=Number(k.max_points);
    if(!title||!Number.isFinite(max)||max<=0||max>1000)throw new Error('RUBRIC_CRITERIA_INVALID');
    const stufenRoh=Array.isArray(k.stufen)?k.stufen as Record<string,unknown>[]:[];
    if(stufenRoh.length>MAX_STUFEN)throw new Error('RUBRIC_LEVELS_INVALID');
    const stufen=stufenRoh.map(s=>{
      const label=clean(s.label,120),p=Number(s.points);
      if(!label||!Number.isFinite(p)||p<0)throw new Error('RUBRIC_LEVELS_INVALID');
      // Eine Stufe, die mehr gibt als das Kriterium hergibt, waere ein Rechenfehler mit Folgen.
      if(p>max)throw new Error('RUBRIC_LEVEL_ABOVE_MAX');
      return{label,beschreibung:clean(s.beschreibung,2000)||null,points:p};
    });
    return{title,erwartungshorizont:clean(k.erwartungshorizont,4000)||null,max_points:max,stufen};
  });
}

export async function createRubric(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,input:Record<string,unknown>){
  manager(auth,courseId);
  const title=clean(input.title,200);
  if(!title)throw new Error('RUBRIC_TITLE_REQUIRED');
  const kriterien=leseKriterien(input);
  const rid=id('rub_'),ts=nowIso();
  const anweisungen=[env.DB.prepare('INSERT INTO grading_rubrics(id,tenant_id,course_id,title,beschreibung,status,vorgaenger_id,fassung,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
    .bind(rid,tenantId,courseId,title,clean(input.beschreibung,4000)||null,'entwurf',clean(input.vorgaenger_id,120)||null,Math.max(1,Math.trunc(Number(input.fassung??1))),auth.userId,ts,ts)];
  kriterien.forEach((k,i)=>{
    const kid=id('rkr_');
    anweisungen.push(env.DB.prepare('INSERT INTO rubric_criteria(id,rubric_id,tenant_id,title,erwartungshorizont,max_points,sort_order) VALUES(?,?,?,?,?,?,?)')
      .bind(kid,rid,tenantId,k.title,k.erwartungshorizont,k.max_points,i));
    k.stufen.forEach((s,j)=>anweisungen.push(env.DB.prepare('INSERT INTO rubric_levels(id,criterion_id,tenant_id,label,beschreibung,points,sort_order) VALUES(?,?,?,?,?,?,?)')
      .bind(id('rst_'),kid,tenantId,s.label,s.beschreibung,s.points,j)));
  });
  // Ein Aufruf, egal wie viele Kriterien und Stufen - sonst kostete ein grosses Raster hundert
  // Unteranfragen von tausend.
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'rubric.created',tenantId,courseId,'grading_rubric',rid,{kriterien:kriterien.length});
  return getRubric(env,auth,tenantId,courseId,rid);
}

export async function getRubric(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,rubricId:string){
  requireCourseAccess(auth,courseId);
  const rubrik=await env.DB.prepare('SELECT * FROM grading_rubrics WHERE id=? AND tenant_id=? AND course_id=?').bind(rubricId,tenantId,courseId).first<Record<string,unknown>>();
  if(!rubrik)throw new Error('RUBRIC_NOT_FOUND');
  const kriterien=(await env.DB.prepare('SELECT * FROM rubric_criteria WHERE rubric_id=? ORDER BY sort_order').bind(rubricId).all<Record<string,unknown>>()).results??[];
  // Alle Stufen aller Kriterien in EINER Abfrage statt einer je Kriterium.
  const stufen=(await env.DB.prepare('SELECT l.* FROM rubric_levels l JOIN rubric_criteria c ON c.id=l.criterion_id WHERE c.rubric_id=? ORDER BY c.sort_order,l.sort_order').bind(rubricId).all<Record<string,unknown>>()).results??[];
  const mitStufen=kriterien.map(k=>({...k,stufen:stufen.filter(s=>s.criterion_id===k.id)})) as (Record<string,unknown>&{stufen:Record<string,unknown>[]})[];
  return{rubrik,kriterien:mitStufen,summe_max:rund(kriterien.reduce((a,k)=>a+Number(k.max_points||0),0))};
}

export async function listRubrics(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  manager(auth,courseId);
  return (await env.DB.prepare('SELECT r.*,(SELECT COUNT(*) FROM rubric_criteria c WHERE c.rubric_id=r.id) AS kriterien,(SELECT COUNT(*) FROM rubric_assessments a WHERE a.rubric_id=r.id) AS bewertungen FROM grading_rubrics r WHERE r.tenant_id=? AND r.course_id=? ORDER BY r.status,r.title,r.fassung DESC')
    .bind(tenantId,courseId).all()).results??[];
}

async function schonBenutzt(env:Env,rubricId:string):Promise<boolean>{
  return !!await env.DB.prepare('SELECT 1 x FROM rubric_assessments WHERE rubric_id=? LIMIT 1').bind(rubricId).first();
}

export async function setRubricStatus(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,rubricId:string,status:string){
  manager(auth,courseId);
  if(!['entwurf','aktiv','archiviert'].includes(status))throw new Error('RUBRIC_STATUS_INVALID');
  // Zurueck in den Entwurf, nachdem damit bewertet wurde, hiesse: das Raster wieder aenderbar
  // machen und damit die Begruendung bereits erteilter Noten.
  if(status==='entwurf'&&await schonBenutzt(env,rubricId))throw new Error('RUBRIC_IN_USE');
  const ts=nowIso();
  const r=await env.DB.prepare('UPDATE grading_rubrics SET status=?,updated_at=? WHERE id=? AND tenant_id=? AND course_id=?').bind(status,ts,rubricId,tenantId,courseId).run();
  if(!r.meta?.changes)throw new Error('RUBRIC_NOT_FOUND');
  await audit(env.DB,auth.userId,'rubric.status_changed',tenantId,courseId,'grading_rubric',rubricId,{status});
  return{status};
}

/**
 * Neue Fassung eines benutzten Rasters.
 *
 * Der Weg, den ein eingefrorenes Raster laesst: die alte Fassung bleibt mit ihren Bewertungen
 * stehen, die neue faengt als Entwurf an. Beide sind ueber vorgaenger_id verbunden, damit spaeter
 * nachvollziehbar ist, dass es dieselbe Aufgabe in einer neuen Fassung ist.
 */
export async function reviseRubric(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,rubricId:string,input:Record<string,unknown>){
  manager(auth,courseId);
  const alt=await getRubric(env,auth,tenantId,courseId,rubricId);
  const kriterien=Array.isArray(input.kriterien)&&(input.kriterien as unknown[]).length
    ?input.kriterien
    :alt.kriterien.map(k=>({title:k.title,erwartungshorizont:k.erwartungshorizont,max_points:k.max_points,stufen:k.stufen.map(s=>({label:s.label,beschreibung:s.beschreibung,points:s.points}))}));
  return createRubric(env,auth,tenantId,courseId,{
    title:clean(input.title,200)||String(alt.rubrik.title),
    beschreibung:input.beschreibung??alt.rubrik.beschreibung,
    kriterien,
    vorgaenger_id:rubricId,
    fassung:Number(alt.rubrik.fassung||1)+1,
  });
}

/** Das Raster an eine Bewertungsposition haengen. Die Punktsummen muessen zusammenpassen. */
export async function attachRubricToItem(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,itemId:string,rubricId:string|null){
  manager(auth,courseId);
  const item=await env.DB.prepare('SELECT id,max_points FROM gradebook_items WHERE id=? AND tenant_id=? AND course_id=?').bind(itemId,tenantId,courseId).first<{id:string;max_points:number|null}>();
  if(!item)throw new Error('GRADEBOOK_ITEM_NOT_FOUND');
  if(rubricId){
    const r=await getRubric(env,auth,tenantId,courseId,rubricId);
    if(r.rubrik.status!=='aktiv')throw new Error('RUBRIC_NOT_ACTIVE');
    // Ein Raster ueber 60 Punkte an einer Aufgabe ueber 50 ergaebe Noten, die es nicht geben darf.
    if(item.max_points!==null&&item.max_points!==undefined&&rund(Number(item.max_points))!==r.summe_max)throw new Error('RUBRIC_POINTS_MISMATCH');
  }
  await env.DB.prepare('UPDATE gradebook_items SET rubric_id=?,updated_by=?,updated_at=? WHERE id=? AND tenant_id=?').bind(rubricId,auth.userId,nowIso(),itemId,tenantId).run();
  await audit(env.DB,auth.userId,'rubric.attached',tenantId,courseId,'gradebook_item',itemId,{rubric_id:rubricId});
  return{item_id:itemId,rubric_id:rubricId};
}

export type RasterEingabe={criterion_id:string;level_id?:string|null;points?:number|null;kommentar?:string|null};

/**
 * Eine Bewertung nach Raster abgeben.
 *
 * `rolle` trennt Erst- und Zweitkorrektur: beide fuellen dasselbe Raster, getrennt voneinander, und
 * genau daraus wird spaeter der Vergleich. Bei 'erstkorrektur' wird die Punktzahl in die Note
 * geschrieben - das Raster IST dann die Bewertung und nicht eine Notiz daneben.
 */
export async function assessWithRubric(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,input:Record<string,unknown>){
  manager(auth,courseId);
  const gegenstand=clean(input.gegenstand,40),bezugId=clean(input.bezug_id,120),rolle=clean(input.rolle,40)||'erstkorrektur';
  if(!['gradebook_score','quiz_attempt'].includes(gegenstand)||!bezugId)throw new Error('RUBRIC_SUBJECT_INVALID');
  if(!['erstkorrektur','zweitkorrektur'].includes(rolle))throw new Error('RUBRIC_ROLE_INVALID');
  const rubricId=clean(input.rubric_id,120);
  const r=await getRubric(env,auth,tenantId,courseId,rubricId);
  if(r.rubrik.status!=='aktiv')throw new Error('RUBRIC_NOT_ACTIVE');
  // WESSEN Arbeit hier bewertet wird, kommt aus der Quelle und nicht aus der Anfrage. Das prueft
  // nebenbei, dass es den Bezug ueberhaupt gibt und dass er zu diesem Kurs gehoert.
  const quelle=gegenstand==='gradebook_score'
    ?await env.DB.prepare('SELECT user_id FROM gradebook_scores WHERE id=? AND tenant_id=? AND course_id=?').bind(bezugId,tenantId,courseId).first<{user_id:string}>()
    :await env.DB.prepare('SELECT user_id FROM quiz_attempts WHERE id=? AND tenant_id=? AND course_id=?').bind(bezugId,tenantId,courseId).first<{user_id:string}>();
  if(!quelle)throw new Error('RUBRIC_SUBJECT_NOT_FOUND');
  const eingaben=Array.isArray(input.bewertungen)?input.bewertungen as RasterEingabe[]:[];
  const stufen=new Map<string,{criterion_id:string;points:number}>();
  for(const k of r.kriterien)for(const s of k.stufen)stufen.set(String(s.id),{criterion_id:String(k.id),points:Number(s.points)});
  const zeilen:{criterion_id:string;level_id:string|null;points:number;kommentar:string|null}[]=[];
  for(const k of r.kriterien){
    const e=eingaben.find(x=>String(x.criterion_id)===String(k.id));
    // Ein halb ausgefuelltes Raster ist keine Begruendung, sieht aber wie eine aus.
    if(!e)throw new Error('RUBRIC_INCOMPLETE');
    let punkte:number;
    let levelId:string|null=null;
    if(e.level_id){
      const s=stufen.get(String(e.level_id));
      if(!s||s.criterion_id!==String(k.id))throw new Error('RUBRIC_LEVEL_NOT_IN_CRITERION');
      levelId=String(e.level_id);punkte=s.points;
    }else{
      punkte=Number(e.points);
      if(!Number.isFinite(punkte)||punkte<0)throw new Error('RUBRIC_POINTS_INVALID');
    }
    if(punkte>Number(k.max_points))throw new Error('RUBRIC_CRITERION_ABOVE_MAX');
    zeilen.push({criterion_id:String(k.id),level_id:levelId,points:punkte,kommentar:clean(e.kommentar,2000)||null});
  }
  const gesamt=rund(zeilen.reduce((a,z)=>a+z.points,0));
  const ts=nowIso(),aid=id('rbw_');
  const anweisungen=[
    env.DB.prepare('DELETE FROM rubric_assessments WHERE tenant_id=? AND gegenstand=? AND bezug_id=? AND bewertet_von=?').bind(tenantId,gegenstand,bezugId,auth.userId),
    env.DB.prepare('INSERT INTO rubric_assessments(id,tenant_id,course_id,rubric_id,gegenstand,bezug_id,rolle,bewertete_person,bewertet_von,gesamtpunkte,bewertet_am,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')
      .bind(aid,tenantId,courseId,rubricId,gegenstand,bezugId,rolle,quelle.user_id,auth.userId,gesamt,ts,ts),
    ...zeilen.map(z=>env.DB.prepare('INSERT INTO rubric_assessment_items(assessment_id,criterion_id,level_id,points,kommentar) VALUES(?,?,?,?,?)').bind(aid,z.criterion_id,z.level_id,z.points,z.kommentar)),
  ];
  if(rolle==='erstkorrektur'&&gegenstand==='gradebook_score')
    anweisungen.push(env.DB.prepare('UPDATE gradebook_scores SET points=?,graded_by=?,graded_at=?,updated_at=? WHERE id=? AND tenant_id=? AND course_id=?').bind(gesamt,auth.userId,ts,ts,bezugId,tenantId,courseId));
  if(rolle==='erstkorrektur'&&gegenstand==='quiz_attempt')
    anweisungen.push(env.DB.prepare('UPDATE quiz_attempts SET total_points=?,manual_points=?-auto_points,graded_by=?,graded_at=? WHERE id=? AND tenant_id=? AND course_id=?').bind(gesamt,gesamt,auth.userId,ts,bezugId,tenantId,courseId));
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'rubric.assessed',tenantId,courseId,'rubric_assessment',aid,{gegenstand,rolle,gesamtpunkte:gesamt});
  return{id:aid,gesamtpunkte:gesamt,kriterien:zeilen.length};
}

/**
 * Erst- und Zweitkorrektur nebeneinander, Kriterium fuer Kriterium.
 *
 * Das ist der eigentliche Gewinn gegenueber einer blossen zweiten Note: die Abweichung wird dort
 * sichtbar, wo sie ist. Wer 38 und 61 vergleicht, weiss nur, DASS man sich uneinig ist.
 */
export async function rubricComparison(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,gegenstand:string,bezugId:string){
  manager(auth,courseId);
  const bewertungen=(await env.DB.prepare('SELECT a.id,a.rolle,a.bewertet_von,a.gesamtpunkte,a.bewertet_am,a.rubric_id,u.display_name FROM rubric_assessments a JOIN users u ON u.id=a.bewertet_von WHERE a.tenant_id=? AND a.gegenstand=? AND a.bezug_id=? ORDER BY a.rolle,a.bewertet_am')
    .bind(tenantId,gegenstand,bezugId).all<Record<string,unknown>>()).results??[];
  if(!bewertungen.length)return{bewertungen:[],kriterien:[],abweichung:null};
  // Alle Positionen aller Bewertungen in EINER Abfrage.
  const posten=(await env.DB.prepare('SELECT i.assessment_id,i.criterion_id,i.points,i.kommentar,c.title,c.max_points,c.sort_order,l.label FROM rubric_assessment_items i JOIN rubric_criteria c ON c.id=i.criterion_id LEFT JOIN rubric_levels l ON l.id=i.level_id WHERE i.assessment_id IN (SELECT id FROM rubric_assessments WHERE tenant_id=? AND gegenstand=? AND bezug_id=?) ORDER BY c.sort_order')
    .bind(tenantId,gegenstand,bezugId).all<Record<string,unknown>>()).results??[];
  const erst=bewertungen.find(b=>b.rolle==='erstkorrektur'),zweit=bewertungen.find(b=>b.rolle==='zweitkorrektur');
  const kennungen=[...new Set(posten.map(p=>String(p.criterion_id)))];
  const kriterien=kennungen.map(cid=>{
    const alle=posten.filter(p=>String(p.criterion_id)===cid);
    const a=alle.find(p=>p.assessment_id===erst?.id),b=alle.find(p=>p.assessment_id===zweit?.id);
    const pa=a?Number(a.points):null,pb=b?Number(b.points):null;
    return{criterion_id:cid,title:String(alle[0]?.title||''),max_points:Number(alle[0]?.max_points||0),
      erstkorrektur:pa,zweitkorrektur:pb,
      erst_stufe:a?.label??null,zweit_stufe:b?.label??null,
      erst_kommentar:a?.kommentar??null,zweit_kommentar:b?.kommentar??null,
      abweichung:pa===null||pb===null?null:rund(pb-pa)};
  });
  return{bewertungen,kriterien,
    abweichung:erst&&zweit?rund(Number(zweit.gesamtpunkte)-Number(erst.gesamtpunkte)):null};
}

/**
 * Die eigene Sicht der bewerteten Person: warum diese Punktzahl.
 *
 * Nur die Erstkorrektur, und nur die eigene Bewertung - eine Zweitkorrektur laeuft noch, solange
 * ueber den Einspruch nicht entschieden ist, und ihr Zwischenstand geht die Person nichts an.
 */
export async function myRubricBreakdown(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,scoreId:string){
  requireCourseAccess(auth,courseId);
  const eigen=await env.DB.prepare("SELECT id FROM gradebook_scores WHERE id=? AND tenant_id=? AND course_id=? AND user_id=? AND status='published'").bind(scoreId,tenantId,courseId,auth.userId).first();
  if(!eigen)throw new Error('RUBRIC_SUBJECT_NOT_FOUND');
  const a=await env.DB.prepare("SELECT id,rubric_id,gesamtpunkte,bewertet_am FROM rubric_assessments WHERE tenant_id=? AND gegenstand='gradebook_score' AND bezug_id=? AND rolle='erstkorrektur'").bind(tenantId,scoreId).first<Record<string,unknown>>();
  if(!a)return{bewertung:null,kriterien:[]};
  const kriterien=(await env.DB.prepare('SELECT c.title,c.erwartungshorizont,c.max_points,i.points,i.kommentar,l.label,l.beschreibung FROM rubric_assessment_items i JOIN rubric_criteria c ON c.id=i.criterion_id LEFT JOIN rubric_levels l ON l.id=i.level_id WHERE i.assessment_id=? ORDER BY c.sort_order').bind(a.id).all()).results??[];
  return{bewertung:{gesamtpunkte:a.gesamtpunkte,bewertet_am:a.bewertet_am},kriterien};
}

/**
 * Die Korrekturliste zu einer Aufgabe mit Raster: wer ist dran, wer ist fertig.
 *
 * Eine Abfrage fuer die ganze Klasse - nicht eine je Person. Ohne diese Liste haette die Lehrkraft
 * keinen Weg, das Raster ueberhaupt auszufuellen, und es waere gebaut und unerreichbar.
 */
export async function rubricGradingQueue(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,itemId:string){
  manager(auth,courseId);
  const item=await env.DB.prepare('SELECT id,title,max_points,rubric_id FROM gradebook_items WHERE id=? AND tenant_id=? AND course_id=?').bind(itemId,tenantId,courseId).first<Record<string,unknown>>();
  if(!item)throw new Error('GRADEBOOK_ITEM_NOT_FOUND');
  const zeilen=(await env.DB.prepare("SELECT s.id AS score_id,s.user_id,s.points,s.status,u.display_name,(SELECT a.gesamtpunkte FROM rubric_assessments a WHERE a.tenant_id=s.tenant_id AND a.gegenstand='gradebook_score' AND a.bezug_id=s.id AND a.bewertet_von=?) AS mein_raster FROM gradebook_scores s JOIN users u ON u.id=s.user_id WHERE s.tenant_id=? AND s.course_id=? AND s.item_id=? ORDER BY u.display_name")
    .bind(auth.userId,tenantId,courseId,itemId).all()).results??[];
  return{item,zeilen};
}

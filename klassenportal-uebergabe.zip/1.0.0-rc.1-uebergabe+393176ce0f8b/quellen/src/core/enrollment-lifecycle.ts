import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Kurswechsel, Unterbrechung, Wiederaufnahme als Vorgang (L2).
//
// Bisher war ein Wechsel ein stiller Zeilentausch in der Mitgliedschaft. Damit war zweierlei
// verloren: die Historie im alten Kurs, und die Unterscheidung zwischen "unterbrochen, kommt
// wieder" und "abgebrochen". Fuer einen gefoerderten Traeger ist genau diese Unterscheidung
// der Unterschied zwischen einer Meldung und einem Rueckforderungsbescheid.
//
// Deshalb: Anlass, Entscheidung mit Begruendung, Stichtag - und eine ausdrueckliche Wahl, was
// mit den Leistungen geschieht. Der Vollzug haengt die Mitgliedschaft um; die Leistungen im
// alten Kurs bleiben stehen, egal wie entschieden wurde. Sie zu loeschen waere Geschichtsfaelschung.

const clean=(v:unknown,n=1000)=>safeString(v,n);
export const ARTEN=['wechsel','unterbrechung','wiederaufnahme','abbruch'] as const;
const tag=(v:string)=>/^\d{4}-\d{2}-\d{2}$/.test(v);

type Vorgang={id:string;user_id:string;art:string;von_course_id:string|null;nach_course_id:string|null;
  stichtag:string;leistungen:string;bezug_id:string|null;status:string};

/**
 * Einen Vorgang beantragen.
 *
 * Fuer sich selbst darf jeder - wer wechseln oder unterbrechen will, muss das sagen koennen,
 * ohne erst jemanden zu finden. Fuer andere nur die Verwaltung.
 */
export async function beantrageVorgang(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const fuer=clean(input.user_id,120)||auth.userId;
  if(fuer!==auth.userId)requireRole(auth,'class_admin');
  const art=clean(input.art,30);
  if(!(ARTEN as readonly string[]).includes(art))throw new Error('LAUFBAHN_ART_UNGUELTIG');
  const anlass=clean(input.anlass,2000);
  if(anlass.length<10)throw new Error('LAUFBAHN_ANLASS_ERFORDERLICH');
  const stichtag=clean(input.stichtag,10);
  if(!tag(stichtag))throw new Error('LAUFBAHN_STICHTAG_UNGUELTIG');
  const von=clean(input.von_course_id,120)||null,nach=clean(input.nach_course_id,120)||null;
  const leistungen=clean(input.leistungen,40)||'im_alten_kurs_belassen';
  if(!['mitnehmen','im_alten_kurs_belassen'].includes(leistungen))throw new Error('LAUFBAHN_LEISTUNGEN_UNGUELTIG');
  const mitglied=await env.DB.prepare("SELECT 1 AS ok FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'").bind(tenantId,fuer).first();
  if(!mitglied)throw new Error('LAUFBAHN_PERSON_NICHT_GEFUNDEN');
  // Ein Wechsel ohne Zielkurs ist kein Wechsel, sondern ein Abbruch mit freundlichem Namen.
  if(art==='wechsel'&&(!von||!nach))throw new Error('LAUFBAHN_WECHSEL_BRAUCHT_ZIEL');
  if(art==='wechsel'&&von===nach)throw new Error('LAUFBAHN_WECHSEL_GLEICHER_KURS');
  let geplant=clean(input.geplante_rueckkehr,10)||null;
  if(art==='unterbrechung'){
    if(!von)throw new Error('LAUFBAHN_KURS_ERFORDERLICH');
    // Eine Unterbrechung ohne geplante Rueckkehr ist in der Statistik ein Abbruch. Wer sie
    // trotzdem offen lassen will, muss das begruenden - sonst verschwindet der Fall lautlos.
    if(geplant&&!tag(geplant))throw new Error('LAUFBAHN_RUECKKEHR_UNGUELTIG');
    if(!geplant&&clean(input.rueckkehr_offen_grund,1000).length<20)throw new Error('LAUFBAHN_RUECKKEHR_ERFORDERLICH');
  }else geplant=null;
  let bezug:string|null=null;
  if(art==='wiederaufnahme'){
    bezug=clean(input.bezug_id,120)||null;
    const offen=bezug
      ? await env.DB.prepare("SELECT id,von_course_id FROM enrollment_transitions WHERE id=? AND tenant_id=? AND user_id=? AND art='unterbrechung' AND status='vollzogen'").bind(bezug,tenantId,fuer).first<{id:string;von_course_id:string|null}>()
      : await env.DB.prepare("SELECT id,von_course_id FROM enrollment_transitions WHERE tenant_id=? AND user_id=? AND art='unterbrechung' AND status='vollzogen' ORDER BY stichtag DESC LIMIT 1").bind(tenantId,fuer).first<{id:string;von_course_id:string|null}>();
    // Wiederaufnahme ohne Unterbrechung ergibt keinen Sinn - und wuerde eine Mitgliedschaft
    // wiederherstellen, die nie beendet wurde.
    if(!offen)throw new Error('LAUFBAHN_KEINE_UNTERBRECHUNG');
    const schonZurueck=await env.DB.prepare("SELECT 1 AS ok FROM enrollment_transitions WHERE tenant_id=? AND bezug_id=? AND art='wiederaufnahme' AND status IN ('beantragt','genehmigt','vollzogen')").bind(tenantId,offen.id).first();
    if(schonZurueck)throw new Error('LAUFBAHN_BEREITS_WIEDERAUFGENOMMEN');
    bezug=offen.id;
  }
  const ts=nowIso(),vid=id('lbn_');
  await env.DB.prepare('INSERT INTO enrollment_transitions(id,tenant_id,user_id,art,von_course_id,nach_course_id,anlass,stichtag,leistungen,geplante_rueckkehr,bezug_id,status,beantragt_von,beantragt_am,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(vid,tenantId,fuer,art,von,nach,anlass,stichtag,leistungen,geplant,bezug,'beantragt',auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'enrollment_transition.filed',tenantId,von??undefined,'enrollment_transition',vid,{art});
  return{id:vid,art,status:'beantragt'};
}

async function ladeVorgang(env:Env,tenantId:string,vorgangId:string):Promise<Vorgang>{
  const v=await env.DB.prepare('SELECT id,user_id,art,von_course_id,nach_course_id,stichtag,leistungen,bezug_id,status FROM enrollment_transitions WHERE id=? AND tenant_id=?')
    .bind(clean(vorgangId,120),tenantId).first<Vorgang>();
  if(!v)throw new Error('LAUFBAHN_VORGANG_NICHT_GEFUNDEN');
  return v;
}

/**
 * Entscheiden - mit Begruendung, und nicht ueber den eigenen Vorgang.
 *
 * Eine Ablehnung ohne Begruendung kann die Person nicht angreifen; das ist bei einem Wechsel
 * genauso ein Verwaltungsakt wie bei einer Anerkennung.
 */
export async function entscheideVorgang(env:Env,auth:CoreAuthContext,tenantId:string,vorgangId:string,genehmigt:boolean,begruendung:string){
  requireRole(auth,'class_admin');
  const v=await ladeVorgang(env,tenantId,vorgangId);
  if(v.status!=='beantragt')throw new Error('LAUFBAHN_BEREITS_ENTSCHIEDEN');
  if(v.user_id===auth.userId&&!auth.isPlatformAdmin)throw new Error('LAUFBAHN_EIGENER_VORGANG');
  const text=clean(begruendung,5000);
  if(text.length<20)throw new Error('LAUFBAHN_BEGRUENDUNG_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.prepare('UPDATE enrollment_transitions SET status=?,entscheidung_begruendung=?,entschieden_von=?,entschieden_am=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(genehmigt?'genehmigt':'abgelehnt',text,auth.userId,ts,ts,vorgangId,tenantId).run();
  await audit(env.DB,auth.userId,'enrollment_transition.decided',tenantId,v.von_course_id??undefined,'enrollment_transition',vorgangId,{genehmigt});
  return{status:genehmigt?'genehmigt':'abgelehnt'};
}

/**
 * Vollziehen: die Mitgliedschaft umhaengen.
 *
 * Was im alten Kurs an Noten und Anwesenheit steht, bleibt stehen - immer. Die Entscheidung
 * "mitnehmen" heisst, dass die Leistungen im neuen Kurs ANGERECHNET werden, nicht dass sie im
 * alten verschwinden. Eine geloeschte Historie waere in einem gefoerderten Kurs ein Beleg, den
 * der Traeger bei der naechsten Pruefung nicht mehr vorlegen kann.
 */
export async function vollzieheVorgang(env:Env,auth:CoreAuthContext,tenantId:string,vorgangId:string){
  requireRole(auth,'class_admin');
  const v=await ladeVorgang(env,tenantId,vorgangId);
  if(v.status!=='genehmigt')throw new Error('LAUFBAHN_NICHT_GENEHMIGT');
  const ts=nowIso(),anweisungen=[];
  if(v.art==='wechsel'){
    anweisungen.push(env.DB.prepare("DELETE FROM memberships WHERE tenant_id=? AND course_id=? AND user_id=? AND role='participant'").bind(tenantId,v.von_course_id,v.user_id));
    anweisungen.push(env.DB.prepare("INSERT INTO memberships(id,tenant_id,course_id,user_id,role,created_at) VALUES(?,?,?,?,'participant',?) ON CONFLICT(tenant_id,course_id,user_id,role) DO NOTHING")
      .bind(id('mem_'),tenantId,v.nach_course_id,v.user_id,ts));
  }else if(v.art==='unterbrechung'||v.art==='abbruch'){
    anweisungen.push(env.DB.prepare("DELETE FROM memberships WHERE tenant_id=? AND course_id=? AND user_id=? AND role='participant'").bind(tenantId,v.von_course_id,v.user_id));
  }else if(v.art==='wiederaufnahme'){
    const u=v.bezug_id?await ladeVorgang(env,tenantId,v.bezug_id):null;
    const ziel=v.nach_course_id??u?.von_course_id??null;
    if(!ziel)throw new Error('LAUFBAHN_KURS_ERFORDERLICH');
    anweisungen.push(env.DB.prepare("INSERT INTO memberships(id,tenant_id,course_id,user_id,role,created_at) VALUES(?,?,?,?,'participant',?) ON CONFLICT(tenant_id,course_id,user_id,role) DO NOTHING")
      .bind(id('mem_'),tenantId,ziel,v.user_id,ts));
  }
  anweisungen.push(env.DB.prepare("UPDATE enrollment_transitions SET status='vollzogen',vollzogen_am=?,updated_at=? WHERE id=? AND tenant_id=?").bind(ts,ts,vorgangId,tenantId));
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'enrollment_transition.executed',tenantId,v.von_course_id??undefined,'enrollment_transition',vorgangId,{art:v.art,leistungen:v.leistungen});
  return{status:'vollzogen',art:v.art};
}

/**
 * Der Laufbahnstand einer Person - und der Punkt, an dem eine Unterbrechung KEIN Abbruch ist.
 *
 * Genau daran haengt, was der Traeger meldet. Wer unterbrochen hat und dessen Rueckkehr noch
 * aussteht, ist nicht gescheitert; wer abgebrochen hat, ist es.
 */
export async function laufbahn(env:Env,auth:CoreAuthContext,tenantId:string,userId:string){
  const person=clean(userId,120)||auth.userId;
  if(person!==auth.userId)requireRole(auth,'class_admin');
  const zeilen=((await env.DB.prepare(`SELECT t.id,t.art,t.von_course_id,t.nach_course_id,t.stichtag,t.leistungen,t.geplante_rueckkehr,t.bezug_id,t.status,t.anlass,t.entscheidung_begruendung
    FROM enrollment_transitions t WHERE t.tenant_id=? AND t.user_id=? ORDER BY t.stichtag,t.beantragt_am`)
    .bind(tenantId,person).all<Record<string,unknown>>()).results)??[];
  const vollzogen=zeilen.filter(z=>z.status==='vollzogen');
  const zurueck=new Set(vollzogen.filter(z=>z.art==='wiederaufnahme').map(z=>String(z.bezug_id??'')));
  const offeneUnterbrechung=vollzogen.find(z=>z.art==='unterbrechung'&&!zurueck.has(String(z.id)));
  const abgebrochen=vollzogen.some(z=>z.art==='abbruch');
  return{vorgaenge:zeilen,
    // Die Reihenfolge ist Absicht: ein Abbruch ist endgueltig, eine offene Unterbrechung nicht.
    stand:abgebrochen?'abgebrochen':offeneUnterbrechung?'unterbrochen':'laufend',
    unterbrochen_seit:offeneUnterbrechung?String(offeneUnterbrechung.stichtag):null,
    rueckkehr_geplant:offeneUnterbrechung?(offeneUnterbrechung.geplante_rueckkehr as string|null)??null:null};
}

/**
 * Was ist offen - und wer ist ueberfaellig zurueckerwartet?
 *
 * Zwei Abfragen fuer den ganzen Mandanten. Eine je Person waere bei 300 Teilnehmenden schon
 * ein Drittel des Budgets fuer eine Uebersichtsseite.
 */
export async function laufbahnUebersicht(env:Env,auth:CoreAuthContext,tenantId:string,heute?:string){
  requireRole(auth,'class_admin');
  const stichtag=clean(heute,10)||nowIso().slice(0,10);
  const offen=((await env.DB.prepare(`SELECT t.id,t.user_id,u.display_name,t.art,t.stichtag,t.anlass FROM enrollment_transitions t JOIN users u ON u.id=t.user_id
    WHERE t.tenant_id=? AND t.status IN ('beantragt','genehmigt') ORDER BY t.stichtag LIMIT 200`).bind(tenantId).all<Record<string,unknown>>()).results)??[];
  const ueberfaellig=((await env.DB.prepare(`SELECT t.id,t.user_id,u.display_name,t.von_course_id,t.geplante_rueckkehr FROM enrollment_transitions t JOIN users u ON u.id=t.user_id
    WHERE t.tenant_id=? AND t.art='unterbrechung' AND t.status='vollzogen' AND t.geplante_rueckkehr IS NOT NULL AND t.geplante_rueckkehr<?
      AND NOT EXISTS(SELECT 1 FROM enrollment_transitions w WHERE w.tenant_id=t.tenant_id AND w.bezug_id=t.id AND w.art='wiederaufnahme' AND w.status IN ('beantragt','genehmigt','vollzogen'))
    ORDER BY t.geplante_rueckkehr LIMIT 200`).bind(tenantId,stichtag).all<Record<string,unknown>>()).results)??[];
  return{offen,ueberfaellig};
}

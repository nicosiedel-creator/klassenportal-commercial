import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { hasPermission } from './enterprise-access.js';
import { stapelSchreiben } from './learning-operations.js';
import { teacherWorkloadBalance } from './planning-constraints.js';
import { id, nowIso, safeString } from './utils.js';

// Honorarabrechnung fuer freie Dozentinnen und Dozenten.
//
// Bei einem Traeger mit 80 Prozent Honorarkraeften ist das der teuerste Handgriff des Monats.
// Heute laeuft er von Hand: jemand zaehlt aus Stundenplan, Vertretungsliste und Krankmeldungen
// zusammen, was jede Person gehalten hat, rechnet den Satz dagegen, mailt das Ergebnis zur
// Bestaetigung und tippt es danach in eine Auszahlungsliste. Jeder dieser Schritte ist eine
// Fehlerquelle, und der teuerste Fehler ist der stille: eine Vertretung, die bei zwei Personen
// zaehlt, oder Unterricht, der waehrend einer Krankmeldung im Kalender stehen geblieben ist.
//
// Deshalb wird hier KEINE zweite Zaehlung gebaut. Das Mengengeruest ist teacherWorkloadBalance
// (src/core/planning-constraints.ts): geleistete Minuten je Person, getrennt nach eigenem
// Unterricht und uebernommener Vertretung, eine uebernommene Stunde ausschliesslich beim
// Vertreter, dokumentierte Abwesenheit zeitgenau herausgeschnitten. Neu sind hier nur drei Dinge:
// der Stundensatz, der Zustand der Abrechnung und die Liste fuer die Buchhaltung.
//
// Es findet KEIN Zahlungsverkehr statt. PAYMENTS_ENABLED ist false; dieses Modul kennt keinen
// Zahlungsdienstleister, keine Bankverbindung und keine Ueberweisung. 'paid' ist ein Vermerk der
// Buchhaltung ueber einen Vorgang, der ausserhalb des Portals stattgefunden hat.

type Row=Record<string,unknown>;
type Taetigkeit='lesson'|'substitution';
const TAETIGKEITEN:Taetigkeit[]=['lesson','substitution'];

// Ein Satz von mehr als 1000 EUR je Zeitstunde ist kein Honorar, sondern ein Tippfehler
// (425000 statt 4250). Die Grenze faengt genau den ab.
const SATZ_MAX_CENT=100000;
// Ein Abrechnungszeitraum ist ein Monat, im Ausnahmefall ein Quartal. Ein halbes Jahr ist die
// Grenze, ab der jemand offensichtlich etwas anderes vorhat, als eine Periode abzurechnen.
const ZEITRAUM_MAX_TAGE=186;
// Ein Lauf schreibt je Person eine Periode und ein bis vier Zeilen. Gestapelt sind das wenige
// Unteranfragen, aber irgendwo muss die Grenze liegen, ab der ein Lauf ehrlich abbricht statt
// die Plattformgrenze zu reissen und die Haelfte geschrieben zu hinterlassen.
const DOZENTEN_MAX=500;
const UNBEFRISTET='9999-12-31';

// Die Auswertung liefert je Person die Tagesaufteilung ihrer geleisteten Minuten. Genau dieses
// Geruest wird hier bepreist - nichts davon wird nachgezaehlt.
type Tagesminuten={date:string;lesson_minutes:number;substitution_minutes:number};
type Mengenzeile={teacher_id:string;teacher_name:string;daily?:Tagesminuten[]};
type Satz={id:string;teacher_id:string;activity:Taetigkeit;rate:number;von:string;bis:string|null;currency:string};
type Periode={id:string;tenant_id:string;teacher_id:string;period_from:string;period_to:string;
  status:'proposed'|'confirmed'|'approved'|'paid';minutes_total:number;total_cents:number;currency:string};

function verwaltet(auth:CoreAuthContext){return auth.isPlatformAdmin||auth.role==='tenant_admin'||hasPermission(auth,'courses.manage');}
function assertVerwaltung(auth:CoreAuthContext){if(!verwaltet(auth))throw new Error('FORBIDDEN_TEACHER_FEE_MANAGE');}
function pflicht(v:unknown,fehler:string,max=200){const s=safeString(v,max);if(!s)throw new Error(fehler);return s;}
function optional(v:unknown,max=1000){return safeString(v,max)||null;}
function datum(v:unknown,fehler:string){
  const s=safeString(v,10);
  if(!s||!/^\d{4}-\d\d-\d\d$/.test(s)||Number.isNaN(Date.parse(`${s}T00:00:00.000Z`)))throw new Error(fehler);
  return s;
}
function taetigkeit(v:unknown){
  const s=safeString(v,30)||'lesson';
  if(s!=='lesson'&&s!=='substitution')throw new Error('TEACHER_FEE_ACTIVITY_INVALID');
  return s as Taetigkeit;
}
// Betraege sind ganzzahlige Cent. Number.isInteger weist 42.5 ebenso ab wie "42,50" - beides
// waere sonst als 42 in der Abrechnung gelandet und die Differenz haette niemand mehr gefunden.
function centBetrag(v:unknown,fehler:string){
  const n=typeof v==='number'?v:Number(safeString(v,20));
  if(!Number.isInteger(n)||n<=0)throw new Error(fehler);
  return n;
}
// Cent aus Minuten und Stundensatz - ausschliesslich in ganzen Zahlen. minuten*satz ergibt
// Cent-Minuten; geteilt wird ueber Ganzteil und Rest, damit an keiner Stelle eine
// Fliesskommazahl entsteht. Der halbe Cent wird kaufmaennisch aufgerundet, und zwar EINMAL je
// Zeile statt je Tag: 20 Tage einzeln zu runden verschoebe die Summe um bis zu 10 Cent
// gegenueber derselben Rechnung in einem Stueck, und genau solche Differenzen sucht am
// Monatsende jemand von Hand.
function betragAusMinuten(minuten:number,satzCentProStunde:number){
  const centMinuten=minuten*satzCentProStunde,rest=centMinuten%60;
  return (centMinuten-rest)/60+(rest*2>=60?1:0);
}
// Anzeige aus ganzen Cent, ohne je durch 100 zu teilen. Eine Division waere hier zwar harmlos,
// aber sie ist der Anfang jeder Rundungsgeschichte - und Kundentexte werden kopiert.
export function alsEuro(cent:number,waehrung='EUR'){
  const v=Math.abs(Math.trunc(cent));
  return `${cent<0?'-':''}${Math.trunc(v/100)},${String(v%100).padStart(2,'0')} ${waehrung}`;
}

// Die Dozentenkennungen, die zum angemeldeten Konto gehoeren. Eine Abfrage, unabhaengig davon,
// wie viele Zuordnungen es gibt - und ausschliesslich aktive: ein entzogener Portalzugang darf
// keine fremde Abrechnung mehr oeffnen.
async function eigeneDozenten(env:Env,tenantId:string,userId:string){
  const r=((await env.DB.prepare(
    `SELECT DISTINCT teacher_id FROM teacher_portal_assignments WHERE tenant_id=? AND user_id=? AND status='active'`
  ).bind(tenantId,userId).all<{teacher_id:string}>()).results)??[];
  return new Set(r.map(x=>String(x.teacher_id)));
}

// Jede vom Client gelieferte Kennung wird gegen den Mandanten geprueft, nie geglaubt. Ohne diese
// Zeile reichte eine fremde Periodenkennung, um die Honorarabrechnung eines anderen Traegers zu
// lesen oder freizugeben.
async function ladePeriode(env:Env,tenantId:string,periodId:string):Promise<Periode>{
  const row=await env.DB.prepare(
    `SELECT id,tenant_id,teacher_id,period_from,period_to,status,minutes_total,total_cents,currency
       FROM teacher_fee_periods WHERE tenant_id=? AND id=?`
  ).bind(tenantId,periodId).first<Row>();
  if(!row)throw new Error('TEACHER_FEE_PERIOD_NOT_FOUND');
  return row as unknown as Periode;
}

/** Die hinterlegten Stundensaetze. Die Verwaltung sieht alle, eine Honorarkraft nur ihre eigenen. */
export async function listTeacherFeeRates(env:Env,auth:CoreAuthContext,tenantId:string,teacherId?:string){
  const gefiltert=safeString(teacherId,120)||null;
  const spalten=`r.id,r.teacher_id,r.activity,r.rate_cents_per_hour,r.currency,r.valid_from,r.valid_until,r.note,r.created_at,r.updated_at,t.name teacher_name`;
  // Drei ausgeschriebene Anweisungen statt einer zusammengesetzten: nur so laesst sich jede von
  // ihnen gegen das echte Schema vorbereiten (tests/sql-schema-contract.mjs).
  if(!verwaltet(auth)){
    const eigene=await eigeneDozenten(env,tenantId,auth.userId);
    if(!eigene.size||(gefiltert&&!eigene.has(gefiltert)))throw new Error('FORBIDDEN_TEACHER_FEE_VIEW');
    const ids=gefiltert?[gefiltert]:[...eigene],marks=ids.map(()=>'?').join(',');
    return((await env.DB.prepare(
      `SELECT ${spalten} FROM teacher_fee_rates r JOIN teachers t ON t.id=r.teacher_id AND t.tenant_id=r.tenant_id
        WHERE r.tenant_id=? AND r.teacher_id IN (${marks}) ORDER BY t.name,r.activity,r.valid_from`
    ).bind(tenantId,...ids).all<Row>()).results)??[];
  }
  if(gefiltert)return((await env.DB.prepare(
    `SELECT ${spalten} FROM teacher_fee_rates r JOIN teachers t ON t.id=r.teacher_id AND t.tenant_id=r.tenant_id
      WHERE r.tenant_id=? AND r.teacher_id=? ORDER BY r.activity,r.valid_from`
  ).bind(tenantId,gefiltert).all<Row>()).results)??[];
  return((await env.DB.prepare(
    `SELECT ${spalten} FROM teacher_fee_rates r JOIN teachers t ON t.id=r.teacher_id AND t.tenant_id=r.tenant_id
      WHERE r.tenant_id=? ORDER BY t.name,r.activity,r.valid_from`
  ).bind(tenantId).all<Row>()).results)??[];
}

/** Einen Stundensatz vereinbaren oder aendern. Nur die Verwaltung, nie die Honorarkraft selbst. */
export async function saveTeacherFeeRate(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  assertVerwaltung(auth);
  const teacherId=pflicht(input.teacher_id,'TEACHER_FEE_TEACHER_REQUIRED',120);
  // Erst gegen den Mandanten pruefen, dann rechnen: eine Dozentenkennung aus einem fremden
  // Mandanten darf nicht einmal einen Satz erzeugen koennen.
  if(!await env.DB.prepare('SELECT 1 ok FROM teachers WHERE tenant_id=? AND id=?').bind(tenantId,teacherId).first())throw new Error('TEACHER_NOT_FOUND');
  const activity=taetigkeit(input.activity);
  const satz=centBetrag(input.rate_cents_per_hour,'TEACHER_FEE_RATE_INVALID');
  if(satz>SATZ_MAX_CENT)throw new Error('TEACHER_FEE_RATE_TOO_HIGH');
  const von=datum(input.valid_from,'TEACHER_FEE_RATE_PERIOD_INVALID');
  const bis=input.valid_until===null||input.valid_until===undefined||input.valid_until===''?null:datum(input.valid_until,'TEACHER_FEE_RATE_PERIOD_INVALID');
  if(bis&&bis<von)throw new Error('TEACHER_FEE_RATE_PERIOD_INVALID');
  // Eine mitgeschickte Kennung muss zu DIESEM Mandanten gehoeren. Ohne diese Pruefung wuerde ein
  // "Aendern" mit geratener Kennung den Satz eines fremden Traegers ueberschreiben.
  const vorhandene=safeString(input.id,120)||'';
  if(vorhandene&&!await env.DB.prepare('SELECT 1 ok FROM teacher_fee_rates WHERE tenant_id=? AND id=?').bind(tenantId,vorhandene).first())
    throw new Error('TEACHER_FEE_RATE_NOT_FOUND');
  const rateId=vorhandene||id('tfr_');
  // Zwei sich ueberschneidende Saetze machen die Abrechnung mehrdeutig - fuer denselben Tag gaebe
  // es zwei richtige Ergebnisse. Die Datenbank haelt dieselbe Regel noch einmal (Trigger in 0113)
  // fuer den Fall, dass zwei Verantwortliche gleichzeitig eintragen; hier steht sie, damit der
  // Mensch am Bildschirm einen Satz sieht statt einer Datenbankmeldung.
  const kollision=await env.DB.prepare(
    `SELECT id FROM teacher_fee_rates WHERE tenant_id=? AND teacher_id=? AND activity=? AND id<>?
       AND COALESCE(valid_until,'${UNBEFRISTET}')>=? AND COALESCE(?,'${UNBEFRISTET}')>=valid_from LIMIT 1`
  ).bind(tenantId,teacherId,activity,rateId,von,bis).first();
  if(kollision)throw new Error('TEACHER_FEE_RATE_OVERLAP');
  const note=optional(input.note,500),ts=nowIso();
  if(vorhandene)await env.DB.prepare(
    `UPDATE teacher_fee_rates SET teacher_id=?,activity=?,rate_cents_per_hour=?,valid_from=?,valid_until=?,note=?,updated_at=?
      WHERE tenant_id=? AND id=?`
  ).bind(teacherId,activity,satz,von,bis,note,ts,tenantId,rateId).run();
  else await env.DB.prepare(
    `INSERT INTO teacher_fee_rates(id,tenant_id,teacher_id,activity,rate_cents_per_hour,currency,valid_from,valid_until,note,created_by,created_at,updated_at)
     VALUES(?,?,?,?,?,'EUR',?,?,?,?,?,?)`
  ).bind(rateId,tenantId,teacherId,activity,satz,von,bis,note,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'teacher_fee.rate_saved',tenantId,undefined,'teacher_fee_rate',rateId,{teacher_id:teacherId,activity,rate_cents_per_hour:satz,valid_from:von,valid_until:bis});
  return{rateId,teacherId,activity,rateCentsPerHour:satz,validFrom:von,validUntil:bis,display:alsEuro(satz)};
}

/**
 * Aus dem tatsaechlich gehaltenen Unterricht den Honorarvorschlag erzeugen - fuer alle
 * Honorarkraefte eines Zeitraums oder fuer eine einzelne.
 *
 * Fail closed je Person: fehlt fuer einen einzigen geleisteten Tag ein Satz, entsteht fuer diese
 * Person GAR KEIN Vorschlag. Ein Vorschlag, der die halbe Leistung ausweist, saehe vollstaendig
 * aus und waere zu niedrig - und das faellt erst auf, wenn die Honorarkraft ihn nachrechnet.
 */
export async function proposeTeacherFeeSettlement(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  assertVerwaltung(auth);
  const von=datum(input.from,'TEACHER_FEE_PERIOD_INVALID'),bis=datum(input.to,'TEACHER_FEE_PERIOD_INVALID');
  if(bis<von)throw new Error('TEACHER_FEE_PERIOD_INVALID');
  const tage=Math.round((Date.parse(`${bis}T00:00:00.000Z`)-Date.parse(`${von}T00:00:00.000Z`))/86400000)+1;
  if(tage>ZEITRAUM_MAX_TAGE)throw new Error('TEACHER_FEE_PERIOD_TOO_LONG');
  const nurEiner=safeString(input.teacher_id,120)||null;

  // Das Mengengeruest. Vier Abfragen, unabhaengig von der Zahl der Dozentinnen und Dozenten.
  const mengen=await teacherWorkloadBalance(env,auth,tenantId,
    {from:von,to:bis,teacher_id:nurEiner??undefined,include_daily:true}) as unknown as {rows:Mengenzeile[]};
  if(mengen.rows.length>DOZENTEN_MAX)throw new Error('TEACHER_FEE_RUN_TOO_LARGE');

  // Zwei weitere Abfragen fuer den ganzen Lauf: alle im Zeitraum gueltigen Saetze und alle
  // Perioden, die sich mit ihm ueberschneiden. Je Person zu fragen waere bei 300 Honorarkraeften
  // genau die Bauart, an der die Plattformgrenze von 1000 Unteranfragen reisst.
  const [satzZeilen,periodenZeilen]=await Promise.all([
    env.DB.prepare(
      `SELECT id,teacher_id,activity,rate_cents_per_hour,currency,valid_from,valid_until FROM teacher_fee_rates
        WHERE tenant_id=?1 AND (?2 IS NULL OR teacher_id=?2) AND valid_from<=?3 AND (valid_until IS NULL OR valid_until>=?4)
        ORDER BY teacher_id,activity,valid_from`
    ).bind(tenantId,nurEiner,bis,von).all<Row>(),
    env.DB.prepare(
      `SELECT id,teacher_id,period_from,period_to,status FROM teacher_fee_periods
        WHERE tenant_id=?1 AND (?2 IS NULL OR teacher_id=?2) AND period_from<=?3 AND period_to>=?4`
    ).bind(tenantId,nurEiner,bis,von).all<Row>(),
  ]);
  const saetze=new Map<string,Satz[]>();
  for(const r of satzZeilen.results??[]){
    const s:Satz={id:String(r.id),teacher_id:String(r.teacher_id),activity:String(r.activity) as Taetigkeit,
      rate:Number(r.rate_cents_per_hour),von:String(r.valid_from),bis:r.valid_until?String(r.valid_until):null,
      currency:String(r.currency||'EUR')};
    const k=`${s.teacher_id}|${s.activity}`,l=saetze.get(k);
    if(l)l.push(s);else saetze.set(k,[s]);
  }
  const bestehende=new Map<string,Array<{id:string;period_from:string;period_to:string;status:string}>>();
  for(const r of periodenZeilen.results??[]){
    const k=String(r.teacher_id),l=bestehende.get(k),p={id:String(r.id),period_from:String(r.period_from),period_to:String(r.period_to),status:String(r.status)};
    if(l)l.push(p);else bestehende.set(k,[p]);
  }
  const satzFuer=(teacherId:string,art:Taetigkeit,tag:string)=>
    (saetze.get(`${teacherId}|${art}`)??[]).find(s=>s.von<=tag&&(s.bis===null||s.bis>=tag))??null;

  const anweisungen:unknown[]=[],ergebnisse:Row[]=[],ts=nowIso();
  let gesamtCent=0,erzeugt=0;
  for(const zeile of mengen.rows){
    const teacherId=String(zeile.teacher_id),name=String(zeile.teacher_name||'');
    const segmente=new Map<string,{activity:Taetigkeit;rateId:string;satz:number;currency:string;von:string;bis:string;tage:number;minuten:number}>();
    const ohneSatz=new Set<string>();
    let minutenGesamt=0;
    for(const tag of zeile.daily??[]){
      for(const art of TAETIGKEITEN){
        const minuten=art==='lesson'?Number(tag.lesson_minutes||0):Number(tag.substitution_minutes||0);
        if(minuten<=0)continue;
        minutenGesamt+=minuten;
        const satz=satzFuer(teacherId,art,tag.date);
        if(!satz){ohneSatz.add(tag.date);continue;}
        // Ein Segment ist alles, was mit DEMSELBEN Satz gerechnet wurde. Wechselt der Satz zum
        // Monatsersten, entstehen zwei Zeilen - so steht in der Abrechnung, welche Minuten mit
        // welchem Satz vergolten wurden, statt eines Mischpreises, den niemand nachrechnen kann.
        const schluessel=`${art}|${satz.id}`,s=segmente.get(schluessel);
        if(s){s.minuten+=minuten;s.tage+=1;if(tag.date<s.von)s.von=tag.date;if(tag.date>s.bis)s.bis=tag.date;}
        else segmente.set(schluessel,{activity:art,rateId:satz.id,satz:satz.rate,currency:satz.currency,von:tag.date,bis:tag.date,tage:1,minuten});
      }
    }
    if(!minutenGesamt){ergebnisse.push({teacher_id:teacherId,teacher_name:name,status:'skipped',reason:'no_work'});continue;}
    if(ohneSatz.size){
      const fehlend=[...ohneSatz].sort();
      ergebnisse.push({teacher_id:teacherId,teacher_name:name,status:'skipped',reason:'no_rate',
        missing_days:fehlend.length,first_missing_day:fehlend[0]});
      continue;
    }
    const treffer=bestehende.get(teacherId)??[];
    const gleicherZeitraum=treffer.find(p=>p.period_from===von&&p.period_to===bis);
    // Eine Periode, die sich ueberschneidet, aber nicht deckt, waere eine zweite Vergueterung
    // derselben Minuten. Sie wird nicht angetastet und die Person nicht abgerechnet.
    if(treffer.some(p=>p!==gleicherZeitraum)){
      ergebnisse.push({teacher_id:teacherId,teacher_name:name,status:'skipped',reason:'overlap'});
      continue;
    }
    if(gleicherZeitraum&&gleicherZeitraum.status!=='proposed'){
      ergebnisse.push({teacher_id:teacherId,teacher_name:name,status:'skipped',reason:'locked',
        period_id:gleicherZeitraum.id,period_status:gleicherZeitraum.status});
      continue;
    }
    const zeilen=[...segmente.values()].sort((a,b)=>a.activity<b.activity?-1:a.activity>b.activity?1:a.von<b.von?-1:1);
    let summe=0;
    const betraege=zeilen.map(s=>{const betrag=betragAusMinuten(s.minuten,s.satz);summe+=betrag;return betrag;});
    const periodId=id('tfp_'),waehrung=zeilen[0]?.currency||'EUR';
    // Ein noch offener Vorschlag wird ersetzt; die Zeilen haengen an der Kaskade. Eine
    // bestaetigte oder freigegebene Periode ist oben bereits ausgenommen worden.
    if(gleicherZeitraum)anweisungen.push(env.DB.prepare(
      `DELETE FROM teacher_fee_periods WHERE tenant_id=? AND id=? AND status='proposed'`
    ).bind(tenantId,gleicherZeitraum.id));
    anweisungen.push(env.DB.prepare(
      `INSERT INTO teacher_fee_periods(id,tenant_id,teacher_id,period_from,period_to,status,minutes_total,total_cents,currency,note,created_by,created_at,updated_at)
       VALUES(?,?,?,?,?,'proposed',?,?,?,?,?,?,?)`
    ).bind(periodId,tenantId,teacherId,von,bis,minutenGesamt,summe,waehrung,null,auth.userId,ts,ts));
    zeilen.forEach((s,i)=>anweisungen.push(env.DB.prepare(
      `INSERT INTO teacher_fee_period_lines(id,tenant_id,period_id,activity,work_from,work_to,days,minutes,rate_id,rate_cents_per_hour,amount_cents,created_at)
       VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`
    ).bind(id('tfl_'),tenantId,periodId,s.activity,s.von,s.bis,s.tage,s.minuten,s.rateId,s.satz,betraege[i],ts)));
    gesamtCent+=summe;erzeugt+=1;
    ergebnisse.push({teacher_id:teacherId,teacher_name:name,status:'proposed',period_id:periodId,
      minutes_total:minutenGesamt,total_cents:summe,lines:zeilen.length,display:alsEuro(summe,waehrung)});
  }
  // Ein Stapel statt einer Anweisung je Zeile: Cloudflare zaehlt einen Stapel als eine
  // Unteranfrage, unabhaengig davon, wie viele Anweisungen er traegt.
  if(anweisungen.length)await stapelSchreiben(env,anweisungen as any[]);
  await audit(env.DB,auth.userId,'teacher_fee.settlement_proposed',tenantId,undefined,'teacher_fee_period',null as unknown as string,
    {from:von,to:bis,proposed:erzeugt,skipped:ergebnisse.length-erzeugt,total_cents:gesamtCent});
  return{from:von,to:bis,proposed:erzeugt,skipped:ergebnisse.length-erzeugt,
    total_cents:gesamtCent,total_display:alsEuro(gesamtCent),rows:ergebnisse};
}

/** Die Abrechnungen eines Mandanten. Eine Honorarkraft sieht ausschliesslich ihre eigenen. */
export async function listTeacherFeePeriods(env:Env,auth:CoreAuthContext,tenantId:string,input:Row={}){
  const status=safeString(input.status,20)||null;
  if(status&&!['proposed','confirmed','approved','paid'].includes(status))throw new Error('TEACHER_FEE_STATUS_INVALID');
  const spalten=`p.id,p.teacher_id,p.period_from,p.period_to,p.status,p.minutes_total,p.total_cents,p.currency,
      p.confirmed_at,p.approved_at,p.paid_at,p.created_at,t.name teacher_name`;
  if(!verwaltet(auth)){
    const eigene=await eigeneDozenten(env,tenantId,auth.userId);
    if(!eigene.size)throw new Error('FORBIDDEN_TEACHER_FEE_VIEW');
    const ids=[...eigene],marks=ids.map(()=>'?').join(',');
    // Die eigene Abrechnung und keine fremde: die Einschraenkung steht in der WHERE-Bedingung,
    // nicht in einem Filter nach dem Laden. Was gar nicht geladen wird, kann auch nicht
    // versehentlich in eine Antwort geraten.
    //
    // Ausschliesslich unnummerierte Platzhalter. Die Zahl der eigenen Kennungen steht erst zur
    // Laufzeit fest, die Liste muss also '?' verwenden - und SQLite nummeriert diese fortlaufend
    // weiter. Ein daneben stehendes '?2' meinte deshalb nicht den Status, sondern die erste
    // Dozentenkennung, und die Anweisung nahm eine Bindung zu viel entgegen: die Abfrage brach
    // ab, und eine Honorarkraft bekam ihre eigene Abrechnung ueberhaupt nicht mehr zu sehen.
    const rows=((await env.DB.prepare(
      `SELECT ${spalten} FROM teacher_fee_periods p JOIN teachers t ON t.id=p.teacher_id AND t.tenant_id=p.tenant_id
        WHERE p.tenant_id=? AND p.teacher_id IN (${marks}) AND (? IS NULL OR p.status=?)
        ORDER BY p.period_from DESC,t.name`
    ).bind(tenantId,...ids,status,status).all<Row>()).results)??[];
    return rows.map(r=>({...r,can_confirm:r.status==='proposed',can_manage:false,display:alsEuro(Number(r.total_cents||0),String(r.currency||'EUR'))}));
  }
  const teacherId=safeString(input.teacher_id,120)||null;
  const rows=((await env.DB.prepare(
    `SELECT ${spalten} FROM teacher_fee_periods p JOIN teachers t ON t.id=p.teacher_id AND t.tenant_id=p.tenant_id
      WHERE p.tenant_id=?1 AND (?2 IS NULL OR p.status=?2) AND (?3 IS NULL OR p.teacher_id=?3)
      ORDER BY p.period_from DESC,t.name`
  ).bind(tenantId,status,teacherId).all<Row>()).results)??[];
  return rows.map(r=>({...r,can_confirm:false,can_manage:true,display:alsEuro(Number(r.total_cents||0),String(r.currency||'EUR'))}));
}

/** Eine Abrechnung mit ihren Zeilen. Die Zeilen tragen den EINGEFRORENEN Satz, nicht den heutigen. */
export async function teacherFeePeriodDetail(env:Env,auth:CoreAuthContext,tenantId:string,periodId:string){
  const p=await ladePeriode(env,tenantId,periodId);
  const eigene=verwaltet(auth)?null:await eigeneDozenten(env,tenantId,auth.userId);
  if(eigene&&!eigene.has(p.teacher_id))throw new Error('FORBIDDEN_TEACHER_FEE_VIEW');
  const dozent=await env.DB.prepare('SELECT name FROM teachers WHERE tenant_id=? AND id=?').bind(tenantId,p.teacher_id).first<{name:string}>();
  const zeilen=((await env.DB.prepare(
    `SELECT id,activity,work_from,work_to,days,minutes,rate_cents_per_hour,amount_cents,rate_id
       FROM teacher_fee_period_lines WHERE tenant_id=? AND period_id=? ORDER BY activity,work_from`
  ).bind(tenantId,periodId).all<Row>()).results)??[];
  return{
    period:{...p,teacher_name:String(dozent?.name||''),display:alsEuro(p.total_cents,p.currency),
      can_confirm:!eigene?false:p.status==='proposed',can_manage:!eigene},
    lines:zeilen.map(z=>({...z,display:alsEuro(Number(z.amount_cents||0),p.currency),
      rate_display:alsEuro(Number(z.rate_cents_per_hour||0),p.currency)})),
  };
}

/**
 * Die Honorarkraft bestaetigt IHRE eigene Abrechnung.
 *
 * Bewusst kann das die Verwaltung nicht - auch nicht "hilfsweise". Eine Bestaetigung, die auch
 * der Verwaltung offensteht, belegt nichts: sie waere dann nur ein zweiter Klick derselben
 * Person, die ohnehin freigibt.
 */
export async function confirmTeacherFeePeriod(env:Env,auth:CoreAuthContext,tenantId:string,periodId:string){
  const p=await ladePeriode(env,tenantId,periodId);
  const eigene=await eigeneDozenten(env,tenantId,auth.userId);
  if(!eigene.has(p.teacher_id))throw new Error('FORBIDDEN_TEACHER_FEE_CONFIRM');
  if(p.status!=='proposed')throw new Error('TEACHER_FEE_PERIOD_NOT_PROPOSED');
  const ts=nowIso();
  // Der Zustand steht in der WHERE-Bedingung, nicht nur in der Pruefung darueber: bestaetigen
  // zwei Sitzungen gleichzeitig, gewinnt genau eine.
  const r=await env.DB.prepare(
    `UPDATE teacher_fee_periods SET status='confirmed',confirmed_at=?,confirmed_by=?,updated_at=?
      WHERE tenant_id=? AND id=? AND status='proposed'`
  ).bind(ts,auth.userId,ts,tenantId,periodId).run();
  if(!Number(r.meta?.changes||0))throw new Error('TEACHER_FEE_PERIOD_NOT_PROPOSED');
  await audit(env.DB,auth.userId,'teacher_fee.period_confirmed',tenantId,undefined,'teacher_fee_period',periodId,{teacher_id:p.teacher_id,total_cents:p.total_cents});
  return{periodId,status:'confirmed',totalCents:p.total_cents,display:alsEuro(p.total_cents,p.currency)};
}

/** Die Verwaltung gibt frei. Ab hier ist die Abrechnung unveraenderlich. */
export async function approveTeacherFeePeriod(env:Env,auth:CoreAuthContext,tenantId:string,periodId:string){
  assertVerwaltung(auth);
  const p=await ladePeriode(env,tenantId,periodId);
  if(p.status!=='confirmed')throw new Error('TEACHER_FEE_PERIOD_NOT_CONFIRMED');
  const ts=nowIso();
  const r=await env.DB.prepare(
    `UPDATE teacher_fee_periods SET status='approved',approved_at=?,approved_by=?,updated_at=?
      WHERE tenant_id=? AND id=? AND status='confirmed'`
  ).bind(ts,auth.userId,ts,tenantId,periodId).run();
  if(!Number(r.meta?.changes||0))throw new Error('TEACHER_FEE_PERIOD_NOT_CONFIRMED');
  await audit(env.DB,auth.userId,'teacher_fee.period_approved',tenantId,undefined,'teacher_fee_period',periodId,{teacher_id:p.teacher_id,total_cents:p.total_cents});
  return{periodId,status:'approved',totalCents:p.total_cents,display:alsEuro(p.total_cents,p.currency)};
}

/**
 * Widerspruch: eine bestaetigte Abrechnung geht zurueck in den Vorschlag, damit neu gerechnet
 * werden kann. Eine freigegebene geht NICHT zurueck - sonst waere der eingefrorene Satz ueber den
 * Umweg "zurueck, neu rechnen" doch wieder aenderbar.
 */
export async function reopenTeacherFeePeriod(env:Env,auth:CoreAuthContext,tenantId:string,periodId:string){
  assertVerwaltung(auth);
  const p=await ladePeriode(env,tenantId,periodId);
  if(p.status!=='confirmed')throw new Error('TEACHER_FEE_PERIOD_NOT_CONFIRMED');
  const ts=nowIso();
  const r=await env.DB.prepare(
    `UPDATE teacher_fee_periods SET status='proposed',confirmed_at=NULL,confirmed_by=NULL,updated_at=?
      WHERE tenant_id=? AND id=? AND status='confirmed'`
  ).bind(ts,tenantId,periodId).run();
  if(!Number(r.meta?.changes||0))throw new Error('TEACHER_FEE_PERIOD_NOT_CONFIRMED');
  await audit(env.DB,auth.userId,'teacher_fee.period_reopened',tenantId,undefined,'teacher_fee_period',periodId,{teacher_id:p.teacher_id});
  return{periodId,status:'proposed'};
}

/**
 * Die Buchhaltung vermerkt die Auszahlung.
 *
 * Das ist ausdruecklich KEIN Zahlungsverkehr: es wird nichts ueberwiesen, nichts an einen
 * Dienstleister gemeldet und keine Bankverbindung gelesen. Der Vermerk haelt fest, dass eine
 * Auszahlung ausserhalb des Portals stattgefunden hat - sonst stuende dieselbe Abrechnung im
 * naechsten Monat wieder auf der Auszahlungsliste.
 */
export async function markTeacherFeePeriodPaid(env:Env,auth:CoreAuthContext,tenantId:string,periodId:string){
  assertVerwaltung(auth);
  const p=await ladePeriode(env,tenantId,periodId);
  if(p.status!=='approved')throw new Error('TEACHER_FEE_PERIOD_NOT_APPROVED');
  const ts=nowIso();
  const r=await env.DB.prepare(
    `UPDATE teacher_fee_periods SET status='paid',paid_at=?,paid_by=?,updated_at=?
      WHERE tenant_id=? AND id=? AND status='approved'`
  ).bind(ts,auth.userId,ts,tenantId,periodId).run();
  if(!Number(r.meta?.changes||0))throw new Error('TEACHER_FEE_PERIOD_NOT_APPROVED');
  await audit(env.DB,auth.userId,'teacher_fee.period_marked_paid',tenantId,undefined,'teacher_fee_period',periodId,{teacher_id:p.teacher_id,total_cents:p.total_cents});
  return{periodId,status:'paid',totalCents:p.total_cents,display:alsEuro(p.total_cents,p.currency)};
}

/**
 * Die Auszahlungsliste fuer die Buchhaltung: was freigegeben ist und noch aussteht.
 *
 * Sie enthaelt Person, Zeitraum, Minuten und Betrag - und ausdruecklich keine Bankverbindung und
 * keinen Zahlungsauftrag. Die Ueberweisung selbst passiert ausserhalb des Portals; hier steht
 * nur, was zu zahlen ist und worauf es sich stuetzt.
 */
export async function teacherFeePayoutList(env:Env,auth:CoreAuthContext,tenantId:string,input:Row={}){
  assertVerwaltung(auth);
  const von=input.from?datum(input.from,'TEACHER_FEE_PERIOD_INVALID'):null;
  const bis=input.to?datum(input.to,'TEACHER_FEE_PERIOD_INVALID'):null;
  if(von&&bis&&bis<von)throw new Error('TEACHER_FEE_PERIOD_INVALID');
  const status=safeString(input.status,20)||'approved';
  if(!['approved','paid'].includes(status))throw new Error('TEACHER_FEE_PAYOUT_STATUS_INVALID');
  const rows=((await env.DB.prepare(
    `SELECT p.id,p.teacher_id,p.period_from,p.period_to,p.status,p.minutes_total,p.total_cents,p.currency,
            p.approved_at,p.paid_at,t.name teacher_name,t.email teacher_email
       FROM teacher_fee_periods p JOIN teachers t ON t.id=p.teacher_id AND t.tenant_id=p.tenant_id
      WHERE p.tenant_id=?1 AND p.status=?2 AND (?3 IS NULL OR p.period_to>=?3) AND (?4 IS NULL OR p.period_from<=?4)
      ORDER BY t.name,p.period_from`
  ).bind(tenantId,status,von,bis).all<Row>()).results)??[];
  const summe=rows.reduce((n,r)=>n+Number(r.total_cents||0),0);
  const minuten=rows.reduce((n,r)=>n+Number(r.minutes_total||0),0);
  return{status,from:von,to:bis,
    rows:rows.map(r=>({...r,display:alsEuro(Number(r.total_cents||0),String(r.currency||'EUR'))})),
    count:rows.length,total_minutes:minuten,total_cents:summe,total_display:alsEuro(summe)};
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { bloeckeLesen, portalDarstellung } from './communication-content.js';
import { id, inBloecken, nowIso, safeString } from './utils.js';

// Benachrichtigungszentrum und Prioritaetshierarchie (Master-Spec V2, K3 und K5).
//
// ZWEI Dinge stehen hier, und sie gehoeren zusammen:
//
// 1. DIE DURCHSETZUNG DER RANGFOLGE. Eine verbindliche Mitteilung der Einrichtung darf sich nicht
//    ausblenden, stummschalten oder wegfiltern lassen. Das gehoert in den ZUSTELLWEG und nicht in
//    die Anzeige: was die Oberflaeche filtert, filtert der naechste Browser anders, und eine
//    Regel, die nur im Browser gilt, gilt nicht. kanalUrteil() ist die einzige Stelle, an der
//    entschieden wird, ob ein Weg bedient, verzoegert oder unterdrueckt wird.
//
// 2. DIE EINSTELLUNGEN DER PERSON. Ohne sie bleibt als einziges Mittel gegen zu viele Meldungen
//    das Wegsehen - und dann geht die verbindliche Mitteilung mit unter. Die Einstellungen sind
//    also kein Zugestaendnis gegen die Zustellung, sondern ihre Voraussetzung.

export type Rangstufe='normal'|'wichtig'|'verbindlich';
export type Kanal='portal'|'mail'|'push';
export const RANGSTUFEN:Rangstufe[]=['normal','wichtig','verbindlich'];
// Themen, gegen die eine Abwahl greifen kann. Eine feste Liste, damit die Abwahl einer Person
// nicht ins Leere laeuft, sobald jemand ein Thema anders schreibt.
export const THEMEN=['allgemein','organisation','unterricht','pruefung','termine','abrechnung'] as const;

export type Praeferenz={mail_aktiv:number;push_aktiv:number;ruhe_von:string|null;ruhe_bis:string|null};
export type Kanalurteil={zustellen:boolean;faellig_ab:string|null;entscheidung:'unterdrueckt'|'verzoegert'|null;grund:'themenabwahl'|'kanal_abgeschaltet'|'ruhezeit'|null};

export const STANDARD_PRAEFERENZ:Praeferenz={mail_aktiv:1,push_aktiv:1,ruhe_von:null,ruhe_bis:null};

export function pruefeRangstufe(wert:unknown,fallback:Rangstufe='normal'):Rangstufe{
  if(wert==null||wert==='')return fallback;
  const x=String(wert);
  if(!RANGSTUFEN.includes(x as Rangstufe))throw new Error('KOMMUNIKATION_RANGSTUFE_UNGUELTIG');
  return x as Rangstufe;
}
export function pruefeThema(wert:unknown):string{
  if(wert==null||wert==='')return 'allgemein';
  const x=String(wert);
  if(!(THEMEN as readonly string[]).includes(x))throw new Error('KOMMUNIKATION_THEMA_UNGUELTIG');
  return x;
}
function pruefeUhrzeit(wert:unknown):string|null{
  const x=safeString(wert,5).trim();
  if(!x)return null;
  if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(x))throw new Error('BENACHRICHTIGUNG_RUHEZEIT_UNGUELTIG');
  return x;
}

// Die Ortszeit des Traegers. Eine Ruhezeit von 22:00 bis 07:00 ist eine Angabe ueber den Abend
// der Person, nicht ueber UTC; ohne Umrechnung laege die Nachtruhe in Deutschland im Sommer zwei
// Stunden falsch. Faellt die Zeitzone aus, wird UTC genommen - lieber eine Stunde daneben als
// eine Ausnahme mitten in der Zustellung.
export function minutenOrtszeit(iso:string,zeitzone:string):number{
  try{
    const teile=new Intl.DateTimeFormat('de-DE',{timeZone:zeitzone,hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date(iso));
    const h=Number(teile.find(t=>t.type==='hour')?.value??'0'),m=Number(teile.find(t=>t.type==='minute')?.value??'0');
    return (h%24)*60+m;
  }catch{const d=new Date(iso);return d.getUTCHours()*60+d.getUTCMinutes();}
}
function alsMinuten(hhmm:string):number{return Number(hhmm.slice(0,2))*60+Number(hhmm.slice(3,5));}

/** Liegt der Zeitpunkt in der Ruhezeit? Ueber Mitternacht hinweg (22:00-07:00) ausdruecklich mitgedacht. */
export function inRuhezeit(praeferenz:Praeferenz,jetzt:string,zeitzone:string):boolean{
  if(!praeferenz.ruhe_von||!praeferenz.ruhe_bis)return false;
  const von=alsMinuten(praeferenz.ruhe_von),bis=alsMinuten(praeferenz.ruhe_bis),jetztMin=minutenOrtszeit(jetzt,zeitzone);
  if(von===bis)return false;
  return von<bis?jetztMin>=von&&jetztMin<bis:jetztMin>=von||jetztMin<bis;
}
/** Wann der Weg wieder frei ist. Gerechnet in Minuten bis zum Ende - das gilt auch ueber Mitternacht. */
export function ruhezeitEnde(praeferenz:Praeferenz,jetzt:string,zeitzone:string):string{
  const bis=alsMinuten(String(praeferenz.ruhe_bis||'00:00')),jetztMin=minutenOrtszeit(jetzt,zeitzone);
  const minuten=((bis-jetztMin)%1440+1440)%1440||1440;
  return new Date(new Date(jetzt).getTime()+minuten*60_000).toISOString();
}

/**
 * DIE Regel aus K3, an genau einer Stelle.
 *
 *   verbindlich - schlaegt jede Nutzereinstellung und jeden Ruhezeitfilter. Ohne Ausnahme.
 *   wichtig     - achtet Ruhezeiten und abgeschaltete Wege, aber KEINE Themenabwahl: wer das Thema
 *                 „Pruefung" abbestellt hat, bekommt die wichtige Pruefungsmitteilung trotzdem.
 *   normal      - achtet beides.
 *
 * Der Weg „portal" ist die Glocke im Portal. Ruhezeiten gelten fuer ihn nicht: er unterbricht
 * niemanden, er wartet. Abschalten laesst er sich auch nicht - die Mitteilung selbst steht
 * unabhaengig davon in der Liste; unterdrueckt wird nur der HINWEIS darauf.
 */
export function kanalUrteil(kanal:Kanal,rangstufe:Rangstufe,opt:{abbestellt:boolean;praeferenz:Praeferenz|null;jetzt:string;zeitzone:string}):Kanalurteil{
  const frei:Kanalurteil={zustellen:true,faellig_ab:null,entscheidung:null,grund:null};
  if(rangstufe==='verbindlich')return frei;
  const praeferenz=opt.praeferenz??STANDARD_PRAEFERENZ;
  if(opt.abbestellt&&rangstufe==='normal')return{zustellen:false,faellig_ab:null,entscheidung:'unterdrueckt',grund:'themenabwahl'};
  if(kanal==='portal')return frei;
  const an=kanal==='mail'?Number(praeferenz.mail_aktiv??1):Number(praeferenz.push_aktiv??1);
  if(!an)return{zustellen:false,faellig_ab:null,entscheidung:'unterdrueckt',grund:'kanal_abgeschaltet'};
  if(inRuhezeit(praeferenz,opt.jetzt,opt.zeitzone))return{zustellen:false,faellig_ab:ruhezeitEnde(praeferenz,opt.jetzt,opt.zeitzone),entscheidung:'verzoegert',grund:'ruhezeit'};
  return frei;
}

// --- Lesen, was eine Menge von Menschen eingestellt hat ------------------------------------------
// Gestapelt nach Kennungen: eine Abfrage je 200 Empfaengern statt einer je Empfaenger. Bei 500
// Empfaengern sind das drei Unteranfragen statt fuenfhundert.
export async function praeferenzenFuerNutzer(env:Env,tenantId:string,userIds:string[]):Promise<Map<string,Praeferenz>>{
  const out=new Map<string,Praeferenz>();
  for(const teil of inBloecken([...new Set(userIds)],200)){
    if(!teil.length)continue;
    const marks=teil.map(()=>'?').join(',');
    const rows=(await env.DB.prepare(`SELECT user_id,mail_aktiv,push_aktiv,ruhe_von,ruhe_bis FROM notification_preferences WHERE tenant_id=? AND user_id IN (${marks})`).bind(tenantId,...teil).all<Record<string,unknown>>()).results??[];
    for(const r of rows)out.set(String(r.user_id),{mail_aktiv:Number(r.mail_aktiv??1),push_aktiv:Number(r.push_aktiv??1),ruhe_von:r.ruhe_von?String(r.ruhe_von):null,ruhe_bis:r.ruhe_bis?String(r.ruhe_bis):null});
  }
  return out;
}
export async function themenAbwahlFuerNutzer(env:Env,tenantId:string,thema:string,userIds:string[]):Promise<Set<string>>{
  const out=new Set<string>();
  for(const teil of inBloecken([...new Set(userIds)],200)){
    if(!teil.length)continue;
    const marks=teil.map(()=>'?').join(',');
    const rows=(await env.DB.prepare(`SELECT user_id FROM notification_topic_preferences WHERE tenant_id=? AND thema=? AND abbestellt=1 AND user_id IN (${marks})`).bind(tenantId,thema,...teil).all<{user_id:string}>()).results??[];
    for(const r of rows)out.add(String(r.user_id));
  }
  return out;
}
/** Wer ueberhaupt ein Geraet fuer Kurzmeldungen angemeldet hat. Ohne Geraet gibt es nichts zu unterdruecken. */
export async function nutzerMitPushGeraet(env:Env,tenantId:string,userIds:string[]):Promise<Set<string>>{
  const out=new Set<string>();
  for(const teil of inBloecken([...new Set(userIds)],200)){
    if(!teil.length)continue;
    const marks=teil.map(()=>'?').join(',');
    const rows=(await env.DB.prepare(`SELECT DISTINCT user_id FROM push_subscriptions WHERE tenant_id=? AND status='active' AND user_id IN (${marks})`).bind(tenantId,...teil).all<{user_id:string}>()).results??[];
    for(const r of rows)out.add(String(r.user_id));
  }
  return out;
}
export async function zeitzoneDesTraegers(env:Env,tenantId:string):Promise<string>{
  const r=await env.DB.prepare('SELECT timezone FROM tenant_settings WHERE tenant_id=?').bind(tenantId).first<{timezone:string|null}>();
  return safeString(r?.timezone,60)||'Europe/Berlin';
}

// --- Das Zentrum: was habe ich bekommen, worueber, und was steht offen? --------------------------
type ZentrumZeile=Record<string,unknown>;

function entscheidungenLesen(roh:unknown):{kanal:string;entscheidung:string;grund:string}[]{
  return String(roh??'').split(',').filter(Boolean).map(x=>{const [kanal,entscheidung,grund]=x.split(':');return{kanal,entscheidung,grund};});
}

/**
 * Eine Stelle, an der eine Person sieht, was sie bekommen hat, ueber welchen Weg, und was davon
 * zugestellt, gelesen und quittiert ist. Eine Abfrage - nicht eine je Meldung.
 */
export async function meinBenachrichtigungszentrum(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'participant');
  const rows=(await env.DB.prepare("SELECT m.id,m.title,m.priority,m.rangstufe,m.thema,m.status,m.published_at,m.require_ack,m.ack_due_at,m.send_email,m.body,m.bloecke_json,r.delivered_at,r.read_at,r.acknowledged_at,r.reminder_count,r.last_reminded_at,(SELECT e.status FROM communication_email_deliveries e WHERE e.message_id=m.id AND e.user_id=r.user_id) AS mail_status,(SELECT o.status FROM push_outbox o JOIN notifications n ON n.id=o.notification_id WHERE n.quelle_typ='communication' AND n.quelle_id=m.id AND o.user_id=r.user_id ORDER BY o.created_at DESC LIMIT 1) AS push_status,(SELECT group_concat(cd.kanal||':'||cd.entscheidung||':'||cd.grund) FROM communication_channel_decisions cd WHERE cd.message_id=m.id AND cd.user_id=r.user_id) AS entscheidungen FROM communication_recipients r JOIN communication_messages m ON m.id=r.message_id WHERE r.tenant_id=? AND r.user_id=? AND m.status IN ('published','closed') ORDER BY CASE m.rangstufe WHEN 'verbindlich' THEN 1 WHEN 'wichtig' THEN 2 ELSE 3 END,m.published_at DESC LIMIT 200").bind(tenantId,auth.userId).all<ZentrumZeile>()).results??[];
  const meldungen=rows.map(r=>({
    id:String(r.id),titel:String(r.title),priority:String(r.priority),rangstufe:String(r.rangstufe),thema:String(r.thema),
    status:String(r.status),veroeffentlicht_am:r.published_at??null,quittung_noetig:Number(r.require_ack||0)===1,quittung_faellig_am:r.ack_due_at??null,
    bloecke:portalDarstellung(bloeckeLesen(r.bloecke_json,r.body)),
    zugestellt_am:r.delivered_at??null,gelesen_am:r.read_at??null,quittiert_am:r.acknowledged_at??null,
    erinnerungen:Number(r.reminder_count||0),zuletzt_erinnert_am:r.last_reminded_at??null,
    kanaele:{portal:'zugestellt',mail:Number(r.send_email||0)?(r.mail_status??'nicht_erzeugt'):'nicht_gewaehlt',push:r.push_status??'nicht_erzeugt'},
    entscheidungen:entscheidungenLesen(r.entscheidungen),
  }));
  return{meldungen,offen:meldungen.filter(m=>m.quittung_noetig&&!m.quittiert_am).length,praeferenzen:await meinePraeferenzen(env,auth,tenantId)};
}

export async function meinePraeferenzen(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'participant');
  const zeile=await env.DB.prepare('SELECT mail_aktiv,push_aktiv,ruhe_von,ruhe_bis,aktualisiert_am FROM notification_preferences WHERE tenant_id=? AND user_id=?').bind(tenantId,auth.userId).first<Record<string,unknown>>();
  const themen=(await env.DB.prepare('SELECT thema,abbestellt FROM notification_topic_preferences WHERE tenant_id=? AND user_id=?').bind(tenantId,auth.userId).all<Record<string,unknown>>()).results??[];
  const abbestellt=new Set(themen.filter(t=>Number(t.abbestellt||0)===1).map(t=>String(t.thema)));
  return{
    mail_aktiv:Number(zeile?.mail_aktiv??1)===1,push_aktiv:Number(zeile?.push_aktiv??1)===1,
    ruhe_von:zeile?.ruhe_von??null,ruhe_bis:zeile?.ruhe_bis??null,aktualisiert_am:zeile?.aktualisiert_am??null,
    themen:THEMEN.map(t=>({thema:t,abbestellt:abbestellt.has(t)})),
    // Steht in der Antwort, damit die Oberflaeche es sagen MUSS statt eine Abschaltung
    // vorzutaeuschen, die es nicht gibt.
    hinweis:'Verbindliche Mitteilungen der Einrichtung erreichen Dich unabhängig von diesen Einstellungen.',
  };
}

export async function speicherePraeferenzen(env:Env,auth:CoreAuthContext,tenantId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'participant');
  const mail=eingabe.mail_aktiv===false?0:1,push=eingabe.push_aktiv===false?0:1;
  const von=pruefeUhrzeit(eingabe.ruhe_von),bis=pruefeUhrzeit(eingabe.ruhe_bis);
  // Eine halbe Ruhezeit ist keine: ohne Ende wuerde sie nie aufhoeren und jede nicht verbindliche
  // Benachrichtigung dauerhaft verschlucken.
  if(!!von!==!!bis)throw new Error('BENACHRICHTIGUNG_RUHEZEIT_UNVOLLSTAENDIG');
  const roheThemen=Array.isArray(eingabe.themen)?eingabe.themen as Record<string,unknown>[]:[];
  if(roheThemen.length>THEMEN.length)throw new Error('KOMMUNIKATION_THEMA_UNGUELTIG');
  const ts=nowIso(),anweisungen=[env.DB.prepare('INSERT INTO notification_preferences(tenant_id,user_id,mail_aktiv,push_aktiv,ruhe_von,ruhe_bis,aktualisiert_am) VALUES(?,?,?,?,?,?,?) ON CONFLICT(tenant_id,user_id) DO UPDATE SET mail_aktiv=excluded.mail_aktiv,push_aktiv=excluded.push_aktiv,ruhe_von=excluded.ruhe_von,ruhe_bis=excluded.ruhe_bis,aktualisiert_am=excluded.aktualisiert_am').bind(tenantId,auth.userId,mail,push,von,bis,ts)];
  for(const t of roheThemen){
    const thema=pruefeThema(t?.thema);
    anweisungen.push(env.DB.prepare('INSERT INTO notification_topic_preferences(tenant_id,user_id,thema,abbestellt,aktualisiert_am) VALUES(?,?,?,?,?) ON CONFLICT(tenant_id,user_id,thema) DO UPDATE SET abbestellt=excluded.abbestellt,aktualisiert_am=excluded.aktualisiert_am').bind(tenantId,auth.userId,thema,t?.abbestellt===true?1:0,ts));
  }
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'notification.preferences_saved',tenantId,undefined,'user',auth.userId,{mail_aktiv:mail===1,push_aktiv:push===1,ruhezeit:!!von,themen:roheThemen.length});
  return meinePraeferenzen(env,auth,tenantId);
}

/**
 * Die Zeilen, die eine Unterdrueckung oder Verzoegerung festhalten. Sie sind der fehlende Teil des
 * Nachweises: eine nicht erfolgte Benachrichtigung ist von einer erfolgten nur zu unterscheiden,
 * wenn sie irgendwo steht.
 */
export function entscheidungsAnweisung(env:Env,args:{messageId:string;tenantId:string;userId:string;kanal:Kanal;urteil:Kanalurteil;rangstufe:Rangstufe},ts:string){
  return env.DB.prepare('INSERT INTO communication_channel_decisions(message_id,tenant_id,user_id,kanal,entscheidung,grund,rangstufe,faellig_ab,erstellt_am) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(message_id,user_id,kanal) DO UPDATE SET entscheidung=excluded.entscheidung,grund=excluded.grund,rangstufe=excluded.rangstufe,faellig_ab=excluded.faellig_ab,erstellt_am=excluded.erstellt_am')
    .bind(args.messageId,args.tenantId,args.userId,args.kanal,args.urteil.entscheidung,args.urteil.grund,args.rangstufe,args.urteil.faellig_ab,ts);
}
/** Eine vorgemerkte Kurzmeldung. `cancelled` heisst: bewusst nicht gesendet - und genau das ist der Nachweis. */
export function pushAnweisung(env:Env,args:{tenantId:string;userId:string;notificationId:string;status:'pending'|'cancelled';faellig_ab:string|null},ts:string){
  return env.DB.prepare('INSERT INTO push_outbox(id,tenant_id,user_id,notification_id,status,attempts,next_attempt_at,created_at) VALUES(?,?,?,?,?,0,?,?)')
    .bind(id('pob_'),args.tenantId,args.userId,args.notificationId,args.status,args.faellig_ab||ts,ts);
}

import type { Env } from './types.js';
import type { BillingCycle, CommercialOffer } from './commerce-offers.js';
import type { PriceCalculation } from './commerce.js';
import { nowIso, safeString } from './utils.js';
import { stripeMode } from './stripe-mode.js';
import { persistStripeModeState, prepareStripeModeState } from './stripe-mode-state.js';
import { assertPaymentsEnabled } from './payment-policy.js';

type StripeObj=Record<string,any>;
export type TaxCatalogRow={plan_id:string;billing_cycle:BillingCycle;currency:string;base_product_id:string;base_price_id:string;base_amount_cents:number;extra_product_id:string|null;extra_price_id:string|null;extra_amount_cents:number|null;tax_behavior:string;tax_code:string};
const API='https://api.stripe.com/v1';
const SAAS_TAX_CODE='txcd_10103001';
const SERVICE_TAX_CODE='txcd_20030000';
const TAX_BEHAVIOR='exclusive';

function sid(v:any):string|null{return typeof v==='string'?v:v&&typeof v.id==='string'?v.id:null;}
function params(entries:Array<[string,unknown]>):URLSearchParams{const p=new URLSearchParams();for(const [k,v] of entries)if(v!==undefined&&v!==null&&String(v)!=='')p.append(k,String(v));return p;}
async function stripe(env:Env,method:'GET'|'POST',path:string,entries:Array<[string,unknown]>=[],idem?:string):Promise<StripeObj>{
  assertPaymentsEnabled(env);
  if(!env.STRIPE_SECRET_KEY||!env.STRIPE_WEBHOOK_SECRET)throw new Error('STRIPE_NOT_CONFIGURED');
  stripeMode(env);
  const p=params(entries);let url=`${API}${path}`;if(method==='GET'&&p.toString())url+=`?${p}`;
  const headers:Record<string,string>={Authorization:`Bearer ${env.STRIPE_SECRET_KEY}`};if(method==='POST')headers['content-type']='application/x-www-form-urlencoded';if(idem)headers['Idempotency-Key']=idem.slice(0,255);
  const r=await fetch(url,{method,headers,body:method==='POST'?p:undefined});let d:any={};try{d=await r.json();}catch{}
  if(!r.ok){const code=String(d?.error?.code||d?.error?.type||'API_ERROR').toUpperCase().replace(/[^A-Z0-9]+/g,'_');throw new Error(`STRIPE_${code}`);}return d;
}
async function product(env:Env,name:string,planId:string,component:'base'|'extra',existing?:string|null):Promise<string>{
  const mode=stripeMode(env);
  if(existing){await stripe(env,'POST',`/products/${encodeURIComponent(existing)}`,[['tax_code',SAAS_TAX_CODE]]);return existing;}
  const p=await stripe(env,'POST','/products',[[ 'name',name],['tax_code',SAAS_TAX_CODE],['metadata[klassenportal_plan_id]',planId],['metadata[klassenportal_component]',component],['metadata[klassenportal_mode]',mode]],`tax-product:${mode}:${planId}:${component}`);const id=sid(p);if(!id)throw new Error('STRIPE_PRODUCT_CREATE_FAILED');return id;
}

export async function ensureTaxStripeCatalog(env:Env,price:PriceCalculation|CommercialOffer,cycle:BillingCycle):Promise<TaxCatalogRow>{
  const mode=await prepareStripeModeState(env),annualMonths='annualMonthsCharged' in price?Number((price as CommercialOffer).annualMonthsCharged||10):10;
  const baseAmount=cycle==='annual'?Number(price.monthlyBaseCents)*annualMonths:Number(price.monthlyBaseCents),extraMonthly=price.extraCourseMonthlyCents===null?null:Number(price.extraCourseMonthlyCents),extraAmount=extraMonthly===null?null:(cycle==='annual'?extraMonthly*annualMonths:extraMonthly),currency=String(price.currency||'EUR').toUpperCase();
  let row=await env.DB.prepare('SELECT * FROM stripe_plan_prices WHERE plan_id=? AND billing_cycle=? AND stripe_mode=?').bind(price.planId,cycle,mode).first<TaxCatalogRow>();
  const baseProduct=await product(env,`Klassenportal ${price.planName}`,price.planId,'base',row?.base_product_id),extraProduct=extraAmount!==null?await product(env,`Klassenportal ${price.planName} – zusätzliche Klasse/Kurs`,price.planId,'extra',row?.extra_product_id):null;
  let basePrice=row?.base_price_id||null,extraPrice=row?.extra_price_id||null;
  const baseNeeds=!row||Number(row.base_amount_cents)!==baseAmount||row.currency!==currency||row.tax_behavior!==TAX_BEHAVIOR||row.tax_code!==SAAS_TAX_CODE;
  if(baseNeeds){const p=await stripe(env,'POST','/prices',[[ 'currency',currency.toLowerCase()],['unit_amount',baseAmount],['product',baseProduct],['tax_behavior',TAX_BEHAVIOR],['recurring[interval]',cycle==='annual'?'year':'month'],['nickname',`${price.planName} ${cycle==='annual'?'jährlich':'monatlich'} netto`],['metadata[klassenportal_plan_id]',price.planId],['metadata[klassenportal_component]','base'],['metadata[klassenportal_cycle]',cycle],['metadata[klassenportal_mode]',mode]],`tax-price:${mode}:${price.planId}:${cycle}:base:${baseAmount}:${currency}`);basePrice=sid(p);if(!basePrice)throw new Error('STRIPE_PRICE_CREATE_FAILED');}
  const extraNeeds=extraAmount!==null&&extraProduct&&(!row||Number(row.extra_amount_cents)!==extraAmount||row.currency!==currency||row.tax_behavior!==TAX_BEHAVIOR||row.tax_code!==SAAS_TAX_CODE||!extraPrice);
  if(extraNeeds){const p=await stripe(env,'POST','/prices',[[ 'currency',currency.toLowerCase()],['unit_amount',extraAmount],['product',extraProduct],['tax_behavior',TAX_BEHAVIOR],['recurring[interval]',cycle==='annual'?'year':'month'],['nickname',`${price.planName} Zusatzklasse ${cycle==='annual'?'jährlich':'monatlich'} netto`],['metadata[klassenportal_plan_id]',price.planId],['metadata[klassenportal_component]','extra'],['metadata[klassenportal_cycle]',cycle],['metadata[klassenportal_mode]',mode]],`tax-price:${mode}:${price.planId}:${cycle}:extra:${extraAmount}:${currency}`);extraPrice=sid(p);if(!extraPrice)throw new Error('STRIPE_PRICE_CREATE_FAILED');}
  const ts=nowIso();await env.DB.prepare(`INSERT INTO stripe_plan_prices(plan_id,billing_cycle,stripe_mode,currency,base_product_id,base_price_id,base_amount_cents,extra_product_id,extra_price_id,extra_amount_cents,tax_behavior,tax_code,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(plan_id,billing_cycle) DO UPDATE SET stripe_mode=excluded.stripe_mode,currency=excluded.currency,base_product_id=excluded.base_product_id,base_price_id=excluded.base_price_id,base_amount_cents=excluded.base_amount_cents,extra_product_id=excluded.extra_product_id,extra_price_id=excluded.extra_price_id,extra_amount_cents=excluded.extra_amount_cents,tax_behavior=excluded.tax_behavior,tax_code=excluded.tax_code,updated_at=excluded.updated_at`)
    .bind(price.planId,cycle,mode,currency,baseProduct,basePrice,baseAmount,extraProduct,extraPrice,extraAmount,TAX_BEHAVIOR,SAAS_TAX_CODE,ts).run();
  await persistStripeModeState(env);
  return{plan_id:price.planId,billing_cycle:cycle,currency,base_product_id:baseProduct,base_price_id:basePrice!,base_amount_cents:baseAmount,extra_product_id:extraProduct,extra_price_id:extraPrice,extra_amount_cents:extraAmount,tax_behavior:TAX_BEHAVIOR,tax_code:SAAS_TAX_CODE};
}

function countryCode(v:unknown):string|null{const s=String(v??'').trim();if(/^[A-Za-z]{2}$/.test(s))return s.toUpperCase();const n=s.toLocaleLowerCase('de-DE');if(n==='deutschland'||n==='germany')return'DE';return null;}
async function ensureCustomer(env:Env,tenantId:string):Promise<string>{
  const mode=await prepareStripeModeState(env),account=await env.DB.prepare('SELECT stripe_customer_id FROM tenant_payment_accounts WHERE tenant_id=? AND stripe_mode=?').bind(tenantId,mode).first<{stripe_customer_id:string|null}>();if(account?.stripe_customer_id)return account.stripe_customer_id;
  const p=await env.DB.prepare('SELECT legal_name,contact_name,contact_email,billing_email,street,postal_code,city,country FROM tenant_profiles WHERE tenant_id=?').bind(tenantId).first<Record<string,unknown>>()??{},cc=countryCode(p.country);
  const entries:Array<[string,unknown]>=[['name',safeString(p.legal_name||p.contact_name,250)],['email',safeString(p.billing_email||p.contact_email,250)],['address[line1]',safeString(p.street,250)],['address[postal_code]',safeString(p.postal_code,40)],['address[city]',safeString(p.city,160)],['metadata[tenant_id]',tenantId],['metadata[klassenportal_mode]',mode]];if(cc)entries.push(['address[country]',cc]);
  const c=await stripe(env,'POST','/customers',entries,`customer:${mode}:${tenantId}`),customer=sid(c);if(!customer)throw new Error('STRIPE_CUSTOMER_CREATE_FAILED');
  await env.DB.prepare(`INSERT INTO tenant_payment_accounts(tenant_id,stripe_mode,provider,stripe_customer_id,updated_at) VALUES(?,?,'stripe',?,?) ON CONFLICT(tenant_id) DO UPDATE SET stripe_mode=excluded.stripe_mode,stripe_customer_id=excluded.stripe_customer_id,stripe_subscription_id=NULL,stripe_checkout_session_id=NULL,stripe_subscription_status=NULL,billing_cycle=NULL,current_plan_id=NULL,current_course_limit=NULL,current_period_end=NULL,cancel_at_period_end=0,last_invoice_id=NULL,updated_at=excluded.updated_at`).bind(tenantId,mode,customer,nowIso()).run();
  await persistStripeModeState(env);
  return customer;
}

export async function createTaxStripeCheckout(env:Env,args:{tenantId:string;orderId:string;invoiceId:string;offer:CommercialOffer;request:Request}):Promise<{checkoutSessionId:string;checkoutUrl:string}>{
  const mode=await prepareStripeModeState(env),offer=args.offer as CommercialOffer&{manualPricing?:boolean;quoteNumber?:string},manual=!!offer.manualPricing,customer=await ensureCustomer(env,args.tenantId),origin=env.APP_ORIGIN||new URL(args.request.url).origin,currency=String(offer.currency||'EUR').toLowerCase();
  const e:Array<[string,unknown]>=[['mode','subscription'],['locale','de'],['customer',customer],['client_reference_id',args.orderId],['success_url',`${origin}/zahlung/erfolg?session_id={CHECKOUT_SESSION_ID}`],['cancel_url',`${origin}/zahlung/abgebrochen`],['billing_address_collection','required'],['customer_update[address]','auto'],['customer_update[name]','auto'],['automatic_tax[enabled]','true'],['tax_id_collection[enabled]','true'],['tax_id_collection[required]','if_supported'],['metadata[tenant_id]',args.tenantId],['metadata[order_id]',args.orderId],['metadata[invoice_id]',args.invoiceId],['metadata[plan_id]',offer.planId],['metadata[course_limit]',offer.courseCount],['metadata[billing_cycle]',offer.billingCycle],['metadata[klassenportal_mode]',mode],['subscription_data[metadata][tenant_id]',args.tenantId],['subscription_data[metadata][order_id]',args.orderId],['subscription_data[metadata][plan_id]',offer.planId],['subscription_data[metadata][course_limit]',offer.courseCount],['subscription_data[metadata][billing_cycle]',offer.billingCycle],['subscription_data[metadata][klassenportal_mode]',mode]];
  let line=0;
  if(manual){
    const amount=offer.billingCycle==='annual'?Number(offer.annualTotalCents):Number(offer.recurringMonthlyCents);if(!Number.isFinite(amount)||amount<1)throw new Error('MANUAL_OFFER_PRICE_INVALID');
    e.push([`line_items[${line}][price_data][currency]`,currency],[`line_items[${line}][price_data][unit_amount]`,amount],[`line_items[${line}][price_data][tax_behavior]`,TAX_BEHAVIOR],[`line_items[${line}][price_data][recurring][interval]`,offer.billingCycle==='annual'?'year':'month'],[`line_items[${line}][price_data][product_data][name]`,`Klassenportal ${offer.planName} – individuelles Angebot`],[`line_items[${line}][price_data][product_data][tax_code]`,SAAS_TAX_CODE],[`line_items[${line}][quantity]`,'1']);line++;
  }else{
    const catalog=await ensureTaxStripeCatalog(env,offer,offer.billingCycle);e.push([`line_items[${line}][price]`,catalog.base_price_id],[`line_items[${line}][quantity]`,'1']);line++;
    if(offer.extraCourses>0&&catalog.extra_price_id){e.push([`line_items[${line}][price]`,catalog.extra_price_id],[`line_items[${line}][quantity]`,offer.extraCourses]);line++;}
  }
  if(offer.managedSetupCents>0)e.push([`line_items[${line}][price_data][currency]`,currency],[`line_items[${line}][price_data][unit_amount]`,offer.managedSetupCents],[`line_items[${line}][price_data][tax_behavior]`,TAX_BEHAVIOR],[`line_items[${line}][price_data][product_data][name]`,offer.managedSetupName],[`line_items[${line}][price_data][product_data][tax_code]`,SERVICE_TAX_CODE],[`line_items[${line}][quantity]`,'1']);
  const session=await stripe(env,'POST','/checkout/sessions',e,`tax-checkout:${mode}:${args.orderId}`),sessionId=sid(session),url=String(session.url||'');if(!sessionId||!url)throw new Error('STRIPE_CHECKOUT_CREATE_FAILED');
  await env.DB.batch([env.DB.prepare('UPDATE commercial_orders SET external_checkout_id=? WHERE id=? AND tenant_id=?').bind(sessionId,args.orderId,args.tenantId),env.DB.prepare(`UPDATE tenant_payment_accounts SET stripe_checkout_session_id=?,billing_cycle=?,current_plan_id=?,current_course_limit=?,updated_at=? WHERE tenant_id=? AND stripe_mode=?`).bind(sessionId,offer.billingCycle,offer.planId,offer.courseCount,nowIso(),args.tenantId,mode)]);
  await persistStripeModeState(env);
  return{checkoutSessionId:sessionId,checkoutUrl:url};
}

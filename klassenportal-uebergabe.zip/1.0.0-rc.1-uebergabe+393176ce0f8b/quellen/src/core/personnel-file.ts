import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Die Personalakte.
//
// Das Portal kannte Lehrkraefte als Zeile mit Namen und E-Mail. Alles, was ein Traeger einer
// Pruefung nach AZAV oder einer Zertifizierung vorlegen muss, lag daneben: Vertrag,
// Beschaeftigungszeitraum, Urlaub, Krankheit, Arbeitszeit, Unterweisungen - und der Austritt.
//
// Vier Regeln tragen dieses Modul. Sie sind nicht erfunden, sondern die Stellen, an denen es in
// der Praxis schiefgeht:
//
//  1. DER ZUGANG GEHT MIT. Beim Ausscheiden wurde nirgends der Portalzugang entzogen - es gab
//     nicht einmal eine Verbindung von der Lehrkraft zum Benutzerkonto. Wer ging, behielt Kurse,
//     Klassenbuecher und Teilnehmerdaten, unbegrenzt.
//  2. KEINE SACHGRUNDLOSE BEFRISTUNG NACH VORBESCHAEFTIGUNG (§ 14 Abs. 2 TzBfG). Wer sie
//     trotzdem vereinbart, hat nach § 16 TzBfG einen unbefristeten Vertrag - und erfaehrt es vor
//     Gericht.
//  3. KEINE ZWEI VERTRAEGE ZUR SELBEN ZEIT. Sie entstehen beim Verlaengern und verdoppeln danach
//     jede Auswertung.
//  4. EINE UNTERWEISUNG OHNE FRIST WIRD NIE WIEDER ANGEFASST. Deshalb traegt jede ihr Intervall
//     bei sich, und der taegliche Lauf erinnert.

const clean=(v:unknown,n=2000)=>safeString(v,n);
export const FUNKTIONEN=['lehrkraft','verwaltung','leitung','sozialpaedagogik','ausbildung','sonstiges'] as const;
export const VERTRAGSARTEN=['festanstellung','teilzeit','honorar','minijob','praktikum','ehrenamt'] as const;
export const ABWESENHEITSARTEN=['urlaub','krankheit','fortbildung','unbezahlt','sonderurlaub','mutterschutz','elternzeit'] as const;
export const UNTERWEISUNGSARTEN=['arbeitsschutz','datenschutz','kinderschutz','infektionsschutz','brandschutz','ersthelfer','fuehrungszeugnis','sonstiges'] as const;
export const AUSTRITTSGRUENDE=['kuendigung_arbeitnehmer','kuendigung_arbeitgeber','befristung_ende','aufhebung','rente','sonstiges'] as const;

/**
 * Die gesetzlichen Mindestintervalle. Ein Traeger darf haeufiger unterweisen, nie seltener.
 *
 * Arbeitsschutz jaehrlich (§ 12 ArbSchG), erweitertes Fuehrungszeugnis alle fuenf Jahre
 * (§ 72a SGB VIII - die Frist ist Vereinbarungssache, fuenf Jahre sind die uebliche Auslegung),
 * Infektionsschutz alle zwei Jahre (§ 43 IfSG).
 */
export const HOECHSTINTERVALL_MONATE:Record<string,number>={
  arbeitsschutz:12,datenschutz:24,kinderschutz:24,infektionsschutz:24,brandschutz:12,
  ersthelfer:24,fuehrungszeugnis:60,sonstiges:120};

/** Der gesetzliche Mindesturlaub bei Fuenftagewoche: 24 Werktage sind 20 Arbeitstage (§ 3 BUrlG). */
export const MINDESTURLAUB_TAGE=20;
/** Ab dem wievielten Kalendertag eine Arbeitsunfaehigkeitsbescheinigung faellig ist (§ 5 EFZG). */
export const AU_AB_TAG=4;
/** Bis wann uebertragener Urlaub genommen sein muss (§ 7 Abs. 3 BUrlG). */
export const UEBERTRAG_ENDE='-03-31';

function datum(v:unknown,feld:string){
  const s=clean(v,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(s))throw new Error(`PERSONAL_${feld}_UNGUELTIG`);
  return s;
}
function monateSpaeter(tag:string,monate:number){
  const d=new Date(`${tag}T00:00:00.000Z`);
  d.setUTCMonth(d.getUTCMonth()+monate);
  return d.toISOString().slice(0,10);
}
function tageZwischen(von:string,bis:string){
  return Math.round((Date.parse(`${bis}T00:00:00Z`)-Date.parse(`${von}T00:00:00Z`))/86400000)+1;
}

async function ladeAkte(env:Env,tenantId:string,personnelId:string){
  const z=await env.DB.prepare('SELECT id,tenant_id,user_id,teacher_id,name,status,eintritt,austritt FROM personnel_records WHERE tenant_id=? AND id=?')
    .bind(tenantId,clean(personnelId,120)).first<{id:string;tenant_id:string;user_id:string|null;teacher_id:string|null;name:string;status:string;eintritt:string;austritt:string|null}>();
  if(!z)throw new Error('PERSONAL_AKTE_NICHT_GEFUNDEN');
  return z;
}

// ---------------------------------------------------------------------------------------------
// Die Akte
// ---------------------------------------------------------------------------------------------

export async function legeAkteAn(env:Env,auth:CoreAuthContext,tenantId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const name=clean(eingabe.name,200);
  if(name.length<2)throw new Error('PERSONAL_NAME_ERFORDERLICH');
  const funktion=clean(eingabe.funktion,40)||'lehrkraft';
  if(!(FUNKTIONEN as readonly string[]).includes(funktion))throw new Error('PERSONAL_FUNKTION_UNGUELTIG');
  const eintritt=datum(eingabe.eintritt,'EINTRITT');
  const userId=clean(eingabe.user_id,120)||null;
  if(userId){
    // Ein Konto, das dem Traeger nicht gehoert, waere ein Zugang, den er nicht entziehen kann.
    const mitglied=await env.DB.prepare('SELECT 1 ok FROM tenant_users WHERE tenant_id=? AND user_id=?').bind(tenantId,userId).first();
    if(!mitglied)throw new Error('PERSONAL_KONTO_NICHT_IM_MANDANTEN');
    const doppelt=await env.DB.prepare('SELECT 1 ok FROM personnel_records WHERE tenant_id=? AND user_id=?').bind(tenantId,userId).first();
    if(doppelt)throw new Error('PERSONAL_KONTO_SCHON_IN_AKTE');
  }
  const teacherId=clean(eingabe.teacher_id,120)||null;
  if(teacherId&&!await env.DB.prepare('SELECT 1 ok FROM teachers WHERE tenant_id=? AND id=?').bind(tenantId,teacherId).first())
    throw new Error('PERSONAL_LEHRKRAFT_NICHT_GEFUNDEN');
  const akteId=id('per_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO personnel_records(id,tenant_id,user_id,teacher_id,name,personalnummer,funktion,eintritt,status,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,'aktiv',?,?,?)`)
    .bind(akteId,tenantId,userId,teacherId,name,clean(eingabe.personalnummer,60)||null,funktion,eintritt,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'personnel.record.created',tenantId,undefined,'personnel_record',akteId,{funktion});
  return{id:akteId,name,funktion,eintritt};
}

export async function personalliste(env:Env,auth:CoreAuthContext,tenantId:string,status?:string){
  requireRole(auth,'tenant_admin');
  const filter=clean(status,20);
  const zeilen=((await env.DB.prepare(`SELECT p.id,p.name,p.funktion,p.eintritt,p.austritt,p.status,p.user_id,p.teacher_id,p.personalnummer,
      (SELECT COUNT(*) FROM personnel_contracts c WHERE c.personnel_id=p.id AND c.status='aktiv') vertraege,
      (SELECT MIN(i.faellig_am) FROM personnel_instructions i WHERE i.personnel_id=p.id) naechste_unterweisung
    FROM personnel_records p WHERE p.tenant_id=? AND (?='' OR p.status=?) ORDER BY p.status,p.name LIMIT 500`)
    .bind(tenantId,filter,filter).all<Record<string,unknown>>()).results)??[];
  return zeilen;
}

// ---------------------------------------------------------------------------------------------
// Vertrag
// ---------------------------------------------------------------------------------------------

/**
 * Einen Vertrag anlegen.
 *
 * Die beiden Pruefungen, die hier sitzen, kann kein Formular ersetzen: die Vorbeschaeftigung
 * steht in der eigenen Datenbank, und die Ueberschneidung sieht nur, wer alle Vertraege der
 * Person nebeneinander legt.
 */
export async function legeVertragAn(env:Env,auth:CoreAuthContext,tenantId:string,personnelId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const akte=await ladeAkte(env,tenantId,personnelId);
  const art=clean(eingabe.art,40);
  if(!(VERTRAGSARTEN as readonly string[]).includes(art))throw new Error('PERSONAL_VERTRAGSART_UNGUELTIG');
  const beginn=datum(eingabe.beginn,'BEGINN');
  const ende=eingabe.ende?datum(eingabe.ende,'ENDE'):null;
  const befristet=!!eingabe.befristet||!!ende;
  if(befristet&&!ende)throw new Error('PERSONAL_BEFRISTUNG_BRAUCHT_ENDE');
  if(ende&&ende<beginn)throw new Error('PERSONAL_ZEITRAUM_UNGUELTIG');
  const sachgrund=clean(eingabe.sachgrund,500)||null;

  // Ueberschneidung zuerst: sie ist der haeufigste Fehler und der konkretere Befund. Ein offenes
  // Ende (ende IS NULL) laeuft weiter und ueberschneidet alles danach - genau das ist der Fall
  // beim vergessenen Beenden des Vorgaengervertrags.
  const kollision=await env.DB.prepare(`SELECT id FROM personnel_contracts
    WHERE tenant_id=? AND personnel_id=? AND status<>'beendet'
      AND beginn<=COALESCE(?,'9999-12-31') AND COALESCE(ende,'9999-12-31')>=?`)
    .bind(tenantId,akte.id,ende,beginn).first<{id:string}>();
  if(kollision)throw new Error('PERSONAL_VERTRAG_UEBERSCHNEIDET');

  // § 14 Abs. 2 TzBfG gilt fuer ARBEITSVERHAELTNISSE. Ein Honorarvertrag ist keines, ein
  // Ehrenamt auch nicht, ein Praktikum im Rahmen einer Ausbildung ebenso wenig - fuer sie gilt
  // die Regel nicht, und sie zaehlen umgekehrt auch nicht als Vorbeschaeftigung.
  const ARBEITSVERHAELTNIS=['festanstellung','teilzeit','minijob'];
  if(befristet&&!sachgrund&&ARBEITSVERHAELTNIS.includes(art)){
    // Sachgrundlos nur bis zwei Jahre UND nur ohne Vorbeschaeftigung bei demselben Arbeitgeber.
    // Beides steht in der eigenen Akte und wird deshalb hier geprueft.
    if(tageZwischen(beginn,ende as string)>731)throw new Error('PERSONAL_BEFRISTUNG_ZU_LANG_OHNE_SACHGRUND');
    const vorher=await env.DB.prepare(`SELECT 1 ok FROM personnel_contracts
      WHERE tenant_id=? AND personnel_id=? AND beginn<? AND art IN ('festanstellung','teilzeit','minijob')`)
      .bind(tenantId,akte.id,beginn).first();
    if(vorher)throw new Error('PERSONAL_VORBESCHAEFTIGUNG_BRAUCHT_SACHGRUND');
  }

  const probezeit=eingabe.probezeit_bis?datum(eingabe.probezeit_bis,'PROBEZEIT'):null;
  // § 622 Abs. 3 BGB: hoechstens sechs Monate. Laenger vereinbart heisst nicht laenger gueltig.
  if(probezeit&&probezeit>monateSpaeter(beginn,6))throw new Error('PERSONAL_PROBEZEIT_ZU_LANG');
  const urlaub=eingabe.urlaubstage_jahr===undefined||eingabe.urlaubstage_jahr===null?null:Number(eingabe.urlaubstage_jahr);
  // Der gesetzliche Mindesturlaub gilt fuer Arbeitsverhaeltnisse; Honorar und Ehrenamt sind
  // keine, dort gibt es keinen Anspruch und deshalb auch keine Untergrenze.
  const mitUrlaubsanspruch=art!=='honorar'&&art!=='ehrenamt';
  if(urlaub!==null&&mitUrlaubsanspruch&&urlaub<MINDESTURLAUB_TAGE)throw new Error('PERSONAL_URLAUB_UNTER_MINDESTANSPRUCH');

  const vertragId=id('pvt_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO personnel_contracts(id,tenant_id,personnel_id,art,beginn,ende,befristet,sachgrund,wochenstunden,deputat_ue,probezeit_bis,verguetung_cent,verguetung_einheit,urlaubstage_jahr,status,bemerkung,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,'aktiv',?,?,?,?)`)
    .bind(vertragId,tenantId,akte.id,art,beginn,ende,befristet?1:0,sachgrund,
      eingabe.wochenstunden===undefined?null:Number(eingabe.wochenstunden),
      eingabe.deputat_ue===undefined?null:Number(eingabe.deputat_ue),probezeit,
      eingabe.verguetung_cent===undefined?null:Math.trunc(Number(eingabe.verguetung_cent)),
      clean(eingabe.verguetung_einheit,10)||null,urlaub,clean(eingabe.bemerkung,1000)||null,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'personnel.contract.created',tenantId,undefined,'personnel_contract',vertragId,{art,befristet});
  return{id:vertragId,art,beginn,ende,befristet};
}

export async function beendeVertrag(env:Env,auth:CoreAuthContext,tenantId:string,vertragId:string,ende:unknown){
  requireRole(auth,'tenant_admin');
  const tag=datum(ende,'ENDE'),ts=nowIso();
  const r=await env.DB.prepare("UPDATE personnel_contracts SET status='beendet',ende=?,updated_at=? WHERE tenant_id=? AND id=? AND status='aktiv'")
    .bind(tag,ts,tenantId,clean(vertragId,120)).run();
  if(!r.meta?.changes)throw new Error('PERSONAL_VERTRAG_NICHT_GEFUNDEN');
  await audit(env.DB,auth.userId,'personnel.contract.ended',tenantId,undefined,'personnel_contract',clean(vertragId,120),{ende:tag});
  return{status:'beendet',ende:tag};
}

// ---------------------------------------------------------------------------------------------
// Urlaub und Abwesenheit
// ---------------------------------------------------------------------------------------------

export async function setzeUrlaubsanspruch(env:Env,auth:CoreAuthContext,tenantId:string,personnelId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const akte=await ladeAkte(env,tenantId,personnelId);
  const jahr=Math.trunc(Number(eingabe.jahr));
  if(!Number.isFinite(jahr)||jahr<2000||jahr>2100)throw new Error('PERSONAL_JAHR_UNGUELTIG');
  const anspruch=Number(eingabe.anspruch_tage);
  if(!Number.isFinite(anspruch)||anspruch<0)throw new Error('PERSONAL_ANSPRUCH_UNGUELTIG');
  const uebertrag=Math.max(0,Number(eingabe.uebertrag_tage??0));
  const ts=nowIso();
  await env.DB.prepare(`INSERT INTO personnel_leave_years(id,tenant_id,personnel_id,jahr,anspruch_tage,uebertrag_tage,uebertrag_verfaellt_am,hinweis_verfall_am,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(tenant_id,personnel_id,jahr) DO UPDATE SET anspruch_tage=excluded.anspruch_tage,uebertrag_tage=excluded.uebertrag_tage,
      uebertrag_verfaellt_am=excluded.uebertrag_verfaellt_am,
      -- Der Hinweis auf den Verfall ist eine Tatsache mit Datum, kein Feld, das man aus Versehen
      -- leert: ein spaeterer Aufruf ohne Hinweis darf den frueheren nicht loeschen.
      hinweis_verfall_am=COALESCE(excluded.hinweis_verfall_am,personnel_leave_years.hinweis_verfall_am),
      updated_at=excluded.updated_at`)
    .bind(id('pul_'),tenantId,akte.id,jahr,anspruch,uebertrag,`${jahr}${UEBERTRAG_ENDE}`,
      eingabe.hinweis_verfall_am?datum(eingabe.hinweis_verfall_am,'HINWEIS'):null,ts,ts).run();
  return{jahr,anspruch_tage:anspruch,uebertrag_tage:uebertrag,uebertrag_verfaellt_am:`${jahr}${UEBERTRAG_ENDE}`};
}

/**
 * Der Urlaubsstand eines Jahres.
 *
 * Genommen wird aus den genehmigten Abwesenheiten gerechnet, nicht gepflegt - eine zweite Zahl,
 * die jemand fortschreiben muesste, waere nach dem ersten Monat falsch.
 */
export async function urlaubsstand(env:Env,auth:CoreAuthContext,tenantId:string,personnelId:string,jahr:number,heute=nowIso().slice(0,10)){
  requireRole(auth,'tenant_admin');
  const akte=await ladeAkte(env,tenantId,personnelId);
  const j=Math.trunc(Number(jahr))||Number(heute.slice(0,4));
  const anspruch=await env.DB.prepare('SELECT anspruch_tage,uebertrag_tage,uebertrag_verfaellt_am,hinweis_verfall_am FROM personnel_leave_years WHERE tenant_id=? AND personnel_id=? AND jahr=?')
    .bind(tenantId,akte.id,j).first<{anspruch_tage:number;uebertrag_tage:number;uebertrag_verfaellt_am:string|null;hinweis_verfall_am:string|null}>();
  const genommen=await env.DB.prepare(`SELECT COALESCE(SUM(tage),0) t FROM personnel_absences
    WHERE tenant_id=? AND personnel_id=? AND art='urlaub' AND status='genehmigt' AND von>=? AND von<=?`)
    .bind(tenantId,akte.id,`${j}-01-01`,`${j}-12-31`).first<{t:number}>();
  const uebertragOffen=Number(anspruch?.uebertrag_tage??0);
  // Der Uebertrag verfaellt am 31.03. - aber nur, wenn der Traeger auf den Verfall hingewiesen
  // hat. Ohne Hinweis bleibt er bestehen; das ist staendige Rechtsprechung und der Punkt, an dem
  // Traeger regelmaessig verlieren.
  const verfallen=!!anspruch?.uebertrag_verfaellt_am&&heute>String(anspruch.uebertrag_verfaellt_am)&&!!anspruch?.hinweis_verfall_am;
  const verfuegbar=Number(anspruch?.anspruch_tage??0)+(verfallen?0:uebertragOffen);
  return{jahr:j,anspruch_tage:Number(anspruch?.anspruch_tage??0),uebertrag_tage:uebertragOffen,
    uebertrag_verfallen:verfallen,hinweis_verfall_am:anspruch?.hinweis_verfall_am??null,
    genommen_tage:Number(genommen?.t??0),rest_tage:Math.round((verfuegbar-Number(genommen?.t??0))*10)/10};
}

/**
 * Eine Abwesenheit erfassen.
 *
 * Krankheit wird gemeldet, nicht beantragt - sie gilt sofort. Urlaub wird beantragt und
 * entschieden. Der Nachweis bei Krankheit wird ab dem vierten Kalendertag verlangt (§ 5 EFZG)
 * und bleibt offen, bis er da ist.
 */
export async function erfasseAbwesenheit(env:Env,auth:CoreAuthContext,tenantId:string,personnelId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const akte=await ladeAkte(env,tenantId,personnelId);
  const art=clean(eingabe.art,30);
  if(!(ABWESENHEITSARTEN as readonly string[]).includes(art))throw new Error('PERSONAL_ABWESENHEITSART_UNGUELTIG');
  const von=datum(eingabe.von,'VON'),bis=datum(eingabe.bis,'BIS');
  if(bis<von)throw new Error('PERSONAL_ZEITRAUM_UNGUELTIG');
  const tage=Number(eingabe.tage??tageZwischen(von,bis));
  if(!Number.isFinite(tage)||tage<=0)throw new Error('PERSONAL_TAGE_UNGUELTIG');

  // Zwei Abwesenheiten zur selben Zeit sind ein Erfassungsfehler - und verdoppeln den Verbrauch.
  const kollision=await env.DB.prepare(`SELECT id FROM personnel_absences
    WHERE tenant_id=? AND personnel_id=? AND status IN ('beantragt','genehmigt') AND von<=? AND bis>=?`)
    .bind(tenantId,akte.id,bis,von).first<{id:string}>();
  if(kollision)throw new Error('PERSONAL_ABWESENHEIT_UEBERSCHNEIDET');

  const krank=art==='krankheit';
  const nachweisNoetig=krank&&tageZwischen(von,bis)>=AU_AB_TAG;
  const status=krank?'genehmigt':'beantragt';
  const abwesenheitId=id('pab_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO personnel_absences(id,tenant_id,personnel_id,art,von,bis,tage,status,grund,nachweis_noetig,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(abwesenheitId,tenantId,akte.id,art,von,bis,tage,status,clean(eingabe.grund,1000)||null,nachweisNoetig?1:0,auth.userId,ts,ts).run();
  return{id:abwesenheitId,art,von,bis,tage,status,nachweis_noetig:nachweisNoetig};
}

export async function entscheideAbwesenheit(env:Env,auth:CoreAuthContext,tenantId:string,abwesenheitId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const ziel=clean(eingabe.status,20);
  if(ziel!=='genehmigt'&&ziel!=='abgelehnt')throw new Error('PERSONAL_ENTSCHEIDUNG_UNGUELTIG');
  const grund=clean(eingabe.ablehnungsgrund,1000)||null;
  if(ziel==='abgelehnt'&&(!grund||grund.length<10))throw new Error('PERSONAL_ABLEHNUNG_BRAUCHT_GRUND');
  const zeile=await env.DB.prepare("SELECT id,personnel_id,art,created_by FROM personnel_absences WHERE tenant_id=? AND id=? AND status='beantragt'")
    .bind(tenantId,clean(abwesenheitId,120)).first<{id:string;personnel_id:string;art:string;created_by:string}>();
  if(!zeile)throw new Error('PERSONAL_ABWESENHEIT_NICHT_GEFUNDEN');
  // Den eigenen Urlaub zu genehmigen ist keine Entscheidung, sondern eine Buchung.
  const eigene=await env.DB.prepare('SELECT 1 ok FROM personnel_records WHERE id=? AND user_id=?').bind(zeile.personnel_id,auth.userId).first();
  if(eigene)throw new Error('PERSONAL_EIGENE_ABWESENHEIT');
  const ts=nowIso();
  await env.DB.prepare('UPDATE personnel_absences SET status=?,entschieden_von=?,entschieden_am=?,ablehnungsgrund=?,updated_at=? WHERE tenant_id=? AND id=?')
    .bind(ziel,auth.userId,ts,grund,ts,tenantId,zeile.id).run();
  await audit(env.DB,auth.userId,'personnel.absence.decided',tenantId,undefined,'personnel_absence',zeile.id,{status:ziel});
  return{status:ziel};
}

export async function belegeNachweis(env:Env,auth:CoreAuthContext,tenantId:string,abwesenheitId:string,am:unknown){
  requireRole(auth,'tenant_admin');
  const tag=datum(am,'NACHWEIS'),ts=nowIso();
  const r=await env.DB.prepare('UPDATE personnel_absences SET nachweis_am=?,updated_at=? WHERE tenant_id=? AND id=? AND nachweis_noetig=1')
    .bind(tag,ts,tenantId,clean(abwesenheitId,120)).run();
  if(!r.meta?.changes)throw new Error('PERSONAL_ABWESENHEIT_NICHT_GEFUNDEN');
  return{nachweis_am:tag};
}

// ---------------------------------------------------------------------------------------------
// Unterweisungen
// ---------------------------------------------------------------------------------------------

export async function erfasseUnterweisung(env:Env,auth:CoreAuthContext,tenantId:string,personnelId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const akte=await ladeAkte(env,tenantId,personnelId);
  const art=clean(eingabe.art,40);
  if(!(UNTERWEISUNGSARTEN as readonly string[]).includes(art))throw new Error('PERSONAL_UNTERWEISUNGSART_UNGUELTIG');
  const durchgefuehrt=datum(eingabe.durchgefuehrt_am,'DURCHGEFUEHRT');
  const hoechstens=HOECHSTINTERVALL_MONATE[art]??12;
  const gewuenscht=Math.trunc(Number(eingabe.intervall_monate??hoechstens));
  if(!Number.isFinite(gewuenscht)||gewuenscht<1)throw new Error('PERSONAL_INTERVALL_UNGUELTIG');
  // Haeufiger als das Gesetz darf ein Traeger immer. Seltener nie - und das faellt hier auf und
  // nicht in der Pruefung.
  if(gewuenscht>hoechstens)throw new Error('PERSONAL_INTERVALL_ZU_LANG');
  const faellig=monateSpaeter(durchgefuehrt,gewuenscht);
  const unterweisungId=id('pun_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO personnel_instructions(id,tenant_id,personnel_id,art,bezeichnung,durchgefuehrt_am,intervall_monate,faellig_am,durchgefuehrt_von,nachweis_datei,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(unterweisungId,tenantId,akte.id,art,clean(eingabe.bezeichnung,200)||art,durchgefuehrt,gewuenscht,faellig,
      clean(eingabe.durchgefuehrt_von,200)||null,clean(eingabe.nachweis_datei,300)||null,auth.userId,ts,ts).run();
  return{id:unterweisungId,art,durchgefuehrt_am:durchgefuehrt,faellig_am:faellig,intervall_monate:gewuenscht};
}

/** Was in den naechsten Wochen faellig wird - oder schon ueberfaellig ist. */
export async function faelligeUnterweisungen(env:Env,auth:CoreAuthContext,tenantId:string,vorlaufTage=60,heute=nowIso().slice(0,10)){
  requireRole(auth,'tenant_admin');
  const grenze=new Date(Date.parse(`${heute}T00:00:00Z`)+Math.max(0,vorlaufTage)*86400000).toISOString().slice(0,10);
  const zeilen=((await env.DB.prepare(`SELECT i.id,i.art,i.bezeichnung,i.faellig_am,i.durchgefuehrt_am,p.id personnel_id,p.name
    FROM personnel_instructions i JOIN personnel_records p ON p.id=i.personnel_id
    WHERE i.tenant_id=? AND p.status='aktiv' AND i.faellig_am<=? ORDER BY i.faellig_am LIMIT 200`)
    .bind(tenantId,grenze).all<Record<string,unknown>>()).results)??[];
  return zeilen.map(z=>({...z,ueberfaellig:String(z.faellig_am)<heute}));
}

// ---------------------------------------------------------------------------------------------
// Austritt
// ---------------------------------------------------------------------------------------------

/**
 * Was beim Austritt noch offen ist - aus dem Bestand, nicht aus einer Vorlage.
 *
 * Eine Vorlage haette immer dieselben Haken. Der Bestand hat die, die wirklich offen sind: das
 * ausgegebene Notebook, der laufende Kurs, der aktive Zugang, die unbezahlte Abrechnung.
 */
export async function austrittsliste(env:Env,auth:CoreAuthContext,tenantId:string,personnelId:string){
  requireRole(auth,'tenant_admin');
  const akte=await ladeAkte(env,tenantId,personnelId);
  const offeneGegenstaende=akte.user_id
    ?((await env.DB.prepare(`SELECT a.id,i.bezeichnung,a.ausgegeben_am FROM inventory_issues a JOIN inventory_items i ON i.id=a.item_id
       WHERE a.tenant_id=? AND a.user_id=? AND a.status='offen' LIMIT 50`).bind(tenantId,akte.user_id).all<Record<string,unknown>>()).results)??[]
    :[];
  const laufendeKurse=akte.teacher_id
    ?((await env.DB.prepare(`SELECT DISTINCT c.id,c.name FROM lessons l JOIN courses c ON c.id=l.course_id
       WHERE l.tenant_id=? AND l.teacher_id=? AND l.starts_at>=? LIMIT 50`)
      .bind(tenantId,akte.teacher_id,nowIso()).all<Record<string,unknown>>()).results)??[]
    :[];
  const zugang=akte.user_id
    ?await env.DB.prepare("SELECT status FROM tenant_users WHERE tenant_id=? AND user_id=?").bind(tenantId,akte.user_id).first<{status:string}>()
    :null;
  const aktiveVertraege=Number((await env.DB.prepare("SELECT COUNT(*) n FROM personnel_contracts WHERE tenant_id=? AND personnel_id=? AND status='aktiv'")
    .bind(tenantId,akte.id).first<{n:number}>())?.n??0);
  const offeneAbwesenheiten=Number((await env.DB.prepare("SELECT COUNT(*) n FROM personnel_absences WHERE tenant_id=? AND personnel_id=? AND status='beantragt'")
    .bind(tenantId,akte.id).first<{n:number}>())?.n??0);
  return{
    person:{id:akte.id,name:akte.name,status:akte.status},
    zugang_aktiv:zugang?.status==='active',
    gegenstaende:offeneGegenstaende,kurse:laufendeKurse,
    aktive_vertraege:aktiveVertraege,offene_abwesenheiten:offeneAbwesenheiten,
    bereit:!(zugang?.status==='active')&&!offeneGegenstaende.length&&!aktiveVertraege&&!offeneAbwesenheiten,
  };
}

/**
 * Den Austritt vollziehen - und dabei den Zugang entziehen.
 *
 * Das ist der Befund dieses ganzen Moduls: es gab keinen Weg, den Zugang einer ausscheidenden
 * Lehrkraft zu entziehen, weil nichts die Lehrkraft mit ihrem Benutzerkonto verband. Der Entzug
 * steht hier deshalb NICHT als Haken in einer Liste, sondern als Schreibvorgang auf
 * tenant_users - zusammen mit dem Beenden der Vertraege, in EINEM Stapel.
 */
export async function vollzieheAustritt(env:Env,auth:CoreAuthContext,tenantId:string,personnelId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const akte=await ladeAkte(env,tenantId,personnelId);
  if(akte.status==='ausgeschieden')throw new Error('PERSONAL_SCHON_AUSGESCHIEDEN');
  const letzterTag=datum(eingabe.letzter_arbeitstag,'LETZTER_ARBEITSTAG');
  if(letzterTag<akte.eintritt)throw new Error('PERSONAL_ZEITRAUM_UNGUELTIG');
  const grund=clean(eingabe.grund,40);
  if(!(AUSTRITTSGRUENDE as readonly string[]).includes(grund))throw new Error('PERSONAL_AUSTRITTSGRUND_UNGUELTIG');
  const ts=nowIso(),offboardingId=id('pof_');

  const anweisungen=[
    env.DB.prepare(`INSERT INTO personnel_offboarding(id,tenant_id,personnel_id,letzter_arbeitstag,grund,status,zugang_entzogen_am,zugang_entzogen_von,bemerkung,created_by,created_at,updated_at)
      VALUES(?,?,?,?,?,'offen',?,?,?,?,?,?)
      ON CONFLICT(tenant_id,personnel_id) DO UPDATE SET letzter_arbeitstag=excluded.letzter_arbeitstag,grund=excluded.grund,
        zugang_entzogen_am=COALESCE(personnel_offboarding.zugang_entzogen_am,excluded.zugang_entzogen_am),updated_at=excluded.updated_at`)
      .bind(offboardingId,tenantId,akte.id,letzterTag,grund,ts,auth.userId,clean(eingabe.bemerkung,1000)||null,auth.userId,ts,ts),
    env.DB.prepare("UPDATE personnel_records SET status='ausgeschieden',austritt=?,austrittsgrund=?,updated_at=? WHERE tenant_id=? AND id=?")
      .bind(letzterTag,grund,ts,tenantId,akte.id),
    env.DB.prepare("UPDATE personnel_contracts SET status='beendet',ende=COALESCE(ende,?),updated_at=? WHERE tenant_id=? AND personnel_id=? AND status='aktiv'")
      .bind(letzterTag,ts,tenantId,akte.id),
    // Offene Antraege einer ausgeschiedenen Person zu genehmigen ergaebe keinen Sinn mehr.
    env.DB.prepare("UPDATE personnel_absences SET status='storniert',updated_at=? WHERE tenant_id=? AND personnel_id=? AND status='beantragt' AND von>?")
      .bind(ts,tenantId,akte.id,letzterTag),
  ];
  if(akte.user_id){
    anweisungen.push(
      env.DB.prepare("UPDATE tenant_users SET status='suspended',updated_at=? WHERE tenant_id=? AND user_id=?").bind(ts,tenantId,akte.user_id),
      // Sitzungen enden sofort. Ein gesperrtes Konto mit noch gueltiger Sitzung ist kein
      // entzogener Zugang, sondern einer mit Verzoegerung.
      env.DB.prepare('DELETE FROM sessions WHERE user_id=?').bind(akte.user_id));
  }
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'personnel.offboarding.done',tenantId,undefined,'personnel_record',akte.id,
    {letzter_arbeitstag:letzterTag,grund,zugang_entzogen:!!akte.user_id});
  return{status:'ausgeschieden',letzter_arbeitstag:letzterTag,zugang_entzogen:!!akte.user_id,
    offene_punkte:await austrittsliste(env,auth,tenantId,akte.id)};
}

export async function schliesseAustrittAb(env:Env,auth:CoreAuthContext,tenantId:string,personnelId:string){
  requireRole(auth,'tenant_admin');
  const akte=await ladeAkte(env,tenantId,personnelId);
  const offen=await austrittsliste(env,auth,tenantId,akte.id);
  if(!offen.bereit)throw new Error('PERSONAL_AUSTRITT_NOCH_OFFEN');
  const ts=nowIso();
  const r=await env.DB.prepare(`UPDATE personnel_offboarding SET status='abgeschlossen',abgeschlossen_am=?,abgeschlossen_von=?,updated_at=?
    WHERE tenant_id=? AND personnel_id=? AND status='offen' AND zugang_entzogen_am IS NOT NULL`)
    .bind(ts,auth.userId,ts,tenantId,akte.id).run();
  if(!r.meta?.changes)throw new Error('PERSONAL_AUSTRITT_NICHT_GEFUNDEN');
  return{status:'abgeschlossen'};
}

// ---------------------------------------------------------------------------------------------
// Die Akte in einem Stueck - und der taegliche Lauf
// ---------------------------------------------------------------------------------------------

export async function personalakte(env:Env,auth:CoreAuthContext,tenantId:string,personnelId:string){
  requireRole(auth,'tenant_admin');
  const akte=await ladeAkte(env,tenantId,personnelId);
  const [vertraege,abwesenheiten,unterweisungen,offboarding]=await Promise.all([
    env.DB.prepare('SELECT * FROM personnel_contracts WHERE tenant_id=? AND personnel_id=? ORDER BY beginn DESC LIMIT 50').bind(tenantId,akte.id).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT * FROM personnel_absences WHERE tenant_id=? AND personnel_id=? ORDER BY von DESC LIMIT 100').bind(tenantId,akte.id).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT * FROM personnel_instructions WHERE tenant_id=? AND personnel_id=? ORDER BY faellig_am LIMIT 50').bind(tenantId,akte.id).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT * FROM personnel_offboarding WHERE tenant_id=? AND personnel_id=?').bind(tenantId,akte.id).first<Record<string,unknown>>(),
  ]);
  const jahr=Number(nowIso().slice(0,4));
  return{person:akte,vertraege:vertraege.results??[],abwesenheiten:abwesenheiten.results??[],
    unterweisungen:unterweisungen.results??[],offboarding:offboarding??null,
    urlaub:await urlaubsstand(env,auth,tenantId,akte.id,jahr)};
}

/**
 * Der taegliche Lauf: faellige Unterweisungen, auslaufende Befristungen, fehlende Nachweise.
 *
 * Alles drei sind Fristen, die niemand im Kopf hat und die erst auffallen, wenn es zu spaet ist -
 * die Unterweisung in der Pruefung, die Befristung am Tag nach ihrem Ablauf (dann gilt das
 * Arbeitsverhaeltnis nach § 15 Abs. 6 TzBfG als unbefristet fortgesetzt), der fehlende
 * Krankheitsnachweis bei der Lohnabrechnung.
 */
export async function erinnereAnPersonalfristen(env:Env,grenze=30,heute=nowIso().slice(0,10)){
  const in30=new Date(Date.parse(`${heute}T00:00:00Z`)+30*86400000).toISOString().slice(0,10);
  const ts=nowIso();
  const faellig=((await env.DB.prepare(`SELECT i.id,i.tenant_id,i.art,i.faellig_am,p.name FROM personnel_instructions i
    JOIN personnel_records p ON p.id=i.personnel_id
    WHERE p.status='aktiv' AND i.faellig_am<=? AND (i.erinnert_am IS NULL OR i.erinnert_am<i.durchgefuehrt_am)
    ORDER BY i.faellig_am LIMIT ?`).bind(in30,Math.max(1,Math.min(100,grenze)))
    .all<{id:string;tenant_id:string;art:string;faellig_am:string;name:string}>()).results)??[];
  for(const f of faellig){
    await env.DB.batch([
      env.DB.prepare('INSERT INTO automation_events(id,tenant_id,event_type,source_type,source_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)')
        .bind(id('aev_'),f.tenant_id,'personnel.instruction.due','personnel_instruction',f.id,
          JSON.stringify({art:f.art,faellig_am:f.faellig_am,name:f.name}),ts),
      env.DB.prepare('UPDATE personnel_instructions SET erinnert_am=? WHERE id=?').bind(ts,f.id),
    ]);
  }
  const auslaufend=((await env.DB.prepare(`SELECT c.id,c.tenant_id,c.ende,p.name FROM personnel_contracts c
    JOIN personnel_records p ON p.id=c.personnel_id
    WHERE c.status='aktiv' AND c.ende IS NOT NULL AND c.ende<=? AND p.status='aktiv' LIMIT ?`)
    .bind(in30,Math.max(1,Math.min(100,grenze))).all<{id:string;tenant_id:string;ende:string;name:string}>()).results)??[];
  for(const a of auslaufend)
    await env.DB.prepare('INSERT INTO automation_events(id,tenant_id,event_type,source_type,source_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)')
      .bind(id('aev_'),a.tenant_id,'personnel.contract.expiring','personnel_contract',a.id,
        JSON.stringify({ende:a.ende,name:a.name}),ts).run();
  return{unterweisungen:faellig.length,befristungen:auslaufend.length};
}

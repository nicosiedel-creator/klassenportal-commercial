import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { ketteAnhaengen } from './immutable-audit.js';
import { requirePlatform, requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Supportzugriff: befristet, zweckgebunden, nachweisbar - und ohne Freigabe geschlossen.
//
// Bisher war "Support sieht nur zu" ein Zustand der OBERFLAECHE: ein Plattform-Admin, der den
// Kundenbereich aufrief, bekam ein Kennzeichen gesetzt, das Knoepfe ausgraut. Die Schnittstelle
// darunter lieferte ihm weiterhin alles - ohne Freigabe des Traegers, ohne Frist, ohne Protokoll.
// Wer die Oberflaeche umgeht, umgeht damit den ganzen Schutz.
//
// Hier liegt der Schutz jetzt: nicht in der Anzeige, sondern vor den Daten.
//
//  - Erteilt wird die Freigabe vom Mandanten-Admin, nicht vom Support. Ein Supportkonto, das sich
//    selbst freigibt, waere genau der Zustand, den das hier beendet.
//  - Sie laeuft ab. Keine Freigabe gilt laenger als drei Tage.
//  - Sie ist lesend. Ein Schreibversuch unter Supportfreigabe wird abgewiesen und protokolliert.
//  - Ohne Freigabe faellt der Zugriff ZU - auch fuer Plattform-Admins. Der Versuch wird
//    protokolliert; genau dieser Eintrag ist der wichtigere.
//  - Die eine Ausnahme ist der Notfallzugriff. Er ist kurz, begruendungspflichtig, wird der Leitung
//    des Mandanten gemeldet und traegt sein eigenes Kennzeichen im Protokoll.

export const HOECHSTDAUER_STUNDEN=72;
export const NOTFALL_MINUTEN=60;
const LESEND=['GET','HEAD'];
const clean=(v:unknown,n=500)=>safeString(v,n);

export type Freigabe={id:string;support_user_id:string;gueltig_bis:string;notfall:number;zweck:string};

async function protokolliere(env:Env,tenantId:string,supportUserId:string,grantId:string|null,art:'zugriff'|'verweigert'|'notfall',methode:string,pfad:string,grund:string|null):Promise<void>{
  const ts=nowIso(),eid=id('sae_');
  const zeile=env.DB.prepare('INSERT INTO support_access_events(id,tenant_id,support_user_id,grant_id,art,methode,pfad,grund,erfasst_am) VALUES(?,?,?,?,?,?,?,?,?)')
    .bind(eid,tenantId,supportUserId,grantId,art,methode,pfad,grund,ts);
  // Der Nachweis haengt an der Kette: ein Zugriffsprotokoll, das sich nachtraeglich aendern laesst,
  // beweist nichts.
  await ketteAnhaengen(env.DB,{tenant_id:tenantId,quelle:'support_access',quelle_id:eid,akteur:supportUserId,
    aktion:`support.${art}`,objekt_typ:'support_access_grant',objekt_id:grantId,inhalt:{methode,pfad,grund}},[zeile]);
}

/** Die heute gueltige Freigabe dieses Supportkontos - oder nichts. Abgelaufen zaehlt als nichts. */
export async function aktiveFreigabe(env:Env,tenantId:string,supportUserId:string,jetzt=nowIso()):Promise<Freigabe|null>{
  return await env.DB.prepare("SELECT id,support_user_id,gueltig_bis,notfall,zweck FROM support_access_grants WHERE tenant_id=? AND support_user_id=? AND status='aktiv' AND gueltig_ab<=? AND gueltig_bis>? ORDER BY gueltig_bis DESC LIMIT 1")
    .bind(tenantId,supportUserId,jetzt,jetzt).first<Freigabe>()??null;
}

/**
 * Das Tor vor den Mandantendaten.
 *
 * Greift nur fuer Plattform-Konten OHNE eigene Mitgliedschaft in diesem Mandanten - wer dort selbst
 * Mitglied ist, handelt als Mensch des Traegers und nicht als Support.
 */
export async function pruefeSupportzugang(env:Env,auth:CoreAuthContext,tenantId:string,methode:string,pfad:string,jetzt=nowIso()):Promise<void>{
  if(!auth.isPlatformAdmin||!tenantId)return;
  const eigen=await env.DB.prepare('SELECT 1 AS ok FROM memberships WHERE tenant_id=? AND user_id=? LIMIT 1').bind(tenantId,auth.userId).first();
  if(eigen)return;
  const freigabe=await aktiveFreigabe(env,tenantId,auth.userId,jetzt);
  if(!freigabe){await protokolliere(env,tenantId,auth.userId,null,'verweigert',methode,pfad,'keine_freigabe');throw new Error('SUPPORT_ACCESS_NOT_GRANTED');}
  if(!LESEND.includes(String(methode).toUpperCase())){await protokolliere(env,tenantId,auth.userId,freigabe.id,'verweigert',methode,pfad,'nur_lesen');throw new Error('SUPPORT_ACCESS_READ_ONLY');}
  await protokolliere(env,tenantId,auth.userId,freigabe.id,Number(freigabe.notfall)===1?'notfall':'zugriff',methode,pfad,null);
}

export async function erteileSupportzugang(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const support=clean(input.support_user_id,120),zweck=clean(input.zweck,500);
  const stunden=Math.trunc(Number(input.stunden??24));
  if(!support)throw new Error('SUPPORT_ACCOUNT_REQUIRED');
  if(zweck.length<10)throw new Error('SUPPORT_PURPOSE_REQUIRED');
  if(!Number.isFinite(stunden)||stunden<1||stunden>HOECHSTDAUER_STUNDEN)throw new Error('SUPPORT_DURATION_INVALID');
  if(support===auth.userId)throw new Error('SUPPORT_SELF_GRANT_FORBIDDEN');
  const konto=await env.DB.prepare("SELECT is_platform_admin FROM users WHERE id=? AND status='active'").bind(support).first<{is_platform_admin:number}>();
  if(!konto||Number(konto.is_platform_admin)!==1)throw new Error('SUPPORT_ACCOUNT_NOT_FOUND');
  const jetzt=new Date(),ab=jetzt.toISOString(),bis=new Date(jetzt.getTime()+stunden*36e5).toISOString(),gid=id('sag_');
  await env.DB.prepare("INSERT INTO support_access_grants(id,tenant_id,support_user_id,erteilt_von,zweck,umfang,gueltig_ab,gueltig_bis,status,notfall,created_at,updated_at) VALUES(?,?,?,?,?,'lesen',?,?,'aktiv',0,?,?)")
    .bind(gid,tenantId,support,auth.userId,zweck,ab,bis,ab,ab).run();
  await audit(env.DB,auth.userId,'support_access.granted',tenantId,undefined,'support_access_grant',gid,{stunden,zweck});
  return{id:gid,gueltig_bis:bis};
}

export async function widerrufeSupportzugang(env:Env,auth:CoreAuthContext,tenantId:string,grantId:string,grund:unknown){
  requireRole(auth,'tenant_admin');
  const text=clean(grund,500),ts=nowIso();
  const r=await env.DB.prepare("UPDATE support_access_grants SET status='widerrufen',widerrufen_von=?,widerrufen_am=?,widerrufsgrund=?,updated_at=? WHERE id=? AND tenant_id=? AND status='aktiv'")
    .bind(auth.userId,ts,text||null,ts,grantId,tenantId).run();
  if(!r.meta?.changes)throw new Error('SUPPORT_GRANT_NOT_FOUND');
  await audit(env.DB,auth.userId,'support_access.revoked',tenantId,undefined,'support_access_grant',grantId);
  return{widerrufen:true};
}

/**
 * Der Notfallzugriff - die eine belegte Ausnahme.
 *
 * Kurz, begruendet, protokolliert und gemeldet. Er ist bewusst unbequem: wer ihn zieht, hinterlaesst
 * einen Eintrag, den die Leitung des Mandanten sieht, bevor sie danach fragen muss.
 */
export async function notfallzugang(env:Env,auth:CoreAuthContext,tenantId:string,begruendung:unknown){
  requirePlatform(auth);
  const text=clean(begruendung,500);
  if(text.length<20)throw new Error('SUPPORT_EMERGENCY_REASON_REQUIRED');
  const mandant=await env.DB.prepare('SELECT id FROM tenants WHERE id=?').bind(tenantId).first();
  if(!mandant)throw new Error('TENANT_NOT_FOUND');
  const jetzt=new Date(),ab=jetzt.toISOString(),bis=new Date(jetzt.getTime()+NOTFALL_MINUTEN*60000).toISOString(),gid=id('sag_');
  const leitung=(await env.DB.prepare("SELECT DISTINCT user_id FROM memberships WHERE tenant_id=? AND role='tenant_admin' LIMIT 50").bind(tenantId).all<{user_id:string}>()).results??[];
  const anweisungen=[env.DB.prepare("INSERT INTO support_access_grants(id,tenant_id,support_user_id,erteilt_von,zweck,umfang,gueltig_ab,gueltig_bis,status,notfall,begruendung,created_at,updated_at) VALUES(?,?,?,?,?,'lesen',?,?,'aktiv',1,?,?,?)")
    .bind(gid,tenantId,auth.userId,auth.userId,'Notfallzugriff',ab,bis,text,ab,ab)];
  for(const l of leitung)anweisungen.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'support_emergency_access',?,?,?)")
    .bind(id('ntf_'),tenantId,l.user_id,'Notfallzugriff des Supports',`Ein Supportkonto hat einen befristeten Notfallzugriff (${NOTFALL_MINUTEN} Minuten, nur lesend) auf Ihre Daten genommen. Begründung: ${text}`,ab));
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'support_access.emergency',tenantId,undefined,'support_access_grant',gid,{minuten:NOTFALL_MINUTEN,gemeldet_an:leitung.length});
  return{id:gid,gueltig_bis:bis,gemeldet_an:leitung.length};
}

export async function listeSupportzugaenge(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return (await env.DB.prepare('SELECT g.id,g.support_user_id,s.display_name AS support_name,g.erteilt_von,g.zweck,g.gueltig_ab,g.gueltig_bis,g.status,g.notfall,g.begruendung FROM support_access_grants g JOIN users s ON s.id=g.support_user_id WHERE g.tenant_id=? ORDER BY g.created_at DESC LIMIT 100')
    .bind(tenantId).all()).results??[];
}

export async function supportProtokoll(env:Env,auth:CoreAuthContext,tenantId:string,limit=100){
  requireRole(auth,'tenant_admin');
  const n=Math.min(Math.max(Number(limit)||100,1),500);
  return (await env.DB.prepare('SELECT id,support_user_id,grant_id,art,methode,pfad,grund,erfasst_am FROM support_access_events WHERE tenant_id=? ORDER BY erfasst_am DESC LIMIT ?')
    .bind(tenantId,n).all()).results??[];
}

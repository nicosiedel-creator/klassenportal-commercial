import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { nowIso, sha256Text } from './utils.js';
import { istGeheim } from '../portability/secret-columns.js';

// Konfigurationssicherung (Master-Spec V2, MUSS-V1 "Konfigurationssicherung").
//
// Die Daten eines Mandanten waren exportierbar, seine KONFIGURATION nicht. Nach einer
// Wiederherstellung stuenden also alle Teilnehmer, Noten und Anwesenheiten wieder da - aber
// Branding, Modulfreischaltungen, Fristen, Integrationen und Vorlagen waeren weg, und niemand
// wuesste, wie sie eingestellt waren. Ein Wiederanlauf, der das Haus wieder aufbaut und die
// Schluessel verliert, ist keiner.
//
// Zwei Regeln, die dieses Modul traegt:
//  - GEHEIMNISSE GEHEN NICHT MIT. Ein Zugangstoken in einer Konfigurationsdatei waere ein
//    Geheimnis in einer Datei, die herumgereicht wird. Stattdessen wird VERMERKT, dass es
//    hinterlegt war - damit beim Wiederanlauf auffaellt, was noch fehlt.
//  - DIE LISTE IST FAIL-CLOSED. Eine neue Konfigurationstabelle, die hier niemand eintraegt,
//    faellt auf, statt still aus der Sicherung zu verschwinden.

/** Was zur Konfiguration eines Mandanten gehoert - und warum. */
export const KONFIGURATIONSTABELLEN:Record<string,string>={
  tenant_settings:'Portalname, Farben, Logo, Sprache, Zeitzone, Einspruchs- und Kompetenzschwellen.',
  course_scheduling_rules:'Planungsgrenzen je Kurs: fruehester Beginn, Hoechstdauer, Pausen.',
  teaching_rhythm_rules:'Unterrichtsrhythmen je Kurs: Block, Doppelstunde, Schicht, Praxisphase.',
  teacher_workload_rules:'Belastungsgrenzen je Lehrkraft.',
  workflow_rules:'Automatische Folgeaufgaben und Benachrichtigungen.',
  participant_billing_settings:'Vorgaben fuer Teilnehmerforderungen.',
  tenant_intake_settings:'Regeln des Bewerbereingangs.',
  kursnet_export_settings:'Vorgaben fuer den KURSNET-Export.',
  discussion_settings:'Regeln des Kursforums.',
  tenant_sso_configs:'Anmeldung ueber das Verzeichnis des Traegers.',
  integrations:'Angebundene Fremdsysteme.',
  certificate_templates:'Zeugnis- und Bescheinigungsvorlagen.',
  document_templates:'Dokumentvorlagen.',
  course_templates:'Kursvorlagen.',
  grading_scales:'Notenskalen.',
  custom_domain_requests:'Eigene Domain des Traegers.',
};

// Tabellen, die zwar nach Konfiguration klingen, aber keine sind - mit Begruendung, damit die
// Pruefung unten nicht zur Formsache wird.
/**
 * Exportiert ja, wiederhergestellt nein.
 *
 * Diese Tabellen sagen, WAS DER TRAEGER GEBUCHT HAT. Sie stehen in der Sicherung, damit beim
 * Wiederanlauf nachvollziehbar ist, welcher Umfang galt - aber sie werden nicht zurueckgeschrieben.
 * Sonst waere die Wiederherstellung einer alten Konfiguration der kuerzeste Weg, ein gekuendigtes
 * Modul wieder freizuschalten: die Leitung eines Mandanten wuerde sich ueber eine Datei selbst
 * Rechte erteilen, die die Plattform vergeben hat.
 *
 * Gefunden hat das die Pruefung unerfassteKonfiguration() - genau dafuer ist sie da.
 */
export const NUR_EXPORT:Record<string,string>={
  feature_flags:'Welche Module dieser Mandant sehen darf - von der Plattform gesetzt.',
  tenant_module_entitlements:'Gebuchte Module.',
  tenant_entitlements:'Tarif, Kurslimit und Preise dieses Mandanten.',
  // Zweiter Grund fuer dieselbe Behandlung, und der haertere: eine Wiederherstellung LOESCHT die
  // heutigen Zeilen der Tabelle, bevor sie die alten einspielt. Bei den Richtlinien haengen an
  // diesen Zeilen die Bestaetigungen - ueber ON DELETE CASCADE. Ein Restore der Konfiguration
  // von vorgestern loeschte damit den Nachweis, wer welche Fassung wann anerkannt hat, und das
  // waere kein Wiederanlauf, sondern Beweisvernichtung. Der Wortlaut steht deshalb in der
  // Sicherung - zum Nachlesen, welche Ordnung galt -, wird aber nie zurueckgeschrieben.
  policy_definitions:'Wortlaut und Fassung der Richtlinien. Steht in der Sicherung, wird aber nie zurückgeschrieben: daran hängen die Bestätigungen.',
};

/**
 * Kindtabellen: sie haengen an einer Konfigurationstabelle und tragen selbst keine Mandantenkennung.
 * Sie werden ueber ihre Elterntabelle mitgesichert und mitgeloescht.
 */
export const KINDTABELLEN:Record<string,{spalte:string;eltern:string}>={
  grading_scale_items:{spalte:'scale_id',eltern:'grading_scales'},
};

/**
 * Plattformweite Einstellungen. Sie gehoeren NICHT in die Sicherung eines Mandanten - sie gelten
 * fuer alle. Waeren sie darin, koennte die Leitung eines Mandanten ueber eine wiederhergestellte
 * Datei die Einstellungen aller uebrigen aendern.
 */
export const PLATTFORMWEIT:Record<string,string>={
  commerce_policy:'Kaufmaennische Vorgaben der Plattform, nicht eines Mandanten.',
  accounting_settings:'Kontenrahmen der Plattform.',
  legal_configuration:'Impressum und Kontaktangaben des Betreibers.',
  module_commerce_rules:'Preisliste der Module, plattformweit.',
};

export const KEINE_KONFIGURATION:Record<string,string>={
  // Eine Bestaetigung ist ein Nachweis, kein Einstellwert. Sie gehoert in die Datensicherung des
  // Mandanten und in die Auskunft der betroffenen Person - aber nicht in eine Datei, die jemand
  // spaeter zurueckschreiben kann: wer Nachweise wiederherstellen kann, kann sie auch faelschen.
  policy_acknowledgements:'Nachweis, wer welche Fassung wann bestätigt hat - kein Einstellwert und nie wiederherstellbar.',
  idempotency_keys:'Wiedererkennung wiederholter Schreibversuche mit Ablaufzeit, kein Einstellwert.',
  // Ein Zustellnachweis ist ein Nachweis, kein Einstellwert. Wer ihn zurueckschreiben kann, kann
  // ihn faelschen: eine unterdrueckte Benachrichtigung liesse sich nachtraeglich in eine
  // zugestellte verwandeln - genau die Frage, um die es geht, wenn jemand sagt, er habe nichts
  // erhalten. Steht in der Datensicherung des Mandanten und in der Auskunft der Person, aber nie
  // in einer Datei, die spaeter jemand einspielt.
  communication_channel_decisions:'Nachweis, was über welchen Weg nicht zugestellt wurde und warum - kein Einstellwert und nie wiederherstellbar.',
  // Die Benachrichtigungseinstellung gehoert der PERSON, nicht dem Traeger. Ein Restore der
  // Traegerkonfiguration von vorgestern wuerde eine inzwischen geaenderte Ruhezeit oder
  // Themenabwahl stillschweigend zuruecksetzen - eine Entscheidung ueber Menschen, die niemand
  // getroffen hat.
  notification_preferences:'Benachrichtigungseinstellung einer Person, keine Trägerkonfiguration.',
  notification_topic_preferences:'Themenabwahl einer Person, keine Trägerkonfiguration.',
  integration_exports:'Laufende Uebertragungen, kein Einstellwert.',
  integration_outbox:'Warteschlange, kein Einstellwert.',
  integration_rate_limits:'Zaehlerstand, kein Einstellwert.',
  module_cancellations:'Vorgang, kein Einstellwert.',
  module_subscription_changes:'Vorgang, kein Einstellwert.',
  timetable_plan_restores:'Vorgang, kein Einstellwert.',
  timetable_plan_scores:'Bewertung eines Planentwurfs, wird neu berechnet.',
  curriculum_framework_versions:'Fassung eines Rahmenlehrplans - Nachweis, kein Einstellwert. Zurueckschreiben wuerde eine veroeffentlichte Fassung veraendern.',
  framework_version_entries:'Momentaufnahme einer Rahmenfassung.',
  prior_learning_claims:'Antrag und Bescheid, kein Einstellwert.',
  exam_sittings:'Ein konkreter Pruefungstermin in einem Raum, kein Einstellwert.',
  exam_sitting_seats:'Platzliste eines Pruefungstermins.',
  exam_supervisions:'Aufsichtszuteilung eines Pruefungstermins.',
  enrollment_transitions:'Ein Laufbahnvorgang einer Person, kein Einstellwert.',
  learning_plans:'Lernplan einer Person.',
  learning_plan_steps:'Schritte eines Lernplans.',
  helpdesk_tickets:'Eine Meldung, kein Einstellwert.',
  helpdesk_ticket_events:'Verlauf einer Meldung.',
  knowledge_articles:'Hilfeartikel des Traegers - Inhalt, kein Einstellwert.',
  knowledge_article_versions:'Fassungen eines Hilfeartikels.',
  knowledge_search_terms:'Suchindex der Wissensbasis, aus den Artikeln ableitbar.',
  onboarding_wizard_state:'Stand der Einrichtung dieses Mandanten.',
  excursions:'Eine geplante Veranstaltung, kein Einstellwert.',
  excursion_participants:'Teilnehmerliste einer Veranstaltung.',
  ai_models:'Zugelassene KI-Modelle dieses Mandanten - Einstellwert, gehoert in die Sicherung.',
  ai_invocations:'Protokoll einzelner KI-Aufrufe, kein Einstellwert.',
  ai_generated_content:'Herkunftsvermerk zu einem erzeugten Text.',
  ai_evaluation_cases:'Pruefsatz fuer KI-Modelle - Einstellwert.',
  ai_evaluation_runs:'Ergebnis eines Pruefsatzlaufs, kein Einstellwert.',
  media_assets:'Ein Medium der Bibliothek samt Lizenz, kein Einstellwert.',
  media_usages:'Wo ein Medium eingebunden ist.',
  media_tracks:'Untertitel und Transkripte zu einem Medium.',
  operations_duties:'Kritische Betriebsaufgaben dieses Mandanten - Einstellwert.',
  operations_duty_holders:'Wer eine Betriebsaufgabe wahrnimmt.',
  operations_incidents:'Eine Betriebsstoerung, kein Einstellwert.',
  operations_incident_updates:'Verlauf einer Betriebsstoerung.',
  event_subscriptions:'Welche Verarbeiter auf welche Ereignisse hoeren - Einstellwert.',
  communication_templates:'Anschreiben-Vorlage des Traegers - Einstellwert, gehoert in die Sicherung.',
  ai_content_drafts:'KI-Entwuerfe fuer Aufgaben, kein Einstellwert.',
  residency_policies:'Zugesagte Datenregion des Traegers - Einstellwert.',
  residency_exceptions:'Begruendete Ausnahme von der Datenresidenz - Einstellwert.',
  alumni_records:'Abschluss einer Person, kein Einstellwert.',
  command_interpretations:'Gedeutete Eingaben der Befehlszeile, kein Einstellwert.',
  communication_template_versions:'Veroeffentlichte Fassungen einer Vorlage.',
  domain_events:'Ein aufgetretenes Ereignis, kein Einstellwert.',
  event_deliveries:'Zustellstand eines Ereignisses.',
  prior_learning_credits:'Anerkannte Vorleistungen eines Antrags.',
  document_versions:'Historie eines Dokuments. Ein Zurueckschreiben waere eine gefaelschte Akte.',
  document_search_terms:'Suchindex, wird aus den Dokumenten neu aufgebaut.',
  automation_failures:'Fehlerlage des Betriebs, kein Einstellwert. Zurueckschreiben wuerde erledigte Fehler wieder aufmachen und liegengebliebene verschwinden lassen.',
  workflow_simulations:'Ergebnis eines Probelaufs, kein Einstellwert.',
  operation_journal:'Laufender oder gescheiterter Vorgang. Zurueckschreiben wuerde einen Wiederanlauf auf einen falschen Stand setzen.',
  operation_journal_steps:'Schritte eines Vorgangs.',
  exam_custody_events:'Beweiskette einer Pruefung. Ein Zurueckschreiben waere eine Faelschung des Verfahrensnachweises.',
  exam_interruptions:'Vorgang waehrend einer Pruefung, kein Einstellwert.',
  exam_integrity_cases:'Taeuschungsverfahren, kein Einstellwert.',
  privacy_incidents:'Vorfallakte und Nachweis gegenueber der Aufsicht, kein Einstellwert.',
  privacy_incident_notes:'Verlauf einer Vorfallakte; nur anzuhaengen, nie zurueckzuschreiben.',
  crisis_alerts:'Vorgang, kein Einstellwert.',
  crisis_alert_recipients:'Zustellnachweis einer Krisenmeldung; ein Zurueckschreiben wuerde Bestaetigungen faelschen.',
  emergency_contacts:'Notfallnummern der Personen - Personendaten, keine Einstellung.',
  complaints:'Vorgang, kein Einstellwert.',
  complaint_notes:'Verlauf eines Beschwerdevorgangs.',
  safeguarding_reports:'Kinderschutzfall, kein Einstellwert.',
  safeguarding_notes:'Verlauf eines Kinderschutzfalls; nur anzuhaengen, nie zurueckzuschreiben.',
  safeguarding_officers:'Benennung von Kinderschutzfachkraeften. Ein Zurueckschreiben wuerde eine entzogene Benennung wieder scharf stellen - mit Einsicht in laufende Faelle.',
  access_restrictions:'Gerichtliche oder behoerdliche Sperre. Ein Zurueckschreiben wuerde eine aufgehobene Sperre wieder scharf stellen oder eine geltende entfernen - beides mit unmittelbarer Wirkung auf Menschen.',
  restore_runs:'Vorgang und Nachweis, kein Einstellwert. Ein zurueckgeschriebener alter Lauf wuerde die Nachweislage faelschen.',
  restore_drill_policy:'Nachweis der letzten Wiederanlaufprobe. Zuruecksetzen wuerde eine bestandene Probe vortaeuschen oder eine gescheiterte verschwinden lassen.',
  stripe_module_prices:'Preise der Plattform, nicht Konfiguration eines Mandanten.',
};

const MANDANTENSPALTE='tenant_id';

async function spalten(env:Env,tabelle:string):Promise<string[]>{
  const r=await env.DB.prepare('SELECT name FROM pragma_table_info(?)').bind(tabelle).all<{name:string}>();
  return (r.results??[]).map(x=>x.name);
}

/**
 * Konfigurationstabellen, die es im Schema wirklich gibt - und solche, die hier fehlen.
 *
 * Fail-closed: wer eine neue Einstellungstabelle anlegt und sie hier nicht eintraegt, bekommt einen
 * roten Test statt einer Sicherung, in der seine Einstellung fehlt.
 */
export async function unerfassteKonfiguration(env:Env):Promise<string[]>{
  const r=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table'").all<{name:string}>();
  const offen:string[]=[];
  for(const t of (r.results??[]).map(x=>x.name)){
    if(KONFIGURATIONSTABELLEN[t]||NUR_EXPORT[t]||KINDTABELLEN[t]||PLATTFORMWEIT[t]||KEINE_KONFIGURATION[t])continue;
    if(!/(^|_)(settings|config|configuration|templates|flags|entitlements|policy|rules)$/.test(t))continue;
    if(!(await spalten(env,t)).includes(MANDANTENSPALTE))continue;
    offen.push(t);
  }
  return offen.sort();
}

export type Konfigurationssicherung={
  schema:number;tenant_id:string;erzeugt_am:string;
  tabellen:Record<string,Record<string,unknown>[]>;
  ausgelassene_geheimnisse:{tabelle:string;spalte:string;zeilen:number}[];
  pruefsumme:string;
};

/**
 * Die Konfiguration eines Mandanten als eigenstaendiges Bundel.
 *
 * Geheime Spalten werden NICHT mitgenommen - aber ihr Vorhandensein wird vermerkt. Beim
 * Wiederanlauf steht dann da: "hier war ein Token hinterlegt", statt dass die Anbindung
 * kommentarlos tot ist und niemand weiss warum.
 */
export async function exportConfiguration(env:Env,auth:CoreAuthContext,tenantId:string):Promise<Konfigurationssicherung>{
  requireRole(auth,'tenant_admin');
  const vorhandene=new Set(((await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table'").all<{name:string}>()).results??[]).map(x=>x.name));
  const tabellen:Record<string,Record<string,unknown>[]>={};
  const ausgelassen:{tabelle:string;spalte:string;zeilen:number}[]=[];
  for(const name of [...Object.keys(KONFIGURATIONSTABELLEN),...Object.keys(KINDTABELLEN),...Object.keys(NUR_EXPORT)].sort()){
    if(!vorhandene.has(name))continue;
    const alle=await spalten(env,name);
    const geheim=alle.filter(istGeheim);
    const sichtbar=alle.filter(s=>!istGeheim(s));
    if(!sichtbar.length)continue;
    const kind=KINDTABELLEN[name];
    // Ohne Mandantenkennung und ohne erklaerte Elternschaft wuerde die Abfrage die Zeilen ALLER
    // Mandanten holen. Das waere kein Konfigurationsexport, sondern ein Datenleck.
    if(!alle.includes(MANDANTENSPALTE)&&!kind)throw new Error(`CONFIG_EXPORT_NICHT_MANDANTENGEBUNDEN: ${name}`);
    const sql=kind
      ?`SELECT ${sichtbar.map(s=>`"${s}"`).join(',')} FROM ${name} WHERE ${kind.spalte} IN (SELECT id FROM ${kind.eltern} WHERE ${MANDANTENSPALTE}=?)`
      :`SELECT ${sichtbar.map(s=>`"${s}"`).join(',')} FROM ${name} WHERE ${MANDANTENSPALTE}=?`;
    const zeilen=((await env.DB.prepare(sql).bind(tenantId).all<Record<string,unknown>>()).results)??[];
    tabellen[name]=zeilen;
    for(const s of geheim)if(zeilen.length)ausgelassen.push({tabelle:name,spalte:s,zeilen:zeilen.length});
  }
  const rumpf={schema:1,tenant_id:tenantId,erzeugt_am:nowIso(),tabellen,ausgelassene_geheimnisse:ausgelassen};
  // Die Pruefsumme deckt den INHALT, nicht den Zeitpunkt: zwei Sicherungen derselben Konfiguration
  // sind daran als gleich erkennbar.
  const pruefsumme=await sha256Text(JSON.stringify({tenant_id:tenantId,tabellen,ausgelassene_geheimnisse:ausgelassen}));
  await audit(env.DB,auth.userId,'configuration.exported',tenantId,undefined,'tenant',tenantId,{tabellen:Object.keys(tabellen).length});
  return{...rumpf,pruefsumme};
}

export type Wiederherstellungsplan={
  tabelle:string;vorhanden:number;in_sicherung:number;wird_ersetzt:boolean;nur_zur_ansicht?:string;
  unbekannte_spalten:string[];fehlende_spalten:string[];
}[];

/**
 * Was eine Wiederherstellung tun WUERDE - vor dem Anfassen.
 *
 * Die Spec verlangt die Simulation ausdruecklich ("Wiederherstellungsumfang anzeigen, Simulation
 * durchfuehren"). Ohne sie ist ein Restore ein Sprung ins Dunkle: man sieht erst hinterher, was
 * ueberschrieben wurde.
 */
export async function planRestore(env:Env,auth:CoreAuthContext,tenantId:string,sicherung:Konfigurationssicherung):Promise<{plan:Wiederherstellungsplan;fehler:string[];geheimnisse:string[]}>{
  requireRole(auth,'tenant_admin');
  const fehler:string[]=[];
  if(Number(sicherung?.schema)!==1)fehler.push('Unbekanntes Format der Sicherung.');
  // Eine Sicherung eines FREMDEN Mandanten wird nicht eingespielt. Das waere der kuerzeste Weg,
  // die Mandantentrennung von innen aufzuheben.
  if(sicherung?.tenant_id!==tenantId)fehler.push('Diese Sicherung gehört zu einem anderen Kundenbereich.');
  const plan:Wiederherstellungsplan=[];
  for(const [name,zeilen] of Object.entries(sicherung?.tabellen??{})){
    if(!KONFIGURATIONSTABELLEN[name]&&!NUR_EXPORT[name]&&!KINDTABELLEN[name]){fehler.push(`Unbekannte Tabelle in der Sicherung: ${name}`);continue;}
    const alle=await spalten(env,name);
    if(!alle.length){fehler.push(`Tabelle fehlt im heutigen Schema: ${name}`);continue;}
    const inSicherung=new Set(zeilen.flatMap(z=>Object.keys(z)));
    const kind=KINDTABELLEN[name];
    const vorhanden=Number((await env.DB.prepare(kind
      ?`SELECT COUNT(*) n FROM ${name} WHERE ${kind.spalte} IN (SELECT id FROM ${kind.eltern} WHERE ${MANDANTENSPALTE}=?)`
      :`SELECT COUNT(*) n FROM ${name} WHERE ${MANDANTENSPALTE}=?`).bind(tenantId).first<{n:number}>())?.n||0);
    plan.push({
      tabelle:name,vorhanden,in_sicherung:zeilen.length,wird_ersetzt:!NUR_EXPORT[name],
      ...(NUR_EXPORT[name]?{nur_zur_ansicht:`Steht in der Sicherung, wird aber nicht zurückgeschrieben: ${NUR_EXPORT[name]}`}:{}),
      unbekannte_spalten:[...inSicherung].filter(s=>!alle.includes(s)).sort(),
      fehlende_spalten:alle.filter(s=>!istGeheim(s)&&!inSicherung.has(s)&&zeilen.length>0).sort(),
    });
  }
  const geheimnisse=(sicherung?.ausgelassene_geheimnisse??[]).map(g=>`${g.tabelle}.${g.spalte}`);
  return{plan,fehler,geheimnisse};
}

/**
 * Einspielen. Nur nach bestandener Simulation - und in EINEM Stapel, damit nicht die Haelfte der
 * Konfiguration von gestern und die Haelfte von heute nebeneinandersteht.
 */
export async function restoreConfiguration(env:Env,auth:CoreAuthContext,tenantId:string,sicherung:Konfigurationssicherung){
  requireRole(auth,'tenant_admin');
  const {plan,fehler}=await planRestore(env,auth,tenantId,sicherung);
  if(fehler.length)throw new Error(`CONFIG_RESTORE_UNZULAESSIG: ${fehler[0]}`);
  const unbekannt=plan.filter(p=>p.wird_ersetzt&&p.unbekannte_spalten.length);
  if(unbekannt.length)throw new Error(`CONFIG_RESTORE_SPALTE_UNBEKANNT: ${unbekannt[0].tabelle}.${unbekannt[0].unbekannte_spalten[0]}`);
  const anweisungen:unknown[]=[];
  const uebersprungen:string[]=[];
  // Erst alle Loeschungen, dann alle Einfuegungen: eine Elterntabelle raeumt ihre Kinder per
  // Kaskade mit weg, und die duerfen nicht nach dem Einfuegen wieder verschwinden.
  const einfuegen:unknown[]=[];
  for(const [name,zeilen] of Object.entries(sicherung.tabellen)){
    // Was die Plattform vergeben hat, schreibt eine Mandantensicherung nicht zurueck.
    if(NUR_EXPORT[name]){uebersprungen.push(name);continue;}
    const alle=await spalten(env,name);
    const kind=KINDTABELLEN[name];
    if(!kind)anweisungen.push(env.DB.prepare(`DELETE FROM ${name} WHERE ${MANDANTENSPALTE}=?`).bind(tenantId));
    for(const z of zeilen){
      const s=Object.keys(z).filter(k=>alle.includes(k));
      if(!s.length)continue;
      // Die Mandantenkennung kommt aus dem Ziel, nicht aus der Datei - eine praeparierte Sicherung
      // soll nicht in einen fremden Bereich schreiben koennen.
      const werte=s.map(k=>k===MANDANTENSPALTE?tenantId:(z[k]??null));
      einfuegen.push(env.DB.prepare(`INSERT INTO ${name}(${s.map(x=>`"${x}"`).join(',')}) VALUES(${s.map(()=>'?').join(',')})`).bind(...werte));
    }
  }
  await env.DB.batch([...anweisungen,...einfuegen] as never[]);
  await audit(env.DB,auth.userId,'configuration.restored',tenantId,undefined,'tenant',tenantId,{tabellen:Object.keys(sicherung.tabellen).length,pruefsumme:sicherung.pruefsumme});
  return{tabellen:plan.filter(p=>p.wird_ersetzt).length,zeilen:plan.filter(p=>p.wird_ersetzt).reduce((a,p)=>a+p.in_sicherung,0),uebersprungen,geheimnisse_fehlen:(sicherung.ausgelassene_geheimnisse??[]).length};
}

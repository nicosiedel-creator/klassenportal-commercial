// Provider-Abstraktion fuer Mail und Storage (Master-Spec V2, MUSS-V1 "Provider-Abstraktion",
// "Anbieterwechsel", "Keine Vendor-Lock-ins").
//
// Bis hierher stand der Anbieter im Quelltext: mail.ts ruft env.EMAIL, cold-storage.ts und die
// Sicherung rufen env.FILES. Ein Anbieterwechsel war damit kein Betriebsvorgang, sondern eine
// Release - mit Entwickler, Deployment und Freigabelauf. Wer Cloudflare wegen Preis, Ausfall oder
// einer Auflage zur Datenhaltung verlassen muesste, kaeme nicht weg.
//
// Vier Dinge traegt dieses Modul, und nur diese vier:
//
//  1. ZWEI SCHMALE VERTRAEGE. MailAdapter kann senden, StorageAdapter kann ablegen, lesen,
//     loeschen, auflisten. Bewusst nicht mehr: jede weitere Methode ist eine Anforderung an jeden
//     kuenftigen Anbieter, und ein Vertrag, den nur Cloudflare erfuellt, ist kein Vertrag.
//  2. DIE WAHL STEHT IN DATEN, nicht im Code (provider_bindings). Der Aufrufer ruft
//     versendeMail() und weiss nicht, wer sendet - genau das ist der Punkt.
//  3. AUSWEICHEN STATT AUSFALLEN. Faellt der erste Anbieter, uebernimmt der naechste nach
//     prioritaet. Jeder Versuch - der geglueckte auch - steht in provider_health_samples, denn ein
//     unsichtbares Ausweichen ist ein Ausfall mit Verspaetung: irgendwann faellt auch der zweite.
//  4. FAELLT ALLES AUS, FLIEGT EIN FEHLER. Kein stilles Nichtstun. Eine Aktivierungsmail, die
//     niemand versendet und niemand vermisst, ist schlimmer als eine, die sichtbar scheitert.
//
// GEHEIMNISSE GEHOEREN NICHT IN DIE KONFIGURATION. konfiguration_json steht in jedem Backup, in
// jedem Mandantenexport und in jeder Konfigurationssicherung, die herumgereicht wird. Hinein darf
// deshalb nur der NAME eines Geheimnisses, nie sein Wert. Durchgesetzt wird das an beiden Enden:
// beim Schreiben (setzeProviderBindung) und beim Benutzen - eine Bindung, in der doch ein
// Geheimnis steht, wird uebersprungen und vermerkt, statt benutzt zu werden.
import type { CoreAuthContext, Env } from './types.js';
import type { D1PreparedStatementLike } from '../portability/types.js';
import { audit } from './audit.js';
import { requirePlatform, requireRole } from './permissions.js';
import { id, nowIso, sha256Text } from './utils.js';
import { mailConfigured, sendMail } from './mail.js';

export type Providerart = 'mail' | 'storage';
export type Konfiguration = Record<string, string | number | boolean>;

// ---------------------------------------------------------------------------------------------
// Die Vertraege
// ---------------------------------------------------------------------------------------------

export interface MailAuftrag {
  an: string;
  betreff: string;
  text: string;
  html: string;
  /** Fuer die Doppelsendungssperre des Anbieters. */
  schluessel?: string;
  tenantId?: string | null;
}

export interface MailAdapter {
  readonly provider: string;
  /** Liefert die Kennung der Nachricht. Wer nichts liefert, hat nichts gesendet. */
  senden(auftrag: MailAuftrag): Promise<string>;
  /**
   * Erreichbarkeit ohne Nebenwirkung, fuer den testweisen Wechsel. Optional, weil nur der Adapter
   * weiss, was "erreichbar" bei ihm heisst - und weil ein Vertrag, der jedem Anbieter eine
   * Pruefroutine abverlangt, Anbieter ausschliesst statt zuzulassen.
   */
  pruefen?(): Promise<void>;
}

export interface StorageAdapter {
  readonly provider: string;
  ablegen(schluessel: string, inhalt: string, optionen?: { contentType?: string }): Promise<void>;
  lesen(schluessel: string): Promise<string | null>;
  loeschen(schluessel: string): Promise<void>;
  auflisten(praefix: string): Promise<string[]>;
}

export type MailFabrik = (env: Env, konfiguration: Konfiguration) => MailAdapter;
export type StorageFabrik = (env: Env, konfiguration: Konfiguration) => StorageAdapter;

const MAIL_FABRIKEN: Record<string, MailFabrik> = {};
const STORAGE_FABRIKEN: Record<string, StorageFabrik> = {};

/**
 * Ein neuer Anbieter kommt hierueber dazu - ohne dass ein einziger Aufrufer angefasst wird. Das
 * ist der eigentliche Inhalt von "austauschbare Schnittstelle": die Liste der Anbieter waechst an
 * einer Stelle, nicht an dreissig.
 */
export function registriereMailAdapter(provider: string, fabrik: MailFabrik): void { MAIL_FABRIKEN[provider] = fabrik; }
export function registriereStorageAdapter(provider: string, fabrik: StorageFabrik): void { STORAGE_FABRIKEN[provider] = fabrik; }
export function bekannteProvider(art: Providerart): string[] { return Object.keys(art === 'mail' ? MAIL_FABRIKEN : STORAGE_FABRIKEN).sort(); }

// ---------------------------------------------------------------------------------------------
// Die Geheimnissperre
// ---------------------------------------------------------------------------------------------

/** Schluesselnamen, hinter denen ein Wert stehen wuerde, der nicht in die Datenbank gehoert. */
const GEHEIMER_NAME = /(secret|token|password|passwort|kennwort|credential|api[_-]?key|apikey|private|signature|geheim)/i;
/** Ein VERWEIS ist erlaubt: er nennt den Namen des Geheimnisses, nicht das Geheimnis. */
const VERWEISNAME = /_(secret_name|secret_ref)$/;
/** Und ein Verweis muss wie ein Umgebungsname aussehen, nicht wie ein Wert. */
const UMGEBUNGSNAME = /^[A-Z][A-Z0-9_]{2,63}$/;

// Werte, die sich selbst verraten. Die Liste ist nicht vollstaendig und kann es nicht sein - sie
// faengt die Faelle, die in der Praxis passieren: jemand kopiert den Schluessel aus dem Portal des
// Anbieters in das Formular, weil das Feld daneben steht.
const GEHEIME_WERTE = [
  /^sk_(live|test)_/i,
  /^xkeysib-/i,
  /^SG\.[A-Za-z0-9_-]{10,}/,
  /^Bearer\s+\S+/i,
  /-----BEGIN [A-Z ]*PRIVATE KEY-----/,
  /^eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\./,
];

function riechtNachGeheimnis(wert: string): boolean {
  if (GEHEIME_WERTE.some(r => r.test(wert))) return true;
  // Der Rest ist eine Entropie-Faustregel: lang, ohne Trennzeichen, gemischt. Ein Bucketname
  // ("eu-central-bildungswerk-objektspeicher") faellt nicht darunter, ein 40-Zeichen-Token schon.
  if (wert.length < 32 || !/^[A-Za-z0-9+/=_-]+$/.test(wert)) return false;
  return /^[0-9a-f]{32,}$/.test(wert) || (/[a-z]/.test(wert) && /[A-Z]/.test(wert) && /[0-9]/.test(wert));
}

/**
 * Konfiguration einlesen und dabei sicherstellen, dass kein Geheimnis darin steht.
 *
 * Wirft statt zu bereinigen: ein stilles Entfernen haette denselben Effekt wie ein kaputter
 * Anbieter, nur ohne Hinweis - und die Person, die den Schluessel eingetragen hat, glaubte, sie
 * haette ihn hinterlegt.
 */
export function pruefeKonfiguration(roh: unknown): Konfiguration {
  let quelle: unknown = roh;
  if (typeof roh === 'string') { try { quelle = JSON.parse(roh || '{}'); } catch { throw new Error('PROVIDER_KONFIGURATION_UNLESBAR'); } }
  if (!quelle || typeof quelle !== 'object' || Array.isArray(quelle)) throw new Error('PROVIDER_KONFIGURATION_UNGUELTIG');
  const out: Konfiguration = {};
  for (const [schluessel, wert] of Object.entries(quelle as Record<string, unknown>)) {
    if (wert === null || wert === undefined) continue;
    if (typeof wert === 'object') throw new Error(`PROVIDER_KONFIGURATION_UNGUELTIG: ${schluessel}`);
    const text = String(wert);
    if (VERWEISNAME.test(schluessel)) {
      // Ein Verweis, der nicht wie ein Umgebungsname aussieht, ist in aller Regel der Wert selbst.
      if (!UMGEBUNGSNAME.test(text)) throw new Error(`PROVIDER_GEHEIMNISVERWEIS_UNGUELTIG: ${schluessel}`);
      out[schluessel] = text;
      continue;
    }
    if (GEHEIMER_NAME.test(schluessel)) throw new Error(`PROVIDER_GEHEIMNIS_IN_KONFIGURATION: ${schluessel}`);
    if (typeof wert === 'string' && riechtNachGeheimnis(text)) throw new Error(`PROVIDER_GEHEIMNIS_IN_KONFIGURATION: ${schluessel}`);
    out[schluessel] = wert as string | number | boolean;
  }
  return out;
}

/**
 * Den Wert zu einem Verweis holen - aus der Umgebung, nie aus der Datenbank. Fehlt er, bricht der
 * Adapter ab und die Kette weicht aus; ein Anbieter ohne Schluessel sendet ohnehin nicht.
 */
export function geheimnisAus(env: Env, konfiguration: Konfiguration, schluessel: string): string {
  const name = String(konfiguration[schluessel] ?? '');
  if (!UMGEBUNGSNAME.test(name)) throw new Error(`PROVIDER_GEHEIMNISVERWEIS_FEHLT: ${schluessel}`);
  const wert = String((env as unknown as Record<string, unknown>)[name] ?? '');
  if (!wert) throw new Error(`PROVIDER_GEHEIMNIS_NICHT_HINTERLEGT: ${name}`);
  return wert;
}

// ---------------------------------------------------------------------------------------------
// Die eingebauten Adapter
// ---------------------------------------------------------------------------------------------

// Der bisherige Weg, unveraendert: Cloudflare Email Service ueber mail.ts. Er bleibt der Standard,
// damit dieses Modul nichts umstellt, was heute laeuft - es macht den Weg nur austauschbar.
registriereMailAdapter('cloudflare_email', (env) => ({
  provider: 'cloudflare_email',
  async senden(auftrag) { return sendMail(env, auftrag.an, auftrag.betreff, auftrag.text, auftrag.html, auftrag.schluessel); },
  async pruefen() { if (!mailConfigured(env)) throw new Error('MAIL_PROVIDER_NOT_CONFIGURED'); },
}));

/**
 * Der Protokolladapter: schreibt, statt zu senden.
 *
 * Er ist kein Spielzeug. Er ist der Weg, auf dem ein Traeger eine Abnahme fahren kann, ohne echte
 * Post an echte Menschen zu schicken - und er ist der Auffangweg, wenn kein Anbieter mehr traegt:
 * dann steht wenigstens fest, WAS haette rausgehen sollen, statt dass es spurlos verschwindet.
 *
 * Der INHALT wird ausdruecklich nicht mitgeschrieben. Aktivierungs- und Passwortmails tragen ein
 * Einmalgeheimnis im Text; ein Protokoll, das den Text mitfuehrt, waere ein Kennwortspeicher im
 * Pruefprotokoll. Empfaenger, Betreff und Laenge reichen fuer jede Nachschau.
 */
registriereMailAdapter('protokoll', (env) => ({
  provider: 'protokoll',
  async senden(auftrag) {
    const kennung = id('mailprot_');
    await audit(env.DB, undefined, 'mail.protokolliert', auftrag.tenantId ?? undefined, undefined, 'mail', kennung,
      { an: auftrag.an, betreff: auftrag.betreff, zeichen: auftrag.text.length, hinweis: 'nicht versendet' });
    return kennung;
  },
}));

// Der Objektspeicher von Cloudflare - der heutige Weg von Sicherung, Kaltarchiv und Materialien.
registriereStorageAdapter('r2', (env) => ({
  provider: 'r2',
  async ablegen(schluessel, inhalt, optionen) { await env.FILES.put(schluessel, inhalt, { httpMetadata: { contentType: optionen?.contentType ?? 'application/octet-stream' } }); },
  async lesen(schluessel) { const obj = await env.FILES.get(schluessel); return obj ? await new Response(obj.body).text() : null; },
  async loeschen(schluessel) { await env.FILES.delete(schluessel); },
  async auflisten(praefix) { return (await env.FILES.list({ prefix: praefix, limit: 1000 })).objects.map(o => o.key); },
}));

// Ein Speicher im Arbeitsspeicher. Fuer Tests und fuer den Trockenlauf eines Wechsels: die
// Integritaetspruefung soll den VERTRAG pruefen koennen, ohne dafuer fremde Kosten und fremde
// Datenhaltung anzufassen. `raum` trennt gleichzeitige Benutzungen voneinander.
const SPEICHERRAEUME = new Map<string, Map<string, string>>();
export function speicherraum(name: string): Map<string, string> {
  const vorhanden = SPEICHERRAEUME.get(name);
  if (vorhanden) return vorhanden;
  const neu = new Map<string, string>();
  SPEICHERRAEUME.set(name, neu);
  return neu;
}
registriereStorageAdapter('speicher', (_env, konfiguration) => {
  const raum = speicherraum(String(konfiguration.raum ?? 'standard'));
  return {
    provider: 'speicher',
    async ablegen(schluessel, inhalt) { raum.set(schluessel, inhalt); },
    async lesen(schluessel) { return raum.has(schluessel) ? String(raum.get(schluessel)) : null; },
    async loeschen(schluessel) { raum.delete(schluessel); },
    async auflisten(praefix) { return [...raum.keys()].filter(k => k.startsWith(praefix)).sort(); },
  };
});

// ---------------------------------------------------------------------------------------------
// Die Kette
// ---------------------------------------------------------------------------------------------

export interface Bindung {
  /** null heisst: eingebauter Standard, es gibt keine Zeile zum Fortschreiben. */
  id: string | null;
  tenant_id: string | null;
  art: Providerart;
  provider: string;
  konfiguration_json: string;
  prioritaet: number;
}

/**
 * Was gilt, solange niemand etwas eingestellt hat.
 *
 * Eine leere Tabelle darf den Mailversand nicht abschalten. Die Migration liefert deshalb
 * ausdruecklich KEINE Zeilen: ohne Eintrag gilt genau der Weg, der vorher fest verdrahtet war.
 * Das Modul aendert damit nichts am Betrieb - es macht ihn nur wechselbar.
 */
export const STANDARDKETTE: Record<Providerart, string[]> = { mail: ['cloudflare_email'], storage: ['r2'] };

function standardbindung(art: Providerart, provider: string, rang: number): Bindung {
  return { id: null, tenant_id: null, art, provider, konfiguration_json: '{}', prioritaet: 1000 + rang };
}

/**
 * Die Kette fuer eine Art laden - EINE Abfrage, gleich wie viele Anbieter eingetragen sind.
 *
 * Hat der Mandant eine eigene Kette, ERSETZT sie die plattformweite; sie ergaenzt sie nicht. Sonst
 * liefe die Mail eines Traegers, der bewusst zu einem eigenen Anbieter gewechselt ist, beim ersten
 * Schluckauf wieder ueber den Weg der Plattform - genau ueber den, von dem er weg wollte. Ein
 * Ausweichen darf keine Auflage zur Datenhaltung unterlaufen.
 */
export async function ketteFuer(env: Env, art: Providerart, tenantId?: string | null): Promise<Bindung[]> {
  const zeilen = ((await env.DB.prepare(
    'SELECT id,tenant_id,art,provider,konfiguration_json,prioritaet FROM provider_bindings WHERE art=? AND ist_aktiv=1 AND (tenant_id=? OR tenant_id IS NULL) ORDER BY prioritaet,provider',
  ).bind(art, tenantId ?? null).all<Bindung>()).results) ?? [];
  const eigene = zeilen.filter(z => z.tenant_id);
  const kette = eigene.length ? eigene : zeilen;
  if (kette.length) return kette;
  return STANDARDKETTE[art].map((p, i) => standardbindung(art, p, i));
}

type Probe = { bindung: Bindung; erfolg: boolean; dauer: number; fehler: string | null };

function fehlercode(error: unknown): string {
  const roh = String((error as Error)?.message ?? error ?? 'FEHLER');
  return (roh.split(':')[0] || 'FEHLER').trim().toUpperCase().replace(/[^A-Z0-9_]+/g, '_').slice(0, 80) || 'FEHLER';
}

/**
 * Stichproben und Bindungsstand in EINEM Stapel.
 *
 * Cloudflare zaehlt 1000 Unteranfragen je Aufruf, ein Stapel zaehlt als eine. Ein Versand kostet
 * damit zwei Unteranfragen fuer die Verwaltung - die Abfrage der Kette und diesen Stapel -
 * unabhaengig davon, wie viele Anbieter probiert wurden. Eine Schreibung je Versuch waere die Art
 * von Detail, die erst beim Rundschreiben an 400 Empfaenger auffaellt.
 */
async function schreibeProben(env: Env, art: Providerart, tenantId: string | null, proben: Probe[]): Promise<void> {
  if (!proben.length) return;
  const jetzt = nowIso();
  const anweisungen: D1PreparedStatementLike[] = [];
  for (const p of proben) {
    anweisungen.push(env.DB.prepare('INSERT INTO provider_health_samples(id,zeitpunkt,tenant_id,art,provider,erfolg,dauer_ms,fehler) VALUES(?,?,?,?,?,?,?,?)')
      .bind(id('phs_'), jetzt, tenantId, art, p.bindung.provider, p.erfolg ? 1 : 0, Math.max(0, Math.round(p.dauer)), p.fehler));
    if (!p.bindung.id) continue;
    anweisungen.push(p.erfolg
      ? env.DB.prepare('UPDATE provider_bindings SET letzter_erfolg_am=?,updated_at=? WHERE id=?').bind(jetzt, jetzt, p.bindung.id)
      : env.DB.prepare('UPDATE provider_bindings SET letzter_fehler_am=?,letzter_fehler=?,updated_at=? WHERE id=?').bind(jetzt, p.fehler, jetzt, p.bindung.id));
  }
  await env.DB.batch(anweisungen);
}

export interface Ausweichergebnis<R> { provider: string; ergebnis: R; ausgewichen: string[]; }

/**
 * Der Kern: die Kette der Reihe nach durchgehen, beim ersten Erfolg aufhoeren, jeden Versuch
 * vermerken - und wenn keiner traegt, LAUT scheitern.
 *
 * Das laute Scheitern ist die eigentliche Zusage. Ein Ausweichplan, der am Ende still nichts tut,
 * ist gefaehrlicher als gar keiner: er nimmt dem Betrieb die Stelle, an der er merken wuerde, dass
 * seit einer Woche keine Mail das Haus verlaesst.
 */
async function ueberKette<A, R>(
  env: Env,
  art: Providerart,
  tenantId: string | null,
  fabriken: Record<string, (env: Env, konfiguration: Konfiguration) => A>,
  tun: (adapter: A) => Promise<R>,
): Promise<Ausweichergebnis<R>> {
  const kette = await ketteFuer(env, art, tenantId);
  const proben: Probe[] = [];
  const ausgewichen: string[] = [];
  let treffer: { provider: string; ergebnis: R } | null = null;
  for (const bindung of kette) {
    const start = Date.now();
    try {
      // Die Geheimnissperre gilt auch hier, nicht nur beim Schreiben: eine Zeile kann ueber eine
      // Wiederherstellung, eine Migration oder die Konsole in die Tabelle kommen. Fail closed -
      // diese Bindung wird nicht benutzt, die naechste uebernimmt, und es steht im Verlauf.
      const konfiguration = pruefeKonfiguration(bindung.konfiguration_json);
      const fabrik = fabriken[bindung.provider];
      if (!fabrik) throw new Error('PROVIDER_UNBEKANNT');
      const ergebnis = await tun(fabrik(env, konfiguration));
      proben.push({ bindung, erfolg: true, dauer: Date.now() - start, fehler: null });
      treffer = { provider: bindung.provider, ergebnis };
      break;
    } catch (error) {
      const code = fehlercode(error);
      proben.push({ bindung, erfolg: false, dauer: Date.now() - start, fehler: code });
      ausgewichen.push(`${bindung.provider}:${code}`);
    }
  }
  await schreibeProben(env, art, tenantId, proben);
  if (!treffer) throw new Error(`PROVIDER_ALLE_AUSGEFALLEN_${art.toUpperCase()}: ${ausgewichen.join(', ') || 'keine Bindung'}`);
  return { provider: treffer.provider, ergebnis: treffer.ergebnis, ausgewichen };
}

// ---------------------------------------------------------------------------------------------
// Was die Aufrufer benutzen
// ---------------------------------------------------------------------------------------------

/**
 * Mail versenden - ohne zu wissen, wer sendet.
 *
 * Genau diese Signatur ist der Gewinn: ein Anbieterwechsel ist ab hier eine Zeile in
 * provider_bindings und keine Aenderung an einer einzigen aufrufenden Stelle.
 */
export async function versendeMail(env: Env, auftrag: MailAuftrag): Promise<{ provider: string; message_id: string; ausgewichen: string[] }> {
  const r = await ueberKette<MailAdapter, string>(env, 'mail', auftrag.tenantId ?? null, MAIL_FABRIKEN, a => a.senden(auftrag));
  return { provider: r.provider, message_id: r.ergebnis, ausgewichen: r.ausgewichen };
}

export async function legeObjektAb(env: Env, schluessel: string, inhalt: string, optionen?: { contentType?: string; tenantId?: string | null }): Promise<{ provider: string }> {
  const r = await ueberKette<StorageAdapter, void>(env, 'storage', optionen?.tenantId ?? null, STORAGE_FABRIKEN, a => a.ablegen(schluessel, inhalt, { contentType: optionen?.contentType }));
  return { provider: r.provider };
}

export async function leseObjekt(env: Env, schluessel: string, optionen?: { tenantId?: string | null }): Promise<{ provider: string; inhalt: string | null }> {
  const r = await ueberKette<StorageAdapter, string | null>(env, 'storage', optionen?.tenantId ?? null, STORAGE_FABRIKEN, a => a.lesen(schluessel));
  return { provider: r.provider, inhalt: r.ergebnis };
}

export async function loescheObjekt(env: Env, schluessel: string, optionen?: { tenantId?: string | null }): Promise<{ provider: string }> {
  const r = await ueberKette<StorageAdapter, void>(env, 'storage', optionen?.tenantId ?? null, STORAGE_FABRIKEN, a => a.loeschen(schluessel));
  return { provider: r.provider };
}

export async function listeObjekte(env: Env, praefix: string, optionen?: { tenantId?: string | null }): Promise<{ provider: string; schluessel: string[] }> {
  const r = await ueberKette<StorageAdapter, string[]>(env, 'storage', optionen?.tenantId ?? null, STORAGE_FABRIKEN, a => a.auflisten(praefix));
  return { provider: r.provider, schluessel: r.ergebnis };
}

// ---------------------------------------------------------------------------------------------
// Verwaltung
// ---------------------------------------------------------------------------------------------

function zugang(auth: CoreAuthContext, tenantId: string | null): void {
  // Plattformweite Ketten gehen nur die Plattform an: sie gelten fuer alle Mandanten, die keine
  // eigene haben. Die eigene Kette eines Traegers ist Sache seiner Leitung.
  if (!tenantId) { requirePlatform(auth); return; }
  requireRole(auth, 'tenant_admin');
  if (!auth.isPlatformAdmin && !auth.tenantIds.includes(tenantId)) throw new Error('FORBIDDEN_TENANT');
}

export async function providerBindungen(env: Env, auth: CoreAuthContext, tenantId: string | null): Promise<Record<string, unknown>[]> {
  zugang(auth, tenantId);
  return ((await env.DB.prepare(
    'SELECT id,tenant_id,art,provider,konfiguration_json,ist_aktiv,prioritaet,letzter_erfolg_am,letzter_fehler_am,letzter_fehler,created_at,updated_at FROM provider_bindings WHERE (tenant_id=? OR (? IS NULL AND tenant_id IS NULL)) ORDER BY art,prioritaet,provider',
  ).bind(tenantId, tenantId).all<Record<string, unknown>>()).results) ?? [];
}

/**
 * Eine Bindung setzen. Derselbe Anbieter zweimal waere ein Ausweichplan, der zweimal an dieselbe
 * Tuer klopft - deshalb ersetzt ein zweiter Aufruf denselben Eintrag.
 */
export async function setzeProviderBindung(env: Env, auth: CoreAuthContext, eingabe: {
  tenantId?: string | null; art: Providerart; provider: string; konfiguration?: unknown; prioritaet?: number; ist_aktiv?: boolean;
}): Promise<{ id: string; art: Providerart; provider: string }> {
  const tenantId = eingabe.tenantId ?? null;
  zugang(auth, tenantId);
  if (eingabe.art !== 'mail' && eingabe.art !== 'storage') throw new Error('PROVIDER_ART_UNBEKANNT');
  const fabriken = eingabe.art === 'mail' ? MAIL_FABRIKEN : STORAGE_FABRIKEN;
  // Ein Anbietername, fuer den es keinen Adapter gibt, waere eine Kette mit einem toten Glied -
  // beim Schreiben auffallen ist billiger als beim ersten Ausfall.
  if (!fabriken[eingabe.provider]) throw new Error(`PROVIDER_UNBEKANNT: ${eingabe.provider}`);
  const konfiguration = pruefeKonfiguration(eingabe.konfiguration ?? {});
  const jetzt = nowIso();
  const vorhanden = await env.DB.prepare(
    'SELECT id FROM provider_bindings WHERE art=? AND provider=? AND (tenant_id=? OR (? IS NULL AND tenant_id IS NULL))',
  ).bind(eingabe.art, eingabe.provider, tenantId, tenantId).first<{ id: string }>();
  const kennung = vorhanden?.id ?? id('prov_');
  const prioritaet = Number.isFinite(eingabe.prioritaet) ? Number(eingabe.prioritaet) : 100;
  const aktiv = eingabe.ist_aktiv === false ? 0 : 1;
  if (vorhanden) {
    await env.DB.prepare('UPDATE provider_bindings SET konfiguration_json=?,ist_aktiv=?,prioritaet=?,updated_at=? WHERE id=?')
      .bind(JSON.stringify(konfiguration), aktiv, prioritaet, jetzt, kennung).run();
  } else {
    await env.DB.prepare('INSERT INTO provider_bindings(id,tenant_id,art,provider,konfiguration_json,ist_aktiv,prioritaet,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)')
      .bind(kennung, tenantId, eingabe.art, eingabe.provider, JSON.stringify(konfiguration), aktiv, prioritaet, auth.userId, jetzt, jetzt).run();
  }
  await audit(env.DB, auth.userId, 'provider.binding.set', tenantId ?? undefined, undefined, 'provider_binding', kennung,
    { art: eingabe.art, provider: eingabe.provider, prioritaet, ist_aktiv: aktiv });
  return { id: kennung, art: eingabe.art, provider: eingabe.provider };
}

export async function providerGesundheit(env: Env, auth: CoreAuthContext, tenantId: string | null, limit = 50): Promise<Record<string, unknown>[]> {
  zugang(auth, tenantId);
  return ((await env.DB.prepare(
    'SELECT id,zeitpunkt,art,provider,erfolg,dauer_ms,fehler FROM provider_health_samples WHERE (tenant_id=? OR (? IS NULL AND tenant_id IS NULL)) ORDER BY zeitpunkt DESC,id DESC LIMIT ?',
  ).bind(tenantId, tenantId, Math.max(1, Math.min(500, limit))).all<Record<string, unknown>>()).results) ?? [];
}

/**
 * Der testweise Wechsel mit Integritaetspruefung (Master-Spec V2).
 *
 * Fuer Storage ist die Pruefung ein Rundlauf ueber den VERTRAG selbst: schreiben, zuruecklesen,
 * Pruefsumme vergleichen, aufraeumen. Was der Anbieter ueber sich selbst meldet, zaehlt dabei
 * nicht - nur was zurueckkommt. Fuer Mail gibt es keinen Rundlauf ohne echte Post an echte
 * Menschen; dort wird geprueft, was ohne Nebenwirkung pruefbar ist, und das Ergebnis sagt offen,
 * wie weit die Pruefung reichte.
 */
export async function pruefeProvider(env: Env, auth: CoreAuthContext, eingabe: { tenantId?: string | null; art: Providerart; provider: string; konfiguration?: unknown }): Promise<{
  art: Providerart; provider: string; erfolg: boolean; dauer_ms: number; tiefe: 'rundlauf' | 'konfiguration'; fehler: string | null;
}> {
  const tenantId = eingabe.tenantId ?? null;
  zugang(auth, tenantId);
  const start = Date.now();
  let erfolg = false, fehler: string | null = null;
  let tiefe: 'rundlauf' | 'konfiguration' = 'konfiguration';
  try {
    const konfiguration = pruefeKonfiguration(eingabe.konfiguration ?? {});
    if (eingabe.art === 'storage') {
      const fabrik = STORAGE_FABRIKEN[eingabe.provider];
      if (!fabrik) throw new Error('PROVIDER_UNBEKANNT');
      const adapter = fabrik(env, konfiguration);
      // Der Probeschluessel traegt keine Kundendaten und wird sofort wieder entfernt.
      const schluessel = `provider-pruefung/${tenantId ?? 'plattform'}/${id('p_')}.txt`;
      const inhalt = `Integritaetspruefung ${nowIso()} ${id('n_')}`;
      await adapter.ablegen(schluessel, inhalt, { contentType: 'text/plain' });
      const zurueck = await adapter.lesen(schluessel);
      tiefe = 'rundlauf';
      if (zurueck === null) throw new Error('PROVIDER_RUNDLAUF_LEER');
      if (await sha256Text(zurueck) !== await sha256Text(inhalt)) throw new Error('PROVIDER_RUNDLAUF_ABWEICHUNG');
      await adapter.loeschen(schluessel);
      if (await adapter.lesen(schluessel) !== null) throw new Error('PROVIDER_LOESCHEN_WIRKUNGSLOS');
    } else {
      const fabrik = MAIL_FABRIKEN[eingabe.provider];
      if (!fabrik) throw new Error('PROVIDER_UNBEKANNT');
      const adapter = fabrik(env, konfiguration);
      if (adapter.pruefen) await adapter.pruefen();
    }
    erfolg = true;
  } catch (error) {
    fehler = fehlercode(error);
  }
  const dauer = Date.now() - start;
  await schreibeProben(env, eingabe.art, tenantId, [{ bindung: { id: null, tenant_id: tenantId, art: eingabe.art, provider: eingabe.provider, konfiguration_json: '{}', prioritaet: 0 }, erfolg, dauer, fehler }]);
  return { art: eingabe.art, provider: eingabe.provider, erfolg, dauer_ms: dauer, tiefe, fehler };
}

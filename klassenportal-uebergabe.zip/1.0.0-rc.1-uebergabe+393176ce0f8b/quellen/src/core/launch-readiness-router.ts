import type { Env } from './types.js';
import { resolveCoreAuth } from './auth.js';
import { ownerLegal, publicLegal, updateOwnerLegal } from './legal.js';
import { productionReadiness } from './launch-readiness.js';
import { approveProductionRelease, releaseStateForOwner, revokeProductionRelease } from './production-release-gate.js';
import { verifyBackup, verifyPendingBackups } from './backup-verification.js';
import { portabilityConfig, runScheduledTenantBackups } from '../portability/index.js';
import { submitLegalContentReport } from './legal-content-report.js';
import { publicProduct } from './public-product.js';
import { copyEuStorageBatch, euStorageMigrationStatus, finalizeEuStorageMigration } from './eu-storage-migration.js';
import { speicherLage } from './storage-growth.js';
import { archiviereKaltdaten, archivierbareJahre, kaltarchive, stelleKaltdatenWiederHer } from './cold-storage.js';
import { brichNachfolgeAb, fuehreNachfolgeFort, nachfolgen, planeNachfolge } from './tenant-succession.js';
import { assertSameOrigin, authStatus, json, safeErrorCode } from './utils.js';

async function body(request:Request):Promise<Record<string,unknown>>{try{return await request.json() as Record<string,unknown>;}catch{return{};}}
function fail(e:unknown):Response{
  const code=safeErrorCode(e);
  const status=authStatus(code)??(code==='UNAUTHENTICATED'?401:code.includes('ADMIN_REQUIRED')||code.startsWith('FORBIDDEN')||code==='CURRENT_PASSWORD_INVALID'?403:code.includes('NOT_FOUND')?404:code==='LEGAL_REPORT_RATE_LIMITED'?429:code==='COLD_ARCHIVE_VERIFY_FAILED'||code==='COLD_ARCHIVE_OBJECT_MISSING'?500:code==='COLD_PERIOD_TOO_RECENT'||code==='COLD_TABLE_NOT_ARCHIVABLE'?409:code==='SUCCESSION_MOVE_INCOMPLETE'?500:code==='SUCCESSION_ALREADY_STARTED'||code==='SUCCESSION_CANCELLED'||code==='SUCCESSION_SAME_TENANT'?409:code.includes('NOT_READY')||code.includes('NOT_ACTIVE')||code.includes('STATE_CHANGED')?409:code.includes('REQUIRED')||code.includes('INVALID')||code.includes('CONFIRMATION')?400:500);
  return json({ok:false,error:code},status);
}
export async function handleLaunchReadinessApi(request:Request,env:Env):Promise<Response|null>{
  const u=new URL(request.url);
  try{
    if(u.pathname==='/api/public/legal'&&request.method==='GET')return json({ok:true,legal:await publicLegal(env)});
    if(u.pathname==='/api/public/product'&&request.method==='GET')return json({ok:true,product:await publicProduct(env)});
    if(u.pathname==='/api/legal/report'&&request.method==='POST')return json({ok:true,...await submitLegalContentReport(env,request)},201);
    if(!u.pathname.startsWith('/api/platform/legal')&&!u.pathname.startsWith('/api/platform/release-readiness')&&!u.pathname.startsWith('/api/platform/release-state')&&!u.pathname.startsWith('/api/platform/backups/')&&!u.pathname.startsWith('/api/platform/eu-storage-migration')&&u.pathname!=='/api/platform/storage'&&!u.pathname.startsWith('/api/platform/cold-storage')&&!u.pathname.startsWith('/api/platform/succession'))return null;
    assertSameOrigin(request,env.APP_ORIGIN);const auth=await resolveCoreAuth(env,request);
    if(u.pathname==='/api/platform/legal'&&request.method==='GET')return json({ok:true,legal:await ownerLegal(env,auth)});
    if(u.pathname==='/api/platform/legal'&&request.method==='PUT')return json({ok:true,legal:await updateOwnerLegal(env,auth,await body(request))});
    if(u.pathname==='/api/platform/release-readiness'&&request.method==='GET')return json({ok:true,readiness:await productionReadiness(env,auth)});
    if(u.pathname==='/api/platform/storage'&&request.method==='GET')return json({ok:true,storage:await speicherLage(env,auth)});
    if(u.pathname==='/api/platform/succession'&&request.method==='GET')return json({ok:true,successions:await nachfolgen(env,auth,u.searchParams.get('tenant_id')||'')});
    if(u.pathname==='/api/platform/succession'&&request.method==='POST')return json({ok:true,...await planeNachfolge(env,auth,await body(request))},201);
    if(u.pathname==='/api/platform/succession/continue'&&request.method==='POST'){const b=await body(request);return json({ok:true,...await fuehreNachfolgeFort(env,auth,String(b.succession_id||''))});}
    if(u.pathname==='/api/platform/succession/cancel'&&request.method==='POST'){const b=await body(request);return json({ok:true,...await brichNachfolgeAb(env,auth,String(b.succession_id||''))});}
    if(u.pathname==='/api/platform/cold-storage'&&request.method==='GET'){const b=u.searchParams.get('tenant_id')||'';return json({ok:true,rahmen:await archivierbareJahre(env,auth),archive:await kaltarchive(env,auth,b)});}
    if(u.pathname==='/api/platform/cold-storage/archive'&&request.method==='POST'){const b=await body(request);return json({ok:true,...await archiviereKaltdaten(env,auth,String(b.tenant_id||''),String(b.table||''),Number(b.year))});}
    if(u.pathname==='/api/platform/cold-storage/restore'&&request.method==='POST'){const b=await body(request);return json({ok:true,...await stelleKaltdatenWiederHer(env,auth,String(b.archive_id||''))});}
    if(u.pathname==='/api/platform/release-state'&&request.method==='GET')return json({ok:true,state:await releaseStateForOwner(env,auth)});
    if(u.pathname==='/api/platform/release-state/approve'&&request.method==='POST')return json({ok:true,...await approveProductionRelease(env,auth,await body(request))});
    if(u.pathname==='/api/platform/release-state/revoke'&&request.method==='POST')return json({ok:true,...await revokeProductionRelease(env,auth,await body(request))});
    if(u.pathname==='/api/platform/eu-storage-migration/status'&&request.method==='GET')return json({ok:true,migration:await euStorageMigrationStatus(env,auth)});
    if(u.pathname==='/api/platform/eu-storage-migration/copy'&&request.method==='POST')return json({ok:true,...await copyEuStorageBatch(env,auth,await body(request))});
    if(u.pathname==='/api/platform/eu-storage-migration/finalize'&&request.method==='POST')return json({ok:true,...await finalizeEuStorageMigration(env,auth,await body(request))});
    // Sicherungen auf Zuruf statt im Sechsstundentakt.
    //
    // Die Freigabe verlangt fuer jeden aktiven Mandanten ein geprueftes Backup, das juenger als
    // 48 Stunden ist. Erzeugt und geprueft wurde beides bisher nur im laengeren Zeitplan
    // (src/index.ts: der Fuenfminutenlauf kehrt vorher um). Wer heute in Betrieb geht, sass also
    // vor einer roten Freigabepruefung und konnte nichts tun ausser warten - bis zu sechs
    // Stunden. Derselbe Ablauf, nur jetzt.
    if(u.pathname==='/api/platform/backups/run'&&request.method==='POST'){
      if(!auth.isPlatformAdmin)throw new Error('PLATFORM_ADMIN_REQUIRED');
      const gesichert=await runScheduledTenantBackups(env,portabilityConfig,`platform:${auth.userId}`,3);
      const geprueft=await verifyPendingBackups(env,3);
      return json({ok:true,gesichert:gesichert.backedUp.length,geprueft:geprueft.verified,gescheitert:geprueft.failed,weitere_offen:!!gesichert.nextCursor});
    }
    const verify=u.pathname.match(/^\/api\/platform\/backups\/([^/]+)\/verify$/);if(verify&&request.method==='POST'){if(!auth.isPlatformAdmin)throw new Error('PLATFORM_ADMIN_REQUIRED');return json({ok:true,verification:await verifyBackup(env,decodeURIComponent(verify[1]))});}
    return new Response('Methode nicht erlaubt',{status:405});
  }catch(e){return fail(e);}
}

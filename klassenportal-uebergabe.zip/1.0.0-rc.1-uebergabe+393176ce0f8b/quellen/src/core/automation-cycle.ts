import type { CoreAuthContext, Env, SessionUser } from './types.js';
import { id, nowIso } from './utils.js';
import { processPushOutbox,PUSH_JE_LAUF} from './collaboration-reporting.js';
import { processErpOutbox, syncCommercialAccounting, syncStripeFees } from './platform-accounting.js';
import { autoMatchBankTransactions, refreshDunningCases } from './platform-accounting-autopilot.js';
import { runSafeEducationAutomation } from './education-automation-safe.js';
import { runLearningOperationsAutomation } from './learning-operations.js';
import { runFutureRadarAllTenants } from './education-radar.js';
import { runConsistencyAllTenants } from './education-consistency.js';
import { runReadinessSnapshots } from './education-readiness-automation.js';
import { runEducationOsMaintenance } from './education-os-maintenance.js';
import { runComplianceRadarBounded } from './training-moat-hardening.js';

function systemAuth():CoreAuthContext{
  const session:SessionUser={userId:'system:accounting',email:'system@localhost.invalid',displayName:'Systemautomation',isPlatformAdmin:true,mustChangePassword:false,tenantRoles:[],authMethod:'api'};
  return{userId:'system:accounting',role:'platform_admin',tenantIds:[],courseIds:[],permissions:['*'],isPlatformAdmin:true,session};
}
async function enqueueNewNotificationPushes(env:Env,limit=500){
  const cutoff=new Date(Date.now()-7*86400000).toISOString();
  const rows=(await env.DB.prepare(`SELECT n.id,n.tenant_id,n.user_id FROM notifications n WHERE n.user_id IS NOT NULL AND n.created_at>=? AND EXISTS(SELECT 1 FROM push_subscriptions s WHERE s.tenant_id=n.tenant_id AND s.user_id=n.user_id AND s.status='active') AND NOT EXISTS(SELECT 1 FROM push_outbox o WHERE o.notification_id=n.id AND o.user_id=n.user_id) ORDER BY n.created_at LIMIT ?`).bind(cutoff,Math.max(1,Math.min(2000,limit))).all<{id:string;tenant_id:string;user_id:string}>()).results??[];
  const ts=nowIso();if(rows.length)await env.DB.batch(rows.map(x=>env.DB.prepare("INSERT INTO push_outbox(id,tenant_id,user_id,notification_id,status,attempts,next_attempt_at,created_at) VALUES(?,?,?,?,'pending',0,?,?)").bind(id('pob_'),x.tenant_id,x.user_id,x.id,ts,ts)));
  return rows.length;
}
async function stripeFeesDue(env:Env){const last=await env.DB.prepare("SELECT created_at FROM accounting_events WHERE event_type='automation.stripe_fees' ORDER BY created_at DESC LIMIT 1").first<{created_at:string}>();return !last||Date.parse(last.created_at)<Date.now()-6*3600000;}
// Cloudflare erlaubt 1000 Unteranfragen je Aufruf - fuer ALLE Jobs zusammen, nicht je Job. Bis
// hierher liefen zwoelf Jobs in einem Zug. Allein die Push-Zustellung brauchte mit 200 Auftraegen
// bis zu 800 davon (je Auftrag eine Abfrage, je Geraet ein Aufruf an den Push-Dienst und eine
// Schreibung), und sie steht an achter Stelle.
//
// Sichtbar wurde das nie, weil jeder Job seinen eigenen Fangblock hat: ist das Budget erschoepft,
// scheitern die restlichen Jobs jeder fuer sich und hinterlassen einen Fehlertext im Ergebnis, den
// niemand liest. Buchhaltung, Bankabgleich, Mahnlauf und ERP-Ausgang stehen am Ende der Liste -
// sie waeren als erstes nie wieder gelaufen, sobald die Plattform ein paar Dutzend Traeger hat.
//
// Jetzt: die guenstigen und die dringenden Jobs laufen jede Runde, die schweren reihum. Der
// Automatiklauf startet alle fuenf Minuten; damit ist jeder schwere Job mindestens stuendlich dran.
export const SCHWERE_JOBS_JE_LAUF=3;

async function reihenfolge(env:Env,anzahl:number):Promise<number>{
  const row=await env.DB.prepare("SELECT next_index FROM automation_cycle_state WHERE id='singleton'").first<{next_index:number}>().catch(()=>null);
  return Math.max(0,Math.trunc(Number(row?.next_index??0)))%Math.max(1,anzahl);
}
async function reihenfolgeMerken(env:Env,naechster:number,gelaufen:string[]):Promise<void>{
  const ts=nowIso();
  await env.DB.prepare("INSERT INTO automation_cycle_state(id,next_index,last_ran,updated_at) VALUES('singleton',?,?,?) ON CONFLICT(id) DO UPDATE SET next_index=excluded.next_index,last_ran=excluded.last_ran,updated_at=excluded.updated_at")
    .bind(naechster,gelaufen.join(','),ts).run().catch(()=>undefined);
}

export async function runPlatformAutomationCycle(env:Env,schwereJeLauf=SCHWERE_JOBS_JE_LAUF){
  const auth=systemAuth(),result:Record<string,unknown>={};
  const versuch=async(name:string,fn:()=>Promise<unknown>)=>{
    try{const r=await fn();if(r!==undefined)result[name]=r;else result[name]='ok';}
    catch(e){result[`${name}_error`]=String((e as Error)?.message||e);}
  };

  // Jede Runde: guenstig oder zeitkritisch. Eine Push-Nachricht, die eine Stunde wartet, ist keine
  // Benachrichtigung mehr.
  await versuch('education_os_maintenance',()=>runEducationOsMaintenance(env));
  await versuch('push_queued',()=>enqueueNewNotificationPushes(env));
  await versuch('push',()=>processPushOutbox(env,PUSH_JE_LAUF));

  // Reihum: jeder dieser Jobs kostet ein Vielfaches und darf die anderen nicht verdraengen.
  const schwer:Array<[string,()=>Promise<unknown>]>=[
    ['education_operations',async()=>{await runSafeEducationAutomation(env);return 'ok';}],
    ['learning_operations',async()=>{await runLearningOperationsAutomation(env);return 'ok';}],
    ['future_radar',()=>runFutureRadarAllTenants(env)],
    ['compliance_radar',()=>runComplianceRadarBounded(env,25)],
    ['consistency',()=>runConsistencyAllTenants(env)],
    ['readiness',()=>runReadinessSnapshots(env)],
    ['accounting',()=>syncCommercialAccounting(env,auth)],
    ['bank_match',()=>autoMatchBankTransactions(env,auth)],
    ['dunning',()=>refreshDunningCases(env,auth)],
    ['stripe_fees',async()=>{
      if(!env.STRIPE_SECRET_KEY)return 'skipped';
      if(!await stripeFeesDue(env))return 'not_due';
      const r=await syncStripeFees(env,auth);
      await env.DB.prepare("INSERT INTO accounting_events(id,event_type,actor_user_id,entity_type,entity_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)")
        .bind(id('aev_'),'automation.stripe_fees',null,'automation','stripe_fees',JSON.stringify(r),nowIso()).run().catch(()=>undefined);
      return r;
    }],
    ['erp',()=>processErpOutbox(env,100)],
  ];
  const start=await reihenfolge(env,schwer.length),genommen=Math.max(1,Math.min(schwer.length,schwereJeLauf)),gelaufen:string[]=[];
  for(let k=0;k<genommen;k++){
    const [name,fn]=schwer[(start+k)%schwer.length];
    gelaufen.push(name);
    await versuch(name,fn);
  }
  await reihenfolgeMerken(env,(start+genommen)%schwer.length,gelaufen);
  result.schwere_jobs_gelaufen=gelaufen;
  result.schwere_jobs_gesamt=schwer.length;
  return result;
}

// Selbsttragende Zeugnisnachweise - Format, Signatur und Pruefung.
//
// WARUM ES DIESES MODUL GIBT
// verifyCertificate sucht den Nachweis ueber verification_token_hash IN DER DATENBANK.
// certificate_records haengt mit ON DELETE CASCADE an tenants. Endet ein Traeger seinen Vertrag,
// wird sein Mandant geloescht und jedes Zeugnis, das er je ausgestellt hat, ist ab diesem Moment
// unpruefbar - obwohl Abschlusszeugnisse in NRW und Berlin bis zu 60 Jahre aufzubewahren sind.
// Ein Nachweis, der die Vertragslaufzeit seines Ausstellers nicht ueberlebt, ist keiner.
//
// Deshalb wird beim Ausstellen zusaetzlich ein Dokument erzeugt, das ALLES enthaelt, was zur
// Pruefung noetig ist - ausser dem oeffentlichen Schluessel des Ausstellers. Wer das Dokument und
// den passenden oeffentlichen Schluessel hat, kann ohne diesen Server, ohne diese Datenbank und
// ohne den Mandanten feststellen, ob der Inhalt echt und unveraendert ist.
//
// VERHAELTNIS ZUR NORM
// Die Form ist an W3C Verifiable Credentials angelehnt (issuer, validFrom, credentialSubject,
// proof als LISTE). Sie gibt sich aber ausdruecklich NICHT als normkonformes VC aus: ein echtes
// JSON-LD-VC verlangt @context und die JSON-LD-Kanonisierung (URDNA2015), und die laesst sich
// hier weder umsetzen noch belegen. Ein "@context" hinzuschreiben, ohne so zu kanonisieren, waere
// eine halbe Norm - also die schlechteste aller Moeglichkeiten: es sieht aus wie etwas, das ein
// fremder Pruefer verarbeiten koennte, ist es aber nicht. Deshalb steht in "format" eine eigene
// Kennung, und die Kanonisierung ist unten ausgeschrieben.
//
// KRYPTO-AGILITAET (ausdrueckliche Anforderung, hier begruendet)
// Ueber 60 Jahre altert jedes Verfahren; SHA-1 und RSA-1024 galten in ihrer Zeit auch als sicher.
// Deshalb:
//   1. Algorithmus und Schluesselkennung stehen IM DOKUMENT (proof.algorithm, proof.keyId), nicht
//      als Annahme im Code. Die Pruefung liest beides aus dem Dokument und sucht das passende
//      Verfahren; sie nimmt nie an, es sei das heutige.
//   2. VERFAHREN ist eine Tabelle. Ein neues Verfahren ist ein Eintrag, kein Umbau - und alte
//      Dokumente bleiben gueltig, weil ihr Eintrag stehen bleibt.
//   3. proof ist eine LISTE. Ein Dokument kann nachsigniert werden: laeuft Ed25519 in 30 Jahren
//      aus, wird mit dem dann starken Verfahren eine zweite Unterschrift ANGEHAENGT, ohne die
//      erste zu entfernen. Jede Unterschrift deckt denselben Rumpf (das Dokument ohne proof), also
//      haengen die Unterschriften nicht voneinander ab und lassen sich in beliebiger Reihenfolge
//      hinzufuegen.
//   Preis dieser Freiheit, offen benannt: weil eine Unterschrift die anderen nicht mitsigniert,
//   kann jeder Unterschriften ABSCHNEIDEN. Eine Pruefung darf deshalb nie nur fragen "ist
//   irgendeine Unterschrift gueltig", sondern muss verlangen, welche Verfahren sie akzeptiert -
//   dafuer gibt es die Option "verlangteAlgorithmen".
//
// WAS DIESES VERFAHREN NICHT LEISTET - ehrlich, damit es niemand annimmt:
//   * Ein selbsttragendes Dokument kann NICHT wissen, dass es widerrufen wurde. Die Unterschrift
//     bleibt nach einem Widerruf mathematisch gueltig. Das Dokument traegt deshalb ein
//     "status"-Feld mit der Adresse der Widerrufsliste und ein Datum (offlineValidUntil), bis zu
//     dem eine Pruefung OHNE Blick in die Liste vertretbar ist. Danach lautet das ehrliche
//     Ergebnis "echt, Widerrufsstand unbekannt" - nicht "gueltig".
//   * Es beweist NICHT, dass der Inhalt wahr ist, sondern nur, dass der Inhaber des Schluessels
//     ihn zu diesem Zeitpunkt so ausgestellt hat.
//   * Es schuetzt NICHT gegen Weitergabe: wer das Dokument kopiert, hat ein gueltiges Dokument.
//     Der Personenbezug im Dokument ist das einzige, was den Missbrauch begrenzt.
//   * Wird der private Schluessel gestohlen, sind alle mit ihm erzeugten Nachweise entwertet. Dann
//     hilft nur, den Schluessel im Verzeichnis auf "retired" zu setzen und die betroffenen
//     Zeugnisse neu auszustellen - rueckwirkend reparieren laesst sich das nicht.
import { safeString } from './utils.js';

/** Kennung des Dokumentformats. Aendert sich die Struktur, aendert sich diese Zahl. */
export const NACHWEIS_FORMAT='klassenportal-nachweis/1';
/** Kennung des Kanonisierungsverfahrens - steht im Dokument, damit ein Pruefer es nachbauen kann. */
export const KANONISIERUNG='kp-json-c14n/1';
// Wie lange eine Pruefung ohne Blick in die Widerrufsliste vertretbar ist. Ein Jahr ist die
// Abwaegung: kuerzer zwingt zu staendigen Onlinepruefungen (und macht den Nachweis wieder vom
// Server abhaengig), laenger laesst einen Widerruf zu lange unbemerkt.
export const OFFLINE_GUELTIG_TAGE=365;

type JwkAehnlich={kty?:string;crv?:string;x?:string;y?:string;d?:string;kid?:string;alg?:string};

type Verfahren={
  /** Wie der Algorithmus im Dokument heisst. */
  kennung:string;
  /** Parameter fuer importKey. */
  einfuhr:{name:string;namedCurve?:string};
  /** Parameter fuer sign/verify. */
  signatur:{name:string;hash?:string};
  /** Erkennt, ob ein JWK zu diesem Verfahren gehoert. */
  passt(jwk:JwkAehnlich):boolean;
  /** Die Felder, die in den Fingerabdruck nach RFC 7638 eingehen - je Schluesseltyp verschieden. */
  fingerabdruckFelder:string[];
};

// Die Verfahrenstabelle. Ein spaeterer Wechsel ist ein Eintrag mehr - kein Umbau.
// Beide Verfahren wurden im echten Workers-Laufzeitkern (workerd, ueber wrangler ausgeliefert)
// ausgefuehrt und nicht nur angenommen: Ed25519 und ECDSA P-256 erzeugen dort je eine 64 Byte
// lange Signatur und verifizieren sie wieder; Ed25519 liefert ein JWK mit kty "OKP" und crv
// "Ed25519". Ed25519 ist die Voreinstellung, weil die Signatur deterministisch ist - dieselbe
// Eingabe ergibt dieselbe Unterschrift, was eine Pruefung 60 Jahre spaeter nachvollziehbar macht.
// ECDSA P-256 steht daneben, weil es im Portal bereits im Einsatz ist (VAPID) und weil ein
// zweites, unabhaengiges Verfahren der Sinn der Sache ist.
export const VERFAHREN:Record<string,Verfahren>={
  'Ed25519':{
    kennung:'Ed25519',
    einfuhr:{name:'Ed25519'},
    signatur:{name:'Ed25519'},
    passt:jwk=>jwk.kty==='OKP'&&jwk.crv==='Ed25519',
    fingerabdruckFelder:['crv','kty','x'],
  },
  'ECDSA-P256-SHA256':{
    kennung:'ECDSA-P256-SHA256',
    einfuhr:{name:'ECDSA',namedCurve:'P-256'},
    signatur:{name:'ECDSA',hash:'SHA-256'},
    passt:jwk=>jwk.kty==='EC'&&jwk.crv==='P-256',
    fingerabdruckFelder:['crv','kty','x','y'],
  },
};

export type Nachweisbeweis={
  algorithm:string;
  keyId:string;
  keyThumbprint:string;
  created:string;
  purpose:string;
  canonicalization:string;
  signature:string;
};
export type Nachweisdokument={
  format:string;
  type:string[];
  id:string;
  issuer:{id:string;name:string;operator:string|null};
  validFrom:string;
  credentialSubject:Record<string,unknown>;
  status:{revocationList:string|null;offlineValidUntil:string;note:string};
  keyDirectory:string|null;
  proof:Nachweisbeweis[];
};

function b64url(bytes:Uint8Array):string{let s='';for(const b of bytes)s+=String.fromCharCode(b);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function ausB64url(text:string):Uint8Array{const s=String(text||'').replace(/-/g,'+').replace(/_/g,'/'),pad=s+'='.repeat((4-s.length%4)%4),roh=atob(pad),out=new Uint8Array(roh.length);for(let i=0;i<roh.length;i++)out[i]=roh.charCodeAt(i);return out;}
function puffer(bytes:Uint8Array):ArrayBuffer{const ab=new ArrayBuffer(bytes.length);new Uint8Array(ab).set(bytes);return ab;}

// Kanonisierung: dieselben Daten muessen JEDES Mal dieselbe Bytefolge ergeben, sonst prueft
// niemand etwas nach - eine andere Schluesselreihenfolge oder ein Leerzeichen mehr wuerde die
// Unterschrift zerstoeren. Regeln, absichtlich klein gehalten und hier ausgeschrieben, damit ein
// fremder Pruefer sie in seiner Sprache nachbauen kann:
//   * Objektschluessel aufsteigend nach UTF-16-Codeeinheiten sortiert (JavaScript-Standardsortierung),
//   * keine Leerzeichen, keine Zeilenumbrueche,
//   * Zahlen in der JSON-Standarddarstellung, undefined und Funktionen sind unzulaessig,
//   * Ausgabe als UTF-8.
// Das entspricht der Idee von RFC 8785 (JCS); Normkonformitaet wird nicht behauptet, weil sie hier
// nicht geprueft werden kann.
export function kanonischesJson(wert:unknown):string{
  if(wert===null)return 'null';
  if(Array.isArray(wert))return `[${wert.map(kanonischesJson).join(',')}]`;
  if(typeof wert==='object'){
    const o=wert as Record<string,unknown>;
    const teile=Object.keys(o).filter(k=>o[k]!==undefined).sort().map(k=>`${JSON.stringify(k)}:${kanonischesJson(o[k])}`);
    return `{${teile.join(',')}}`;
  }
  if(typeof wert==='number'&&!Number.isFinite(wert))throw new Error('CERTIFICATE_CREDENTIAL_INVALID');
  if(typeof wert==='undefined'||typeof wert==='function')throw new Error('CERTIFICATE_CREDENTIAL_INVALID');
  return JSON.stringify(wert);
}

function verfahrenZuJwk(jwk:JwkAehnlich):Verfahren|null{return Object.values(VERFAHREN).find(v=>v.passt(jwk))??null;}
function verfahrenZuKennung(kennung:string):Verfahren|null{return VERFAHREN[String(kennung||'')]??null;}

/** Nur der oeffentliche Teil - der private Anteil "d" darf das Modul nie verlassen. */
export function oeffentlicherTeil(jwk:JwkAehnlich):JwkAehnlich{
  const out:JwkAehnlich={kty:jwk.kty,crv:jwk.crv,x:jwk.x};
  if(jwk.y!==undefined)out.y=jwk.y;
  return out;
}

/** Fingerabdruck des oeffentlichen Schluessels nach RFC 7638: base64url(SHA-256(kanonisches JWK)). */
export async function schluesselFingerabdruck(jwk:JwkAehnlich):Promise<string>{
  const v=verfahrenZuJwk(jwk);
  if(!v)throw new Error('CERTIFICATE_CREDENTIAL_ALGORITHM_UNSUPPORTED');
  const teil:Record<string,unknown>={};
  for(const feld of v.fingerabdruckFelder)teil[feld]=(jwk as Record<string,unknown>)[feld];
  const digest=await crypto.subtle.digest('SHA-256',puffer(new TextEncoder().encode(kanonischesJson(teil))));
  return b64url(new Uint8Array(digest));
}

export type Signierschluessel={keyId:string;algorithmus:string;privat:CryptoKey;oeffentlichJwk:JwkAehnlich;fingerabdruck:string};

/**
 * Der Signierschluessel kommt AUSSCHLIESSLICH aus der Umgebung (Secret), nie aus der Datenbank:
 * ein Schluessel in der Datenbank waere in jedem Backup, in jedem Export und in jeder Kopie der
 * Produktionsdaten - und wer ihn hat, kann jedes Zeugnis dieses Portals faelschen.
 * Fehlt er, wird hier laut abgebrochen. Ein stillschweigend unsigniertes Zeugnis waere das
 * schlechteste Ergebnis: es saehe fertig aus und waere in dem Moment wertlos, in dem es gebraucht
 * wird - und niemand haette es gemerkt.
 */
export async function ladeSignierschluessel(env:{CERTIFICATE_SIGNING_JWK?:string;CERTIFICATE_SIGNING_KEY_ID?:string}):Promise<Signierschluessel>{
  const roh=safeString(env.CERTIFICATE_SIGNING_JWK,8000);
  if(!roh)throw new Error('CERTIFICATE_SIGNING_KEY_MISSING');
  let jwk:JwkAehnlich;
  try{jwk=JSON.parse(roh) as JwkAehnlich;}catch{throw new Error('CERTIFICATE_SIGNING_KEY_INVALID');}
  if(!jwk||typeof jwk!=='object'||!jwk.d)throw new Error('CERTIFICATE_SIGNING_KEY_INVALID');
  const v=verfahrenZuJwk(jwk);
  if(!v)throw new Error('CERTIFICATE_SIGNING_KEY_INVALID');
  let privat:CryptoKey;
  try{privat=await crypto.subtle.importKey('jwk',{...jwk,key_ops:['sign'],ext:false} as JsonWebKey,v.einfuhr,false,['sign']);}
  catch{throw new Error('CERTIFICATE_SIGNING_KEY_INVALID');}
  const oeffentlichJwk=oeffentlicherTeil(jwk),fingerabdruck=await schluesselFingerabdruck(oeffentlichJwk);
  // Die Schluesselkennung darf sich NIE aendern, solange derselbe Schluessel benutzt wird - sonst
  // findet ein Pruefer den Schluessel spaeter nicht wieder. Ohne ausdrueckliche Kennung wird sie
  // deshalb aus dem Schluessel selbst abgeleitet und ist damit reproduzierbar.
  const keyId=safeString(env.CERTIFICATE_SIGNING_KEY_ID,120)||jwk.kid||`kp-${fingerabdruck.slice(0,16)}`;
  return{keyId,algorithmus:v.kennung,privat,oeffentlichJwk,fingerabdruck};
}

/**
 * Grobe Bereitschaftspruefung fuer die Live-Freigabe: ist ueberhaupt ein brauchbarer
 * Signierschluessel hinterlegt? Sie parst nur, sie importiert den Schluessel nicht - dafuer ist
 * ladeSignierschluessel zustaendig. Der Zweck ist ein anderer: der Betreiber soll VOR dem
 * Jahrgangsabschluss erfahren, dass ohne Schluessel kein Zeugnis ausgestellt wird, statt es die
 * Verwaltung beim ersten Ausstellen herausfinden zu lassen.
 */
export function signierschluesselBereit(env:{CERTIFICATE_SIGNING_JWK?:string}):boolean{
  try{
    const roh=safeString(env.CERTIFICATE_SIGNING_JWK,8000);
    if(!roh)return false;
    const jwk=JSON.parse(roh) as JwkAehnlich;
    return Boolean(jwk&&jwk.d&&verfahrenZuJwk(jwk));
  }catch{return false;}
}

function ohneBeweise(dokument:Nachweisdokument):Record<string,unknown>{const kopie:Record<string,unknown>={...dokument};delete kopie.proof;return kopie;}
function beweiskopf(beweis:Nachweisbeweis):Record<string,unknown>{const kopie:Record<string,unknown>={...beweis};delete kopie.signature;return kopie;}
/**
 * Die signierten Bytes. Signiert wird der Rumpf des Dokuments ZUSAMMEN mit dem Kopf der
 * Unterschrift - sonst koennte jemand "algorithm" oder "created" einer Unterschrift veraendern,
 * ohne sie zu brechen.
 */
export function signiereEingabe(dokument:Nachweisdokument,beweis:Nachweisbeweis):Uint8Array{
  return new TextEncoder().encode(kanonischesJson({document:ohneBeweise(dokument),proof:beweiskopf(beweis)}));
}

export function offlineGueltigBis(ausgestelltAm:string,tage=OFFLINE_GUELTIG_TAGE):string{
  const t=Date.parse(ausgestelltAm);
  const basis=Number.isFinite(t)?t:Date.now();
  return new Date(basis+tage*24*60*60*1000).toISOString();
}

export type NachweisEingabe={
  seriennummer:string;
  ausgestelltAm:string;
  ausstellerId:string;
  ausstellerName:string;
  betreiber:string|null;
  inhalt:Record<string,unknown>;
  widerrufslisteUrl:string|null;
  schluesselverzeichnisUrl:string|null;
};

/** Baut den unsignierten Rumpf. Alles, was zur Pruefung noetig ist, steht darin. */
export function baueNachweis(e:NachweisEingabe):Nachweisdokument{
  return{
    format:NACHWEIS_FORMAT,
    type:['VerifiableCredential','KlassenportalCertificate'],
    id:`urn:klassenportal:certificate:${e.seriennummer}`,
    issuer:{id:`urn:klassenportal:tenant:${e.ausstellerId}`,name:e.ausstellerName,operator:e.betreiber},
    validFrom:e.ausgestelltAm,
    credentialSubject:{...e.inhalt,serialNumber:e.seriennummer},
    status:{
      revocationList:e.widerrufslisteUrl,
      offlineValidUntil:offlineGueltigBis(e.ausgestelltAm),
      note:'Die Unterschrift belegt Echtheit und Unversehrtheit dauerhaft. Ob dieses Zeugnis spaeter widerrufen wurde, kann das Dokument selbst nicht wissen; das steht ausschliesslich in der Widerrufsliste. Nach offlineValidUntil lautet das ehrliche Ergebnis einer Pruefung ohne Liste: echt, Widerrufsstand unbekannt.',
    },
    keyDirectory:e.schluesselverzeichnisUrl,
    proof:[],
  };
}

/**
 * Haengt eine Unterschrift an. Bestehende Unterschriften bleiben stehen - genau das ist das
 * Nachsignieren: kommt in 30 Jahren ein staerkeres Verfahren, wird damit ein zweites Mal
 * unterschrieben, ohne den bisherigen Nachweis zu entwerten.
 */
export async function signiereNachweis(dokument:Nachweisdokument,schluessel:Signierschluessel,zweck='assertionMethod',jetzt=new Date().toISOString()):Promise<Nachweisdokument>{
  const v=verfahrenZuKennung(schluessel.algorithmus);
  if(!v)throw new Error('CERTIFICATE_CREDENTIAL_ALGORITHM_UNSUPPORTED');
  const beweis:Nachweisbeweis={
    algorithm:schluessel.algorithmus,
    keyId:schluessel.keyId,
    keyThumbprint:schluessel.fingerabdruck,
    created:jetzt,
    purpose:zweck,
    canonicalization:KANONISIERUNG,
    signature:'',
  };
  const roh=new Uint8Array(await crypto.subtle.sign(v.signatur,schluessel.privat,puffer(signiereEingabe(dokument,beweis))));
  return{...dokument,proof:[...(dokument.proof??[]),{...beweis,signature:b64url(roh)}]};
}

export type Schluesselverzeichnis=Array<{keyId:string;algorithm?:string;publicKeyJwk:JwkAehnlich;retiredAt?:string|null}>;
export type Unterschriftsbefund={algorithm:string;keyId:string;valid:boolean;reason:string|null};
export type Nachweisbefund={
  authentic:boolean;
  signatures:Unterschriftsbefund[];
  subject:Record<string,unknown>;
  serialNumber:string;
  issuer:{id:string;name:string;operator:string|null};
  validFrom:string;
  offlineValidUntil:string;
  offlineStatusFresh:boolean;
  revocationList:string|null;
  notes:string[];
};

/** Liest ein Dokument aus Text oder Objekt und prueft grob die Form. */
export function leseNachweis(roh:unknown):Nachweisdokument{
  let d:unknown=roh;
  if(typeof roh==='string'){try{d=JSON.parse(roh);}catch{throw new Error('CERTIFICATE_CREDENTIAL_INVALID');}}
  const dok=d as Nachweisdokument;
  if(!dok||typeof dok!=='object'||dok.format!==NACHWEIS_FORMAT||!Array.isArray(dok.proof)||!dok.credentialSubject||typeof dok.credentialSubject!=='object')throw new Error('CERTIFICATE_CREDENTIAL_INVALID');
  return dok;
}

/**
 * Die eigentliche Pruefung. Sie braucht KEINE Datenbank und keinen Server - nur das Dokument und
 * die oeffentlichen Schluessel. Genau darin liegt der Sinn: sie funktioniert auch dann noch, wenn
 * es den Mandanten und seine Zeile in certificate_records laengst nicht mehr gibt.
 *
 * verlangteAlgorithmen: welche Verfahren der Pruefer akzeptiert. Ohne diese Angabe genuegt eine
 * beliebige gueltige Unterschrift - das ist bequem, aber wer in 30 Jahren prueft, sollte
 * ausdruecklich sagen, welchem Verfahren er dann noch traut (siehe Kopf: Unterschriften lassen
 * sich abschneiden).
 */
export async function pruefeNachweis(roh:unknown,verzeichnis:Schluesselverzeichnis,optionen:{jetzt?:string;verlangteAlgorithmen?:string[]}={}):Promise<Nachweisbefund>{
  const dokument=leseNachweis(roh);
  const jetzt=optionen.jetzt??new Date().toISOString();
  const befunde:Unterschriftsbefund[]=[];
  for(const beweis of dokument.proof){
    const kennung=String(beweis?.algorithm||''),keyId=String(beweis?.keyId||'');
    const v=verfahrenZuKennung(kennung);
    if(!v){befunde.push({algorithm:kennung,keyId,valid:false,reason:'CERTIFICATE_CREDENTIAL_ALGORITHM_UNSUPPORTED'});continue;}
    const eintrag=verzeichnis.find(k=>k.keyId===keyId);
    if(!eintrag){befunde.push({algorithm:kennung,keyId,valid:false,reason:'CERTIFICATE_CREDENTIAL_KEY_UNKNOWN'});continue;}
    // Der Fingerabdruck im Dokument gegen den tatsaechlich vorgelegten Schluessel: sonst koennte
    // jemand unter derselben Kennung einen anderen Schluessel unterschieben.
    let fingerabdruck='';
    try{fingerabdruck=await schluesselFingerabdruck(eintrag.publicKeyJwk);}catch{/* unbekannter Schluesseltyp faellt unten auf */}
    if(!fingerabdruck||fingerabdruck!==String(beweis.keyThumbprint||'')){befunde.push({algorithm:kennung,keyId,valid:false,reason:'CERTIFICATE_CREDENTIAL_KEY_MISMATCH'});continue;}
    if(String(beweis.canonicalization||'')!==KANONISIERUNG){befunde.push({algorithm:kennung,keyId,valid:false,reason:'CERTIFICATE_CREDENTIAL_CANONICALIZATION_UNSUPPORTED'});continue;}
    let gueltig=false;
    try{
      const key=await crypto.subtle.importKey('jwk',{...eintrag.publicKeyJwk,key_ops:['verify'],ext:true} as JsonWebKey,v.einfuhr,true,['verify']);
      gueltig=await crypto.subtle.verify(v.signatur,key,puffer(ausB64url(String(beweis.signature||''))),puffer(signiereEingabe(dokument,beweis)));
    }catch{gueltig=false;}
    befunde.push({algorithm:kennung,keyId,valid:gueltig,reason:gueltig?null:'CERTIFICATE_CREDENTIAL_SIGNATURE_INVALID'});
  }
  const verlangt=optionen.verlangteAlgorithmen?.length?optionen.verlangteAlgorithmen:null;
  const authentic=befunde.some(b=>b.valid&&(!verlangt||verlangt.includes(b.algorithm)));
  const offlineBis=String(dokument.status?.offlineValidUntil||'');
  const frisch=Boolean(offlineBis)&&Date.parse(offlineBis)>Date.parse(jetzt);
  const hinweise:string[]=[];
  if(!authentic)hinweise.push('Keine der vorliegenden Unterschriften konnte bestaetigt werden.');
  if(authentic&&!frisch)hinweise.push('Die Unterschrift ist echt. Der Widerrufsstand ist ohne Blick in die Widerrufsliste nicht mehr aktuell.');
  if(verzeichnis.length===0)hinweise.push('Es lag kein oeffentlicher Schluessel vor.');
  return{
    authentic,
    signatures:befunde,
    subject:dokument.credentialSubject as Record<string,unknown>,
    serialNumber:String((dokument.credentialSubject as Record<string,unknown>).serialNumber||''),
    issuer:dokument.issuer,
    validFrom:dokument.validFrom,
    offlineValidUntil:offlineBis,
    offlineStatusFresh:frisch,
    revocationList:dokument.status?.revocationList??null,
    notes:hinweise,
  };
}

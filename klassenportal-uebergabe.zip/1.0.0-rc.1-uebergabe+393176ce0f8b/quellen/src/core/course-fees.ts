import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { hasPermission } from './enterprise-access.js';
import { stapelSchreiben } from './learning-operations.js';
import { requireCourseAccess } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Kleinbetraege einsammeln: "Exkursion, 24 EUR, faellig 15.10."
//
// Das ist ausdruecklich KEIN Zahlungsverkehr. Es wird nichts eingezogen, nichts an einen
// Dienstleister gemeldet und keine Zahlung ausgeloest; PAYMENTS_ENABLED bleibt unberuehrt. Das
// Modul haelt nur fest, wer wie viel schuldet und was davon von Hand als eingegangen eingetragen
// wurde - genau das, was die Klassenleitung heute auf einem Zettel fuehrt.
//
// Und es ist bewusst NICHT die Debitorenbuchhaltung aus accounting_*/commercial_*. Dort haengen
// Rechnungsnummer, Konto, Periode, Steuer und Mahnstufe an jedem Vorgang. Ein Kopiergeld von
// 3,50 EUR durch diesen Apparat zu schicken, wuerde den Periodenabschluss des Traegers von
// Klassenkassen abhaengig machen.

type Row=Record<string,unknown>;
type Collection={
  id:string;tenant_id:string;course_id:string;title:string;purpose:string|null;amount_cents:number;
  currency:string;due_date:string;status:'open'|'closed'|'cancelled';created_by:string;created_at:string;updated_at:string;
};

// Obergrenze fuer einen einzelnen Beitrag. Sie ist die Grenze zur Debitorenbuchhaltung: was
// darueber liegt, ist keine Klassenkasse mehr, sondern ein Entgelt und gehoert auf eine Rechnung.
const BETRAG_MAX_CENT=50000;
const METHODEN=new Set(['cash','transfer','other']);

function tenantAdmin(auth:CoreAuthContext){return auth.isPlatformAdmin||auth.role==='tenant_admin';}
function pflicht(v:unknown,fehler:string,max=200){const s=safeString(v,max);if(!s)throw new Error(fehler);return s;}
function optional(v:unknown,max=1000){return safeString(v,max)||null;}
function datum(v:unknown,fehler:string){
  const s=safeString(v,10);
  if(!s||!/^\d{4}-\d\d-\d\d$/.test(s)||Number.isNaN(Date.parse(`${s}T00:00:00.000Z`)))throw new Error(fehler);
  return s;
}
// Betraege sind ganzzahlige Cent. Number.isInteger weist 24.5 ebenso ab wie "24,50" - beides
// waere sonst als 24 in der Kasse gelandet und die Differenz haette niemand mehr gefunden.
function centBetrag(v:unknown,fehler:string){
  const n=typeof v==='number'?v:Number(safeString(v,20));
  if(!Number.isInteger(n)||n<=0)throw new Error(fehler);
  return n;
}
// Anzeige aus ganzen Cent, ohne je durch 100 zu teilen. Eine Division waere hier zwar harmlos,
// aber sie ist der Anfang jeder Rundungsgeschichte - und Kundentexte werden kopiert.
function alsEuro(cent:number,waehrung='EUR'){
  const v=Math.abs(Math.trunc(cent));
  return `${cent<0?'-':''}${Math.trunc(v/100)},${String(v%100).padStart(2,'0')} ${waehrung}`;
}
function alsTag(iso:string){const [j,m,t]=iso.split('-');return `${t}.${m}.${j}`;}

// Wer eine Sammlung fuehrt: die Verwaltung traegerweit, sonst die Verantwortliche IN DIESEM Kurs.
// auth.role waere hier falsch - das ist die hoechste Rolle ueber alle Kurse. Wer in Klasse A
// verantwortlich und in Klasse B nur Teilnehmer ist, koennte damit die Kasse der Klasse B fuehren.
function darfVerwalten(auth:CoreAuthContext,courseId:string){
  if(tenantAdmin(auth)||hasPermission(auth,'courses.manage'))return true;
  try{requireCourseAccess(auth,courseId,'class_admin');return true;}catch{return false;}
}
function assertVerwalten(auth:CoreAuthContext,courseId:string){
  if(!darfVerwalten(auth,courseId))throw new Error('FORBIDDEN_FEE_MANAGE');
}
// Wer eine Sammlung ueberhaupt sehen darf: die Verantwortlichen und die Betroffenen des Kurses.
function assertSehen(auth:CoreAuthContext,courseId:string){
  if(darfVerwalten(auth,courseId))return;
  try{requireCourseAccess(auth,courseId,'participant');}catch{throw new Error('FORBIDDEN_FEE_VIEW');}
}

// Jede vom Client gelieferte Kennung wird gegen den Mandanten geprueft, nie geglaubt. Ohne diese
// Zeile reichte eine fremde Sammlungskennung, um die Kasse eines anderen Traegers zu lesen.
async function ladeSammlung(env:Env,tenantId:string,collectionId:string):Promise<Collection>{
  const row=await env.DB.prepare('SELECT * FROM course_fee_collections WHERE tenant_id=? AND id=?')
    .bind(tenantId,collectionId).first<Row>();
  if(!row)throw new Error('FEE_COLLECTION_NOT_FOUND');
  return row as unknown as Collection;
}

/** Die Sammlungen eines Mandanten. Verantwortliche sehen den Stand der Kasse, Betroffene ihren eigenen. */
export async function listFeeCollections(env:Env,auth:CoreAuthContext,tenantId:string,courseId?:string){
  if(courseId)assertSehen(auth,courseId);
  // Zwei ausgeschriebene Anweisungen statt einer zusammengesetzten: nur so laesst sich jede von
  // ihnen gegen das echte Schema vorbereiten (tests/sql-schema-contract.mjs).
  const rows=courseId
    ?((await env.DB.prepare(
      `SELECT c.id,c.course_id,c.title,c.purpose,c.amount_cents,c.currency,c.due_date,c.status,c.created_at,k.name course_name,
              (SELECT COUNT(*) FROM course_fee_shares s WHERE s.tenant_id=c.tenant_id AND s.collection_id=c.id) share_count,
              (SELECT COALESCE(SUM(s.amount_cents),0) FROM course_fee_shares s WHERE s.tenant_id=c.tenant_id AND s.collection_id=c.id) due_cents,
              (SELECT COALESCE(SUM(p.amount_cents),0) FROM course_fee_payments p JOIN course_fee_shares s ON s.id=p.share_id
                WHERE s.tenant_id=c.tenant_id AND s.collection_id=c.id) paid_cents
         FROM course_fee_collections c JOIN courses k ON k.id=c.course_id AND k.tenant_id=c.tenant_id
        WHERE c.tenant_id=? AND c.course_id=?
        ORDER BY c.due_date DESC, c.created_at DESC`
    ).bind(tenantId,courseId).all<Row>()).results)??[]
    :((await env.DB.prepare(
      `SELECT c.id,c.course_id,c.title,c.purpose,c.amount_cents,c.currency,c.due_date,c.status,c.created_at,k.name course_name,
              (SELECT COUNT(*) FROM course_fee_shares s WHERE s.tenant_id=c.tenant_id AND s.collection_id=c.id) share_count,
              (SELECT COALESCE(SUM(s.amount_cents),0) FROM course_fee_shares s WHERE s.tenant_id=c.tenant_id AND s.collection_id=c.id) due_cents,
              (SELECT COALESCE(SUM(p.amount_cents),0) FROM course_fee_payments p JOIN course_fee_shares s ON s.id=p.share_id
                WHERE s.tenant_id=c.tenant_id AND s.collection_id=c.id) paid_cents
         FROM course_fee_collections c JOIN courses k ON k.id=c.course_id AND k.tenant_id=c.tenant_id
        WHERE c.tenant_id=?
        ORDER BY c.due_date DESC, c.created_at DESC`
    ).bind(tenantId).all<Row>()).results)??[];
  // Die Sichtbarkeit haengt an der Rolle IN DEM Kurs, zu dem die Sammlung gehoert. Eine
  // Kassenliste ueber alle Kurse ist sonst genau das Leck, das requireCourseAccess verhindert.
  return rows
    .filter(r=>darfVerwalten(auth,String(r.course_id))||sichtbarAlsBetroffener(auth,String(r.course_id)))
    .map(r=>{
      const faellig=Number(r.due_cents||0),bezahlt=Number(r.paid_cents||0);
      return{...r,open_cents:faellig-bezahlt,can_manage:darfVerwalten(auth,String(r.course_id))};
    });
}
function sichtbarAlsBetroffener(auth:CoreAuthContext,courseId:string){
  try{requireCourseAccess(auth,courseId,'participant');return true;}catch{return false;}
}

/** Eine Sammlung anlegen. Alle Betroffenen des Kurses bekommen sofort ihren Anteil und eine Mitteilung. */
export async function createFeeCollection(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  const courseId=pflicht(input.course_id,'FEE_COURSE_REQUIRED',120);
  // Erst gegen den Mandanten pruefen, dann gegen die Rolle: eine Kurskennung aus einem fremden
  // Mandanten darf nicht einmal die Rollenpruefung erreichen.
  const kurs=await env.DB.prepare('SELECT id,name FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,courseId).first<{id:string;name:string}>();
  if(!kurs)throw new Error('COURSE_NOT_FOUND');
  assertVerwalten(auth,courseId);
  const title=pflicht(input.title,'FEE_TITLE_REQUIRED',200);
  const purpose=optional(input.purpose,1000);
  const amount=centBetrag(input.amount_cents,'FEE_AMOUNT_INVALID');
  if(amount>BETRAG_MAX_CENT)throw new Error('FEE_AMOUNT_TOO_HIGH');
  const dueDate=datum(input.due_date,'FEE_DUE_DATE_INVALID');

  const betroffene=((await env.DB.prepare(
    `SELECT DISTINCT user_id FROM memberships WHERE tenant_id=? AND course_id=? AND role='participant'`
  ).bind(tenantId,courseId).all<{user_id:string}>()).results)??[];
  if(!betroffene.length)throw new Error('FEE_NO_PARTICIPANTS');

  const collectionId=id('cfc_'),ts=nowIso();
  const anweisungen:unknown[]=[env.DB.prepare(
    `INSERT INTO course_fee_collections(id,tenant_id,course_id,title,purpose,amount_cents,currency,due_date,status,created_by,created_at,updated_at)
     VALUES(?,?,?,?,?,?,'EUR',?,'open',?,?,?)`
  ).bind(collectionId,tenantId,courseId,title,purpose,amount,dueDate,auth.userId,ts,ts)];
  const text=`${title}: ${alsEuro(amount)}, fällig am ${alsTag(dueDate)}.`;
  for(const {user_id:userId} of betroffene){
    anweisungen.push(env.DB.prepare(
      'INSERT INTO course_fee_shares(id,tenant_id,collection_id,user_id,amount_cents,created_at,updated_at) VALUES(?,?,?,?,?,?,?)'
    ).bind(id('cfs_'),tenantId,collectionId,userId,amount,ts,ts));
    anweisungen.push(env.DB.prepare(
      'INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,?,?,?,?,?,?)'
    ).bind(id('ntf_'),tenantId,courseId,userId,'course_fee','Beitrag für die Klasse',text,ts));
  }
  await stapelSchreiben(env,anweisungen as any[]);
  await audit(env.DB,auth.userId,'course_fee.created',tenantId,courseId,'course_fee_collection',collectionId,{amount_cents:amount,shares:betroffene.length});
  return{collectionId,shares:betroffene.length,amountCents:amount,dueDate,title,courseName:kurs.name};
}

/** Der Stand einer Sammlung: wer bezahlt hat und wer noch offen ist. */
export async function feeCollectionDetail(env:Env,auth:CoreAuthContext,tenantId:string,collectionId:string){
  const c=await ladeSammlung(env,tenantId,collectionId);
  assertSehen(auth,c.course_id);
  const verwaltet=darfVerwalten(auth,c.course_id);
  const rows=((await env.DB.prepare(
    `SELECT s.id,s.user_id,s.amount_cents,u.display_name,u.email,
            (SELECT COALESCE(SUM(p.amount_cents),0) FROM course_fee_payments p WHERE p.tenant_id=s.tenant_id AND p.share_id=s.id) paid_cents
       FROM course_fee_shares s JOIN users u ON u.id=s.user_id
      WHERE s.tenant_id=? AND s.collection_id=?
      ORDER BY u.display_name`
  ).bind(tenantId,collectionId).all<Row>()).results)??[];
  // Eine betroffene Person sieht ihren eigenen Anteil - nicht, wer sonst noch nicht bezahlt hat.
  // Der Zahlungsstand der Mitschueler ist eine soziale Information, keine Kassenauskunft.
  const sichtbar=verwaltet?rows:rows.filter(r=>String(r.user_id)===auth.userId);
  const anteile=sichtbar.map(r=>{
    const soll=Number(r.amount_cents||0),ist=Number(r.paid_cents||0);
    return{...r,open_cents:soll-ist,settled:ist>=soll};
  });
  const dueCents=rows.reduce((s,r)=>s+Number(r.amount_cents||0),0);
  const paidCents=rows.reduce((s,r)=>s+Number(r.paid_cents||0),0);
  return{
    collection:{...c,can_manage:verwaltet},
    shares:anteile,
    summary:{shareCount:rows.length,dueCents,paidCents,openCents:dueCents-paidCents,
      openShares:rows.filter(r=>Number(r.paid_cents||0)<Number(r.amount_cents||0)).length},
  };
}

/** Einen Zahlungseingang eintragen. Handarbeit der Leitung, kein Zahlungsverkehr. */
export async function recordFeePayment(env:Env,auth:CoreAuthContext,tenantId:string,collectionId:string,input:Row){
  const c=await ladeSammlung(env,tenantId,collectionId);
  assertVerwalten(auth,c.course_id);
  if(c.status!=='open')throw new Error('FEE_COLLECTION_NOT_OPEN');
  const shareId=pflicht(input.share_id,'FEE_SHARE_REQUIRED',120);
  // Der Anteil muss zu DIESEM Mandanten UND zu DIESER Sammlung gehoeren. Ohne die zweite
  // Bedingung liesse sich mit einer fremden Anteilskennung in eine Kasse einzahlen, fuer die der
  // Aufrufer gerade keine Rolle hat.
  const share=await env.DB.prepare('SELECT id,user_id,amount_cents FROM course_fee_shares WHERE tenant_id=? AND id=? AND collection_id=?')
    .bind(tenantId,shareId,collectionId).first<{id:string;user_id:string;amount_cents:number}>();
  if(!share)throw new Error('FEE_SHARE_NOT_FOUND');
  const amount=centBetrag(input.amount_cents,'FEE_PAYMENT_AMOUNT_INVALID');
  const receivedOn=input.received_on?datum(input.received_on,'FEE_RECEIVED_DATE_INVALID'):nowIso().slice(0,10);
  const method=safeString(input.method,20)||'cash';
  if(!METHODEN.has(method))throw new Error('FEE_PAYMENT_METHOD_INVALID');
  const note=optional(input.note,500);

  const bisher=Number((await env.DB.prepare('SELECT COALESCE(SUM(amount_cents),0) summe FROM course_fee_payments WHERE tenant_id=? AND share_id=?')
    .bind(tenantId,shareId).first<{summe:number}>())?.summe??0);
  // Mehr als geschuldet ergibt eine Kasse, die nicht stimmt. Der haeufigste Weg dorthin ist ein
  // Tippfehler: 2400 statt 24. Die Datenbank haelt dieselbe Regel noch einmal (Trigger in 0111),
  // fuer den Fall, dass zwei Verantwortliche gleichzeitig eintragen.
  if(bisher+amount>Number(share.amount_cents))throw new Error('FEE_PAYMENT_EXCEEDS_SHARE');

  const paymentId=id('cfp_'),ts=nowIso();
  await env.DB.prepare(
    'INSERT INTO course_fee_payments(id,tenant_id,share_id,amount_cents,received_on,method,note,recorded_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)'
  ).bind(paymentId,tenantId,shareId,amount,receivedOn,method,note,auth.userId,ts).run();
  await audit(env.DB,auth.userId,'course_fee.payment_recorded',tenantId,c.course_id,'course_fee_payment',paymentId,{share_id:shareId,amount_cents:amount});
  const paid=bisher+amount;
  return{paymentId,shareId,paidCents:paid,openCents:Number(share.amount_cents)-paid,settled:paid>=Number(share.amount_cents)};
}

/** Einen falsch eingetragenen Eingang zuruecknehmen. */
export async function deleteFeePayment(env:Env,auth:CoreAuthContext,tenantId:string,paymentId:string){
  const row=await env.DB.prepare(
    `SELECT p.id,p.share_id,p.amount_cents,c.course_id,c.id collection_id
       FROM course_fee_payments p
       JOIN course_fee_shares s ON s.id=p.share_id AND s.tenant_id=p.tenant_id
       JOIN course_fee_collections c ON c.id=s.collection_id AND c.tenant_id=p.tenant_id
      WHERE p.tenant_id=? AND p.id=?`
  ).bind(tenantId,paymentId).first<{id:string;share_id:string;amount_cents:number;course_id:string;collection_id:string}>();
  if(!row)throw new Error('FEE_PAYMENT_NOT_FOUND');
  assertVerwalten(auth,row.course_id);
  await env.DB.prepare('DELETE FROM course_fee_payments WHERE tenant_id=? AND id=?').bind(tenantId,paymentId).run();
  await audit(env.DB,auth.userId,'course_fee.payment_removed',tenantId,row.course_id,'course_fee_payment',paymentId,{share_id:row.share_id,amount_cents:row.amount_cents});
  return{paymentId,collectionId:row.collection_id};
}

/** Eine Sammlung abschliessen oder zuruecknehmen. */
export async function setFeeCollectionStatus(env:Env,auth:CoreAuthContext,tenantId:string,collectionId:string,input:Row){
  const c=await ladeSammlung(env,tenantId,collectionId);
  assertVerwalten(auth,c.course_id);
  const status=safeString(input.status,20);
  if(!['open','closed','cancelled'].includes(status))throw new Error('FEE_STATUS_INVALID');
  const ts=nowIso();
  await env.DB.prepare('UPDATE course_fee_collections SET status=?,updated_at=? WHERE tenant_id=? AND id=?')
    .bind(status,ts,tenantId,collectionId).run();
  await audit(env.DB,auth.userId,'course_fee.status_changed',tenantId,c.course_id,'course_fee_collection',collectionId,{status});
  return{collectionId,status};
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { hasPermission } from './enterprise-access.js';
import { stapelSchreiben } from './learning-operations.js';
import { requireCourseAccess } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Sprechtag und Beratungsgespraech: die Familie bucht sich ihr Zeitfenster selbst.
//
// Das Raster wird NICHT neu erfunden. Es entsteht aus dem, was das Portal schon fuehrt:
// teacher_availability (wann jemand arbeiten moechte), teacher_unavailability (wann jemand an
// diesem Tag ausfaellt) und planning_blackouts (wann der Traeger zu hat). Dieses Modul fuegt nur
// hinzu, was es bisher nirgends gab: die Veranstaltung, das gebuchte Fenster und die zwei Regeln,
// an denen ein Sprechtag sonst scheitert - kein Fenster zweimal, und keine Familie zur selben
// Minute bei zwei Dozenten.

type Row=Record<string,unknown>;
type ConsultationDay={
  id:string;tenant_id:string;course_id:string|null;title:string;event_date:string;starts_time:string;ends_time:string;
  slot_minutes:number;break_minutes:number;location:string|null;booking_opens_at:string|null;booking_closes_at:string|null;
  max_bookings_per_user:number;status:'draft'|'open'|'closed';
};

const SLOTS_MAX_PER_DAY=2000;

function tenantAdmin(auth:CoreAuthContext){return auth.isPlatformAdmin||auth.role==='tenant_admin';}
function required(v:unknown,max=400){const s=safeString(v,max);if(!s)throw new Error('FIELD_REQUIRED');return s;}
function optional(v:unknown,max=2000){return safeString(v,max)||null;}
function datum(v:unknown){const s=safeString(v,10);if(!s||!/^\d{4}-\d\d-\d\d$/.test(s)||Number.isNaN(Date.parse(`${s}T00:00:00.000Z`)))throw new Error('CONSULTATION_DAY_DATE_INVALID');return s;}
function uhrzeit(v:unknown){const s=safeString(v,5);if(!s||!/^([01]\d|2[0-3]):[0-5]\d$/.test(s))throw new Error('CONSULTATION_DAY_TIME_INVALID');return s;}
function zeitpunkt(v:unknown,fehler:string){const s=safeString(v,50);if(!s)return null;const d=new Date(s);if(Number.isNaN(d.getTime()))throw new Error(fehler);return d.toISOString();}
function minuten(startsAt:string,endsAt:string){return Math.round((Date.parse(endsAt)-Date.parse(startsAt))/60000);}
function ueberschneidet(aVon:string,aBis:string,bVon:string,bBis:string){return aVon<bBis&&bVon<aBis;}

// Die Zeitachse des Portals ist ueberall dieselbe: ein Kalendertag plus Wanduhrzeit ergibt einen
// ISO-Zeitpunkt. teacher_availability wird in planning-constraints genauso gelesen (Wochentag und
// Uhrzeit aus dem UTC-Anteil). Wer hier umrechnete, wuerde ein Raster erzeugen, das gegen die
// zugesagten Arbeitszeiten geprueft nicht mehr passt.
function zeitpunktAusTag(datumText:string,zeit:string){return `${datumText}T${zeit}:00.000Z`;}
function alsMinuten(zeit:string){return Number(zeit.slice(0,2))*60+Number(zeit.slice(3,5));}
function wochentag(datumText:string){const d=new Date(`${datumText}T00:00:00.000Z`);return((d.getUTCDay()+6)%7)+1;}

async function ladeTag(env:Env,tenantId:string,dayId:string):Promise<ConsultationDay>{
  const row=await env.DB.prepare('SELECT * FROM consultation_days WHERE tenant_id=? AND id=?').bind(tenantId,dayId).first<Row>();
  if(!row)throw new Error('CONSULTATION_DAY_NOT_FOUND');
  return row as unknown as ConsultationDay;
}

// Wer den Sprechtag baut. Traegerweit entscheidet die Mandantenrolle; haengt der Sprechtag an
// einer Klasse, entscheidet die Rolle IN DIESER Klasse. auth.role waere hier falsch: das ist die
// hoechste Rolle ueber alle Kurse - eine Klassenverantwortliche der Klasse A koennte damit den
// Sprechtag der Klasse B umbauen, indem sie course_id einfach weglaesst.
function assertManage(auth:CoreAuthContext,courseId:string|null){
  if(tenantAdmin(auth)||hasPermission(auth,'courses.manage'))return;
  if(!courseId)throw new Error('FORBIDDEN_CONSULTATION_MANAGE');
  try{requireCourseAccess(auth,courseId,'class_admin');}
  catch{throw new Error('FORBIDDEN_CONSULTATION_MANAGE');}
}

// Wer buchen darf. Bei einem Sprechtag einer Klasse muss der Buchende in GENAU DIESER Klasse sein.
function assertBookingAccess(auth:CoreAuthContext,courseId:string|null){
  if(tenantAdmin(auth)||hasPermission(auth,'courses.manage'))return;
  if(!courseId)return;
  try{requireCourseAccess(auth,courseId,'participant');}
  catch{throw new Error('FORBIDDEN_CONSULTATION_BOOKING');}
}

// Der Laufzettel gehoert der betreffenden Person selbst - oder der Verwaltung. Dieselbe Zuordnung
// wie bei den Arbeitszeiten: teacher_portal_assignments verbindet Konto und Dozentendatensatz.
async function assertRunSheetAccess(env:Env,auth:CoreAuthContext,tenantId:string,teacherId:string,courseId:string|null){
  if(tenantAdmin(auth)||hasPermission(auth,'courses.manage'))return;
  const eigen=await env.DB.prepare(`SELECT 1 ok FROM teacher_portal_assignments WHERE tenant_id=? AND teacher_id=? AND user_id=? AND status='active' LIMIT 1`).bind(tenantId,teacherId,auth.userId).first();
  if(eigen)return;
  if(courseId){try{requireCourseAccess(auth,courseId,'class_admin');return;}catch{/* faellt unten durch */}}
  throw new Error('FORBIDDEN_CONSULTATION_RUN_SHEET');
}

export async function saveConsultationDay(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  const dayId=safeString(input.id,120)||'';
  // Eine vom Client gelieferte Kurskennung wird nie geglaubt: sie muss zu DIESEM Mandanten
  // gehoeren. Sonst haengte ein Sprechtag an einer fremden Klasse, und die Rollenpruefung unten
  // liefe gegen einen Kurs, den der Aufrufer in seiner Sitzung gar nicht hat.
  const courseId=safeString(input.course_id,120)||null;
  if(courseId&&!await env.DB.prepare('SELECT 1 ok FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,courseId).first())throw new Error('COURSE_NOT_FOUND');
  assertManage(auth,courseId);

  const eventDate=datum(input.event_date),start=uhrzeit(input.starts_time),ende=uhrzeit(input.ends_time);
  if(alsMinuten(start)>=alsMinuten(ende))throw new Error('CONSULTATION_DAY_TIME_INVALID');
  const slotMinutes=Math.trunc(Number(input.slot_minutes));
  if(!Number.isFinite(slotMinutes)||slotMinutes<5||slotMinutes>120)throw new Error('CONSULTATION_SLOT_MINUTES_INVALID');
  const breakMinutes=input.break_minutes===undefined||input.break_minutes===null||input.break_minutes===''?0:Math.trunc(Number(input.break_minutes));
  if(!Number.isFinite(breakMinutes)||breakMinutes<0||breakMinutes>60)throw new Error('CONSULTATION_BREAK_MINUTES_INVALID');
  if(alsMinuten(start)+slotMinutes>alsMinuten(ende))throw new Error('CONSULTATION_SLOT_MINUTES_INVALID');
  const oeffnet=zeitpunkt(input.booking_opens_at,'CONSULTATION_BOOKING_WINDOW_INVALID'),schliesst=zeitpunkt(input.booking_closes_at,'CONSULTATION_BOOKING_WINDOW_INVALID');
  if(oeffnet&&schliesst&&oeffnet>schliesst)throw new Error('CONSULTATION_BOOKING_WINDOW_INVALID');
  const status=String(input.status||'draft');
  if(!['draft','open','closed'].includes(status))throw new Error('CONSULTATION_DAY_STATUS_INVALID');
  const grenze=input.max_bookings_per_user===undefined||input.max_bookings_per_user===null||input.max_bookings_per_user===''?0:Math.trunc(Number(input.max_bookings_per_user));
  if(!Number.isFinite(grenze)||grenze<0)throw new Error('CONSULTATION_BOOKING_LIMIT_INVALID');
  const titel=required(input.title,300),ort=optional(input.location,300),ts=nowIso();

  if(dayId){
    const alt=await ladeTag(env,tenantId,dayId);
    // Auch fuer den BISHERIGEN Kurs muss die Berechtigung bestehen, sonst liesse sich ein fremder
    // Sprechtag uebernehmen, indem man ihn auf die eigene Klasse umschreibt.
    assertManage(auth,alt.course_id);
    await env.DB.prepare('UPDATE consultation_days SET course_id=?,title=?,event_date=?,starts_time=?,ends_time=?,slot_minutes=?,break_minutes=?,location=?,booking_opens_at=?,booking_closes_at=?,max_bookings_per_user=?,status=?,updated_at=? WHERE tenant_id=? AND id=?')
      .bind(courseId,titel,eventDate,start,ende,slotMinutes,breakMinutes,ort,oeffnet,schliesst,grenze,status,ts,tenantId,dayId).run();
    await audit(env.DB,auth.userId,'consultation.day_updated',tenantId,courseId??undefined,'consultation_day',dayId,{status,eventDate});
    return{consultation_day_id:dayId};
  }
  const neu=id('cnd_');
  await env.DB.prepare('INSERT INTO consultation_days(id,tenant_id,course_id,title,event_date,starts_time,ends_time,slot_minutes,break_minutes,location,booking_opens_at,booking_closes_at,max_bookings_per_user,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(neu,tenantId,courseId,titel,eventDate,start,ende,slotMinutes,breakMinutes,ort,oeffnet,schliesst,grenze,status,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'consultation.day_created',tenantId,courseId??undefined,'consultation_day',neu,{status,eventDate});
  return{consultation_day_id:neu};
}

// Was der Aufrufer sehen darf: die Verwaltung alles, alle anderen nur, was offen ist und was zu
// ihren eigenen Kursen gehoert. Ein Entwurf ('draft') ist bewusst unsichtbar, sonst buchten Eltern
// in ein Raster, das noch gar nicht steht.
export async function listConsultationDays(env:Env,auth:CoreAuthContext,tenantId:string,courseId?:string){
  const gefiltert=safeString(courseId,120)||'';
  const verwaltet=tenantAdmin(auth)||hasPermission(auth,'courses.manage');
  const eigeneKurse=auth.courseIds??[];
  const bedingungen:string[]=['d.tenant_id=?'],werte:unknown[]=[tenantId];
  if(gefiltert){bedingungen.push('d.course_id=?');werte.push(gefiltert);}
  if(!verwaltet){
    bedingungen.push(`d.status<>'draft'`);
    // Ein traegerweiter Sprechtag (course_id IS NULL) steht allen Mitgliedern offen; ein
    // klassenbezogener nur der eigenen Klasse. Ohne Kurs in der Sitzung bleibt nur der erste Fall.
    if(eigeneKurse.length){bedingungen.push(`(d.course_id IS NULL OR d.course_id IN (${eigeneKurse.map(()=>'?').join(',')}))`);werte.push(...eigeneKurse);}
    else bedingungen.push('d.course_id IS NULL');
  }
  const sql=`SELECT d.*,c.name course_name,
    (SELECT COUNT(*) FROM consultation_slots s WHERE s.tenant_id=d.tenant_id AND s.consultation_day_id=d.id) slot_count,
    (SELECT COUNT(*) FROM consultation_bookings b WHERE b.tenant_id=d.tenant_id AND b.consultation_day_id=d.id AND b.status='booked') booked_count
    FROM consultation_days d LEFT JOIN courses c ON c.id=d.course_id AND c.tenant_id=d.tenant_id
    WHERE ${bedingungen.join(' AND ')} ORDER BY d.event_date DESC,d.starts_time LIMIT 200`;
  return((await env.DB.prepare(sql).bind(...werte).all<Row>()).results)??[];
}

/**
 * Erzeugt das Raster aus den vorhandenen Planungsdaten - es wird nichts doppelt gepflegt.
 *
 * Je Dozent gilt: liegen zugesagte Arbeitszeiten vor, entstehen Fenster NUR darin. Liegt keine
 * einzige Zusage vor, gilt das ganze Zeitfenster des Sprechtags. Das ist dieselbe Opt-in-Regel wie
 * in 0095 - wuerde "keine Zusage" hier als "nicht verfuegbar" gelten, koennte ein Traeger, der die
 * Arbeitszeiten nie gepflegt hat, gar keinen Sprechtag anlegen.
 *
 * Abwesenheiten und Schliesszeiten schneiden Fenster heraus, statt sie zu verschieben: ein
 * verschobenes Fenster stuende nicht mehr im Raster, und der Laufzettel waere nicht mehr lesbar.
 */
export async function generateConsultationSlots(env:Env,auth:CoreAuthContext,tenantId:string,dayId:string,input:Row){
  const tag=await ladeTag(env,tenantId,dayId);
  assertManage(auth,tag.course_id);

  const gewuenscht=Array.isArray(input.teacher_ids)?input.teacher_ids.map(x=>safeString(x,120)).filter(Boolean):[];
  const alle=((await env.DB.prepare('SELECT id,name FROM teachers WHERE tenant_id=? ORDER BY name').bind(tenantId).all<{id:string;name:string}>()).results)??[];
  const bekannt=new Map(alle.map(t=>[t.id,t.name]));
  // Jede vom Client gelieferte Dozentenkennung gegen den Mandanten pruefen. Ohne das liesse sich
  // ueber eine geratene Kennung ein Fenster fuer eine Person eines fremden Mandanten anlegen.
  for(const t of gewuenscht)if(!bekannt.has(t))throw new Error('TEACHER_NOT_FOUND');
  const dozenten=gewuenscht.length?gewuenscht:alle.map(t=>t.id);
  if(!dozenten.length)throw new Error('CONSULTATION_NO_TEACHERS');

  const tagBeginn=zeitpunktAusTag(tag.event_date,tag.starts_time),tagEnde=zeitpunktAusTag(tag.event_date,tag.ends_time);
  const [zusagen,abwesend,sperren]=await Promise.all([
    env.DB.prepare('SELECT teacher_id,weekday,starts_time,ends_time,valid_from,valid_until FROM teacher_availability WHERE tenant_id=?').bind(tenantId).all<Row>(),
    env.DB.prepare('SELECT teacher_id,starts_at,ends_at FROM teacher_unavailability WHERE tenant_id=? AND starts_at<? AND ends_at>?').bind(tenantId,tagEnde,tagBeginn).all<Row>(),
    env.DB.prepare('SELECT course_id,starts_at,ends_at FROM planning_blackouts WHERE tenant_id=? AND blocks_teaching=1 AND starts_at<? AND ends_at>?').bind(tenantId,tagEnde,tagBeginn).all<Row>(),
  ]);
  const hatZusage=new Set<string>(),fensterJeDozent=new Map<string,Array<[number,number]>>();
  const wochentagDesTages=wochentag(tag.event_date);
  for(const z of zusagen.results??[]){
    const teacherId=String(z.teacher_id);hatZusage.add(teacherId);
    if(Number(z.weekday)!==wochentagDesTages)continue;
    const von=z.valid_from?String(z.valid_from):null,bis=z.valid_until?String(z.valid_until):null;
    if(von&&tag.event_date<von)continue;
    if(bis&&tag.event_date>bis)continue;
    const liste=fensterJeDozent.get(teacherId)??[];
    liste.push([alsMinuten(String(z.starts_time)),alsMinuten(String(z.ends_time))]);
    fensterJeDozent.set(teacherId,liste);
  }
  const abwesenheit=new Map<string,Array<[string,string]>>();
  for(const a of abwesend.results??[]){const k=String(a.teacher_id),l=abwesenheit.get(k)??[];l.push([String(a.starts_at),String(a.ends_at)]);abwesenheit.set(k,l);}
  const geschlossen:Array<[string,string]>=[];
  for(const s of sperren.results??[]){
    const kurs=s.course_id?String(s.course_id):null;
    // Eine Sperrzeit einer anderen Klasse geht diesen Sprechtag nichts an.
    if(kurs&&kurs!==tag.course_id)continue;
    geschlossen.push([String(s.starts_at),String(s.ends_at)]);
  }

  const anlegen:Array<{teacherId:string;startsAt:string;endsAt:string}>=[];
  const uebersprungen:Array<{teacher_id:string;teacher_name:string;grund:string}>=[];
  const tagVon=alsMinuten(tag.starts_time),tagBis=alsMinuten(tag.ends_time),schritt=tag.slot_minutes+tag.break_minutes;
  for(const teacherId of dozenten){
    const zusagenDesTages=fensterJeDozent.get(teacherId)??[];
    if(hatZusage.has(teacherId)&&!zusagenDesTages.length){uebersprungen.push({teacher_id:teacherId,teacher_name:String(bekannt.get(teacherId)||''),grund:'keine zugesagte Arbeitszeit an diesem Tag'});continue;}
    const fenster=zusagenDesTages.length?zusagenDesTages:[[tagVon,tagBis] as [number,number]];
    let erzeugt=0;
    for(const [fVon,fBis] of fenster){
      const von=Math.max(tagVon,fVon),bis=Math.min(tagBis,fBis);
      for(let cursor=von;cursor+tag.slot_minutes<=bis;cursor+=schritt){
        const startsAt=zeitpunktAusTag(tag.event_date,`${String(Math.floor(cursor/60)).padStart(2,'0')}:${String(cursor%60).padStart(2,'0')}`);
        const endsAt=new Date(Date.parse(startsAt)+tag.slot_minutes*60000).toISOString();
        if((abwesenheit.get(teacherId)??[]).some(([aVon,aBis])=>ueberschneidet(startsAt,endsAt,aVon,aBis)))continue;
        if(geschlossen.some(([gVon,gBis])=>ueberschneidet(startsAt,endsAt,gVon,gBis)))continue;
        anlegen.push({teacherId,startsAt,endsAt});erzeugt++;
      }
    }
    if(!erzeugt&&!uebersprungen.some(x=>x.teacher_id===teacherId))uebersprungen.push({teacher_id:teacherId,teacher_name:String(bekannt.get(teacherId)||''),grund:'an diesem Tag durchgehend abwesend oder gesperrt'});
  }
  if(!anlegen.length)throw new Error('CONSULTATION_NO_SLOTS_POSSIBLE');
  // Eine Rasterweite von 5 Minuten ueber zwoelf Stunden und hundert Dozenten waere ein
  // Schreibauftrag ueber Zehntausende Zeilen. Lieber ein klarer Satz als eine Zeitueberschreitung.
  if(anlegen.length>SLOTS_MAX_PER_DAY)throw new Error('CONSULTATION_SLOTS_TOO_MANY');

  const ts=nowIso();
  // Bereits gebuchte Fenster bleiben stehen. Wer das Raster nachtraeglich erweitert, darf damit
  // nicht die Buchungen der Familien loeschen - deshalb wird nur ergaenzt, was noch fehlt.
  //
  // Gefragt wird ueber ALLE Sprechtage dieses Kalendertages, nicht nur ueber diesen: laufen die
  // Sprechtage zweier Klassen am selben Abend mit unterschiedlicher Rasterweite, beansprucht der
  // eine schon eine Minute, die der andere gerade belegen wollte. Ohne diese Abfrage liefe der
  // eindeutige Schluessel der Tabelle auf einen rohen Datenbankfehler mitten im Schreiben.
  const vorhanden=new Set(((await env.DB.prepare(`SELECT s.teacher_id,s.starts_at FROM consultation_slots s
      JOIN consultation_days d ON d.id=s.consultation_day_id AND d.tenant_id=s.tenant_id
      WHERE s.tenant_id=? AND d.event_date=?`).bind(tenantId,tag.event_date).all<Row>()).results??[]).map(r=>`${String(r.teacher_id)}|${String(r.starts_at)}`));
  const anweisungen=anlegen.filter(s=>!vorhanden.has(`${s.teacherId}|${s.startsAt}`))
    .map(s=>env.DB.prepare('INSERT INTO consultation_slots(id,tenant_id,consultation_day_id,teacher_id,starts_at,ends_at,status,created_at) VALUES(?,?,?,?,?,?,?,?)')
      .bind(id('cns_'),tenantId,dayId,s.teacherId,s.startsAt,s.endsAt,'open',ts));
  // Gestapelt und in Teilen geschrieben: ein Raster ueber viele Dozenten sprengt sonst die
  // Grenze der Plattform fuer Unteranfragen bzw. fuer die Groesse eines einzelnen Stapels.
  if(anweisungen.length)await stapelSchreiben(env,anweisungen);
  await audit(env.DB,auth.userId,'consultation.slots_generated',tenantId,tag.course_id??undefined,'consultation_day',dayId,{created:anweisungen.length,teachers:dozenten.length});
  return{consultation_day_id:dayId,created:anweisungen.length,already_present:anlegen.length-anweisungen.length,skipped:uebersprungen};
}

export async function listConsultationSlots(env:Env,auth:CoreAuthContext,tenantId:string,dayId:string){
  const tag=await ladeTag(env,tenantId,dayId);
  const verwaltet=tenantAdmin(auth)||hasPermission(auth,'courses.manage');
  if(!verwaltet){
    if(tag.status==='draft')throw new Error('CONSULTATION_DAY_NOT_OPEN');
    assertBookingAccess(auth,tag.course_id);
  }
  const rows=((await env.DB.prepare(`SELECT s.id,s.teacher_id,s.starts_at,s.ends_at,s.status,t.name teacher_name,
      b.id booking_id,b.user_id booked_user_id,b.participant_name
      FROM consultation_slots s JOIN teachers t ON t.id=s.teacher_id AND t.tenant_id=s.tenant_id
      LEFT JOIN consultation_bookings b ON b.tenant_id=s.tenant_id AND b.slot_id=s.id AND b.status='booked'
      WHERE s.tenant_id=? AND s.consultation_day_id=? ORDER BY t.name,s.starts_at`).bind(tenantId,dayId).all<Row>()).results)??[];
  // Eine Familie darf sehen, DASS ein Fenster belegt ist - nicht, WER es gebucht hat. Sonst
  // erfaehrt jeder Elternteil, welche andere Familie zum Gespraech bestellt wurde.
  return{
    day:tag,
    slots:rows.map(r=>{
      const eigen=String(r.booked_user_id||'')===auth.userId;
      const sichtbar=verwaltet||eigen;
      return{
        id:r.id,teacher_id:r.teacher_id,teacher_name:r.teacher_name,starts_at:r.starts_at,ends_at:r.ends_at,
        status:r.status,taken:r.booking_id?1:0,mine:eigen?1:0,
        booking_id:sichtbar?r.booking_id??null:null,
        participant_name:sichtbar?r.participant_name??null:null,
      };
    }),
  };
}

export async function bookConsultationSlot(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  const slotId=required(input.slot_id,120);
  const slot=await env.DB.prepare('SELECT * FROM consultation_slots WHERE tenant_id=? AND id=?').bind(tenantId,slotId).first<Row>();
  if(!slot)throw new Error('CONSULTATION_SLOT_NOT_FOUND');
  const tag=await ladeTag(env,tenantId,String(slot.consultation_day_id));
  assertBookingAccess(auth,tag.course_id);
  if(tag.status!=='open')throw new Error('CONSULTATION_DAY_NOT_OPEN');
  if(String(slot.status)!=='open')throw new Error('CONSULTATION_SLOT_BLOCKED');
  const jetzt=nowIso();
  if(tag.booking_opens_at&&jetzt<tag.booking_opens_at)throw new Error('CONSULTATION_BOOKING_NOT_STARTED');
  if(tag.booking_closes_at&&jetzt>tag.booking_closes_at)throw new Error('CONSULTATION_BOOKING_CLOSED');

  // Die Verwaltung darf telefonisch nachtragen. Fuer alle anderen ist das buchende Konto das
  // eigene - sonst koennte eine Familie einer anderen einen Termin unterschieben oder wegnehmen.
  const gewuenschterNutzer=safeString(input.user_id,120)||'';
  let userId=auth.userId;
  if(gewuenschterNutzer&&gewuenschterNutzer!==auth.userId){
    assertManage(auth,tag.course_id);
    const mitglied=await env.DB.prepare('SELECT 1 ok FROM memberships WHERE tenant_id=? AND user_id=? LIMIT 1').bind(tenantId,gewuenschterNutzer).first();
    if(!mitglied)throw new Error('CONSULTATION_PERSON_NOT_IN_TENANT');
    userId=gewuenschterNutzer;
  }

  const startsAt=String(slot.starts_at),endsAt=String(slot.ends_at);
  const belegt=await env.DB.prepare(`SELECT 1 ok FROM consultation_bookings WHERE tenant_id=? AND slot_id=? AND status='booked' LIMIT 1`).bind(tenantId,slotId).first();
  if(belegt)throw new Error('CONSULTATION_SLOT_TAKEN');

  // Die eigentliche Regel des Sprechtags: eine Familie kann nicht zur selben Zeit bei zwei
  // Dozenten sitzen. Geprueft wird ueber ALLE Sprechtage des Mandanten, nicht nur ueber diesen -
  // zwei parallel laufende Sprechtage zweier Klassen sind fuer die Familie derselbe Abend.
  const eigene=((await env.DB.prepare(`SELECT b.id,b.teacher_id,b.starts_at,b.ends_at,t.name teacher_name
      FROM consultation_bookings b JOIN teachers t ON t.id=b.teacher_id AND t.tenant_id=b.tenant_id
      WHERE b.tenant_id=? AND b.user_id=? AND b.status='booked'`).bind(tenantId,userId).all<Row>()).results)??[];
  const kollision=eigene.find(b=>ueberschneidet(startsAt,endsAt,String(b.starts_at),String(b.ends_at)));
  if(kollision)throw new Error('CONSULTATION_FAMILY_OVERLAP');
  if(eigene.some(b=>String(b.teacher_id)===String(slot.teacher_id)&&String(b.starts_at).slice(0,10)===startsAt.slice(0,10)))throw new Error('CONSULTATION_TEACHER_ALREADY_BOOKED');
  if(tag.max_bookings_per_user>0){
    const anzahl=eigene.filter(b=>String(b.starts_at).slice(0,10)===startsAt.slice(0,10)).length;
    if(anzahl>=tag.max_bookings_per_user)throw new Error('CONSULTATION_BOOKING_LIMIT_REACHED');
  }

  const bookingId=id('cnb_'),ts=nowIso();
  try{
    await env.DB.prepare('INSERT INTO consultation_bookings(id,tenant_id,slot_id,consultation_day_id,teacher_id,user_id,course_id,starts_at,ends_at,participant_name,note,status,created_by,created_at,updated_at,cancelled_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL)')
      .bind(bookingId,tenantId,slotId,tag.id,String(slot.teacher_id),userId,tag.course_id,startsAt,endsAt,optional(input.participant_name,200),optional(input.note,1000),'booked',auth.userId,ts,ts).run();
  }catch(e){
    // Zwei Eltern haben im selben Moment auf "Buchen" getippt: beide lasen oben "frei", die
    // Datenbank laesst nur einen durch. Der zweite bekommt dieselbe Auskunft wie beim langsamen
    // Fall - nicht einen Datenbankfehler.
    if(/UNIQUE|constraint/i.test(String((e as Error)?.message||'')))throw new Error('CONSULTATION_SLOT_TAKEN');
    throw e;
  }
  await audit(env.DB,auth.userId,'consultation.slot_booked',tenantId,tag.course_id??undefined,'consultation_booking',bookingId,{slotId,userId,teacherId:String(slot.teacher_id)});
  return{booking_id:bookingId,slot_id:slotId,starts_at:startsAt,ends_at:endsAt};
}

export async function cancelConsultationBooking(env:Env,auth:CoreAuthContext,tenantId:string,bookingId:string){
  const row=await env.DB.prepare('SELECT * FROM consultation_bookings WHERE tenant_id=? AND id=?').bind(tenantId,bookingId).first<Row>();
  if(!row)throw new Error('CONSULTATION_BOOKING_NOT_FOUND');
  if(String(row.status)!=='booked')throw new Error('CONSULTATION_BOOKING_NOT_FOUND');
  const kurs=row.course_id?String(row.course_id):null;
  if(String(row.user_id)!==auth.userId)assertManage(auth,kurs);
  const ts=nowIso();
  await env.DB.prepare(`UPDATE consultation_bookings SET status='cancelled',cancelled_at=?,updated_at=? WHERE tenant_id=? AND id=? AND status='booked'`).bind(ts,ts,tenantId,bookingId).run();
  await audit(env.DB,auth.userId,'consultation.booking_cancelled',tenantId,kurs??undefined,'consultation_booking',bookingId,{userId:String(row.user_id)});
  return{booking_id:bookingId};
}

/**
 * Der Laufzettel: was an diesem Abend auf dem Tisch der Dozentin oder des Dozenten liegt.
 * Freie Fenster bleiben ausdruecklich stehen - ein Laufzettel ohne Luecken laesst nicht erkennen,
 * wann jemand kurz weg kann, und lockt dazu, den naechsten Termin vorzuziehen.
 */
export async function consultationRunSheet(env:Env,auth:CoreAuthContext,tenantId:string,dayId:string,teacherId:string){
  const tag=await ladeTag(env,tenantId,dayId);
  const person=await env.DB.prepare('SELECT id,name FROM teachers WHERE tenant_id=? AND id=?').bind(tenantId,teacherId).first<{id:string;name:string}>();
  if(!person)throw new Error('TEACHER_NOT_FOUND');
  await assertRunSheetAccess(env,auth,tenantId,teacherId,tag.course_id);
  const rows=((await env.DB.prepare(`SELECT s.id slot_id,s.starts_at,s.ends_at,s.status,
      b.id booking_id,b.participant_name,b.note,u.display_name family_name,c.name course_name
      FROM consultation_slots s
      LEFT JOIN consultation_bookings b ON b.tenant_id=s.tenant_id AND b.slot_id=s.id AND b.status='booked'
      LEFT JOIN users u ON u.id=b.user_id
      LEFT JOIN courses c ON c.id=b.course_id AND c.tenant_id=b.tenant_id
      WHERE s.tenant_id=? AND s.consultation_day_id=? AND s.teacher_id=? ORDER BY s.starts_at`).bind(tenantId,dayId,teacherId).all<Row>()).results)??[];
  const zeilen=rows.map(r=>({
    slot_id:r.slot_id,starts_at:r.starts_at,ends_at:r.ends_at,
    // Ein gesperrtes Fenster ist keine Pause und keine Buchung. Es gehoert benannt, sonst sucht
    // die Person auf dem Zettel nach einer Familie, die nie kommen wird.
    state:r.booking_id?'gebucht':String(r.status)==='blocked'?'gesperrt':'frei',
    family_name:r.family_name??null,participant_name:r.participant_name??null,note:r.note??null,course_name:r.course_name??null,
  }));
  return{
    day:tag,teacher_id:person.id,teacher_name:person.name,
    rows:zeilen,
    booked:zeilen.filter(z=>z.state==='gebucht').length,
    free:zeilen.filter(z=>z.state==='frei').length,
  };
}

/**
 * Der Ablaufplan einer Familie: alle ihre Gespraeche dieses Abends in der Reihenfolge, in der sie
 * stattfinden, mit der Wartezeit dazwischen. Ohne die Pausenangabe steht die Familie vor der Frage,
 * ob sie zwischen zwei Terminen im Haus bleiben muss.
 *
 * Fuer den eigenen Plan zaehlt der ganze Kalendertag, nicht nur dieser eine Sprechtag: hat eine
 * Familie zwei Kinder in zwei Klassen, laufen deren Sprechtage am selben Abend parallel - ein auf
 * einen Sprechtag verkuerzter Plan verschwiege dann genau die Termine, wegen derer es eng wird.
 */
export async function consultationFamilySchedule(env:Env,auth:CoreAuthContext,tenantId:string,dayId:string,userId?:string){
  const tag=await ladeTag(env,tenantId,dayId);
  let ziel=auth.userId;
  const gewuenscht=safeString(userId,120)||'';
  if(gewuenscht&&gewuenscht!==auth.userId){
    // Der Ablaufplan einer anderen Familie ist deren Sache. Nur die Verwaltung des Sprechtags
    // darf ihn sehen - etwa um ihn am Empfang auszudrucken.
    assertManage(auth,tag.course_id);
    ziel=gewuenscht;
  }
  // Den Plan einer FREMDEN Familie gibt es nur fuer diesen einen Sprechtag. Sonst saehe die
  // Klassenleitung der Klasse A ueber den Ausdruck am Empfang auch die Gespraeche derselben
  // Familie in der Klasse B - Daten, mit denen sie nichts zu tun hat.
  const nurDieserTag=ziel!==auth.userId;
  const sql=`SELECT b.id booking_id,b.starts_at,b.ends_at,b.participant_name,b.note,t.name teacher_name,c.name course_name,d.location,d.title day_title
      FROM consultation_bookings b
      JOIN teachers t ON t.id=b.teacher_id AND t.tenant_id=b.tenant_id
      JOIN consultation_days d ON d.id=b.consultation_day_id AND d.tenant_id=b.tenant_id
      LEFT JOIN courses c ON c.id=b.course_id AND c.tenant_id=b.tenant_id
      WHERE b.tenant_id=? AND b.user_id=? AND b.status='booked'
        AND ${nurDieserTag?'b.consultation_day_id=?':'d.event_date=?'} ORDER BY b.starts_at`;
  const rows=((await env.DB.prepare(sql).bind(tenantId,ziel,nurDieserTag?dayId:tag.event_date).all<Row>()).results)??[];
  const person=await env.DB.prepare('SELECT display_name FROM users WHERE id=?').bind(ziel).first<{display_name:string}>();
  let vorher='';
  const zeilen=rows.map(r=>{
    const wartezeit=vorher?minuten(vorher,String(r.starts_at)):0;
    vorher=String(r.ends_at);
    return{booking_id:r.booking_id,starts_at:r.starts_at,ends_at:r.ends_at,teacher_name:r.teacher_name,course_name:r.course_name??null,
      location:r.location??null,day_title:r.day_title??null,participant_name:r.participant_name??null,note:r.note??null,wait_minutes:wartezeit};
  });
  return{
    day:tag,user_id:ziel,family_name:person?.display_name??null,rows:zeilen,
    first_starts_at:zeilen.length?zeilen[0].starts_at:null,
    last_ends_at:zeilen.length?zeilen[zeilen.length-1].ends_at:null,
  };
}

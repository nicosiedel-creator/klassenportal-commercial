import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Richtlinienbestaetigung (Master-Spec V2, R9 "Richtlinien-Akzeptanz").
//
// Nutzungsordnung, IT-Ordnung, Hausordnung, Datenschutzhinweise: verteilt werden sie ueberall,
// nachweisbar sind sie nirgends. Wenn es darauf ankommt - ein Vorfall im Netz des Traegers, eine
// Abmahnung, eine Pruefung durch den Kostentraeger - lautet die Frage nie "gab es eine Ordnung",
// sondern: WER hat WELCHE FASSUNG WANN bestaetigt. Fehlt eine der drei Angaben, ist die Ordnung
// im Streitfall nicht durchsetzbar, und der Traeger steht mit leeren Haenden da.
//
// Verwandt mit der Einwilligung aus legal-hold-retention.ts, aber ausdruecklich etwas anderes:
//
//   Einwilligung  freiwillig. Jederzeit widerrufbar. Ein Widerruf ist ein gueltiger Endzustand.
//   Richtlinie    verpflichtend. KEIN Widerruf. Wer sie nicht bestaetigt, bekommt den betroffenen
//                 Bereich nicht; wer sie bestaetigt hat, kann das nicht zuruecknehmen. Nur eine
//                 NEUE FASSUNG stellt die Frage erneut.
//
// Die Fassungslogik ist von dort uebernommen, weil sie dort richtig ist: verbunden wird ueber den
// SCHLUESSEL, nicht ueber die Kennung. Jede neue Fassung ist eine eigene Zeile mit eigener
// Kennung; wer ueber die Kennung verbindet, findet nach einer Textaenderung gar nichts mehr und
// haelt "veraltete Bestaetigung" faelschlich fuer "nie gefragt". Das ist nicht dasselbe: das eine
// heisst nachfragen, das andere heisst, es wurde nie gemacht.

export const BEREICHE=['portal','anwesenheit','pruefung','kommunikation','material'] as const;
export type Bereich=typeof BEREICHE[number];

/**
 * Die vier Ordnungen, die ein Traeger praktisch immer hat. Sie stehen hier und nicht in der
 * Migration: der Wortlaut ist Sache des Traegers, die Vorlage nimmt ihm nur den kalten Start ab.
 * Bestaetigt wird immer der Text, der wirklich hinterlegt ist - nicht diese Vorlage.
 */
export const RICHTLINIEN_VORGABEN:Record<string,{titel:string;bereich:Bereich;pflicht:boolean;text:string}>={
  nutzungsordnung:{titel:'Nutzungsordnung',bereich:'portal',pflicht:true,
    text:'Ich habe die Nutzungsordnung des Bildungsträgers gelesen und erkenne sie an.'},
  it_ordnung:{titel:'IT- und Netznutzungsordnung',bereich:'material',pflicht:true,
    text:'Ich habe die IT- und Netznutzungsordnung gelesen und erkenne sie an. Mir ist bekannt, dass die Zugangsdaten persönlich sind und nicht weitergegeben werden dürfen.'},
  hausordnung:{titel:'Hausordnung',bereich:'portal',pflicht:true,
    text:'Ich habe die Hausordnung gelesen und erkenne sie an.'},
  datenschutzhinweise:{titel:'Datenschutzhinweise',bereich:'portal',pflicht:true,
    text:'Ich habe die Datenschutzhinweise zur Kenntnis genommen.'},
};

const clean=(v:unknown,n=500)=>safeString(v,n);

// ---------------------------------------------------------------------------
// Die Richtlinien selbst
// ---------------------------------------------------------------------------

/**
 * Eine Richtlinie anlegen oder neu fassen.
 *
 * Eine neue Fassung entsteht NUR, wenn sich der Text aendert. Das ist keine Bequemlichkeit,
 * sondern die eigentliche Regel: jede neue Fassung setzt saemtliche Bestaetigungen ausser Kraft
 * und schickt jede Person erneut durch die Abfrage. Wuerde schon ein korrigierter Tippfehler im
 * Titel das ausloesen, waere die Folge, dass niemand mehr hinsieht - und genau dann ist die
 * Bestaetigung wertlos. Titel, Bereich und Pflichtigkeit werden deshalb an der laufenden Fassung
 * nachgezogen, ohne sie zu entwerten.
 */
export async function savePolicyDefinition(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const schluessel=clean(input.schluessel,80),titel=clean(input.titel,200),text=clean(input.text,20000);
  if(!schluessel||!titel||!text)throw new Error('RICHTLINIE_UNVOLLSTAENDIG');
  const bereich=clean(input.bereich,40)||'portal';
  if(!BEREICHE.includes(bereich as never))throw new Error('RICHTLINIE_BEREICH_UNGUELTIG');
  const pflicht=input.pflicht===false?0:1;
  const ts=nowIso();
  const aktiv=await env.DB.prepare("SELECT id,fassung,text FROM policy_definitions WHERE tenant_id=? AND schluessel=? AND status='aktiv'").bind(tenantId,schluessel).first<{id:string;fassung:number;text:string}>();
  if(aktiv&&String(aktiv.text)===text){
    await env.DB.prepare('UPDATE policy_definitions SET titel=?,bereich=?,pflicht=?,updated_at=? WHERE id=? AND tenant_id=?').bind(titel,bereich,pflicht,ts,aktiv.id,tenantId).run();
    await audit(env.DB,auth.userId,'policy.definition_updated',tenantId,undefined,'policy_definition',aktiv.id,{schluessel,fassung:Number(aktiv.fassung)});
    return env.DB.prepare('SELECT * FROM policy_definitions WHERE id=?').bind(aktiv.id).first();
  }
  // Die hoechste bisher vergebene Fassung, nicht die aktive: eine abgeloeste Fassung bleibt
  // stehen, weil die Bestaetigungen darauf zeigen. Ihre Nummer darf nie zweimal vergeben werden.
  const letzte=await env.DB.prepare('SELECT MAX(fassung) f FROM policy_definitions WHERE tenant_id=? AND schluessel=?').bind(tenantId,schluessel).first<{f:number|null}>();
  const fassung=Number(letzte?.f||0)+1,pid=id('richt_');
  await env.DB.batch([
    env.DB.prepare("UPDATE policy_definitions SET status='abgeloest',updated_at=? WHERE tenant_id=? AND schluessel=? AND status='aktiv'").bind(ts,tenantId,schluessel),
    env.DB.prepare("INSERT INTO policy_definitions(id,tenant_id,schluessel,titel,bereich,fassung,text,pflicht,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,'aktiv',?,?,?)")
      .bind(pid,tenantId,schluessel,titel,bereich,fassung,text,pflicht,auth.userId,ts,ts),
  ]);
  await audit(env.DB,auth.userId,'policy.definition_saved',tenantId,undefined,'policy_definition',pid,{schluessel,fassung});
  return env.DB.prepare('SELECT * FROM policy_definitions WHERE id=?').bind(pid).first();
}

/** Die Vorlagen einmalig anlegen. Vorhandene Richtlinien bleiben unberuehrt. */
export async function seedPolicyDefinitions(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  const ts=nowIso();
  await env.DB.batch(Object.entries(RICHTLINIEN_VORGABEN).map(([schluessel,v])=>
    env.DB.prepare("INSERT INTO policy_definitions(id,tenant_id,schluessel,titel,bereich,fassung,text,pflicht,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,1,?,?,'aktiv',?,?,?) ON CONFLICT(tenant_id,schluessel,fassung) DO NOTHING")
      .bind(id('richt_'),tenantId,schluessel,v.titel,v.bereich,v.text,v.pflicht?1:0,auth.userId,ts,ts)));
  await audit(env.DB,auth.userId,'policy.seeded',tenantId,undefined,'tenant',tenantId,{anzahl:Object.keys(RICHTLINIEN_VORGABEN).length});
  return listPolicyDefinitions(env,auth,tenantId);
}

export async function listPolicyDefinitions(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return (await env.DB.prepare("SELECT * FROM policy_definitions WHERE tenant_id=? AND status='aktiv' ORDER BY pflicht DESC,titel").bind(tenantId).all()).results??[];
}

// ---------------------------------------------------------------------------
// Bestaetigen
// ---------------------------------------------------------------------------

/**
 * Bestaetigen. Nur fuer sich selbst, nur die AKTIVE Fassung, und nur ausdruecklich.
 *
 * Es gibt bewusst keinen Weg, fuer eine andere Person zu bestaetigen. Bei der Einwilligung gibt
 * es ihn (Sorgeberechtigte erklaeren fuer ihr Kind) - hier waere er das Gegenteil eines
 * Nachweises: eine Bestaetigung, die jemand anderes abgegeben hat, belegt gerade nicht, dass die
 * Person die Ordnung gelesen hat.
 */
export async function acknowledgePolicy(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const definitionId=clean(input.definition_id,120);
  // Eine Richtlinie kennt keinen Widerruf. Wer einen schickt, hat sie mit einer Einwilligung
  // verwechselt - und bekommt das gesagt, statt dass die Angabe still verschluckt wird.
  if(input.widerruf===true||clean(input.entscheidung,40)==='widerrufen')throw new Error('RICHTLINIE_KEIN_WIDERRUF');
  if(input.bestaetigt!==true)throw new Error('RICHTLINIE_BESTAETIGUNG_ERFORDERLICH');
  const d=await env.DB.prepare("SELECT id,schluessel,fassung FROM policy_definitions WHERE id=? AND tenant_id=? AND status='aktiv'").bind(definitionId,tenantId).first<{id:string;schluessel:string;fassung:number}>();
  // Auch die abgeloeste Fassung fuehrt hierher: sie laesst sich nicht mehr bestaetigen, denn sie
  // ist nicht mehr die Ordnung, die gilt.
  if(!d)throw new Error('RICHTLINIE_NICHT_GEFUNDEN');
  const ts=nowIso();
  // Eine zweite Bestaetigung derselben Fassung ist kein neuer Nachweis - sie wuerde nur den
  // Zeitpunkt des ersten ueberschreiben. Der erste zaehlt.
  await env.DB.prepare('INSERT INTO policy_acknowledgements(id,tenant_id,definition_id,user_id,text_fassung,bestaetigt_am,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(tenant_id,definition_id,user_id) DO NOTHING')
    .bind(id('richtb_'),tenantId,d.id,auth.userId,Number(d.fassung),ts,ts).run();
  await audit(env.DB,auth.userId,'policy.acknowledged',tenantId,undefined,'policy_definition',d.id,{schluessel:d.schluessel,fassung:Number(d.fassung)});
  return env.DB.prepare('SELECT * FROM policy_acknowledgements WHERE tenant_id=? AND definition_id=? AND user_id=?').bind(tenantId,d.id,auth.userId).first();
}

export type Richtlinienstand={
  definition_id:string;schluessel:string;titel:string;bereich:string;pflicht:number;
  aktuelle_fassung:number;bestaetigte_fassung:number|null;bestaetigt_am:string|null;
  bestaetigt:boolean;fassung_veraltet:boolean;offen:boolean;
};

/**
 * Der Stand einer Person - in EINER Abfrage.
 *
 * Verbunden wird ueber den Schluessel; die juengste Bestaetigung zu diesem Schluessel wird
 * gesucht, egal zu welcher Fassung sie gehoert. Nur so entsteht der Unterschied zwischen
 * "veraltet" (hat die Fassung von 2024 bestaetigt) und "offen" (hat nie bestaetigt) - und genau
 * den braucht die Person, die vor der Abfrage sitzt.
 */
export async function policyStatus(env:Env,auth:CoreAuthContext,tenantId:string,userId:string):Promise<Richtlinienstand[]>{
  if(userId!==auth.userId)requireRole(auth,'tenant_admin');
  const zeilen=(await env.DB.prepare("SELECT d.id AS definition_id,d.schluessel,d.titel,d.bereich,d.pflicht,d.text,d.fassung AS aktuelle_fassung,a.text_fassung AS bestaetigte_fassung,a.bestaetigt_am FROM policy_definitions d LEFT JOIN policy_acknowledgements a ON a.id=(SELECT x.id FROM policy_acknowledgements x JOIN policy_definitions xd ON xd.id=x.definition_id WHERE xd.tenant_id=d.tenant_id AND xd.schluessel=d.schluessel AND x.user_id=? ORDER BY x.bestaetigt_am DESC,x.rowid DESC LIMIT 1) WHERE d.tenant_id=? AND d.status='aktiv' ORDER BY d.pflicht DESC,d.titel")
    .bind(userId,tenantId).all<Record<string,unknown>>()).results??[];
  return zeilen.map(z=>{
    const bestaetigt=z.bestaetigte_fassung!==null&&z.bestaetigte_fassung!==undefined;
    const veraltet=bestaetigt&&Number(z.bestaetigte_fassung)<Number(z.aktuelle_fassung);
    return{...z,bestaetigt:bestaetigt&&!veraltet,fassung_veraltet:veraltet,offen:!bestaetigt||veraltet} as unknown as Richtlinienstand;
  });
}

/**
 * Die Sperre. Solange eine PFLICHTrichtlinie fuer diesen Bereich offen ist, geht der Bereich
 * nicht auf.
 *
 * Eine Abfrage, kein Aufwand je Richtlinie. 'portal' sperrt immer mit: eine Hausordnung gilt
 * nicht nur fuer einen Teil des Portals.
 */
export async function assertPolicyAcknowledged(env:Env,tenantId:string,userId:string,bereich:Bereich):Promise<void>{
  const offen=await env.DB.prepare("SELECT d.schluessel FROM policy_definitions d WHERE d.tenant_id=? AND d.status='aktiv' AND d.pflicht=1 AND (d.bereich=? OR d.bereich='portal') AND NOT EXISTS(SELECT 1 FROM policy_acknowledgements a WHERE a.definition_id=d.id AND a.user_id=?) LIMIT 1")
    .bind(tenantId,bereich,userId).first<{schluessel:string}>();
  if(offen)throw new Error('RICHTLINIE_NICHT_BESTAETIGT');
}

export type Richtlinienuebersicht={
  stand:{schluessel:string;titel:string;bereich:string;pflicht:number;aktuelle_fassung:number;betroffen:number;bestaetigt:number;offen:number}[];
  ausstehend:{schluessel:string;titel:string;user_id:string;display_name:string}[];
  ausstehend_gekuerzt:boolean;
};

/**
 * Die Auswertung fuer die Leitung: wer steht noch aus, wer hat welche Fassung.
 *
 * Zwei Abfragen, nicht eine je Person: die Zahlen kommen aggregiert aus der Datenbank, die
 * Namensliste getrennt und begrenzt. Ein Traeger mit 800 Teilnehmenden und vier Richtlinien
 * ergaebe sonst 3200 Zeilen in einer Antwort, die niemand liest - und bei zeilenweiser Abfrage
 * waere die Unteranfragen-Grenze lange vorher erreicht.
 *
 * Gezaehlt wird gegen d.id, also gegen die AKTUELLE Fassung. Wer die Vorgaengerfassung
 * bestaetigt hat, steht deshalb richtigerweise wieder unter "ausstehend".
 */
export async function policyOverview(env:Env,auth:CoreAuthContext,tenantId:string,grenze=200):Promise<Richtlinienuebersicht>{
  requireRole(auth,'tenant_admin');
  const max=Math.min(Math.max(Math.trunc(Number(grenze)||200),1),500);
  const stand=(await env.DB.prepare("SELECT d.schluessel,d.titel,d.bereich,d.pflicht,d.fassung AS aktuelle_fassung,(SELECT COUNT(DISTINCT m.user_id) FROM memberships m WHERE m.tenant_id=d.tenant_id) AS betroffen,(SELECT COUNT(*) FROM policy_acknowledgements a WHERE a.definition_id=d.id) AS bestaetigt FROM policy_definitions d WHERE d.tenant_id=? AND d.status='aktiv' ORDER BY d.pflicht DESC,d.titel")
    .bind(tenantId).all<{schluessel:string;titel:string;bereich:string;pflicht:number;aktuelle_fassung:number;betroffen:number;bestaetigt:number}>()).results??[];
  const ausstehend=(await env.DB.prepare("SELECT d.schluessel,d.titel,u.id AS user_id,u.display_name FROM policy_definitions d JOIN users u ON u.id IN (SELECT m.user_id FROM memberships m WHERE m.tenant_id=d.tenant_id) WHERE d.tenant_id=? AND d.status='aktiv' AND NOT EXISTS(SELECT 1 FROM policy_acknowledgements a WHERE a.definition_id=d.id AND a.user_id=u.id) ORDER BY d.titel,u.display_name LIMIT ?")
    .bind(tenantId,max+1).all<{schluessel:string;titel:string;user_id:string;display_name:string}>()).results??[];
  return{
    stand:stand.map(z=>({...z,offen:Math.max(Number(z.betroffen)-Number(z.bestaetigt),0)})),
    ausstehend:ausstehend.slice(0,max),
    ausstehend_gekuerzt:ausstehend.length>max,
  };
}

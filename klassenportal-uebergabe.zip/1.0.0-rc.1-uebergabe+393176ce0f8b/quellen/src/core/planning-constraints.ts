import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { hasPermission } from './enterprise-access.js';
import { ausFaechern, getTimetablePlan, inFaecher, publishTimetablePlan, saveTimetablePlanEntry, stapelSchreiben, validateTimetablePlan } from './learning-operations.js';
import { id, nowIso, safeString } from './utils.js';

function admin(auth:CoreAuthContext){return auth.isPlatformAdmin||auth.role==='tenant_admin';}
function requireManage(auth:CoreAuthContext){if(!admin(auth)&&!hasPermission(auth,'courses.manage'))throw new Error('FORBIDDEN_PLANNING_MANAGE');}
function courseScope(auth:CoreAuthContext,courseId:string){if(!admin(auth)&&!auth.courseIds.includes(courseId))throw new Error('FORBIDDEN_COURSE_SCOPE');}
function required(v:unknown,max=400){const s=safeString(v,max);if(!s)throw new Error('FIELD_REQUIRED');return s;}
function optional(v:unknown,max=4000){return safeString(v,max)||null;}
function iso(v:unknown){const s=safeString(v,50);if(!s)return null;const d=new Date(s);if(Number.isNaN(d.getTime()))throw new Error('DATE_INVALID');return d.toISOString();}
function bool(v:unknown){return v===true||v===1||String(v)==='1'?1:0;}
function enumValue<T extends readonly string[]>(v:unknown,allowed:T,fallback:T[number]):T[number]{const x=String(v||fallback);if(!allowed.includes(x as T[number]))throw new Error('ENUM_VALUE_INVALID');return x as T[number];}
function minutes(start:string,end:string){return Math.max(0,Math.round((Date.parse(end)-Date.parse(start))/60000));}
function dateKey(v:string){return String(v).slice(0,10);}
function mondayKey(v:string){const d=new Date(v),day=(d.getUTCDay()+6)%7;d.setUTCDate(d.getUTCDate()-day);return d.toISOString().slice(0,10);}
function localTime(v:string){return String(v).slice(11,16);}
function overlaps(aStart:string,aEnd:string,bStart:string,bEnd:string){return aStart<bEnd&&bStart<aEnd;}
// Tages- und Wochensummen einer Personenlast. Dieselbe Rechnung wird an zwei Stellen gebraucht:
// im Entwurf (was geplant werden SOLL) und im Rueckblick (was stattgefunden HAT). Eine gemeinsame
// Funktion haelt beide Zahlen vergleichbar - sonst meldete der Entwurf eine Tagesgrenze als
// gerissen, die die Auswertung fuer denselben Tag noch als eingehalten auswies.
function lastNachTagUndWoche(bloecke:Array<{starts_at:string;ends_at:string}>){
  const tage=new Map<string,number>(),wochen=new Map<string,number>();
  for(const b of bloecke){const m=minutes(b.starts_at,b.ends_at),d=dateKey(b.starts_at),w=mondayKey(b.starts_at);
    tage.set(d,(tage.get(d)||0)+m);wochen.set(w,(wochen.get(w)||0)+m);}
  return{tage,wochen};
}

export async function listPlanningResources(env:Env,auth:CoreAuthContext,tenantId:string){requireManage(auth);return(await env.DB.prepare(`SELECT r.*,(SELECT COUNT(*) FROM planning_resource_unavailability u WHERE u.tenant_id=r.tenant_id AND u.resource_id=r.id AND u.ends_at>strftime('%Y-%m-%dT%H:%M:%fZ','now')) future_blocks FROM planning_resources r WHERE r.tenant_id=? ORDER BY CASE r.resource_type WHEN 'room' THEN 0 WHEN 'online_room' THEN 1 ELSE 2 END,r.name`).bind(tenantId).all<Record<string,unknown>>()).results??[];}
export async function savePlanningResource(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){requireManage(auth);const resourceId=optional(input.id,120)||id('res_'),type=enumValue(input.resource_type,['room','equipment','vehicle','online_room','other'] as const,'room'),status=enumValue(input.status,['active','inactive','maintenance'] as const,'active'),ts=nowIso(),found=await env.DB.prepare('SELECT 1 ok FROM planning_resources WHERE tenant_id=? AND id=?').bind(tenantId,resourceId).first();const features=Array.isArray(input.features)?JSON.stringify(input.features.map(String).slice(0,100)):optional(input.features_json,5000),capacity=input.capacity===null||input.capacity===''||input.capacity===undefined?null:Math.max(0,Math.floor(Number(input.capacity)||0));if(found)await env.DB.prepare('UPDATE planning_resources SET resource_type=?,name=?,code=?,location=?,capacity=?,features_json=?,status=?,updated_at=? WHERE tenant_id=? AND id=?').bind(type,required(input.name,300),optional(input.code,120),optional(input.location,500),capacity,features,status,ts,tenantId,resourceId).run();else await env.DB.prepare('INSERT INTO planning_resources(id,tenant_id,resource_type,name,code,location,capacity,features_json,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').bind(resourceId,tenantId,type,required(input.name,300),optional(input.code,120),optional(input.location,500),capacity,features,status,auth.userId,ts,ts).run();await audit(env.DB,auth.userId,'planning.resource_saved',tenantId,undefined,'planning_resource',resourceId,{type,status,capacity});return{resource_id:resourceId};}
export async function saveResourceUnavailability(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){requireManage(auth);const resourceId=required(input.resource_id,120),starts=iso(input.starts_at),ends=iso(input.ends_at);if(!starts||!ends||starts>=ends)throw new Error('RESOURCE_BLOCK_TIME_INVALID');if(!await env.DB.prepare('SELECT 1 ok FROM planning_resources WHERE tenant_id=? AND id=?').bind(tenantId,resourceId).first())throw new Error('RESOURCE_NOT_FOUND');const blockId=optional(input.id,120)||id('rblk_'),source=enumValue(input.source,['manual','maintenance','external','automation'] as const,'manual'),ts=nowIso();await env.DB.prepare('INSERT INTO planning_resource_unavailability(id,tenant_id,resource_id,starts_at,ends_at,reason,source,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET starts_at=excluded.starts_at,ends_at=excluded.ends_at,reason=excluded.reason,source=excluded.source,updated_at=excluded.updated_at').bind(blockId,tenantId,resourceId,starts,ends,optional(input.reason,2000),source,auth.userId,ts,ts).run();return{block_id:blockId};}

export async function saveTeacherUnavailability(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){requireManage(auth);const teacherId=required(input.teacher_id,120),starts=iso(input.starts_at),ends=iso(input.ends_at);if(!starts||!ends||starts>=ends)throw new Error('TEACHER_BLOCK_TIME_INVALID');if(!await env.DB.prepare('SELECT 1 ok FROM teachers WHERE tenant_id=? AND id=?').bind(tenantId,teacherId).first())throw new Error('TEACHER_NOT_FOUND');const blockId=optional(input.id,120)||id('tblk_'),source=enumValue(input.source,['manual','sickness','vacation','training','external','automation'] as const,'manual'),ts=nowIso();await env.DB.prepare('INSERT INTO teacher_unavailability(id,tenant_id,teacher_id,starts_at,ends_at,reason,source,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET starts_at=excluded.starts_at,ends_at=excluded.ends_at,reason=excluded.reason,source=excluded.source,updated_at=excluded.updated_at').bind(blockId,tenantId,teacherId,starts,ends,optional(input.reason,2000),source,auth.userId,ts,ts).run();return{block_id:blockId};}
export async function listTeacherUnavailability(env:Env,auth:CoreAuthContext,tenantId:string){requireManage(auth);return(await env.DB.prepare(`SELECT u.*,t.name teacher_name FROM teacher_unavailability u JOIN teachers t ON t.id=u.teacher_id AND t.tenant_id=u.tenant_id WHERE u.tenant_id=? AND u.ends_at>=datetime('now','-60 day') ORDER BY u.starts_at LIMIT 1000`).bind(tenantId).all<Record<string,unknown>>()).results??[];}

export async function savePlanningBlackout(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){requireManage(auth);const blackoutId=optional(input.id,120)||id('blk_'),courseId=optional(input.course_id,120),starts=iso(input.starts_at),ends=iso(input.ends_at);if(courseId)courseScope(auth,courseId);if(!starts||!ends||starts>=ends)throw new Error('BLACKOUT_TIME_INVALID');const type=enumValue(input.blackout_type,['holiday','closure','exam_block','practice_block','maintenance','other'] as const,'closure'),ts=nowIso();await env.DB.prepare('INSERT INTO planning_blackouts(id,tenant_id,course_id,title,starts_at,ends_at,blackout_type,blocks_teaching,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET course_id=excluded.course_id,title=excluded.title,starts_at=excluded.starts_at,ends_at=excluded.ends_at,blackout_type=excluded.blackout_type,blocks_teaching=excluded.blocks_teaching,updated_at=excluded.updated_at').bind(blackoutId,tenantId,courseId,required(input.title,300),starts,ends,type,bool(input.blocks_teaching??true),auth.userId,ts,ts).run();return{blackout_id:blackoutId};}
export async function listPlanningBlackouts(env:Env,auth:CoreAuthContext,tenantId:string){requireManage(auth);return(await env.DB.prepare(`SELECT b.*,c.name course_name FROM planning_blackouts b LEFT JOIN courses c ON c.id=b.course_id AND c.tenant_id=b.tenant_id WHERE b.tenant_id=? AND b.ends_at>=datetime('now','-180 day') ORDER BY b.starts_at LIMIT 1000`).bind(tenantId).all<Record<string,unknown>>()).results??[];}

export async function getCourseSchedulingRules(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){requireManage(auth);courseScope(auth,courseId);return await env.DB.prepare('SELECT * FROM course_scheduling_rules WHERE tenant_id=? AND course_id=?').bind(tenantId,courseId).first<Record<string,unknown>>()||{tenant_id:tenantId,course_id:courseId};}
export async function saveCourseSchedulingRules(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,input:Record<string,unknown>){requireManage(auth);courseScope(auth,courseId);const ts=nowIso(),earliest=optional(input.earliest_start,5),latest=optional(input.latest_end,5);if(earliest&&!/^\d\d:\d\d$/.test(earliest)||latest&&!/^\d\d:\d\d$/.test(latest))throw new Error('SCHEDULING_TIME_INVALID');const num=(v:unknown)=>v===null||v===''||v===undefined?null:Math.max(0,Math.floor(Number(v)||0));await env.DB.prepare(`INSERT INTO course_scheduling_rules(tenant_id,course_id,earliest_start,latest_end,max_daily_minutes,max_consecutive_minutes,min_break_minutes,allow_saturday,allow_sunday,default_lesson_minutes,updated_by,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,course_id) DO UPDATE SET earliest_start=excluded.earliest_start,latest_end=excluded.latest_end,max_daily_minutes=excluded.max_daily_minutes,max_consecutive_minutes=excluded.max_consecutive_minutes,min_break_minutes=excluded.min_break_minutes,allow_saturday=excluded.allow_saturday,allow_sunday=excluded.allow_sunday,default_lesson_minutes=excluded.default_lesson_minutes,updated_by=excluded.updated_by,updated_at=excluded.updated_at`).bind(tenantId,courseId,earliest,latest,num(input.max_daily_minutes),num(input.max_consecutive_minutes),num(input.min_break_minutes),bool(input.allow_saturday),bool(input.allow_sunday),num(input.default_lesson_minutes),auth.userId,ts).run();return getCourseSchedulingRules(env,auth,tenantId,courseId);}
export async function saveTeacherWorkloadRules(env:Env,auth:CoreAuthContext,tenantId:string,teacherId:string,input:Record<string,unknown>){requireManage(auth);if(!await env.DB.prepare('SELECT 1 ok FROM teachers WHERE tenant_id=? AND id=?').bind(tenantId,teacherId).first())throw new Error('TEACHER_NOT_FOUND');const num=(v:unknown)=>v===null||v===''||v===undefined?null:Math.max(0,Math.floor(Number(v)||0)),ts=nowIso();await env.DB.prepare(`INSERT INTO teacher_workload_rules(tenant_id,teacher_id,max_daily_minutes,max_weekly_minutes,max_consecutive_minutes,min_break_minutes,updated_by,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,teacher_id) DO UPDATE SET max_daily_minutes=excluded.max_daily_minutes,max_weekly_minutes=excluded.max_weekly_minutes,max_consecutive_minutes=excluded.max_consecutive_minutes,min_break_minutes=excluded.min_break_minutes,updated_by=excluded.updated_by,updated_at=excluded.updated_at`).bind(tenantId,teacherId,num(input.max_daily_minutes),num(input.max_weekly_minutes),num(input.max_consecutive_minutes),num(input.min_break_minutes),auth.userId,ts).run();return{teacher_id:teacherId};}

export async function linkPlanEntryResource(env:Env,auth:CoreAuthContext,tenantId:string,planId:string,entryId:string,input:Record<string,unknown>){requireManage(auth);const resourceId=required(input.resource_id,120),quantity=Math.max(1,Math.floor(Number(input.quantity||1)||1));if(!await env.DB.prepare('SELECT 1 ok FROM timetable_plan_entries WHERE tenant_id=? AND plan_id=? AND id=?').bind(tenantId,planId,entryId).first())throw new Error('PLAN_ENTRY_NOT_FOUND');if(!await env.DB.prepare("SELECT 1 ok FROM planning_resources WHERE tenant_id=? AND id=? AND status='active'").bind(tenantId,resourceId).first())throw new Error('RESOURCE_NOT_AVAILABLE');await env.DB.prepare('INSERT INTO timetable_plan_entry_resources(tenant_id,plan_id,entry_id,resource_id,quantity,created_by,created_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(tenant_id,entry_id,resource_id) DO UPDATE SET quantity=excluded.quantity').bind(tenantId,planId,entryId,resourceId,quantity,auth.userId,nowIso()).run();return{entry_id:entryId,resource_id:resourceId};}

// Ein Fach je Schluessel: erst holen, sonst anlegen. Damit lassen sich Sperren, Belegungen und
// Termine einmal geladen nach Ressource oder Person und Kalendertag einsortieren.
function unterFach<T>(m:Map<string,Map<string,T[]>>,schluessel:string){let f=m.get(schluessel);if(!f){f=new Map();m.set(schluessel,f);}return f;}

// Die erweiterte Pruefung stellte frueher elf Abfragen JE TERMIN. Ein Schuljahresplan mit 250
// Terminen kam damit auf rund 2750 Unteranfragen - die Plattform laesst 1000 zu. Der Kunde konnte
// also einen Jahresplan erzeugen, aber weder pruefen noch veroeffentlichen. Jetzt wird jeder
// Datenbestand genau einmal geladen und im Speicher zugeordnet; die Zahl der Abfragen ist von der
// Zahl der Termine unabhaengig.
export async function validateAdvancedTimetablePlan(env:Env,auth:CoreAuthContext,tenantId:string,planId:string){
  requireManage(auth);const base=await validateTimetablePlan(env,auth,tenantId,planId),data=await getTimetablePlan(env,auth,tenantId,planId),entries=data.entries as any[],issues:Array<{entry_id:string;type:string;severity:'warning'|'error';message:string}>=[],konflikte:any[]=[];
  const add=(e:any,type:string,severity:'warning'|'error',message:string,otherId?:string|null)=>{issues.push({entry_id:String(e.id),type,severity,message});konflikte.push(env.DB.prepare('INSERT INTO timetable_plan_conflicts(id,tenant_id,plan_id,entry_id,conflicting_entry_id,conflict_type,severity,message,detected_at,resolved_at) VALUES(?,?,?,?,?,?,?,?,?,NULL)').bind(id('tpc_'),tenantId,planId,String(e.id),otherId||null,type,severity,message,nowIso()));};
  const courseRules=new Map<string,any>(),teacherRules=new Map<string,any>(),kursRegelnAlle=new Map<string,any>(),dozentRegelnAlle=new Map<string,any>();
  const sperrzeiten=new Map<string,Record<string,unknown>[]>(),dozentSperren=new Map<string,Map<string,Record<string,unknown>[]>>(),arbeitszeiten=new Map<string,Record<string,unknown>[]>();
  const teilnahmen=new Map<string,number>(),terminMittel=new Map<string,Record<string,unknown>[]>();
  const raumNachName=new Map<string,Record<string,unknown>>(),raumNachCode=new Map<string,Record<string,unknown>>();
  const mittelSperren=new Map<string,Map<string,Record<string,unknown>[]>>(),mittelBelegung=new Map<string,Map<string,any[]>>(),veroeffentlichteBelegung=new Map<string,Map<string,Record<string,unknown>[]>>();
  if(entries.length){
    let von=String(entries[0].starts_at),bis=String(entries[0].ends_at);
    for(const e of entries){if(String(e.starts_at)<von)von=String(e.starts_at);if(String(e.ends_at)>bis)bis=String(e.ends_at);}
    const [sperrZeilen,dozentZeilen,zeitZeilen,kursRegeln,dozentRegeln,teilnahmeZeilen,mittelZeilen,raumZeilen,mittelSperrZeilen,belegtZeilen]=await Promise.all([
      env.DB.prepare('SELECT title,blackout_type,course_id,starts_at,ends_at FROM planning_blackouts WHERE tenant_id=? AND blocks_teaching=1 AND starts_at<? AND ends_at>?').bind(tenantId,bis,von).all<Record<string,unknown>>(),
      env.DB.prepare('SELECT teacher_id,reason,starts_at,ends_at FROM teacher_unavailability WHERE tenant_id=? AND starts_at<? AND ends_at>?').bind(tenantId,bis,von).all<Record<string,unknown>>(),
      env.DB.prepare('SELECT teacher_id,weekday,starts_time,ends_time,valid_from,valid_until FROM teacher_availability WHERE tenant_id=?').bind(tenantId).all<Record<string,unknown>>(),
      env.DB.prepare('SELECT * FROM course_scheduling_rules WHERE tenant_id=?').bind(tenantId).all<Record<string,unknown>>(),
      env.DB.prepare('SELECT * FROM teacher_workload_rules WHERE tenant_id=?').bind(tenantId).all<Record<string,unknown>>(),
      env.DB.prepare("SELECT course_id,COUNT(DISTINCT user_id) n FROM memberships WHERE tenant_id=? AND role IN ('participant','class_admin') GROUP BY course_id").bind(tenantId).all<Record<string,unknown>>(),
      env.DB.prepare('SELECT pr.entry_id,r.* FROM timetable_plan_entry_resources pr JOIN planning_resources r ON r.id=pr.resource_id AND r.tenant_id=pr.tenant_id WHERE pr.tenant_id=? AND pr.plan_id=?').bind(tenantId,planId).all<Record<string,unknown>>(),
      env.DB.prepare("SELECT * FROM planning_resources WHERE tenant_id=? AND resource_type='room' AND status='active'").bind(tenantId).all<Record<string,unknown>>(),
      env.DB.prepare('SELECT resource_id,reason,starts_at,ends_at FROM planning_resource_unavailability WHERE tenant_id=? AND starts_at<? AND ends_at>?').bind(tenantId,bis,von).all<Record<string,unknown>>(),
      env.DB.prepare('SELECT rr.resource_id,l.id,l.starts_at,l.ends_at FROM lesson_resource_reservations rr JOIN lessons l ON l.id=rr.lesson_id AND l.tenant_id=rr.tenant_id WHERE rr.tenant_id=? AND l.starts_at<? AND l.ends_at>?').bind(tenantId,bis,von).all<Record<string,unknown>>(),
    ]);
    for(const b of sperrZeilen.results??[])inFaecher(sperrzeiten,String(b.starts_at),String(b.ends_at),b);
    for(const b of dozentZeilen.results??[])inFaecher(unterFach(dozentSperren,String(b.teacher_id)),String(b.starts_at),String(b.ends_at),b);
    for(const z of zeitZeilen.results??[]){const k=String(z.teacher_id),l=arbeitszeiten.get(k);if(l)l.push(z);else arbeitszeiten.set(k,[z]);}
    for(const r of kursRegeln.results??[])kursRegelnAlle.set(String(r.course_id),r);
    for(const r of dozentRegeln.results??[])dozentRegelnAlle.set(String(r.teacher_id),r);
    for(const t of teilnahmeZeilen.results??[])teilnahmen.set(String(t.course_id),Number(t.n)||0);
    for(const m of mittelZeilen.results??[]){const k=String(m.entry_id),l=terminMittel.get(k);if(l)l.push(m);else terminMittel.set(k,[m]);}
    for(const r of raumZeilen.results??[]){const name=String(r.name??'').toLowerCase(),code=String(r.code??'').toLowerCase();if(name&&!raumNachName.has(name))raumNachName.set(name,r);if(code&&!raumNachCode.has(code))raumNachCode.set(code,r);}
    for(const s of mittelSperrZeilen.results??[])inFaecher(unterFach(mittelSperren,String(s.resource_id)),String(s.starts_at),String(s.ends_at),s);
    for(const b of belegtZeilen.results??[])inFaecher(unterFach(veroeffentlichteBelegung,String(b.resource_id)),String(b.starts_at),String(b.ends_at),b);
    // Belegungen im selben Entwurf ergeben sich aus den bereits geladenen Terminen und ihren Mitteln.
    const nachId=new Map<string,any>();for(const e of entries)nachId.set(String(e.id),e);
    for(const [entryId,mittel] of terminMittel){const e=nachId.get(entryId);if(!e)continue;for(const m of mittel)inFaecher(unterFach(mittelBelegung,String(m.id)),String(e.starts_at),String(e.ends_at),e);}
  }
  // Fuer die Tages- und Wochenbilanz zaehlen nur die wirklich verplanten Kurse und Personen - in
  // der Reihenfolge, in der sie im Plan vorkommen, damit die Meldungen dieselbe Ordnung behalten.
  for(const e of entries){const k=String(e.course_id);if(!courseRules.has(k))courseRules.set(k,kursRegelnAlle.get(k)??null);if(e.teacher_id){const t=String(e.teacher_id);if(!teacherRules.has(t))teacherRules.set(t,dozentRegelnAlle.get(t)??null);}}
  for(const e of entries){
    const start=String(e.starts_at),end=String(e.ends_at),day=dateKey(start),dow=new Date(start).getUTCDay();
    const rule=courseRules.get(String(e.course_id));
    if(rule){if(rule.earliest_start&&localTime(start)<String(rule.earliest_start))add(e,'course_time_window','warning',`Beginn ${localTime(start)} liegt vor der gewünschten Startzeit ${rule.earliest_start}.`);if(rule.latest_end&&localTime(end)>String(rule.latest_end))add(e,'course_time_window','warning',`Ende ${localTime(end)} liegt nach der gewünschten Endzeit ${rule.latest_end}.`);if(dow===6&&!Number(rule.allow_saturday))add(e,'weekend_not_allowed','error','Samstagsunterricht ist für diesen Kurs nicht freigegeben.');if(dow===0&&!Number(rule.allow_sunday))add(e,'weekend_not_allowed','error','Sonntagsunterricht ist für diesen Kurs nicht freigegeben.');}
    for(const b of ausFaechern(sperrzeiten,start,end)){if(b.course_id!==null&&b.course_id!==undefined&&String(b.course_id)!==String(e.course_id))continue;if(!overlaps(start,end,String(b.starts_at),String(b.ends_at)))continue;add(e,'planning_blackout','error',`Termin liegt in Sperrzeit: ${String(b.title)} (${String(b.blackout_type)}).`);}
    if(e.teacher_id){
      for(const b of ausFaechern(unterFach(dozentSperren,String(e.teacher_id)),start,end)){if(!overlaps(start,end,String(b.starts_at),String(b.ends_at)))continue;add(e,'teacher_unavailable','error',`Dozent/in ist nicht verfügbar${b.reason?`: ${String(b.reason)}`:''}.`);}
      // Hat die Person Arbeitszeiten zugesagt, darf ausserhalb davon nicht stillschweigend
      // geplant werden. Bewusst ein Hinweis und kein Fehler: eine Absprache im Einzelfall soll
      // moeglich bleiben, sie muss nur sichtbar sein.
      const zusagen=arbeitszeiten.get(String(e.teacher_id))??[];
      if(zusagen.length){const passend=zusagen.some(av=>Number(av.weekday)===wochentag(start)&&String(av.starts_time)<=localTime(start)&&String(av.ends_time)>=localTime(end)&&(av.valid_from===null||av.valid_from===undefined||String(av.valid_from)<=day)&&(av.valid_until===null||av.valid_until===undefined||String(av.valid_until)>=day));
        if(!passend)add(e,'teacher_outside_availability','warning','Der Termin liegt außerhalb der zugesagten Arbeitszeiten dieser Dozentin oder dieses Dozenten.');}}
    const participantCount=teilnahmen.get(String(e.course_id))||0;
    let resources=terminMittel.get(String(e.id))??[];
    if(!resources.length&&e.room){const schluessel=String(e.room).toLowerCase(),r=raumNachName.get(schluessel)||raumNachCode.get(schluessel);if(r)resources=[r];}
    for(const r of resources){
      if(String(r.status)!=='active')add(e,'resource_inactive','error',`Ressource ${String(r.name)} ist nicht aktiv.`);
      if(r.capacity!==null&&r.capacity!==undefined&&participantCount>Number(r.capacity))add(e,'resource_capacity','error',`${String(r.name)} hat nur ${Number(r.capacity)} Plätze für ${participantCount} Teilnehmende.`);
      const unavailable=ausFaechern(unterFach(mittelSperren,String(r.id)),start,end).find(s=>overlaps(start,end,String(s.starts_at),String(s.ends_at)));
      if(unavailable)add(e,'resource_unavailable','error',`${String(r.name)} ist nicht verfügbar${unavailable.reason?`: ${String(unavailable.reason)}`:''}.`);
      const planned=ausFaechern(unterFach(mittelBelegung,String(r.id)),start,end).find(o=>String(o.id)!==String(e.id)&&overlaps(start,end,String(o.starts_at),String(o.ends_at)));
      if(planned)add(e,'resource_overlap','error',`${String(r.name)} ist im selben Plan bereits belegt.`,String(planned.id));
      const published=ausFaechern(unterFach(veroeffentlichteBelegung,String(r.id)),start,end).find(o=>overlaps(start,end,String(o.starts_at),String(o.ends_at)));
      if(published)add(e,'resource_overlap','error',`${String(r.name)} ist durch veröffentlichten Unterricht belegt.`);
    }
    void day;
  }
  for(const [courseId,rule] of courseRules){if(!rule?.max_daily_minutes)continue;const days=new Map<string,number>();for(const e of entries.filter(x=>String(x.course_id)===courseId)){const k=dateKey(String(e.starts_at));days.set(k,(days.get(k)||0)+minutes(String(e.starts_at),String(e.ends_at)));}for(const [d,total] of days)if(total>Number(rule.max_daily_minutes)){const e=entries.find(x=>String(x.course_id)===courseId&&dateKey(String(x.starts_at))===d);if(e)add(e,'course_daily_limit','warning',`Geplante Unterrichtszeit ${total} Min. überschreitet das Tagesziel ${rule.max_daily_minutes} Min.`);}}
  for(const [teacherId,rule] of teacherRules){if(!rule)continue;const teacherEntries=entries.filter(x=>String(x.teacher_id||'')===teacherId);const {tage:days,wochen:weeks}=lastNachTagUndWoche(teacherEntries.map(e=>({starts_at:String(e.starts_at),ends_at:String(e.ends_at)})));if(rule.max_daily_minutes)for(const [d,total] of days)if(total>Number(rule.max_daily_minutes)){const e=teacherEntries.find(x=>dateKey(String(x.starts_at))===d);if(e)add(e,'teacher_daily_limit','warning',`Dozentenbelastung ${total} Min. überschreitet Tagesgrenze ${rule.max_daily_minutes} Min.`);}if(rule.max_weekly_minutes)for(const [w,total] of weeks)if(total>Number(rule.max_weekly_minutes)){const e=teacherEntries.find(x=>mondayKey(String(x.starts_at))===w);if(e)add(e,'teacher_weekly_limit','warning',`Dozentenbelastung ${total} Min. überschreitet Wochengrenze ${rule.max_weekly_minutes} Min.`);}}
  await stapelSchreiben(env,konflikte);
  const errors=Number(base.errors||0)+issues.filter(x=>x.severity==='error').length,warnings=Number(base.warnings||0)+issues.filter(x=>x.severity==='warning').length;await audit(env.DB,auth.userId,'planning.advanced_validated',tenantId,undefined,'timetable_plan',planId,{errors,warnings,advancedIssues:issues.length});return{issues:[...(base.issues||[]),...issues],errors,warnings};
}

// Auch das Reservieren lief frueher je Termin mit eigenen Abfragen. Bei einem Jahresplan blieb es
// mitten im Reservieren stehen. Jetzt: einmal laden, gestapelt schreiben.
async function reservePublishedResources(env:Env,tenantId:string,planId:string){
  const data=await env.DB.prepare('SELECT e.id,e.published_lesson_id,e.room FROM timetable_plan_entries e WHERE e.tenant_id=? AND e.plan_id=? AND e.published_lesson_id IS NOT NULL').bind(tenantId,planId).all<Record<string,unknown>>();
  const eintraege=data.results??[];
  if(!eintraege.length)return;
  const [mittelZeilen,raumZeilen]=await Promise.all([
    env.DB.prepare('SELECT entry_id,resource_id,quantity FROM timetable_plan_entry_resources WHERE tenant_id=? AND plan_id=?').bind(tenantId,planId).all<Record<string,unknown>>(),
    env.DB.prepare("SELECT id,name,code FROM planning_resources WHERE tenant_id=? AND resource_type='room' AND status='active'").bind(tenantId).all<Record<string,unknown>>(),
  ]);
  const jeTermin=new Map<string,Array<{resource_id:string;quantity:number}>>(),raumNachName=new Map<string,string>(),raumNachCode=new Map<string,string>();
  for(const m of mittelZeilen.results??[]){const k=String(m.entry_id),w={resource_id:String(m.resource_id),quantity:Number(m.quantity)||1},l=jeTermin.get(k);if(l)l.push(w);else jeTermin.set(k,[w]);}
  for(const r of raumZeilen.results??[]){const name=String(r.name??'').toLowerCase(),code=String(r.code??'').toLowerCase();if(name&&!raumNachName.has(name))raumNachName.set(name,String(r.id));if(code&&!raumNachCode.has(code))raumNachCode.set(code,String(r.id));}
  const ts=nowIso(),anweisungen:any[]=[];
  for(const e of eintraege){
    let resources=jeTermin.get(String(e.id))??[];
    if(!resources.length&&e.room){const schluessel=String(e.room).toLowerCase(),rid=raumNachName.get(schluessel)||raumNachCode.get(schluessel);if(rid)resources=[{resource_id:rid,quantity:1}];}
    for(const r of resources)anweisungen.push(env.DB.prepare('INSERT OR IGNORE INTO lesson_resource_reservations(tenant_id,lesson_id,resource_id,quantity,source_plan_id,created_at) VALUES(?,?,?,?,?,?)').bind(tenantId,String(e.published_lesson_id),r.resource_id,r.quantity||1,planId,ts));
  }
  await stapelSchreiben(env,anweisungen);
}
export async function publishAdvancedTimetablePlan(env:Env,auth:CoreAuthContext,tenantId:string,planId:string){const validation=await validateAdvancedTimetablePlan(env,auth,tenantId,planId);if(validation.errors)throw new Error('TIMETABLE_PLAN_HAS_CONFLICTS');const result=await publishTimetablePlan(env,auth,tenantId,planId);await reservePublishedResources(env,tenantId,planId);return{...result,validation};}

// Wann eine Dozentin oder ein Dozent arbeiten MOECHTE - fuer Honorarkraefte der eigentliche
// Planungsschluessel. Bewusst opt-in: wer kein Fenster angibt, wird geplant wie bisher. Erst wer
// mindestens eines angibt, wird ausschliesslich innerhalb seiner Fenster vorgeschlagen.
//
// Wochentag und Uhrzeit werden - wie im ganzen Planungsmodul - aus der Zeichenkette des Termins
// gelesen. Das ist dieselbe Rechnung, die auch die Kursregeln (earliest_start/latest_end) und die
// Konfliktpruefung verwenden; alles bleibt damit in einer einzigen, durchgaengigen Zeitrechnung.
function wochentag(iso:string){const d=new Date(iso);if(Number.isNaN(d.getTime()))throw new Error('DATE_INVALID');return((d.getUTCDay()+6)%7)+1;}
const AVAILABILITY_MAX_PER_TEACHER=200;
function zeitFeld(v:unknown,fehler:string){const t=safeString(v,5);if(!t||!/^\d\d:\d\d$/.test(t))throw new Error(fehler);return t;}
async function assertTeacherSelfOrManage(env:Env,auth:CoreAuthContext,tenantId:string,teacherId:string){
  if(admin(auth)||hasPermission(auth,'courses.manage'))return'admin' as const;
  const eigen=await env.DB.prepare(`SELECT 1 ok FROM teacher_portal_assignments WHERE tenant_id=? AND teacher_id=? AND user_id=? AND status='active' LIMIT 1`).bind(tenantId,teacherId,auth.userId).first();
  if(!eigen)throw new Error('FORBIDDEN_TEACHER_AVAILABILITY');
  return'teacher' as const;
}
export async function listTeacherAvailability(env:Env,auth:CoreAuthContext,tenantId:string,teacherId?:string){
  const gefiltert=safeString(teacherId,120);
  if(gefiltert)await assertTeacherSelfOrManage(env,auth,tenantId,gefiltert);
  else if(!admin(auth)&&!hasPermission(auth,'courses.manage'))throw new Error('FORBIDDEN_TEACHER_AVAILABILITY');
  const sql=`SELECT a.*,t.name teacher_name FROM teacher_availability a JOIN teachers t ON t.id=a.teacher_id AND t.tenant_id=a.tenant_id WHERE a.tenant_id=?${gefiltert?' AND a.teacher_id=?':''} ORDER BY t.name,a.weekday,a.starts_time`;
  const r=gefiltert?await env.DB.prepare(sql).bind(tenantId,gefiltert).all<Record<string,unknown>>():await env.DB.prepare(sql).bind(tenantId).all<Record<string,unknown>>();
  return r.results??[];
}
export async function saveTeacherAvailability(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const teacherId=required(input.teacher_id,120);
  const quelle=await assertTeacherSelfOrManage(env,auth,tenantId,teacherId);
  const vorhanden=await env.DB.prepare('SELECT 1 ok FROM teachers WHERE tenant_id=? AND id=?').bind(tenantId,teacherId).first();
  if(!vorhanden)throw new Error('TEACHER_NOT_FOUND');
  const weekday=Math.trunc(Number(input.weekday));
  if(!Number.isFinite(weekday)||weekday<1||weekday>7)throw new Error('AVAILABILITY_WEEKDAY_INVALID');
  const start=zeitFeld(input.starts_time,'AVAILABILITY_TIME_INVALID'),ende=zeitFeld(input.ends_time,'AVAILABILITY_TIME_INVALID');
  if(start>=ende)throw new Error('AVAILABILITY_TIME_INVALID');
  const von=safeString(input.valid_from,10)||null,bis=safeString(input.valid_until,10)||null;
  if(von&&bis&&von>bis)throw new Error('AVAILABILITY_PERIOD_INVALID');
  const praeferenz=String(input.preference||'available');
  if(!['available','preferred'].includes(praeferenz))throw new Error('AVAILABILITY_PREFERENCE_INVALID');
  const anzahl=Number((await env.DB.prepare('SELECT COUNT(*) n FROM teacher_availability WHERE tenant_id=? AND teacher_id=?').bind(tenantId,teacherId).first<{n:number}>())?.n||0);
  const eintragId=safeString(input.id,120)||'';
  if(!eintragId&&anzahl>=AVAILABILITY_MAX_PER_TEACHER)throw new Error('AVAILABILITY_TOO_MANY');
  const ts=nowIso();
  if(eintragId){
    const alt=await env.DB.prepare('SELECT teacher_id FROM teacher_availability WHERE tenant_id=? AND id=?').bind(tenantId,eintragId).first<{teacher_id:string}>();
    if(!alt)throw new Error('AVAILABILITY_NOT_FOUND');
    if(alt.teacher_id!==teacherId)throw new Error('AVAILABILITY_NOT_FOUND');
    await env.DB.prepare('UPDATE teacher_availability SET weekday=?,starts_time=?,ends_time=?,valid_from=?,valid_until=?,preference=?,note=?,updated_at=? WHERE tenant_id=? AND id=?')
      .bind(weekday,start,ende,von,bis,praeferenz,safeString(input.note,500)||null,ts,tenantId,eintragId).run();
    await audit(env.DB,auth.userId,'planning.teacher_availability_updated',tenantId,undefined,'teacher_availability',eintragId,{teacherId,weekday,quelle});
    return{availability_id:eintragId};
  }
  const neu=id('tav_');
  await env.DB.prepare('INSERT INTO teacher_availability(id,tenant_id,teacher_id,weekday,starts_time,ends_time,valid_from,valid_until,preference,note,source,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(neu,tenantId,teacherId,weekday,start,ende,von,bis,praeferenz,safeString(input.note,500)||null,quelle==='teacher'?'teacher':'admin',auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'planning.teacher_availability_added',tenantId,undefined,'teacher_availability',neu,{teacherId,weekday,quelle});
  return{availability_id:neu};
}
export async function deleteTeacherAvailability(env:Env,auth:CoreAuthContext,tenantId:string,availabilityId:string){
  const row=await env.DB.prepare('SELECT teacher_id FROM teacher_availability WHERE tenant_id=? AND id=?').bind(tenantId,availabilityId).first<{teacher_id:string}>();
  if(!row)throw new Error('AVAILABILITY_NOT_FOUND');
  await assertTeacherSelfOrManage(env,auth,tenantId,row.teacher_id);
  await env.DB.prepare('DELETE FROM teacher_availability WHERE tenant_id=? AND id=?').bind(tenantId,availabilityId).run();
  await audit(env.DB,auth.userId,'planning.teacher_availability_removed',tenantId,undefined,'teacher_availability',availabilityId,{teacherId:row.teacher_id});
  return{availability_id:availabilityId};
}

// Geleistete Stunden je Dozentin oder Dozent in einem Zeitraum - fuer Honorarkraefte die
// Grundlage ihrer Rechnung, fuer den Traeger die Kostenkontrolle.
//
// Getrennt ausgewiesen: was tatsaechlich stattgefunden hat (veroeffentlichter Unterricht) und
// was erst geplant ist (Entwuerfe). Beides in eine Zahl zu werfen waere eine Rechnung ueber
// Stunden, die es noch nicht gibt.
export async function teacherWorkloadSummary(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const von=safeString(input.from,10),bis=safeString(input.to,10);
  if(!von||!bis||!/^\d{4}-\d\d-\d\d$/.test(von)||!/^\d{4}-\d\d-\d\d$/.test(bis)||von>bis)throw new Error('WORKLOAD_PERIOD_INVALID');
  const gefiltert=safeString(input.teacher_id,120);
  if(gefiltert)await assertTeacherSelfOrManage(env,auth,tenantId,gefiltert);
  else if(!admin(auth)&&!hasPermission(auth,'courses.manage'))throw new Error('FORBIDDEN_TEACHER_WORKLOAD');
  const sql=`SELECT t.id teacher_id,t.name teacher_name,
      COALESCE(wr.max_weekly_minutes,0) max_weekly_minutes,
      (SELECT COALESCE(SUM((julianday(l.ends_at)-julianday(l.starts_at))*1440),0) FROM lessons l
        WHERE l.tenant_id=t.tenant_id AND l.teacher_id=t.id AND substr(l.starts_at,1,10) BETWEEN ?1 AND ?2) held_minutes,
      (SELECT COUNT(*) FROM lessons l WHERE l.tenant_id=t.tenant_id AND l.teacher_id=t.id AND substr(l.starts_at,1,10) BETWEEN ?1 AND ?2) held_lessons,
      (SELECT COALESCE(SUM((julianday(e.ends_at)-julianday(e.starts_at))*1440),0) FROM timetable_plan_entries e
        JOIN timetable_plan_versions v ON v.id=e.plan_id AND v.tenant_id=e.tenant_id
        WHERE e.tenant_id=t.tenant_id AND e.teacher_id=t.id AND v.status IN ('draft','review') AND substr(e.starts_at,1,10) BETWEEN ?1 AND ?2) planned_minutes
    FROM teachers t LEFT JOIN teacher_workload_rules wr ON wr.tenant_id=t.tenant_id AND wr.teacher_id=t.id
    WHERE t.tenant_id=?3${gefiltert?' AND t.id=?4':''} ORDER BY t.name`;
  const r=gefiltert?await env.DB.prepare(sql).bind(von,bis,tenantId,gefiltert).all<Record<string,unknown>>()
                   :await env.DB.prepare(sql).bind(von,bis,tenantId).all<Record<string,unknown>>();
  const zeilen=(r.results??[]).map(x=>({
    teacher_id:String(x.teacher_id),teacher_name:String(x.teacher_name||''),
    held_minutes:Math.round(Number(x.held_minutes||0)),held_lessons:Number(x.held_lessons||0),
    planned_minutes:Math.round(Number(x.planned_minutes||0)),
    max_weekly_minutes:Number(x.max_weekly_minutes||0)}));
  return{from:von,to:bis,rows:zeilen,
    held_minutes_total:zeilen.reduce((n,x)=>n+x.held_minutes,0),
    planned_minutes_total:zeilen.reduce((n,x)=>n+x.planned_minutes,0)};
}

// ---------------------------------------------------------------------------------------------
// Soll-Ist der Dozentenlast auf TATSAECHLICH gehaltenem Unterricht.
//
// Die vereinbarten Grenzen einer Person (teacher_workload_rules) wurden bisher ausschliesslich im
// Stundenplan-ENTWURF geprueft. Auf veroeffentlichte lessons und erst recht auf uebernommene
// Vertretungen wirkte keine einzige Regel. Eine ueberlastete Honorarkraft fiel deshalb erst auf,
// wenn sie ausfiel oder kuendigte - die Zahlen lagen die ganze Zeit im Portal, nur stellte sie
// niemand gegenueber.
//
// Gezaehlt wird, was stattgefunden hat:
//   + veroeffentlichter Unterricht (lessons.teacher_id)
//   + uebernommene Vertretungen: sie zaehlen beim VERTRETER und werden dem Ausgefallenen
//     abgezogen. Beides zu zaehlen waere die haeufigste stille Fehlerquelle einer solchen
//     Auswertung - die Stunde hat einmal stattgefunden, nicht zweimal.
//   - dokumentierte Abwesenheit (teacher_unavailability): eine Stunde, die im Kalender stehen
//     bleibt, waehrend die Person nachweislich krank oder im Urlaub war, hat nicht stattgefunden.
//     Deshalb wird sie nicht gestrichen, sondern zeitgenau beschnitten - eine Abwesenheit ab
//     10 Uhr laesst die ersten zwei Stunden des Vormittags bestehen.
//
// Das Soll ist das nach den Regeln ZULAESSIGE Volumen, nicht eine Erwartung: max_weekly_minutes
// je Kalenderwoche, angebrochene Wochen anteilig nach ihren Tagen im Zeitraum. Wer keine
// Wochengrenze vereinbart hat, bekommt kein Soll (null) statt einer erfundenen Zahl - seine
// Regelverstoesse werden trotzdem gemeldet.
const WORKLOAD_MAX_TAGE=366;
// Die Auswertung laedt den Unterricht des Zeitraums einmal vollstaendig. Eine stille Kuerzung
// waere hier besonders teuer: das Ergebnis saehe vollstaendig aus und waere falsch. Deshalb wird
// eine Ueberschreitung gemeldet, statt sie wegzuschneiden.
const WORKLOAD_MAX_ZEILEN=8000;
const WORKLOAD_MAX_MELDUNGEN=200;
function deutschesDatum(tag:string){return `${tag.slice(8,10)}.${tag.slice(5,7)}.${tag.slice(0,4)}`;}

// Ein Zeitblock, aus dem sich das Ist zusammensetzt: entweder eine gehaltene Unterrichtseinheit
// oder eine uebernommene Vertretung.
type Lastblock={starts_at:string;ends_at:string;quelle:'lesson'|'substitution';ref:string};

// Schneidet aus einem Zeitblock alle dokumentierten Abwesenheiten heraus. Uebrig bleibt, was
// wirklich stattgefunden haben kann - moeglicherweise nichts, moeglicherweise zwei Reste.
function ohneAbwesenheit(start:string,ende:string,sperren:Array<{s:string;e:string}>){
  let teile=[{s:start,e:ende}];
  for(const sp of sperren){
    if(!overlaps(start,ende,sp.s,sp.e))continue;
    const rest:Array<{s:string;e:string}>=[];
    for(const t of teile){
      if(!overlaps(t.s,t.e,sp.s,sp.e)){rest.push(t);continue;}
      if(t.s<sp.s)rest.push({s:t.s,e:sp.s});
      if(sp.e<t.e)rest.push({s:sp.e,e:t.e});
    }
    teile=rest;
    if(!teile.length)break;
  }
  return teile;
}

// Zwei unmittelbar aneinander liegende Unterrichtseinheiten sind EIN durchgehender Einsatz, keine
// Pause von null Minuten. Ohne dieses Zusammenlegen meldete jede Doppelstunde eine unterschrittene
// Mindestpause - die Auswertung waere im Rauschen untergegangen.
function zusammenhaengend(teile:Array<{s:string;e:string}>,luecke:number){
  const sortiert=[...teile].sort((a,b)=>a.s<b.s?-1:a.s>b.s?1:0),aus:Array<{s:string;e:string}>=[];
  for(const t of sortiert){
    const letzter=aus[aus.length-1];
    if(letzter&&minutes(letzter.e,t.s)<luecke){if(t.e>letzter.e)letzter.e=t.e;}
    else aus.push({s:t.s,e:t.e});
  }
  return aus;
}

export async function teacherWorkloadBalance(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const von=safeString(input.from,10),bis=safeString(input.to,10);
  if(!von||!bis||!/^\d{4}-\d\d-\d\d$/.test(von)||!/^\d{4}-\d\d-\d\d$/.test(bis)||von>bis)throw new Error('WORKLOAD_PERIOD_INVALID');
  const spanne=Math.round((Date.parse(`${bis}T00:00:00.000Z`)-Date.parse(`${von}T00:00:00.000Z`))/86400000)+1;
  if(!Number.isFinite(spanne)||spanne>WORKLOAD_MAX_TAGE)throw new Error('WORKLOAD_PERIOD_TOO_LONG');
  // Dieselbe Zugangsregel wie bei der Stundenuebersicht: die eigenen Stunden sieht die Person
  // selbst, die Uebersicht ueber alle nur die Planungsverwaltung.
  const gefiltert=safeString(input.teacher_id,120)||null;
  if(gefiltert)await assertTeacherSelfOrManage(env,auth,tenantId,gefiltert);
  else if(!admin(auth)&&!hasPermission(auth,'courses.manage'))throw new Error('FORBIDDEN_TEACHER_WORKLOAD');
  // Die Tagesaufteilung derselben Minuten - dieselbe Rechnung, nur nicht zur Summe verdichtet.
  // Die Honorarabrechnung braucht sie, weil ein Stundensatz zum Monatsersten wechseln kann: ohne
  // Tag laesst sich nicht sagen, welche Minute noch zum alten und welche schon zum neuen Satz
  // gehoert. Sie wird nur auf Anforderung mitgeliefert, damit die Uebersicht im Portal - die sie
  // nicht braucht - nicht bei jedem Aufruf hunderte Tagesfaecher mitschleppt.
  const mitTagen=input.include_daily===true;
  const vonIso=`${von}T00:00:00.000Z`,bisIso=`${bis}T23:59:59.999Z`,grenze=WORKLOAD_MAX_ZEILEN+1;

  // Vier Abfragen - unabhaengig davon, ob der Mandant drei oder dreihundert Dozentinnen und
  // Dozenten hat. Je Person zu fragen waere bei einem Jahreszeitraum genau die Bauart, an der die
  // erweiterte Planungspruefung schon einmal in die Unteranfragen-Grenze gelaufen ist.
  const [personen,stunden,vertretungen,abwesenheiten]=await Promise.all([
    env.DB.prepare(`SELECT t.id teacher_id,t.name teacher_name,
        wr.max_daily_minutes,wr.max_weekly_minutes,wr.max_consecutive_minutes,wr.min_break_minutes
      FROM teachers t LEFT JOIN teacher_workload_rules wr ON wr.tenant_id=t.tenant_id AND wr.teacher_id=t.id
      WHERE t.tenant_id=?1 AND (?2 IS NULL OR t.id=?2) ORDER BY t.name`).bind(tenantId,gefiltert).all<Record<string,unknown>>(),
    env.DB.prepare(`SELECT l.id,l.teacher_id,l.starts_at,l.ends_at FROM lessons l
      WHERE l.tenant_id=?1 AND l.teacher_id IS NOT NULL AND substr(l.starts_at,1,10) BETWEEN ?2 AND ?3
        AND (?4 IS NULL OR l.teacher_id=?4 OR l.id IN (SELECT sc.lesson_id FROM substitution_cases sc
          WHERE sc.tenant_id=?1 AND sc.lesson_id IS NOT NULL AND sc.substitute_teacher_id=?4))
      ORDER BY l.starts_at LIMIT ?5`).bind(tenantId,von,bis,gefiltert,grenze).all<Record<string,unknown>>(),
    // Uebernommen heisst: es steht eine Vertretung fest. Ein noch offener Fall ('open') hat
    // niemanden gefunden - dessen Stunde bleibt beim Ausgefallenen, damit die Luecke sichtbar
    // bleibt statt sich stillschweigend in Luft aufzuloesen.
    env.DB.prepare(`SELECT sc.lesson_id,sc.substitute_teacher_id,sc.replacement_starts_at,sc.replacement_ends_at,
        l.starts_at lesson_starts_at,l.ends_at lesson_ends_at,l.teacher_id lesson_teacher_id
      FROM substitution_cases sc
      LEFT JOIN lessons l ON l.id=sc.lesson_id AND l.tenant_id=sc.tenant_id
      WHERE sc.tenant_id=?1 AND sc.substitute_teacher_id IS NOT NULL
        AND sc.status IN ('assigned','rescheduled','completed')
        AND (substr(COALESCE(sc.replacement_starts_at,l.starts_at),1,10) BETWEEN ?2 AND ?3
          OR substr(l.starts_at,1,10) BETWEEN ?2 AND ?3)
        AND (?4 IS NULL OR sc.substitute_teacher_id=?4 OR l.teacher_id=?4)
      ORDER BY sc.updated_at LIMIT ?5`).bind(tenantId,von,bis,gefiltert,grenze).all<Record<string,unknown>>(),
    env.DB.prepare(`SELECT u.teacher_id,u.starts_at,u.ends_at FROM teacher_unavailability u
      WHERE u.tenant_id=?1 AND u.starts_at<?2 AND u.ends_at>?3 AND (?4 IS NULL OR u.teacher_id=?4)
      ORDER BY u.starts_at LIMIT ?5`).bind(tenantId,bisIso,vonIso,gefiltert,grenze).all<Record<string,unknown>>(),
  ]);
  const stundenZeilen=stunden.results??[],vertretungsZeilen=vertretungen.results??[],abwesenheitsZeilen=abwesenheiten.results??[];
  if(stundenZeilen.length>WORKLOAD_MAX_ZEILEN||vertretungsZeilen.length>WORKLOAD_MAX_ZEILEN||abwesenheitsZeilen.length>WORKLOAD_MAX_ZEILEN)throw new Error('WORKLOAD_RANGE_TOO_LARGE');

  // Erst die Vertretungen: sie entscheiden, wem eine Stunde ueberhaupt zugerechnet wird.
  const uebernommen=new Set<string>(),bloecke=new Map<string,Lastblock[]>();
  const anfuegen=(teacherId:string,block:Lastblock)=>{const l=bloecke.get(teacherId);if(l)l.push(block);else bloecke.set(teacherId,[block]);};
  for(const v of vertretungsZeilen){
    const lessonId=v.lesson_id?String(v.lesson_id):'';
    if(lessonId)uebernommen.add(lessonId);
    // Ein verlegter Ersatztermin braucht Beginn UND Ende, sonst wird die Stunde am urspruenglichen
    // Termin gezaehlt - halb verlegte Zeiten ergaeben sonst eine Dauer von Stunden oder Minus.
    const verlegt=Boolean(v.replacement_starts_at&&v.replacement_ends_at);
    const start=verlegt?String(v.replacement_starts_at):String(v.lesson_starts_at??''),
      ende=verlegt?String(v.replacement_ends_at):String(v.lesson_ends_at??'');
    if(!start||!ende||start>=ende)continue;
    const tag=dateKey(start);
    if(tag<von||tag>bis)continue;
    anfuegen(String(v.substitute_teacher_id),{starts_at:start,ends_at:ende,quelle:'substitution',ref:lessonId});
  }
  for(const l of stundenZeilen){
    if(uebernommen.has(String(l.id)))continue;
    anfuegen(String(l.teacher_id),{starts_at:String(l.starts_at),ends_at:String(l.ends_at),quelle:'lesson',ref:String(l.id)});
  }
  const sperren=new Map<string,Array<{s:string;e:string}>>();
  for(const a of abwesenheitsZeilen){const k=String(a.teacher_id),w={s:String(a.starts_at),e:String(a.ends_at)},l=sperren.get(k);if(l)l.push(w);else sperren.set(k,[w]);}

  // Das zulaessige Volumen je Kalenderwoche. Eine angebrochene Woche zaehlt anteilig nach ihren
  // Tagen im Zeitraum - sonst bekaeme ein Zeitraum von Freitag bis Montag zwei volle Wochendeputate
  // und jede Auswertung ueber einen Monatsrand hinweg meldete eine Unterdeckung, die es nicht gibt.
  const wochenTage=new Map<string,number>();
  for(let t=Date.parse(`${von}T00:00:00.000Z`);t<=Date.parse(`${bis}T00:00:00.000Z`);t+=86400000){
    const w=mondayKey(new Date(t).toISOString());wochenTage.set(w,(wochenTage.get(w)||0)+1);
  }

  const zeilen=(personen.results??[]).map(p=>{
    const teacherId=String(p.teacher_id),eigene=bloecke.get(teacherId)??[],eigeneSperren=sperren.get(teacherId)??[];
    const maxTag=p.max_daily_minutes===null||p.max_daily_minutes===undefined?null:Number(p.max_daily_minutes),
      maxWoche=p.max_weekly_minutes===null||p.max_weekly_minutes===undefined?null:Number(p.max_weekly_minutes),
      maxAmStueck=p.max_consecutive_minutes===null||p.max_consecutive_minutes===undefined?null:Number(p.max_consecutive_minutes),
      minPause=p.min_break_minutes===null||p.min_break_minutes===undefined?null:Number(p.min_break_minutes);
    let unterrichtMinuten=0,vertretungMinuten=0,abgezogen=0;
    const gehalten:Array<{s:string;e:string;quelle:'lesson'|'substitution'}>=[],stundenIds=new Set<string>(),vertretungIds=new Set<string>();
    for(const b of eigene){
      const brutto=minutes(b.starts_at,b.ends_at),teile=ohneAbwesenheit(b.starts_at,b.ends_at,eigeneSperren);
      let netto=0;
      // Die Herkunft bleibt am beschnittenen Rest haengen: eine halb in eine Krankmeldung
      // gefallene Vertretung ist mit ihrem Rest immer noch eine Vertretung und wird spaeter
      // moeglicherweise anders verguetet als eigener Unterricht.
      for(const t of teile){netto+=minutes(t.s,t.e);gehalten.push({...t,quelle:b.quelle});}
      abgezogen+=brutto-netto;
      if(!netto)continue;
      if(b.quelle==='substitution'){vertretungMinuten+=netto;vertretungIds.add(b.ref||`${b.starts_at}|${b.ends_at}`);}
      else{unterrichtMinuten+=netto;stundenIds.add(b.ref);}
    }
    const {tage,wochen}=lastNachTagUndWoche(gehalten.map(t=>({starts_at:t.s,ends_at:t.e})));
    const ist=unterrichtMinuten+vertretungMinuten;
    let soll:number|null=null;
    if(maxWoche!==null&&maxWoche>0){let summe=0;for(const [,anzahl] of wochenTage)summe+=maxWoche*anzahl/7;soll=Math.round(summe);}

    // Was gerissen wurde - mit dem konkreten Tag bzw. der konkreten Woche. Eine Zahl ohne Datum
    // liesse sich nicht nachpruefen und damit auch nicht abstellen.
    const meldungen:Array<{rule:string;date:string|null;week:string|null;actual_minutes:number;limit_minutes:number;message:string}>=[];
    if(maxTag!==null&&maxTag>0)for(const [tag,summe] of [...tage].sort((a,b)=>a[0]<b[0]?-1:1))if(summe>maxTag)
      meldungen.push({rule:'daily_limit',date:tag,week:null,actual_minutes:summe,limit_minutes:maxTag,
        message:`Am ${deutschesDatum(tag)} wurden ${summe} Minuten unterrichtet; vereinbart sind höchstens ${maxTag} Minuten am Tag.`});
    if(maxWoche!==null&&maxWoche>0)for(const [woche,summe] of [...wochen].sort((a,b)=>a[0]<b[0]?-1:1))if(summe>maxWoche)
      meldungen.push({rule:'weekly_limit',date:null,week:woche,actual_minutes:summe,limit_minutes:maxWoche,
        message:`In der Woche ab ${deutschesDatum(woche)} wurden ${summe} Minuten unterrichtet; vereinbart sind höchstens ${maxWoche} Minuten in der Woche.`});
    if((maxAmStueck!==null&&maxAmStueck>0)||(minPause!==null&&minPause>0)){
      const jeTag=new Map<string,Array<{s:string;e:string}>>();
      for(const t of gehalten){const k=dateKey(t.s),l=jeTag.get(k);if(l)l.push(t);else jeTag.set(k,[t]);}
      for(const [tag,teile] of [...jeTag].sort((a,b)=>a[0]<b[0]?-1:1)){
        const einsaetze=zusammenhaengend(teile,1);
        // Eine Pause, die kuerzer ist als vereinbart, ist keine Pause: die beiden Einsaetze
        // zaehlen dann als ein durchgehender Einsatz. Genau davor schuetzt max_consecutive_minutes.
        if(minPause!==null&&minPause>0)for(let i=1;i<einsaetze.length;i++){
          const luecke=minutes(einsaetze[i-1].e,einsaetze[i].s);
          if(luecke<minPause)meldungen.push({rule:'min_break',date:tag,week:null,actual_minutes:luecke,limit_minutes:minPause,
            message:`Am ${deutschesDatum(tag)} lagen zwischen zwei Einsätzen nur ${luecke} Minuten Pause (${localTime(einsaetze[i-1].e)}–${localTime(einsaetze[i].s)} Uhr); vereinbart sind mindestens ${minPause} Minuten.`});
        }
        if(maxAmStueck!==null&&maxAmStueck>0)for(const stueck of zusammenhaengend(einsaetze,Math.max(1,minPause??1))){
          const dauer=minutes(stueck.s,stueck.e);
          if(dauer>maxAmStueck)meldungen.push({rule:'consecutive_limit',date:tag,week:null,actual_minutes:dauer,limit_minutes:maxAmStueck,
            message:`Am ${deutschesDatum(tag)} lagen ${dauer} Minuten Unterricht am Stück (${localTime(stueck.s)}–${localTime(stueck.e)} Uhr); vereinbart sind höchstens ${maxAmStueck} Minuten ohne ausreichende Pause.`});
        }
      }
    }
    const abwesenheitsTage=new Set<string>();
    for(const s of eigeneSperren)for(let t=Date.parse(dateKey(s.s)+'T00:00:00.000Z');t<=Date.parse(dateKey(s.e)+'T00:00:00.000Z');t+=86400000){
      const tag=new Date(t).toISOString().slice(0,10);if(tag>=von&&tag<=bis)abwesenheitsTage.add(tag);
    }
    // Ein Einsatz zaehlt an dem Tag, an dem er BEGINNT - dieselbe Zuordnung, die auch die
    // Tagesgrenze prueft. Zwei Zaehlweisen nebeneinander waeren die sichere Quelle dafuer, dass
    // Abrechnung und Regelpruefung ueber Mitternacht hinweg verschiedene Tage meinen.
    const jeTagUndArt=new Map<string,{lesson:number;substitution:number}>();
    if(mitTagen)for(const t of gehalten){
      const k=dateKey(t.s);let f=jeTagUndArt.get(k);
      if(!f){f={lesson:0,substitution:0};jeTagUndArt.set(k,f);}
      if(t.quelle==='substitution')f.substitution+=minutes(t.s,t.e);else f.lesson+=minutes(t.s,t.e);
    }
    const tagesZeilen=[...jeTagUndArt].sort((a,b)=>a[0]<b[0]?-1:1)
      .map(([datum,f])=>({date:datum,lesson_minutes:f.lesson,substitution_minutes:f.substitution}));
    return{teacher_id:teacherId,teacher_name:String(p.teacher_name||''),
      ...(mitTagen?{daily:tagesZeilen}:{}),
      has_rules:maxTag!==null||maxWoche!==null||maxAmStueck!==null||minPause!==null,
      max_daily_minutes:maxTag,max_weekly_minutes:maxWoche,max_consecutive_minutes:maxAmStueck,min_break_minutes:minPause,
      allowed_minutes:soll,held_minutes:ist,lesson_minutes:unterrichtMinuten,substitution_minutes:vertretungMinuten,
      held_lessons:stundenIds.size,substitution_count:vertretungIds.size,
      absence_deducted_minutes:abgezogen,unavailable_days:abwesenheitsTage.size,
      balance_minutes:soll===null?null:ist-soll,
      coverage_percent:soll===null||soll===0?null:Math.round(ist/soll*1000)/10,
      breach_count:meldungen.length,breaches:meldungen.slice(0,WORKLOAD_MAX_MELDUNGEN)};
  });
  return{from:von,to:bis,weeks:wochenTage.size,rows:zeilen,
    held_minutes_total:zeilen.reduce((n,x)=>n+x.held_minutes,0),
    allowed_minutes_total:zeilen.reduce((n,x)=>n+(x.allowed_minutes??0),0),
    substitution_minutes_total:zeilen.reduce((n,x)=>n+x.substitution_minutes,0),
    absence_deducted_minutes_total:zeilen.reduce((n,x)=>n+x.absence_deducted_minutes,0),
    breach_count:zeilen.reduce((n,x)=>n+x.breach_count,0),
    teachers_with_breaches:zeilen.filter(x=>x.breach_count>0).length};
}

export async function planningSuggestions(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){requireManage(auth);const courseId=required(input.course_id,120),starts=iso(input.starts_at),ends=iso(input.ends_at),subjectId=optional(input.subject_id,120);courseScope(auth,courseId);if(!starts||!ends||starts>=ends)throw new Error('SUGGESTION_TIME_INVALID');
  const tag=wochentag(starts),zeitVon=localTime(starts),zeitBis=localTime(ends),datum=dateKey(starts);
  // Die Auslastung zaehlt Unterricht UND Entwuerfe: sonst waere die vereinbarte Grenze einer
  // Honorarkraft schon ueberschritten, bevor der Entwurf ueberhaupt veroeffentlicht ist.
  const montag=new Date(starts);montag.setUTCDate(montag.getUTCDate()-((montag.getUTCDay()+6)%7));
  const sonntag=new Date(montag);sonntag.setUTCDate(sonntag.getUTCDate()+6);
  const wocheVon=montag.toISOString().slice(0,10),wocheBis=sonntag.toISOString().slice(0,10);
  const dauer=Math.max(0,Math.round((Date.parse(ends)-Date.parse(starts))/60000));
  const participantCount=Number((await env.DB.prepare("SELECT COUNT(DISTINCT user_id) n FROM memberships WHERE tenant_id=? AND course_id=? AND role IN ('participant','class_admin')").bind(tenantId,courseId).first<{n:number}>())?.n||0);
  const teachers=(await env.DB.prepare(`SELECT t.id,t.name,t.email,
    CASE WHEN ? IS NOT NULL AND EXISTS(SELECT 1 FROM teacher_qualifications q WHERE q.tenant_id=t.tenant_id AND q.teacher_id=t.id AND q.subject_id=? AND q.status='valid' AND (q.valid_until IS NULL OR q.valid_until>=date('now'))) THEN 1 ELSE 0 END qualified,
    (SELECT COUNT(*) FROM lessons l WHERE l.tenant_id=t.tenant_id AND l.teacher_id=t.id AND l.course_id=?) familiarity,
    COALESCE(wr.max_daily_minutes,0) max_daily_minutes,COALESCE(wr.max_weekly_minutes,0) max_weekly_minutes,
    (SELECT COALESCE(SUM((julianday(l.ends_at)-julianday(l.starts_at))*1440),0) FROM lessons l WHERE l.tenant_id=t.tenant_id AND l.teacher_id=t.id AND substr(l.starts_at,1,10)=?)
    +(SELECT COALESCE(SUM((julianday(e.ends_at)-julianday(e.starts_at))*1440),0) FROM timetable_plan_entries e JOIN timetable_plan_versions v ON v.id=e.plan_id AND v.tenant_id=e.tenant_id
      WHERE e.tenant_id=t.tenant_id AND e.teacher_id=t.id AND v.status IN ('draft','review') AND substr(e.starts_at,1,10)=? AND NOT(e.course_id=? AND e.starts_at=? AND e.ends_at=?)) day_minutes,
    (SELECT COALESCE(SUM((julianday(l.ends_at)-julianday(l.starts_at))*1440),0) FROM lessons l WHERE l.tenant_id=t.tenant_id AND l.teacher_id=t.id AND substr(l.starts_at,1,10) BETWEEN ? AND ?)
    +(SELECT COALESCE(SUM((julianday(e.ends_at)-julianday(e.starts_at))*1440),0) FROM timetable_plan_entries e JOIN timetable_plan_versions v ON v.id=e.plan_id AND v.tenant_id=e.tenant_id
      WHERE e.tenant_id=t.tenant_id AND e.teacher_id=t.id AND v.status IN ('draft','review') AND substr(e.starts_at,1,10) BETWEEN ? AND ? AND NOT(e.course_id=? AND e.starts_at=? AND e.ends_at=?)) week_minutes,
    (SELECT COALESCE(MAX(CASE WHEN av.preference='preferred' THEN 1 ELSE 0 END),0) FROM teacher_availability av
      WHERE av.tenant_id=t.tenant_id AND av.teacher_id=t.id AND av.weekday=? AND av.starts_time<=? AND av.ends_time>=?
        AND (av.valid_from IS NULL OR av.valid_from<=?) AND (av.valid_until IS NULL OR av.valid_until>=?)) preferred
    FROM teachers t LEFT JOIN teacher_workload_rules wr ON wr.tenant_id=t.tenant_id AND wr.teacher_id=t.id WHERE t.tenant_id=?
      AND NOT EXISTS(SELECT 1 FROM teacher_unavailability u WHERE u.tenant_id=t.tenant_id AND u.teacher_id=t.id AND u.starts_at<? AND u.ends_at>?)
      AND NOT EXISTS(SELECT 1 FROM lessons l WHERE l.tenant_id=t.tenant_id AND l.teacher_id=t.id AND l.starts_at<? AND l.ends_at>?)
      AND NOT EXISTS(SELECT 1 FROM timetable_plan_entries e JOIN timetable_plan_versions v ON v.id=e.plan_id AND v.tenant_id=e.tenant_id
        WHERE e.tenant_id=t.tenant_id AND e.teacher_id=t.id AND v.status IN ('draft','review') AND e.starts_at<? AND e.ends_at>?
          AND NOT(e.course_id=? AND e.starts_at=? AND e.ends_at=?))
      AND (NOT EXISTS(SELECT 1 FROM teacher_availability av WHERE av.tenant_id=t.tenant_id AND av.teacher_id=t.id)
        OR EXISTS(SELECT 1 FROM teacher_availability av WHERE av.tenant_id=t.tenant_id AND av.teacher_id=t.id
          AND av.weekday=? AND av.starts_time<=? AND av.ends_time>=?
          AND (av.valid_from IS NULL OR av.valid_from<=?) AND (av.valid_until IS NULL OR av.valid_until>=?)))
    ORDER BY qualified DESC,
      CASE WHEN (max_daily_minutes>0 AND day_minutes+?>max_daily_minutes) OR (max_weekly_minutes>0 AND week_minutes+?>max_weekly_minutes) THEN 1 ELSE 0 END ASC,
      preferred DESC,familiarity DESC,day_minutes ASC,t.name LIMIT 20`).bind(subjectId,subjectId,courseId,datum,datum,courseId,starts,ends,wocheVon,wocheBis,wocheVon,wocheBis,courseId,starts,ends,tag,zeitVon,zeitBis,datum,datum,tenantId,ends,starts,ends,starts,ends,starts,courseId,starts,ends,tag,zeitVon,zeitBis,datum,datum,dauer,dauer).all<Record<string,unknown>>()).results??[];
  const rooms=(await env.DB.prepare(`SELECT r.id,r.name,r.code,r.location,r.capacity,r.features_json FROM planning_resources r WHERE r.tenant_id=? AND r.resource_type='room' AND r.status='active' AND (r.capacity IS NULL OR r.capacity>=?) AND NOT EXISTS(SELECT 1 FROM planning_resource_unavailability u WHERE u.tenant_id=r.tenant_id AND u.resource_id=r.id AND u.starts_at<? AND u.ends_at>?) AND NOT EXISTS(SELECT 1 FROM lesson_resource_reservations rr JOIN lessons l ON l.id=rr.lesson_id AND l.tenant_id=rr.tenant_id WHERE rr.tenant_id=r.tenant_id AND rr.resource_id=r.id AND l.starts_at<? AND l.ends_at>?) AND NOT EXISTS(SELECT 1 FROM timetable_plan_entries e JOIN timetable_plan_versions v ON v.id=e.plan_id AND v.tenant_id=e.tenant_id LEFT JOIN timetable_plan_entry_resources pr ON pr.tenant_id=e.tenant_id AND pr.entry_id=e.id WHERE e.tenant_id=r.tenant_id AND v.status IN ('draft','review') AND e.starts_at<? AND e.ends_at>? AND (pr.resource_id=r.id OR lower(COALESCE(e.room,''))=lower(r.name) OR (r.code IS NOT NULL AND r.code<>'' AND lower(COALESCE(e.room,''))=lower(r.code))) AND NOT(e.course_id=? AND e.starts_at=? AND e.ends_at=?)) ORDER BY CASE WHEN r.capacity IS NULL THEN 999999 ELSE r.capacity END,r.name LIMIT 20`).bind(tenantId,participantCount,ends,starts,ends,starts,ends,starts,courseId,starts,ends).all<Record<string,unknown>>()).results??[];const teachersMitLast=teachers.map(t=>{
    const tag=Number(t.max_daily_minutes||0),woche=Number(t.max_weekly_minutes||0);
    const ueberTag=tag>0&&Number(t.day_minutes||0)+dauer>tag,ueberWoche=woche>0&&Number(t.week_minutes||0)+dauer>woche;
    return{...t,over_limit:ueberTag||ueberWoche?1:0,over_limit_reason:ueberTag?'DAILY':ueberWoche?'WEEKLY':null};
  });
  return{teachers:teachersMitLast,rooms,participant_count:participantCount};}

// Erzeugt aus den hinterlegten Kursregeln einen vollstaendigen Stundenplanentwurf.
// Bewusst nur ein Entwurf: es wird nichts veroeffentlicht, nichts im laufenden
// Betrieb veraendert. Wo keine freie Person oder kein freier Raum gefunden wird,
// entsteht KEIN Termin - die Luecke wird benannt, damit sie jemand entscheidet.
// Cloudflare begrenzt die Zahl der Unteranfragen je Aufruf; jede Datenbankabfrage zaehlt dazu.
// Gemessen kostet ein erzeugter Termin rund 12 Abfragen, ein uebersprungener Tag rund 2. Mit einer
// starren Obergrenze von 500 Terminen waere der Lauf mitten im Schreiben abgebrochen worden - der
// Entwurf bliebe halb befuellt liegen, ohne dass jemand sagen koennte, wo. Deshalb rechnet der Lauf
// sein eigenes Budget mit und hoert vorher auf. Ein erneuter Lauf setzt fort, weil bereits belegte
// Tage uebersprungen werden.
const AUTOFILL_MAX_DAYS=400;
// Das Abfragebudget eines Laufs. Gemessen, nicht geschaetzt: ein Vorschlag kostet drei Abfragen,
// das Anlegen eines Termins samt Raumbindung sieben. Beides ist hier mit einer Reserve versehen.
// Das blosse Durchgehen des Kalenders kostet nichts mehr - genau daran scheiterte der Lauf frueher:
// bei einem Schuljahr ging das ganze Budget fuer die Tagesabfragen drauf, der Lauf blieb im ersten
// Kurs stecken und meldete auch dann noch "Obergrenze erreicht", wenn er gar nichts mehr schaffte.
const AUTOFILL_ABFRAGE_BUDGET=850,AUTOFILL_KOSTEN_VORSCHLAG=4,AUTOFILL_KOSTEN_ANLAGE=8;
function tagSchluessel(d:Date){return d.toISOString().slice(0,10);}
function uhrzeit(v:unknown,fallback:string){const s=safeString(v,5);return s&&/^\d\d:\d\d$/.test(s)?s:fallback;}
export async function autofillTimetablePlan(env:Env,auth:CoreAuthContext,tenantId:string,planId:string,input:Record<string,unknown>){
  requireManage(auth);
  const plan=await env.DB.prepare('SELECT starts_on,ends_on,status FROM timetable_plan_versions WHERE tenant_id=? AND id=?').bind(tenantId,planId).first<{starts_on:string;ends_on:string;status:string}>();
  if(!plan)throw new Error('TIMETABLE_PLAN_NOT_FOUND');
  if(plan.status==='published'||plan.status==='archived')throw new Error('TIMETABLE_PLAN_LOCKED');
  const gewuenscht=Array.isArray(input.course_ids)?[...new Set(input.course_ids.map(x=>safeString(x,120)).filter((x):x is string=>!!x))]:[];
  const alle=(await env.DB.prepare(`SELECT c.id,c.name,r.earliest_start,r.latest_end,r.default_lesson_minutes,r.allow_saturday,r.allow_sunday
    FROM courses c JOIN course_scheduling_rules r ON r.tenant_id=c.tenant_id AND r.course_id=c.id
    WHERE c.tenant_id=? ORDER BY c.name`).bind(tenantId).all<Record<string,unknown>>()).results??[];
  // Ohne ausdrueckliche Liste plant der Lauf, was die aufrufende Person verantwortet - eine
  // Stundenplanung mit begrenztem Bereich koennte sonst nie ohne Liste starten, weil die erste
  // fremde Klasse den ganzen Lauf abbraeche. Wird eine Klasse ausdruecklich genannt, gilt
  // weiterhin: fehlt die Berechtigung, bricht der Lauf ab, statt sie still zu uebergehen.
  const kurse=gewuenscht.length?alle.filter(k=>gewuenscht.includes(String(k.id)))
    :alle.filter(k=>admin(auth)||auth.courseIds.includes(String(k.id)));
  if(gewuenscht.length)for(const k of kurse)courseScope(auth,String(k.id));
  if(!kurse.length)throw new Error('PLAN_AUTOFILL_NO_RULES');
  const von=new Date(`${plan.starts_on}T00:00:00Z`),bis=new Date(`${plan.ends_on}T00:00:00Z`);
  if(Number.isNaN(von.getTime())||Number.isNaN(bis.getTime())||von>bis)throw new Error('PLAN_RANGE_INVALID');
  if((bis.getTime()-von.getTime())/86400000>AUTOFILL_MAX_DAYS)throw new Error('PLAN_RANGE_TOO_LONG');
  let erzeugt=0,budget=0;const luecken:Array<{course_id:string;course_name:string;date:string;reason:string}>=[];
  // Sperrzeiten und bereits verplante Tage einmal laden statt je Tag zu fragen.
  const vonIso=`${plan.starts_on}T00:00:00.000Z`,bisIso=`${plan.ends_on}T23:59:59.999Z`;
  const [sperrZeilen,belegtZeilen]=await Promise.all([
    env.DB.prepare('SELECT course_id,title,starts_at,ends_at FROM planning_blackouts WHERE tenant_id=? AND blocks_teaching=1 AND starts_at<? AND ends_at>?').bind(tenantId,bisIso,vonIso).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT course_id,substr(starts_at,1,10) tag FROM timetable_plan_entries WHERE tenant_id=? AND plan_id=? GROUP BY course_id,substr(starts_at,1,10)').bind(tenantId,planId).all<Record<string,unknown>>(),
  ]);
  const sperrFach=new Map<string,Record<string,unknown>[]>(),belegteTage=new Map<string,Set<string>>();
  for(const b of sperrZeilen.results??[])inFaecher(sperrFach,String(b.starts_at),String(b.ends_at),b);
  for(const b of belegtZeilen.results??[]){const k=String(b.course_id),t=belegteTage.get(k);if(t)t.add(String(b.tag));else belegteTage.set(k,new Set([String(b.tag)]));}
  // Wo der vorige Lauf aufgehoert hat. Ohne diesen Merker begaenne jeder Lauf wieder von vorn -
  // und Tage, an denen sich nichts planen laesst (kein freier Raum, keine freie Person), wuerden
  // in jedem Lauf erneut geprueft. Bei genuegend solchen Tagen ginge das ganze Budget dafuer drauf
  // und der Kunde klickte ewig weiter, ohne dass je ein Termin dazukaeme. Mit dem Merker geht
  // jeder Lauf ein Stueck weiter, und die Folge endet garantiert.
  let fortsetzenKurs=safeString(input.resume_course_id,120)||'';
  const fortsetzenTag=safeString(input.resume_date,10)||'';
  if(fortsetzenKurs&&!kurse.some(k=>String(k.id)===fortsetzenKurs))fortsetzenKurs='';
  let ueberspringen=Boolean(fortsetzenKurs),naechsterKurs='',naechsterTag='';
  if(!fortsetzenKurs)for(const gewollt of gewuenscht)if(!kurse.some(k=>String(k.id)===gewollt)){
    courseScope(auth,gewollt);
    const name=await env.DB.prepare('SELECT name FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,gewollt).first<{name:string}>();
    luecken.push({course_id:gewollt,course_name:String(name?.name||''),date:plan.starts_on,reason:name?'NO_COURSE_RULES':'COURSE_NOT_FOUND'});
  }
  const proKurs=new Map<string,number>();
  for(const k of kurse){
    if(naechsterKurs)break;
    const kursId=String(k.id),kursName=String(k.name||''),
      beginn=uhrzeit(k.earliest_start,'08:00'),dauer=Math.max(15,Math.min(600,Number(k.default_lesson_minutes||0)||90));
    if(ueberspringen&&kursId!==fortsetzenKurs)continue;
    const [bh,bm]=beginn.split(':').map(Number),endeMinuten=bh*60+bm+dauer;
    if(endeMinuten>=24*60){luecken.push({course_id:kursId,course_name:kursName,date:plan.starts_on,reason:'LESSON_EXCEEDS_DAY'});continue;}
    const ende=`${String(Math.floor(endeMinuten/60)).padStart(2,'0')}:${String(endeMinuten%60).padStart(2,'0')}`;
    if(k.latest_end&&ende>String(k.latest_end)){luecken.push({course_id:kursId,course_name:kursName,date:plan.starts_on,reason:'LESSON_AFTER_LATEST_END'});continue;}
    proKurs.set(kursId,0);
    for(let d=new Date(von.getTime());d<=bis;d.setUTCDate(d.getUTCDate()+1)){
      const dow=d.getUTCDay(),datum=tagSchluessel(d);
      if(ueberspringen){if(datum<fortsetzenTag)continue;ueberspringen=false;}
      if(budget>=AUTOFILL_ABFRAGE_BUDGET){naechsterKurs=kursId;naechsterTag=datum;break;}
      if(dow===6&&!Number(k.allow_saturday))continue;
      if(dow===0&&!Number(k.allow_sunday))continue;
      const start=`${datum}T${beginn}:00.000Z`,schluss=`${datum}T${ende}:00.000Z`;
      if(belegteTage.get(kursId)?.has(datum))continue;
      if(ausFaechern(sperrFach,start,schluss).some(b=>(b.course_id===null||b.course_id===undefined||String(b.course_id)===kursId)&&overlaps(start,schluss,String(b.starts_at),String(b.ends_at))))continue;
      budget+=AUTOFILL_KOSTEN_VORSCHLAG;
      const vorschlag=await planningSuggestions(env,auth,tenantId,{course_id:kursId,starts_at:start,ends_at:schluss});
      const person=(vorschlag.teachers as Array<Record<string,unknown>>)[0],raum=(vorschlag.rooms as Array<Record<string,unknown>>)[0];
      if(!person||!raum){luecken.push({course_id:kursId,course_name:kursName,date:datum,reason:person?'NO_ROOM_AVAILABLE':'NO_TEACHER_AVAILABLE'});continue;}
      const {entry_id}=await saveTimetablePlanEntry(env,auth,tenantId,planId,{course_id:kursId,teacher_id:String(person.id),room:String(raum.name||''),starts_at:start,ends_at:schluss,activity_type:'classroom',source:'automation'});
      await linkPlanEntryResource(env,auth,tenantId,planId,entry_id,{resource_id:String(raum.id)});
      erzeugt++;budget+=AUTOFILL_KOSTEN_ANLAGE;belegteTage.get(kursId)?.add(datum)??belegteTage.set(kursId,new Set([datum]));proKurs.set(kursId,(proKurs.get(kursId)||0)+1);
    }
    ueberspringen=false;
  }
  await audit(env.DB,auth.userId,'education.timetable_plan_autofilled',tenantId,undefined,'timetable_plan',planId,{created:erzeugt,gaps:luecken.length,courses:kurse.length});
  return{plan_id:planId,created:erzeugt,limit_reached:Boolean(naechsterKurs),
    resume_course_id:naechsterKurs||null,resume_date:naechsterTag||null,
    courses:kurse.map(k=>({course_id:String(k.id),course_name:String(k.name||''),created:proKurs.get(String(k.id))||0})),
    gaps:luecken.slice(0,200),gap_count:luecken.length,published:false};
}

export async function substituteSuggestions(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,lessonId:string){requireManage(auth);courseScope(auth,courseId);const lesson=await env.DB.prepare('SELECT id,subject_id,teacher_id,starts_at,ends_at FROM lessons WHERE tenant_id=? AND course_id=? AND id=?').bind(tenantId,courseId,lessonId).first<Record<string,unknown>>();if(!lesson)throw new Error('LESSON_NOT_FOUND');const result=await planningSuggestions(env,auth,tenantId,{course_id:courseId,subject_id:lesson.subject_id,starts_at:lesson.starts_at,ends_at:lesson.ends_at});return{...result,teachers:(result.teachers as any[]).filter(t=>String(t.id)!==String(lesson.teacher_id||''))};}

import type { D1DatabaseLike, D1PreparedStatementLike } from '../portability/types.js';
import type { CoreAuthContext, Env } from './types.js';
import { requirePlatform, requireRole } from './permissions.js';
import { id, nowIso, sha256Text } from './utils.js';

// Manipulationsresistentes Revisionsprotokoll (Master-Spec V2, B15 "Immutable Audit").
//
// Das Protokoll war eine gewoehnliche Tabelle. Wer Schreibrecht auf die Datenbank hatte, konnte
// eine Zeile aendern oder loeschen, und nichts daran haette es verraten - ausgerechnet der
// Nachweis, auf den sich der Traeger gegenueber Aufsicht, Gericht und Pruefer beruft, war die am
// leichtesten zu faelschende Tabelle des Systems.
//
// Vier Funktionen, mehr braucht es nicht:
//   ketteAnhaengen  schreibt die naechste Zeile - Kettenkopf und Zeile in EINEM Stapel.
//   kettePruefen    laeuft die Kette nach und nennt die ERSTE gebrochene Stelle.
//   ketteSiegeln    haelt einen Kopfstand fest, damit auch ein Neuaufbau auffaellt.
//   kettenUebersicht zeigt, welche Ketten es gibt und wie lang sie sind.
//
// Was die Kette leistet und was nicht, gehoert nebeneinander gesagt:
//   AENDERN  faellt auf - der Hash der Zeile passt nicht mehr zu ihrem Inhalt.
//   LOESCHEN faellt auf - die Position fehlt und der Nachfolger nennt einen fremden Vorgaenger.
//   EINFUEGEN faellt auf - die eingeschobene Zeile nennt nicht den Hash ihres Vorgaengers.
//   ANHAENGEN kann weiterhin, wer Schreibrecht hat. Das ist die Eigenschaft jeder Hash-Kette und
//   keine Luecke dieser Umsetzung: geschuetzt wird die VERGANGENHEIT.
//
// Unteranfragen: Anhaengen kostet zwei (Kopf lesen, ein Stapel schreiben), Pruefen vier bis fuenf -
// unabhaengig von der Laenge der Kette. Cloudflare zaehlt 1000 je Aufruf fuer alles zusammen, und
// ein Protokoll, das sich diese Grenze mit der eigentlichen Arbeit teilt, darf nicht je Zeile
// fragen.

/** Die Kette fuer alles ohne Mandantenbezug: Plattformverwaltung, Betrieb, Abrechnung. */
export const PLATTFORMKETTE = 'plattform';

/**
 * Der Vorgaengerhash der allerersten Zeile einer Kette.
 *
 * Ein fester, erkennbarer Wert statt eines leeren Feldes: eine leere Angabe liesse sich spaeter
 * nicht von "Feld vergessen" unterscheiden, und genau diese Verwechslung waere das Schlupfloch,
 * um eine Kette vorne abzuschneiden.
 */
export const KETTENANFANG = 'kettenanfang:v1';

export type Kettenquelle = 'audit_log' | 'portability_audit_events' | 'support_access' | 'siegel';

export interface Kettenglied {
  /** Der Kettenname. Fehlt er, entscheidet die Mandantenkennung - ohne sie die Plattformkette. */
  bereich?: string;
  tenant_id?: string | null;
  quelle: Kettenquelle;
  quelle_id?: string | null;
  akteur?: string | null;
  aktion: string;
  objekt_typ?: string | null;
  objekt_id?: string | null;
  inhalt?: unknown;
}

export interface Kettenspitze { bereich: string; position: number; zeilen_hash: string }

interface Kettenzeile {
  bereich: string; position: number; tenant_id: string | null;
  quelle: string; quelle_id: string | null; akteur: string | null;
  aktion: string; objekt_typ: string | null; objekt_id: string | null;
  inhalt_json: string; erstellt_am: string;
}

/**
 * Kanonische Serialisierung: Schluessel sortiert, keine Leerzeichen, undefined faellt weg.
 *
 * Ohne sie haengt der Hash an der Reihenfolge, in der ein Aufrufer die Felder zufaellig gebaut hat.
 * Zwei gleiche Inhalte haetten dann verschiedene Hashes, und die Pruefung meldete Bruch, wo keiner
 * ist - eine Pruefung, die falschen Alarm schlaegt, wird nach dem dritten Mal abgeschaltet.
 */
export function kanonisch(wert: unknown): string {
  if (wert === null || wert === undefined) return 'null';
  if (Array.isArray(wert)) return `[${wert.map(kanonisch).join(',')}]`;
  if (typeof wert === 'object') {
    const eintraege = Object.entries(wert as Record<string, unknown>)
      .filter(([, v]) => v !== undefined)
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
    return `{${eintraege.map(([k, v]) => `${JSON.stringify(k)}:${kanonisch(v)}`).join(',')}}`;
  }
  if (typeof wert === 'number' && !Number.isFinite(wert)) return 'null';
  return JSON.stringify(wert);
}

function zeilenInhalt(z: Kettenzeile): string {
  return kanonisch({
    bereich: z.bereich, position: z.position, tenant_id: z.tenant_id,
    quelle: z.quelle, quelle_id: z.quelle_id, akteur: z.akteur,
    aktion: z.aktion, objekt_typ: z.objekt_typ, objekt_id: z.objekt_id,
    inhalt: z.inhalt_json, erstellt_am: z.erstellt_am,
  });
}

/** Der Hash einer Zeile: sha256 ueber Vorgaengerhash und kanonischen Inhalt. */
export async function zeilenHash(zeile: Kettenzeile, vorgaengerHash: string): Promise<string> {
  return sha256Text(`${vorgaengerHash}\n${zeilenInhalt(zeile)}`);
}

function text(wert: unknown): string | null {
  return wert === null || wert === undefined ? null : String(wert);
}

// Zwei gleichzeitige Schreibvorgaenge lesen denselben Kopf und wollen dieselbe Position. Einer
// verliert an UNIQUE(bereich,position) - und weil die Kettenzeile im selben Stapel steht wie die
// Protokollzeile, verloere sonst die ganze Handlung. Deshalb ein begrenzter zweiter und dritter
// Anlauf: begrenzt, damit ein echter Defekt nicht zur Endlosschleife wird.
const ANLAEUFE = 3;

// Der Kettenkopf im Arbeitsspeicher - je Datenbankobjekt und Kette.
//
// Ohne ihn kostete JEDE Protokollzeile eine zusaetzliche Unteranfrage nur zum Lesen des Kopfes. Bei
// der Grenze von 1000 Unteranfragen je Aufruf ist das der Unterschied zwischen einem Massenlauf,
// der durchlaeuft, und einem, der abbricht. Schreibt jemand anderes dazwischen, verliert dieser
// Lauf an UNIQUE(bereich,position) - und genau dann wird der Kopf frisch gelesen. Der Zwischen-
// speicher kann also hoechstens einen Anlauf kosten, nie eine falsche Kette.
const kopfSpeicher = new WeakMap<object, Map<string, { position: number; kopf_hash: string }>>();
function gemerkterKopf(db: D1DatabaseLike, bereich: string) { return kopfSpeicher.get(db as unknown as object)?.get(bereich) ?? null; }
function merkeKopf(db: D1DatabaseLike, bereich: string, position: number, kopf_hash: string) {
  const schluessel = db as unknown as object;
  const karte = kopfSpeicher.get(schluessel) ?? new Map<string, { position: number; kopf_hash: string }>();
  karte.set(bereich, { position, kopf_hash });
  kopfSpeicher.set(schluessel, karte);
}
function vergissKopf(db: D1DatabaseLike, bereich: string) { kopfSpeicher.get(db as unknown as object)?.delete(bereich); }

/**
 * Haengt eine Zeile an die Kette - Kettenzeile, Kettenkopf und die mitgegebenen Anweisungen des
 * Aufrufers in EINEM Stapel.
 *
 * Der Stapel ist der Kern: die Protokollzeile (audit_log) und ihre Kettenzeile entstehen zusammen
 * oder gar nicht. Ein Protokoll, dessen Kette hinterherhinkt, waere schlimmer als keine Kette -
 * jede Luecke waere erklaerbar und damit jede Faelschung bestreitbar.
 */
export async function ketteAnhaengen(db: D1DatabaseLike, glied: Kettenglied, zusatz: D1PreparedStatementLike[] = []): Promise<Kettenspitze> {
  const bereich = glied.bereich ?? glied.tenant_id ?? PLATTFORMKETTE;
  let letzterFehler: unknown = null;
  for (let versuch = 0; versuch < ANLAEUFE; versuch++) {
    const kopf = (versuch === 0 ? gemerkterKopf(db, bereich) : null)
      ?? await db.prepare('SELECT position,kopf_hash FROM audit_chain_heads WHERE bereich=?').bind(bereich).first<{ position: number; kopf_hash: string }>();
    const position = Number(kopf?.position ?? 0) + 1;
    const vorgaenger = kopf?.kopf_hash ?? KETTENANFANG;
    const zeile: Kettenzeile = {
      bereich, position, tenant_id: text(glied.tenant_id),
      quelle: glied.quelle, quelle_id: text(glied.quelle_id), akteur: text(glied.akteur),
      aktion: glied.aktion, objekt_typ: text(glied.objekt_typ), objekt_id: text(glied.objekt_id),
      inhalt_json: kanonisch(glied.inhalt ?? null), erstellt_am: nowIso(),
    };
    const hash = await zeilenHash(zeile, vorgaenger);
    try {
      await db.batch([
        ...zusatz,
        db.prepare('INSERT INTO audit_chain_entries(id,bereich,position,tenant_id,quelle,quelle_id,akteur,aktion,objekt_typ,objekt_id,inhalt_json,vorgaenger_hash,zeilen_hash,erstellt_am) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
          .bind(id('akt_'), zeile.bereich, zeile.position, zeile.tenant_id, zeile.quelle, zeile.quelle_id, zeile.akteur, zeile.aktion, zeile.objekt_typ, zeile.objekt_id, zeile.inhalt_json, vorgaenger, hash, zeile.erstellt_am),
        db.prepare('INSERT INTO audit_chain_heads(bereich,position,kopf_hash,aktualisiert_am) VALUES(?,?,?,?) ON CONFLICT(bereich) DO UPDATE SET position=excluded.position,kopf_hash=excluded.kopf_hash,aktualisiert_am=excluded.aktualisiert_am')
          .bind(zeile.bereich, zeile.position, hash, zeile.erstellt_am),
      ]);
      merkeKopf(db, bereich, position, hash);
      return { bereich, position, zeilen_hash: hash };
    } catch (e) {
      letzterFehler = e;
      vergissKopf(db, bereich);
      // Nur der Positionsstreit wird wiederholt. Alles andere - fehlende Tabelle, defekte
      // Zusatzanweisung - waere durch Wiederholen nur langsamer falsch.
      if (!/UNIQUE|constraint/i.test(String((e as Error)?.message ?? ''))) throw e;
    }
  }
  throw letzterFehler ?? new Error('AUDIT_KETTE_NICHT_SCHREIBBAR');
}

export type Bruchart = 'zeile_geaendert' | 'zeile_geloescht' | 'zeile_eingefuegt' | 'kopf_weicht_ab' | 'siegel_gebrochen';
export interface Bruch { art: Bruchart; position: number; hinweis: string }
export interface Pruefbericht {
  bereich: string;
  ab: number;
  /** Wie viele Zeilen dieser Lauf angesehen hat. */
  geprueft: number;
  /** Die hoechste gepruefte Position - von hier setzt der naechste Lauf mit ab= fort. */
  bis_position: number;
  /** Ob die Kette bis zu ihrem heutigen Ende gelesen wurde oder die Obergrenze zuschlug. */
  vollstaendig: boolean;
  gueltig: boolean;
  bruch: Bruch | null;
  kopf_position: number;
  siegel: number;
  letztes_siegel: string | null;
}

export const PRUEFUNG_STANDARD = 500;
export const PRUEFUNG_HOECHSTENS = 2000;

// Die Hinweise sind fuer Menschen geschrieben, die keine Datenbank bedienen: Position und
// Bedeutung, kein SQL, kein Hash, keine Kennung. Wer tiefer schauen muss, hat die Position - und
// mit ihr die Zeile.
const HINWEIS: Record<Bruchart, (position: number) => string> = {
  zeile_geaendert: p => `Der Eintrag an Position ${p} stimmt nicht mehr mit seiner Prüfsumme überein. Er wurde nach dem Schreiben verändert.`,
  zeile_geloescht: p => `An Position ${p} fehlt ein Eintrag. Die Kette ist dort unterbrochen – ein Vorgang wurde nachträglich entfernt.`,
  zeile_eingefuegt: p => `Der Eintrag an Position ${p} schließt nicht an seinen Vorgänger an. Er wurde nachträglich eingefügt.`,
  kopf_weicht_ab: p => `Das Ende der Kette weicht vom festgehaltenen Stand ab (Position ${p}). Es wurde an der Kette vorbei geschrieben.`,
  siegel_gebrochen: p => `Der gesiegelte Stand an Position ${p} findet sich so nicht mehr. Das Protokoll wurde nachträglich neu aufgebaut.`,
};

function bruch(art: Bruchart, position: number): Bruch {
  return { art, position, hinweis: HINWEIS[art](position) };
}

/**
 * Laeuft die Kette nach und meldet die ERSTE gebrochene Stelle.
 *
 * "Die erste" ist die eigentliche Leistung: eine Liste aller Abweichungen waere nach einer
 * geaenderten Zeile endlos, weil ab dort jede folgende Verkettung rechnerisch nicht mehr passt.
 * Gesucht ist die Stelle, an der eingegriffen wurde - alles danach ist Folge, nicht Befund.
 *
 * Vier Abfragen, unabhaengig von der Kettenlaenge: die Seite der Kette, der Kopf, die Siegel und
 * die gesiegelten Positionen. Der Rest ist Rechnung im Speicher.
 */
export async function kettePruefen(env: Env, bereich: string, ab = 1, limit = PRUEFUNG_STANDARD): Promise<Pruefbericht> {
  const von = Math.max(1, Math.floor(Number(ab) || 1));
  const menge = Math.max(1, Math.min(PRUEFUNG_HOECHSTENS, Math.floor(Number(limit) || PRUEFUNG_STANDARD)));

  const zeilen = ((await env.DB.prepare('SELECT bereich,position,tenant_id,quelle,quelle_id,akteur,aktion,objekt_typ,objekt_id,inhalt_json,vorgaenger_hash,zeilen_hash,erstellt_am FROM audit_chain_entries WHERE bereich=? AND position>=? ORDER BY position LIMIT ?')
    .bind(bereich, von, menge).all<Record<string, unknown>>()).results) ?? [];
  const kopf = await env.DB.prepare('SELECT position,kopf_hash FROM audit_chain_heads WHERE bereich=?').bind(bereich).first<{ position: number; kopf_hash: string }>();
  const siegel = ((await env.DB.prepare('SELECT position,kopf_hash,gesiegelt_am FROM audit_chain_seals WHERE bereich=? ORDER BY position DESC LIMIT 50')
    .bind(bereich).all<{ position: number; kopf_hash: string; gesiegelt_am: string }>()).results) ?? [];

  // Der Vorgaenger der ersten gelesenen Zeile. Bei ab=1 ist es der Kettenanfang, sonst die Zeile
  // davor - ohne sie waere ein Bruch genau an der Seitengrenze unsichtbar, und wer seitenweise
  // prueft, haette ausgerechnet dort ein blindes Feld.
  let vorher = KETTENANFANG;
  if (von > 1) {
    const davor = await env.DB.prepare('SELECT zeilen_hash FROM audit_chain_entries WHERE bereich=? AND position=?').bind(bereich, von - 1).first<{ zeilen_hash: string }>();
    vorher = davor?.zeilen_hash ?? '';
  }

  const kopfPosition = Number(kopf?.position ?? 0);
  let gefunden: Bruch | null = null;
  let erwartet = von;
  let letzte = von - 1;

  for (const roh of zeilen) {
    const zeile: Kettenzeile = {
      bereich: String(roh.bereich), position: Number(roh.position), tenant_id: text(roh.tenant_id),
      quelle: String(roh.quelle), quelle_id: text(roh.quelle_id), akteur: text(roh.akteur),
      aktion: String(roh.aktion), objekt_typ: text(roh.objekt_typ), objekt_id: text(roh.objekt_id),
      inhalt_json: String(roh.inhalt_json), erstellt_am: String(roh.erstellt_am),
    };
    const vorgaengerHash = String(roh.vorgaenger_hash), zeilenhash = String(roh.zeilen_hash);
    // Erst die Luecke: ein geloeschter Vorgang reisst zugleich die Verkettung des Nachfolgers.
    // Wer hier die Verkettung zuerst prueft, meldet "eingefuegt", wo geloescht wurde.
    if (zeile.position !== erwartet) { gefunden = bruch('zeile_geloescht', erwartet); break; }
    if (await zeilenHash(zeile, vorgaengerHash) !== zeilenhash) { gefunden = bruch('zeile_geaendert', zeile.position); break; }
    if (vorgaengerHash !== vorher) { gefunden = bruch('zeile_eingefuegt', zeile.position); break; }
    vorher = zeilenhash;
    letzte = zeile.position;
    erwartet = zeile.position + 1;
  }

  const vollstaendig = zeilen.length < menge;
  // Der Kopf ist die zweite Zeugenaussage. Wer eine Zeile am Ende anhaengt oder abschneidet, ohne
  // den Kopf zu pflegen, faellt hier auf - und wer den Kopf pflegt, ohne die Zeile zu schreiben,
  // ebenso.
  if (!gefunden && vollstaendig) {
    if (kopfPosition > letzte) gefunden = bruch('zeile_geloescht', letzte + 1);
    else if (kopfPosition < letzte) gefunden = bruch('zeile_eingefuegt', kopfPosition + 1);
    else if (letzte >= von && kopf && String(kopf.kopf_hash) !== vorher) gefunden = bruch('kopf_weicht_ab', letzte);
  }

  // Die Siegel zuletzt - aber sie koennen weiter vorn liegen als der bisherige Befund, und dann
  // zaehlt ihre Position. Geprueft wird gegen die Zeilen selbst, nicht gegen die gelesene Seite:
  // ein vollstaendiger Neuaufbau der Tabelle faellt sonst nicht auf, solange man nur den Anfang
  // liest.
  if (siegel.length) {
    const positionen = siegel.map(s => Number(s.position));
    const treffer = ((await env.DB.prepare(`SELECT position,zeilen_hash FROM audit_chain_entries WHERE bereich=? AND position IN (${positionen.map(() => '?').join(',')})`)
      .bind(bereich, ...positionen).all<{ position: number; zeilen_hash: string }>()).results) ?? [];
    const jeStelle = new Map(treffer.map(t => [Number(t.position), String(t.zeilen_hash)]));
    for (const s of [...siegel].sort((a, b) => Number(a.position) - Number(b.position))) {
      const stelle = Number(s.position), ist = jeStelle.get(stelle);
      if (ist === String(s.kopf_hash)) continue;
      const siegelbruch = bruch(ist === undefined ? 'zeile_geloescht' : 'siegel_gebrochen', stelle);
      if (!gefunden || siegelbruch.position < gefunden.position) gefunden = siegelbruch;
      break;
    }
  }

  return {
    bereich, ab: von, geprueft: zeilen.length, bis_position: Math.max(letzte, von - 1),
    vollstaendig, gueltig: !gefunden, bruch: gefunden, kopf_position: kopfPosition,
    siegel: siegel.length,
    letztes_siegel: siegel.length ? String(siegel[0].gesiegelt_am) : null,
  };
}

/**
 * Haelt den heutigen Kopfstand als Siegelpunkt fest.
 *
 * Ohne Siegel bliebe ein Angriff unentdeckt: wer die Kettentabelle KOMPLETT neu aufbaut,
 * hinterlaesst eine in sich schluessige, nur kuerzere Kette. Das Siegel sagt, dass es Position
 * 4711 mit genau diesem Hash gegeben hat - und macht den Neuaufbau damit beweisbar.
 */
export async function ketteSiegeln(env: Env, bereich: string, akteur?: string | null): Promise<{ bereich: string; position: number; kopf_hash: string; gesiegelt_am: string }> {
  const kopf = await env.DB.prepare('SELECT position,kopf_hash FROM audit_chain_heads WHERE bereich=?').bind(bereich).first<{ position: number; kopf_hash: string }>();
  if (!kopf || Number(kopf.position) < 1) throw new Error('AUDIT_KETTE_LEER');
  const jetzt = nowIso();
  // Zweimal dasselbe Siegel ist kein Fehler, sondern der Normalfall eines turnusmaessigen Laufs
  // ohne neue Vorgaenge - deshalb DO NOTHING statt Abbruch. Ein zweites Siegel MIT anderem Hash
  // auf derselben Position kann es nicht geben: das waere schon der Bruch, und die Aenderungssperre
  // der Tabelle laesst ihn nicht zu.
  await env.DB.prepare('INSERT INTO audit_chain_seals(id,bereich,position,kopf_hash,gesiegelt_am,gesiegelt_von) VALUES(?,?,?,?,?,?) ON CONFLICT(bereich,position) DO NOTHING')
    .bind(id('sgl_'), bereich, Number(kopf.position), String(kopf.kopf_hash), jetzt, akteur ?? null).run();
  return { bereich, position: Number(kopf.position), kopf_hash: String(kopf.kopf_hash), gesiegelt_am: jetzt };
}

export interface Kettenstand { bereich: string; position: number; aktualisiert_am: string; siegel: number; letztes_siegel: string | null }

/** Welche Ketten es gibt, wie weit sie reichen und wann zuletzt gesiegelt wurde. */
export async function kettenUebersicht(env: Env, limit = 50): Promise<Kettenstand[]> {
  const n = Math.max(1, Math.min(200, Math.floor(Number(limit) || 50)));
  const zeilen = ((await env.DB.prepare('SELECT h.bereich,h.position,h.aktualisiert_am,(SELECT COUNT(*) FROM audit_chain_seals s WHERE s.bereich=h.bereich) AS siegel,(SELECT MAX(s.gesiegelt_am) FROM audit_chain_seals s WHERE s.bereich=h.bereich) AS letztes_siegel FROM audit_chain_heads h ORDER BY h.aktualisiert_am DESC LIMIT ?')
    .bind(n).all<Record<string, unknown>>()).results) ?? [];
  return zeilen.map(z => ({
    bereich: String(z.bereich), position: Number(z.position ?? 0), aktualisiert_am: String(z.aktualisiert_am),
    siegel: Number(z.siegel ?? 0), letztes_siegel: text(z.letztes_siegel),
  }));
}

// ---------------------------------------------------------------------------
// Der Turnus. Ohne ihn ist die Kette nur eine Rechenvorschrift.
// ---------------------------------------------------------------------------
//
// Befund des Gesamtaudits: Pruefen, Siegeln und Uebersicht hatten ausserhalb ihres eigenen Tests
// keinen Aufrufer. Das ist beim Protokoll schlimmer als bei jeder anderen Funktion: die Kette
// verhindert keine Faelschung, sie macht sie SICHTBAR - und sichtbar wird sie erst, wenn jemand
// nachrechnet. Vorher ist der Nachweis nur eine Behauptung ueber eine Tabelle.
//
// Die Reihenfolge des Laufs ist dabei nicht beliebig: erst pruefen, dann siegeln. Ein Siegel auf
// eine schon gebrochene Kette waere das Gegenteil eines Nachweises - es wuerde den gefaelschten
// Stand als geprueft festschreiben.

/** Das Ergebnis der letzten Pruefung einer Kette, wie es die Oberflaeche zeigt. */
export interface Kettenpruefstand {
  bereich: string; geprueft_am: string; gueltig: boolean; ab: number; bis_position: number;
  kopf_position: number; geprueft: number; vollstaendig: boolean;
  bruch_art: Bruchart | null; bruch_position: number | null; hinweis: string | null;
}

function pruefstand(z: Record<string, unknown> | null | undefined): Kettenpruefstand | null {
  if (!z) return null;
  return {
    bereich: String(z.bereich), geprueft_am: String(z.geprueft_am), gueltig: Number(z.gueltig) === 1,
    ab: Number(z.ab ?? 1), bis_position: Number(z.bis_position ?? 0), kopf_position: Number(z.kopf_position ?? 0),
    geprueft: Number(z.geprueft ?? 0), vollstaendig: Number(z.vollstaendig ?? 0) === 1,
    bruch_art: (text(z.bruch_art) as Bruchart | null), bruch_position: z.bruch_position === null || z.bruch_position === undefined ? null : Number(z.bruch_position),
    hinweis: text(z.hinweis),
  };
}

/** Haelt das Ergebnis einer Pruefung fest - ein Bruch bleibt stehen, bis ihn jemand ansieht. */
export async function pruefungFesthalten(env: Env, bericht: Pruefbericht, jetzt = nowIso()): Promise<void> {
  await env.DB.prepare(`INSERT INTO audit_chain_checks(bereich,geprueft_am,gueltig,ab,bis_position,kopf_position,geprueft,vollstaendig,bruch_art,bruch_position,hinweis)
    VALUES(?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(bereich) DO UPDATE SET geprueft_am=excluded.geprueft_am,gueltig=excluded.gueltig,ab=excluded.ab,
      bis_position=excluded.bis_position,kopf_position=excluded.kopf_position,geprueft=excluded.geprueft,
      vollstaendig=excluded.vollstaendig,bruch_art=excluded.bruch_art,bruch_position=excluded.bruch_position,hinweis=excluded.hinweis`)
    .bind(bericht.bereich, jetzt, bericht.gueltig ? 1 : 0, bericht.ab, bericht.bis_position, bericht.kopf_position,
      bericht.geprueft, bericht.vollstaendig ? 1 : 0, bericht.bruch?.art ?? null, bericht.bruch?.position ?? null,
      bericht.bruch?.hinweis ?? null).run();
}

/** Der zuletzt festgehaltene Pruefstand einer Kette. */
export async function letztePruefung(env: Env, bereich: string): Promise<Kettenpruefstand | null> {
  return pruefstand(await env.DB.prepare('SELECT * FROM audit_chain_checks WHERE bereich=?').bind(bereich).first<Record<string, unknown>>());
}

/**
 * Der turnusmaessige Lauf: pruefen, festhalten, siegeln.
 *
 * Er nimmt zwei Arten von Ketten: die, die sich seit ihrem letzten Siegel bewegt haben, und die,
 * die zu lange nicht geprueft wurden. Das Zweite ist nicht die Kuer: eine ruhende Kette - ein
 * beendeter Vertrag, ein stillgelegter Mandant - wuerde sonst nie wieder nachgerechnet, und
 * ausgerechnet dort lohnt sich ein Eingriff am meisten, weil niemand mehr hinsieht.
 *
 * Eine unveraenderte, frisch gepruefte Kette bleibt dagegen liegen: sie jeden Tag neu zu siegeln
 * fuellt die Tabelle, ohne etwas zu beweisen. Und je Lauf kommt nur eine Handvoll dran - ein
 * Aufruf der Plattform hat 1000 Unteranfragen fuer alle Arbeiten zusammen, eine Pruefung kostet
 * vier bis fuenf davon.
 *
 * Geprueft wird das Ende der Kette. Der Anfang ist durch die Siegel gedeckt: kettePruefen haelt
 * jedes bekannte Siegel gegen die Zeile, die heute an seiner Stelle steht - auch wenn sie weit
 * ausserhalb der gelesenen Seite liegt.
 */
export const PRUEFABSTAND_TAGE = 30;

export async function ketteTurnusPruefen(env: Env, maxKetten = 10, jetzt = nowIso(), abstandTage = PRUEFABSTAND_TAGE): Promise<{ geprueft: number; gesiegelt: number; gebrochen: string[] }> {
  const faellig = new Date(new Date(jetzt).getTime() - Math.max(1, Number(abstandTage) || PRUEFABSTAND_TAGE) * 86400000).toISOString();
  const ketten = ((await env.DB.prepare(`SELECT h.bereich,h.position FROM audit_chain_heads h
    LEFT JOIN audit_chain_checks c ON c.bereich=h.bereich
    WHERE h.position>0 AND (
      NOT EXISTS(SELECT 1 FROM audit_chain_seals s WHERE s.bereich=h.bereich AND s.position=h.position)
      OR c.bereich IS NULL OR c.geprueft_am<?)
    ORDER BY COALESCE(c.geprueft_am,''),h.aktualisiert_am LIMIT ?`)
    .bind(faellig, Math.max(1, Math.min(50, Math.floor(Number(maxKetten) || 10))))
    .all<{ bereich: string; position: number }>()).results) ?? [];
  let geprueft = 0, gesiegelt = 0; const gebrochen: string[] = [];
  for (const k of ketten) {
    const bereich = String(k.bereich);
    try {
      const ab = Math.max(1, Number(k.position) - PRUEFUNG_STANDARD + 1);
      const bericht = await kettePruefen(env, bereich, ab, PRUEFUNG_STANDARD);
      await pruefungFesthalten(env, bericht, jetzt);
      geprueft++;
      if (!bericht.gueltig) {
        // Kein Siegel auf eine gebrochene Kette: das wuerde den gefaelschten Stand festschreiben.
        gebrochen.push(bereich);
        console.error('Revisionsprotokoll: Kette gebrochen', { bereich, art: bericht.bruch?.art, position: bericht.bruch?.position });
        continue;
      }
      await ketteSiegeln(env, bereich, 'system:turnus');
      gesiegelt++;
    } catch (e) {
      // Eine Kette, die stolpert, darf die uebrigen nicht mitnehmen.
      console.error('Revisionsprotokoll: Pruefung fehlgeschlagen', { bereich, error: String((e as Error)?.message || e) });
    }
  }
  return { geprueft, gesiegelt, gebrochen };
}

// ---------------------------------------------------------------------------
// Was der Traeger und die Plattformverwaltung davon sehen
// ---------------------------------------------------------------------------
//
// Der Kettenname ist NIE ein Wert aus der Anfrage. Er ist die Mandantenkennung des angemeldeten
// Zugriffs - sonst liesse sich ueber den Umweg der Pruefung das Protokoll eines fremden Traegers
// lesen, und zwar mit Aktion, Objekt und Zeitpunkt.

/** Stand und letzte Pruefung der eigenen Protokollkette. */
export async function protokollkette(env: Env, auth: CoreAuthContext, tenantId: string): Promise<{ stand: Kettenstand | null; pruefung: Kettenpruefstand | null }> {
  requireRole(auth, 'tenant_admin');
  const kopf = await env.DB.prepare(`SELECT h.bereich,h.position,h.aktualisiert_am,
      (SELECT COUNT(*) FROM audit_chain_seals s WHERE s.bereich=h.bereich) AS siegel,
      (SELECT MAX(s.gesiegelt_am) FROM audit_chain_seals s WHERE s.bereich=h.bereich) AS letztes_siegel
    FROM audit_chain_heads h WHERE h.bereich=?`).bind(tenantId).first<Record<string, unknown>>();
  return {
    stand: kopf ? {
      bereich: String(kopf.bereich), position: Number(kopf.position ?? 0), aktualisiert_am: String(kopf.aktualisiert_am),
      siegel: Number(kopf.siegel ?? 0), letztes_siegel: text(kopf.letztes_siegel),
    } : null,
    pruefung: await letztePruefung(env, tenantId),
  };
}

/**
 * Die eigene Kette auf Verlangen pruefen - der Knopf, den ein Pruefer im Haus drueckt.
 *
 * Das Ergebnis wird festgehalten: eine Pruefung, die nur auf dem Bildschirm stand, ist spaeter
 * kein Nachweis.
 */
export async function protokollkettePruefen(env: Env, auth: CoreAuthContext, tenantId: string, ab = 1, limit = PRUEFUNG_STANDARD): Promise<Pruefbericht> {
  requireRole(auth, 'tenant_admin');
  const bericht = await kettePruefen(env, tenantId, ab, limit);
  await pruefungFesthalten(env, bericht);
  return bericht;
}

/**
 * Den heutigen Stand siegeln lassen - vor einer Pruefung, einem Audit, einer Uebergabe.
 *
 * Gesiegelt wird nur, was vorher als heil erkannt wurde. Sonst waere das Siegel eine Bestaetigung
 * des gefaelschten Standes.
 */
export async function protokollketteSiegeln(env: Env, auth: CoreAuthContext, tenantId: string) {
  requireRole(auth, 'tenant_admin');
  const kopf = await env.DB.prepare('SELECT position FROM audit_chain_heads WHERE bereich=?').bind(tenantId).first<{ position: number }>();
  if (!kopf || Number(kopf.position) < 1) throw new Error('AUDIT_KETTE_LEER');
  const bericht = await kettePruefen(env, tenantId, Math.max(1, Number(kopf.position) - PRUEFUNG_STANDARD + 1), PRUEFUNG_STANDARD);
  await pruefungFesthalten(env, bericht);
  if (!bericht.gueltig) throw new Error('AUDIT_KETTE_GEBROCHEN');
  return { ...await ketteSiegeln(env, tenantId, auth.userId), bericht };
}

/** Alle Ketten mit ihrem letzten Pruefergebnis - Sache der Plattformverwaltung. */
export async function protokollkettenUebersicht(env: Env, auth: CoreAuthContext, limit = 50): Promise<(Kettenstand & { pruefung: Kettenpruefstand | null })[]> {
  requirePlatform(auth);
  const staende = await kettenUebersicht(env, limit);
  if (!staende.length) return [];
  const pruefungen = ((await env.DB.prepare(`SELECT * FROM audit_chain_checks WHERE bereich IN (${staende.map(() => '?').join(',')})`)
    .bind(...staende.map(s => s.bereich)).all<Record<string, unknown>>()).results) ?? [];
  const jeBereich = new Map(pruefungen.map(p => [String(p.bereich), pruefstand(p)]));
  return staende.map(s => ({ ...s, pruefung: jeBereich.get(s.bereich) ?? null }));
}

// D1 hat eine harte Obergrenze von 10 GB je Datenbank. Cloudflare hebt sie nicht an, auch nicht
// gegen Geld. Wer sie erreicht, kann nicht mehr schreiben: keine Anwesenheit, keine Note, kein
// Zeugnis, kein Import. Lesen geht weiter, arbeiten nicht.
//
// Gerechnet: 20.000 Teilnehmende x 200 Unterrichtstage x 10 Einheiten = 40 Mio. Anwesenheits-
// zeilen. Bei rund 250 Byte je Zeile inklusive Index sind das etwa 10 GB - allein aus einer
// einzigen Tabelle, ohne Protokolle, ohne Aufgaben, ohne Noten.
//
// Das ist keine Panik: heute ist die Datenbank klein. Aber es ist eine Wand, die genau einmal
// getroffen wird, und dann steht der Betrieb aller Mandanten gleichzeitig. Deshalb dieses Modul.
// Es aendert nichts am Verhalten, es misst und meldet - und ab der kritischen Stufe verweigert es
// neue Masseneinspielungen mit einem klaren Satz, statt sie mittendrin scheitern zu lassen.
import type { Env } from './types.js';
import type { CoreAuthContext } from './types.js';
import { requirePlatform } from './permissions.js';
import { nowIso } from './utils.js';

export const D1_GRENZE_BYTES = 10 * 1024 * 1024 * 1024;

// Ab welchem Anteil welche Stufe gilt. Bewusst frueh: bei 85 % bleiben bei heutigem Zuwachs
// noch Wochen, und ein Umzug kalter Daten braucht Vorlauf, keinen Feueralarm.
export const STUFEN = [
  { stufe: 'kritisch' as const, ab: 0.85 },
  { stufe: 'warnung' as const, ab: 0.70 },
  { stufe: 'beobachten' as const, ab: 0.50 },
  { stufe: 'ok' as const, ab: 0 },
];
export type Speicherstufe = 'ok' | 'beobachten' | 'warnung' | 'kritisch';

export function stufeFuer(anteil: number): Speicherstufe {
  for (const s of STUFEN) if (anteil >= s.ab) return s.stufe;
  return 'ok';
}

// Die Tabellen, die tatsaechlich mit dem Betrieb wachsen - je Teilnehmendem und je Tag. Alles
// andere waechst mit der Zahl der Mandanten und faellt daneben nicht ins Gewicht.
export const WACHSTUMSTABELLEN = [
  'attendance_records', 'attendance_events', 'attendance_sessions',
  'audit_log', 'login_attempts', 'provisioning_log', 'portability_audit_events',
  'assignment_submissions', 'quiz_attempt_answers', 'quiz_attempts',
  'notifications', 'message_recipients', 'messages',
] as const;

async function tabelleExistiert(env: Env, name: string): Promise<boolean> {
  const row = await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").bind(name).first<{ name: string }>();
  return !!row;
}

// Die echte Groesse. D1 meldet sie in meta.size_after; das ist die einzige verlaessliche Quelle,
// denn PRAGMA page_count ist in D1 gesperrt. Fehlt sie (lokale SQLite, aelteres D1), wird
// ehrlich geschaetzt statt geraten: gemessene Nutzlast je Tabelle plus ein Indexaufschlag.
export async function datenbankGroesse(env: Env): Promise<{ bytes: number; quelle: 'gemessen' | 'geschaetzt'; zeilen: number; tabellen: Array<{ tabelle: string; zeilen: number; bytes: number }> }> {
  const probe = await env.DB.prepare('SELECT 1 AS x').all<{ x: number }>();
  const gemessen = Number((probe.meta as { size_after?: number } | undefined)?.size_after || 0);

  const tabellen: Array<{ tabelle: string; zeilen: number; bytes: number }> = [];
  let zeilen = 0, nutzlast = 0;
  for (const t of WACHSTUMSTABELLEN) {
    if (!await tabelleExistiert(env, t)) continue;
    // length() ueber die ganze Zeile ist in SQLite nicht moeglich; die Zeilenzahl mal der an einer
    // Stichprobe gemessenen Zeilenlaenge ist die naechstbeste ehrliche Zahl.
    const anzahl = Number((await env.DB.prepare(`SELECT COUNT(*) AS n FROM ${t}`).first<{ n: number }>())?.n || 0);
    const bytes = anzahl * 250;
    zeilen += anzahl; nutzlast += bytes;
    if (anzahl > 0) tabellen.push({ tabelle: t, zeilen: anzahl, bytes });
  }
  tabellen.sort((a, b) => b.bytes - a.bytes);
  return gemessen > 0
    ? { bytes: gemessen, quelle: 'gemessen', zeilen, tabellen }
    : { bytes: nutzlast, quelle: 'geschaetzt', zeilen, tabellen };
}

// Eine Stichprobe je Tag. Mehr braucht es nicht, und weniger ergibt keine Gerade.
export async function speicherStichprobeSchreiben(env: Env): Promise<{ sampled_on: string; bytes: number; quelle: string }> {
  const g = await datenbankGroesse(env);
  const ts = nowIso(), tag = ts.slice(0, 10);
  await env.DB.prepare(
    'INSERT INTO storage_growth_samples (id,sampled_on,bytes,source,rows_total,created_at) VALUES (?,?,?,?,?,?) ' +
    'ON CONFLICT(sampled_on) DO UPDATE SET bytes=excluded.bytes,source=excluded.source,rows_total=excluded.rows_total'
  ).bind(`sg_${tag}`, tag, g.bytes, g.quelle, g.zeilen, ts).run();
  return { sampled_on: tag, bytes: g.bytes, quelle: g.quelle };
}

function tageDifferenz(a: string, b: string): number {
  return Math.round((Date.parse(`${a}T00:00:00Z`) - Date.parse(`${b}T00:00:00Z`)) / 86400000);
}

// Die Vorhersage ist bewusst stumpf: erste und letzte Stichprobe, gerade Linie. Eine kompliziertere
// Rechnung waere hier Scheingenauigkeit - gebraucht wird nur die Groessenordnung der Restzeit.
export async function speicherLage(env: Env, auth?: CoreAuthContext) {
  if (auth) requirePlatform(auth);
  const g = await datenbankGroesse(env);
  const anteil = g.bytes / D1_GRENZE_BYTES;
  const stufe = stufeFuer(anteil);

  const proben = (await env.DB.prepare('SELECT sampled_on,bytes FROM storage_growth_samples ORDER BY sampled_on ASC').all<{ sampled_on: string; bytes: number }>()).results || [];
  let taeglicherZuwachsBytes = 0, tageBisGrenze: number | null = null;
  if (proben.length >= 2) {
    const erste = proben[0], letzte = proben[proben.length - 1];
    const tage = tageDifferenz(letzte.sampled_on, erste.sampled_on);
    if (tage > 0) {
      taeglicherZuwachsBytes = Math.max(0, Math.round((Number(letzte.bytes) - Number(erste.bytes)) / tage));
      if (taeglicherZuwachsBytes > 0) tageBisGrenze = Math.max(0, Math.floor((D1_GRENZE_BYTES - g.bytes) / taeglicherZuwachsBytes));
    }
  }
  return {
    bytes: g.bytes,
    quelle: g.quelle,
    grenze_bytes: D1_GRENZE_BYTES,
    anteil: Math.round(anteil * 10000) / 10000,
    stufe,
    zeilen: g.zeilen,
    tabellen: g.tabellen.slice(0, 10),
    messreihe_tage: proben.length,
    taeglicher_zuwachs_bytes: taeglicherZuwachsBytes,
    tage_bis_grenze: tageBisGrenze,
  };
}

// Der Schutz vor der Wand. Eine Masseneinspielung, die mittendrin an der Grenze scheitert,
// hinterlaesst halb eingespielte Daten - das ist teurer als eine klare Absage vorher.
// Kleine Schreibvorgaenge im Tagesbetrieb bleiben unberuehrt: Anwesenheit eintragen muss
// bis zur letzten Zeile moeglich sein.
export const MASSENSCHWELLE_ZEILEN = 500;

export async function assertSpeicherFuerMassenimport(env: Env, geplanteZeilen: number): Promise<void> {
  if (geplanteZeilen < MASSENSCHWELLE_ZEILEN) return;
  const g = await datenbankGroesse(env);
  if (stufeFuer(g.bytes / D1_GRENZE_BYTES) === 'kritisch') throw new Error('STORAGE_LIMIT_CRITICAL');
}

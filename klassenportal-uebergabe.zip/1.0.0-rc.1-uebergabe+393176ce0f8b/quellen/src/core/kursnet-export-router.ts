import type { Env } from './types.js';
import { resolveCoreAuth } from './auth.js';
import { assertTenantWriteAllowed } from './commerce-offers.js';
import { kursnetAngebotEntfernen, kursnetAngebotSchreiben, kursnetAngeboteLesen, kursnetEinstellungenLesen, kursnetEinstellungenSchreiben, kursnetKatalogBauen } from './kursnet-export.js';
import { assertSameOrigin, authStatus, json, safeErrorCode } from './utils.js';

// /api/kursnet - Meldung der Bildungsangebote an KURSNET im Format open-Qcat V1.1.
//
// Vorbild und Aufbau wie /api/course-fees: ein eigener Router VOR dem Sammelrouter, damit die
// Pfade nicht in dessen 404-Zweig laufen.

async function body(request:Request):Promise<Record<string,unknown>>{try{return await request.json() as Record<string,unknown>;}catch{return{};}}

// Ein fehlender Anbieterschluessel ist kein Serverfehler: der Traeger kann ihn selbst
// hinterlegen. 409 sagt "es fehlt noch etwas", nicht "hier ist etwas kaputt".
const KONFLIKT=new Set(['KURSNET_SETTINGS_MISSING','KURSNET_INSTITUTION_NUMBER_MISSING','KURSNET_INPUT_TYPE_MISSING',
  'KURSNET_CATALOG_ID_MISSING','KURSNET_SUPPLIER_NAME_MISSING','KURSNET_SUPPLIER_ADDRESS_MISSING']);
function fail(e:unknown){
  const code=safeErrorCode(e);
  const status=authStatus(code)??(code==='UNAUTHENTICATED'?401
    :code.startsWith('FORBIDDEN')?403
    :code.includes('NOT_FOUND')?404
    :KONFLIKT.has(code)?409:400);
  return json({ok:false,error:code},status);
}

export async function handleKursnetExportApi(request:Request,env:Env):Promise<Response|null>{
  const u=new URL(request.url),path=u.pathname;
  if(!path.startsWith('/api/kursnet'))return null;
  try{
    assertSameOrigin(request,env.APP_ORIGIN);
    const tenantId=u.searchParams.get('tenant_id')||'';
    if(!tenantId)throw new Error('TENANT_ID_REQUIRED');
    const auth=await resolveCoreAuth(env,request,tenantId);
    if(request.method!=='GET'&&request.method!=='HEAD')await assertTenantWriteAllowed(env,tenantId);

    if(path==='/api/kursnet/settings'&&request.method==='GET')
      return json({ok:true,...await kursnetEinstellungenLesen(env,auth,tenantId)});
    if(path==='/api/kursnet/settings'&&request.method==='PUT')
      return json({ok:true,...await kursnetEinstellungenSchreiben(env,auth,tenantId,await body(request))});
    if(path==='/api/kursnet/offers'&&request.method==='GET')
      return json({ok:true,...await kursnetAngeboteLesen(env,auth,tenantId)});
    if(path==='/api/kursnet/offers'&&request.method==='POST')
      return json({ok:true,...await kursnetAngebotSchreiben(env,auth,tenantId,await body(request))},201);
    const angebot=path.match(/^\/api\/kursnet\/offers\/([^/]+)$/);
    if(angebot&&request.method==='DELETE')
      return json({ok:true,...await kursnetAngebotEntfernen(env,auth,tenantId,decodeURIComponent(angebot[1]))});

    // Der Katalog wird zweimal angeboten: als Bericht (JSON, mit den liegengebliebenen Angeboten
    // und dem Pruefergebnis) und als die Datei selbst. Wer nur die Datei zieht, bekommt sie auch
    // dann, wenn Angebote fehlen - aber der Bericht sagt ihm vorher, welche und warum.
    const auswahl=(u.searchParams.get('course_ids')||'').split(',').map(s=>s.trim()).filter(Boolean).slice(0,500);
    if(path==='/api/kursnet/catalog'&&request.method==='GET'){
      const katalog=await kursnetKatalogBauen(env,auth,tenantId,auswahl);
      return json({ok:true,dateiname:katalog.dateiname,angebote:katalog.angebote,
        ausgelassen:katalog.ausgelassen,gueltig:katalog.gueltig,befunde:katalog.befunde});
    }
    if(path==='/api/kursnet/catalog.xml'&&request.method==='GET'){
      const katalog=await kursnetKatalogBauen(env,auth,tenantId,auswahl);
      // Eine Datei, die die eigene Pruefung nicht besteht, wird NICHT ausgeliefert. Sonst laedt
      // der Traeger sie hoch, KURSNET weist sie ab, und er sucht den Fehler bei sich.
      if(!katalog.gueltig)return json({ok:false,error:'KURSNET_CATALOG_INVALID',befunde:katalog.befunde},409);
      return new Response(katalog.xml,{status:200,headers:{
        'Content-Type':'application/xml; charset=utf-8',
        'Content-Disposition':`attachment; filename="${katalog.dateiname}"`,
      }});
    }

    return json({ok:false,error:'NOT_FOUND'},404);
  }catch(e){return fail(e);}
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Veranstaltungen und Exkursionen als Vorgang (S4).
//
// Eine Exkursion war ein Kalendereintrag. Was sie in Wahrheit ist, stand nirgends:
//  - eine GENEHMIGUNG (wer hat die Fahrt erlaubt, und mit welcher Begleitung),
//  - das EINVERSTAENDNIS der Sorgeberechtigten - bei Minderjaehrigen ersetzt die Zusage der
//    Person es nicht,
//  - eine NOTFALLLISTE fuer den Tag: wer ist dabei, wer ist erreichbar, was ist zu beachten,
//  - ein NACHWEIS danach: was stattgefunden hat und wer teilgenommen hat.
//
// Am Tag der Fahrt ist die Notfallliste das Einzige, was zaehlt. Sie muss deshalb ohne
// Vorbereitung abrufbar sein - und sie darf nur die Leitung sehen.

const clean=(v:unknown,n=2000)=>safeString(v,n);
const tagOk=(v:string)=>/^\d{4}-\d{2}-\d{2}$/.test(v);

type Fahrt={id:string;course_id:string;titel:string;beginnt_am:string;endet_am:string;leitung_user_id:string;
  begleitung_je_teilnehmer:number;rueckmeldung_bis:string;status:string};

async function ladeFahrt(env:Env,tenantId:string,fahrtId:string):Promise<Fahrt>{
  const f=await env.DB.prepare('SELECT id,course_id,titel,beginnt_am,endet_am,leitung_user_id,begleitung_je_teilnehmer,rueckmeldung_bis,status FROM excursions WHERE id=? AND tenant_id=?')
    .bind(clean(fahrtId,120),tenantId).first<Fahrt>();
  if(!f)throw new Error('FAHRT_NICHT_GEFUNDEN');
  return f;
}

export async function planeFahrt(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const courseId=clean(input.course_id,120),titel=clean(input.titel,200),ziel=clean(input.ziel,300);
  if(titel.length<5)throw new Error('FAHRT_TITEL_ERFORDERLICH');
  if(ziel.length<3)throw new Error('FAHRT_ZIEL_ERFORDERLICH');
  const von=clean(input.beginnt_am,40),bis=clean(input.endet_am,40),frist=clean(input.rueckmeldung_bis,10);
  if(!Number.isFinite(Date.parse(von))||!Number.isFinite(Date.parse(bis))||Date.parse(bis)<=Date.parse(von))throw new Error('FAHRT_ZEIT_UNGUELTIG');
  if(!tagOk(frist))throw new Error('FAHRT_FRIST_UNGUELTIG');
  // Eine Rueckmeldefrist nach der Abfahrt ist keine Frist.
  if(Date.parse(frist)>Date.parse(von))throw new Error('FAHRT_FRIST_NACH_ABFAHRT');
  const kurs=await env.DB.prepare('SELECT 1 AS ok FROM courses WHERE id=? AND tenant_id=?').bind(courseId,tenantId).first();
  if(!kurs)throw new Error('FAHRT_KURS_NICHT_GEFUNDEN');
  const leitung=clean(input.leitung_user_id,120)||auth.userId;
  const leitungOk=await env.DB.prepare("SELECT 1 AS ok FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'").bind(tenantId,leitung).first();
  if(!leitungOk)throw new Error('FAHRT_LEITUNG_NICHT_GEFUNDEN');
  const kosten=Math.trunc(Number(input.kosten_cent??0));
  if(!Number.isFinite(kosten)||kosten<0)throw new Error('FAHRT_KOSTEN_UNGUELTIG');
  const schluessel=Math.trunc(Number(input.begleitung_je_teilnehmer??15));
  if(!Number.isFinite(schluessel)||schluessel<1||schluessel>100)throw new Error('FAHRT_BEGLEITSCHLUESSEL_UNGUELTIG');
  const ts=nowIso(),fahrtId=id('exk_');
  await env.DB.prepare('INSERT INTO excursions(id,tenant_id,course_id,titel,ziel,beginnt_am,endet_am,leitung_user_id,kosten_cent,begleitung_je_teilnehmer,rueckmeldung_bis,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(fahrtId,tenantId,courseId,titel,ziel,von,bis,leitung,kosten,schluessel,frist,'entwurf',auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'excursion.planned',tenantId,courseId,'excursion',fahrtId,{ziel});
  return{id:fahrtId,status:'entwurf'};
}

/** Wer mitfaehrt - und wer begleitet. Beides in einem Zug, damit der Schluessel aufgeht. */
export async function ladeFahrtPersonen(env:Env,auth:CoreAuthContext,tenantId:string,fahrtId:string,eintraege:{user_id:string;rolle?:string}[]){
  requireRole(auth,'class_admin');
  const f=await ladeFahrt(env,tenantId,fahrtId);
  if(f.status!=='entwurf')throw new Error('FAHRT_NICHT_MEHR_ENTWURF');
  const liste=eintraege.map(e=>({user_id:clean(e.user_id,120),rolle:clean(e.rolle,20)||'teilnehmer'})).filter(e=>e.user_id).slice(0,300);
  if(!liste.length)throw new Error('FAHRT_KEINE_PERSONEN');
  for(const e of liste)if(!['teilnehmer','begleitung'].includes(e.rolle))throw new Error('FAHRT_ROLLE_UNGUELTIG');
  const ph=liste.map(()=>'?').join(',');
  // Eine Abfrage fuer die Kursmitgliedschaft, eine fuer die Traegerzugehoerigkeit - nicht je Person.
  const imKurs=new Set((((await env.DB.prepare(`SELECT user_id FROM memberships WHERE tenant_id=? AND course_id=? AND role='participant' AND user_id IN (${ph})`)
    .bind(tenantId,f.course_id,...liste.map(e=>e.user_id)).all<{user_id:string}>()).results)??[]).map(r=>r.user_id));
  const imTraeger=new Set((((await env.DB.prepare(`SELECT user_id FROM tenant_users WHERE tenant_id=? AND status='active' AND user_id IN (${ph})`)
    .bind(tenantId,...liste.map(e=>e.user_id)).all<{user_id:string}>()).results)??[]).map(r=>r.user_id));
  for(const e of liste){
    if(e.rolle==='teilnehmer'&&!imKurs.has(e.user_id))throw new Error('FAHRT_NICHT_IM_KURS');
    if(e.rolle==='begleitung'&&!imTraeger.has(e.user_id))throw new Error('FAHRT_BEGLEITUNG_NICHT_GEFUNDEN');
  }
  const ts=nowIso();
  const anweisungen=liste.map(e=>env.DB.prepare('INSERT INTO excursion_participants(id,tenant_id,excursion_id,user_id,rolle,zusage,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(excursion_id,user_id) DO UPDATE SET rolle=excluded.rolle,updated_at=excluded.updated_at')
    .bind(id('exp_'),tenantId,f.id,e.user_id,e.rolle,'offen',ts,ts));
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  return{aufgenommen:liste.length};
}

/** Zusagen darf die Person selbst. Das Einverstaendnis gibt die sorgeberechtigte Person. */
export async function sageFahrtZu(env:Env,auth:CoreAuthContext,tenantId:string,fahrtId:string,zusage:boolean){
  const f=await ladeFahrt(env,tenantId,fahrtId);
  if(f.status==='abgesagt')throw new Error('FAHRT_ABGESAGT');
  const zeile=await env.DB.prepare('SELECT id FROM excursion_participants WHERE excursion_id=? AND tenant_id=? AND user_id=?').bind(f.id,tenantId,auth.userId).first<{id:string}>();
  if(!zeile)throw new Error('FAHRT_NICHT_EINGETRAGEN');
  await env.DB.prepare('UPDATE excursion_participants SET zusage=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(zusage?'zugesagt':'abgesagt',nowIso(),zeile.id,tenantId).run();
  return{zusage:zusage?'zugesagt':'abgesagt'};
}

/**
 * Einverstaendnis erteilen.
 *
 * Nur wer fuer diese Person sorgeberechtigt ist - oder die Person selbst, wenn keine
 * Sorgeberechtigung eingetragen ist (dann ist sie volljaehrig oder der Traeger fuehrt keine).
 * Eine Verwaltung, die das Einverstaendnis selbst setzt, waere eine Unterschrift in fremdem
 * Namen; genau daran scheitert im Schadensfall die Versicherung.
 */
export async function erteileEinverstaendnis(env:Env,auth:CoreAuthContext,tenantId:string,fahrtId:string,userId:string,notfall:Record<string,unknown>={}){
  const f=await ladeFahrt(env,tenantId,fahrtId);
  const person=clean(userId,120);
  const zeile=await env.DB.prepare('SELECT id FROM excursion_participants WHERE excursion_id=? AND tenant_id=? AND user_id=?').bind(f.id,tenantId,person).first<{id:string}>();
  if(!zeile)throw new Error('FAHRT_NICHT_EINGETRAGEN');
  if(person!==auth.userId){
    const sorge=await env.DB.prepare("SELECT 1 AS ok FROM guardianships WHERE tenant_id=? AND guardian_user_id=? AND participant_user_id=? AND status='aktiv'")
      .bind(tenantId,auth.userId,person).first();
    if(!sorge)throw new Error('FAHRT_KEIN_SORGERECHT');
  }else{
    const fremdeSorge=await env.DB.prepare("SELECT 1 AS ok FROM guardianships WHERE tenant_id=? AND participant_user_id=? AND status='aktiv'").bind(tenantId,person).first();
    if(fremdeSorge)throw new Error('FAHRT_SORGEBERECHTIGT_ERFORDERLICH');
  }
  const ts=nowIso();
  await env.DB.prepare('UPDATE excursion_participants SET einverstaendnis_von=?,einverstaendnis_am=?,notfall_kontakt=?,notfall_hinweis=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(auth.userId,ts,clean(notfall.kontakt,200)||null,clean(notfall.hinweis,1000)||null,ts,zeile.id,tenantId).run();
  return{einverstaendnis_am:ts};
}

/**
 * Genehmigen - und dabei pruefen, was am Fahrttag zaehlt.
 *
 * Der Begleitschluessel ist keine Empfehlung: zu wenig Begleitung ist der haeufigste Grund,
 * warum eine Fahrt im Nachhinein als Aufsichtspflichtverletzung gilt.
 */
export async function entscheideFahrt(env:Env,auth:CoreAuthContext,tenantId:string,fahrtId:string,genehmigt:boolean,begruendung:string){
  requireRole(auth,'tenant_admin');
  const f=await ladeFahrt(env,tenantId,fahrtId);
  if(!['entwurf','beantragt'].includes(f.status))throw new Error('FAHRT_BEREITS_ENTSCHIEDEN');
  const text=clean(begruendung,4000);
  if(text.length<20)throw new Error('FAHRT_BEGRUENDUNG_ERFORDERLICH');
  if(genehmigt){
    const zahlen=await env.DB.prepare(`SELECT
      SUM(CASE WHEN rolle='teilnehmer' AND zusage='zugesagt' THEN 1 ELSE 0 END) AS teilnehmer,
      SUM(CASE WHEN rolle='begleitung' THEN 1 ELSE 0 END) AS begleitung
      FROM excursion_participants WHERE excursion_id=? AND tenant_id=?`).bind(f.id,tenantId).first<{teilnehmer:number;begleitung:number}>();
    const teilnehmer=Number(zahlen?.teilnehmer??0),begleitung=Number(zahlen?.begleitung??0);
    if(!teilnehmer)throw new Error('FAHRT_KEINE_ZUSAGEN');
    const noetig=Math.ceil(teilnehmer/f.begleitung_je_teilnehmer);
    if(begleitung<noetig)throw new Error('FAHRT_BEGLEITUNG_ZU_WENIG');
  }
  const ts=nowIso();
  await env.DB.prepare('UPDATE excursions SET status=?,entscheidung_begruendung=?,entschieden_von=?,entschieden_am=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(genehmigt?'genehmigt':'abgelehnt',text,auth.userId,ts,ts,f.id,tenantId).run();
  await audit(env.DB,auth.userId,'excursion.decided',tenantId,f.course_id,'excursion',f.id,{genehmigt});
  return{status:genehmigt?'genehmigt':'abgelehnt'};
}

/**
 * Die Notfallliste fuer den Tag.
 *
 * Nur die Leitung und die Traegerleitung sehen sie - es sind Gesundheitshinweise und private
 * Rufnummern. Wer ohne Einverstaendnis dasteht, faehrt nicht mit; das steht hier ausdruecklich
 * drin, statt es der Leitung am Bus zu ueberlassen.
 */
export async function notfallliste(env:Env,auth:CoreAuthContext,tenantId:string,fahrtId:string){
  const f=await ladeFahrt(env,tenantId,fahrtId);
  if(f.leitung_user_id!==auth.userId)requireRole(auth,'tenant_admin');
  if(f.status!=='genehmigt'&&f.status!=='durchgefuehrt')throw new Error('FAHRT_NICHT_GENEHMIGT');
  const zeilen=((await env.DB.prepare(`SELECT p.user_id,u.display_name,p.rolle,p.zusage,p.einverstaendnis_am,p.notfall_kontakt,p.notfall_hinweis
    FROM excursion_participants p JOIN users u ON u.id=p.user_id WHERE p.excursion_id=? AND p.tenant_id=? ORDER BY p.rolle,u.display_name`)
    .bind(f.id,tenantId).all<Record<string,unknown>>()).results)??[];
  const faehrtMit=zeilen.filter(z=>z.rolle==='begleitung'||(z.zusage==='zugesagt'&&z.einverstaendnis_am));
  const nichtMit=zeilen.filter(z=>z.rolle==='teilnehmer'&&z.zusage==='zugesagt'&&!z.einverstaendnis_am);
  return{fahrt:{id:f.id,titel:f.titel,beginnt_am:f.beginnt_am,endet_am:f.endet_am},
    faehrt_mit:faehrtMit,ohne_einverstaendnis:nichtMit,
    anzahl:faehrtMit.filter(z=>z.rolle==='teilnehmer').length,begleitung:faehrtMit.filter(z=>z.rolle==='begleitung').length};
}

/** Der Nachweis danach: was stattgefunden hat und wer wirklich dabei war. */
export async function weiseFahrtNach(env:Env,auth:CoreAuthContext,tenantId:string,fahrtId:string,bericht:string,teilgenommen:string[]){
  const f=await ladeFahrt(env,tenantId,fahrtId);
  if(f.leitung_user_id!==auth.userId)requireRole(auth,'class_admin');
  if(f.status!=='genehmigt')throw new Error('FAHRT_NICHT_GENEHMIGT');
  const text=clean(bericht,8000);
  if(text.length<20)throw new Error('FAHRT_BERICHT_ERFORDERLICH');
  const dabei=[...new Set(teilgenommen.map(v=>clean(v,120)).filter(Boolean))].slice(0,300);
  const ts=nowIso();
  const anweisungen=[env.DB.prepare("UPDATE excursion_participants SET teilgenommen=0,updated_at=? WHERE excursion_id=? AND tenant_id=?").bind(ts,f.id,tenantId)];
  if(dabei.length){
    const ph=dabei.map(()=>'?').join(',');
    anweisungen.push(env.DB.prepare(`UPDATE excursion_participants SET teilgenommen=1,updated_at=? WHERE excursion_id=? AND tenant_id=? AND user_id IN (${ph})`)
      .bind(ts,f.id,tenantId,...dabei));
  }
  anweisungen.push(env.DB.prepare("UPDATE excursions SET status='durchgefuehrt',nachweis=?,nachweis_am=?,updated_at=? WHERE id=? AND tenant_id=?").bind(text,ts,ts,f.id,tenantId));
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'excursion.documented',tenantId,f.course_id,'excursion',f.id,{teilnehmer:dabei.length});
  return{status:'durchgefuehrt',teilgenommen:dabei.length};
}

export async function sageFahrtAb(env:Env,auth:CoreAuthContext,tenantId:string,fahrtId:string,grund:string){
  requireRole(auth,'class_admin');
  const f=await ladeFahrt(env,tenantId,fahrtId);
  if(f.status==='durchgefuehrt')throw new Error('FAHRT_BEREITS_DURCHGEFUEHRT');
  const text=clean(grund,2000);
  if(text.length<10)throw new Error('FAHRT_ABSAGEGRUND_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.prepare("UPDATE excursions SET status='abgesagt',entscheidung_begruendung=?,updated_at=? WHERE id=? AND tenant_id=?").bind(text,ts,f.id,tenantId).run();
  return{status:'abgesagt'};
}

/** Die Fahrten eines Traegers - mit dem Rueckmeldestand, in zwei Abfragen. */
export async function fahrtenUebersicht(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  const fahrten=((await env.DB.prepare(`SELECT e.id,e.titel,e.ziel,e.beginnt_am,e.endet_am,e.status,e.rueckmeldung_bis,e.kosten_cent,c.name AS kurs,u.display_name AS leitung
    FROM excursions e JOIN courses c ON c.id=e.course_id JOIN users u ON u.id=e.leitung_user_id
    WHERE e.tenant_id=? ORDER BY e.beginnt_am DESC LIMIT 100`).bind(tenantId).all<Record<string,unknown>>()).results)??[];
  if(!fahrten.length)return{fahrten:[]};
  const ph=fahrten.map(()=>'?').join(',');
  const stand=((await env.DB.prepare(`SELECT excursion_id,
    SUM(CASE WHEN rolle='teilnehmer' THEN 1 ELSE 0 END) AS eingeladen,
    SUM(CASE WHEN rolle='teilnehmer' AND zusage='zugesagt' THEN 1 ELSE 0 END) AS zugesagt,
    SUM(CASE WHEN rolle='teilnehmer' AND einverstaendnis_am IS NOT NULL THEN 1 ELSE 0 END) AS einverstanden,
    SUM(CASE WHEN rolle='begleitung' THEN 1 ELSE 0 END) AS begleitung
    FROM excursion_participants WHERE tenant_id=? AND excursion_id IN (${ph}) GROUP BY excursion_id`)
    .bind(tenantId,...fahrten.map(f=>String(f.id))).all<Record<string,unknown>>()).results)??[];
  const karte=new Map(stand.map(s=>[String(s.excursion_id),s]));
  return{fahrten:fahrten.map(f=>({...f,stand:karte.get(String(f.id))??{eingeladen:0,zugesagt:0,einverstanden:0,begleitung:0}}))};
}

/** Meine Fahrten - fuer Teilnehmende und Sorgeberechtigte. */
export async function meineFahrten(env:Env,auth:CoreAuthContext,tenantId:string){
  return ((await env.DB.prepare(`SELECT e.id,e.titel,e.ziel,e.beginnt_am,e.rueckmeldung_bis,e.kosten_cent,e.status,p.user_id,u.display_name,p.zusage,p.einverstaendnis_am
    FROM excursion_participants p JOIN excursions e ON e.id=p.excursion_id JOIN users u ON u.id=p.user_id
    WHERE p.tenant_id=? AND (p.user_id=? OR p.user_id IN (SELECT participant_user_id FROM guardianships WHERE tenant_id=? AND guardian_user_id=? AND status='aktiv'))
      AND e.status NOT IN ('abgesagt','abgelehnt') ORDER BY e.beginnt_am LIMIT 100`)
    .bind(tenantId,auth.userId,tenantId,auth.userId).all()).results)??[];
}

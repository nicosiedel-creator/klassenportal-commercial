import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString, sha256Text } from './utils.js';

// Angebote und Vertraege fuer Kurse (Kostentraegerunterlagen).
//
// Der Traeger verkauft seine Massnahme an einen Kostentraeger: Agentur, Jobcenter,
// Rentenversicherung, einen Betrieb oder die Person selbst. Bisher lief das komplett ausserhalb -
// Word-Datei, Kostenaufstellung von Hand, Massnahmeplan getippt. Drei Folgen, und die erste ist
// die teure:
//
//  - Der GETIPPTE PLAN WEICHT VOM UNTERRICHT AB. Genau das prueft der Kostentraeger spaeter
//    gegen den Anwesenheitsnachweis; dort entstehen Rueckforderungen.
//  - Welche Anlage welcher Kostentraeger braucht, wusste die Person, die es zuletzt gemacht hat.
//  - Nach der Zusage trug jemand jeden Foerderfall einzeln nach - mit derselben
//    Massnahmenummer, die im Angebot stand, nur abgetippt.
//
// Deshalb: der Massnahmeplan wird ABGELEITET. Aus Kursdauer, Stundenplan und Lernfeldern. Ueber
// den abgeleiteten Plan steht eine Pruefsumme - aendert sich der Unterricht nach dem Versand,
// passt das Angebot nicht mehr, und das faellt auf, bevor jemand es annimmt.

const clean=(v:unknown,n=2000)=>safeString(v,n);
export const KOSTENTRAEGER=['agentur_fuer_arbeit','jobcenter','rentenversicherung','berufsgenossenschaft','betrieb','land','selbstzahler','sonstige'] as const;
export const ANLAGENARTEN=['massnahmeplan','kostenaufstellung','zulassung','lehrplan','raumkonzept','dozentenprofil','sonstiges'] as const;

/**
 * Welche Anlagen welcher Kostentraeger verlangt.
 *
 * Das steht hier und nicht im Kopf der Person, die es zuletzt gemacht hat. Die oeffentliche
 * Hand will die Zulassung sehen (AZAV) und die Massnahmenummer; ein Betrieb, der eine
 * Weiterbildung einkauft, will wissen, was unterrichtet wird und was es kostet.
 */
export const PFLICHTANLAGEN:Record<string,string[]>={
  agentur_fuer_arbeit:['massnahmeplan','kostenaufstellung','zulassung'],
  jobcenter:['massnahmeplan','kostenaufstellung','zulassung'],
  rentenversicherung:['massnahmeplan','kostenaufstellung','zulassung'],
  berufsgenossenschaft:['massnahmeplan','kostenaufstellung'],
  land:['massnahmeplan','kostenaufstellung'],
  betrieb:['massnahmeplan','kostenaufstellung'],
  selbstzahler:['kostenaufstellung'],
  sonstige:['kostenaufstellung'],
};
/** Kostentraeger, bei denen die Massnahmenummer zur Abrechnung gehoert. */
const BRAUCHT_MASSNAHMENUMMER=new Set(['agentur_fuer_arbeit','jobcenter','rentenversicherung']);

export interface Massnahmeplan{
  kurs:string;kurscode:string;beginn:string|null;ende:string|null;
  unterrichtseinheiten:number;stunden:number;wochen:number;
  lernfelder:{code:string;titel:string;minuten:number}[];
  faecher:{fach:string;stunden:number}[];
}

/**
 * Den Massnahmeplan ABLEITEN - aus dem, was wirklich geplant ist.
 *
 * Drei Abfragen, unabhaengig von der Kursgroesse. Eine Unterrichtseinheit sind 45 Minuten; das
 * ist die Einheit, in der Kostentraeger rechnen, und deshalb die Einheit, in der der Plan
 * spricht.
 */
export async function leiteMassnahmeplanAb(env:Env,tenantId:string,courseId:string):Promise<Massnahmeplan>{
  const kurs=await env.DB.prepare('SELECT name,code,start_date,end_date FROM courses WHERE id=? AND tenant_id=?')
    .bind(clean(courseId,120),tenantId).first<{name:string;code:string;start_date:string|null;end_date:string|null}>();
  if(!kurs)throw new Error('ANGEBOT_KURS_NICHT_GEFUNDEN');
  const stunden=((await env.DB.prepare(`SELECT COALESCE(s.name,l.notes,'Unterricht') AS fach,
      SUM((julianday(l.ends_at)-julianday(l.starts_at))*24*60) AS minuten
    FROM lessons l LEFT JOIN subjects s ON s.id=l.subject_id
    WHERE l.tenant_id=? AND l.course_id=? GROUP BY fach ORDER BY minuten DESC LIMIT 60`)
    .bind(tenantId,courseId).all<{fach:string;minuten:number}>()).results)??[];
  // Die Lernfelder kommen ueber den Rahmenplan, der dem Kurs zugeordnet ist - nicht ueber eine
  // eigene Liste im Angebot. Sonst stuende im Angebot ein Lehrplan, den der Kurs nicht hat.
  const lernfelder=((await env.DB.prepare(`SELECT ci.code,ci.title,COALESCE(ci.target_minutes,0) AS minuten
    FROM curriculum_items ci JOIN course_curriculum_bindings b ON b.framework_id=ci.framework_id
    WHERE ci.tenant_id=? AND b.tenant_id=ci.tenant_id AND b.course_id=? ORDER BY ci.sort_order,ci.code LIMIT 80`)
    .bind(tenantId,courseId).all<{code:string;title:string;minuten:number}>()).results)??[];
  const gesamtMinuten=stunden.reduce((a,z)=>a+Math.max(0,Math.round(Number(z.minuten)||0)),0);
  const tage=kurs.start_date&&kurs.end_date?Math.max(1,Math.round((Date.parse(kurs.end_date)-Date.parse(kurs.start_date))/86400000)):0;
  return{
    kurs:kurs.name,kurscode:kurs.code,beginn:kurs.start_date,ende:kurs.end_date,
    // 45 Minuten sind eine Unterrichtseinheit - so rechnet der Kostentraeger, also rechnet der
    // Plan auch so. Abgerundet wird bewusst: eine angefangene Einheit ist keine geleistete.
    // Aufrunden hiesse, dem Kostentraeger mehr Unterricht zuzusagen, als der Stundenplan hergibt -
    // und genau diese Differenz wird spaeter gegen den Anwesenheitsnachweis gerechnet.
    unterrichtseinheiten:Math.floor(gesamtMinuten/45),
    stunden:Math.floor(gesamtMinuten/60),
    wochen:tage?Math.round(tage/7):0,
    lernfelder:lernfelder.map(l=>({code:l.code,titel:l.title,minuten:Math.max(0,Math.round(Number(l.minuten)||0))})),
    faecher:stunden.map(s=>({fach:String(s.fach),stunden:Math.floor((Number(s.minuten)||0)/60)})),
  };
}

const planPruefsumme=(plan:Massnahmeplan)=>sha256Text(JSON.stringify({
  ue:plan.unterrichtseinheiten,wochen:plan.wochen,beginn:plan.beginn,ende:plan.ende,
  lernfelder:plan.lernfelder.map(l=>`${l.code}:${l.minuten}`),faecher:plan.faecher.map(f=>`${f.fach}:${f.stunden}`)}));

export async function legeAngebotAn(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const courseId=clean(input.course_id,120);
  const art=clean(input.kostentraeger_art,40);
  if(!(KOSTENTRAEGER as readonly string[]).includes(art))throw new Error('ANGEBOT_KOSTENTRAEGER_UNGUELTIG');
  const name=clean(input.kostentraeger_name,200);
  if(name.length<2)throw new Error('ANGEBOT_EMPFAENGER_ERFORDERLICH');
  const preis=Math.trunc(Number(input.preis_je_teilnehmer_cent??-1));
  if(!Number.isFinite(preis)||preis<0)throw new Error('ANGEBOT_PREIS_UNGUELTIG');
  const plaetze=Math.trunc(Number(input.plaetze??0));
  if(!Number.isFinite(plaetze)||plaetze<1||plaetze>500)throw new Error('ANGEBOT_PLAETZE_UNGUELTIG');
  const gueltig=clean(input.gueltig_bis,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(gueltig))throw new Error('ANGEBOT_FRIST_ERFORDERLICH');
  const plan=await leiteMassnahmeplanAb(env,tenantId,courseId);
  // Ein Angebot ueber einen Kurs ohne geplanten Unterricht waere eine Zusage ins Blaue - und
  // beim ersten Nachweis ein Problem.
  if(!plan.unterrichtseinheiten)throw new Error('ANGEBOT_OHNE_UNTERRICHT');
  const pruefsumme=await planPruefsumme(plan);
  const ts=nowIso(),angebotId=id('ang_');
  await env.DB.prepare(`INSERT INTO course_offers(id,tenant_id,course_id,nummer,kostentraeger_art,kostentraeger_name,ansprechpartner,empfaenger_email,aktenzeichen,massnahmenummer,preis_je_teilnehmer_cent,plaetze,plan_json,plan_pruefsumme,gueltig_bis,status,erstellt_von,created_at,updated_at)
    SELECT ?,?,?,COALESCE(MAX(nummer),0)+1,?,?,?,?,?,?,?,?,?,?,?,'entwurf',?,?,? FROM course_offers WHERE tenant_id=?`)
    .bind(angebotId,tenantId,courseId,art,name,clean(input.ansprechpartner,200)||null,clean(input.empfaenger_email,200)||null,
      clean(input.aktenzeichen,80)||null,clean(input.massnahmenummer,80)||null,preis,plaetze,
      JSON.stringify(plan),pruefsumme,gueltig,auth.userId,ts,ts,tenantId).run();
  // Der Massnahmeplan ist die erste Anlage, und er ist abgeleitet - nicht abgetippt.
  await env.DB.prepare("INSERT INTO course_offer_attachments(id,tenant_id,offer_id,art,titel,inhalt_json,abgeleitet,created_at) VALUES(?,?,?,'massnahmeplan',?,?,1,?)")
    .bind(id('ana_'),tenantId,angebotId,`Maßnahmeplan ${plan.kurscode}`,JSON.stringify(plan),ts).run();
  const zeile=await env.DB.prepare('SELECT nummer FROM course_offers WHERE id=? AND tenant_id=?').bind(angebotId,tenantId).first<{nummer:number}>();
  await audit(env.DB,auth.userId,'course_offer.created',tenantId,courseId,'course_offer',angebotId,{art,plaetze});
  return{id:angebotId,nummer:Number(zeile?.nummer??0),summe_cent:preis*plaetze,plan,status:'entwurf'};
}

async function ladeAngebot(env:Env,tenantId:string,angebotId:string){
  const a=await env.DB.prepare('SELECT * FROM course_offers WHERE id=? AND tenant_id=?').bind(clean(angebotId,120),tenantId).first<Record<string,unknown>>();
  if(!a)throw new Error('ANGEBOT_NICHT_GEFUNDEN');
  return a;
}

/** Eine Anlage beilegen - abgeleitet oder aus der Medienbibliothek. */
export async function legeAnlageBei(env:Env,auth:CoreAuthContext,tenantId:string,angebotId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const a=await ladeAngebot(env,tenantId,angebotId);
  if(a.status!=='entwurf')throw new Error('ANGEBOT_NICHT_MEHR_ENTWURF');
  const art=clean(input.art,40);
  if(!(ANLAGENARTEN as readonly string[]).includes(art))throw new Error('ANGEBOT_ANLAGENART_UNGUELTIG');
  const titel=clean(input.titel,200);
  if(titel.length<3)throw new Error('ANGEBOT_ANLAGENTITEL_ERFORDERLICH');
  const medium=clean(input.media_asset_id,120)||null;
  const inhalt=input.inhalt!==undefined?JSON.stringify(input.inhalt):null;
  if(!medium&&!inhalt)throw new Error('ANGEBOT_ANLAGE_LEER');
  if(medium){
    const m=await env.DB.prepare("SELECT 1 AS ok FROM media_assets WHERE id=? AND tenant_id=? AND status='aktiv'").bind(medium,tenantId).first();
    if(!m)throw new Error('ANGEBOT_ANLAGE_NICHT_GEFUNDEN');
  }
  await env.DB.prepare('INSERT INTO course_offer_attachments(id,tenant_id,offer_id,art,titel,inhalt_json,media_asset_id,abgeleitet,created_at) VALUES(?,?,?,?,?,?,?,0,?) ON CONFLICT(offer_id,art) DO UPDATE SET titel=excluded.titel,inhalt_json=excluded.inhalt_json,media_asset_id=excluded.media_asset_id')
    .bind(id('ana_'),tenantId,a.id,art,titel,inhalt,medium,nowIso()).run();
  return{art,titel};
}

/**
 * Versenden - der Punkt, an dem geprueft wird.
 *
 * Fehlt eine Pflichtanlage, geht das Angebot nicht hinaus. Ein Angebot, das ohne Zulassung bei
 * der Agentur landet, kommt nicht "mit Nachfrage" zurueck, sondern gar nicht.
 */
export async function versendeAngebot(env:Env,auth:CoreAuthContext,tenantId:string,angebotId:string,heute?:string){
  requireRole(auth,'tenant_admin');
  const a=await ladeAngebot(env,tenantId,angebotId);
  if(a.status!=='entwurf')throw new Error('ANGEBOT_NICHT_MEHR_ENTWURF');
  const tag=clean(heute,10)||nowIso().slice(0,10);
  if(String(a.gueltig_bis)<tag)throw new Error('ANGEBOT_FRIST_VERGANGEN');
  const art=String(a.kostentraeger_art);
  if(BRAUCHT_MASSNAHMENUMMER.has(art)&&!clean(a.massnahmenummer,80))throw new Error('ANGEBOT_MASSNAHMENUMMER_ERFORDERLICH');
  const vorhanden=new Set(((await env.DB.prepare('SELECT art FROM course_offer_attachments WHERE offer_id=? AND tenant_id=?')
    .bind(a.id,tenantId).all<{art:string}>()).results??[]).map(z=>z.art));
  const fehlend=(PFLICHTANLAGEN[art]??[]).filter(p=>!vorhanden.has(p));
  if(fehlend.length)throw new Error('ANGEBOT_PFLICHTANLAGE_FEHLT');
  const ts=nowIso();
  await env.DB.prepare("UPDATE course_offers SET status='versendet',versendet_am=?,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(ts,ts,a.id,tenantId).run();
  await audit(env.DB,auth.userId,'course_offer.sent',tenantId,String(a.course_id),'course_offer',String(a.id),{art});
  return{status:'versendet',versendet_am:ts};
}

/**
 * Passt das Angebot noch zum Unterricht?
 *
 * Wer nach dem Versand den Stundenplan aendert, aendert den Massnahmeplan - und damit das, was
 * der Kostentraeger zugesagt bekommen hat. Die Pruefsumme macht das sichtbar, bevor jemand
 * annimmt.
 */
export async function pruefeAngebotAktuell(env:Env,tenantId:string,angebotId:string){
  const a=await ladeAngebot(env,tenantId,angebotId);
  const jetzt=await leiteMassnahmeplanAb(env,tenantId,String(a.course_id));
  const pruefsumme=await planPruefsumme(jetzt);
  return{unveraendert:pruefsumme===String(a.plan_pruefsumme),
    plan_damals:JSON.parse(String(a.plan_json||'{}')) as Massnahmeplan,plan_heute:jetzt};
}

/**
 * Die Zusage - und der Punkt, an dem aus einem Angebot Betrieb wird.
 *
 * Der Vertrag entsteht, und aus ihm die Foerderfaelle der Teilnehmenden: mit derselben
 * Massnahmenummer, die im Angebot stand. Sie abzutippen war der Weg, auf dem die Nummer in der
 * Haelfte der Akten falsch stand.
 */
export async function nimmAngebotAn(env:Env,auth:CoreAuthContext,tenantId:string,angebotId:string,input:Record<string,unknown>={}){
  requireRole(auth,'tenant_admin');
  const a=await ladeAngebot(env,tenantId,angebotId);
  if(a.status!=='versendet')throw new Error('ANGEBOT_NICHT_VERSENDET');
  const tag=clean(input.heute,10)||nowIso().slice(0,10);
  // Ein abgelaufenes Angebot anzunehmen hiesse, den Traeger an einen Preis zu binden, den er
  // ausdruecklich befristet hatte.
  if(String(a.gueltig_bis)<tag)throw new Error('ANGEBOT_ABGELAUFEN');
  const stand=await pruefeAngebotAktuell(env,tenantId,angebotId);
  if(!stand.unveraendert)throw new Error('ANGEBOT_PLAN_GEAENDERT');
  const nummer=clean(input.vertragsnummer,80)||`V-${String(a.nummer).padStart(4,'0')}`;
  const ts=nowIso(),vertragId=id('vtr_');
  const plan=stand.plan_damals;
  const anweisungen=[
    env.DB.prepare("UPDATE course_offers SET status='angenommen',entschieden_am=?,updated_at=? WHERE id=? AND tenant_id=?").bind(ts,ts,a.id,tenantId),
    env.DB.prepare('INSERT INTO course_contracts(id,tenant_id,offer_id,course_id,vertragsnummer,kostentraeger_art,kostentraeger_name,massnahmenummer,aktenzeichen,preis_je_teilnehmer_cent,plaetze,laufzeit_von,laufzeit_bis,plan_pruefsumme,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .bind(vertragId,tenantId,a.id,String(a.course_id),nummer,String(a.kostentraeger_art),String(a.kostentraeger_name),
        a.massnahmenummer??null,a.aktenzeichen??null,Number(a.preis_je_teilnehmer_cent),Number(a.plaetze),
        plan.beginn??null,plan.ende??null,String(a.plan_pruefsumme),'aktiv',ts,ts)];
  // Die Foerderfaelle der bereits eingeschriebenen Teilnehmenden - eine Abfrage, ein Stapel.
  const teilnehmer=((await env.DB.prepare("SELECT user_id FROM memberships WHERE tenant_id=? AND course_id=? AND role='participant' LIMIT 500")
    .bind(tenantId,String(a.course_id)).all<{user_id:string}>()).results)??[];
  for(const t of teilnehmer)
    anweisungen.push(env.DB.prepare(`INSERT INTO participant_funding_cases(id,tenant_id,course_id,user_id,cost_bearer,cost_bearer_name,case_number,measure_number,entered_on,planned_exit_on,status,created_by,created_at,updated_at)
      SELECT ?,?,?,?,?,?,?,?,?,?,'aktiv',?,?,? WHERE NOT EXISTS(SELECT 1 FROM participant_funding_cases WHERE tenant_id=? AND course_id=? AND user_id=? AND status='aktiv')`)
      .bind(id('foe_'),tenantId,String(a.course_id),t.user_id,String(a.kostentraeger_art),String(a.kostentraeger_name),
        a.aktenzeichen??null,a.massnahmenummer??null,plan.beginn??tag,plan.ende??null,auth.userId,ts,ts,
        tenantId,String(a.course_id),t.user_id));
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  await audit(env.DB,auth.userId,'course_offer.accepted',tenantId,String(a.course_id),'course_contract',vertragId,{teilnehmer:teilnehmer.length});
  return{vertrag_id:vertragId,vertragsnummer:nummer,foerderfaelle:teilnehmer.length,
    summe_cent:Number(a.preis_je_teilnehmer_cent)*Number(a.plaetze)};
}

export async function lehneAngebotAb(env:Env,auth:CoreAuthContext,tenantId:string,angebotId:string,grund:string){
  requireRole(auth,'tenant_admin');
  const a=await ladeAngebot(env,tenantId,angebotId);
  if(a.status!=='versendet')throw new Error('ANGEBOT_NICHT_VERSENDET');
  const text=clean(grund,2000);
  // Der Grund ist die einzige Rueckmeldung, aus der sich das naechste Angebot verbessern laesst.
  if(text.length<5)throw new Error('ANGEBOT_ABLEHNUNGSGRUND_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.prepare("UPDATE course_offers SET status='abgelehnt',ablehnungsgrund=?,entschieden_am=?,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(text,ts,ts,a.id,tenantId).run();
  return{status:'abgelehnt'};
}

/** Abgelaufene Angebote schliessen - von allein, nicht von Hand. */
export async function schliesseAbgelaufeneAngebote(env:Env,tenantId:string,heute?:string){
  const tag=clean(heute,10)||nowIso().slice(0,10);
  const r=await env.DB.prepare("UPDATE course_offers SET status='abgelaufen',updated_at=? WHERE tenant_id=? AND status IN ('entwurf','versendet') AND gueltig_bis<?")
    .bind(nowIso(),tenantId,tag).run();
  return{abgelaufen:Number(r?.meta?.changes??0)};
}

/** Die Angebotsmappe - mit Summe und Anlagenstand, in drei Abfragen. */
export async function angebotsmappe(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  const angebote=((await env.DB.prepare(`SELECT a.id,a.nummer,a.kostentraeger_art,a.kostentraeger_name,a.status,a.plaetze,
    a.preis_je_teilnehmer_cent,a.gueltig_bis,a.massnahmenummer,c.name AS kurs
    FROM course_offers a JOIN courses c ON c.id=a.course_id WHERE a.tenant_id=? ORDER BY a.nummer DESC LIMIT 200`)
    .bind(tenantId).all<Record<string,unknown>>()).results)??[];
  if(!angebote.length)return{angebote:[],vertraege:[]};
  const ph=angebote.map(()=>'?').join(',');
  const anlagen=((await env.DB.prepare(`SELECT offer_id,art FROM course_offer_attachments WHERE tenant_id=? AND offer_id IN (${ph})`)
    .bind(tenantId,...angebote.map(a=>String(a.id))).all<{offer_id:string;art:string}>()).results)??[];
  const vertraege=((await env.DB.prepare(`SELECT v.id,v.vertragsnummer,v.kostentraeger_name,v.plaetze,v.preis_je_teilnehmer_cent,v.status,c.name AS kurs
    FROM course_contracts v JOIN courses c ON c.id=v.course_id WHERE v.tenant_id=? ORDER BY v.created_at DESC LIMIT 200`)
    .bind(tenantId).all<Record<string,unknown>>()).results)??[];
  return{angebote:angebote.map(a=>{
    const eigene=anlagen.filter(x=>x.offer_id===a.id).map(x=>x.art);
    const pflicht=PFLICHTANLAGEN[String(a.kostentraeger_art)]??[];
    return{...a,summe_cent:Number(a.preis_je_teilnehmer_cent)*Number(a.plaetze),
      anlagen:eigene,
      // Was noch fehlt, bevor es hinausgehen kann - der Satz, der in der Liste stehen muss.
      fehlende_anlagen:pflicht.filter(p=>!eigene.includes(p))};
  }),vertraege};
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { woerter } from './document-versions.js';
import { id, nowIso, safeString } from './utils.js';

// Wissensbasis und kontextbezogene Hilfe (S2).
//
// Die Hilfe stand im Handbuch, das niemand oeffnet. "Kontextbezogen" heisst hier nicht
// "irgendwo verlinkt", sondern: wer auf der Stundenplanseite Hilfe ruft, bekommt die
// Stundenplanartikel - nicht das Inhaltsverzeichnis.
//
// Zwei Entscheidungen tragen den Rest:
//  - Kein FTS5. Es legt fuenf Schattentabellen an, die keine der Fail-Closed-Registries kennt;
//    Auskunft und Mandantenloeschung wuerden sie uebersehen. Stattdessen derselbe eigene
//    invertierte Index wie beim Dokumentenarchiv.
//  - Jede veroeffentlichte Fassung bleibt lesbar. Wer heute anders handelt als gestern, muss
//    nachlesen koennen, was gestern dort stand - sonst ist die Anweisung nicht nachweisbar.

const clean=(v:unknown,n=20000)=>safeString(v,n);
const TITELGEWICHT=5;
// Mehr Bereiche bindet niemand sinnvoll an einen Artikel; die Grenze haelt auch die Abfrage klein.
const HOECHSTBEREICHE=12;

const bereichsliste=(v:unknown):string[]=>{
  const roh=Array.isArray(v)?v:String(v??'').split(',');
  return [...new Set(roh.map(b=>safeString(b,80).trim().toLowerCase()).filter(Boolean))].slice(0,HOECHSTBEREICHE);
};

export async function legeArtikelAn(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const slug=clean(input.slug,120).toLowerCase().replace(/[^a-z0-9-]+/g,'-').replace(/^-+|-+$/g,'');
  if(slug.length<3)throw new Error('WISSEN_SLUG_ERFORDERLICH');
  const titel=clean(input.titel,200);
  if(titel.length<5)throw new Error('WISSEN_TITEL_ERFORDERLICH');
  const inhalt=clean(input.inhalt,20000);
  if(inhalt.length<20)throw new Error('WISSEN_INHALT_ERFORDERLICH');
  const vorhanden=await env.DB.prepare('SELECT 1 AS ok FROM knowledge_articles WHERE tenant_id=? AND slug=?').bind(tenantId,slug).first();
  if(vorhanden)throw new Error('WISSEN_SLUG_VERGEBEN');
  const ts=nowIso(),artikelId=id('wis_');
  await env.DB.prepare('INSERT INTO knowledge_articles(id,tenant_id,plattformweit,slug,titel,inhalt,bereiche_json,fassung,status,verfasst_von,created_at,updated_at) VALUES(?,?,0,?,?,?,?,1,?,?,?,?)')
    .bind(artikelId,tenantId,slug,titel,inhalt,JSON.stringify(bereichsliste(input.bereiche)),'entwurf',auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'knowledge.created',tenantId,undefined,'knowledge_article',artikelId,{slug});
  return{id:artikelId,slug,status:'entwurf',fassung:1};
}

export async function bearbeiteArtikel(env:Env,auth:CoreAuthContext,tenantId:string,artikelId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const a=await ladeArtikel(env,tenantId,artikelId);
  if(a.status==='zurueckgezogen')throw new Error('WISSEN_ZURUECKGEZOGEN');
  const titel=clean(input.titel,200)||a.titel,inhalt=clean(input.inhalt,20000)||a.inhalt;
  if(titel.length<5)throw new Error('WISSEN_TITEL_ERFORDERLICH');
  if(inhalt.length<20)throw new Error('WISSEN_INHALT_ERFORDERLICH');
  const bereiche=input.bereiche===undefined?a.bereiche_json:JSON.stringify(bereichsliste(input.bereiche));
  const ts=nowIso();
  // Bearbeiten setzt den Artikel zurueck auf Entwurf. Ein veroeffentlichter Artikel, der sich
  // unter der Hand aendert, ist genau die Anweisung, auf die sich niemand berufen kann.
  await env.DB.prepare("UPDATE knowledge_articles SET titel=?,inhalt=?,bereiche_json=?,status='entwurf',updated_at=? WHERE id=? AND tenant_id=?")
    .bind(titel,inhalt,bereiche,ts,a.id,tenantId).run();
  return{id:a.id,status:'entwurf'};
}

async function ladeArtikel(env:Env,tenantId:string,artikelId:string){
  const a=await env.DB.prepare('SELECT id,slug,titel,inhalt,bereiche_json,fassung,status,plattformweit FROM knowledge_articles WHERE id=? AND tenant_id=?')
    .bind(clean(artikelId,120),tenantId).first<{id:string;slug:string;titel:string;inhalt:string;bereiche_json:string;fassung:number;status:string;plattformweit:number}>();
  if(!a)throw new Error('WISSEN_NICHT_GEFUNDEN');
  return a;
}

/**
 * Veroeffentlichen: die Fassung wird festgehalten und der Suchindex neu gebaut.
 *
 * Indiziert wird nur, was veroeffentlicht ist. Ein Entwurf in der Suche waere eine Anweisung,
 * die noch niemand freigegeben hat - und genau so entstehen falsche Auskuenfte am Telefon.
 */
export async function veroeffentlicheArtikel(env:Env,auth:CoreAuthContext,tenantId:string,artikelId:string){
  requireRole(auth,'class_admin');
  const a=await ladeArtikel(env,tenantId,artikelId);
  if(a.status==='veroeffentlicht')throw new Error('WISSEN_BEREITS_VEROEFFENTLICHT');
  const ts=nowIso(),neueFassung=a.status==='entwurf'&&a.fassung===1&&!(await env.DB.prepare('SELECT 1 AS ok FROM knowledge_article_versions WHERE article_id=?').bind(a.id).first())
    ? 1 : Number((await env.DB.prepare('SELECT COALESCE(MAX(fassung),0)+1 AS n FROM knowledge_article_versions WHERE article_id=?').bind(a.id).first<{n:number}>())?.n??1);
  const anweisungen=[
    env.DB.prepare('INSERT INTO knowledge_article_versions(id,tenant_id,article_id,fassung,titel,inhalt,bereiche_json,veroeffentlicht_von,veroeffentlicht_am) VALUES(?,?,?,?,?,?,?,?,?)')
      .bind(id('wsf_'),tenantId,a.id,neueFassung,a.titel,a.inhalt,a.bereiche_json,auth.userId,ts),
    env.DB.prepare("UPDATE knowledge_articles SET status='veroeffentlicht',fassung=?,veroeffentlicht_am=?,updated_at=? WHERE id=? AND tenant_id=?")
      .bind(neueFassung,ts,ts,a.id,tenantId),
    env.DB.prepare('DELETE FROM knowledge_search_terms WHERE tenant_id=? AND article_id=?').bind(tenantId,a.id)];
  for(const [quelle,text] of [['titel',a.titel],['inhalt',a.inhalt]] as const)
    for(const [wort,anzahl] of woerter(text))
      anweisungen.push(env.DB.prepare('INSERT INTO knowledge_search_terms(tenant_id,article_id,wort,quelle,anzahl) VALUES(?,?,?,?,?) ON CONFLICT(tenant_id,article_id,wort,quelle) DO UPDATE SET anzahl=excluded.anzahl')
        .bind(tenantId,a.id,wort,quelle,anzahl));
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  await audit(env.DB,auth.userId,'knowledge.published',tenantId,undefined,'knowledge_article',a.id,{fassung:neueFassung});
  return{id:a.id,fassung:neueFassung,status:'veroeffentlicht'};
}

/** Zurueckziehen nimmt den Artikel aus Suche und Hilfe - die Fassungen bleiben lesbar. */
export async function ziehArtikelZurueck(env:Env,auth:CoreAuthContext,tenantId:string,artikelId:string){
  requireRole(auth,'class_admin');
  const a=await ladeArtikel(env,tenantId,artikelId);
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE knowledge_articles SET status='zurueckgezogen',updated_at=? WHERE id=? AND tenant_id=?").bind(ts,a.id,tenantId),
    env.DB.prepare('DELETE FROM knowledge_search_terms WHERE tenant_id=? AND article_id=?').bind(tenantId,a.id)]);
  return{status:'zurueckgezogen'};
}

/**
 * Suchen - UND-verknuepft, in einer Abfrage.
 *
 * Wer zwei Begriffe eingibt, meint beide. Ein Artikel, der nur einen enthaelt, ist kein
 * Treffer, sondern Rauschen.
 */
export async function sucheWissen(env:Env,auth:CoreAuthContext,tenantId:string,frage:unknown,grenze=20){
  const begriffe=[...woerter(frage).keys()].slice(0,8);
  if(!begriffe.length)throw new Error('WISSEN_BEGRIFF_ERFORDERLICH');
  const n=Math.min(Math.max(Number(grenze)||20,1),100);
  const marken=begriffe.map(()=>'?').join(',');
  return ((await env.DB.prepare(`SELECT t.article_id,a.slug,a.titel,COUNT(DISTINCT t.wort) AS treffer,
    SUM(t.anzahl*CASE t.quelle WHEN 'titel' THEN ${TITELGEWICHT} ELSE 1 END) AS punkte
    FROM knowledge_search_terms t JOIN knowledge_articles a ON a.id=t.article_id AND a.tenant_id=t.tenant_id
    WHERE t.tenant_id=? AND a.status='veroeffentlicht' AND t.wort IN (${marken})
    GROUP BY t.article_id,a.slug,a.titel HAVING COUNT(DISTINCT t.wort)=? ORDER BY punkte DESC,a.titel LIMIT ?`)
    .bind(tenantId,...begriffe,begriffe.length,n).all<Record<string,unknown>>()).results)??[];
}

/**
 * Kontextbezogene Hilfe: was gehoert zu DIESEM Bereich?
 *
 * Eine Abfrage, unabhaengig von der Zahl der Artikel. Der Bereich steckt als Liste im Artikel;
 * gesucht wird mit den Trennzeichen drumherum, damit "stundenplan" nicht auch
 * "stundenplan-import" trifft, wenn nur der eine gemeint war.
 */
export async function hilfeZuBereich(env:Env,auth:CoreAuthContext,tenantId:string,bereich:string){
  const b=safeString(bereich,80).trim().toLowerCase();
  if(!b)throw new Error('WISSEN_BEREICH_ERFORDERLICH');
  return ((await env.DB.prepare(`SELECT id,slug,titel,plattformweit FROM knowledge_articles
    WHERE (tenant_id=? OR plattformweit=1) AND status='veroeffentlicht' AND instr(bereiche_json,?)>0
    ORDER BY plattformweit,titel LIMIT 20`).bind(tenantId,`"${b}"`).all<Record<string,unknown>>()).results)??[];
}

/** Einen Artikel lesen - veroeffentlicht fuer alle, Entwuerfe nur fuer die Verwaltung. */
export async function lesArtikel(env:Env,auth:CoreAuthContext,tenantId:string,slugOderId:string){
  const s=clean(slugOderId,120);
  const a=await env.DB.prepare('SELECT id,slug,titel,inhalt,bereiche_json,fassung,status,veroeffentlicht_am FROM knowledge_articles WHERE (tenant_id=? OR plattformweit=1) AND (slug=? OR id=?)')
    .bind(tenantId,s,s).first<Record<string,unknown>>();
  if(!a)throw new Error('WISSEN_NICHT_GEFUNDEN');
  if(a.status!=='veroeffentlicht')requireRole(auth,'class_admin');
  return{artikel:a,bereiche:JSON.parse(String(a.bereiche_json||'[]')) as string[]};
}

/** Die Fassungen eines Artikels - was stand wann dort. */
export async function artikelFassungen(env:Env,auth:CoreAuthContext,tenantId:string,artikelId:string){
  requireRole(auth,'class_admin');
  return ((await env.DB.prepare('SELECT fassung,titel,veroeffentlicht_am FROM knowledge_article_versions WHERE tenant_id=? AND article_id=? ORDER BY fassung DESC LIMIT 50')
    .bind(tenantId,clean(artikelId,120)).all()).results)??[];
}

export async function listeArtikel(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  return ((await env.DB.prepare('SELECT id,slug,titel,status,fassung,bereiche_json,updated_at FROM knowledge_articles WHERE tenant_id=? ORDER BY titel LIMIT 200')
    .bind(tenantId).all()).results)??[];
}

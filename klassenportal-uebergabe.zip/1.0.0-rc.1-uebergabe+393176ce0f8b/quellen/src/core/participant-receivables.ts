import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { hasPermission } from './enterprise-access.js';
import { csvSafeCell } from './gradebook-correctness.js';
import { stapelSchreiben } from './learning-operations.js';
import { id, nowIso, safeString, sha256Text } from './utils.js';

// Debitorenprozess des TRAEGERS gegenueber seinen Teilnehmenden: Schulgeld und Kursgebuehr.
//
// Diese Richtung fehlte im Portal. Vorhanden war jeweils etwas anderes:
//   accounting_* (0061/0062) ist die Buchhaltung des PLATTFORMBETREIBERS,
//   commercial_*/subscriptions/tenant_payment_accounts sind der Verkauf des Portals AN den Traeger,
//   course_fee_collections (0111) ist die Klassenkasse - Kleinbetraege ohne Rechnungslauf.
// "Der Traeger stellt der Teilnehmerin Schulgeld in Rechnung" stand in keiner davon.
//
// Es findet KEIN Zahlungsverkehr statt. PAYMENTS_ENABLED ist false. Dieses Modul zieht nichts ein,
// erzeugt keine SEPA-XML, spricht keine Bank und keinen Dienstleister an und ruft nichts nach
// aussen. Es erfasst das Mandat, stellt die Forderung, kennt die Frist, fuehrt die Mahnstufe und
// gibt eine Buchungsdatei aus. Der Einzug selbst findet ausserhalb des Portals statt; ein
// Zahlungseingang ist hier ein Vermerk von Hand.
//
// Die vollstaendige IBAN wird bewusst NICHT gespeichert - Begruendung siehe Migration 0114 und
// mandatAusIban() weiter unten.

type Row=Record<string,unknown>;
type Art='tuition'|'course_fee';
type Zahlweg='sepa_direct_debit'|'transfer';

// Ein Schulgeld von mehr als 10.000 EUR im Monat ist kein Schulgeld, sondern ein Tippfehler
// (150000 statt 15000). Die Grenze faengt genau den ab.
const BETRAG_MAX_CENT=1000000;
// Eine Mahngebuehr von mehr als 50 EUR waere kein Verzugsschaden mehr.
const GEBUEHR_MAX_CENT=5000;
// So viele Vereinbarungen bzw. offene Posten verarbeitet ein Lauf. Was darueber liegt, wird nicht
// abgeschnitten, sondern ueber next_cursor fortgesetzt: ein Traeger mit 2000 Teilnehmenden soll
// abrechnen koennen, ohne an der Plattformgrenze von 1000 Unteranfragen zu scheitern.
const LAUF_MAX=500;
const ARTEN=new Set(['tuition','course_fee']);
const ZAHLWEGE=new Set(['sepa_direct_debit','transfer']);
const ZAHLARTEN=new Set(['transfer','cash','direct_debit','other']);

// Die Debitorenbuchhaltung ist Traegersache, nicht Klassensache. 'org.manage' ist die Freigabe der
// Verantwortlichen; hasPermission laesst Plattform- und Mandantenadministration ohnehin durch.
// Bewusst NICHT 'courses.manage': wer eine Klasse fuehrt, soll deswegen keine Forderungen stellen
// und keine Mahngebuehren festsetzen koennen.
function darfVerwalten(auth:CoreAuthContext){return hasPermission(auth,'org.manage');}
function assertVerwalten(auth:CoreAuthContext){if(!darfVerwalten(auth))throw new Error('FORBIDDEN_RECEIVABLE_MANAGE');}

function pflicht(v:unknown,fehler:string,max=200){const s=safeString(v,max);if(!s)throw new Error(fehler);return s;}
function optional(v:unknown,max=1000){return safeString(v,max)||null;}
function datum(v:unknown,fehler:string){
  // Grosszuegig lesen, streng pruefen: eine zu lange Eingabe soll den erklaerenden Fehler dieses
  // Feldes ausloesen und nicht die allgemeine Laengenmeldung von safeString.
  const s=safeString(v,40);
  if(!s||!/^\d{4}-\d\d-\d\d$/.test(s)||Number.isNaN(Date.parse(`${s}T00:00:00.000Z`)))throw new Error(fehler);
  return s;
}
function monat(v:unknown,fehler:string){
  const s=safeString(v,40);
  if(!s||!/^\d{4}-\d\d$/.test(s)||Number(s.slice(5,7))<1||Number(s.slice(5,7))>12)throw new Error(fehler);
  return s;
}
// Betraege sind ganzzahlige Cent. Number.isInteger weist 42.5 ebenso ab wie "42,50" - beides
// waere sonst als 42 in der Forderung gelandet und die Differenz haette niemand mehr gefunden.
function centBetrag(v:unknown,fehler:string,minNull=false){
  const n=typeof v==='number'?v:Number(safeString(v,20));
  if(!Number.isInteger(n)||(minNull?n<0:n<=0))throw new Error(fehler);
  return n;
}
function ganzzahl(v:unknown,fehler:string,min:number,max:number){
  const n=typeof v==='number'?v:Number(safeString(v,40));
  if(!Number.isInteger(n)||n<min||n>max)throw new Error(fehler);
  return n;
}
// Ein Konto des Kontenrahmens: 4 bis 8 Ziffern. Ein Buchstabe darin macht die Buchungsdatei fuer
// jede Finanzbuchhaltung unlesbar, und das faellt erst beim Einlesen dort auf.
function konto(v:unknown,fehler:string){
  const s=safeString(v,60);
  if(!s||!/^\d{4,8}$/.test(s))throw new Error(fehler);
  return s;
}
function tage(iso:string,n:number){return new Date(Date.parse(`${iso}T00:00:00.000Z`)+n*86400000).toISOString().slice(0,10);}
function tageZwischen(a:string,b:string){return Math.round((Date.parse(`${b}T00:00:00.000Z`)-Date.parse(`${a}T00:00:00.000Z`))/86400000);}
function monatsEnde(periode:string){
  const jahr=Number(periode.slice(0,4)),m=Number(periode.slice(5,7));
  // Tag 0 des Folgemonats ist der letzte Tag dieses Monats - inklusive Schaltjahr, ohne Tabelle.
  return new Date(Date.UTC(jahr,m,0)).toISOString().slice(0,10);
}

// Anzeige aus ganzen Cent, ohne je durch 100 zu teilen. Eine Division waere hier zwar harmlos,
// aber sie ist der Anfang jeder Rundungsgeschichte - und Kundentexte werden kopiert.
export function alsEuro(cent:number,waehrung='EUR'){
  const v=Math.abs(Math.trunc(cent));
  return `${cent<0?'-':''}${Math.trunc(v/100)},${String(v%100).padStart(2,'0')} ${waehrung}`;
}
// Dieselbe Zahl fuer die Buchungsdatei: Komma als Dezimaltrennzeichen, kein Waehrungszeichen,
// kein Tausenderpunkt. Auch hier ausschliesslich Ganzzahlarithmetik.
function alsBuchungsbetrag(cent:number){
  const v=Math.abs(Math.trunc(cent));
  return `${cent<0?'-':''}${Math.trunc(v/100)},${String(v%100).padStart(2,'0')}`;
}

/**
 * Eine IBAN pruefen und daraus die Merkmale gewinnen, die gespeichert werden duerfen.
 *
 * Die vollstaendige Nummer verlaesst diese Funktion NICHT. Sie wird geprueft (Aufbau und
 * Pruefziffer nach ISO 7064 Modulo 97-10, reine Rechnung ohne jeden Netzzugriff), und danach
 * bleiben nur Laenderkennzeichen, die letzten vier Stellen und ein mandantenbezogener Hash uebrig.
 * Der Hash beantwortet die einzige Frage, die spaeter noch gestellt wird - "ist das dasselbe Konto
 * wie im widerrufenen Mandat?" - ohne die Nummer zu halten.
 *
 * Warum die volle IBAN nicht gespeichert wird: sie wuerde ausschliesslich fuer den Einzug
 * gebraucht, und der findet hier nicht statt. Eine Kontonummer, die niemand benutzt, steht sonst
 * in jedem Mandantenexport, in jedem Backup und in jeder versehentlich mitgeladenen Zeile. Wird
 * der Einzug spaeter freigeschaltet, ist sie eigens neu zu erheben.
 */
async function mandatAusIban(tenantId:string,roh:unknown){
  const eingabe=String(roh??'').replace(/\s+/g,'').toUpperCase();
  if(!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(eingabe))throw new Error('SEPA_IBAN_INVALID');
  // Modulo 97 stellenweise, damit keine Zahl entsteht, die groesser als Number.MAX_SAFE_INTEGER
  // waere - eine 34-stellige IBAN als Zahl waere still ungenau und die Pruefung wertlos.
  const umgestellt=eingabe.slice(4)+eingabe.slice(0,4);
  let rest=0;
  for(const zeichen of umgestellt){
    const wert=zeichen>='0'&&zeichen<='9'?zeichen:String(zeichen.charCodeAt(0)-55);
    for(const ziffer of wert)rest=(rest*10+Number(ziffer))%97;
  }
  if(rest!==1)throw new Error('SEPA_IBAN_INVALID');
  return{
    land:eingabe.slice(0,2),
    letzteVier:eingabe.slice(-4),
    // Mandantenbezogen: derselbe Hash bei zwei Traegern wuerde verraten, dass dieselbe Person
    // dort dasselbe Konto benutzt.
    fingerabdruck:await sha256Text(`sepa:${tenantId}:${eingabe}`),
  };
}

// Die Mandatsreferenz erscheint auf dem Kontoauszug der Person. SEPA laesst hoechstens 35 Zeichen
// aus einem festen Vorrat zu; ein Umlaut darin macht die Referenz beim Kreditinstitut unbrauchbar.
function mandatsreferenz(v:unknown){
  const s=safeString(v,200);
  if(!s||!/^[A-Za-z0-9+?/\-:().,']{1,35}$/.test(s))throw new Error('SEPA_MANDATE_REFERENCE_INVALID');
  return s;
}

// Jede vom Client gelieferte Kennung wird gegen den Mandanten geprueft, nie geglaubt. Ohne diese
// Zeile reichte eine fremde Forderungskennung, um die Debitorenbuchhaltung eines anderen Traegers
// zu lesen oder zu veraendern.
async function ladeForderung(env:Env,tenantId:string,receivableId:string){
  const row=await env.DB.prepare(
    `SELECT id,tenant_id,plan_id,course_id,user_id,document_no,kind,title,period,issued_on,due_on,
            amount_cents,currency,payment_method,mandate_reference,receivable_account,revenue_account,
            status,dunning_level,settled_on,cancelled_on,cancel_reason
       FROM participant_receivables WHERE tenant_id=? AND id=?`
  ).bind(tenantId,receivableId).first<Row>();
  if(!row)throw new Error('RECEIVABLE_NOT_FOUND');
  return row;
}

async function ladeEinstellungen(env:Env,tenantId:string){
  const row=await env.DB.prepare('SELECT * FROM participant_billing_settings WHERE tenant_id=?').bind(tenantId).first<Row>();
  if(!row)throw new Error('RECEIVABLE_SETTINGS_MISSING');
  return row;
}

/** Kontierung und Mahnregeln des Traegers. */
export async function getBillingSettings(env:Env,auth:CoreAuthContext,tenantId:string){
  assertVerwalten(auth);
  const row=await env.DB.prepare('SELECT * FROM participant_billing_settings WHERE tenant_id=?').bind(tenantId).first<Row>();
  return{settings:row??null,configured:!!row};
}

/** Kontierung und Mahnregeln festlegen. Ohne sie laeuft weder ein Lauf noch ein Export. */
export async function saveBillingSettings(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  assertVerwalten(auth);
  const forderungskonto=konto(input.receivable_account,'RECEIVABLE_ACCOUNT_INVALID');
  const erloesSchulgeld=konto(input.revenue_account_tuition,'RECEIVABLE_ACCOUNT_INVALID');
  const erloesKursgebuehr=konto(input.revenue_account_course_fee,'RECEIVABLE_ACCOUNT_INVALID');
  const erloesMahngebuehr=konto(input.revenue_account_dunning_fee,'RECEIVABLE_ACCOUNT_INVALID');
  const bankkonto=konto(input.bank_account,'RECEIVABLE_ACCOUNT_INVALID');
  const glaeubiger=optional(input.creditor_identifier,35);
  const stufe1=ganzzahl(input.dunning_level1_after_days??7,'DUNNING_SCHEDULE_INVALID',0,365);
  const stufe2=ganzzahl(input.dunning_level2_after_days??21,'DUNNING_SCHEDULE_INVALID',0,365);
  const stufe3=ganzzahl(input.dunning_level3_after_days??35,'DUNNING_SCHEDULE_INVALID',0,365);
  if(!(stufe1<stufe2&&stufe2<stufe3))throw new Error('DUNNING_SCHEDULE_INVALID');
  const frist=ganzzahl(input.dunning_deadline_days??14,'DUNNING_SCHEDULE_INVALID',1,90);
  const gebuehr1=centBetrag(input.dunning_level1_fee_cents??0,'DUNNING_FEE_INVALID',true);
  const gebuehr2=centBetrag(input.dunning_level2_fee_cents??500,'DUNNING_FEE_INVALID',true);
  const gebuehr3=centBetrag(input.dunning_level3_fee_cents??1000,'DUNNING_FEE_INVALID',true);
  for(const g of [gebuehr1,gebuehr2,gebuehr3])if(g>GEBUEHR_MAX_CENT)throw new Error('DUNNING_FEE_TOO_HIGH');
  const ts=nowIso();
  await env.DB.prepare(
    `INSERT INTO participant_billing_settings(tenant_id,receivable_account,revenue_account_tuition,
       revenue_account_course_fee,revenue_account_dunning_fee,bank_account,creditor_identifier,
       dunning_level1_after_days,dunning_level2_after_days,dunning_level3_after_days,dunning_deadline_days,
       dunning_level1_fee_cents,dunning_level2_fee_cents,dunning_level3_fee_cents,currency,updated_by,created_at,updated_at)
     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,'EUR',?,?,?)
     ON CONFLICT(tenant_id) DO UPDATE SET receivable_account=excluded.receivable_account,
       revenue_account_tuition=excluded.revenue_account_tuition,
       revenue_account_course_fee=excluded.revenue_account_course_fee,
       revenue_account_dunning_fee=excluded.revenue_account_dunning_fee,
       bank_account=excluded.bank_account,creditor_identifier=excluded.creditor_identifier,
       dunning_level1_after_days=excluded.dunning_level1_after_days,
       dunning_level2_after_days=excluded.dunning_level2_after_days,
       dunning_level3_after_days=excluded.dunning_level3_after_days,
       dunning_deadline_days=excluded.dunning_deadline_days,
       dunning_level1_fee_cents=excluded.dunning_level1_fee_cents,
       dunning_level2_fee_cents=excluded.dunning_level2_fee_cents,
       dunning_level3_fee_cents=excluded.dunning_level3_fee_cents,
       updated_by=excluded.updated_by,updated_at=excluded.updated_at`
  ).bind(tenantId,forderungskonto,erloesSchulgeld,erloesKursgebuehr,erloesMahngebuehr,bankkonto,glaeubiger,
    stufe1,stufe2,stufe3,frist,gebuehr1,gebuehr2,gebuehr3,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'receivable.settings_saved',tenantId,undefined,'participant_billing_settings',tenantId,
    {receivable_account:forderungskonto,bank_account:bankkonto});
  return{configured:true};
}

/**
 * Die SEPA-Mandate. Die Liste zeigt Land und die letzten vier Stellen - nie die ganze Nummer,
 * und den Fingerabdruck erst recht nicht.
 */
export async function listSepaMandates(env:Env,auth:CoreAuthContext,tenantId:string,userId?:string){
  const gefiltert=safeString(userId,120)||null;
  // Wer nicht verwaltet, sieht ausschliesslich das eigene Mandat - und zwar durch die
  // WHERE-Bedingung, nicht durch einen Filter nach dem Laden. Was gar nicht geladen wird, kann
  // auch nicht versehentlich in eine Antwort geraten.
  const spalten=`m.id,m.user_id,m.mandate_reference,m.signed_on,m.account_holder,m.iban_country,m.iban_last4,
      m.status,m.revoked_on,m.note,m.created_at,u.display_name`;
  const eigene=!darfVerwalten(auth);
  if(eigene&&gefiltert&&gefiltert!==auth.userId)throw new Error('FORBIDDEN_RECEIVABLE_VIEW');
  const rows=eigene
    ?((await env.DB.prepare(
      `SELECT ${spalten} FROM participant_sepa_mandates m JOIN users u ON u.id=m.user_id
        WHERE m.tenant_id=? AND m.user_id=? ORDER BY m.signed_on DESC`
    ).bind(tenantId,auth.userId).all<Row>()).results)??[]
    :gefiltert
    ?((await env.DB.prepare(
      `SELECT ${spalten} FROM participant_sepa_mandates m JOIN users u ON u.id=m.user_id
        WHERE m.tenant_id=? AND m.user_id=? ORDER BY m.signed_on DESC`
    ).bind(tenantId,gefiltert).all<Row>()).results)??[]
    :((await env.DB.prepare(
      `SELECT ${spalten} FROM participant_sepa_mandates m JOIN users u ON u.id=m.user_id
        WHERE m.tenant_id=? ORDER BY u.display_name,m.signed_on DESC`
    ).bind(tenantId).all<Row>()).results)??[];
  return rows.map(r=>({...r,iban_display:`${String(r.iban_country||'')}•• •••• ${String(r.iban_last4||'')}`}));
}

/**
 * Ein erteiltes SEPA-Mandat erfassen: Referenz, Erteilungsdatum, Kontoinhaber, IBAN.
 *
 * Ein Mandat wird nicht geaendert, sondern widerrufen und neu erteilt - es ist ein
 * unterschriebenes Dokument, kein Formularstand. Deshalb gibt es hier kein Aktualisieren.
 * Eingezogen wird nichts: das Portal haelt fest, DASS ein Mandat vorliegt.
 */
export async function saveSepaMandate(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  assertVerwalten(auth);
  const userId=pflicht(input.user_id,'RECEIVABLE_PARTICIPANT_REQUIRED',120);
  // Die Person muss zu DIESEM Mandanten gehoeren. Ohne diese Pruefung liesse sich ueber eine
  // geratene Kennung ein Mandat an einem fremden Konto festmachen.
  const gehoert=await env.DB.prepare(
    'SELECT 1 ok FROM tenant_users WHERE tenant_id=? AND user_id=? UNION SELECT 1 ok FROM memberships WHERE tenant_id=? AND user_id=? LIMIT 1'
  ).bind(tenantId,userId,tenantId,userId).first();
  if(!gehoert)throw new Error('RECEIVABLE_PARTICIPANT_NOT_IN_TENANT');
  const referenz=mandatsreferenz(input.mandate_reference);
  const erteiltAm=datum(input.signed_on,'SEPA_MANDATE_SIGNED_DATE_INVALID');
  // Ein Mandat, das in der Zukunft erteilt wurde, gibt es nicht - das ist immer ein Zahlendreher.
  if(erteiltAm>nowIso().slice(0,10))throw new Error('SEPA_MANDATE_SIGNED_DATE_INVALID');
  const inhaber=pflicht(input.account_holder,'SEPA_MANDATE_HOLDER_REQUIRED',150);
  const merkmale=await mandatAusIban(tenantId,input.iban);
  const vorhanden=await env.DB.prepare('SELECT id FROM participant_sepa_mandates WHERE tenant_id=? AND mandate_reference=?')
    .bind(tenantId,referenz).first();
  if(vorhanden)throw new Error('SEPA_MANDATE_REFERENCE_EXISTS');
  const mandateId=id('psm_'),ts=nowIso();
  await env.DB.prepare(
    `INSERT INTO participant_sepa_mandates(id,tenant_id,user_id,mandate_reference,signed_on,account_holder,
       iban_country,iban_last4,iban_fingerprint_hash,status,revoked_on,note,created_by,created_at,updated_at)
     VALUES(?,?,?,?,?,?,?,?,?,'active',NULL,?,?,?,?)`
  ).bind(mandateId,tenantId,userId,referenz,erteiltAm,inhaber,merkmale.land,merkmale.letzteVier,
    merkmale.fingerabdruck,optional(input.note,500),auth.userId,ts,ts).run();
  // Im Protokoll stehen Referenz und die letzten vier Stellen - nie die ganze Nummer und nie der
  // Fingerabdruck. Das Revisionsprotokoll wird ausgelesen und exportiert.
  await audit(env.DB,auth.userId,'receivable.mandate_created',tenantId,undefined,'participant_sepa_mandate',mandateId,
    {user_id:userId,mandate_reference:referenz,signed_on:erteiltAm,iban_last4:merkmale.letzteVier});
  return{mandateId,mandateReference:referenz,signedOn:erteiltAm,ibanLast4:merkmale.letzteVier,ibanCountry:merkmale.land};
}

/** Ein Mandat widerrufen. Bereits gestellte Forderungen behalten ihre Referenz als Beleg. */
export async function revokeSepaMandate(env:Env,auth:CoreAuthContext,tenantId:string,mandateId:string,revokedOn?:unknown){
  assertVerwalten(auth);
  const am=revokedOn?datum(revokedOn,'SEPA_MANDATE_SIGNED_DATE_INVALID'):nowIso().slice(0,10);
  const ts=nowIso();
  // Der Zustand steht in der WHERE-Bedingung, nicht nur in einer Pruefung davor: widerrufen zwei
  // Sitzungen gleichzeitig, gewinnt genau eine.
  const r=await env.DB.prepare(
    `UPDATE participant_sepa_mandates SET status='revoked',revoked_on=?,updated_at=?
      WHERE tenant_id=? AND id=? AND status='active'`
  ).bind(am,ts,tenantId,mandateId).run();
  if(!Number(r.meta?.changes||0)){
    const da=await env.DB.prepare('SELECT status FROM participant_sepa_mandates WHERE tenant_id=? AND id=?')
      .bind(tenantId,mandateId).first<{status:string}>();
    throw new Error(da?'SEPA_MANDATE_ALREADY_REVOKED':'SEPA_MANDATE_NOT_FOUND');
  }
  await audit(env.DB,auth.userId,'receivable.mandate_revoked',tenantId,undefined,'participant_sepa_mandate',mandateId,{revoked_on:am});
  return{mandateId,status:'revoked',revokedOn:am};
}

/** Die wiederkehrenden und einmaligen Vereinbarungen. Teilnehmende sehen nur die eigenen. */
export async function listFeePlans(env:Env,auth:CoreAuthContext,tenantId:string,input:Row={}){
  const spalten=`p.id,p.course_id,p.user_id,p.title,p.kind,p.interval,p.amount_cents,p.currency,p.starts_on,
      p.ends_on,p.due_day,p.payment_method,p.mandate_id,p.status,p.note,p.created_at,
      k.name course_name,u.display_name,m.mandate_reference`;
  const von=`participant_fee_plans p
      JOIN courses k ON k.id=p.course_id AND k.tenant_id=p.tenant_id
      JOIN users u ON u.id=p.user_id
      LEFT JOIN participant_sepa_mandates m ON m.id=p.mandate_id AND m.tenant_id=p.tenant_id`;
  if(!darfVerwalten(auth)){
    const rows=((await env.DB.prepare(
      `SELECT ${spalten} FROM ${von} WHERE p.tenant_id=? AND p.user_id=? ORDER BY p.starts_on DESC`
    ).bind(tenantId,auth.userId).all<Row>()).results)??[];
    return rows.map(r=>({...r,display:alsEuro(Number(r.amount_cents||0),String(r.currency||'EUR')),can_manage:false}));
  }
  const kurs=safeString(input.course_id,120)||null;
  const person=safeString(input.user_id,120)||null;
  const status=safeString(input.status,20)||null;
  if(status&&!['active','paused','ended'].includes(status))throw new Error('RECEIVABLE_PLAN_STATUS_INVALID');
  // Ein Platzhalter je Bindung, alle unnummeriert, jeder Wert so oft gebunden wie er vorkommt.
  // Nummerierte und unnummerierte Platzhalter zu mischen ist der Fehler, der erst zur Laufzeit
  // auffaellt: SQLite zaehlt jedes '?' fortlaufend weiter und ein daneben stehendes '?2' meint
  // dann etwas anderes als gedacht.
  const rows=((await env.DB.prepare(
    `SELECT ${spalten} FROM ${von}
      WHERE p.tenant_id=? AND (? IS NULL OR p.course_id=?) AND (? IS NULL OR p.user_id=?) AND (? IS NULL OR p.status=?)
      ORDER BY u.display_name,p.starts_on DESC`
  ).bind(tenantId,kurs,kurs,person,person,status,status).all<Row>()).results)??[];
  return rows.map(r=>({...r,display:alsEuro(Number(r.amount_cents||0),String(r.currency||'EUR')),can_manage:true}));
}

/**
 * Eine Vereinbarung anlegen oder aendern.
 *
 * Sie wirkt nur nach vorn. Bereits gestellte Forderungen bleiben unberuehrt - der Betrag ist dort
 * eingefroren, und eine Schulgelderhoehung darf eine schon gemahnte Forderung nicht nachtraeglich
 * erhoehen.
 */
export async function saveFeePlan(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  assertVerwalten(auth);
  const courseId=pflicht(input.course_id,'RECEIVABLE_COURSE_REQUIRED',120);
  const userId=pflicht(input.user_id,'RECEIVABLE_PARTICIPANT_REQUIRED',120);
  const titel=pflicht(input.title,'RECEIVABLE_PLAN_TITLE_REQUIRED',200);
  const art=safeString(input.kind,30)||'tuition';
  if(!ARTEN.has(art))throw new Error('RECEIVABLE_KIND_INVALID');
  const rhythmus=safeString(input.interval,30)||(art==='tuition'?'monthly':'once');
  if(rhythmus!=='monthly'&&rhythmus!=='once')throw new Error('RECEIVABLE_INTERVAL_INVALID');
  const betrag=centBetrag(input.amount_cents,'RECEIVABLE_AMOUNT_INVALID');
  if(betrag>BETRAG_MAX_CENT)throw new Error('RECEIVABLE_AMOUNT_TOO_HIGH');
  const beginn=datum(input.starts_on,'RECEIVABLE_PLAN_PERIOD_INVALID');
  const ende=input.ends_on===null||input.ends_on===undefined||input.ends_on===''?null:datum(input.ends_on,'RECEIVABLE_PLAN_PERIOD_INVALID');
  if(ende&&ende<beginn)throw new Error('RECEIVABLE_PLAN_PERIOD_INVALID');
  const faelligkeitstag=rhythmus==='monthly'?ganzzahl(input.due_day??1,'RECEIVABLE_DUE_DAY_INVALID',1,28):null;
  const zahlweg=(safeString(input.payment_method,30)||'transfer') as Zahlweg;
  if(!ZAHLWEGE.has(zahlweg))throw new Error('RECEIVABLE_PAYMENT_METHOD_INVALID');
  const status=safeString(input.status,20)||'active';
  if(!['active','paused','ended'].includes(status))throw new Error('RECEIVABLE_PLAN_STATUS_INVALID');

  // Erst gegen den Mandanten pruefen, dann rechnen: eine Kurs- oder Personenkennung aus einem
  // fremden Mandanten darf nicht einmal eine Vereinbarung erzeugen koennen.
  if(!await env.DB.prepare('SELECT 1 ok FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,courseId).first())
    throw new Error('RECEIVABLE_COURSE_NOT_FOUND');
  if(!await env.DB.prepare(
    `SELECT 1 ok FROM memberships WHERE tenant_id=? AND course_id=? AND user_id=? AND role='participant' LIMIT 1`
  ).bind(tenantId,courseId,userId).first())throw new Error('RECEIVABLE_PARTICIPANT_NOT_IN_COURSE');

  let mandateId=safeString(input.mandate_id,120)||null;
  if(zahlweg==='sepa_direct_debit'){
    if(!mandateId)throw new Error('SEPA_MANDATE_REQUIRED');
    const mandat=await env.DB.prepare('SELECT user_id,status FROM participant_sepa_mandates WHERE tenant_id=? AND id=?')
      .bind(tenantId,mandateId).first<{user_id:string;status:string}>();
    if(!mandat)throw new Error('SEPA_MANDATE_NOT_FOUND');
    // Das Mandat einer anderen Person einzuhaengen waere ein Einzug vom falschen Konto.
    if(String(mandat.user_id)!==userId)throw new Error('SEPA_MANDATE_USER_MISMATCH');
    if(String(mandat.status)!=='active')throw new Error('SEPA_MANDATE_ALREADY_REVOKED');
  }else mandateId=null;

  const vorhandene=safeString(input.id,120)||'';
  if(vorhandene&&!await env.DB.prepare('SELECT 1 ok FROM participant_fee_plans WHERE tenant_id=? AND id=?').bind(tenantId,vorhandene).first())
    throw new Error('RECEIVABLE_PLAN_NOT_FOUND');
  const planId=vorhandene||id('pfp_'),note=optional(input.note,500),ts=nowIso();
  if(vorhandene)await env.DB.prepare(
    `UPDATE participant_fee_plans SET course_id=?,user_id=?,title=?,kind=?,interval=?,amount_cents=?,
       starts_on=?,ends_on=?,due_day=?,payment_method=?,mandate_id=?,status=?,note=?,updated_at=?
      WHERE tenant_id=? AND id=?`
  ).bind(courseId,userId,titel,art,rhythmus,betrag,beginn,ende,faelligkeitstag,zahlweg,mandateId,status,note,ts,tenantId,planId).run();
  else await env.DB.prepare(
    `INSERT INTO participant_fee_plans(id,tenant_id,course_id,user_id,title,kind,interval,amount_cents,currency,
       starts_on,ends_on,due_day,payment_method,mandate_id,status,note,created_by,created_at,updated_at)
     VALUES(?,?,?,?,?,?,?,?,'EUR',?,?,?,?,?,?,?,?,?,?)`
  ).bind(planId,tenantId,courseId,userId,titel,art,rhythmus,betrag,beginn,ende,faelligkeitstag,zahlweg,mandateId,status,note,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'receivable.plan_saved',tenantId,courseId,'participant_fee_plan',planId,
    {user_id:userId,kind:art,interval:rhythmus,amount_cents:betrag,starts_on:beginn,ends_on:ende,status});
  return{planId,amountCents:betrag,display:alsEuro(betrag),status};
}

/** Eine Vereinbarung stilllegen oder beenden. */
export async function setFeePlanStatus(env:Env,auth:CoreAuthContext,tenantId:string,planId:string,status:unknown){
  assertVerwalten(auth);
  const neu=safeString(status,20);
  if(!['active','paused','ended'].includes(neu))throw new Error('RECEIVABLE_PLAN_STATUS_INVALID');
  const ts=nowIso();
  const r=await env.DB.prepare('UPDATE participant_fee_plans SET status=?,updated_at=? WHERE tenant_id=? AND id=?')
    .bind(neu,ts,tenantId,planId).run();
  if(!Number(r.meta?.changes||0))throw new Error('RECEIVABLE_PLAN_NOT_FOUND');
  await audit(env.DB,auth.userId,'receivable.plan_status',tenantId,undefined,'participant_fee_plan',planId,{status:neu});
  return{planId,status:neu};
}

/**
 * Der Monatslauf: aus den Vereinbarungen die Forderungen des Monats stellen.
 *
 * Drei Eigenschaften, an denen so ein Lauf sonst scheitert:
 *   1. Er ist WIEDERHOLBAR. Ein zweiter Lauf desselben Monats stellt nichts doppelt - weder ueber
 *      die vorgeladene Liste noch, falls zwei Laeufe gleichzeitig starten, an der Datenbank
 *      vorbei: dafuer sorgt der eindeutige Teilindex aus 0114.
 *   2. Er ist FORTSETZBAR. Ueber LAUF_MAX hinaus bricht er nicht ab, sondern gibt next_cursor
 *      zurueck. 2000 Teilnehmende sind vier Aufrufe, nicht ein Abbruch.
 *   3. Die Zahl der Unteranfragen haengt NICHT an der Zahl der Teilnehmenden: vier Abfragen und
 *      gestapelte Schreibvorgaenge, nicht eine Anweisung je Forderung.
 *
 * Das Belegdatum ist der Monatserste, nicht der Tag des Laufs. Sonst haette dieselbe Forderung je
 * nach Ausfuehrungstag ein anderes Datum, und ein am 20. nachgeholter Lauf brauchte ein
 * Belegdatum nach der eigenen Faelligkeit.
 */
export async function runReceivableBilling(env:Env,auth:CoreAuthContext,tenantId:string,input:Row={}){
  assertVerwalten(auth);
  const periode=monat(input.period,'RECEIVABLE_PERIOD_INVALID');
  const beginn=`${periode}-01`,ende=monatsEnde(periode);
  const kurs=safeString(input.course_id,120)||null;
  const cursor=safeString(input.cursor,120)||'';
  const einstellungen=await ladeEinstellungen(env,tenantId);

  // Eine Abfrage fuer alle faelligen Vereinbarungen, aufsteigend nach Kennung, damit der Cursor
  // eine stabile Reihenfolge hat. Eine mehr als LAUF_MAX, um zu erkennen, ob noch etwas folgt.
  const plaene=((await env.DB.prepare(
    `SELECT p.id,p.course_id,p.user_id,p.title,p.kind,p.interval,p.amount_cents,p.currency,p.starts_on,
            p.ends_on,p.due_day,p.payment_method,p.mandate_id,u.display_name
       FROM participant_fee_plans p JOIN users u ON u.id=p.user_id
      WHERE p.tenant_id=? AND p.status='active' AND p.starts_on<=? AND (p.ends_on IS NULL OR p.ends_on>=?)
        AND (? IS NULL OR p.course_id=?) AND p.id>?
      ORDER BY p.id LIMIT ?`
  ).bind(tenantId,ende,beginn,kurs,kurs,cursor,LAUF_MAX+1).all<Row>()).results)??[];
  const weitere=plaene.length>LAUF_MAX;
  const zuTun=weitere?plaene.slice(0,LAUF_MAX):plaene;

  // Zwei weitere Abfragen fuer den ganzen Lauf statt einer je Vereinbarung: was fuer diesen Monat
  // bereits gestellt ist, und die Mandate. Je Person zu fragen waere bei 500 Teilnehmenden genau
  // die Bauart, an der die Plattformgrenze von 1000 Unteranfragen reisst.
  const [gestellt,mandate,letzterBeleg]=await Promise.all([
    env.DB.prepare(
      `SELECT plan_id,period FROM participant_receivables
        WHERE tenant_id=? AND plan_id IS NOT NULL AND (period=? OR period IS NULL)`
    ).bind(tenantId,periode).all<Row>(),
    env.DB.prepare(
      `SELECT id,user_id,mandate_reference,status FROM participant_sepa_mandates WHERE tenant_id=? AND status='active'`
    ).bind(tenantId).all<Row>(),
    // Die naechste Belegnummer. Vierstellig aufgefuellt, damit die groesste Zeichenkette auch die
    // groesste Zahl ist - sonst stuende '10' vor '9'.
    env.DB.prepare(
      `SELECT MAX(document_no) letzte FROM participant_receivables WHERE tenant_id=? AND document_no>=? AND document_no<?`
    ).bind(tenantId,`R-${periode}-`,`R-${periode}-~`).first<{letzte:string|null}>(),
  ]);
  const schonGestellt=new Set((gestellt.results??[]).map(r=>`${String(r.plan_id)}|${r.period===null?'':String(r.period)}`));
  const mandatNach=new Map((mandate.results??[]).map(r=>[String(r.id),{user:String(r.user_id),ref:String(r.mandate_reference)}]));
  let laufnummer=Number(String(letzterBeleg?.letzte||'').slice(-4))||0;

  const forderungskonto=String(einstellungen.receivable_account);
  const anweisungen:unknown[]=[],ergebnisse:Row[]=[],ts=nowIso();
  let gesamtCent=0,erzeugt=0,letzteKennung=cursor;
  for(const p of zuTun){
    letzteKennung=String(p.id);
    const rhythmus=String(p.interval) as 'monthly'|'once';
    const art=String(p.kind) as Art;
    const schluessel=`${String(p.id)}|${rhythmus==='monthly'?periode:''}`;
    if(schonGestellt.has(schluessel)){
      ergebnisse.push({plan_id:p.id,user_id:p.user_id,display_name:p.display_name,status:'skipped',reason:'already_billed'});
      continue;
    }
    const zahlweg=String(p.payment_method) as Zahlweg;
    let referenz:string|null=null;
    if(zahlweg==='sepa_direct_debit'){
      const m=p.mandate_id?mandatNach.get(String(p.mandate_id)):undefined;
      // Fail closed: ohne gueltiges Mandat entsteht KEINE Lastschriftforderung. Sie stattdessen
      // still auf Ueberweisung umzustellen, waere eine Aenderung der Vereinbarung durch den Lauf.
      if(!m||m.user!==String(p.user_id)){
        ergebnisse.push({plan_id:p.id,user_id:p.user_id,display_name:p.display_name,status:'skipped',reason:'no_active_mandate'});
        continue;
      }
      referenz=m.ref;
    }
    const belegdatum=rhythmus==='monthly'?beginn:String(p.starts_on);
    const faellig=rhythmus==='monthly'
      ?`${periode}-${String(Number(p.due_day)).padStart(2,'0')}`
      :String(p.starts_on);
    const betrag=Number(p.amount_cents);
    laufnummer+=1;
    const belegnummer=`R-${periode}-${String(laufnummer).padStart(4,'0')}`;
    const erloeskonto=art==='tuition'?String(einstellungen.revenue_account_tuition):String(einstellungen.revenue_account_course_fee);
    const forderungId=id('pdr_');
    anweisungen.push(env.DB.prepare(
      `INSERT INTO participant_receivables(id,tenant_id,plan_id,course_id,user_id,document_no,kind,title,period,
         issued_on,due_on,amount_cents,currency,payment_method,mandate_reference,receivable_account,revenue_account,
         status,dunning_level,created_by,created_at,updated_at)
       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'open',0,?,?,?)`
    ).bind(forderungId,tenantId,String(p.id),String(p.course_id),String(p.user_id),belegnummer,art,String(p.title),
      rhythmus==='monthly'?periode:null,belegdatum,faellig,betrag,String(p.currency||'EUR'),zahlweg,referenz,
      forderungskonto,erloeskonto,auth.userId,ts,ts));
    gesamtCent+=betrag;erzeugt+=1;
    ergebnisse.push({plan_id:p.id,user_id:p.user_id,display_name:p.display_name,status:'billed',
      receivable_id:forderungId,document_no:belegnummer,due_on:faellig,amount_cents:betrag,display:alsEuro(betrag)});
  }
  // Ein Stapel statt einer Anweisung je Forderung: Cloudflare zaehlt einen Stapel als eine
  // Unteranfrage, unabhaengig davon, wie viele Anweisungen er traegt.
  if(anweisungen.length)await stapelSchreiben(env,anweisungen as any[]);
  await audit(env.DB,auth.userId,'receivable.billing_run',tenantId,undefined,'participant_receivable',null as unknown as string,
    {period:periode,billed:erzeugt,skipped:ergebnisse.length-erzeugt,total_cents:gesamtCent});
  return{period:periode,billed:erzeugt,skipped:ergebnisse.length-erzeugt,total_cents:gesamtCent,
    total_display:alsEuro(gesamtCent),next_cursor:weitere?letzteKennung:null,rows:ergebnisse};
}

// Die offenen Posten als Abfrage. Offen ist Forderung zuzueglich Mahngebuehren abzueglich
// vermerkter Eingaenge - in einer Anweisung, nicht in einer Schleife ueber die Posten.
const OFFENE_SPALTEN=`r.id,r.course_id,r.user_id,r.document_no,r.kind,r.title,r.period,r.issued_on,r.due_on,
    r.amount_cents,r.currency,r.payment_method,r.mandate_reference,r.status,r.dunning_level,
    u.display_name,k.name course_name,
    COALESCE((SELECT SUM(z.amount_cents) FROM participant_receivable_payments z WHERE z.receivable_id=r.id),0) paid_cents,
    COALESCE((SELECT SUM(m.fee_cents) FROM participant_dunning_notices m WHERE m.receivable_id=r.id),0) fee_cents,
    (SELECT MAX(m.deadline_on) FROM participant_dunning_notices m WHERE m.receivable_id=r.id) dunning_deadline`;
const OFFENE_QUELLE=`participant_receivables r
    JOIN users u ON u.id=r.user_id
    JOIN courses k ON k.id=r.course_id AND k.tenant_id=r.tenant_id`;

type OffenerPosten=Row&{open_cents:number;days_overdue:number};
function offenAufbereiten(rows:Row[],stichtag:string):OffenerPosten[]{
  return rows.map(r=>{
    const offen=Number(r.amount_cents||0)+Number(r.fee_cents||0)-Number(r.paid_cents||0);
    const verzug=r.status==='open'&&offen>0?Math.max(0,tageZwischen(String(r.due_on),stichtag)):0;
    return{...r,open_cents:offen,days_overdue:verzug,
      display:alsEuro(Number(r.amount_cents||0),String(r.currency||'EUR')),
      open_display:alsEuro(offen,String(r.currency||'EUR'))};
  });
}

/**
 * Die offenen Posten. Die Verwaltung sieht alle, eine teilnehmende Person ausschliesslich ihre
 * eigenen - und zwar durch die WHERE-Bedingung, nicht durch einen Filter nach dem Laden.
 */
export async function listOpenItems(env:Env,auth:CoreAuthContext,tenantId:string,input:Row={}){
  const stichtag=input.as_of?datum(input.as_of,'RECEIVABLE_DATE_INVALID'):nowIso().slice(0,10);
  const nurOffene=input.include_settled?0:1;
  if(!darfVerwalten(auth)){
    const rows=((await env.DB.prepare(
      `SELECT ${OFFENE_SPALTEN} FROM ${OFFENE_QUELLE}
        WHERE r.tenant_id=? AND r.user_id=? AND (?=0 OR r.status='open') ORDER BY r.due_on DESC`
    ).bind(tenantId,auth.userId,nurOffene).all<Row>()).results)??[];
    const posten=offenAufbereiten(rows,stichtag);
    const summe=posten.reduce((n,r)=>n+(r.status==='open'?r.open_cents:0),0);
    return{as_of:stichtag,rows:posten,count:posten.length,open_cents:summe,open_display:alsEuro(summe),can_manage:false};
  }
  const kurs=safeString(input.course_id,120)||null;
  const person=safeString(input.user_id,120)||null;
  const nurUeberfaellig=input.overdue_only?1:0;
  const rows=((await env.DB.prepare(
    `SELECT ${OFFENE_SPALTEN} FROM ${OFFENE_QUELLE}
      WHERE r.tenant_id=? AND (?=0 OR r.status='open') AND (? IS NULL OR r.course_id=?) AND (? IS NULL OR r.user_id=?)
        AND (?=0 OR r.due_on<?)
      ORDER BY r.due_on,u.display_name`
  ).bind(tenantId,nurOffene,kurs,kurs,person,person,nurUeberfaellig,stichtag).all<Row>()).results)??[];
  const posten=offenAufbereiten(rows,stichtag).filter(r=>!nurUeberfaellig||r.open_cents>0);
  const summe=posten.reduce((n,r)=>n+(r.status==='open'?r.open_cents:0),0);
  return{as_of:stichtag,rows:posten,count:posten.length,open_cents:summe,open_display:alsEuro(summe),can_manage:true};
}

/** Eine Forderung mit ihren Eingaengen und Mahnungen. */
export async function receivableDetail(env:Env,auth:CoreAuthContext,tenantId:string,receivableId:string){
  const r=await ladeForderung(env,tenantId,receivableId);
  // Die eigene Forderung darf die betroffene Person sehen, jede andere nicht.
  if(!darfVerwalten(auth)&&String(r.user_id)!==auth.userId)throw new Error('FORBIDDEN_RECEIVABLE_VIEW');
  const [eingaenge,mahnungen]=await Promise.all([
    env.DB.prepare(
      `SELECT id,amount_cents,received_on,method,note,created_at FROM participant_receivable_payments
        WHERE tenant_id=? AND receivable_id=? ORDER BY received_on,created_at`
    ).bind(tenantId,receivableId).all<Row>(),
    env.DB.prepare(
      `SELECT id,level,document_no,issued_on,deadline_on,fee_cents,open_cents_at_issue FROM participant_dunning_notices
        WHERE tenant_id=? AND receivable_id=? ORDER BY level`
    ).bind(tenantId,receivableId).all<Row>(),
  ]);
  const bezahlt=(eingaenge.results??[]).reduce((n,z)=>n+Number(z.amount_cents||0),0);
  const gebuehren=(mahnungen.results??[]).reduce((n,m)=>n+Number(m.fee_cents||0),0);
  const offen=Number(r.amount_cents||0)+gebuehren-bezahlt;
  const waehrung=String(r.currency||'EUR');
  return{
    receivable:{...r,paid_cents:bezahlt,fee_cents:gebuehren,open_cents:offen,
      display:alsEuro(Number(r.amount_cents||0),waehrung),open_display:alsEuro(offen,waehrung),
      can_manage:darfVerwalten(auth)},
    payments:(eingaenge.results??[]).map(z=>({...z,display:alsEuro(Number(z.amount_cents||0),waehrung)})),
    dunning_notices:(mahnungen.results??[]).map(m=>({...m,fee_display:alsEuro(Number(m.fee_cents||0),waehrung)})),
  };
}

/**
 * Einen Zahlungseingang vermerken.
 *
 * Das ist ausdruecklich KEIN Zahlungsverkehr: es wird nichts eingezogen und nichts an eine Bank
 * gemeldet. Der Vermerk haelt fest, dass eine Zahlung ausserhalb des Portals eingegangen ist -
 * sonst stuende dieselbe Forderung im naechsten Monat wieder in den offenen Posten.
 */
export async function recordReceivablePayment(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  assertVerwalten(auth);
  const receivableId=pflicht(input.receivable_id,'RECEIVABLE_REQUIRED',120);
  const r=await ladeForderung(env,tenantId,receivableId);
  if(String(r.status)!=='open')throw new Error('RECEIVABLE_NOT_OPEN');
  const betrag=centBetrag(input.amount_cents,'RECEIVABLE_PAYMENT_AMOUNT_INVALID');
  const eingegangen=datum(input.received_on,'RECEIVABLE_DATE_INVALID');
  const art=safeString(input.method,20)||'transfer';
  if(!ZAHLARTEN.has(art))throw new Error('RECEIVABLE_PAYMENT_METHOD_INVALID');
  const stand=await env.DB.prepare(
    `SELECT COALESCE((SELECT SUM(z.amount_cents) FROM participant_receivable_payments z WHERE z.receivable_id=?),0) bezahlt,
            COALESCE((SELECT SUM(m.fee_cents) FROM participant_dunning_notices m WHERE m.receivable_id=?),0) gebuehren`
  ).bind(receivableId,receivableId).first<{bezahlt:number;gebuehren:number}>();
  const geschuldet=Number(r.amount_cents||0)+Number(stand?.gebuehren||0);
  const bezahlt=Number(stand?.bezahlt||0);
  // Mehr eintragen als geschuldet ist, ergibt eine Buchhaltung, die nicht stimmt - und der
  // haeufigste Weg dorthin ist ein Tippfehler. Die Datenbank haelt dieselbe Regel noch einmal
  // (Trigger in 0114) fuer den Fall, dass zwei Personen gleichzeitig eintragen; hier steht sie,
  // damit der Mensch am Bildschirm einen Satz sieht statt einer Datenbankmeldung.
  if(bezahlt+betrag>geschuldet)throw new Error('RECEIVABLE_PAYMENT_EXCEEDS_OPEN');
  const zahlungId=id('pdz_'),ts=nowIso();
  const anweisungen:unknown[]=[env.DB.prepare(
    `INSERT INTO participant_receivable_payments(id,tenant_id,receivable_id,amount_cents,received_on,method,note,recorded_by,created_at)
     VALUES(?,?,?,?,?,?,?,?,?)`
  ).bind(zahlungId,tenantId,receivableId,betrag,eingegangen,art,optional(input.note,500),auth.userId,ts)];
  const jetztOffen=geschuldet-(bezahlt+betrag);
  if(jetztOffen<=0)anweisungen.push(env.DB.prepare(
    // Der Zustand steht in der WHERE-Bedingung: zwei gleichzeitige Eingaenge sollen nicht
    // zweimal ausgleichen.
    `UPDATE participant_receivables SET status='settled',settled_on=?,updated_at=? WHERE tenant_id=? AND id=? AND status='open'`
  ).bind(eingegangen,ts,tenantId,receivableId));
  await stapelSchreiben(env,anweisungen as any[]);
  await audit(env.DB,auth.userId,'receivable.payment_recorded',tenantId,undefined,'participant_receivable',receivableId,
    {amount_cents:betrag,received_on:eingegangen,method:art,open_cents:jetztOffen});
  return{paymentId:zahlungId,receivableId,openCents:jetztOffen,settled:jetztOffen<=0,display:alsEuro(betrag,String(r.currency||'EUR'))};
}

/**
 * Eine Forderung stornieren.
 *
 * Sie wird NICHT geloescht und ihr Betrag NICHT geaendert - beides waere eine rueckwirkende
 * Aenderung einer gestellten Forderung. Der Storno ist ein eigener Vorgang mit eigenem Datum, und
 * im Buchungsexport erscheint er als Gegenbuchung.
 */
export async function cancelReceivable(env:Env,auth:CoreAuthContext,tenantId:string,receivableId:string,input:Row={}){
  assertVerwalten(auth);
  const grund=pflicht(input.reason,'RECEIVABLE_CANCEL_REASON_REQUIRED',300);
  const am=input.cancelled_on?datum(input.cancelled_on,'RECEIVABLE_DATE_INVALID'):nowIso().slice(0,10);
  const ts=nowIso();
  const r=await env.DB.prepare(
    `UPDATE participant_receivables SET status='cancelled',cancelled_on=?,cancel_reason=?,updated_at=?
      WHERE tenant_id=? AND id=? AND status='open'`
  ).bind(am,grund,ts,tenantId,receivableId).run();
  if(!Number(r.meta?.changes||0)){
    await ladeForderung(env,tenantId,receivableId);
    throw new Error('RECEIVABLE_NOT_OPEN');
  }
  await audit(env.DB,auth.userId,'receivable.cancelled',tenantId,undefined,'participant_receivable',receivableId,{reason:grund,cancelled_on:am});
  return{receivableId,status:'cancelled',cancelledOn:am};
}

/**
 * Der Mahnlauf: Stufe 1, 2 und 3 mit Fristen und Gebuehren.
 *
 * Eine Stufe wird erreicht, wenn zwei Dinge zutreffen: die vereinbarte Zahl der Tage seit
 * Faelligkeit ist verstrichen UND die Frist der vorigen Mahnung ist abgelaufen. Ohne die zweite
 * Bedingung koennte ein Lauf am selben Tag Stufe 1, 2 und 3 erteilen und die eingeraeumte
 * Zahlungsfrist waere eine Behauptung.
 *
 * Auch dieser Lauf ist fortsetzbar (next_cursor) und schreibt gestapelt.
 */
export async function runDunning(env:Env,auth:CoreAuthContext,tenantId:string,input:Row={}){
  assertVerwalten(auth);
  const stichtag=input.as_of?datum(input.as_of,'RECEIVABLE_DATE_INVALID'):nowIso().slice(0,10);
  const cursor=safeString(input.cursor,120)||'';
  const e=await ladeEinstellungen(env,tenantId);
  const nachTagen=[Number(e.dunning_level1_after_days),Number(e.dunning_level2_after_days),Number(e.dunning_level3_after_days)];
  const gebuehren=[Number(e.dunning_level1_fee_cents),Number(e.dunning_level2_fee_cents),Number(e.dunning_level3_fee_cents)];
  const fristTage=Number(e.dunning_deadline_days);

  const kandidaten=((await env.DB.prepare(
    `SELECT r.id,r.user_id,r.document_no,r.due_on,r.amount_cents,r.currency,r.dunning_level,
            COALESCE((SELECT SUM(z.amount_cents) FROM participant_receivable_payments z WHERE z.receivable_id=r.id),0) paid_cents,
            COALESCE((SELECT SUM(m.fee_cents) FROM participant_dunning_notices m WHERE m.receivable_id=r.id),0) fee_cents,
            (SELECT MAX(m.deadline_on) FROM participant_dunning_notices m WHERE m.receivable_id=r.id) last_deadline
       FROM participant_receivables r
      WHERE r.tenant_id=? AND r.status='open' AND r.due_on<? AND r.dunning_level<3 AND r.id>?
      ORDER BY r.id LIMIT ?`
  ).bind(tenantId,stichtag,cursor,LAUF_MAX+1).all<Row>()).results)??[];
  const weitere=kandidaten.length>LAUF_MAX;
  const zuTun=weitere?kandidaten.slice(0,LAUF_MAX):kandidaten;

  const anweisungen:unknown[]=[],ergebnisse:Row[]=[],ts=nowIso();
  let erzeugt=0,gebuehrSumme=0,letzteKennung=cursor;
  for(const r of zuTun){
    letzteKennung=String(r.id);
    const offen=Number(r.amount_cents||0)+Number(r.fee_cents||0)-Number(r.paid_cents||0);
    if(offen<=0){ergebnisse.push({receivable_id:r.id,document_no:r.document_no,status:'skipped',reason:'nothing_open'});continue;}
    const stufe=Number(r.dunning_level||0)+1;
    if(stichtag<tage(String(r.due_on),nachTagen[stufe-1])){
      ergebnisse.push({receivable_id:r.id,document_no:r.document_no,status:'skipped',reason:'not_due_yet',level:stufe});
      continue;
    }
    // Die Frist der vorigen Mahnung muss abgelaufen sein. Ist sie das nicht, laeuft die Person
    // noch in der eingeraeumten Zeit - eine zweite Mahnung waere in dieser Frist unwirksam.
    const letzteFrist=r.last_deadline?String(r.last_deadline):'';
    if(letzteFrist&&stichtag<=letzteFrist){
      ergebnisse.push({receivable_id:r.id,document_no:r.document_no,status:'skipped',reason:'deadline_running',level:stufe});
      continue;
    }
    const gebuehr=gebuehren[stufe-1];
    const mahnungId=id('pdm_');
    // Die Belegnummer leitet sich aus der Forderung ab: sie ist damit ohne Zaehler eindeutig und
    // ein Mensch sieht sofort, wozu die Mahnung gehoert.
    const belegnummer=`M${stufe}-${String(r.document_no)}`;
    anweisungen.push(env.DB.prepare(
      `INSERT INTO participant_dunning_notices(id,tenant_id,receivable_id,level,document_no,issued_on,deadline_on,
         fee_cents,open_cents_at_issue,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`
    ).bind(mahnungId,tenantId,String(r.id),stufe,belegnummer,stichtag,tage(stichtag,fristTage),gebuehr,offen,auth.userId,ts));
    anweisungen.push(env.DB.prepare(
      // Die alte Stufe steht in der WHERE-Bedingung: zwei gleichzeitige Laeufe sollen nicht
      // zweimal dieselbe Stufe erteilen.
      `UPDATE participant_receivables SET dunning_level=?,updated_at=? WHERE tenant_id=? AND id=? AND dunning_level=?`
    ).bind(stufe,ts,tenantId,String(r.id),stufe-1));
    erzeugt+=1;gebuehrSumme+=gebuehr;
    ergebnisse.push({receivable_id:r.id,document_no:r.document_no,status:'dunned',level:stufe,
      dunning_document_no:belegnummer,deadline_on:tage(stichtag,fristTage),fee_cents:gebuehr,
      open_cents:offen,open_display:alsEuro(offen,String(r.currency||'EUR'))});
  }
  if(anweisungen.length)await stapelSchreiben(env,anweisungen as any[]);
  await audit(env.DB,auth.userId,'receivable.dunning_run',tenantId,undefined,'participant_receivable',null as unknown as string,
    {as_of:stichtag,dunned:erzeugt,fee_cents:gebuehrSumme});
  return{as_of:stichtag,dunned:erzeugt,skipped:ergebnisse.length-erzeugt,fee_cents:gebuehrSumme,
    fee_display:alsEuro(gebuehrSumme),next_cursor:weitere?letzteKennung:null,rows:ergebnisse};
}

/**
 * Der Buchungsexport fuer die Finanzbuchhaltung - CSV, DATEV-nah.
 *
 * Eine Zeile je Buchungssatz mit Datum, Betrag, Soll- und Habenkonto, Belegfeld und Buchungstext.
 * Vier Arten von Saetzen:
 *   Forderung      Soll Forderungskonto      an Haben Erloeskonto
 *   Mahngebuehr    Soll Forderungskonto      an Haben Erloeskonto Mahngebuehren
 *   Zahlungseingang Soll Bankkonto           an Haben Forderungskonto
 *   Storno         Soll Erloeskonto          an Haben Forderungskonto (Gegenbuchung)
 *
 * Es steht KEINE Bankverbindung in dieser Datei - weder eine IBAN noch die letzten vier Stellen.
 * Eine Buchungsdatei geht per Mail an die Steuerkanzlei; sie ist der letzte Ort, an dem
 * Zahlungsdaten etwas zu suchen haetten. Die Mandatsreferenz erscheint ebenfalls nicht: sie ist
 * fuer die Buchung ohne Bedeutung.
 */
export async function exportBookingCsv(env:Env,auth:CoreAuthContext,tenantId:string,input:Row={}){
  assertVerwalten(auth);
  const von=datum(input.from,'RECEIVABLE_EXPORT_PERIOD_INVALID');
  const bis=datum(input.to,'RECEIVABLE_EXPORT_PERIOD_INVALID');
  if(bis<von)throw new Error('RECEIVABLE_EXPORT_PERIOD_INVALID');
  const e=await ladeEinstellungen(env,tenantId);
  const mahngebuehrKonto=String(e.revenue_account_dunning_fee);

  const [forderungen,mahnungen,eingaenge]=await Promise.all([
    env.DB.prepare(
      `SELECT r.document_no,r.title,r.period,r.issued_on,r.amount_cents,r.currency,r.receivable_account,
              r.revenue_account,r.status,r.cancelled_on,u.display_name
         FROM participant_receivables r JOIN users u ON u.id=r.user_id
        WHERE r.tenant_id=? AND (r.issued_on BETWEEN ? AND ? OR (r.cancelled_on IS NOT NULL AND r.cancelled_on BETWEEN ? AND ?))
        ORDER BY r.issued_on,r.document_no`
    ).bind(tenantId,von,bis,von,bis).all<Row>(),
    env.DB.prepare(
      `SELECT m.document_no,m.level,m.issued_on,m.fee_cents,r.document_no receivable_no,r.currency,
              r.receivable_account,u.display_name
         FROM participant_dunning_notices m
         JOIN participant_receivables r ON r.id=m.receivable_id AND r.tenant_id=m.tenant_id
         JOIN users u ON u.id=r.user_id
        WHERE m.tenant_id=? AND m.issued_on BETWEEN ? AND ? AND m.fee_cents>0
        ORDER BY m.issued_on,m.document_no`
    ).bind(tenantId,von,bis).all<Row>(),
    env.DB.prepare(
      `SELECT z.amount_cents,z.received_on,z.method,r.document_no,r.currency,r.receivable_account,u.display_name
         FROM participant_receivable_payments z
         JOIN participant_receivables r ON r.id=z.receivable_id AND r.tenant_id=z.tenant_id
         JOIN users u ON u.id=r.user_id
        WHERE z.tenant_id=? AND z.received_on BETWEEN ? AND ?
        ORDER BY z.received_on,r.document_no`
    ).bind(tenantId,von,bis).all<Row>(),
  ]);

  type Satz={datum:string;cent:number;soll:string;haben:string;beleg:string;text:string;waehrung:string};
  const saetze:Satz[]=[];
  for(const r of forderungen.results??[]){
    const zeitraum=r.period?` ${String(r.period)}`:'';
    if(String(r.issued_on)>=von&&String(r.issued_on)<=bis)saetze.push({
      datum:String(r.issued_on),cent:Number(r.amount_cents||0),soll:String(r.receivable_account),haben:String(r.revenue_account),
      beleg:String(r.document_no),text:`${String(r.title)}${zeitraum} ${String(r.display_name||'')}`.trim(),
      waehrung:String(r.currency||'EUR')});
    if(r.status==='cancelled'&&r.cancelled_on&&String(r.cancelled_on)>=von&&String(r.cancelled_on)<=bis)saetze.push({
      datum:String(r.cancelled_on),cent:Number(r.amount_cents||0),soll:String(r.revenue_account),haben:String(r.receivable_account),
      beleg:String(r.document_no),text:`Storno ${String(r.title)}${zeitraum} ${String(r.display_name||'')}`.trim(),
      waehrung:String(r.currency||'EUR')});
  }
  for(const m of mahnungen.results??[])saetze.push({
    datum:String(m.issued_on),cent:Number(m.fee_cents||0),soll:String(m.receivable_account),haben:mahngebuehrKonto,
    beleg:String(m.document_no),text:`Mahngebuehr Stufe ${Number(m.level)} zu ${String(m.receivable_no)} ${String(m.display_name||'')}`.trim(),
    waehrung:String(m.currency||'EUR')});
  for(const z of eingaenge.results??[])saetze.push({
    datum:String(z.received_on),cent:Number(z.amount_cents||0),soll:String(e.bank_account),haben:String(z.receivable_account),
    beleg:String(z.document_no),text:`Zahlungseingang ${String(z.document_no)} ${String(z.display_name||'')}`.trim(),
    waehrung:String(z.currency||'EUR')});
  saetze.sort((a,b)=>a.datum<b.datum?-1:a.datum>b.datum?1:a.beleg<b.beleg?-1:a.beleg>b.beleg?1:0);

  // Semikolon als Trennzeichen, CRLF als Zeilenende, Komma als Dezimaltrennzeichen: so liest
  // jede deutsche Finanzbuchhaltung die Datei ohne Nachfrage. csvSafeCell entschaerft zusaetzlich
  // Zellen, die mit = + - @ beginnen - ein Name wie "-Meier" waere in Excel sonst eine Formel.
  const spalten=['Buchungsdatum','Betrag','Sollkonto','Habenkonto','Belegfeld','Buchungstext','Waehrung'];
  const zeilen=[spalten.map(csvSafeCell).join(';')];
  for(const s of saetze)zeilen.push([s.datum,alsBuchungsbetrag(s.cent),s.soll,s.haben,s.beleg,s.text,s.waehrung].map(csvSafeCell).join(';'));
  const summe=saetze.reduce((n,s)=>n+s.cent,0);
  await audit(env.DB,auth.userId,'receivable.booking_export',tenantId,undefined,'participant_receivable',null as unknown as string,
    {from:von,to:bis,rows:saetze.length,total_cents:summe});
  return{content:zeilen.join('\r\n'),row_count:saetze.length,total_cents:summe,total_display:alsEuro(summe),
    filename:`buchungen-debitoren-${von}-${bis}.csv`,from:von,to:bis};
}

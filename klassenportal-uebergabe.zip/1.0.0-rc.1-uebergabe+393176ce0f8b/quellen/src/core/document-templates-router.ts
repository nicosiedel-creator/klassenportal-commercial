import type { Env } from './types.js';
import { resolveCoreAuth } from './auth.js';
import { assertTenantWriteAllowed } from './commerce-offers.js';
import { continueDocumentRun, documentPlaceholderCatalogue, getDocumentRun, listDocumentRuns, listDocumentTemplates, previewDocumentTemplate, saveDocumentTemplate, startDocumentRun } from './document-templates.js';
import { assertSameOrigin, authStatus, json, safeErrorCode } from './utils.js';

async function body(request:Request){try{return await request.json() as Record<string,unknown>;}catch{return{};}}
function fail(e:unknown){
  const code=safeErrorCode(e);
  const status=authStatus(code)??(code==='UNAUTHENTICATED'?401:code.startsWith('FORBIDDEN')?403:code.includes('NOT_FOUND')?404:code.includes('TOO_LARGE')||code.includes('INACTIVE')?409:400);
  return json({ok:false,error:code},status);
}

export async function handleDocumentTemplatesApi(request:Request,env:Env):Promise<Response|null>{
  const u=new URL(request.url),path=u.pathname;
  if(!path.startsWith('/api/document-templates')&&!path.startsWith('/api/document-runs'))return null;
  try{
    assertSameOrigin(request,env.APP_ORIGIN);
    const tenantId=u.searchParams.get('tenant_id')||'',courseId=u.searchParams.get('course_id')||undefined;
    if(!tenantId)throw new Error('TENANT_ID_REQUIRED');
    const auth=await resolveCoreAuth(env,request,tenantId,courseId);
    if(path==='/api/document-templates'&&request.method==='GET')
      return json({ok:true,templates:await listDocumentTemplates(env,auth,tenantId),placeholders:documentPlaceholderCatalogue()});
    if(path==='/api/document-templates'&&request.method==='POST'){
      await assertTenantWriteAllowed(env,tenantId);
      return json({ok:true,template:await saveDocumentTemplate(env,auth,tenantId,await body(request))},201);
    }
    if(path==='/api/document-templates/preview'&&request.method==='POST'){
      const b=await body(request);
      return json({ok:true,preview:await previewDocumentTemplate(env,auth,tenantId,{...b,course_id:b.course_id||courseId})});
    }
    if(path==='/api/document-runs'&&request.method==='GET')
      return json({ok:true,runs:await listDocumentRuns(env,auth,tenantId,courseId)});
    if(path==='/api/document-runs'&&request.method==='POST'){
      await assertTenantWriteAllowed(env,tenantId);
      const b=await body(request);
      return json({ok:true,run:await startDocumentRun(env,auth,tenantId,{...b,course_id:b.course_id||courseId})},201);
    }
    const weiter=path.match(/^\/api\/document-runs\/([^/]+)\/continue$/);
    if(weiter&&request.method==='POST'){
      await assertTenantWriteAllowed(env,tenantId);
      const b=await body(request);
      return json({ok:true,run:await continueDocumentRun(env,auth,tenantId,decodeURIComponent(weiter[1]),b.max_documents)});
    }
    const einzeln=path.match(/^\/api\/document-runs\/([^/]+)$/);
    if(einzeln&&request.method==='GET')
      return json({ok:true,...await getDocumentRun(env,auth,tenantId,decodeURIComponent(einzeln[1]))});
    return json({ok:false,error:'DOCUMENT_ROUTE_NOT_FOUND'},404);
  }catch(e){return fail(e);}
}

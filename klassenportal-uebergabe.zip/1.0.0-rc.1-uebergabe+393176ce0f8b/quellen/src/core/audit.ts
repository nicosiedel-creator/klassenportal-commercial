import type { D1DatabaseLike } from '../portability/types.js';
import { id, nowIso } from './utils.js';
import { ketteAnhaengen } from './immutable-audit.js';

// Jede Protokollzeile entsteht zusammen mit ihrer Kettenzeile - in EINEM Stapel.
//
// Vorher war das Protokoll eine gewoehnliche Tabelle: wer Schreibrecht auf die Datenbank hat,
// konnte eine Zeile aendern oder loeschen, ohne dass es irgendwo auffaellt. Genau das macht ein
// Protokoll als Nachweis wertlos - vor Gericht ist ein aenderbares Protokoll kein Beweis, sondern
// eine Behauptung.
//
// Die Kette schliesst das: jede Zeile traegt den Hash ihrer Vorgaengerin. Eine geaenderte,
// geloeschte oder eingeschobene Zeile bricht sie an einer benennbaren Stelle. Und weil die
// Kettenzeile im selben Stapel steht wie die Protokollzeile, kann die Kette nicht hinterherhinken:
// entweder es entsteht beides, oder nichts.
export async function audit(db:D1DatabaseLike, actor:string|undefined, action:string, tenantId?:string, courseId?:string, entityType?:string, entityId?:string, details?:unknown):Promise<void>{
  const eintragId=id('aud_'),ts=nowIso();
  const zeile=db.prepare('INSERT INTO audit_log(id,tenant_id,course_id,actor_user_id,action,entity_type,entity_id,details_json,created_at) VALUES(?,?,?,?,?,?,?,?,?)')
    .bind(eintragId,tenantId??null,courseId??null,actor??null,action,entityType??null,entityId??null,details?JSON.stringify(details):null,ts);
  await ketteAnhaengen(db,{tenant_id:tenantId??null,quelle:'audit_log',quelle_id:eintragId,akteur:actor??null,aktion:action,
    objekt_typ:entityType??null,objekt_id:entityId??null,inhalt:{course_id:courseId??null,details:details??null}},[zeile]);
}

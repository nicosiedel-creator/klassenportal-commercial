import type { Env } from './types.js';
import { resolveCoreAuth } from './auth.js';
import { assertTenantWriteAllowed } from './commerce-offers.js';
import { requireDelegatedPrivilegeAccess } from './delegated-privilege.js';
import { assertSameOrigin, authStatus, json, safeErrorCode } from './utils.js';
import { teacherWorkloadBalance,teacherWorkloadSummary,deleteTeacherAvailability,listTeacherAvailability,saveTeacherAvailability,autofillTimetablePlan,getCourseSchedulingRules,linkPlanEntryResource,listPlanningBlackouts,listTeacherUnavailability,
  planningSuggestions,publishAdvancedTimetablePlan,saveCourseSchedulingRules,savePlanningBlackout,
  saveResourceUnavailability,saveTeacherWorkloadRules,substituteSuggestions,validateAdvancedTimetablePlan,
} from './planning-constraints.js';
import { saveTeacherUnavailabilityWithSubstitutions } from './planning-automation.js';
import { bookConsultationSlot,cancelConsultationBooking,consultationFamilySchedule,consultationRunSheet,
  generateConsultationSlots,listConsultationDays,listConsultationSlots,saveConsultationDay } from './consultation-booking.js';
import {
  listPlanningResourcesManaged,listPlanningTeachersManaged,listResourceUnavailabilityManaged,savePlanningResourceManaged,
} from './planning-resource-management.js';

async function body(request:Request):Promise<Record<string,unknown>>{try{return await request.json() as Record<string,unknown>;}catch{return{};}}
// Ein belegtes Zeitfenster ist kein Serverfehler, sondern das erwartete Ergebnis eines Wettlaufs:
// zwei Familien wollten dasselbe Fenster. Ohne diese Liste antwortete die Buchung mit 500, und die
// Oberflaeche haette dem Elternteil "Der Dienst ist nicht verfuegbar" gezeigt statt "schon vergeben".
const BELEGT=new Set(['CONSULTATION_SLOT_TAKEN','CONSULTATION_FAMILY_OVERLAP','CONSULTATION_TEACHER_ALREADY_BOOKED',
  'CONSULTATION_BOOKING_LIMIT_REACHED','CONSULTATION_SLOT_BLOCKED','CONSULTATION_DAY_NOT_OPEN',
  'CONSULTATION_BOOKING_NOT_STARTED','CONSULTATION_BOOKING_CLOSED','CONSULTATION_NO_SLOTS_POSSIBLE',
  'CONSULTATION_NO_TEACHERS','CONSULTATION_PERSON_NOT_IN_TENANT','CONSULTATION_SLOTS_TOO_MANY']);
function fail(e:unknown){const code=safeErrorCode(e),status=authStatus(code)??(code==='UNAUTHENTICATED'?401:code.startsWith('FORBIDDEN')?403:code.includes('NOT_FOUND')?404:BELEGT.has(code)||code.includes('CONFLICT')||code.includes('LOCKED')||code.includes('EXISTS')?409:code.includes('REQUIRED')||code.includes('INVALID')?400:500);return json({ok:false,error:code},status);}

export async function handlePlanningApi(request:Request,env:Env):Promise<Response|null>{
  const url=new URL(request.url),path=url.pathname;
  const advancedPlan=/^\/api\/education\/timetable-plans\/[^/]+\/(?:validate|publish|autofill)$/.test(path);
  if(!path.startsWith('/api/education/planning/')&&!advancedPlan)return null;
  try{
    assertSameOrigin(request,env.APP_ORIGIN);
    const tenantId=url.searchParams.get('tenant_id')||'';if(!tenantId)throw new Error('TENANT_REQUIRED');
    const courseId=url.searchParams.get('course_id')||undefined,auth=await resolveCoreAuth(env,request,tenantId,courseId);
    if(!auth.isPlatformAdmin&&auth.role!=='tenant_admin'&&(auth.permissions||[]).length)await requireDelegatedPrivilegeAccess(env,auth);
    if(request.method!=='GET'&&request.method!=='HEAD')await assertTenantWriteAllowed(env,tenantId);

    const validate=path.match(/^\/api\/education\/timetable-plans\/([^/]+)\/validate$/);if(validate&&request.method==='POST')return json({ok:true,...await validateAdvancedTimetablePlan(env,auth,tenantId,decodeURIComponent(validate[1]))});
    const autofill=path.match(/^\/api\/education\/timetable-plans\/([^/]+)\/autofill$/);if(autofill&&request.method==='POST')return json({ok:true,...await autofillTimetablePlan(env,auth,tenantId,decodeURIComponent(autofill[1]),await body(request))},201);
    const publish=path.match(/^\/api\/education\/timetable-plans\/([^/]+)\/publish$/);if(publish&&request.method==='POST')return json({ok:true,...await publishAdvancedTimetablePlan(env,auth,tenantId,decodeURIComponent(publish[1]))});

    if(path==='/api/education/planning/teacher-workload'&&request.method==='GET')return json({ok:true,workload:await teacherWorkloadSummary(env,auth,tenantId,{from:url.searchParams.get('from'),to:url.searchParams.get('to'),teacher_id:url.searchParams.get('teacher_id')||undefined})});
    // Soll-Ist auf tatsaechlich gehaltenem Unterricht - bewusst neben der reinen Stundensumme
    // und nicht in ihr: die Summe beantwortet "wie viel", diese Auswertung "und war das erlaubt".
    if(path==='/api/education/planning/teacher-workload-balance'&&request.method==='GET')return json({ok:true,balance:await teacherWorkloadBalance(env,auth,tenantId,{from:url.searchParams.get('from'),to:url.searchParams.get('to'),teacher_id:url.searchParams.get('teacher_id')||undefined})});
    if(path==='/api/education/planning/teacher-availability'&&request.method==='GET')return json({ok:true,availability:await listTeacherAvailability(env,auth,tenantId,url.searchParams.get('teacher_id')||undefined)});
    if(path==='/api/education/planning/teacher-availability'&&request.method==='POST')return json({ok:true,...await saveTeacherAvailability(env,auth,tenantId,await body(request))},201);
    const availabilityDelete=path.match(/^\/api\/education\/planning\/teacher-availability\/([^/]+)$/);if(availabilityDelete&&request.method==='DELETE')return json({ok:true,...await deleteTeacherAvailability(env,auth,tenantId,decodeURIComponent(availabilityDelete[1]))});
    if(path==='/api/education/planning/resources'&&request.method==='GET')return json({ok:true,resources:await listPlanningResourcesManaged(env,auth,tenantId)});
    if(path==='/api/education/planning/resources'&&request.method==='POST')return json({ok:true,...await savePlanningResourceManaged(env,auth,tenantId,await body(request))},201);
    if(path==='/api/education/planning/resources/unavailability'&&request.method==='GET')return json({ok:true,blocks:await listResourceUnavailabilityManaged(env,auth,tenantId)});
    if(path==='/api/education/planning/resources/unavailability'&&request.method==='POST')return json({ok:true,...await saveResourceUnavailability(env,auth,tenantId,await body(request))},201);
    if(path==='/api/education/planning/teachers'&&request.method==='GET')return json({ok:true,teachers:await listPlanningTeachersManaged(env,auth,tenantId)});

    if(path==='/api/education/planning/teacher-unavailability'&&request.method==='GET')return json({ok:true,blocks:await listTeacherUnavailability(env,auth,tenantId)});
    if(path==='/api/education/planning/teacher-unavailability'&&request.method==='POST')return json({ok:true,...await saveTeacherUnavailabilityWithSubstitutions(env,auth,tenantId,await body(request))},201);
    if(path==='/api/education/planning/blackouts'&&request.method==='GET')return json({ok:true,blackouts:await listPlanningBlackouts(env,auth,tenantId)});
    if(path==='/api/education/planning/blackouts'&&request.method==='POST')return json({ok:true,...await savePlanningBlackout(env,auth,tenantId,await body(request))},201);

    const courseRules=path.match(/^\/api\/education\/planning\/courses\/([^/]+)\/rules$/);
    if(courseRules&&request.method==='GET')return json({ok:true,rules:await getCourseSchedulingRules(env,auth,tenantId,decodeURIComponent(courseRules[1]))});
    if(courseRules&&request.method==='PUT')return json({ok:true,rules:await saveCourseSchedulingRules(env,auth,tenantId,decodeURIComponent(courseRules[1]),await body(request))});

    const teacherRules=path.match(/^\/api\/education\/planning\/teachers\/([^/]+)\/rules$/);if(teacherRules&&request.method==='PUT')return json({ok:true,...await saveTeacherWorkloadRules(env,auth,tenantId,decodeURIComponent(teacherRules[1]),await body(request))});
    const resourceLink=path.match(/^\/api\/education\/planning\/timetable-plans\/([^/]+)\/entries\/([^/]+)\/resources$/);if(resourceLink&&request.method==='POST')return json({ok:true,...await linkPlanEntryResource(env,auth,tenantId,decodeURIComponent(resourceLink[1]),decodeURIComponent(resourceLink[2]),await body(request))},201);
    // Sprechtag und Beratungsgespraech. Die Adressen liegen bewusst unter .../planning/: das
    // Raster stammt aus denselben Verfuegbarkeiten, Abwesenheiten und Sperrzeiten wie die Planung.
    if(path==='/api/education/planning/consultation-days'&&request.method==='GET')return json({ok:true,days:await listConsultationDays(env,auth,tenantId,courseId)});
    if(path==='/api/education/planning/consultation-days'&&request.method==='POST')return json({ok:true,...await saveConsultationDay(env,auth,tenantId,await body(request))},201);
    const consultationSlots=path.match(/^\/api\/education\/planning\/consultation-days\/([^/]+)\/slots$/);
    if(consultationSlots&&request.method==='GET')return json({ok:true,...await listConsultationSlots(env,auth,tenantId,decodeURIComponent(consultationSlots[1]))});
    if(consultationSlots&&request.method==='POST')return json({ok:true,...await generateConsultationSlots(env,auth,tenantId,decodeURIComponent(consultationSlots[1]),await body(request))},201);
    const consultationRun=path.match(/^\/api\/education\/planning\/consultation-days\/([^/]+)\/run-sheet$/);
    if(consultationRun&&request.method==='GET')return json({ok:true,...await consultationRunSheet(env,auth,tenantId,decodeURIComponent(consultationRun[1]),url.searchParams.get('teacher_id')||'')});
    const consultationPlan=path.match(/^\/api\/education\/planning\/consultation-days\/([^/]+)\/schedule$/);
    if(consultationPlan&&request.method==='GET')return json({ok:true,...await consultationFamilySchedule(env,auth,tenantId,decodeURIComponent(consultationPlan[1]),url.searchParams.get('user_id')||undefined)});
    if(path==='/api/education/planning/consultation-bookings'&&request.method==='POST')return json({ok:true,...await bookConsultationSlot(env,auth,tenantId,await body(request))},201);
    const consultationBooking=path.match(/^\/api\/education\/planning\/consultation-bookings\/([^/]+)$/);
    if(consultationBooking&&request.method==='DELETE')return json({ok:true,...await cancelConsultationBooking(env,auth,tenantId,decodeURIComponent(consultationBooking[1]))});

    if(path==='/api/education/planning/suggestions'&&request.method==='GET')return json({ok:true,...await planningSuggestions(env,auth,tenantId,{course_id:courseId,subject_id:url.searchParams.get('subject_id'),starts_at:url.searchParams.get('starts_at'),ends_at:url.searchParams.get('ends_at')})});
    const substitute=path.match(/^\/api\/education\/planning\/courses\/([^/]+)\/lessons\/([^/]+)\/substitutes$/);if(substitute&&request.method==='GET')return json({ok:true,...await substituteSuggestions(env,auth,tenantId,decodeURIComponent(substitute[1]),decodeURIComponent(substitute[2]))});
    return json({ok:false,error:'PLANNING_ROUTE_NOT_FOUND'},404);
  }catch(e){return fail(e);}
}

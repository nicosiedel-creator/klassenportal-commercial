import type { CoreAuthContext, Env } from './types.js';
import { requireRole } from './permissions.js';
import { assertBudget, verbucheVerbrauch } from './cost-guard.js';
import { id, nowIso, safeString, sha256Text } from './utils.js';

// KI-Modellabstraktion mit Fallback (K11).
//
// Jede KI-Nutzung hing an einem Anbieter. Faellt der aus, faellt die Funktion aus - und zwar
// stillschweigend, weil ein KI-Aufruf im Zweifel eine leere Antwort liefert statt zu scheitern.
// Das ist der schlimmste Fall: die Oberflaeche zeigt "keine Vorschlaege", und niemand erfaehrt,
// dass der Anbieter seit zwei Tagen 500er liefert.
//
// Drei Dinge machen die Abstraktion mehr als eine Schleife ueber Anbieter:
//  - FAEHIGKEITEN: ein Textmodell fuer eine Bildaufgabe zu waehlen ist kein Ausweichen, sondern
//    ein Fehler. Es wird gar nicht erst probiert.
//  - DATENKLASSE UND REGION: fail closed. Ohne Klassifizierung geht nichts hinaus, und ein
//    Modell, dessen Region oder Hoechstklasse nicht passt, wird uebersprungen - nicht als
//    letzte Rettung doch genommen.
//  - EINE GRENZE: hoechstens drei Versuche. Eine Kette ohne Grenze frisst bei einem
//    flaechigen Ausfall das Unteranfragenbudget des ganzen Aufrufs auf.

const clean=(v:unknown,n=500)=>safeString(v,n);
export const FAEHIGKEITEN=['text','vision','einbettung'] as const;
export const DATENKLASSEN=['oeffentlich','intern','personenbezogen','besonders'] as const;
export const REGIONEN=['eu','us','sonstige'] as const;
// Hoechstens so viele Modelle werden je Aufruf probiert. Jeder Versuch ist eine ausgehende
// Anfrage und zaehlt gegen die 1000 Unteranfragen, die ein Worker-Aufruf insgesamt hat.
export const HOECHSTVERSUCHE=3;
// Welche Regionen fuer welche Datenklasse zulaessig sind. Personendaten bleiben in der EU -
// das ist keine Vorliebe, sondern die Grundlage, auf der der Traeger seine Auftragsverarbeitung
// gemeldet hat.
export const ERLAUBTE_REGIONEN:Record<string,string[]>={
  oeffentlich:['eu','us','sonstige'],intern:['eu','us'],personenbezogen:['eu'],besonders:['eu']};
const RANG:Record<string,number>={oeffentlich:0,intern:1,personenbezogen:2,besonders:3};

export interface Modellzeile{id:string;tenant_id:string|null;anbieter:string;modell:string;faehigkeiten_json:string;
  region:string;max_datenklasse:string;kosten_je_1k_eingabe_cent:number;kosten_je_1k_ausgabe_cent:number;zeitlimit_ms:number;prioritaet:number}

export interface KiAntwort{text:string;eingabe_token:number;ausgabe_token:number}
/** Der Adapter. Bewusst schmal: mehr braucht das Portal nicht, und weniger geht nicht. */
export type KiAdapter=(auftrag:{modell:Modellzeile;eingabe:string;zeitlimit_ms:number})=>Promise<KiAntwort>;

const ADAPTER:Record<string,KiAdapter>={};
export function registriereKiAdapter(anbieter:string,adapter:KiAdapter){ADAPTER[anbieter]=adapter;}
export function bekannteKiAnbieter(){return Object.keys(ADAPTER).sort();}

/**
 * Die Kette fuer diesen Aufruf - EINE Abfrage, unabhaengig davon, wie viele Modelle eingetragen sind.
 *
 * Eine eigene Kette des Mandanten ERSETZT die plattformweite. Sonst liefe der Traeger, der
 * bewusst ein EU-Modell eingetragen hat, beim ersten Schluckauf ueber ein Modell der Plattform -
 * und genau das waere der Verstoss, den er vermeiden wollte.
 */
export async function modellkette(env:Env,tenantId:string|null,faehigkeit:string,datenklasse:string):Promise<Modellzeile[]>{
  const zeilen=((await env.DB.prepare('SELECT id,tenant_id,anbieter,modell,faehigkeiten_json,region,max_datenklasse,kosten_je_1k_eingabe_cent,kosten_je_1k_ausgabe_cent,zeitlimit_ms,prioritaet FROM ai_models WHERE aktiv=1 AND (tenant_id=? OR tenant_id IS NULL) ORDER BY prioritaet,anbieter,modell')
    .bind(tenantId).all<Modellzeile>()).results)??[];
  const eigene=zeilen.filter(z=>z.tenant_id);
  const grund=eigene.length?eigene:zeilen;
  const erlaubt=ERLAUBTE_REGIONEN[datenklasse]??[];
  return grund.filter(z=>{
    let f:string[]=[];try{f=JSON.parse(z.faehigkeiten_json||'[]');}catch{}
    if(!f.includes(faehigkeit))return false;
    if(!erlaubt.includes(z.region))return false;
    // Ein Modell, das hoechstens 'intern' darf, bekommt keine Personendaten - auch nicht als
    // letzte verbleibende Moeglichkeit.
    return (RANG[z.max_datenklasse]??0)>=(RANG[datenklasse]??99);
  });
}

export interface KiAuftrag{zweck:string;faehigkeit?:string;datenklasse?:string;eingabe:string;akteur?:string}

/**
 * Der Aufruf.
 *
 * Scheitert alles, wird das GEMELDET. Eine leere Antwort zurueckzugeben waere bequem und genau
 * der Fehler, den dieses Modul beheben soll: eine abgeschaltete Funktion, die aussieht wie eine
 * Funktion ohne Ergebnis.
 */
export async function frageKi(env:Env,tenantId:string|null,auftrag:KiAuftrag){
  const zweck=clean(auftrag.zweck,80);
  if(!zweck)throw new Error('KI_ZWECK_ERFORDERLICH');
  const faehigkeit=clean(auftrag.faehigkeit,30)||'text';
  if(!(FAEHIGKEITEN as readonly string[]).includes(faehigkeit))throw new Error('KI_FAEHIGKEIT_UNGUELTIG');
  // Fail closed: ohne Klassifizierung geht nichts hinaus. Eine Vorgabe waere hier bequem und
  // falsch - die haeufigste Eingabe im Portal enthaelt Personendaten.
  const datenklasse=clean(auftrag.datenklasse,30);
  if(!(DATENKLASSEN as readonly string[]).includes(datenklasse))throw new Error('KI_DATENKLASSE_ERFORDERLICH');
  const eingabe=String(auftrag.eingabe??'');
  if(!eingabe.trim())throw new Error('KI_EINGABE_ERFORDERLICH');
  const eingabeHash=await sha256Text(eingabe);
  const ts=nowIso();

  // Das Budget entscheidet VOR dem ersten Versuch. Danach waere das Geld schon ausgegeben.
  const budget=await assertBudget(env,tenantId,'ki',zweck).catch(async e=>{
    await schreibeAufruf(env,{tenantId,zweck,faehigkeit,datenklasse,eingabeHash,status:'abgelehnt',
      fehler:String((e as Error)?.message??'KI_BUDGET'),akteur:auftrag.akteur??null,ts});
    // Der Kostenwaechter meldet allgemein; hier bekommt die Person den Satz, der ihr sagt,
    // welche Funktion warum gerade nicht geht.
    throw new Error('KI_BUDGET_ERSCHOEPFT');
  });
  if(budget&&budget.stufe==='gebremst'){
    await schreibeAufruf(env,{tenantId,zweck,faehigkeit,datenklasse,eingabeHash,status:'abgelehnt',fehler:'KI_BUDGET_ERSCHOEPFT',akteur:auftrag.akteur??null,ts});
    throw new Error('KI_BUDGET_ERSCHOEPFT');
  }

  const kette=await modellkette(env,tenantId,faehigkeit,datenklasse);
  if(!kette.length){
    await schreibeAufruf(env,{tenantId,zweck,faehigkeit,datenklasse,eingabeHash,status:'abgelehnt',fehler:'KI_KEIN_ZUGELASSENES_MODELL',akteur:auftrag.akteur??null,ts});
    throw new Error('KI_KEIN_ZUGELASSENES_MODELL');
  }
  const ausgewichen:string[]=[];
  let letzterFehler='KI_KEIN_VERSUCH';
  for(const modell of kette.slice(0,HOECHSTVERSUCHE)){
    const adapter=ADAPTER[modell.anbieter];
    if(!adapter){ausgewichen.push(`${modell.anbieter}:KEIN_ADAPTER`);letzterFehler='KI_ADAPTER_FEHLT';continue;}
    const begonnen=Date.now();
    try{
      const antwort=await mitZeitlimit(adapter({modell,eingabe,zeitlimit_ms:modell.zeitlimit_ms}),modell.zeitlimit_ms);
      const dauer=Date.now()-begonnen;
      const kosten=Math.round(antwort.eingabe_token/1000*modell.kosten_je_1k_eingabe_cent
        +antwort.ausgabe_token/1000*modell.kosten_je_1k_ausgabe_cent);
      const aufrufId=await schreibeAufruf(env,{tenantId,zweck,faehigkeit,datenklasse,eingabeHash,
        ausgabeHash:await sha256Text(antwort.text),modellId:modell.id,
        eingabeToken:antwort.eingabe_token,ausgabeToken:antwort.ausgabe_token,kosten,dauer,
        status:'erfolg',ausgewichen,akteur:auftrag.akteur??null,ts});
      await verbucheVerbrauch(env,{tenant_id:tenantId,dienst:'ki',funktion:zweck,einheiten:1,betrag_cent:kosten,quelle_ref:aufrufId});
      return{invocation_id:aufrufId,text:antwort.text,anbieter:modell.anbieter,modell:modell.modell,
        eingabe_hash:eingabeHash,kosten_cent:kosten,ausgewichen};
    }catch(e){
      letzterFehler=fehlercode(e);
      ausgewichen.push(`${modell.anbieter}/${modell.modell}:${letzterFehler}`);
    }
  }
  // Alles probiert, nichts ging. Das ist eine Stoerung, keine leere Antwort.
  await schreibeAufruf(env,{tenantId,zweck,faehigkeit,datenklasse,eingabeHash,status:'fehler',
    fehler:letzterFehler,ausgewichen,akteur:auftrag.akteur??null,ts});
  throw new Error('KI_NICHT_ERREICHBAR');
}

function fehlercode(error:unknown):string{
  const roh=String((error as Error)?.message??error??'FEHLER');
  return (roh.split(':')[0]||'FEHLER').trim().toUpperCase().replace(/[^A-Z0-9_]+/g,'_').slice(0,60)||'FEHLER';
}

/** Ein haengender Anbieter darf den Aufruf nicht mitnehmen. */
function mitZeitlimit<T>(p:Promise<T>,ms:number):Promise<T>{
  return new Promise<T>((loese,brich)=>{
    const uhr=setTimeout(()=>brich(new Error('KI_ZEITUEBERSCHREITUNG')),Math.max(1000,ms));
    p.then(v=>{clearTimeout(uhr);loese(v);},e=>{clearTimeout(uhr);brich(e);});
  });
}

async function schreibeAufruf(env:Env,d:{tenantId:string|null;zweck:string;faehigkeit:string;datenklasse:string;eingabeHash:string;
  ausgabeHash?:string;modellId?:string;eingabeToken?:number;ausgabeToken?:number;kosten?:number;dauer?:number;
  status:'erfolg'|'abgelehnt'|'fehler';fehler?:string|null;ausgewichen?:string[];akteur:string|null;ts:string}){
  const aufrufId=id('kia_');
  await env.DB.prepare('INSERT INTO ai_invocations(id,tenant_id,zweck,faehigkeit,datenklasse,modell_id,eingabe_hash,ausgabe_hash,eingabe_token,ausgabe_token,kosten_cent,dauer_ms,status,ausgewichen_json,fehler,akteur,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(aufrufId,d.tenantId,d.zweck,d.faehigkeit,d.datenklasse,d.modellId??null,d.eingabeHash,d.ausgabeHash??null,
      d.eingabeToken??0,d.ausgabeToken??0,d.kosten??0,d.dauer??0,d.status,JSON.stringify(d.ausgewichen??[]),
      d.fehler??null,d.akteur,d.ts).run();
  return aufrufId;
}

/** Modelle pflegen - Traegerleitung, weil daran die Auftragsverarbeitung haengt. */
export async function legeModellAn(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const anbieter=clean(input.anbieter,60),modell=clean(input.modell,120);
  if(!anbieter||!modell)throw new Error('KI_MODELL_UNVOLLSTAENDIG');
  const region=clean(input.region,20)||'eu';
  if(!(REGIONEN as readonly string[]).includes(region))throw new Error('KI_REGION_UNGUELTIG');
  const maxKlasse=clean(input.max_datenklasse,30)||'intern';
  if(!(DATENKLASSEN as readonly string[]).includes(maxKlasse))throw new Error('KI_DATENKLASSE_UNGUELTIG');
  // Ein Modell in den USA, das Personendaten annehmen soll, waere der Eintrag, der die ganze
  // Kette wertlos macht. Er wird hier abgelehnt und nicht erst beim Aufruf uebersprungen.
  if(!(ERLAUBTE_REGIONEN[maxKlasse]??[]).includes(region))throw new Error('KI_REGION_ZU_KLASSE_UNZULAESSIG');
  const roh=Array.isArray(input.faehigkeiten)?input.faehigkeiten.map(v=>clean(v,20)):['text'];
  const faehigkeiten=[...new Set(roh)].filter(f=>(FAEHIGKEITEN as readonly string[]).includes(f));
  if(!faehigkeiten.length)throw new Error('KI_FAEHIGKEIT_ERFORDERLICH');
  const ts=nowIso(),modellId=id('kim_');
  await env.DB.prepare('INSERT INTO ai_models(id,tenant_id,anbieter,modell,faehigkeiten_json,region,max_datenklasse,kosten_je_1k_eingabe_cent,kosten_je_1k_ausgabe_cent,zeitlimit_ms,prioritaet,aktiv,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,1,?,?)')
    .bind(modellId,tenantId,anbieter,modell,JSON.stringify(faehigkeiten),region,maxKlasse,
      Math.max(0,Math.trunc(Number(input.kosten_je_1k_eingabe_cent??0))),Math.max(0,Math.trunc(Number(input.kosten_je_1k_ausgabe_cent??0))),
      Math.min(120000,Math.max(1000,Math.trunc(Number(input.zeitlimit_ms??20000)))),Math.trunc(Number(input.prioritaet??100)),ts,ts).run();
  return{id:modellId,anbieter,modell,region};
}

export async function listeModelle(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return ((await env.DB.prepare('SELECT id,tenant_id,anbieter,modell,faehigkeiten_json,region,max_datenklasse,prioritaet,aktiv FROM ai_models WHERE tenant_id=? OR tenant_id IS NULL ORDER BY prioritaet,anbieter')
    .bind(tenantId).all()).results)??[];
}

export async function schalteModell(env:Env,auth:CoreAuthContext,tenantId:string,modellId:string,aktiv:boolean){
  requireRole(auth,'tenant_admin');
  const zeile=await env.DB.prepare('SELECT id FROM ai_models WHERE id=? AND tenant_id=?').bind(clean(modellId,120),tenantId).first();
  if(!zeile)throw new Error('KI_MODELL_NICHT_GEFUNDEN');
  await env.DB.prepare('UPDATE ai_models SET aktiv=?,updated_at=? WHERE id=? AND tenant_id=?').bind(aktiv?1:0,nowIso(),clean(modellId,120),tenantId).run();
  return{aktiv};
}

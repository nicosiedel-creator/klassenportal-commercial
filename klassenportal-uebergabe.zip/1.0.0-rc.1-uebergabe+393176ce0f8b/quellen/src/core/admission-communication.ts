import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { mailConfigured } from './mail.js';
import { versendeMail } from './provider-registry.js';
import { enforcePublicWriteLimit, storeIntakeSubmissionDocuments } from './intake-center.js';
import { istErsatzAdresse } from './participant-document-import.js';
import { requireRole } from './permissions.js';
import { b64, id, nowIso, randomBytes, safeString, sha256Text } from './utils.js';
import { MAX_ADMISSION_DOCUMENT_BYTES, MAX_ADMISSION_FILES, MAX_ADMISSION_TOTAL_BYTES } from './admissions.js';

// Bewerberkommunikation.
//
// Der Trichter konnte alles ausser reden: eine Bewerbung ging ein, wurde entschieden und
// aufgenommen - und der Mensch am anderen Ende erfuhr davon nichts. In der Praxis lief das ueber
// das private Postfach der Sachbearbeitung. Nicht nachweisbar, und die nachgeforderten Zeugnisse
// landeten dort ebenfalls.
//
// Drei Regeln, und sie sind der ganze Inhalt dieses Moduls:
//
// 1. DIE INTERNE NOTIZ GEHT NIE HINAUS. admissions.decision_note ist die Begruendung fuer die
//    eigene Akte; was der Bewerber liest, wird eigens geschrieben. Eine durchgereichte
//    Absagenotiz ist der kuerzeste Weg in ein AGG-Verfahren.
// 2. EINE NACHFORDERUNG HAT EINE FRIST UND EINEN RUECKWEG. Der Rueckweg ist ein Einmal-Link, der
//    ausschliesslich einreichen laesst. Einen Statusabruf gibt es bewusst nicht: ein Link, der
//    den Stand einer Bewerbung zeigt, zeigt ihn jedem, an den er weitergeleitet wird.
// 3. OHNE ERREICHBARE ADRESSE WIRD NICHTS VERSENDET, ABER ALLES FESTGEHALTEN. Wer keine eigene
//    E-Mail hinterlassen hat, bekommt im Trichter eine Ersatzadresse - die ist kein Postfach.
//    Dorthin zu senden hiesse, den Versand nur zu behaupten.

export const NACHRICHTENARTEN=['eingang','nachforderung','einladung','zusage','absage','hinweis'] as const;
export type Nachrichtenart=(typeof NACHRICHTENARTEN)[number];

/** Frist einer Nachforderung, wenn der Traeger keine eigene setzt. */
export const NACHFORDERUNG_TAGE_STANDARD=14;
export const NACHFORDERUNG_TAGE_MAX=90;
/** Wie lange der Einmal-Link nach Fristende noch traegt - ein Tag Puffer fuer den letzten Abend. */
export const LINK_PUFFER_TAGE=1;
export const MAX_BETREFF=160;
export const MAX_TEXT=4000;

const BETREFF:Record<Nachrichtenart,string>={
  eingang:'Ihre Bewerbung ist eingegangen',nachforderung:'Es fehlen noch Unterlagen',
  einladung:'Einladung zum Gespräch',zusage:'Ihre Zusage',absage:'Ihre Bewerbung',hinweis:'Zu Ihrer Bewerbung',
};

function tage(wert:unknown,standard:number){
  const n=Math.floor(Number(wert));
  if(!Number.isFinite(n)||n<1)return standard;
  return Math.min(NACHFORDERUNG_TAGE_MAX,n);
}
function plusTage(ab:string,n:number){return new Date(new Date(ab).getTime()+n*86400000).toISOString();}
const escapeHtml=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c] as string));

async function ladeBewerbung(env:Env,tenantId:string,admissionId:string){
  const z=await env.DB.prepare(`SELECT id,tenant_id,reference_code,applicant_name,applicant_email,status,intake_batch_id,anonymisiert_am
    FROM admissions WHERE tenant_id=? AND id=?`).bind(tenantId,safeString(admissionId,120))
    .first<{id:string;tenant_id:string;reference_code:string;applicant_name:string;applicant_email:string;status:string;intake_batch_id:string|null;anonymisiert_am:string|null}>();
  if(!z)throw new Error('ADMISSION_NOT_FOUND');
  // Eine anonymisierte Bewerbung hat keinen Empfaenger mehr. Ihr zu schreiben hiesse, den
  // Personenbezug wiederherzustellen, den die Loeschung gerade entfernt hat.
  if(z.anonymisiert_am)throw new Error('ADMISSION_ANONYMISIERT');
  return z;
}

/** Ist diese Adresse ein Postfach - oder die Ersatzadresse fuer jemanden ohne eigene? */
export function erreichbar(email:string|null|undefined){
  const a=String(email??'');
  return !!a&&!istErsatzAdresse(a);
}

function baueText(name:string,referenz:string,text:string,linkZeile:string|null){
  const rumpf=`Guten Tag ${name},\n\n${text}\n\n`+(linkZeile?`${linkZeile}\n\n`:'')
    +`Ihre Vorgangsnummer: ${referenz}\n\nBitte antworten Sie nicht auf diese Nachricht.`;
  const html=`<p>Guten Tag ${escapeHtml(name)},</p>`
    +text.split(/\n{2,}/).map(a=>`<p>${escapeHtml(a).replace(/\n/g,'<br>')}</p>`).join('')
    +(linkZeile?`<p>${linkZeile.replace(/(https?:\/\/\S+)/,'<a href="$1">$1</a>')}</p>`:'')
    +`<p>Ihre Vorgangsnummer: <strong>${escapeHtml(referenz)}</strong></p>`
    +`<p>Bitte antworten Sie nicht auf diese Nachricht.</p>`;
  return{text:rumpf,html};
}

/**
 * Die Adresse, unter der das Portal wirklich laeuft.
 *
 * Hier stand ein Rueckfall auf eine feste Domain, und die dafuer vorgesehene Variable war
 * nirgends gesetzt - auch nicht in der Konfiguration. Jede Einladung zum Nachreichen und jeder
 * Link in der Verwaltungsmaske zeigte damit beim Traeger auf eine FREMDE Domain, samt
 * Einmal-Token in der Adresse. Der Bewerber konnte nichts einreichen, und das Token ging an
 * jemand anderen.
 *
 * Deshalb: dieselbe Quelle wie jeder andere Mailweg (APP_ORIGIN), und ohne sie ein Fehler statt
 * einer Vermutung.
 */
function basis(env:Env){const roh=String(env.APP_ORIGIN||'').trim().replace(/\/$/,'');if(!/^https:\/\//.test(roh))throw new Error('APP_ORIGIN_REQUIRED');return roh;}

/**
 * Eine Nachricht an den Bewerber - festhalten, dann senden.
 *
 * In dieser Reihenfolge: eine Nachricht, die hinausging, aber nicht in der Akte steht, ist
 * schlimmer als eine, die in der Akte steht und nicht hinausging. Das Erste faellt niemandem auf,
 * das Zweite steht als Fehler daneben.
 */
async function schreibeUndSende(env:Env,bewerbung:{id:string;reference_code:string;applicant_name:string;applicant_email:string},
  tenantId:string,art:Nachrichtenart,betreff:string,text:string,
  extra:{frist_am?:string|null;token?:string|null;token_expires_at?:string|null;gesendet_von?:string|null}={}){
  const jetzt=nowIso(),nachrichtId=id('amsg_');
  const kanal=erreichbar(bewerbung.applicant_email)&&mailConfigured(env)?'mail':'kein_kanal';
  const linkZeile=extra.token?`Ihre Unterlagen reichen Sie hier ein: ${basis(env)}/bewerbung/nachreichen/${extra.token}`:null;
  await env.DB.prepare(`INSERT INTO admission_messages(id,tenant_id,admission_id,art,betreff,text,frist_am,kanal,token_hash,token_expires_at,gesendet_von,created_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(nachrichtId,tenantId,bewerbung.id,art,betreff,text,extra.frist_am??null,kanal,
      extra.token?await sha256Text(extra.token):null,extra.token_expires_at??null,extra.gesendet_von??null,jetzt).run();
  let fehler:string|null=null;
  if(kanal==='mail'){
    const {text:reintext,html}=baueText(bewerbung.applicant_name,bewerbung.reference_code,text,linkZeile);
    try{
      await versendeMail(env,{an:bewerbung.applicant_email,betreff,text:reintext,html,tenantId,schluessel:`admission:${nachrichtId}`});
    }catch(e){
      // Der Fehlschlag gehoert in die Akte, nicht ins Nichts: sonst wartet der Traeger auf eine
      // Antwort, die nie kommen kann, und der Bewerber auf eine Nachricht, die nie ankam.
      fehler=String((e as Error)?.message||e).slice(0,120);
      await env.DB.prepare('UPDATE admission_messages SET versand_fehler=? WHERE id=?').bind(fehler,nachrichtId).run();
    }
  }
  return{id:nachrichtId,art,betreff,kanal,frist_am:extra.frist_am??null,versand_fehler:fehler,gesendet_am:jetzt};
}

/**
 * Die Eingangsbestaetigung. Sie laeuft ohne angemeldeten Menschen, direkt aus dem Trichter.
 *
 * Sie nennt die Vorgangsnummer und sonst nichts: kein Stand, kein Termin, keine Aussicht. Was ein
 * Traeger darueber hinaus sagen will, sagt er als eigene Nachricht - unter seinem Namen.
 */
export async function bestaetigeEingang(env:Env,tenantId:string,admissionId:string){
  const b=await ladeBewerbung(env,tenantId,admissionId);
  return schreibeUndSende(env,b,tenantId,'eingang',BETREFF.eingang,
    'wir haben Ihre Bewerbung erhalten. Wir prüfen sie und melden uns. Sollten Unterlagen fehlen, fordern wir sie gesondert an.');
}

/**
 * Die Bestaetigung zu einer eben eingegangenen Bewerbung - gesucht ueber Formularschluessel und
 * Vorgangsnummer.
 *
 * Der Umweg ist Absicht. Die Antwort des oeffentlichen Weges darf weder Mandanten- noch
 * Vorgangskennung enthalten: sie waere sonst an jeder eingegangenen Bewerbung ablesbar, und schon
 * die Kennung sagt etwas ueber den Bestand. Zwei Abfragen sind der Preis dafuer.
 */
export async function bestaetigeEingangZuVorgang(env:Env,slug:string,referenz:string){
  const formular=await env.DB.prepare("SELECT tenant_id FROM admission_forms WHERE public_slug=? AND status='published'")
    .bind(safeString(slug,120)).first<{tenant_id:string}>();
  if(!formular)return null;
  const zeile=await env.DB.prepare('SELECT id FROM admissions WHERE tenant_id=? AND reference_code=?')
    .bind(String(formular.tenant_id),safeString(referenz,60)).first<{id:string}>();
  if(!zeile)return null;
  return bestaetigeEingang(env,String(formular.tenant_id),String(zeile.id));
}

/**
 * Nachricht von Hand - Einladung, Zusage, Absage, Hinweis.
 *
 * Der Text kommt vom Traeger. Die interne Entscheidungsnotiz wird nicht angeboten und nicht
 * vorbelegt: was hinausgeht, schreibt ein Mensch bewusst.
 */
export async function sendeBewerbernachricht(env:Env,auth:CoreAuthContext,tenantId:string,admissionId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const art=String(eingabe.art||'hinweis') as Nachrichtenart;
  if(!NACHRICHTENARTEN.includes(art)||art==='eingang'||art==='nachforderung')throw new Error('BEWERBERNACHRICHT_ART_UNGUELTIG');
  const text=safeString(eingabe.text,MAX_TEXT);
  if(text.length<20)throw new Error('BEWERBERNACHRICHT_TEXT_ERFORDERLICH');
  const b=await ladeBewerbung(env,tenantId,admissionId);
  const betreff=safeString(eingabe.betreff,MAX_BETREFF)||BETREFF[art];
  const n=await schreibeUndSende(env,b,tenantId,art,betreff,text,{gesendet_von:auth.userId});
  await audit(env.DB,auth.userId,'admission.message.sent',tenantId,undefined,'admission',b.id,{art,kanal:n.kanal});
  return n;
}

/**
 * Unterlagen nachfordern: Frist, Einmal-Link, Wiedervorlage.
 *
 * Der Link traegt bis einen Tag nach der Frist - wer am letzten Abend hochlaedt, soll nicht an
 * einer Zeitzone scheitern. Danach ist er tot, und zwar wirklich: geprueft wird gegen den
 * gespeicherten Ablauf, nicht gegen den Stand der Bewerbung.
 */
export async function fordereUnterlagenNach(env:Env,auth:CoreAuthContext,tenantId:string,admissionId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const text=safeString(eingabe.text,MAX_TEXT);
  if(text.length<20)throw new Error('BEWERBERNACHRICHT_TEXT_ERFORDERLICH');
  const b=await ladeBewerbung(env,tenantId,admissionId);
  if(b.status==='rejected'||b.status==='enrolled')throw new Error('ADMISSION_ENTSCHIEDEN');
  const jetzt=nowIso(),frist=plusTage(jetzt,tage(eingabe.frist_tage,NACHFORDERUNG_TAGE_STANDARD));
  const token=b64(randomBytes(32)).replace(/[^A-Za-z0-9]/g,'').slice(0,43);
  const n=await schreibeUndSende(env,b,tenantId,'nachforderung',safeString(eingabe.betreff,MAX_BETREFF)||BETREFF.nachforderung,
    `${text}\n\nBitte reichen Sie die Unterlagen bis zum ${frist.slice(0,10).split('-').reverse().join('.')} ein.`,
    {frist_am:frist,token,token_expires_at:plusTage(frist,LINK_PUFFER_TAGE),gesendet_von:auth.userId});
  await audit(env.DB,auth.userId,'admission.documents.requested',tenantId,undefined,'admission',b.id,{frist_am:frist,kanal:n.kanal});
  // Der Link steht genau einmal in der Antwort - danach nur noch sein Hash. Wer keine erreichbare
  // Adresse hat, bekommt ihn so auf Papier oder am Telefon.
  return{...n,link:`${basis(env)}/bewerbung/nachreichen/${token}`};
}

/** Der Verlauf einer Bewerbung: was wann an wen ging - und was offen ist. */
export async function bewerbungsverlauf(env:Env,auth:CoreAuthContext,tenantId:string,admissionId:string){
  requireRole(auth,'tenant_admin');
  const zeilen=((await env.DB.prepare(`SELECT id,art,betreff,text,frist_am,kanal,versand_fehler,uploads,erledigt_am,erinnert_am,gesendet_von,created_at
    FROM admission_messages WHERE tenant_id=? AND admission_id=? ORDER BY created_at DESC,rowid DESC LIMIT 200`)
    .bind(tenantId,safeString(admissionId,120)).all<Record<string,unknown>>()).results)??[];
  const jetzt=nowIso();
  return zeilen.map(z=>({...z,
    offen:z.art==='nachforderung'&&!z.erledigt_am,
    ueberfaellig:z.art==='nachforderung'&&!z.erledigt_am&&String(z.frist_am??'')<jetzt}));
}

// ---------------------------------------------------------------------------------------------
// Der Rueckweg: ausschliesslich einreichen
// ---------------------------------------------------------------------------------------------

async function nachforderungZuToken(env:Env,roh:string){
  const hash=await sha256Text(String(roh||''));
  const z=await env.DB.prepare(`SELECT m.id,m.tenant_id,m.admission_id,m.token_expires_at,m.erledigt_am,m.uploads,m.intake_batch_id,a.reference_code,a.status,a.anonymisiert_am
    FROM admission_messages m JOIN admissions a ON a.id=m.admission_id
    WHERE m.token_hash=? AND m.art='nachforderung'`).bind(hash)
    .first<{id:string;tenant_id:string;admission_id:string;token_expires_at:string;erledigt_am:string|null;uploads:number;intake_batch_id:string|null;reference_code:string;status:string;anonymisiert_am:string|null}>();
  // Ein einziger Fehler fuer alle Faelle: unbekannt, abgelaufen, schon erledigt, Bewerbung
  // entschieden. Wer die Unterschiede sieht, kann Vorgangsnummern durchprobieren.
  if(!z||z.anonymisiert_am||String(z.token_expires_at)<=nowIso()||Number(z.uploads)>=3
    ||z.status==='rejected'||z.status==='enrolled')throw new Error('NACHREICHEN_LINK_UNGUELTIG');
  return z;
}

/** Was die Seite zum Nachreichen anzeigen darf: die Vorgangsnummer, sonst nichts. */
export async function nachreichenAnfrage(env:Env,roh:string){
  const z=await nachforderungZuToken(env,roh);
  return{reference:z.reference_code};
}

/**
 * Der Upload ueber den Einmal-Link.
 *
 * Die Nachweise landen in einem eigenen Stapel, der an der Nachricht haengt - damit spaeter
 * unterscheidbar bleibt, was mit der Bewerbung kam und was nachgereicht wurde. Der Aufraeumlauf
 * schuetzt beide Stapel, solange die Bewerbung laeuft.
 */
export async function nimmNachgereichtesAn(env:Env,roh:string,request:Request){
  const z=await nachforderungZuToken(env,roh);
  const absender=request.headers.get('CF-Connecting-IP')||'unbekannt';
  await enforcePublicWriteLimit(env,`nachreichen:${z.id}:${absender}`,10,'ADMISSION_RATE_LIMITED');
  const formular=await request.formData();
  const dateien=formular.getAll('files').filter(x=>x instanceof File) as File[];
  if(!dateien.length)throw new Error('ADMISSION_DOCUMENTS_REQUIRED');
  if(dateien.length>MAX_ADMISSION_FILES)throw new Error('ADMISSION_TOO_MANY_DOCUMENTS');
  // Alles zu EINER Aufforderung landet im selben Stapel - auch der Nachtrag von morgen. Sonst
  // haengt der zweite Stapel an nichts, und der Aufraeumlauf, der laufende Vorgaenge verschont,
  // kennt ihn nicht.
  const abgelegt=await storeIntakeSubmissionDocuments(env,z.tenant_id,dateien,{
    subject:`Nachgereicht ${z.reference_code}`,sender:`admission-followup:${z.admission_id}`,courseId:null,
    retentionDays:90,maxFiles:MAX_ADMISSION_FILES,maxFileBytes:MAX_ADMISSION_DOCUMENT_BYTES,maxTotalBytes:MAX_ADMISSION_TOTAL_BYTES,
    batchId:z.intake_batch_id});
  // "Schon da" ist kein Fehler des Einreichenden, sondern eine Auskunft: wer unsicher ist, ob
  // seine Datei angekommen ist, schickt sie noch einmal - und bekommt sonst zu hoeren, sie sei
  // abgelehnt worden.
  if(!abgelegt.stored){
    if(abgelegt.rejected.every(r=>r.error==='DUPLICATE_DOCUMENT'))throw new Error('ADMISSION_DOCUMENT_DUPLICATE');
    throw new Error('ADMISSION_DOCUMENT_REJECTED');
  }
  const jetzt=nowIso();
  await env.DB.batch([
    env.DB.prepare('UPDATE admission_messages SET uploads=uploads+1,erledigt_am=?,intake_batch_id=COALESCE(intake_batch_id,?) WHERE id=?')
      .bind(jetzt,abgelegt.batch_id,z.id),
    env.DB.prepare('UPDATE admissions SET document_count=document_count+?,updated_at=? WHERE tenant_id=? AND id=?')
      .bind(abgelegt.stored,jetzt,z.tenant_id,z.admission_id),
    env.DB.prepare('INSERT INTO automation_events(id,tenant_id,event_type,source_type,source_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)')
      .bind(id('aev_'),z.tenant_id,'admission.documents.received','admission',z.admission_id,JSON.stringify({documents:abgelegt.stored}),jetzt),
  ]);
  return{reference:z.reference_code,documents:abgelegt.stored,status:'eingegangen'};
}

// ---------------------------------------------------------------------------------------------
// Der Turnus: Fristen laufen, auch wenn niemand hinsieht
// ---------------------------------------------------------------------------------------------

/**
 * Erinnert an offene Nachforderungen - erst den Bewerber, nach Fristablauf den Traeger.
 *
 * Die Erinnerung geht EINMAL raus (erinnert_am), drei Tage vor Fristende. Danach ist es die Sache
 * des Traegers zu entscheiden, nicht die einer Automatik: eine Bewerbung wegen fehlender
 * Unterlagen selbsttaetig abzulehnen waere eine Entscheidung ohne Mensch - und im Streitfall
 * genau die, die niemand vertreten will.
 */
export async function erinnereAnBewerberfristen(env:Env,grenze=20,jetzt=nowIso()){
  const vorlauf=plusTage(jetzt,3);
  const offene=((await env.DB.prepare(`SELECT m.id,m.tenant_id,m.admission_id,m.frist_am,a.reference_code,a.applicant_name,a.applicant_email,a.status,a.anonymisiert_am
    FROM admission_messages m JOIN admissions a ON a.id=m.admission_id
    WHERE m.art='nachforderung' AND m.erledigt_am IS NULL AND m.erinnert_am IS NULL AND m.frist_am<=?
    ORDER BY m.frist_am LIMIT ?`).bind(vorlauf,Math.max(1,Math.min(100,grenze)))
    .all<{id:string;tenant_id:string;admission_id:string;frist_am:string;reference_code:string;applicant_name:string;applicant_email:string;status:string;anonymisiert_am:string|null}>()).results)??[];
  let erinnert=0,aufgaben=0;
  for(const o of offene){
    const ts=nowIso();
    if(o.anonymisiert_am||o.status==='rejected'||o.status==='enrolled'){
      await env.DB.prepare('UPDATE admission_messages SET erinnert_am=? WHERE id=?').bind(ts,o.id).run();
      continue;
    }
    if(String(o.frist_am)>jetzt&&erreichbar(o.applicant_email)&&mailConfigured(env)){
      const {text,html}=baueText(o.applicant_name,o.reference_code,
        `die Frist für die angeforderten Unterlagen läuft am ${String(o.frist_am).slice(0,10).split('-').reverse().join('.')} ab. Bitte verwenden Sie den Link aus unserer Nachricht.`,null);
      await versendeMail(env,{an:o.applicant_email,betreff:'Erinnerung: Es fehlen noch Unterlagen',text,html,tenantId:o.tenant_id,schluessel:`admission-reminder:${o.id}`})
        .catch(e=>{console.error('Bewerbererinnerung',{error:String((e as Error)?.message||e)});});
      erinnert++;
    }else{
      // Frist vorbei oder kein Kanal: das ist jetzt eine Sache fuer den Schreibtisch.
      await env.DB.prepare('INSERT INTO automation_events(id,tenant_id,event_type,source_type,source_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)')
        .bind(id('aev_'),o.tenant_id,'admission.documents.overdue','admission',o.admission_id,
          JSON.stringify({reference:o.reference_code,frist_am:o.frist_am}),ts).run();
      aufgaben++;
    }
    await env.DB.prepare('UPDATE admission_messages SET erinnert_am=? WHERE id=?').bind(ts,o.id).run();
  }
  return{geprueft:offene.length,erinnert,aufgaben};
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Loeschsperre, Aufbewahrungsfristen und Einwilligungen.
//
// Geloescht werden konnte bisher; gesperrt nicht. Das ist die gefaehrlichere Haelfte: eine
// turnusmaessige Frist, die mitten in einem laufenden Verfahren zuschlaegt, loescht genau die
// Unterlagen weg, um die gestritten wird. Das ist kein Datenschutzgewinn, sondern
// Beweisvereitelung - und trifft den Traeger haerter als eine zu lange Aufbewahrung.
//
// Die Regel dieses Moduls ist deshalb eine einzige, und sie gilt ohne Ausnahme:
// EINE AKTIVE SPERRE SCHLAEGT JEDE FRIST. Nicht "in der Regel", nicht "sofern konfiguriert".

export const UMFAENGE=['mandant','person','kurs','vorgang'] as const;
export const GRUENDE=['rechtsstreit','behoerde','pruefungsanfechtung','ermittlung','sonstiges'] as const;
export const MASSNAHMEN=['loeschen','anonymisieren','archivieren'] as const;

// Vorgabewerte, die ein Traeger bestaetigen oder aendern muss. Sie stehen hier und nicht in der
// Migration, weil sie eine Rechtsfrage sind: die Zahlen folgen den ueblichen deutschen Fristen,
// ersetzen aber keine Pruefung fuer den Einzelfall.
export const FRIST_VORGABEN:Record<string,{monate:number;grundlage:string;massnahme:typeof MASSNAHMEN[number]}>={
  buchhaltung:{monate:120,grundlage:'§ 147 AO, § 257 HGB — zehn Jahre',massnahme:'archivieren'},
  teilnahmenachweise:{monate:120,grundlage:'Nachweispflicht gegenüber Kostenträgern',massnahme:'archivieren'},
  pruefungsunterlagen:{monate:60,grundlage:'Anfechtbarkeit von Prüfungsentscheidungen',massnahme:'archivieren'},
  zeugnisse:{monate:600,grundlage:'Ein Zeugnis wird Jahrzehnte später gebraucht',massnahme:'archivieren'},
  anwesenheit:{monate:120,grundlage:'Grundlage der Förderabrechnung',massnahme:'anonymisieren'},
  bewerbungen:{monate:6,grundlage:'§ 15 AGG — sechs Monate nach Absage',massnahme:'loeschen'},
  kommunikation:{monate:36,grundlage:'Betrieblicher Zweck entfällt',massnahme:'loeschen'},
  protokolle:{monate:36,grundlage:'Nachvollziehbarkeit von Zugriffen',massnahme:'loeschen'},
};

const clean=(v:unknown,n=500)=>safeString(v,n);

// ---------------------------------------------------------------------------
// Loeschsperre
// ---------------------------------------------------------------------------

export async function placeLegalHold(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const umfang=clean(input.umfang,40),grund=clean(input.grund,40),beschreibung=clean(input.beschreibung,4000);
  if(!UMFAENGE.includes(umfang as never))throw new Error('HOLD_SCOPE_INVALID');
  if(!GRUENDE.includes(grund as never))throw new Error('HOLD_REASON_INVALID');
  // Eine Sperre ohne Begruendung laesst sich spaeter nicht rechtfertigen - und eine Sperre ist ein
  // Eingriff in das Loeschrecht der betroffenen Person, den man begruenden koennen muss.
  if(beschreibung.length<20)throw new Error('HOLD_DESCRIPTION_REQUIRED');
  const bezug=clean(input.bezug_id,120)||null;
  if(umfang!=='mandant'&&!bezug)throw new Error('HOLD_SUBJECT_REQUIRED');
  const hid=id('hold_'),ts=nowIso();
  await env.DB.prepare('INSERT INTO legal_holds(id,tenant_id,umfang,bezug_id,grund,aktenzeichen,beschreibung,status,verhaengt_von,verhaengt_am,updated_at) VALUES(?,?,?,?,?,?,?,\'aktiv\',?,?,?)')
    .bind(hid,tenantId,umfang,bezug,grund,clean(input.aktenzeichen,120)||null,beschreibung,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'legal_hold.placed',tenantId,undefined,'legal_hold',hid,{umfang,grund});
  return env.DB.prepare('SELECT * FROM legal_holds WHERE id=?').bind(hid).first();
}

export async function liftLegalHold(env:Env,auth:CoreAuthContext,tenantId:string,holdId:string,grund:string){
  requireRole(auth,'tenant_admin');
  const text=clean(grund,2000);
  // Aufheben ist so begruendungspflichtig wie Verhaengen: danach darf wieder geloescht werden.
  if(text.length<20)throw new Error('HOLD_LIFT_REASON_REQUIRED');
  const ts=nowIso();
  const r=await env.DB.prepare("UPDATE legal_holds SET status='aufgehoben',aufgehoben_von=?,aufgehoben_am=?,aufhebungsgrund=?,updated_at=? WHERE id=? AND tenant_id=? AND status='aktiv'")
    .bind(auth.userId,ts,text,ts,holdId,tenantId).run();
  if(!r.meta?.changes)throw new Error('HOLD_NOT_FOUND');
  await audit(env.DB,auth.userId,'legal_hold.lifted',tenantId,undefined,'legal_hold',holdId);
  return{lifted:true};
}

export async function listLegalHolds(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return (await env.DB.prepare('SELECT h.*,v.display_name AS verhaengt_name FROM legal_holds h JOIN users v ON v.id=h.verhaengt_von WHERE h.tenant_id=? ORDER BY h.status,h.verhaengt_am DESC')
    .bind(tenantId).all()).results??[];
}

export type Sperrlage={gesperrt:boolean;gruende:{id:string;umfang:string;grund:string;aktenzeichen:string|null}[]};

/**
 * Gilt fuer diesen Gegenstand eine Sperre?
 *
 * Eine Abfrage fuer alle Sperren des Mandanten - nicht eine je Person. Bei einem Loeschlauf ueber
 * tausend Personen waere das sonst der Unterschied zwischen einer Abfrage und tausend.
 */
export async function sperrlage(env:Env,tenantId:string,bezuege:{umfang:string;bezug_id:string|null}[]):Promise<Map<string,Sperrlage>>{
  const sperren=(await env.DB.prepare("SELECT id,umfang,bezug_id,grund,aktenzeichen FROM legal_holds WHERE tenant_id=? AND status='aktiv'")
    .bind(tenantId).all<{id:string;umfang:string;bezug_id:string|null;grund:string;aktenzeichen:string|null}>()).results??[];
  const mandantweit=sperren.filter(s=>s.umfang==='mandant');
  const karte=new Map<string,Sperrlage>();
  for(const b of bezuege){
    const schluessel=`${b.umfang}:${b.bezug_id??''}`;
    const treffer=[...mandantweit,...sperren.filter(s=>s.umfang===b.umfang&&s.bezug_id===b.bezug_id)];
    karte.set(schluessel,{gesperrt:treffer.length>0,gruende:treffer.map(t=>({id:t.id,umfang:t.umfang,grund:t.grund,aktenzeichen:t.aktenzeichen}))});
  }
  return karte;
}

// ---------------------------------------------------------------------------
// Aufbewahrungsfristen
// ---------------------------------------------------------------------------

export async function saveRetentionPolicy(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const datenart=clean(input.datenart,80);
  if(!datenart)throw new Error('RETENTION_KIND_REQUIRED');
  const monate=Math.trunc(Number(input.aufbewahrung_monate));
  if(!Number.isFinite(monate)||monate<1||monate>1200)throw new Error('RETENTION_MONTHS_INVALID');
  const massnahme=clean(input.massnahme,40)||'loeschen';
  if(!MASSNAHMEN.includes(massnahme as never))throw new Error('RETENTION_ACTION_INVALID');
  const ts=nowIso();
  await env.DB.prepare('INSERT INTO retention_policies(id,tenant_id,datenart,aufbewahrung_monate,rechtsgrundlage,massnahme,aktiv,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,datenart) DO UPDATE SET aufbewahrung_monate=excluded.aufbewahrung_monate,rechtsgrundlage=excluded.rechtsgrundlage,massnahme=excluded.massnahme,aktiv=excluded.aktiv,updated_at=excluded.updated_at')
    .bind(id('ret_'),tenantId,datenart,monate,clean(input.rechtsgrundlage,500)||null,massnahme,input.aktiv===false?0:1,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'retention.policy_saved',tenantId,undefined,'retention_policy',datenart,{monate,massnahme});
  return env.DB.prepare('SELECT * FROM retention_policies WHERE tenant_id=? AND datenart=?').bind(tenantId,datenart).first();
}

/** Die Vorgaben einmalig anlegen, damit ein Traeger nicht bei null anfaengt. Vorhandene bleiben. */
export async function seedRetentionPolicies(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  const ts=nowIso();
  await env.DB.batch(Object.entries(FRIST_VORGABEN).map(([datenart,v])=>
    env.DB.prepare('INSERT INTO retention_policies(id,tenant_id,datenart,aufbewahrung_monate,rechtsgrundlage,massnahme,aktiv,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,1,?,?,?) ON CONFLICT(tenant_id,datenart) DO NOTHING')
      .bind(id('ret_'),tenantId,datenart,v.monate,v.grundlage,v.massnahme,auth.userId,ts,ts)));
  await audit(env.DB,auth.userId,'retention.seeded',tenantId,undefined,'tenant',tenantId,{anzahl:Object.keys(FRIST_VORGABEN).length});
  return listRetentionPolicies(env,auth,tenantId);
}

export async function listRetentionPolicies(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return (await env.DB.prepare('SELECT * FROM retention_policies WHERE tenant_id=? ORDER BY datenart').bind(tenantId).all()).results??[];
}

export type Faellig={datenart:string;massnahme:string;stichtag:string;bezug:{umfang:string;bezug_id:string|null};gesperrt:boolean;sperrgruende:string[]};

/**
 * Was waere faellig - und was davon haelt eine Sperre zurueck.
 *
 * Bewusst als VORSCHAU getrennt vom Vollzug. Ein Loeschlauf, den man nicht vorher ansehen kann,
 * ist im Ernstfall nicht zu verantworten; die Spec verlangt "Ausnahmen und Audit" ausdruecklich.
 */
export async function retentionPreview(env:Env,auth:CoreAuthContext,tenantId:string,bezuege:{umfang:string;bezug_id:string|null;datenart:string;entstanden_am:string}[],jetzt=nowIso()):Promise<{faellig:Faellig[];zurueckgehalten:number}>{
  requireRole(auth,'tenant_admin');
  const regeln=new Map(((await env.DB.prepare('SELECT datenart,aufbewahrung_monate,massnahme FROM retention_policies WHERE tenant_id=? AND aktiv=1').bind(tenantId).all<{datenart:string;aufbewahrung_monate:number;massnahme:string}>()).results??[]).map(r=>[r.datenart,r]));
  const karte=await sperrlage(env,tenantId,bezuege.map(b=>({umfang:b.umfang,bezug_id:b.bezug_id})));
  const faellig:Faellig[]=[];
  let zurueckgehalten=0;
  for(const b of bezuege){
    const regel=regeln.get(b.datenart);
    if(!regel)continue;
    const stichtag=new Date(b.entstanden_am);
    stichtag.setUTCMonth(stichtag.getUTCMonth()+Number(regel.aufbewahrung_monate));
    if(stichtag.toISOString()>jetzt)continue;
    const lage=karte.get(`${b.umfang}:${b.bezug_id??''}`)??{gesperrt:false,gruende:[]};
    if(lage.gesperrt)zurueckgehalten++;
    faellig.push({datenart:b.datenart,massnahme:String(regel.massnahme),stichtag:stichtag.toISOString(),
      bezug:{umfang:b.umfang,bezug_id:b.bezug_id},gesperrt:lage.gesperrt,
      sperrgruende:lage.gruende.map(g=>`${g.grund}${g.aktenzeichen?` (${g.aktenzeichen})`:''}`)});
  }
  return{faellig,zurueckgehalten};
}

/**
 * Der Lauf. Gibt zurueck, was zu behandeln ist - und haelt fest, was eine Sperre zurueckgehalten hat.
 *
 * Das Zweite ist das Wichtigere: es ist der Nachweis, dass die Sperre gewirkt hat. Ein Protokoll,
 * das nur die Loeschungen nennt, kann diesen Nachweis nicht fuehren.
 */
export async function runRetention(env:Env,auth:CoreAuthContext,tenantId:string,bezuege:{umfang:string;bezug_id:string|null;datenart:string;entstanden_am:string}[],jetzt=nowIso()){
  requireRole(auth,'tenant_admin');
  const {faellig,zurueckgehalten}=await retentionPreview(env,auth,tenantId,bezuege,jetzt);
  const zuBehandeln=faellig.filter(f=>!f.gesperrt);
  const lauf=id('retl_');
  await env.DB.prepare('INSERT INTO retention_runs(id,tenant_id,gestartet_am,beendet_am,geprueft,behandelt,wegen_sperre_uebersprungen,detail_json,ausgeloest_von) VALUES(?,?,?,?,?,?,?,?,?)')
    .bind(lauf,tenantId,jetzt,nowIso(),bezuege.length,zuBehandeln.length,zurueckgehalten,
      JSON.stringify({zurueckgehalten:faellig.filter(f=>f.gesperrt).map(f=>({datenart:f.datenart,bezug:f.bezug,gruende:f.sperrgruende}))}),auth.userId).run();
  await audit(env.DB,auth.userId,'retention.run',tenantId,undefined,'retention_run',lauf,{geprueft:bezuege.length,behandelt:zuBehandeln.length,gesperrt:zurueckgehalten});
  return{lauf,geprueft:bezuege.length,zu_behandeln:zuBehandeln,wegen_sperre_uebersprungen:zurueckgehalten};
}

// ---------------------------------------------------------------------------
// Einwilligungen
// ---------------------------------------------------------------------------

export async function saveConsentDefinition(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const schluessel=clean(input.schluessel,80),titel=clean(input.titel,200),zweck=clean(input.zweck,1000),text=clean(input.text,20000);
  if(!schluessel||!titel||!zweck||!text)throw new Error('CONSENT_DEFINITION_INCOMPLETE');
  // Aendert sich der Text, entsteht eine NEUE Fassung. Die alte bleibt stehen, weil die bereits
  // erteilten Einwilligungen auf sie zeigen - sonst waere nicht mehr nachweisbar, wozu jemand
  // zugestimmt hat.
  const letzte=await env.DB.prepare('SELECT MAX(fassung) f FROM consent_definitions WHERE tenant_id=? AND schluessel=?').bind(tenantId,schluessel).first<{f:number|null}>();
  const fassung=Number(letzte?.f||0)+1;
  const cid=id('einw_'),ts=nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE consent_definitions SET status='abgeloest',updated_at=? WHERE tenant_id=? AND schluessel=? AND status='aktiv'").bind(ts,tenantId,schluessel),
    env.DB.prepare('INSERT INTO consent_definitions(id,tenant_id,schluessel,titel,zweck,fassung,text,pflicht,sorgeberechtigt_noetig,gueltig_monate,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,\'aktiv\',?,?,?)')
      .bind(cid,tenantId,schluessel,titel,zweck,fassung,text,input.pflicht===true?1:0,input.sorgeberechtigt_noetig===true?1:0,
        input.gueltig_monate?Math.trunc(Number(input.gueltig_monate)):null,auth.userId,ts,ts),
  ]);
  await audit(env.DB,auth.userId,'consent.definition_saved',tenantId,undefined,'consent_definition',cid,{schluessel,fassung});
  return env.DB.prepare('SELECT * FROM consent_definitions WHERE id=?').bind(cid).first();
}

/**
 * Erklaeren. Die Fassung wird mitgeschrieben - wozu jemand zugestimmt hat, muss der Textaenderung
 * standhalten.
 */
export async function recordConsent(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const definitionId=clean(input.definition_id,120),entscheidung=clean(input.entscheidung,40);
  if(!['erteilt','abgelehnt','widerrufen'].includes(entscheidung))throw new Error('CONSENT_DECISION_INVALID');
  const d=await env.DB.prepare("SELECT * FROM consent_definitions WHERE id=? AND tenant_id=? AND status='aktiv'").bind(definitionId,tenantId).first<Record<string,unknown>>();
  if(!d)throw new Error('CONSENT_DEFINITION_NOT_FOUND');
  // Fuer wen erklaert wird: standardmaessig fuer sich selbst. Ein Sorgeberechtigter erklaert fuer
  // sein Kind - das darf nur, wer die gepruefte Verknuepfung hat.
  const fuer=clean(input.user_id,120)||auth.userId;
  let alsWer:'selbst'|'sorgeberechtigt'='selbst';
  if(fuer!==auth.userId){
    const {assertMuendel}=await import('./guardianship.js');
    await assertMuendel(env,auth,tenantId,fuer);
    alsWer='sorgeberechtigt';
  }
  // Eine Pflichteinwilligung, die eine sorgeberechtigte Erklaerung verlangt, kann das Kind nicht
  // selbst wirksam erteilen.
  if(Number(d.sorgeberechtigt_noetig)&&alsWer==='selbst'&&entscheidung==='erteilt')
    throw new Error('CONSENT_GUARDIAN_REQUIRED');
  const ts=nowIso();
  const bis=d.gueltig_monate?(()=>{const x=new Date(ts);x.setUTCMonth(x.getUTCMonth()+Number(d.gueltig_monate));return x.toISOString();})():null;
  const rid=id('einwr_');
  await env.DB.prepare('INSERT INTO consent_records(id,tenant_id,definition_id,user_id,erklaert_von,erklaert_als,entscheidung,erklaert_am,gueltig_bis,text_fassung,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
    .bind(rid,tenantId,definitionId,fuer,auth.userId,alsWer,entscheidung,ts,bis,Number(d.fassung),ts).run();
  await audit(env.DB,auth.userId,'consent.recorded',tenantId,undefined,'consent_record',rid,{entscheidung,als:alsWer});
  return env.DB.prepare('SELECT * FROM consent_records WHERE id=?').bind(rid).first();
}

/**
 * Der geltende Stand je Einwilligung - die jeweils JUENGSTE Erklaerung zaehlt.
 *
 * Abgelaufen gilt als nicht erteilt: eine Einwilligung mit Gueltigkeitsdauer, die niemand erneuert
 * hat, traegt nichts mehr.
 */
export async function consentStatus(env:Env,auth:CoreAuthContext,tenantId:string,userId:string,jetzt=nowIso()){
  if(userId!==auth.userId)requireRole(auth,'tenant_admin');
  // Die juengste Erklaerung wird ueber den SCHLUESSEL gesucht, nicht ueber die Fassung: jede neue
  // Fassung ist eine eigene Zeile mit eigener Kennung, und die alte Zustimmung zeigt auf die alte.
  // Wer hier auf die Kennung verbindet, findet nach jeder Textaenderung gar nichts mehr - und
  // haette dann nicht "veraltete Zustimmung", sondern "nie gefragt", was etwas anderes ist.
  const zeilen=(await env.DB.prepare("SELECT d.schluessel,d.titel,d.zweck,d.pflicht,d.fassung AS aktuelle_fassung,r.entscheidung,r.erklaert_am,r.erklaert_als,r.gueltig_bis,r.text_fassung,d.id AS definition_id FROM consent_definitions d LEFT JOIN consent_records r ON r.id=(SELECT x.id FROM consent_records x JOIN consent_definitions xd ON xd.id=x.definition_id WHERE xd.tenant_id=d.tenant_id AND xd.schluessel=d.schluessel AND x.user_id=? ORDER BY x.erklaert_am DESC,x.rowid DESC LIMIT 1) WHERE d.tenant_id=? AND d.status='aktiv' ORDER BY d.pflicht DESC,d.titel")
    .bind(userId,tenantId).all<Record<string,unknown>>()).results??[];
  return zeilen.map(z=>{
    const abgelaufen=!!z.gueltig_bis&&String(z.gueltig_bis)<jetzt;
    const veraltet=!!z.text_fassung&&Number(z.text_fassung)<Number(z.aktuelle_fassung);
    return{...z,abgelaufen,fassung_veraltet:veraltet,
      wirksam:z.entscheidung==='erteilt'&&!abgelaufen&&!veraltet};
  });
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Der Taeuschungsfall (P4).
//
// Ein Verdacht ist noch kein Verstoss. Und eine Entscheidung ohne Anhoerung ist formal fehlerhaft -
// sie faellt im Widerspruch, selbst wenn die Taeuschung tatsaechlich vorlag. Das ist der haeufigste
// Fehler in diesem Bereich, und er kostet den Traeger den ganzen Fall.
//
// Deshalb steht die Anhoerung hier als Pflichtschritt zwischen Verdacht und Entscheidung:
//  - Die betroffene Person erfaehrt, was ihr vorgeworfen wird, und bekommt eine Frist.
//  - Sie kann eine Stellungnahme abgeben - oder ausdruecklich verzichten, oder die Frist
//    verstreichen lassen. Alle drei sind zulaessige Ergebnisse; "gar nicht angeboten" ist keins.
//  - Erst danach wird entschieden, mit Begruendung und mit Hinweis auf den Rechtsbehelf.
//
// Die Beweise kommen aus dem, was ohnehin protokolliert wird: die Sicherheitsereignisse des
// gesperrten Browsers. Sie werden beim Eroeffnen des Falls FESTGEHALTEN, nicht spaeter
// nachgeladen - sonst waere nicht nachvollziehbar, worauf sich die Entscheidung stuetzte.

export const VERDACHTSARTEN=['taeuschung','unerlaubtes_hilfsmittel','identitaet','stoerung','plagiat'] as const;
export const QUELLEN=['sicherheitsereignis','aufsicht','plagiatspruefung','hinweis','nachkontrolle'] as const;
export const ENTSCHEIDUNGEN=['kein_verstoss','ermahnung','teilbewertung','nicht_bestanden','ausschluss'] as const;
// Die Frist zur Stellungnahme. Kurz genug fuer den Betrieb, lang genug, um jemanden zu fragen.
export const ANHOERUNG_TAGE=7;
const clean=(v:unknown,n=5000)=>safeString(v,n);

async function ladeFall(env:Env,tenantId:string,caseId:string){
  const f=await env.DB.prepare('SELECT * FROM exam_integrity_cases WHERE id=? AND tenant_id=?').bind(caseId,tenantId).first<Record<string,unknown>>();
  if(!f)throw new Error('INTEGRITAET_FALL_NICHT_GEFUNDEN');
  return f;
}

/**
 * Fall eroeffnen. Die Beweise werden JETZT festgehalten - was spaeter nachgeladen wuerde, koennte
 * nicht mehr die Grundlage der Entscheidung sein.
 */
export async function eroeffneIntegritaetsfall(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const quizId=clean(input.quiz_id,120),person=clean(input.betroffene_person,120);
  const attemptId=clean(input.attempt_id,120)||null;
  const verdacht=clean(input.verdacht,40),quelle=clean(input.quelle,40),sachverhalt=clean(input.sachverhalt,5000);
  if(!quizId||!person)throw new Error('INTEGRITAET_ANGABEN_UNVOLLSTAENDIG');
  if(!VERDACHTSARTEN.includes(verdacht as never))throw new Error('INTEGRITAET_VERDACHT_UNGUELTIG');
  if(!QUELLEN.includes(quelle as never))throw new Error('INTEGRITAET_QUELLE_UNGUELTIG');
  if(sachverhalt.length<20)throw new Error('INTEGRITAET_SACHVERHALT_ERFORDERLICH');
  const bogen=await env.DB.prepare('SELECT course_id FROM quizzes WHERE id=? AND tenant_id=?').bind(quizId,tenantId).first<{course_id:string}>();
  if(!bogen)throw new Error('PRUEFUNG_NICHT_GEFUNDEN');
  const ereignisse=attemptId
    ? ((await env.DB.prepare('SELECT event_type,request_path,created_at FROM quiz_attempt_security_events WHERE attempt_id=? ORDER BY created_at LIMIT 200').bind(attemptId).all()).results)??[]
    : [];
  const fallId=id('int_'),ts=nowIso();
  await env.DB.prepare('INSERT INTO exam_integrity_cases(id,tenant_id,quiz_id,attempt_id,betroffene_person,verdacht,quelle,sachverhalt,beweise_json,status,eroeffnet_von,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(fallId,tenantId,quizId,attemptId,person,verdacht,quelle,sachverhalt,JSON.stringify({sicherheitsereignisse:ereignisse}),'offen',auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'exam_integrity.opened',tenantId,bogen.course_id,'exam_integrity_case',fallId,{verdacht,quelle,beweise:ereignisse.length});
  return{id:fallId,beweise:ereignisse.length};
}

/**
 * Anhoerung anbieten. Ohne diesen Schritt gibt es keine Entscheidung - das ist die harte Regel
 * dieses Moduls.
 */
export async function biteZurAnhoerung(env:Env,auth:CoreAuthContext,tenantId:string,caseId:string,tage=ANHOERUNG_TAGE){
  requireRole(auth,'class_admin');
  const fall=await ladeFall(env,tenantId,caseId);
  if(String(fall.status)!=='offen')throw new Error('INTEGRITAET_STATUS_UNPASSEND');
  const t=Math.max(1,Math.min(30,Math.trunc(Number(tage)||ANHOERUNG_TAGE)));
  const ts=nowIso(),frist=new Date(Date.parse(ts)+t*864e5).toISOString();
  await env.DB.batch([
    env.DB.prepare("UPDATE exam_integrity_cases SET status='anhoerung',anhoerung_angeboten_am=?,anhoerung_frist_am=?,updated_at=? WHERE id=? AND tenant_id=?").bind(ts,frist,ts,caseId,tenantId),
    env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'exam_integrity_hearing',?,?,?)")
      .bind(id('ntf_'),tenantId,String(fall.betroffene_person),'Prüfung: Gelegenheit zur Stellungnahme',`Zu einem Prüfungsvorgang liegt ein Verdacht vor. Sie können bis zum ${frist} Stellung nehmen.`,ts),
  ]);
  await audit(env.DB,auth.userId,'exam_integrity.hearing_offered',tenantId,undefined,'exam_integrity_case',caseId,{frist});
  return{frist_am:frist};
}

/** Die betroffene Person sieht ihren eigenen Fall - Vorwurf, Beweise, Frist. */
export async function meinIntegritaetsfall(env:Env,auth:CoreAuthContext,tenantId:string,caseId:string){
  const fall=await ladeFall(env,tenantId,caseId);
  if(String(fall.betroffene_person)!==auth.userId)throw new Error('INTEGRITAET_KEINE_EINSICHT');
  // Wer sich aeussern soll, muss wissen, wozu. Deshalb gehen Sachverhalt UND Beweise heraus - alles
  // andere waere eine Anhoerung dem Namen nach.
  return{id:fall.id,verdacht:fall.verdacht,quelle:fall.quelle,sachverhalt:fall.sachverhalt,beweise:fall.beweise_json,
    status:fall.status,anhoerung_frist_am:fall.anhoerung_frist_am,stellungnahme:fall.stellungnahme,
    entscheidung:fall.entscheidung,entscheidung_begruendung:fall.entscheidung_begruendung};
}

export async function gibStellungnahmeAb(env:Env,auth:CoreAuthContext,tenantId:string,caseId:string,text:unknown){
  const fall=await ladeFall(env,tenantId,caseId);
  if(String(fall.betroffene_person)!==auth.userId)throw new Error('INTEGRITAET_KEINE_EINSICHT');
  if(String(fall.status)!=='anhoerung')throw new Error('INTEGRITAET_KEINE_ANHOERUNG');
  if(fall.stellungnahme)throw new Error('INTEGRITAET_STELLUNGNAHME_VORHANDEN');
  const inhalt=clean(text,5000);
  if(inhalt.length<5)throw new Error('INTEGRITAET_STELLUNGNAHME_LEER');
  const ts=nowIso();
  await env.DB.prepare("UPDATE exam_integrity_cases SET stellungnahme=?,stellungnahme_am=?,anhoerung_ergebnis='stellungnahme',updated_at=? WHERE id=? AND tenant_id=?")
    .bind(inhalt,ts,ts,caseId,tenantId).run();
  return{abgegeben_am:ts};
}

/** Ausdruecklicher Verzicht - auch das ist ein Ergebnis der Anhoerung und wird festgehalten. */
export async function verzichteAufAnhoerung(env:Env,auth:CoreAuthContext,tenantId:string,caseId:string){
  const fall=await ladeFall(env,tenantId,caseId);
  if(String(fall.betroffene_person)!==auth.userId)throw new Error('INTEGRITAET_KEINE_EINSICHT');
  if(String(fall.status)!=='anhoerung')throw new Error('INTEGRITAET_KEINE_ANHOERUNG');
  await env.DB.prepare("UPDATE exam_integrity_cases SET anhoerung_ergebnis='verzichtet',updated_at=? WHERE id=? AND tenant_id=?").bind(nowIso(),caseId,tenantId).run();
  return{verzichtet:true};
}

/**
 * Entscheiden.
 *
 * Geht nur, wenn die Anhoerung stattgefunden hat ODER ihre Frist abgelaufen ist. Die verstrichene
 * Frist wird dabei ausdruecklich als 'nicht_wahrgenommen' festgehalten - im Widerspruchsverfahren
 * ist genau das die Frage: Wurde die Person gehoert, und wenn nein, warum nicht?
 */
export async function entscheideIntegritaetsfall(env:Env,auth:CoreAuthContext,tenantId:string,caseId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const fall=await ladeFall(env,tenantId,caseId);
  if(['entschieden','eingestellt'].includes(String(fall.status)))throw new Error('INTEGRITAET_BEREITS_ENTSCHIEDEN');
  const entscheidung=clean(input.entscheidung,40),begruendung=clean(input.begruendung,5000);
  if(!ENTSCHEIDUNGEN.includes(entscheidung as never))throw new Error('INTEGRITAET_ENTSCHEIDUNG_UNGUELTIG');
  if(begruendung.length<20)throw new Error('INTEGRITAET_BEGRUENDUNG_ERFORDERLICH');
  if(String(fall.status)!=='anhoerung')throw new Error('INTEGRITAET_ANHOERUNG_ERFORDERLICH');
  const ts=nowIso();
  const gehoert=!!fall.stellungnahme||fall.anhoerung_ergebnis==='verzichtet';
  const fristAb=fall.anhoerung_frist_am?Date.parse(String(fall.anhoerung_frist_am))<=Date.parse(ts):false;
  if(!gehoert&&!fristAb)throw new Error('INTEGRITAET_ANHOERUNGSFRIST_LAEUFT');
  const ergebnis=fall.anhoerung_ergebnis??(gehoert?'stellungnahme':'nicht_wahrgenommen');
  const status=entscheidung==='kein_verstoss'?'eingestellt':'entschieden';
  await env.DB.batch([
    env.DB.prepare('UPDATE exam_integrity_cases SET status=?,entscheidung=?,entscheidung_begruendung=?,entschieden_von=?,entschieden_am=?,anhoerung_ergebnis=?,updated_at=? WHERE id=? AND tenant_id=?')
      .bind(status,entscheidung,begruendung,auth.userId,ts,ergebnis,ts,caseId,tenantId),
    env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'exam_integrity_decision',?,?,?)")
      .bind(id('ntf_'),tenantId,String(fall.betroffene_person),'Prüfung: Entscheidung',`Es wurde entschieden. Die Begründung steht in Ihrem Vorgang; gegen die Entscheidung können Sie Einspruch einlegen.`,ts),
  ]);
  await audit(env.DB,auth.userId,'exam_integrity.decided',tenantId,undefined,'exam_integrity_case',caseId,{entscheidung,anhoerung:ergebnis});
  // Der Hinweis auf den Rechtsbehelf gehoert zur Entscheidung, nicht in eine Fussnote.
  return{status,entscheidung,anhoerung_ergebnis:ergebnis,rechtsbehelf:'Gegen diese Entscheidung kann Einspruch eingelegt werden.'};
}

export async function listeIntegritaetsfaelle(env:Env,auth:CoreAuthContext,tenantId:string,nurOffen=true){
  requireRole(auth,'class_admin');
  const sql=nurOffen
    ? "SELECT id,quiz_id,attempt_id,betroffene_person,verdacht,quelle,status,anhoerung_frist_am,created_at FROM exam_integrity_cases WHERE tenant_id=? AND status IN ('offen','anhoerung') ORDER BY created_at"
    : 'SELECT id,quiz_id,attempt_id,betroffene_person,verdacht,quelle,status,entscheidung,anhoerung_ergebnis,created_at FROM exam_integrity_cases WHERE tenant_id=? ORDER BY created_at DESC LIMIT 200';
  return ((await env.DB.prepare(sql).bind(tenantId).all()).results)??[];
}

export async function integritaetsfallLesen(env:Env,auth:CoreAuthContext,tenantId:string,caseId:string){
  requireRole(auth,'class_admin');
  return{fall:await ladeFall(env,tenantId,caseId)};
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Kinderschutz.
//
// Drei Dinge entscheiden, ob so ein Modul im Ernstfall etwas taugt - und alle drei sind
// Einschraenkungen, nicht Funktionen:
//
//  1. Einsicht haben BENANNTE Fachkraefte, nicht "die Verwaltung". Wer Verwaltungsrechte hat, sieht
//     hier nichts. Das ist kein Versehen: die Meldung kann sich gegen jemanden aus der Verwaltung
//     richten, und solange das moeglich ist, meldet niemand.
//  2. Wer selbst betroffen oder gemeldet ist, sieht seinen eigenen Fall nicht - auch als Fachkraft
//     nicht. Befangenheit wird nicht erklaert, sie wird ausgeschlossen.
//  3. Eine Frist laeuft, ob jemand hinsieht oder nicht. Ein Verdacht, der vier Wochen in einem
//     Postfach liegt, ist im Ergebnis dasselbe wie kein Verdacht.
//
// Der Verlauf ist nur anzuhaengen. Eine Akte, aus der sich Eintraege entfernen lassen, ist bei
// einer Anhoerung wertlos.

export const KATEGORIEN=['vernachlaessigung','koerperliche_gewalt','sexualisierte_gewalt','selbstgefaehrdung','mobbing','sonstiges'] as const;
export const DRINGLICHKEITEN=['akut','hoch','normal'] as const;
// Stunden bis zur Frist. 'akut' heisst heute - nicht "demnaechst".
export const FRIST_STUNDEN:Record<string,number>={akut:4,hoch:24,normal:72};
const clean=(v:unknown,n=5000)=>safeString(v,n);

export type Fall={id:string;tenant_id:string;betroffene_person:string|null;gemeldet_von:string;status:string;dringlichkeit:string;frist_am:string;zugewiesen_an:string|null};

/** Die aktiven Fachkraefte eines Mandanten. Eine Abfrage, auch wenn danach zwanzig Faelle folgen. */
export async function listeFachkraefte(env:Env,tenantId:string):Promise<{user_id:string;rolle:string}[]>{
  return ((await env.DB.prepare("SELECT user_id,rolle FROM safeguarding_officers WHERE tenant_id=? AND aktiv=1 ORDER BY rolle,user_id").bind(tenantId).all<{user_id:string;rolle:string}>()).results)??[];
}

export async function benenneFachkraft(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const person=clean(input.user_id,120),rolle=clean(input.rolle,40)||'fachkraft';
  if(!person)throw new Error('SAFEGUARDING_PERSON_REQUIRED');
  if(!['fachkraft','stellvertretung','externe_stelle'].includes(rolle))throw new Error('SAFEGUARDING_ROLLE_UNGUELTIG');
  const mitglied=await env.DB.prepare("SELECT 1 AS ok FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'").bind(tenantId,person).first();
  if(!mitglied)throw new Error('SAFEGUARDING_PERSON_NOT_FOUND');
  const ts=nowIso();
  await env.DB.prepare('INSERT INTO safeguarding_officers(id,tenant_id,user_id,rolle,benannt_von,benannt_am,aktiv,updated_at) VALUES(?,?,?,?,?,?,1,?) ON CONFLICT(tenant_id,user_id) DO UPDATE SET rolle=excluded.rolle,aktiv=1,beendet_am=NULL,updated_at=excluded.updated_at')
    .bind(id('sgo_'),tenantId,person,rolle,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'safeguarding.officer_named',tenantId,undefined,'safeguarding_officer',person,{rolle});
  return{benannt:true};
}

export async function entzieheFachkraft(env:Env,auth:CoreAuthContext,tenantId:string,userId:string){
  requireRole(auth,'tenant_admin');
  const ts=nowIso();
  const r=await env.DB.prepare('UPDATE safeguarding_officers SET aktiv=0,beendet_am=?,updated_at=? WHERE tenant_id=? AND user_id=? AND aktiv=1').bind(ts,ts,tenantId,userId).run();
  if(!r.meta?.changes)throw new Error('SAFEGUARDING_FACHKRAFT_NOT_FOUND');
  await audit(env.DB,auth.userId,'safeguarding.officer_removed',tenantId,undefined,'safeguarding_officer',userId);
  return{beendet:true};
}

/**
 * Darf diese Person diesen Fall sehen?
 *
 * Fail closed, und die Befangenheit schlaegt die Benennung: wer betroffen oder gemeldet ist, sieht
 * den Fall nicht - auch als Fachkraft nicht, und auch nicht als Mandanten-Admin.
 */
async function assertEinsicht(env:Env,auth:CoreAuthContext,tenantId:string,fall:Fall):Promise<'fachkraft'|'melder'>{
  if(fall.betroffene_person===auth.userId)throw new Error('SAFEGUARDING_BEFANGEN');
  const fachkraefte=await listeFachkraefte(env,tenantId);
  const istFachkraft=fachkraefte.some(f=>f.user_id===auth.userId);
  // Die meldende Person sieht ihren eigenen Fall - sonst weiss sie nie, ob etwas geschehen ist.
  // Aber nur ihn, und ohne den Verlauf der Fachkraefte zu steuern.
  if(fall.gemeldet_von===auth.userId&&!istFachkraft)return 'melder';
  if(!istFachkraft)throw new Error('SAFEGUARDING_KEINE_EINSICHT');
  return 'fachkraft';
}

async function ladeFall(env:Env,tenantId:string,reportId:string):Promise<Fall>{
  const f=await env.DB.prepare('SELECT id,tenant_id,betroffene_person,gemeldet_von,status,dringlichkeit,frist_am,zugewiesen_an FROM safeguarding_reports WHERE id=? AND tenant_id=?').bind(reportId,tenantId).first<Fall>();
  if(!f)throw new Error('SAFEGUARDING_FALL_NOT_FOUND');
  return f;
}

/**
 * Melden darf jeder, der zum Mandanten gehoert - ohne Rolle, ohne Zustimmung, ohne Vorpruefung.
 * Eine Meldeschwelle waere genau die Huerde, an der solche Faelle liegen bleiben.
 */
export async function meldeSachverhalt(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const kategorie=clean(input.kategorie,40),dringlichkeit=clean(input.dringlichkeit,20)||'normal';
  const sachverhalt=clean(input.sachverhalt,5000),betroffen=clean(input.betroffene_person,120)||null;
  if(!KATEGORIEN.includes(kategorie as never))throw new Error('SAFEGUARDING_KATEGORIE_UNGUELTIG');
  if(!DRINGLICHKEITEN.includes(dringlichkeit as never))throw new Error('SAFEGUARDING_DRINGLICHKEIT_UNGUELTIG');
  if(sachverhalt.length<20)throw new Error('SAFEGUARDING_SACHVERHALT_ERFORDERLICH');
  const jetzt=new Date(),ts=jetzt.toISOString(),fallId=id('sgr_');
  const frist=new Date(jetzt.getTime()+FRIST_STUNDEN[dringlichkeit]*36e5).toISOString();
  const fachkraefte=await listeFachkraefte(env,tenantId);
  // Befangene Fachkraefte werden gar nicht erst benachrichtigt: die Meldung kann sie betreffen.
  const zuBenachrichtigen=fachkraefte.filter(f=>f.user_id!==betroffen);
  const anweisungen=[env.DB.prepare('INSERT INTO safeguarding_reports(id,tenant_id,betroffene_person,gemeldet_von,kategorie,dringlichkeit,sachverhalt,status,frist_am,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
    .bind(fallId,tenantId,betroffen,auth.userId,kategorie,dringlichkeit,sachverhalt,'offen',frist,ts,ts)];
  for(const f of zuBenachrichtigen)anweisungen.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'safeguarding_report',?,?,?)")
    .bind(id('ntf_'),tenantId,f.user_id,dringlichkeit==='akut'?'Kinderschutz: akute Meldung':'Kinderschutz: neue Meldung',`Es liegt eine Meldung vor. Frist zur Bearbeitung: ${frist}.`,ts));
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'safeguarding.reported',tenantId,undefined,'safeguarding_report',fallId,{kategorie,dringlichkeit,benachrichtigt:zuBenachrichtigen.length});
  // Der Sachverhalt steht bewusst NICHT im Protokoll: es sieht mehr Menschen als der Fall.
  return{id:fallId,frist_am:frist,benachrichtigt:zuBenachrichtigen.length,ohne_fachkraft:fachkraefte.length===0};
}

export async function meineMeldungen(env:Env,auth:CoreAuthContext,tenantId:string){
  return ((await env.DB.prepare('SELECT id,kategorie,dringlichkeit,status,frist_am,created_at,abgeschlossen_am FROM safeguarding_reports WHERE tenant_id=? AND gemeldet_von=? ORDER BY created_at DESC LIMIT 100')
    .bind(tenantId,auth.userId).all()).results)??[];
}

export async function offeneFaelle(env:Env,auth:CoreAuthContext,tenantId:string){
  const fachkraefte=await listeFachkraefte(env,tenantId);
  if(!fachkraefte.some(f=>f.user_id===auth.userId))throw new Error('SAFEGUARDING_KEINE_EINSICHT');
  return ((await env.DB.prepare("SELECT id,betroffene_person,gemeldet_von,kategorie,dringlichkeit,status,frist_am,zugewiesen_an,created_at FROM safeguarding_reports WHERE tenant_id=? AND status<>'abgeschlossen' AND COALESCE(betroffene_person,'')<>? ORDER BY CASE dringlichkeit WHEN 'akut' THEN 1 WHEN 'hoch' THEN 2 ELSE 3 END,frist_am")
    .bind(tenantId,auth.userId).all()).results)??[];
}

export async function fallLesen(env:Env,auth:CoreAuthContext,tenantId:string,reportId:string){
  const fall=await ladeFall(env,tenantId,reportId);
  const sicht=await assertEinsicht(env,auth,tenantId,fall);
  const voll=await env.DB.prepare('SELECT * FROM safeguarding_reports WHERE id=?').bind(reportId).first<Record<string,unknown>>();
  if(sicht==='melder')return{fall:{id:voll?.id,kategorie:voll?.kategorie,dringlichkeit:voll?.dringlichkeit,status:voll?.status,frist_am:voll?.frist_am,created_at:voll?.created_at},verlauf:[],sicht};
  const verlauf=((await env.DB.prepare('SELECT id,verfasst_von,art,text,erfasst_am FROM safeguarding_notes WHERE report_id=? ORDER BY erfasst_am').bind(reportId).all()).results)??[];
  return{fall:voll,verlauf,sicht};
}

export async function notizHinzufuegen(env:Env,auth:CoreAuthContext,tenantId:string,reportId:string,input:Record<string,unknown>){
  const fall=await ladeFall(env,tenantId,reportId);
  if(await assertEinsicht(env,auth,tenantId,fall)!=='fachkraft')throw new Error('SAFEGUARDING_KEINE_EINSICHT');
  const text=clean(input.text,5000),art=clean(input.art,20)||'notiz';
  if(!['notiz','gespraech','massnahme'].includes(art))throw new Error('SAFEGUARDING_NOTIZART_UNGUELTIG');
  if(text.length<3)throw new Error('SAFEGUARDING_NOTIZ_LEER');
  await env.DB.prepare('INSERT INTO safeguarding_notes(id,tenant_id,report_id,verfasst_von,art,text,erfasst_am) VALUES(?,?,?,?,?,?,?)')
    .bind(id('sgn_'),tenantId,reportId,auth.userId,art,text,nowIso()).run();
  return{gespeichert:true};
}

/**
 * Zustand aendern. Jeder Wechsel schreibt seinen eigenen Verlaufseintrag - im selben Stapel, damit
 * kein Zustand ohne Begruendung im System stehen kann.
 */
export async function setzeFallstatus(env:Env,auth:CoreAuthContext,tenantId:string,reportId:string,input:Record<string,unknown>){
  const fall=await ladeFall(env,tenantId,reportId);
  if(await assertEinsicht(env,auth,tenantId,fall)!=='fachkraft')throw new Error('SAFEGUARDING_KEINE_EINSICHT');
  const status=clean(input.status,30),grund=clean(input.grund,2000);
  if(!['in_bearbeitung','eskaliert','abgeschlossen'].includes(status))throw new Error('SAFEGUARDING_STATUS_UNGUELTIG');
  if(fall.status==='abgeschlossen')throw new Error('SAFEGUARDING_FALL_ABGESCHLOSSEN');
  const ts=nowIso();
  const anweisungen=[];
  if(status==='eskaliert'){
    const stelle=clean(input.eskaliert_an,200);
    // Eskalieren heisst: an eine benannte Stelle ausserhalb. "Irgendwohin gemeldet" ist kein Nachweis.
    if(!stelle)throw new Error('SAFEGUARDING_ESKALATIONSZIEL_ERFORDERLICH');
    if(grund.length<10)throw new Error('SAFEGUARDING_GRUND_ERFORDERLICH');
    anweisungen.push(env.DB.prepare("UPDATE safeguarding_reports SET status='eskaliert',eskaliert_an=?,eskaliert_am=?,eskalationsgrund=?,zugewiesen_an=COALESCE(zugewiesen_an,?),updated_at=? WHERE id=? AND tenant_id=?")
      .bind(stelle,ts,grund,auth.userId,ts,reportId,tenantId));
    anweisungen.push(env.DB.prepare("INSERT INTO safeguarding_notes(id,tenant_id,report_id,verfasst_von,art,text,erfasst_am) VALUES(?,?,?,?,'eskalation',?,?)")
      .bind(id('sgn_'),tenantId,reportId,auth.userId,`Eskaliert an ${stelle}: ${grund}`,ts));
  }else if(status==='abgeschlossen'){
    if(grund.length<10)throw new Error('SAFEGUARDING_GRUND_ERFORDERLICH');
    anweisungen.push(env.DB.prepare("UPDATE safeguarding_reports SET status='abgeschlossen',abgeschlossen_am=?,ergebnis=?,updated_at=? WHERE id=? AND tenant_id=?").bind(ts,grund,ts,reportId,tenantId));
    anweisungen.push(env.DB.prepare("INSERT INTO safeguarding_notes(id,tenant_id,report_id,verfasst_von,art,text,erfasst_am) VALUES(?,?,?,?,'statuswechsel',?,?)")
      .bind(id('sgn_'),tenantId,reportId,auth.userId,`Abgeschlossen: ${grund}`,ts));
  }else{
    anweisungen.push(env.DB.prepare("UPDATE safeguarding_reports SET status='in_bearbeitung',zugewiesen_an=COALESCE(zugewiesen_an,?),updated_at=? WHERE id=? AND tenant_id=?").bind(auth.userId,ts,reportId,tenantId));
    anweisungen.push(env.DB.prepare("INSERT INTO safeguarding_notes(id,tenant_id,report_id,verfasst_von,art,text,erfasst_am) VALUES(?,?,?,?,'statuswechsel',?,?)")
      .bind(id('sgn_'),tenantId,reportId,auth.userId,grund||'In Bearbeitung genommen.',ts));
  }
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,`safeguarding.${status}`,tenantId,undefined,'safeguarding_report',reportId);
  return{status};
}

/**
 * Ueberfaellige Faelle - fuer den zeitgesteuerten Lauf.
 *
 * Eine Frist, die niemand prueft, ist keine Frist. Erinnert wird hoechstens einmal je Stunde und
 * nur die benannten Fachkraefte; ein ueberfaelliger Fall bleibt ueberfaellig, bis er bearbeitet
 * ist - er verschwindet nicht aus der Liste, nur weil schon erinnert wurde.
 */
export async function faelligeFaelle(env:Env,grenze=20,jetzt=nowIso()){
  // Eskaliert ist NICHT erledigt. Ein Fall, der an das Jugendamt gegeben wurde, bleibt in der
  // Verantwortung des Traegers, bis er mit Ergebnis abgeschlossen ist - sonst waere das Eskalieren
  // der bequemste Weg, ihn aus der Liste zu bekommen.
  return ((await env.DB.prepare("SELECT id,tenant_id,dringlichkeit,frist_am FROM safeguarding_reports WHERE status<>'abgeschlossen' AND frist_am<=? ORDER BY frist_am LIMIT ?")
    .bind(jetzt,Math.max(1,Math.min(100,grenze))).all<{id:string;tenant_id:string;dringlichkeit:string;frist_am:string}>()).results)??[];
}

export async function erinnereAnFaelligeFaelle(env:Env,grenze=20,jetzt=nowIso()):Promise<{erinnert:number;faelle:number}>{
  const faelle=await faelligeFaelle(env,grenze,jetzt);
  if(!faelle.length)return{erinnert:0,faelle:0};
  const jeMandant=new Map<string,{id:string;dringlichkeit:string}[]>();
  for(const f of faelle){const liste=jeMandant.get(f.tenant_id)??[];liste.push({id:f.id,dringlichkeit:f.dringlichkeit});jeMandant.set(f.tenant_id,liste);}
  const anweisungen=[];let erinnert=0;
  for(const [tenantId,liste] of jeMandant){
    for(const f of await listeFachkraefte(env,tenantId)){
      anweisungen.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'safeguarding_overdue',?,?,?)")
        .bind(id('ntf_'),tenantId,f.user_id,'Kinderschutz: Frist überschritten',`${liste.length} Meldung(en) sind über ihre Frist hinaus offen.`,jetzt));
      erinnert++;
    }
  }
  if(anweisungen.length)await env.DB.batch(anweisungen);
  return{erinnert,faelle:faelle.length};
}

// Rechtsnachfolge: einen Traeger uebergeben, statt ihn nur loeschen zu koennen.
//
// Ein Bildungstraeger verschwindet selten sauber. Er wird uebernommen, verschmilzt, wird
// aufgeloest - und ein anderer fuehrt die laufenden Kurse zu Ende. Bisher kannte das System dafuer
// nur Vertragsende und Loeschen. Wer uebernehmen wollte, musste exportieren und beim Nachfolger neu
// einspielen. Damit riss die Anwesenheitshistorie, die Zeugnisse verloren ihren Bezug, und die
// Teilnehmenden waren beim Nachfolger neue Personen ohne Vergangenheit. Fuer eine laufende
// Umschulung ist das nicht hinnehmbar: sie dauert zwei Jahre und muss lueckenlos nachweisbar sein.
//
// Drei Faelle:
//   inhaberwechsel - derselbe Betrieb, neuer Inhaber. Es zieht nichts um, nur die Verantwortung
//                    wechselt und wird nachweisbar festgehalten.
//   uebergang      - ausgewaehlte Kurse ziehen mit allem, was an ihnen haengt, zu einem anderen
//                    Traeger im selben Portal.
//   aufloesung     - der Traeger endet, ein Nachfolger ausserhalb des Portals uebernimmt. Es zieht
//                    nichts um; festgehalten wird, wer ab wann zustaendig ist.
//
// Zwei Dinge sind unverhandelbar:
//  1. Der Nachweis ueberlebt den Vorgaenger. Die Nachfolge steht ohne Fremdschluessel und mit
//     eingefrorenem Namen in der Datenbank - wird der Vorgaenger spaeter geloescht, bleibt
//     nachvollziehbar, wer ein Zeugnis ausgestellt hat und wer es heute fortfuehrt.
//  2. Es zieht ALLES um oder nichts. Die Tabellen, die ein Kurs beruehrt, werden zur Laufzeit aus
//     dem echten Schema bestimmt, nicht aus einer gepflegten Liste. Was nicht ausdruecklich
//     zurueckbleiben darf, zieht mit - und nach dem Umzug wird nachgezaehlt.
import type { Env, CoreAuthContext } from './types.js';
import { requirePlatform } from './permissions.js';
import { audit } from './audit.js';
import { id, nowIso } from './utils.js';

// Was ausdruecklich beim Vorgaenger bleibt, mit Begruendung. Alles andere zieht mit. Die Richtung
// ist Absicht: eine vergessene Tabelle bleibt dann nicht heimlich zurueck, sondern zieht um.
export const BLEIBT_BEIM_VORGAENGER: Record<string, string> = {
  // Das Protokoll dokumentiert, wer unter der Verantwortung des VORGAENGERS was getan hat.
  // Wuerde es mitziehen, waeren dessen Handlungen dem Nachfolger zugeschrieben.
  audit_log: 'Protokoll der Handlungen des Vorgaengers - Zuschreibung darf nicht wechseln.',
  // Offene Forderungen und Zahlungen gehoeren dem, der die Leistung abgerechnet hat. Wer sie
  // uebernimmt, regelt der Vertrag, nicht die Datenbank.
  participant_receivables: 'Forderungen gehoeren dem, der abgerechnet hat.',
  course_fee_collections: 'Eingesammelte Betraege gehoeren dem, der sie eingesammelt hat.',
  participant_fee_plans: 'Zahlungsplaene haengen an der Forderung, nicht am Kurs.',
  // Halbfertige Einspielungen sind Arbeitsstand, kein Bestand.
  participant_import_batches: 'Arbeitsstand einer Einspielung, kein Bestand.',
  participant_import_results: 'Arbeitsstand einer Einspielung, kein Bestand.',
  legacy_import_batches: 'Arbeitsstand einer Einspielung, kein Bestand.',
  timetable_import_lessons: 'Arbeitsstand einer Einspielung, kein Bestand.',
  microsoft_oauth_states: 'Kurzlebiger Anmeldezustand, gehoert niemandem.',
};

// Welche Tabellen ein Kurs beruehrt, steht im Schema - nicht in einer Liste, die jemand pflegen
// muesste. Eine neue Tabelle mit tenant_id und course_id zieht dadurch automatisch mit.
export async function umzugstabellen(env: Env): Promise<string[]> {
  // Eine einzige Abfrage: die Plattform zaehlt Unteranfragen (1000 je Aufruf), und ein PRAGMA je
  // Tabelle waere bei rund 200 Tabellen ein Fuenftel des Budgets, bevor der erste Kurs zieht.
  const tabellen = ((await env.DB.prepare("SELECT name,sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all<{ name: string; sql: string | null }>()).results) ?? [];
  return tabellen
    .filter(t => !BLEIBT_BEIM_VORGAENGER[t.name] && /\btenant_id\b/.test(t.sql || '') && /\bcourse_id\b/.test(t.sql || ''))
    .map(t => t.name);
}

async function mandant(env: Env, tenantId: string) {
  const t = await env.DB.prepare('SELECT id,name,slug,status FROM tenants WHERE id=?').bind(tenantId).first<{ id: string; name: string; slug: string; status: string }>();
  if (!t) throw new Error('SUCCESSION_TENANT_NOT_FOUND');
  return t;
}

export async function planeNachfolge(env: Env, auth: CoreAuthContext, input: Record<string, unknown>) {
  requirePlatform(auth);
  const art = String(input.kind || '');
  if (!['inhaberwechsel', 'uebergang', 'aufloesung'].includes(art)) throw new Error('SUCCESSION_KIND_INVALID');
  const stichtag = String(input.effective_on || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(stichtag)) throw new Error('SUCCESSION_EFFECTIVE_DATE_INVALID');
  const vorgaenger = await mandant(env, String(input.predecessor_tenant_id || ''));

  let nachfolgerId: string | null = null, nachfolgerName = String(input.successor_name || '').trim();
  if (input.successor_tenant_id) {
    const n = await mandant(env, String(input.successor_tenant_id));
    if (n.id === vorgaenger.id) throw new Error('SUCCESSION_SAME_TENANT');
    nachfolgerId = n.id; nachfolgerName = nachfolgerName || n.name;
  }
  // Ein Uebergang braucht einen Nachfolger IM Portal - sonst gibt es kein Ziel, in das Kurse
  // ziehen koennten. Aufloesung und Inhaberwechsel duerfen nach aussen zeigen.
  if (art === 'uebergang' && !nachfolgerId) throw new Error('SUCCESSION_SUCCESSOR_REQUIRED');
  if (!nachfolgerName) throw new Error('SUCCESSION_SUCCESSOR_NAME_REQUIRED');

  const gewuenscht = Array.isArray(input.course_ids) ? input.course_ids.map(String) : [];
  let kurse: Array<{ id: string; name: string }> = [];
  if (art === 'uebergang') {
    const alle = ((await env.DB.prepare('SELECT id,name FROM courses WHERE tenant_id=? ORDER BY name').bind(vorgaenger.id).all<{ id: string; name: string }>()).results) ?? [];
    kurse = gewuenscht.length ? alle.filter(k => gewuenscht.includes(k.id)) : alle;
    if (!kurse.length) throw new Error('SUCCESSION_NO_COURSES');
    // Eine genannte, aber nicht gefundene Kennung ist ein Irrtum des Aufrufers - nicht stillschweigend
    // weniger uebergeben als beauftragt.
    if (gewuenscht.length && kurse.length !== gewuenscht.length) throw new Error('SUCCESSION_COURSE_NOT_FOUND');
  }

  const sid = id('succ_'), ts = nowIso();
  await env.DB.prepare('INSERT INTO tenant_successions (id,predecessor_tenant_id,predecessor_name,predecessor_slug,successor_tenant_id,successor_name,kind,effective_on,legal_basis,status,courses_total,courses_done,created_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,0,?,?,?)')
    .bind(sid, vorgaenger.id, vorgaenger.name, vorgaenger.slug, nachfolgerId, nachfolgerName, art, stichtag, input.legal_basis ? String(input.legal_basis).slice(0, 500) : null, kurse.length ? 'vorbereitet' : 'abgeschlossen', kurse.length, auth.userId, ts, ts).run();
  if (!kurse.length) await env.DB.prepare('UPDATE tenant_successions SET completed_at=? WHERE id=?').bind(ts, sid).run();
  else await env.DB.batch(kurse.map(k => env.DB.prepare('INSERT INTO tenant_succession_courses (succession_id,course_id,course_name) VALUES (?,?,?)').bind(sid, k.id, k.name)));
  await audit(env.DB, auth.userId, 'succession.planned', vorgaenger.id, undefined, 'tenant_succession', sid, { kind: art, courses: kurse.length });
  return { succession_id: sid, kind: art, courses_total: kurse.length, status: kurse.length ? 'vorbereitet' : 'abgeschlossen' };
}

// Der Umzug laeuft in Haeppchen - die Plattform zaehlt Unteranfragen, und ein Traeger kann Hunderte
// Kurse haben. Der Aufruf meldet completed=false, solange noch Kurse offen sind.
export async function fuehreNachfolgeFort(env: Env, auth: CoreAuthContext, successionId: string, maxKurse = 5) {
  requirePlatform(auth);
  const s = await env.DB.prepare('SELECT * FROM tenant_successions WHERE id=?').bind(successionId).first<Record<string, unknown>>();
  if (!s) throw new Error('SUCCESSION_NOT_FOUND');
  if (s.status === 'abgebrochen') throw new Error('SUCCESSION_CANCELLED');
  if (s.status === 'abgeschlossen') return { succession_id: successionId, verschoben: 0, completed: true, remaining: 0 };
  const ziel = String(s.successor_tenant_id || ''), quelle = String(s.predecessor_tenant_id);
  if (!ziel) throw new Error('SUCCESSION_SUCCESSOR_REQUIRED');
  await mandant(env, ziel);

  const offen = ((await env.DB.prepare('SELECT course_id FROM tenant_succession_courses WHERE succession_id=? AND moved_at IS NULL ORDER BY course_id LIMIT ?').bind(successionId, maxKurse).all<{ course_id: string }>()).results) ?? [];
  if (!offen.length) return abschluss(env, auth, successionId);

  const tabellen = await umzugstabellen(env);
  const ts = nowIso();
  let verschoben = 0;
  for (const k of offen) {
    const anweisungen = tabellen.map(t => env.DB.prepare(`UPDATE ${t} SET tenant_id=? WHERE tenant_id=? AND course_id=?`).bind(ziel, quelle, k.course_id));
    for (let i = 0; i < anweisungen.length; i += 50) await env.DB.batch(anweisungen.slice(i, i + 50));

    // Nachgezaehlt statt geglaubt: bleibt irgendwo eine Zeile dieses Kurses beim Vorgaenger
    // liegen, ist der Umzug unvollstaendig und muss auffallen, nicht durchgehen.
    const summe = tabellen.map(t => `(SELECT COUNT(*) FROM ${t} WHERE tenant_id=? AND course_id=?)`).join('+');
    const binden: unknown[] = [];
    for (const _ of tabellen) binden.push(quelle, k.course_id);
    const rest = await env.DB.prepare(`SELECT ${summe} AS n`).bind(...binden).first<{ n: number }>();
    if (Number(rest?.n || 0)) throw new Error('SUCCESSION_MOVE_INCOMPLETE');

    // Der Kurs selbst zuletzt: bricht der Umzug vorher ab, steht er noch beim Vorgaenger und der
    // Auftrag gilt als offen. Ein erneuter Lauf wiederholt dieselben Aktualisierungen folgenlos.
    await env.DB.prepare('UPDATE courses SET tenant_id=? WHERE tenant_id=? AND id=?').bind(ziel, quelle, k.course_id).run();

    // Wer im Kurs ist, gehoert jetzt zum Nachfolger. Ohne diesen Schritt haetten die Teilnehmenden
    // beim neuen Traeger Kurse, aber keinen Zugang.
    await env.DB.prepare('INSERT OR IGNORE INTO tenant_users (tenant_id,user_id,status,source,created_at,updated_at) SELECT ?,user_id,\'active\',\'import\',?,? FROM memberships WHERE tenant_id=? AND course_id=?')
      .bind(ziel, ts, ts, ziel, k.course_id).run();

    await env.DB.prepare('UPDATE tenant_succession_courses SET moved_at=? WHERE succession_id=? AND course_id=?').bind(ts, successionId, k.course_id).run();
    verschoben++;
  }
  await env.DB.prepare("UPDATE tenant_successions SET status='laufend',courses_done=courses_done+?,updated_at=? WHERE id=?").bind(verschoben, ts, successionId).run();
  const rest = Number((await env.DB.prepare('SELECT COUNT(*) n FROM tenant_succession_courses WHERE succession_id=? AND moved_at IS NULL').bind(successionId).first<{ n: number }>())?.n || 0);
  if (!rest) return { ...(await abschluss(env, auth, successionId)), verschoben };
  return { succession_id: successionId, verschoben, completed: false, remaining: rest };
}

async function abschluss(env: Env, auth: CoreAuthContext, successionId: string) {
  const ts = nowIso();
  await env.DB.prepare("UPDATE tenant_successions SET status='abgeschlossen',completed_at=?,updated_at=? WHERE id=?").bind(ts, ts, successionId).run();
  await audit(env.DB, auth.userId, 'succession.completed', undefined, undefined, 'tenant_succession', successionId);
  return { succession_id: successionId, verschoben: 0, completed: true, remaining: 0 };
}

export async function brichNachfolgeAb(env: Env, auth: CoreAuthContext, successionId: string) {
  requirePlatform(auth);
  const s = await env.DB.prepare('SELECT status,courses_done FROM tenant_successions WHERE id=?').bind(successionId).first<{ status: string; courses_done: number }>();
  if (!s) throw new Error('SUCCESSION_NOT_FOUND');
  // Was schon umgezogen ist, wird nicht zurueckgeschoben: der Nachfolger arbeitet bereits damit,
  // und ein halber Rueckweg waere gefaehrlicher als ein klarer Stand.
  if (Number(s.courses_done || 0) > 0) throw new Error('SUCCESSION_ALREADY_STARTED');
  await env.DB.prepare("UPDATE tenant_successions SET status='abgebrochen',updated_at=? WHERE id=?").bind(nowIso(), successionId).run();
  return { succession_id: successionId, status: 'abgebrochen' };
}

export async function nachfolgen(env: Env, auth: CoreAuthContext, tenantId: string) {
  requirePlatform(auth);
  return ((await env.DB.prepare('SELECT * FROM tenant_successions WHERE predecessor_tenant_id=? OR successor_tenant_id=? ORDER BY effective_on DESC').bind(tenantId, tenantId).all<Record<string, unknown>>()).results) ?? [];
}

// Fuer die oeffentliche Zeugnispruefung: wer ein Zeugnis eines Traegers in der Hand haelt, den es
// nicht mehr gibt, muss erfahren, wer heute zustaendig ist. Bewusst ohne Anmeldung und bewusst
// sparsam - Name und Stichtag, mehr nicht.
export async function nachfolgeFuerAussteller(env: Env, ausstellerTenantId: string): Promise<{ successor_name: string; effective_on: string; kind: string } | null> {
  const s = await env.DB.prepare("SELECT successor_name,effective_on,kind FROM tenant_successions WHERE predecessor_tenant_id=? AND status='abgeschlossen' ORDER BY effective_on DESC LIMIT 1")
    .bind(ausstellerTenantId).first<{ successor_name: string; effective_on: string; kind: string }>();
  return s ?? null;
}

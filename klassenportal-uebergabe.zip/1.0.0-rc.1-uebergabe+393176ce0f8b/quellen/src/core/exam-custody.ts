import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { ketteAnhaengen } from './immutable-audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';
import { sha256Text } from '../portability/backup-integrity.js';

// Die Beweiskette einer Pruefung (P2).
//
// Wer eine Pruefung anficht, greift zuerst das Verfahren an - nicht die Bewertung: Wer hat den
// Bogen erstellt? Wer hat ihn freigegeben? Konnte ihn jemand vorher sehen? Ist er seit der
// Versiegelung unveraendert? Der Traeger traegt die Beweislast fuer sein eigenes Verfahren; ohne
// Kette steht Aussage gegen Aussage, und dann verliert er.
//
// Deshalb hier vier harte Regeln:
//  1. Ein versiegelter Bogen laesst sich nicht mehr aendern. Wer aendern will, muss entsiegeln -
//     mit Begruendung, und das steht fuer immer in der Kette.
//  2. Der Hash wird beim Versiegeln ueber den tatsaechlichen Inhalt gebildet. Eine spaetere
//     Aenderung direkt in der Datenbank faellt damit auf.
//  3. Jedes Ereignis geht zusaetzlich in die manipulationsresistente Protokollkette.
//  4. Archiviert wird erst, wenn bewertet ist - ein Archiv ohne Ergebnis waere kein Abschluss.

export const STATIONEN=['entwurf','freigegeben','versiegelt','archiviert'] as const;
const clean=(v:unknown,n=2000)=>safeString(v,n);

async function bogenHash(env:Env,quizId:string):Promise<string>{
  // Der Hash deckt das ab, was die Pruefung ausmacht: die Kopfdaten und jede verknuepfte Frage mit
  // ihrer Reihenfolge und Punktzahl. Nicht abgedeckt sind Felder, die den Inhalt nicht beruehren.
  const kopf=await env.DB.prepare('SELECT id,title,description,time_limit_minutes,max_attempts,randomize_questions,randomize_options,show_results_mode,opens_at,closes_at FROM quizzes WHERE id=?').bind(quizId).first<Record<string,unknown>>();
  const fragen=((await env.DB.prepare('SELECT question_id,sort_order,points_override FROM quiz_question_links WHERE quiz_id=? ORDER BY sort_order,question_id').bind(quizId).all<Record<string,unknown>>()).results)??[];
  return sha256Text(JSON.stringify({kopf,fragen}));
}

async function kette(env:Env,auth:CoreAuthContext,tenantId:string,quizId:string,ereignis:string,begruendung:string|null,hash:string|null,attemptId:string|null,ts:string){
  const eid=id('pkt_');
  const zeile=env.DB.prepare('INSERT INTO exam_custody_events(id,tenant_id,quiz_id,attempt_id,ereignis,akteur,begruendung,papier_hash,erfasst_am) VALUES(?,?,?,?,?,?,?,?,?)')
    .bind(eid,tenantId,quizId,attemptId,ereignis,auth.userId,begruendung,hash,ts);
  await ketteAnhaengen(env.DB,{tenant_id:tenantId,quelle:'audit_log',quelle_id:eid,akteur:auth.userId,
    aktion:`exam.custody.${ereignis}`,objekt_typ:'quiz',objekt_id:quizId,inhalt:{begruendung,papier_hash:hash,attempt_id:attemptId}},[zeile]);
}

async function ladeBogen(env:Env,tenantId:string,quizId:string){
  const q=await env.DB.prepare('SELECT id,course_id,freigabe_status,papier_hash,versiegelt_am,archiviert_am FROM quizzes WHERE id=? AND tenant_id=?')
    .bind(quizId,tenantId).first<{id:string;course_id:string;freigabe_status:string;papier_hash:string|null;versiegelt_am:string|null;archiviert_am:string|null}>();
  if(!q)throw new Error('PRUEFUNG_NICHT_GEFUNDEN');
  return q;
}

/** Freigeben: der Bogen ist fachlich fertig. Er ist damit noch nicht versiegelt. */
export async function gibBogenFrei(env:Env,auth:CoreAuthContext,tenantId:string,quizId:string,begruendung?:unknown){
  requireRole(auth,'class_admin');
  const q=await ladeBogen(env,tenantId,quizId);
  if(q.freigabe_status!=='entwurf')throw new Error('PRUEFUNG_STATUS_UNPASSEND');
  const ts=nowIso();
  await env.DB.prepare("UPDATE quizzes SET freigabe_status='freigegeben',freigegeben_von=?,freigegeben_am=? WHERE id=? AND tenant_id=?").bind(auth.userId,ts,quizId,tenantId).run();
  await kette(env,auth,tenantId,quizId,'freigegeben',clean(begruendung)||null,null,null,ts);
  await audit(env.DB,auth.userId,'exam.released',tenantId,q.course_id,'quiz',quizId);
  return{status:'freigegeben'};
}

/**
 * Versiegeln: ab hier ist der Bogen unveraenderlich.
 *
 * Die vier Augen sind Absicht: wer den Bogen freigegeben hat, versiegelt ihn nicht selbst. Bei
 * einer Anfechtung ist genau das die Frage, die gestellt wird.
 */
export async function versiegleBogen(env:Env,auth:CoreAuthContext,tenantId:string,quizId:string){
  requireRole(auth,'class_admin');
  const q=await ladeBogen(env,tenantId,quizId);
  if(q.freigabe_status!=='freigegeben')throw new Error('PRUEFUNG_ERST_FREIGEBEN');
  const freigeber=await env.DB.prepare('SELECT freigegeben_von FROM quizzes WHERE id=?').bind(quizId).first<{freigegeben_von:string|null}>();
  if(freigeber?.freigegeben_von===auth.userId&&!auth.isPlatformAdmin&&auth.role!=='tenant_admin')throw new Error('PRUEFUNG_VIER_AUGEN_ERFORDERLICH');
  const hash=await bogenHash(env,quizId),ts=nowIso();
  await env.DB.prepare("UPDATE quizzes SET freigabe_status='versiegelt',versiegelt_am=?,papier_hash=? WHERE id=? AND tenant_id=?").bind(ts,hash,quizId,tenantId).run();
  await kette(env,auth,tenantId,quizId,'versiegelt',null,hash,null,ts);
  await audit(env.DB,auth.userId,'exam.sealed',tenantId,q.course_id,'quiz',quizId);
  return{status:'versiegelt',papier_hash:hash};
}

/** Entsiegeln geht nur mit Begruendung - und die bleibt fuer immer in der Kette. */
export async function entsiegleBogen(env:Env,auth:CoreAuthContext,tenantId:string,quizId:string,begruendung:unknown){
  requireRole(auth,'tenant_admin');
  const q=await ladeBogen(env,tenantId,quizId);
  if(q.freigabe_status!=='versiegelt')throw new Error('PRUEFUNG_STATUS_UNPASSEND');
  const text=clean(begruendung);
  if(text.length<20)throw new Error('PRUEFUNG_ENTSIEGELN_BEGRUENDUNG');
  const benutzt=await env.DB.prepare('SELECT COUNT(*) n FROM quiz_attempts WHERE quiz_id=?').bind(quizId).first<{n:number}>();
  const ts=nowIso();
  await env.DB.prepare("UPDATE quizzes SET freigabe_status='entwurf',versiegelt_am=NULL WHERE id=? AND tenant_id=?").bind(quizId,tenantId).run();
  await kette(env,auth,tenantId,quizId,'entsiegelt',`${text} (bereits ${Number(benutzt?.n??0)} Versuche)`,q.papier_hash,null,ts);
  await audit(env.DB,auth.userId,'exam.unsealed',tenantId,q.course_id,'quiz',quizId,{versuche:Number(benutzt?.n??0)});
  return{status:'entwurf',bisherige_versuche:Number(benutzt?.n??0)};
}

/**
 * Ist der Bogen seit der Versiegelung unveraendert?
 *
 * Wird vor der Ausgabe geprueft. Stimmt der Hash nicht, wird nicht ausgegeben - eine Pruefung auf
 * einem veraenderten Bogen waere von Anfang an anfechtbar.
 */
export async function pruefeSiegel(env:Env,tenantId:string,quizId:string):Promise<{unveraendert:boolean;erwartet:string|null;gefunden:string}>{
  const q=await ladeBogen(env,tenantId,quizId);
  const jetzt=await bogenHash(env,quizId);
  return{unveraendert:!!q.papier_hash&&q.papier_hash===jetzt,erwartet:q.papier_hash,gefunden:jetzt};
}

/** Ausgabe an eine Person - der Moment, ab dem sie den Bogen kennt. */
export async function protokolliereAusgabe(env:Env,auth:CoreAuthContext,tenantId:string,quizId:string,attemptId:string){
  const q=await ladeBogen(env,tenantId,quizId);
  if(q.freigabe_status!=='versiegelt')throw new Error('PRUEFUNG_NICHT_VERSIEGELT');
  const siegel=await pruefeSiegel(env,tenantId,quizId);
  if(!siegel.unveraendert)throw new Error('PRUEFUNG_SIEGEL_GEBROCHEN');
  await kette(env,auth,tenantId,quizId,'ausgegeben',null,q.papier_hash,attemptId,nowIso());
  return{ausgegeben:true};
}

export async function protokolliereEinsicht(env:Env,auth:CoreAuthContext,tenantId:string,quizId:string,attemptId:string|null,begruendung?:unknown){
  await ladeBogen(env,tenantId,quizId);
  await kette(env,auth,tenantId,quizId,'einsicht',clean(begruendung)||null,null,attemptId??null,nowIso());
  return{erfasst:true};
}

/** Archivieren schliesst die Kette - und geht erst, wenn alle Versuche bewertet sind. */
export async function archiviereBogen(env:Env,auth:CoreAuthContext,tenantId:string,quizId:string){
  requireRole(auth,'class_admin');
  const q=await ladeBogen(env,tenantId,quizId);
  if(q.archiviert_am)throw new Error('PRUEFUNG_BEREITS_ARCHIVIERT');
  const offen=await env.DB.prepare("SELECT COUNT(*) n FROM quiz_attempts WHERE quiz_id=? AND status NOT IN ('graded','expired')").bind(quizId).first<{n:number}>();
  if(Number(offen?.n??0)>0)throw new Error('PRUEFUNG_VERSUCHE_OFFEN');
  const ts=nowIso();
  await env.DB.prepare("UPDATE quizzes SET freigabe_status='archiviert',archiviert_am=? WHERE id=? AND tenant_id=?").bind(ts,quizId,tenantId).run();
  await kette(env,auth,tenantId,quizId,'archiviert',null,q.papier_hash,null,ts);
  await audit(env.DB,auth.userId,'exam.archived',tenantId,q.course_id,'quiz',quizId);
  return{status:'archiviert'};
}

/** Die Kette selbst - das, was im Widerspruchsverfahren vorgelegt wird. */
export async function beweiskette(env:Env,auth:CoreAuthContext,tenantId:string,quizId:string){
  requireRole(auth,'class_admin');
  const q=await ladeBogen(env,tenantId,quizId);
  const ereignisse=((await env.DB.prepare('SELECT e.id,e.ereignis,e.akteur,u.display_name AS akteur_name,e.begruendung,e.papier_hash,e.attempt_id,e.erfasst_am FROM exam_custody_events e JOIN users u ON u.id=e.akteur WHERE e.quiz_id=? ORDER BY e.erfasst_am,e.id')
    .bind(quizId).all()).results)??[];
  const siegel=q.papier_hash?await pruefeSiegel(env,tenantId,quizId):{unveraendert:false,erwartet:null,gefunden:''};
  return{bogen:q,ereignisse,siegel};
}

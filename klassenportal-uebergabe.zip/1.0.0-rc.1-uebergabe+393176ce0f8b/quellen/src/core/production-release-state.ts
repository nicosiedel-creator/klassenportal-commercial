import type { Env } from './types.js';

export interface ProductionOriginStatus { ok:boolean; origin:string|null; reason?:string; }
export interface WorkerVersionInfo { id:string; tag:string|null; timestamp:string|null; }
export interface ProductionReleaseAccess {
  production:boolean;
  allowed:boolean;
  approved:boolean;
  origin:string|null;
  version:WorkerVersionInfo|null;
  approvedAt:string|null;
  approvedBy:string|null;
  reason:string|null;
}

const WORKER_SERVICE_NAME='klassenportal-commercial';

export function productionOriginStatus(env:Env):ProductionOriginStatus{
  try{
    const u=new URL(String(env.APP_ORIGIN||''));
    if(u.protocol!=='https:')return{ok:false,origin:u.origin,reason:'APP_ORIGIN muss HTTPS verwenden'};
    const h=u.hostname.toLowerCase();
    if(h.endsWith('.workers.dev')||h.endsWith('.pages.dev')||h==='localhost'||h==='127.0.0.1')return{ok:false,origin:u.origin,reason:'APP_ORIGIN verwendet noch eine Vorschau-/Entwicklungsdomain'};
    return{ok:true,origin:u.origin};
  }catch{return{ok:false,origin:null,reason:'APP_ORIGIN fehlt oder ist ungültig'};}
}

export function requestLooksLikeRemotePreview(request:Request):boolean{
  try{
    const h=new URL(request.url).hostname.toLowerCase();
    if(h.endsWith('.pages.dev'))return true;
    if(!h.endsWith('.workers.dev'))return false;
    const firstLabel=h.split('.')[0]||'';
    return firstLabel!==WORKER_SERVICE_NAME&&firstLabel.endsWith(`-${WORKER_SERVICE_NAME}`);
  }catch{return false;}
}

export function requestLooksLikePreview(request:Request):boolean{
  try{
    const h=new URL(request.url).hostname.toLowerCase();
    if(h==='localhost'||h==='127.0.0.1')return true;
    return requestLooksLikeRemotePreview(request);
  }catch{return false;}
}

function requestUrl(request:Request):URL|null{try{return new URL(request.url);}catch{return null;}}
function requestOrigin(request:Request):string|null{return requestUrl(request)?.origin??null;}

export function requestMatchesConfiguredProductionOrigin(env:Env,request:Request):boolean{
  const configured=productionOriginStatus(env),actual=requestOrigin(request);return !!configured.ok&&!!configured.origin&&actual===configured.origin;
}

async function requestUsesVerifiedCustomDomain(env:Env,request:Request):Promise<boolean>{
  const u=requestUrl(request);if(!u||u.protocol!=='https:')return false;const host=u.hostname.toLowerCase();
  if(host.endsWith('.workers.dev')||host.endsWith('.pages.dev')||host==='localhost'||host==='127.0.0.1')return false;
  try{
    const row=await env.DB.prepare(`SELECT c.tenant_id FROM custom_domain_requests c
      JOIN tenant_settings s ON s.tenant_id=c.tenant_id AND LOWER(s.custom_domain)=LOWER(c.hostname)
      WHERE LOWER(c.hostname)=? AND c.status='active' AND c.hostname_status='active' AND c.ssl_status='active'
        AND c.activated_at IS NOT NULL AND c.removed_at IS NULL LIMIT 1`).bind(host).first<{tenant_id:string}>();
    return !!row?.tenant_id;
  }catch{return false;}
}

export function currentWorkerVersion(env:Env):WorkerVersionInfo|null{
  const raw=env.CF_VERSION_METADATA,id=String(raw?.id||'').trim();if(!id)return null;
  return{id,tag:String(raw?.tag||'').trim()||null,timestamp:String(raw?.timestamp||'').trim()||null};
}

export async function ensureProductionReleaseSchema(env:Env):Promise<void>{
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS production_release_approvals (
    version_id TEXT PRIMARY KEY,version_tag TEXT,version_timestamp TEXT,app_origin TEXT NOT NULL,approved_by TEXT NOT NULL,approved_at TEXT NOT NULL,
    readiness_json TEXT NOT NULL,revoked_at TEXT,revoked_by TEXT,FOREIGN KEY(approved_by) REFERENCES users(id),FOREIGN KEY(revoked_by) REFERENCES users(id))`).run();
  await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_production_release_approvals_active ON production_release_approvals(app_origin,revoked_at,approved_at DESC)').run();
}

export async function productionReleaseAccess(env:Env,request:Request):Promise<ProductionReleaseAccess>{
  const origin=productionOriginStatus(env),version=currentWorkerVersion(env),preview=requestLooksLikePreview(request),remotePreview=requestLooksLikeRemotePreview(request),actualOrigin=requestOrigin(request);
  if(remotePreview)return{production:true,allowed:false,approved:false,origin:origin.origin,version,approvedAt:null,approvedBy:null,reason:'Öffentliche Remote-Preview ist deaktiviert; Vorschau darf keine Produktionsdaten verwenden'};
  if(preview&&!origin.ok)return{production:false,allowed:true,approved:false,origin:origin.origin,version,approvedAt:null,approvedBy:null,reason:null};
  if(preview&&origin.ok)return{production:true,allowed:false,approved:false,origin:origin.origin,version,approvedAt:null,approvedBy:null,reason:'Vorschau-URL verwendet Produktionskonfiguration; Kundenverkehr bleibt aus Sicherheitsgründen gesperrt'};
  if(!origin.ok)return{production:true,allowed:false,approved:false,origin:origin.origin,version,approvedAt:null,approvedBy:null,reason:origin.reason||'Produktionsursprung ist nicht sicher konfiguriert'};
  if(!version)return{production:true,allowed:false,approved:false,origin:origin.origin,version:null,approvedAt:null,approvedBy:null,reason:'Worker-Versionsmetadaten fehlen; Produktion bleibt gesperrt'};
  const trustedHost=!!actualOrigin&&(actualOrigin===origin.origin||await requestUsesVerifiedCustomDomain(env,request));
  if(!trustedHost)return{production:true,allowed:false,approved:false,origin:origin.origin,version,approvedAt:null,approvedBy:null,reason:'Anfrageursprung ist weder Produktionsdomain noch aktiv verifizierte Kundendomain'};
  try{
    const row=await env.DB.prepare(`SELECT approved_at,approved_by FROM production_release_approvals
      WHERE version_id=? AND app_origin=? AND revoked_at IS NULL`).bind(version.id,origin.origin).first<{approved_at:string;approved_by:string}>();
    if(!row)return{production:true,allowed:false,approved:false,origin:origin.origin,version,approvedAt:null,approvedBy:null,reason:'Diese Worker-Version wurde noch nicht ausdrücklich für Produktion freigegeben'};
    return{production:true,allowed:true,approved:true,origin:origin.origin,version,approvedAt:row.approved_at,approvedBy:row.approved_by,reason:null};
  }catch{
    return{production:true,allowed:false,approved:false,origin:origin.origin,version,approvedAt:null,approvedBy:null,reason:'Produktionsfreigabe-Speicher ist nicht verfügbar'};
  }
}

import type { Env } from './types.js';
import { resolveCoreAuth } from './auth.js';
import { assertTenantWriteAllowed } from './commerce-offers.js';
import { approveTeacherFeePeriod, confirmTeacherFeePeriod, listTeacherFeePeriods, listTeacherFeeRates,
  markTeacherFeePeriodPaid, proposeTeacherFeeSettlement, reopenTeacherFeePeriod, saveTeacherFeeRate,
  teacherFeePayoutList, teacherFeePeriodDetail } from './teacher-fees.js';
import { assertSameOrigin, authStatus, json, safeErrorCode } from './utils.js';

// /api/teacher-fees - Honorarabrechnung der freien Dozentinnen und Dozenten.
//
// Bewusst nicht unter /api/payments/: dort haengt der eingefrorene Zahlungsverkehr. Dieser Bereich
// rechnet, laesst bestaetigen, gibt frei und fuehrt eine Liste - er loest nie eine Zahlung aus und
// kennt weder Zahlungsdienstleister noch Bankverbindung. 'paid' ist der Vermerk der Buchhaltung
// ueber eine Auszahlung, die ausserhalb des Portals stattgefunden hat.

async function body(request:Request):Promise<Record<string,unknown>>{try{return await request.json() as Record<string,unknown>;}catch{return{};}}

// Ein Zustand, der die Handlung gerade nicht zulaesst, ist kein Serverfehler und keine falsche
// Eingabe: die Abrechnung ist bestaetigt, freigegeben oder laengst ausgezahlt, und die Oberflaeche
// muss den Stand neu laden statt die Eingabe zu bemaengeln. Genauso der ueberschneidende Satz -
// den loest der Mensch am Bildschirm auf, indem er den alten befristet.
const KONFLIKT=new Set(['TEACHER_FEE_PERIOD_NOT_PROPOSED','TEACHER_FEE_PERIOD_NOT_CONFIRMED',
  'TEACHER_FEE_PERIOD_NOT_APPROVED','TEACHER_FEE_PERIOD_LOCKED','TEACHER_FEE_RATE_OVERLAP',
  'TEACHER_FEE_STATUS_TRANSITION_INVALID','TEACHER_FEE_RUN_TOO_LARGE']);
function fail(e:unknown){
  const code=safeErrorCode(e);
  const status=authStatus(code)??(code==='UNAUTHENTICATED'?401
    :code.startsWith('FORBIDDEN')?403
    :code.includes('NOT_FOUND')?404
    :KONFLIKT.has(code)?409:400);
  return json({ok:false,error:code},status);
}

export async function handleTeacherFeesApi(request:Request,env:Env):Promise<Response|null>{
  const u=new URL(request.url),path=u.pathname;
  if(!path.startsWith('/api/teacher-fees'))return null;
  try{
    assertSameOrigin(request,env.APP_ORIGIN);
    const tenantId=u.searchParams.get('tenant_id')||'';
    if(!tenantId)throw new Error('TENANT_ID_REQUIRED');
    const auth=await resolveCoreAuth(env,request,tenantId);
    if(request.method!=='GET'&&request.method!=='HEAD')await assertTenantWriteAllowed(env,tenantId);

    if(path==='/api/teacher-fees/rates'&&request.method==='GET')
      return json({ok:true,rates:await listTeacherFeeRates(env,auth,tenantId,u.searchParams.get('teacher_id')||undefined)});
    if(path==='/api/teacher-fees/rates'&&request.method==='POST')
      return json({ok:true,...await saveTeacherFeeRate(env,auth,tenantId,await body(request))},201);

    // Zuerst der feste Weg, dann der mit der Kennung: sonst schluckt /periods/<id> den Aufruf
    // /periods/propose und die Verwaltung bekaeme eine Abrechnung namens "propose" gemeldet.
    if(path==='/api/teacher-fees/periods/propose'&&request.method==='POST')
      return json({ok:true,...await proposeTeacherFeeSettlement(env,auth,tenantId,await body(request))},201);
    if(path==='/api/teacher-fees/periods'&&request.method==='GET')
      return json({ok:true,periods:await listTeacherFeePeriods(env,auth,tenantId,
        {status:u.searchParams.get('status')||undefined,teacher_id:u.searchParams.get('teacher_id')||undefined})});
    if(path==='/api/teacher-fees/payout'&&request.method==='GET')
      return json({ok:true,...await teacherFeePayoutList(env,auth,tenantId,
        {from:u.searchParams.get('from')||undefined,to:u.searchParams.get('to')||undefined,status:u.searchParams.get('status')||undefined})});

    const schritt=path.match(/^\/api\/teacher-fees\/periods\/([^/]+)\/(confirm|approve|reopen|paid)$/);
    if(schritt&&request.method==='POST'){
      const periodId=decodeURIComponent(schritt[1]);
      // Jeder Schritt wird abgewartet: ein zurueckgegebenes Versprechen liefe am catch dieses
      // Routers vorbei und ein Zugriffsfehler kaeme beim Aufrufer als 500 an.
      if(schritt[2]==='confirm')return json({ok:true,...await confirmTeacherFeePeriod(env,auth,tenantId,periodId)});
      if(schritt[2]==='approve')return json({ok:true,...await approveTeacherFeePeriod(env,auth,tenantId,periodId)});
      if(schritt[2]==='reopen')return json({ok:true,...await reopenTeacherFeePeriod(env,auth,tenantId,periodId)});
      return json({ok:true,...await markTeacherFeePeriodPaid(env,auth,tenantId,periodId)});
    }
    const periode=path.match(/^\/api\/teacher-fees\/periods\/([^/]+)$/);
    if(periode&&request.method==='GET')
      return json({ok:true,...await teacherFeePeriodDetail(env,auth,tenantId,decodeURIComponent(periode[1]))});

    return json({ok:false,error:'NOT_FOUND'},404);
  }catch(e){return fail(e);}
}

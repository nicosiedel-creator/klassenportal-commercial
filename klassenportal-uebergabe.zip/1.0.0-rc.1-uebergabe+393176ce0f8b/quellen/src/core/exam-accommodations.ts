import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireCourseAccess, requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Nachteilsausgleich (Master-Spec V2 §2.4).
//
// Ohne ihn ist eine Pruefung, die eine behinderte oder chronisch kranke Person nicht bestanden hat,
// anfechtbar - und ein oeffentlich gefoerderter Traeger darf sie so nicht abnehmen. Der Ausgleich
// gleicht die Bedingungen an, nicht den Massstab: mehr Zeit, anderes Format, Hilfsmittel. Die
// Anforderung an die Leistung selbst bleibt unveraendert, deshalb gibt es hier auch keinen
// Punktebonus und keine abgesenkte Bestehensgrenze.
//
// Was hier bewusst NICHT steht: die Diagnose. Gesundheitsdaten sind Art. 9 DSGVO. Gespeichert wird
// die Auswirkung und ein Aktenzeichen; das Attest bleibt in der Personalakte des Traegers.

export const MAX_ZEITZUSCHLAG_PROZENT=200;
export const FORMATE=['grossdruck','screenreader','braille','muendlich_statt_schriftlich','schriftlich_statt_muendlich','leichte_sprache','einzelraum','pausen'] as const;
export type Format=typeof FORMATE[number];

export type Ausgleich={
  zeitzuschlag_prozent:number;
  zusatzversuche:number;
  seb_befreit:boolean;
  formate:Format[];
  hilfsmittel:string[];
  bescheide:string[];
};

const clean=(v:unknown,n=500)=>safeString(v,n);
function manager(auth:CoreAuthContext,courseId:string){requireRole(auth,'class_admin');requireCourseAccess(auth,courseId,'class_admin');}

/**
 * Der fuer diese Person und diese Pruefung geltende Ausgleich, in EINER Abfrage.
 *
 * Es koennen mehrere Bescheide zutreffen - einer fuer den ganzen Kurs, einer fuer genau diese
 * Pruefung. Zusammengefuehrt wird immer zugunsten der Person: der hoechste Zeitzuschlag, jede
 * Befreiung, alle Formate. Andernfalls koennte ein spaeterer, enger gefasster Bescheid einen
 * bereits gewaehrten Ausgleich still wieder einkassieren.
 */
export async function nachteilsausgleichFuer(env:Env,tenantId:string,courseId:string,userId:string,quizId:string|null,stichtag=nowIso()):Promise<Ausgleich|null>{
  const tag=stichtag.slice(0,10);
  const zeilen=(await env.DB.prepare("SELECT zeitzuschlag_prozent,zusatzversuche,seb_befreit,format,hilfsmittel,bescheid_referenz FROM exam_accommodations WHERE tenant_id=? AND course_id=? AND user_id=? AND status='aktiv' AND (quiz_id IS NULL OR quiz_id=?) AND (gueltig_ab IS NULL OR substr(gueltig_ab,1,10)<=?) AND (gueltig_bis IS NULL OR substr(gueltig_bis,1,10)>=?)")
    .bind(tenantId,courseId,userId,quizId,tag,tag)
    .all<{zeitzuschlag_prozent:number;zusatzversuche:number;seb_befreit:number;format:string|null;hilfsmittel:string|null;bescheid_referenz:string|null}>()).results??[];
  if(!zeilen.length)return null;
  const a:Ausgleich={zeitzuschlag_prozent:0,zusatzversuche:0,seb_befreit:false,formate:[],hilfsmittel:[],bescheide:[]};
  for(const z of zeilen){
    a.zeitzuschlag_prozent=Math.max(a.zeitzuschlag_prozent,Number(z.zeitzuschlag_prozent||0));
    a.zusatzversuche=Math.max(a.zusatzversuche,Number(z.zusatzversuche||0));
    if(Number(z.seb_befreit))a.seb_befreit=true;
    if(z.format&&!a.formate.includes(z.format as Format))a.formate.push(z.format as Format);
    if(z.hilfsmittel&&!a.hilfsmittel.includes(z.hilfsmittel))a.hilfsmittel.push(z.hilfsmittel);
    if(z.bescheid_referenz&&!a.bescheide.includes(z.bescheid_referenz))a.bescheide.push(z.bescheid_referenz);
  }
  return a;
}

/** Aufgerundet - eine halbe Minute Zuschlag faellt sonst weg. */
export function zeitlimitMitAusgleich(minuten:number|null,ausgleich:Ausgleich|null):number|null{
  if(minuten===null||minuten===undefined)return null;
  if(!ausgleich||!ausgleich.zeitzuschlag_prozent)return minuten;
  return Math.ceil(Number(minuten)*(1+ausgleich.zeitzuschlag_prozent/100));
}

export function versucheMitAusgleich(maxVersuche:number,ausgleich:Ausgleich|null):number{
  return maxVersuche+(ausgleich?ausgleich.zusatzversuche:0);
}

export async function grantAccommodation(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,input:Record<string,unknown>){
  manager(auth,courseId);
  const userId=clean(input.user_id,120);if(!userId)throw new Error('ACCOMMODATION_USER_REQUIRED');
  const mitglied=await env.DB.prepare("SELECT 1 x FROM memberships WHERE tenant_id=? AND course_id=? AND user_id=? AND role='participant'").bind(tenantId,courseId,userId).first();
  if(!mitglied)throw new Error('ACCOMMODATION_USER_NOT_IN_COURSE');
  const quizId=clean(input.quiz_id,120)||null;
  if(quizId){const q=await env.DB.prepare('SELECT 1 x FROM quizzes WHERE id=? AND tenant_id=? AND course_id=?').bind(quizId,tenantId,courseId).first();if(!q)throw new Error('ACCOMMODATION_QUIZ_SCOPE_INVALID');}
  const zuschlag=Math.trunc(Number(input.zeitzuschlag_prozent??0)),zusatz=Math.trunc(Number(input.zusatzversuche??0));
  if(!Number.isFinite(zuschlag)||zuschlag<0||zuschlag>MAX_ZEITZUSCHLAG_PROZENT||!Number.isFinite(zusatz)||zusatz<0||zusatz>10)throw new Error('ACCOMMODATION_INVALID');
  const format=input.format===null||input.format===undefined||input.format===''?null:clean(input.format,60);
  if(format&&!FORMATE.includes(format as Format))throw new Error('ACCOMMODATION_FORMAT_UNKNOWN');
  const seb=input.seb_befreit===true?1:0;
  // Ein Bescheid, der nichts bewirkt, ist ein Bedienfehler und keine Entscheidung.
  if(!zuschlag&&!zusatz&&!seb&&!format&&!clean(input.hilfsmittel,500))throw new Error('ACCOMMODATION_EMPTY');
  const ab=clean(input.gueltig_ab,40)||null,bis=clean(input.gueltig_bis,40)||null;
  if(ab&&bis&&ab>bis)throw new Error('ACCOMMODATION_PERIOD_INVALID');
  const aid=id('nta_'),ts=nowIso();
  await env.DB.prepare('INSERT INTO exam_accommodations(id,tenant_id,course_id,user_id,quiz_id,zeitzuschlag_prozent,zusatzversuche,seb_befreit,format,hilfsmittel,hinweis,bescheid_referenz,gueltig_ab,gueltig_bis,status,granted_by,granted_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,\'aktiv\',?,?,?)')
    .bind(aid,tenantId,courseId,userId,quizId,zuschlag,zusatz,seb,format,clean(input.hilfsmittel,500)||null,clean(input.hinweis,2000)||null,clean(input.bescheid_referenz,120)||null,ab,bis,auth.userId,ts,ts).run();
  // Im Protokoll steht, DASS ein Ausgleich gewaehrt wurde und in welchem Umfang - nicht, warum.
  await audit(env.DB,auth.userId,'exam.accommodation_granted',tenantId,courseId,'exam_accommodation',aid,{zeitzuschlag_prozent:zuschlag,zusatzversuche:zusatz,seb_befreit:!!seb,format});
  return env.DB.prepare('SELECT * FROM exam_accommodations WHERE id=?').bind(aid).first();
}

export async function revokeAccommodation(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,accommodationId:string){
  manager(auth,courseId);
  const ts=nowIso();
  // Widerrufen, nicht loeschen: bei einem Einspruch muss nachvollziehbar bleiben, was wann galt.
  const r=await env.DB.prepare("UPDATE exam_accommodations SET status='widerrufen',revoked_by=?,revoked_at=?,updated_at=? WHERE id=? AND tenant_id=? AND course_id=? AND status='aktiv'")
    .bind(auth.userId,ts,ts,accommodationId,tenantId,courseId).run();
  if(!r.meta?.changes)throw new Error('ACCOMMODATION_NOT_FOUND');
  await audit(env.DB,auth.userId,'exam.accommodation_revoked',tenantId,courseId,'exam_accommodation',accommodationId);
  return{revoked:true};
}

/**
 * Alles, was die Oberflaeche fuer diese Maske braucht, in einem Aufruf: die Bescheide, die Personen
 * zur Auswahl und die Pruefungen des Kurses.
 */
export async function listAccommodations(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  manager(auth,courseId);
  const accommodations=(await env.DB.prepare('SELECT a.*,u.display_name,q.title AS quiz_title FROM exam_accommodations a JOIN users u ON u.id=a.user_id LEFT JOIN quizzes q ON q.id=a.quiz_id WHERE a.tenant_id=? AND a.course_id=? ORDER BY a.status,u.display_name,a.granted_at DESC')
    .bind(tenantId,courseId).all()).results??[];
  const teilnehmer=(await env.DB.prepare("SELECT DISTINCT u.id,u.display_name FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.tenant_id=? AND m.course_id=? AND m.role='participant' AND u.status='active' ORDER BY u.display_name")
    .bind(tenantId,courseId).all()).results??[];
  const pruefungen=(await env.DB.prepare('SELECT id,title FROM quizzes WHERE tenant_id=? AND course_id=? ORDER BY title')
    .bind(tenantId,courseId).all()).results??[];
  return{accommodations,teilnehmer,pruefungen};
}

/** Die eigene Sicht: wer einen Ausgleich hat, muss vor der Pruefung wissen, was fuer ihn gilt. */
export async function meinNachteilsausgleich(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  requireCourseAccess(auth,courseId);
  return (await env.DB.prepare("SELECT id,quiz_id,zeitzuschlag_prozent,zusatzversuche,seb_befreit,format,hilfsmittel,hinweis,gueltig_ab,gueltig_bis,status FROM exam_accommodations WHERE tenant_id=? AND course_id=? AND user_id=? AND status='aktiv' ORDER BY granted_at DESC")
    .bind(tenantId,courseId,auth.userId).all()).results??[];
}

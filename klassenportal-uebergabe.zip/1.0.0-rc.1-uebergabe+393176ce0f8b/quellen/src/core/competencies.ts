import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireCourseAccess, requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Kompetenzen (Master-Spec V2 §2.6).
//
// Die Frage, die Kostentraeger und Kammer stellen, ist nicht "war die Person anwesend" und auch
// nicht "wie viele Punkte hat sie", sondern "kann sie das". Bis hierher stand die Antwort als
// Freitext in curriculum_items und war damit nicht auswertbar.
//
// Der Kompetenzstand wird ABGELEITET, nicht gespeichert. Eine gespeicherte Kennzahl waere am Tag
// nach der ersten Nachkorrektur falsch, und niemand wuesste, welche der beiden Zahlen gilt. Er
// entsteht aus den Nachweisen, die ohnehin da sind: Noten zu Aufgaben, Ergebnisse von Tests und -
// am genauesten - einzelne Kriterien eines Bewertungsrasters.

export const SCHWELLE_VORGABE=60;
export const GEGENSTAENDE=['curriculum_item','gradebook_item','quiz','rubric_criterion'] as const;
export const ARTEN=['fachkompetenz','methodenkompetenz','sozialkompetenz','selbstkompetenz'] as const;
const clean=(v:unknown,n=500)=>safeString(v,n);
const rund=(n:number)=>Math.round(n*10)/10;
function manager(auth:CoreAuthContext,courseId:string){requireRole(auth,'class_admin');requireCourseAccess(auth,courseId,'class_admin');}

export async function createCompetency(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const code=clean(input.code,60),title=clean(input.title,200);
  if(!code||!title)throw new Error('COMPETENCY_CODE_AND_TITLE_REQUIRED');
  const art=clean(input.art,40)||'fachkompetenz';
  if(!ARTEN.includes(art as never))throw new Error('COMPETENCY_KIND_INVALID');
  const niveau=input.dqr_niveau===null||input.dqr_niveau===undefined||input.dqr_niveau===''?null:Math.trunc(Number(input.dqr_niveau));
  if(niveau!==null&&(!Number.isFinite(niveau)||niveau<1||niveau>8))throw new Error('COMPETENCY_DQR_INVALID');
  const cid=id('kmp_'),ts=nowIso();
  try{
    await env.DB.prepare('INSERT INTO competencies(id,tenant_id,framework_id,parent_id,code,title,beschreibung,dqr_niveau,art,status,sort_order,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,\'aktiv\',?,?,?,?)')
      .bind(cid,tenantId,clean(input.framework_id,120)||null,clean(input.parent_id,120)||null,code,title,clean(input.beschreibung,4000)||null,niveau,art,Math.trunc(Number(input.sort_order??0)),auth.userId,ts,ts).run();
  }catch(e){
    if(/UNIQUE/i.test(String((e as Error).message)))throw new Error('COMPETENCY_CODE_TAKEN');
    throw e;
  }
  await audit(env.DB,auth.userId,'competency.created',tenantId,undefined,'competency',cid,{code,dqr_niveau:niveau});
  return env.DB.prepare('SELECT * FROM competencies WHERE id=?').bind(cid).first();
}

export async function listCompetencies(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  const kompetenzen=(await env.DB.prepare('SELECT * FROM competencies WHERE tenant_id=? ORDER BY status,sort_order,code').bind(tenantId).all<Record<string,unknown>>()).results??[];
  // Alle Verbindungen in EINER Abfrage statt einer je Kompetenz.
  const verbindungen=(await env.DB.prepare('SELECT competency_id,gegenstand,bezug_id,gewicht FROM competency_links WHERE tenant_id=?').bind(tenantId).all<Record<string,unknown>>()).results??[];
  return kompetenzen.map(k=>({...k,verbindungen:verbindungen.filter(v=>v.competency_id===k.id)}));
}

export async function linkCompetency(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,input:Record<string,unknown>){
  manager(auth,courseId);
  const competencyId=clean(input.competency_id,120),gegenstand=clean(input.gegenstand,40),bezugId=clean(input.bezug_id,120);
  if(!GEGENSTAENDE.includes(gegenstand as never)||!bezugId)throw new Error('COMPETENCY_LINK_INVALID');
  const gewicht=Number(input.gewicht??1);
  if(!Number.isFinite(gewicht)||gewicht<=0||gewicht>100)throw new Error('COMPETENCY_WEIGHT_INVALID');
  const k=await env.DB.prepare('SELECT id FROM competencies WHERE id=? AND tenant_id=?').bind(competencyId,tenantId).first();
  if(!k)throw new Error('COMPETENCY_NOT_FOUND');
  // Die Kette zeigt nur auf Dinge, die es gibt und die zu diesem Kurs gehoeren. Sonst haengt sie
  // ins Leere und der Kompetenzstand rechnet still mit nichts.
  const tabelle={curriculum_item:'curriculum_items',gradebook_item:'gradebook_items',quiz:'quizzes',rubric_criterion:'rubric_criteria'}[gegenstand as string];
  const bezug=gegenstand==='curriculum_item'||gegenstand==='rubric_criterion'
    ?await env.DB.prepare(`SELECT id FROM ${tabelle} WHERE id=? AND tenant_id=?`).bind(bezugId,tenantId).first()
    :await env.DB.prepare(`SELECT id FROM ${tabelle} WHERE id=? AND tenant_id=? AND course_id=?`).bind(bezugId,tenantId,courseId).first();
  if(!bezug)throw new Error('COMPETENCY_LINK_TARGET_NOT_FOUND');
  const ts=nowIso();
  try{
    await env.DB.prepare('INSERT INTO competency_links(id,tenant_id,competency_id,gegenstand,bezug_id,gewicht,verknuepft_von,verknuepft_am) VALUES(?,?,?,?,?,?,?,?)')
      .bind(id('kvl_'),tenantId,competencyId,gegenstand,bezugId,gewicht,auth.userId,ts).run();
  }catch(e){
    if(/UNIQUE/i.test(String((e as Error).message)))throw new Error('COMPETENCY_LINK_EXISTS');
    throw e;
  }
  await audit(env.DB,auth.userId,'competency.linked',tenantId,courseId,'competency',competencyId,{gegenstand,bezug_id:bezugId});
  return{linked:true};
}

export async function unlinkCompetency(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,linkId:string){
  manager(auth,courseId);
  const r=await env.DB.prepare('DELETE FROM competency_links WHERE id=? AND tenant_id=?').bind(linkId,tenantId).run();
  if(!r.meta?.changes)throw new Error('COMPETENCY_LINK_NOT_FOUND');
  await audit(env.DB,auth.userId,'competency.unlinked',tenantId,courseId,'competency_link',linkId);
  return{unlinked:true};
}

export type Kompetenzstand={competency_id:string;code:string;title:string;dqr_niveau:number|null;art:string;
  nachweise:number;erreichbar:number;erreicht:number;prozent:number|null;stand:'erreicht'|'teilweise'|'offen'|'ohne_nachweis'};

async function schwelle(env:Env,tenantId:string):Promise<number>{
  const r=await env.DB.prepare('SELECT kompetenz_schwelle_prozent FROM tenant_settings WHERE tenant_id=?').bind(tenantId).first<{kompetenz_schwelle_prozent:number}>();
  return Number(r?.kompetenz_schwelle_prozent||SCHWELLE_VORGABE);
}

/**
 * Der Kompetenzstand einer Person - abgeleitet, in drei Abfragen fuer alle Kompetenzen zusammen.
 *
 * Drei Arten von Nachweis, absteigend nach Genauigkeit:
 *  - ein Kriterium eines Bewertungsrasters: sagt genau ueber DIESE Kompetenz etwas aus;
 *  - eine Bewertungsposition: die Note zu einer Aufgabe, die diese Kompetenz verlangt;
 *  - ein Test: das Ergebnis des besten bewerteten Versuchs.
 *
 * Ohne Nachweis gibt es keinen Stand. Eine Kompetenz als "offen" zu melden, die nie geprueft wurde,
 * waere eine Aussage ueber die Person, die auf nichts beruht.
 */
async function nachweiseFuer(env:Env,tenantId:string,courseId:string,personen:string[]){
  const p=personen.map(()=>'?').join(',');
  // Eine Anweisung, eine Zeile: die Schemapruefung liest die Abfrage als Ganzes und faende an
  // einer ueber mehrere Zeilen zusammengesetzten Zeichenkette nur Bruchstuecke.
  return (await env.DB.prepare(`SELECT a.bewertete_person AS person,l.competency_id,l.gewicht,i.points AS erreicht,c.max_points AS moeglich FROM competency_links l JOIN rubric_criteria c ON c.id=l.bezug_id JOIN rubric_assessment_items i ON i.criterion_id=c.id JOIN rubric_assessments a ON a.id=i.assessment_id AND a.rolle='erstkorrektur' WHERE l.tenant_id=? AND l.gegenstand='rubric_criterion' AND a.course_id=? AND a.bewertete_person IN (${p}) UNION ALL SELECT s.user_id,l.competency_id,l.gewicht,s.points,gi.max_points FROM competency_links l JOIN gradebook_items gi ON gi.id=l.bezug_id JOIN gradebook_scores s ON s.item_id=gi.id AND s.status='published' WHERE l.tenant_id=? AND l.gegenstand='gradebook_item' AND s.course_id=? AND s.points IS NOT NULL AND s.user_id IN (${p}) UNION ALL SELECT t.user_id,l.competency_id,l.gewicht,MAX(t.total_points),(SELECT SUM(q.max_points) FROM quiz_question_links ql JOIN quiz_questions q ON q.id=ql.question_id WHERE ql.quiz_id=l.bezug_id) FROM competency_links l JOIN quiz_attempts t ON t.quiz_id=l.bezug_id AND t.status='graded' WHERE l.tenant_id=? AND l.gegenstand='quiz' AND t.course_id=? AND t.user_id IN (${p}) GROUP BY t.user_id,l.competency_id,l.gewicht,l.bezug_id`)
    .bind(tenantId,courseId,...personen,tenantId,courseId,...personen,tenantId,courseId,...personen)
    .all<{person:string;competency_id:string;gewicht:number;erreicht:number|null;moeglich:number|null}>()).results??[];
}

function rechne(kompetenzen:{id:string;code:string;title:string;dqr_niveau:number|null;art:string}[],
  nachweise:{competency_id:string;gewicht:number;erreicht:number|null;moeglich:number|null}[],grenze:number):Kompetenzstand[]{
  return kompetenzen.map(k=>{
    const meine=nachweise.filter(n=>n.competency_id===k.id&&Number(n.moeglich||0)>0);
    // Ohne Nachweis gibt es keinen Stand. Eine nie gepruefte Kompetenz als "offen" zu melden waere
    // eine Aussage ueber die Person, die auf nichts beruht.
    if(!meine.length)return{competency_id:k.id,code:k.code,title:k.title,dqr_niveau:k.dqr_niveau,art:k.art,
      nachweise:0,erreichbar:0,erreicht:0,prozent:null,stand:'ohne_nachweis' as const};
    const erreichbar=meine.reduce((a,n)=>a+Number(n.moeglich)*Number(n.gewicht),0);
    const erreicht=meine.reduce((a,n)=>a+Number(n.erreicht||0)*Number(n.gewicht),0);
    const prozent=erreichbar>0?rund(erreicht/erreichbar*100):null;
    return{competency_id:k.id,code:k.code,title:k.title,dqr_niveau:k.dqr_niveau,art:k.art,
      nachweise:meine.length,erreichbar:rund(erreichbar),erreicht:rund(erreicht),prozent,
      stand:(prozent===null?'ohne_nachweis':prozent>=grenze?'erreicht':prozent>0?'teilweise':'offen') as Kompetenzstand['stand']};
  });
}

async function aktiveKompetenzen(env:Env,tenantId:string){
  return (await env.DB.prepare("SELECT id,code,title,dqr_niveau,art FROM competencies WHERE tenant_id=? AND status='aktiv' ORDER BY sort_order,code")
    .bind(tenantId).all<{id:string;code:string;title:string;dqr_niveau:number|null;art:string}>()).results??[];
}

/**
 * Der Kompetenzstand einer Person - abgeleitet, in drei Abfragen fuer alle Kompetenzen zusammen.
 *
 * Drei Arten von Nachweis, absteigend nach Genauigkeit:
 *  - ein Kriterium eines Bewertungsrasters: sagt genau ueber DIESE Kompetenz etwas aus;
 *  - eine Bewertungsposition: die Note zu einer Aufgabe, die diese Kompetenz verlangt;
 *  - ein Test: das Ergebnis des besten bewerteten Versuchs.
 */
export async function kompetenzstand(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,userId:string):Promise<{schwelle_prozent:number;kompetenzen:Kompetenzstand[]}>{
  if(userId!==auth.userId)manager(auth,courseId);else requireCourseAccess(auth,courseId);
  const grenze=await schwelle(env,tenantId);
  const kompetenzen=await aktiveKompetenzen(env,tenantId);
  if(!kompetenzen.length)return{schwelle_prozent:grenze,kompetenzen:[]};
  return{schwelle_prozent:grenze,kompetenzen:rechne(kompetenzen,await nachweiseFuer(env,tenantId,courseId,[userId]),grenze)};
}

/**
 * Der Kompetenzstand der ganzen Klasse.
 *
 * Vier Abfragen fuer die ganze Klasse, nicht drei je Person: bei 40 Personen waere das der
 * Unterschied zwischen 4 und 120 Unteranfragen von 1000, die ein Aufruf hat.
 */
export async function kompetenzUebersicht(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  manager(auth,courseId);
  const grenze=await schwelle(env,tenantId);
  const kompetenzen=await aktiveKompetenzen(env,tenantId);
  const personen=(await env.DB.prepare("SELECT DISTINCT u.id,u.display_name FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.tenant_id=? AND m.course_id=? AND m.role='participant' AND u.status='active' ORDER BY u.display_name")
    .bind(tenantId,courseId).all<{id:string;display_name:string}>()).results??[];
  if(!personen.length||!kompetenzen.length)return{schwelle_prozent:grenze,zeilen:[],gesamt:personen.length,gezeigt:0,abgeschnitten:false};
  // Die Abfrage bindet eine Kennung je Person dreimal. SQLite und D1 begrenzen die Zahl der
  // Platzhalter; 150 Personen sind eine sehr grosse Klasse und bleiben deutlich darunter.
  const sichtbar=personen.slice(0,150);
  const nachweise=await nachweiseFuer(env,tenantId,courseId,sichtbar.map(p=>p.id));
  return{schwelle_prozent:grenze,
    zeilen:sichtbar.map(p=>({user_id:p.id,display_name:p.display_name,kompetenzen:rechne(kompetenzen,nachweise.filter(n=>n.person===p.id),grenze)})),
    gesamt:personen.length,gezeigt:sichtbar.length,abgeschnitten:personen.length>sichtbar.length};
}

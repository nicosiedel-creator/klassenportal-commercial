import type { CoreAuthContext, Env } from './types.js';
import { id, json, nowIso, sha256Text } from './utils.js';

// Idempotenz schreibender Wege (Master-Spec V2, B17 "Netzunterbrechung / Offline-Verhalten").
//
// Der Fall, um den es geht, steht im Klassenraum und nicht im Rechenzentrum: die Lehrkraft hakt
// die Anwesenheit ab, das WLAN bricht weg, sie klickt noch dreimal. Was der Server davon sieht,
// ist unbestimmt - vielleicht kam die erste Anfrage durch und nur die Antwort ging verloren.
//
// Eine Wiederholung darf deshalb NICHT ein zweites Mal schreiben. Sie bekommt die gespeicherte
// Antwort, und zwar dieselbe wie beim ersten Mal.
//
// Die zweite, schaerfere Regel: derselbe Schluessel mit einer ANDEREN Anfrage ist keine
// Wiederholung. Das ist entweder ein Fehler im Aufrufer oder der Versuch, an eine fremde Antwort
// zu kommen. Beides wird abgewiesen (IDEMPOTENZ_KONFLIKT) und nie stillschweigend ueberschrieben:
// eine vertauschte Anwesenheitsliste faellt hinterher niemandem mehr auf.
//
// Und die dritte: der Schluessel gilt je Mandant UND je Person. Waere er nur mandantenweit
// eindeutig, koennte eine zweite Lehrkraft mit einem geratenen Schluessel die gespeicherte
// Antwort der ersten abholen - die Wiedererkennung waere dann selbst das Leck.

/** Wie lange eine gespeicherte Antwort wiederverwendet wird. */
export const IDEMPOTENZ_GUELTIG_STUNDEN=24;

const ERLAUBT=/^[A-Za-z0-9][A-Za-z0-9_.:-]{7,199}$/;

/**
 * Den Schluessel aus der Anfrage lesen.
 *
 * Die deutsche Kopfzeile ist die eigene; "Idempotency-Key" wird zusaetzlich akzeptiert, weil jede
 * fremde Bibliothek und jedes Werkzeug sie so schreibt. Ein leerer Wert heisst schlicht "ohne
 * Idempotenz" - das ist kein Fehler, sondern der bisherige Weg.
 */
export function idempotenzSchluessel(request:Request):string{
  const roh=(request.headers.get('Idempotenz-Schluessel')||request.headers.get('Idempotency-Key')||'').trim();
  if(!roh)return '';
  // Ein zu kurzer oder beliebig geformter Schluessel waere ratbar. Geraten werden kann er hier
  // zwar nur innerhalb des eigenen Kontos, aber ein Schluessel, den zwei verschiedene Vorgaenge
  // versehentlich teilen, waere ein Konflikt ohne Not.
  if(!ERLAUBT.test(roh))throw new Error('IDEMPOTENZ_SCHLUESSEL_UNGUELTIG');
  return roh;
}

/** Was ein schreibender Weg zurueckgibt, bevor daraus eine Antwort wird. */
export type Schreibergebnis={status:number;daten:Record<string,unknown>};

function ablauf(jetzt:string):string{
  const d=new Date(jetzt);d.setUTCHours(d.getUTCHours()+IDEMPOTENZ_GUELTIG_STUNDEN);return d.toISOString();
}

/**
 * Die Aufraeumanweisung - EINE Anweisung fuer alle abgelaufenen Eintraege EINES Mandanten.
 *
 * Bewusst als Anweisung und nicht als Lauf: so laesst sie sich mit dem Einfuegen in einen Stapel
 * legen und kostet keine zweite Unteranfrage. Eine Schleife mit einer Abfrage je Zeile waere bei
 * der Grenze von 1000 Unteranfragen je Aufruf der sichere Weg in den Abbruch.
 */
export function aufraeumAnweisung(env:Env,tenantId:string,jetzt:string){
  return env.DB.prepare('DELETE FROM idempotency_keys WHERE tenant_id=? AND expires_at<=?').bind(tenantId,jetzt);
}

/** Derselbe Lauf einzeln - mandantengetrennt, damit er nie fremde Eintraege mitnimmt. */
export async function idempotenzAufraeumen(env:Env,tenantId:string,jetzt=nowIso()):Promise<{geraeumt:number}>{
  const r=await aufraeumAnweisung(env,tenantId,jetzt).run();
  return{geraeumt:Number(r?.meta?.changes??0)};
}

type Gespeichert={anfrage_hash:string;antwort_status:number;antwort_json:string};

/**
 * Einen schreibenden Weg idempotent ausfuehren.
 *
 * Ohne Schluessel aendert sich nichts: der Weg laeuft wie bisher. Mit Schluessel gilt:
 *   - gleiche Anfrage, schon ausgefuehrt  -> gespeicherte Antwort, KEIN zweiter Schreibvorgang
 *   - andere Anfrage, gleicher Schluessel -> IDEMPOTENZ_KONFLIKT
 *   - noch nicht ausgefuehrt              -> ausfuehren und Antwort hinterlegen
 *
 * Gespeichert wird nur, was GELUNGEN ist. Ein Fehlschlag hinterlaesst nichts - sonst waere ein
 * voruebergehender Fehler fuer 24 Stunden festgeschrieben und der zweite Versuch chancenlos.
 */
export async function mitIdempotenz(env:Env,auth:CoreAuthContext,tenantId:string,request:Request,rumpf:string,ausfuehren:()=>Promise<Schreibergebnis>):Promise<Response>{
  const schluessel=idempotenzSchluessel(request);
  if(!schluessel){const e=await ausfuehren();return json(e.daten,e.status);}
  const jetzt=nowIso(),wegpfad=new URL(request.url).pathname,methode=request.method.toUpperCase();
  const anfrageHash=await sha256Text(`${methode} ${wegpfad}\n${rumpf}`);
  const vorhanden=await env.DB.prepare('SELECT anfrage_hash,antwort_status,antwort_json FROM idempotency_keys WHERE tenant_id=? AND user_id=? AND schluessel=? AND expires_at>?')
    .bind(tenantId,auth.userId,schluessel,jetzt).first<Gespeichert>();
  if(vorhanden){
    if(String(vorhanden.anfrage_hash)!==anfrageHash)throw new Error('IDEMPOTENZ_KONFLIKT');
    return json(JSON.parse(String(vorhanden.antwort_json)),Number(vorhanden.antwort_status),{'Idempotenz-Zustand':'wiederholt'});
  }
  const ergebnis=await ausfuehren();
  const antwort=JSON.stringify(ergebnis.daten);
  // Aufraeumen und Hinterlegen in EINEM Stapel: das zaehlt als eine Unteranfrage, und die
  // Loeschung laeuft vor dem Einfuegen - sonst blockierte ein abgelaufener Eintrag mit demselben
  // Schluessel das Hinterlegen der neuen Antwort.
  await env.DB.batch([
    aufraeumAnweisung(env,tenantId,jetzt),
    env.DB.prepare('INSERT INTO idempotency_keys(id,tenant_id,schluessel,user_id,wegpfad,methode,anfrage_hash,antwort_status,antwort_json,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,user_id,schluessel) DO NOTHING')
      .bind(id('idem_'),tenantId,schluessel,auth.userId,wegpfad,methode,anfrageHash,ergebnis.status,antwort,jetzt,ablauf(jetzt)),
  ]);
  return json(ergebnis.daten,ergebnis.status,{'Idempotenz-Zustand':'neu'});
}

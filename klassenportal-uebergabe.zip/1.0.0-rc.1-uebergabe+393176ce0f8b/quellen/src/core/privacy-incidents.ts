import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Datenschutzvorfall - Artikel 33 und 34 DSGVO.
//
// Der Bussgeldtatbestand ist fast nie der Vorfall selbst, sondern das, was danach fehlt: keine
// Meldung binnen 72 Stunden, keine Bewertung, kein Nachweis. Genau das bildet diese Datei ab -
// und zwar so, dass die unbequemen Stellen nicht uebersprungen werden koennen:
//
//  - Die Frist laeuft ab KENNTNIS, nicht ab Erfassung. Wer den Vorfall drei Tage spaeter eintraegt,
//    traegt auch ein, wann er davon wusste - und die Frist ist dann eben schon abgelaufen.
//  - Auch ein Vorfall OHNE Meldepflicht muss dokumentiert werden (Artikel 33 Absatz 5). "Geringes
//    Risiko" ist deshalb kein Knopf, sondern eine Begruendung.
//  - Eine Meldung nach Ablauf der 72 Stunden verlangt einen Verzoegerungsgrund (Artikel 33 Absatz 1
//    Satz 2). Das System fragt danach, statt die Ueberschreitung zu verschweigen.
//
// Melden darf jeder im Haus. Wer eine Fehlversendung bemerkt, ist selten die Leitung - und eine
// Meldeschwelle waere genau die Stelle, an der die 72 Stunden verstreichen.

export const ARTEN=['fehlversand','unbefugter_zugriff','verlust','offenlegung','schadsoftware','ausfall','sonstiges'] as const;
export const FRIST_STUNDEN=72;
const clean=(v:unknown,n=5000)=>safeString(v,n);

export type Vorfall={id:string;tenant_id:string;status:string;risiko:string;entdeckt_am:string;frist_behoerde_am:string;meldepflicht_behoerde:number;gemeldet_behoerde_am:string|null};

function frist(entdecktAm:string):string{
  const t=Date.parse(entdecktAm);
  return new Date((Number.isFinite(t)?t:Date.now())+FRIST_STUNDEN*36e5).toISOString();
}

async function ladeVorfall(env:Env,tenantId:string,incidentId:string):Promise<Vorfall>{
  const v=await env.DB.prepare('SELECT id,tenant_id,status,risiko,entdeckt_am,frist_behoerde_am,meldepflicht_behoerde,gemeldet_behoerde_am FROM privacy_incidents WHERE id=? AND tenant_id=?')
    .bind(incidentId,tenantId).first<Vorfall>();
  if(!v)throw new Error('VORFALL_NICHT_GEFUNDEN');
  return v;
}

async function verlauf(env:Env,tenantId:string,incidentId:string,auth:CoreAuthContext,art:string,text:string,ts:string){
  return env.DB.prepare('INSERT INTO privacy_incident_notes(id,tenant_id,incident_id,verfasst_von,art,text,erfasst_am) VALUES(?,?,?,?,?,?,?)')
    .bind(id('vfn_'),tenantId,incidentId,auth.userId,art,text,ts);
}

/** Melden darf jeder. Die Frist beginnt mit dem Zeitpunkt, zu dem jemand im Haus davon wusste. */
export async function meldeVorfall(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const art=clean(input.art,40),beschreibung=clean(input.beschreibung,5000);
  if(!ARTEN.includes(art as never))throw new Error('VORFALL_ART_UNGUELTIG');
  if(beschreibung.length<20)throw new Error('VORFALL_BESCHREIBUNG_ERFORDERLICH');
  const jetzt=nowIso(),entdeckt=clean(input.entdeckt_am,40)||jetzt;
  if(Number.isNaN(Date.parse(entdeckt)))throw new Error('VORFALL_ZEITPUNKT_UNGUELTIG');
  // Kenntnis in der Zukunft gibt es nicht - das waere ein Tippfehler, der die Frist verschoebe.
  if(Date.parse(entdeckt)>Date.parse(jetzt)+60000)throw new Error('VORFALL_ZEITPUNKT_UNGUELTIG');
  const vorfallId=id('vfa_'),fristAm=frist(entdeckt);
  await env.DB.batch([
    env.DB.prepare('INSERT INTO privacy_incidents(id,tenant_id,art,beschreibung,vorgefallen_am,entdeckt_am,gemeldet_von,betroffene_kategorien,betroffene_anzahl,frist_behoerde_am,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .bind(vorfallId,tenantId,art,beschreibung,clean(input.vorgefallen_am,40)||null,entdeckt,auth.userId,
        clean(input.betroffene_kategorien,500)||null,Number.isFinite(Number(input.betroffene_anzahl))?Math.trunc(Number(input.betroffene_anzahl)):null,
        fristAm,'offen',jetzt,jetzt),
    await verlauf(env,tenantId,vorfallId,auth,'notiz',`Gemeldet: ${beschreibung}`,jetzt),
  ]);
  const leitung=((await env.DB.prepare("SELECT DISTINCT user_id FROM memberships WHERE tenant_id=? AND role='tenant_admin' LIMIT 20").bind(tenantId).all<{user_id:string}>()).results)??[];
  if(leitung.length)await env.DB.batch(leitung.map(l=>env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'privacy_incident',?,?,?)")
    .bind(id('ntf_'),tenantId,l.user_id,'Datenschutzvorfall gemeldet',`Bewertung erforderlich. Meldefrist an die Aufsichtsbehörde: ${fristAm}.`,jetzt)));
  await audit(env.DB,auth.userId,'privacy_incident.reported',tenantId,undefined,'privacy_incident',vorfallId,{art});
  return{id:vorfallId,frist_behoerde_am:fristAm,leitung_benachrichtigt:leitung.length};
}

/**
 * Bewerten. Die Bewertung entscheidet ueber die Meldepflicht - und "kein Risiko" ist keine
 * Abkuerzung, sondern eine begruendete Entscheidung, die genauso dokumentiert wird.
 */
export async function bewerteVorfall(env:Env,auth:CoreAuthContext,tenantId:string,incidentId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const vorfall=await ladeVorfall(env,tenantId,incidentId);
  if(vorfall.status==='abgeschlossen')throw new Error('VORFALL_ABGESCHLOSSEN');
  const risiko=clean(input.risiko,20),begruendung=clean(input.begruendung,5000);
  if(!['gering','hoch'].includes(risiko))throw new Error('VORFALL_RISIKO_UNGUELTIG');
  if(begruendung.length<20)throw new Error('VORFALL_BEGRUENDUNG_ERFORDERLICH');
  // Hohes Risiko heisst: Behoerde UND Betroffene. Geringes Risiko heisst: dokumentieren, nicht
  // melden - die Entscheidung selbst bleibt nachlesbar.
  const behoerde=risiko==='hoch'?1:0;
  const betroffene=risiko==='hoch'&&input.betroffene_benachrichtigen!==false?1:0;
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE privacy_incidents SET risiko=?,risikobegruendung=?,bewertet_von=?,bewertet_am=?,meldepflicht_behoerde=?,meldepflicht_betroffene=?,status=CASE WHEN status='offen' THEN 'bewertet' ELSE status END,updated_at=? WHERE id=? AND tenant_id=?")
      .bind(risiko,begruendung,auth.userId,ts,behoerde,betroffene,ts,incidentId,tenantId),
    await verlauf(env,tenantId,incidentId,auth,'bewertung',`Risiko ${risiko}: ${begruendung}`,ts),
  ]);
  await audit(env.DB,auth.userId,'privacy_incident.assessed',tenantId,undefined,'privacy_incident',incidentId,{risiko,behoerde:!!behoerde});
  return{risiko,meldepflicht_behoerde:!!behoerde,meldepflicht_betroffene:!!betroffene,frist_behoerde_am:vorfall.frist_behoerde_am};
}

/**
 * Meldung an die Aufsichtsbehoerde festhalten.
 *
 * Ohne vorherige Bewertung geht das nicht: was gemeldet wird, muss vorher bewertet worden sein.
 * Nach Ablauf der 72 Stunden verlangt das System einen Verzoegerungsgrund - so steht er in der
 * Akte, wo die Behoerde ihn ohnehin verlangt.
 */
export async function meldeAnBehoerde(env:Env,auth:CoreAuthContext,tenantId:string,incidentId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const vorfall=await ladeVorfall(env,tenantId,incidentId);
  if(vorfall.risiko==='offen')throw new Error('VORFALL_ERST_BEWERTEN');
  if(vorfall.gemeldet_behoerde_am)throw new Error('VORFALL_BEREITS_GEMELDET');
  const behoerde=clean(input.behoerde,200),aktenzeichen=clean(input.aktenzeichen,120)||null;
  if(behoerde.length<3)throw new Error('VORFALL_BEHOERDE_ERFORDERLICH');
  const ts=nowIso(),verspaetet=Date.parse(ts)>Date.parse(vorfall.frist_behoerde_am);
  const grund=clean(input.verzoegerungsgrund,2000);
  if(verspaetet&&grund.length<20)throw new Error('VORFALL_VERZOEGERUNGSGRUND_ERFORDERLICH');
  await env.DB.batch([
    env.DB.prepare("UPDATE privacy_incidents SET gemeldet_behoerde_am=?,behoerde=?,aktenzeichen=?,verzoegerungsgrund=?,status='gemeldet',updated_at=? WHERE id=? AND tenant_id=?")
      .bind(ts,behoerde,aktenzeichen,verspaetet?grund:null,ts,incidentId,tenantId),
    await verlauf(env,tenantId,incidentId,auth,'meldung',`An ${behoerde} gemeldet${aktenzeichen?` (Aktenzeichen ${aktenzeichen})`:''}${verspaetet?`; verspätet, Grund: ${grund}`:''}.`,ts),
  ]);
  await audit(env.DB,auth.userId,'privacy_incident.reported_authority',tenantId,undefined,'privacy_incident',incidentId,{verspaetet});
  return{gemeldet_am:ts,verspaetet};
}

/** Benachrichtigung der betroffenen Personen nach Artikel 34 festhalten. */
export async function informiereBetroffene(env:Env,auth:CoreAuthContext,tenantId:string,incidentId:string,text:unknown){
  requireRole(auth,'tenant_admin');
  const vorfall=await ladeVorfall(env,tenantId,incidentId);
  if(vorfall.risiko==='offen')throw new Error('VORFALL_ERST_BEWERTEN');
  const inhalt=clean(text,5000);
  // Artikel 34 verlangt klare und einfache Sprache - das kann kein System pruefen. Was es pruefen
  // kann: dass ueberhaupt ein Text da ist, der den Menschen sagt, was passiert ist.
  if(inhalt.length<50)throw new Error('VORFALL_INFORMATION_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare('UPDATE privacy_incidents SET betroffene_informiert_am=?,information_text=?,updated_at=? WHERE id=? AND tenant_id=?').bind(ts,inhalt,ts,incidentId,tenantId),
    await verlauf(env,tenantId,incidentId,auth,'information','Betroffene informiert.',ts),
  ]);
  await audit(env.DB,auth.userId,'privacy_incident.subjects_informed',tenantId,undefined,'privacy_incident',incidentId);
  return{informiert_am:ts};
}

export async function vorfallNotiz(env:Env,auth:CoreAuthContext,tenantId:string,incidentId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  await ladeVorfall(env,tenantId,incidentId);
  const text=clean(input.text,5000);
  if(text.length<3)throw new Error('VORFALL_NOTIZ_LEER');
  const art=clean(input.art,20)||'notiz';
  if(!['notiz','massnahme'].includes(art))throw new Error('VORFALL_NOTIZART_UNGUELTIG');
  await (await verlauf(env,tenantId,incidentId,auth,art,text,nowIso())).run();
  return{gespeichert:true};
}

/**
 * Abschliessen - aber nicht, solange eine Pflicht offen ist.
 *
 * Ein Vorfall, der als erledigt gilt, waehrend die Meldung an die Behoerde aussteht, ist genau der
 * Zustand, den man spaeter nicht erklaeren kann.
 */
export async function schliesseVorfall(env:Env,auth:CoreAuthContext,tenantId:string,incidentId:string,massnahmen:unknown){
  requireRole(auth,'tenant_admin');
  const vorfall=await ladeVorfall(env,tenantId,incidentId);
  if(vorfall.status==='abgeschlossen')throw new Error('VORFALL_ABGESCHLOSSEN');
  if(vorfall.risiko==='offen')throw new Error('VORFALL_ERST_BEWERTEN');
  if(Number(vorfall.meldepflicht_behoerde)===1&&!vorfall.gemeldet_behoerde_am)throw new Error('VORFALL_MELDUNG_OFFEN');
  const text=clean(massnahmen,5000);
  if(text.length<20)throw new Error('VORFALL_MASSNAHMEN_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE privacy_incidents SET status='abgeschlossen',massnahmen=?,abgeschlossen_am=?,updated_at=? WHERE id=? AND tenant_id=?").bind(text,ts,ts,incidentId,tenantId),
    await verlauf(env,tenantId,incidentId,auth,'abschluss',text,ts),
  ]);
  await audit(env.DB,auth.userId,'privacy_incident.closed',tenantId,undefined,'privacy_incident',incidentId);
  return{abgeschlossen:true};
}

/**
 * Das Verzeichnis nach Artikel 33 Absatz 5.
 *
 * Es enthaelt JEDEN Vorfall - auch die, die nicht gemeldet wurden. Genau darin besteht seine
 * Aufgabe: die Aufsicht will sehen, dass bewertet wurde, nicht nur, dass gemeldet wurde.
 */
export async function vorfallRegister(env:Env,auth:CoreAuthContext,tenantId:string,grenze=200){
  requireRole(auth,'tenant_admin');
  const n=Math.min(Math.max(Number(grenze)||200,1),500);
  return ((await env.DB.prepare('SELECT id,art,beschreibung,entdeckt_am,risiko,risikobegruendung,meldepflicht_behoerde,frist_behoerde_am,gemeldet_behoerde_am,behoerde,aktenzeichen,verzoegerungsgrund,betroffene_informiert_am,betroffene_anzahl,status,massnahmen,abgeschlossen_am FROM privacy_incidents WHERE tenant_id=? ORDER BY entdeckt_am DESC LIMIT ?')
    .bind(tenantId,n).all()).results)??[];
}

export async function vorfallLesen(env:Env,auth:CoreAuthContext,tenantId:string,incidentId:string){
  requireRole(auth,'tenant_admin');
  const vorfall=await env.DB.prepare('SELECT * FROM privacy_incidents WHERE id=? AND tenant_id=?').bind(incidentId,tenantId).first();
  if(!vorfall)throw new Error('VORFALL_NICHT_GEFUNDEN');
  const eintraege=((await env.DB.prepare('SELECT id,verfasst_von,art,text,erfasst_am FROM privacy_incident_notes WHERE incident_id=? ORDER BY erfasst_am').bind(incidentId).all()).results)??[];
  return{vorfall,verlauf:eintraege};
}

/**
 * Die Frist erinnert von selbst - vor Ablauf und danach.
 *
 * Vorher, weil eine Meldung nach 71 Stunden noch fristgemaess ist. Nachher, weil ein
 * ueberschrittener Vorfall nicht aus der Liste verschwinden darf, nur weil die Frist vorbei ist.
 */
export async function erinnereAnVorfallfristen(env:Env,grenze=20,jetzt=nowIso()):Promise<{erinnert:number;vorfaelle:number}>{
  const vorwarnung=new Date(Date.parse(jetzt)+12*36e5).toISOString();
  // Erinnert wird, wo eine Meldepflicht besteht - und wo noch NIEMAND bewertet hat. Der zweite
  // Fall ist der gefaehrlichere: die Frist laeuft, und es hat noch niemand entschieden. Ein als
  // gering bewerteter Vorfall erinnert dagegen nicht; ihn zu melden ist gerade nicht verlangt.
  const offen=((await env.DB.prepare("SELECT id,tenant_id,frist_behoerde_am,risiko FROM privacy_incidents WHERE status<>'abgeschlossen' AND gemeldet_behoerde_am IS NULL AND (meldepflicht_behoerde=1 OR risiko='offen') AND frist_behoerde_am<=? ORDER BY frist_behoerde_am LIMIT ?")
    .bind(vorwarnung,Math.max(1,Math.min(100,grenze))).all<{id:string;tenant_id:string;frist_behoerde_am:string;risiko:string}>()).results)??[];
  if(!offen.length)return{erinnert:0,vorfaelle:0};
  const jeMandant=new Map<string,number>();
  for(const v of offen)jeMandant.set(v.tenant_id,(jeMandant.get(v.tenant_id)??0)+1);
  const anweisungen=[];let erinnert=0;
  for(const [tenantId,anzahl] of jeMandant){
    const leitung=((await env.DB.prepare("SELECT DISTINCT user_id FROM memberships WHERE tenant_id=? AND role='tenant_admin' LIMIT 20").bind(tenantId).all<{user_id:string}>()).results)??[];
    for(const l of leitung){
      anweisungen.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'privacy_incident_deadline',?,?,?)")
        .bind(id('ntf_'),tenantId,l.user_id,'Datenschutzvorfall: Meldefrist',`${anzahl} Vorfall/Vorfälle sind nicht gemeldet und die 72-Stunden-Frist läuft ab oder ist abgelaufen.`,jetzt));
      erinnert++;
    }
  }
  if(anweisungen.length)await env.DB.batch(anweisungen);
  return{erinnert,vorfaelle:offen.length};
}

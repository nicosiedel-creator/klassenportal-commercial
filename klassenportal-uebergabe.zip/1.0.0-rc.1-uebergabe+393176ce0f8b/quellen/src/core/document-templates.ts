import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { certificateEligibleParticipants } from './certificate-eligible.js';
import { DOKUMENT_PLATZHALTER, erlaubtePlatzhalter, renderePlatzhalter, unbekanntePlatzhalter, type Zielgruppe } from './document-placeholders.js';
import { requireCourseAccess, requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Dokumentvorlagen mit Platzhaltern und Serienausgabe.
//
// Was hier WIEDERVERWENDET wird, statt es ein zweites Mal zu bauen:
//   - die Platzhalterschreibweise {{...}} und der Renderer selbst (document-placeholders.ts).
//     certificates.ts hatte eine eigene, weniger strenge Fassung; sie ist ersetzt, es gibt jetzt
//     genau EINEN Renderer im Portal.
//   - certificateEligibleParticipants() bestimmt, wer in einem Kurs ein Dokument bekommen kann.
//     Dieselbe Frage, dieselbe Antwort, dieselben Rechtepruefungen - kein zweiter Auswahlpfad.
//   - der Schnappschuss: certificate_records friert das fertige Dokument in snapshot_json ein,
//     statt es spaeter aus Lebenddaten neu zu rechnen. document_run_items macht es genauso.
//   - die fortsetzbare Serie aus participant-document-import.ts: Zeiger auf die naechste offene
//     Position, completed/remaining nach aussen, gesammelte Anweisungen ueber env.DB.batch().
//
// Was NICHT wiederverwendet wird und warum: certificate_templates haengt am Zeugnislebenslauf
// (vorbereiten, freigeben, ausstellen, widerrufen), an Anwesenheitskriterien und an einem
// oeffentlichen Pruef-Token. Ein Absageschreiben oder ein Kostentraegerbericht durchlaeuft davon
// nichts. Haette man beides in eine Tabelle gezwungen, waere jeder Serienbrief als "Zeugnis" in
// der Zeugnisliste erschienen und haette einen Pruef-Link bekommen.

type VorlageZeile={id:string;tenant_id:string;name:string;document_kind:string;subject_scope:Zielgruppe;title_template:string;body_template:string;is_active:number;version:number};
type LaufZeile={id:string;tenant_id:string;template_id:string;template_version:number;course_id:string;period_from:string|null;period_to:string|null;status:'running'|'completed';template_snapshot_json:string;total_count:number;done_upto:number;subjects_json:string;created_at:string};

const DOKUMENT_ARTEN=['teilnahmebescheinigung','praktikumsvertrag','kostentraegerbericht','absageschreiben','sonstiges'];
const ZIELGRUPPEN:Zielgruppe[]=['teilnehmer','kurs'];

// Wie viele Dokumente EIN Aufruf erzeugt. Gemessen, nicht geschaetzt: ein Aufruf kostet unabhaengig
// von dieser Zahl rund acht Unteranfragen (Lauf lesen, Vorlage lesen, Kurs lesen, Traeger lesen,
// Teilnehmerzahl, Personen des Fensters in EINER Abfrage, die Schreibstapel, der Zeiger) - die
// Plattform laesst 1000 je Aufruf zu. Die Grenze steht deshalb nicht wegen der Unteranfragen,
// sondern wegen Rechenzeit und Antwortgroesse.
const DOKUMENTE_JE_AUFRUF=200;
// So viele Einfuegungen gehen in EINEN Stapel. env.DB.batch() ist eine Unteranfrage, egal wie
// viele Anweisungen darin stehen; die Stueckelung schuetzt nur vor einer zu grossen Anfrage.
const SCHREIB_STAPEL=50;
// So gross darf eine Serie insgesamt sein. Darueber wird abgewiesen statt halb bearbeitet - der
// Weg ist derselbe wie bei den Zeugnissen: in Gruppen ausgeben.
export const DOKUMENT_SERIE_MAX=2000;

function deDatum(roh:unknown):string{
  const s=String(roh??'').trim();
  const m=s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m?`${m[3]}.${m[2]}.${m[1]}`:s;
}

async function vorlageLesen(env:Env,tenantId:string,templateId:string,nurAktive:boolean){
  const t=await env.DB.prepare('SELECT id,tenant_id,name,document_kind,subject_scope,title_template,body_template,is_active,version FROM document_templates WHERE tenant_id=? AND id=?').bind(tenantId,templateId).first<VorlageZeile>();
  if(!t)throw new Error('DOCUMENT_TEMPLATE_NOT_FOUND');
  if(nurAktive&&!Number(t.is_active))throw new Error('DOCUMENT_TEMPLATE_INACTIVE');
  return t;
}

// Kurs, Traeger und Teilnehmerzahl - alles, was jedes Dokument einer Serie gemeinsam hat. Die
// Kursabfrage traegt die Mandantenkennung; eine vom Client gelieferte Kurskennung aus einem
// fremden Mandanten findet hier nichts und endet als COURSE_NOT_FOUND.
async function grunddaten(env:Env,tenantId:string,courseId:string){
  const kurs=await env.DB.prepare('SELECT id,name,code,start_date,end_date FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,courseId).first<{id:string;name:string;code:string;start_date:string|null;end_date:string|null}>();
  if(!kurs)throw new Error('COURSE_NOT_FOUND');
  const traeger=await env.DB.prepare('SELECT t.name name,COALESCE(s.portal_name,t.name) portal_name FROM tenants t LEFT JOIN tenant_settings s ON s.tenant_id=t.id WHERE t.id=?').bind(tenantId).first<{name:string;portal_name:string}>();
  const anzahl=await env.DB.prepare("SELECT COUNT(*) anzahl FROM memberships m JOIN users u ON u.id=m.user_id JOIN tenant_users tu ON tu.tenant_id=m.tenant_id AND tu.user_id=m.user_id WHERE m.tenant_id=? AND m.course_id=? AND m.role='participant' AND u.status='active' AND tu.status='active'").bind(tenantId,courseId).first<{anzahl:number}>();
  return {kurs,traegerName:String(traeger?.name||''),portalName:String(traeger?.portal_name||''),teilnehmerzahl:Number(anzahl?.anzahl||0)};
}

type Grunddaten=Awaited<ReturnType<typeof grunddaten>>;

// Die Personen eines Fensters in EINER Abfrage. Je Person einzeln zu lesen waere bei zweihundert
// Dokumenten der teuerste Teil eines Aufrufs und der einzige, der mit der Fenstergroesse waechst.
// Der Mandant steht in der Verknuepfung, nicht nur im WHERE: eine Kennung aus einem fremden
// Mandanten findet hier nichts.
async function personenLesen(env:Env,tenantId:string,kennungen:string[]){
  const personen=new Map<string,Record<string,unknown>>();
  if(!kennungen.length)return personen;
  const marks=kennungen.map(()=>'?').join(',');
  const r=await env.DB.prepare(`SELECT u.id,u.display_name,u.email,tu.external_id FROM users u JOIN tenant_users tu ON tu.tenant_id=? AND tu.user_id=u.id WHERE u.id IN (${marks}) AND u.status='active' AND tu.status='active'`).bind(tenantId,...kennungen).all<Record<string,unknown>>();
  for(const p of r.results??[])personen.set(String(p.id),p);
  return personen;
}

function gemeinsameWerte(g:Grunddaten,vorlageName:string,von:string|null,bis:string|null,ausstellungsdatum:string){
  const werte=new Map<string,string>();
  werte.set('kurs.bezeichnung',String(g.kurs.name||''));
  werte.set('kurs.code',String(g.kurs.code||''));
  werte.set('kurs.beginn',deDatum(g.kurs.start_date));
  werte.set('kurs.ende',deDatum(g.kurs.end_date));
  werte.set('kurs.teilnehmerzahl',String(g.teilnehmerzahl));
  werte.set('zeitraum.von',deDatum(von??g.kurs.start_date));
  werte.set('zeitraum.bis',deDatum(bis??g.kurs.end_date));
  werte.set('traeger.name',g.traegerName);
  werte.set('traeger.portal',g.portalName);
  werte.set('dokument.datum',deDatum(ausstellungsdatum.slice(0,10)));
  werte.set('dokument.vorlage',vorlageName);
  return werte;
}

// Die Wertetabelle EINES Dokuments. Fuer eine kursweite Vorlage bleiben teilnehmer.* bewusst
// aussen vor - was nicht in der Tabelle steht, kann kein Platzhalter erreichen.
function dokumentWerte(basis:ReadonlyMap<string,string>,zielgruppe:Zielgruppe,person:{display_name?:unknown;email?:unknown;external_id?:unknown}|null,nummer:string){
  const werte=new Map(basis);
  werte.set('dokument.nummer',nummer);
  if(zielgruppe==='teilnehmer'){
    werte.set('teilnehmer.name',String(person?.display_name??''));
    werte.set('teilnehmer.email',String(person?.email??''));
    werte.set('teilnehmer.nummer',String(person?.external_id??''));
  }
  return werte;
}

/** Der Katalog fuer die Oberflaeche: welche Platzhalter es gibt und was sie bedeuten. */
export function documentPlaceholderCatalogue(){
  return DOKUMENT_PLATZHALTER.map(p=>({schluessel:p.schluessel,bedeutung:p.bedeutung,zielgruppe:p.nur}));
}

export async function listDocumentTemplates(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  const r=await env.DB.prepare('SELECT id,name,document_kind,subject_scope,title_template,body_template,is_active,version,updated_at FROM document_templates WHERE tenant_id=? ORDER BY is_active DESC,name').bind(tenantId).all<Record<string,unknown>>();
  return (r.results??[]).map(t=>({...t,unbekannte_platzhalter:unbekanntePlatzhalter(`${t.title_template} ${t.body_template}`,erlaubtePlatzhalter(String(t.subject_scope) as Zielgruppe))}));
}

export async function saveDocumentTemplate(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const templateId=safeString(input.id,120),name=safeString(input.name,200),titel=safeString(input.title_template,500),text=safeString(input.body_template,20000);
  const art=String(input.document_kind||'sonstiges'),zielgruppe=String(input.subject_scope||'teilnehmer') as Zielgruppe;
  if(!name||!titel||!text)throw new Error('DOCUMENT_TEMPLATE_FIELDS_REQUIRED');
  if(!DOKUMENT_ARTEN.includes(art))throw new Error('DOCUMENT_TEMPLATE_KIND_INVALID');
  if(!ZIELGRUPPEN.includes(zielgruppe))throw new Error('DOCUMENT_TEMPLATE_SCOPE_INVALID');
  const aktiv=input.is_active===false?0:1,ts=nowIso();
  if(templateId){
    const alt=await vorlageLesen(env,tenantId,templateId,false);
    const version=Number(alt.version)+1;
    await env.DB.prepare('UPDATE document_templates SET name=?,document_kind=?,subject_scope=?,title_template=?,body_template=?,is_active=?,version=?,updated_by=?,updated_at=? WHERE tenant_id=? AND id=?')
      .bind(name,art,zielgruppe,titel,text,aktiv,version,auth.userId,ts,tenantId,templateId).run();
    await audit(env.DB,auth.userId,'document.template.updated',tenantId,undefined,'document_template',templateId,{version,kind:art,scope:zielgruppe});
    return withHinweis(await vorlageLesen(env,tenantId,templateId,false));
  }
  const neu=id('dtp_');
  await env.DB.prepare('INSERT INTO document_templates(id,tenant_id,name,document_kind,subject_scope,title_template,body_template,is_active,version,created_by,created_at,updated_by,updated_at) VALUES(?,?,?,?,?,?,?,?,1,?,?,?,?)')
    .bind(neu,tenantId,name,art,zielgruppe,titel,text,aktiv,auth.userId,ts,auth.userId,ts).run();
  await audit(env.DB,auth.userId,'document.template.created',tenantId,undefined,'document_template',neu,{kind:art,scope:zielgruppe});
  return withHinweis(await vorlageLesen(env,tenantId,neu,false));
}

// Ein Platzhalter, den niemand fuellen kann, ist kein Fehler - er bleibt im Dokument stehen. Der
// Kunde soll es aber beim Speichern erfahren und nicht erst im gedruckten Schreiben.
function withHinweis(t:VorlageZeile){
  return {...t,unbekannte_platzhalter:unbekanntePlatzhalter(`${t.title_template} ${t.body_template}`,erlaubtePlatzhalter(t.subject_scope))};
}

/** Eine Vorschau an echten Daten, bevor eine Serie ueber hundert Personen laeuft. */
export async function previewDocumentTemplate(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const templateId=safeString(input.template_id,120),courseId=safeString(input.course_id,120),userId=safeString(input.user_id,120);
  if(!templateId)throw new Error('DOCUMENT_TEMPLATE_ID_REQUIRED');
  if(!courseId)throw new Error('COURSE_ID_REQUIRED');
  const t=await vorlageLesen(env,tenantId,templateId,false);
  const teilnehmende=await certificateEligibleParticipants(env,auth,tenantId,courseId);
  const g=await grunddaten(env,tenantId,courseId);
  const basis=gemeinsameWerte(g,t.name,safeString(input.period_from,20)||null,safeString(input.period_to,20)||null,nowIso());
  // Ohne ausdrueckliche Person wird die erste der Klasse gezeigt. Eine vom Client genannte Person
  // muss in DIESER Klasse dieses Mandanten sein - sonst waere die Vorschau ein Weg, fremde Namen
  // abzufragen.
  const gewaehlt=userId?teilnehmende.find(x=>String(x.id)===userId):teilnehmende[0];
  if(userId&&!gewaehlt)throw new Error('DOCUMENT_RUN_SUBJECT_UNKNOWN');
  // Dieselbe Abfrage wie im Serienlauf. Sonst zeigte die Vorschau Felder leer, die im echten
  // Dokument gefuellt sind - und der Kunde korrigierte eine Vorlage, an der nichts fehlte.
  const person=t.subject_scope==='teilnehmer'&&gewaehlt?(await personenLesen(env,tenantId,[String(gewaehlt.id)])).get(String(gewaehlt.id))??null:null;
  const werte=dokumentWerte(basis,t.subject_scope,person,'DOK-VORSCHAU');
  return {
    template_id:t.id,subject_scope:t.subject_scope,
    subject_name:t.subject_scope==='teilnehmer'?String(gewaehlt?.display_name||''):String(g.kurs.name||''),
    title:renderePlatzhalter(t.title_template,werte),
    body:renderePlatzhalter(t.body_template,werte),
    unbekannte_platzhalter:unbekanntePlatzhalter(`${t.title_template} ${t.body_template}`,erlaubtePlatzhalter(t.subject_scope)),
  };
}

/**
 * Startet die Serie. Die Empfaengerliste wird hier eingefroren; erzeugt wird ab dem ersten
 * Fenster, den Rest holt continueDocumentRun.
 */
export async function startDocumentRun(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const templateId=safeString(input.template_id,120),courseId=safeString(input.course_id,120);
  if(!templateId)throw new Error('DOCUMENT_TEMPLATE_ID_REQUIRED');
  if(!courseId)throw new Error('COURSE_ID_REQUIRED');
  const t=await vorlageLesen(env,tenantId,templateId,true);
  let subjects:string[];
  if(t.subject_scope==='teilnehmer'){
    // Dieselbe Auswahl wie bei den Zeugnissen - samt Kurszugriff, Mandantenpruefung und der
    // Bedingung, dass Konto und Mandantenzuordnung aktiv sind.
    const alle=await certificateEligibleParticipants(env,auth,tenantId,courseId);
    const gewuenscht=Array.isArray(input.user_ids)?new Set((input.user_ids as unknown[]).map(x=>safeString(x,120)).filter(Boolean)):null;
    const vorhanden=new Set(alle.map(x=>String(x.id)));
    // Eine vom Client gelieferte Kennung, die nicht zu dieser Klasse dieses Mandanten gehoert,
    // wird nicht stillschweigend weggelassen: der Aufrufer soll wissen, dass seine Auswahl nicht
    // die ist, die er glaubt.
    if(gewuenscht)for(const x of gewuenscht)if(!vorhanden.has(x))throw new Error('DOCUMENT_RUN_SUBJECT_UNKNOWN');
    subjects=alle.map(x=>String(x.id)).filter(x=>!gewuenscht||gewuenscht.has(x));
  }else{
    requireCourseAccess(auth,courseId,'class_admin');
    // Ein Kursdokument entsteht genau einmal; die leere Kennung steht fuer "keine Person".
    subjects=[''];
  }
  if(!subjects.length)throw new Error('DOCUMENT_RUN_NO_SUBJECTS');
  if(subjects.length>DOKUMENT_SERIE_MAX)throw new Error('DOCUMENT_RUN_TOO_LARGE');
  const ts=nowIso(),runId=id('drn_');
  const schnappschuss={name:t.name,document_kind:t.document_kind,subject_scope:t.subject_scope,title_template:t.title_template,body_template:t.body_template,version:t.version};
  await env.DB.prepare('INSERT INTO document_runs(id,tenant_id,template_id,template_version,course_id,period_from,period_to,status,template_snapshot_json,total_count,done_upto,subjects_json,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,0,?,?,?,?)')
    .bind(runId,tenantId,t.id,t.version,courseId,safeString(input.period_from,20)||null,safeString(input.period_to,20)||null,'running',JSON.stringify(schnappschuss),subjects.length,JSON.stringify(subjects),auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'document.run.started',tenantId,courseId,'document_run',runId,{templateId:t.id,version:t.version,total:subjects.length});
  return continueDocumentRun(env,auth,tenantId,runId,input.max_documents);
}

/**
 * Erzeugt das naechste Fenster der Serie. Nach aussen wie beim Teilnehmerimport: completed sagt,
 * ob die Serie durch ist, remaining, wie viel noch aussteht.
 */
export async function continueDocumentRun(env:Env,auth:CoreAuthContext,tenantId:string,runIdRaw:unknown,maxRaw?:unknown){
  requireRole(auth,'class_admin');
  const runId=safeString(runIdRaw,120);
  const lauf=await env.DB.prepare('SELECT id,tenant_id,template_id,template_version,course_id,period_from,period_to,status,template_snapshot_json,total_count,done_upto,subjects_json,created_at FROM document_runs WHERE tenant_id=? AND id=?').bind(tenantId,runId).first<LaufZeile>();
  if(!lauf)throw new Error('DOCUMENT_RUN_NOT_FOUND');
  requireCourseAccess(auth,lauf.course_id,'class_admin');
  const subjects=JSON.parse(lauf.subjects_json) as string[];
  const zeiger=Math.max(0,Number(lauf.done_upto)||0);
  if(lauf.status==='completed'||zeiger>=subjects.length){
    if(lauf.status!=='completed')await env.DB.prepare("UPDATE document_runs SET status='completed',completed_at=?,updated_at=? WHERE tenant_id=? AND id=?").bind(nowIso(),nowIso(),tenantId,runId).run();
    return {run_id:runId,produced:0,skipped:[] as Array<{position:number;reason:string}>,completed:true,remaining:0,total:subjects.length};
  }
  const grenze=Math.max(1,Math.min(DOKUMENTE_JE_AUFRUF,Math.floor(Number(maxRaw))||DOKUMENTE_JE_AUFRUF));
  const gefroren=JSON.parse(lauf.template_snapshot_json) as {name:string;subject_scope:Zielgruppe;title_template:string;body_template:string};
  const zielgruppe:Zielgruppe=gefroren.subject_scope==='kurs'?'kurs':'teilnehmer';
  const fenster=subjects.slice(zeiger,zeiger+grenze);
  const g=await grunddaten(env,tenantId,lauf.course_id);
  const basis=gemeinsameWerte(g,gefroren.name,lauf.period_from,lauf.period_to,lauf.created_at);
  const personen=zielgruppe==='teilnehmer'?await personenLesen(env,tenantId,fenster.filter(Boolean)):new Map<string,Record<string,unknown>>();
  const ts=nowIso(),kurz=runId.slice(-6).toUpperCase(),jahr=ts.slice(0,4);
  const anweisungen:ReturnType<Env['DB']['prepare']>[]=[],uebersprungen:Array<{position:number;reason:string}>=[];
  fenster.forEach((subject,versatz)=>{
    const position=zeiger+versatz;
    const person=zielgruppe==='teilnehmer'?personen.get(subject):null;
    // Wer den Mandanten zwischen Start und Fortsetzung verlassen hat, bekommt kein Dokument mit
    // leeren Feldern, sondern faellt benannt aus der Serie. Die Position bleibt trotzdem belegt,
    // damit sich die folgenden Nummern nicht verschieben.
    if(zielgruppe==='teilnehmer'&&!person){uebersprungen.push({position,reason:'SUBJECT_NO_LONGER_ACTIVE'});return;}
    const nummer=`DOK-${jahr}-${kurz}-${String(position+1).padStart(4,'0')}`;
    const werte=dokumentWerte(basis,zielgruppe,person??null,nummer);
    const titel=renderePlatzhalter(gefroren.title_template,werte),text=renderePlatzhalter(gefroren.body_template,werte);
    const name=zielgruppe==='teilnehmer'?String(person?.display_name||''):String(g.kurs.name||'');
    const schnappschuss={provider:g.traegerName,subject_scope:zielgruppe,subject_name:name,course:{id:g.kurs.id,name:g.kurs.name,code:g.kurs.code},template:{id:lauf.template_id,name:gefroren.name,version:lauf.template_version},document_number:nummer,title:titel,body:text};
    // INSERT OR IGNORE: bricht ein Aufruf nach dem Schreiben, aber vor dem Fortschreiben des
    // Zeigers ab, erzeugt die Wiederholung dieselben Positionen nicht ein zweites Mal.
    anweisungen.push(env.DB.prepare('INSERT OR IGNORE INTO document_run_items(id,tenant_id,run_id,position,user_id,subject_name,document_number,title,body,snapshot_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .bind(id('dri_'),tenantId,runId,position,subject||null,name,nummer,titel,text,JSON.stringify(schnappschuss),ts));
  });
  for(let i=0;i<anweisungen.length;i+=SCHREIB_STAPEL)await env.DB.batch(anweisungen.slice(i,i+SCHREIB_STAPEL));
  const neuerZeiger=zeiger+fenster.length,fertig=neuerZeiger>=subjects.length;
  await env.DB.prepare('UPDATE document_runs SET done_upto=?,status=?,completed_at=?,updated_at=? WHERE tenant_id=? AND id=?')
    .bind(neuerZeiger,fertig?'completed':'running',fertig?ts:null,ts,tenantId,runId).run();
  await audit(env.DB,auth.userId,'document.run.continued',tenantId,lauf.course_id,'document_run',runId,{produced:anweisungen.length,skipped:uebersprungen.length,remaining:subjects.length-neuerZeiger,completed:fertig});
  return {run_id:runId,produced:anweisungen.length,skipped:uebersprungen,completed:fertig,remaining:subjects.length-neuerZeiger,total:subjects.length};
}

export async function listDocumentRuns(env:Env,auth:CoreAuthContext,tenantId:string,courseId?:string){
  requireRole(auth,'class_admin');
  let sql='SELECT r.id,r.template_id,r.template_version,r.course_id,r.status,r.total_count,r.done_upto,r.created_at,r.completed_at,c.name course_name,t.name template_name FROM document_runs r JOIN courses c ON c.id=r.course_id JOIN document_templates t ON t.id=r.template_id WHERE r.tenant_id=?';
  const args:unknown[]=[tenantId];
  if(courseId){requireCourseAccess(auth,courseId,'class_admin');sql+=' AND r.course_id=?';args.push(courseId);}
  else if(!auth.isPlatformAdmin&&auth.role!=='tenant_admin'){
    if(!auth.courseIds.length)return[];
    sql+=` AND r.course_id IN (${auth.courseIds.map(()=>'?').join(',')})`;args.push(...auth.courseIds);
  }
  sql+=' ORDER BY r.created_at DESC LIMIT 200';
  return (await env.DB.prepare(sql).bind(...args).all<Record<string,unknown>>()).results??[];
}

export async function getDocumentRun(env:Env,auth:CoreAuthContext,tenantId:string,runIdRaw:unknown){
  requireRole(auth,'class_admin');
  const runId=safeString(runIdRaw,120);
  const lauf=await env.DB.prepare('SELECT id,template_id,template_version,course_id,status,total_count,done_upto,created_at,completed_at FROM document_runs WHERE tenant_id=? AND id=?').bind(tenantId,runId).first<Record<string,unknown>>();
  if(!lauf)throw new Error('DOCUMENT_RUN_NOT_FOUND');
  requireCourseAccess(auth,String(lauf.course_id),'class_admin');
  const items=(await env.DB.prepare('SELECT id,position,user_id,subject_name,document_number,title,body FROM document_run_items WHERE tenant_id=? AND run_id=? ORDER BY position LIMIT 500').bind(tenantId,runId).all<Record<string,unknown>>()).results??[];
  return {run:lauf,documents:items};
}

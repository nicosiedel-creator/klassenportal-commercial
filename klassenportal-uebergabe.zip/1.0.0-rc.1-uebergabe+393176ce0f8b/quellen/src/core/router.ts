import type { Env } from './types.js';
import { assertSameOrigin, authStatus, json, safeErrorCode } from './utils.js';
import { changePassword, getSession, login, logout, resolveCoreAuth } from './auth.js';
import { provisionTenant } from './provision.js';
import { createContent, createCourse, deleteContent, deletePersonalGrade, getModules, getSettings, listContent, listCourses, listPersonalGrades, listTenants, savePersonalGrade, setExamVisibility, setModule, updateContent, updateCourse, updatePersonalGrade, updateSettings } from './data.js';
import { publicOverview } from './public.js';
import { requirePlatform } from './permissions.js';
import { createTenantUser, deleteTenantMembership, listTenantUsers, resetTenantUserPassword, updateTenantMembership } from './users.js';
import { uploadTenantLogo } from './branding.js';
import { applyTimetable, getTimetableUpdatePreference, previewTimetable, setTimetableUpdatePreference } from './timetable-v2.js';
import { prepareHierarchyAwareTimetableRequest } from './timetable-hierarchy-targeting.js';
import { storeTimetableSource } from './timetable-source.js';
import { createOnboardingInvitation, getPublicOnboarding, getPublicOnboardingQuote, listOnboardingInvitations, revokeOnboardingInvitation, submitPublicOnboarding } from './onboarding.js';
import { billingSummary, enforceCourseEntitlement, getSellerProfile, listCommercePlans, quoteExpansion, requestExpansion, updateCommercePlan, updateSellerProfile } from './commerce.js';
import { assertTenantWriteAllowed, calculateCommercialOffer, createPaidBooking, getCommercePolicy, listManagedSetupOptions, tenantTrialSummary } from './commerce-offers.js';
import { deleteLearningMaterial, downloadLearningMaterial, listLearningMaterials, updateLearningMaterial, uploadLearningMaterial } from './materials.js';
import { listTenantAudit, listUserNotifications, markAllNotificationsRead, markNotificationRead } from './support.js';
import { closeSurvey, createOrRotateCalendarFeed, createSubstitutionUpdate, createSurvey, deleteSubstitutionUpdate, deleteSurvey, getTeamsIntegration, listCalendarFeeds, listSubstitutionUpdates, listSurveys, saveTeamsIntegration, statisticsSummary, testTeamsIntegration, voteSurvey } from './advanced-modules.js';
import { refererSurface } from './page-routes.js';
import { pruefeGesundheit, sloStand, alarmBedarf } from './observability.js';
import { kostenUebersicht } from './cost-guard.js';
import { placeLegalHold, liftLegalHold, listLegalHolds, saveRetentionPolicy, seedRetentionPolicies, listRetentionPolicies, saveConsentDefinition, recordConsent, consentStatus } from './legal-hold-retention.js';
import { protokollkette, protokollkettePruefen, protokollketteSiegeln, protokollkettenUebersicht } from './immutable-audit.js';
import { acknowledgePolicy, listPolicyDefinitions, policyOverview, policyStatus, savePolicyDefinition, seedPolicyDefinitions } from './policy-acknowledgement.js';
import { createPeriod, setCurrentPeriod, listPeriods, currentPeriod, assignCourseToPeriod, createEvent, createRecurringEvents, moveEvent, cancelEvent, scheduleView } from './schedule-core.js';
import { exportConfiguration, planRestore, restoreConfiguration } from './configuration-backup.js';
import type { Konfigurationssicherung } from './configuration-backup.js';
import { createGuardianship, endGuardianship, listGuardianships, meineMuendel, myGuardians, setOwnGuardianConsent, wardOverview } from './guardianship.js';
import { hebeBeschraenkungAuf, listeBeschraenkungen, setzeHaushalt, verhaengeBeschraenkung } from './access-restrictions.js';
import { fassungen, fassungsinhalt, legeFassungAn, pruefeFassung, veroeffentlicheFassung } from './framework-versions.js';
import { anerkennungLesen, beantrageAnerkennung, entscheideAnerkennung, listeAnerkennungen, meineAnerkennungen, ziehAnerkennungZurueck } from './prior-learning.js';
import { besetzePlaetze, bestaetigeAufsicht, gibSitzungFrei, legeSitzungAn, meineAufsichten, pruefungsplan, sageSitzungAb, teileAufsichtEin } from './exam-scheduling.js';
import { beantrageVorgang, entscheideVorgang, laufbahn, laufbahnUebersicht, vollzieheVorgang } from './enrollment-lifecycle.js';
import { lernplan, meineLernplaene, planeLernen, schrittErledigt } from './learning-plan.js';
import { antworteTicket, eroeffneErneut, eskaliereFaelligeTickets, helpdeskUebersicht, loeseTicket, meinTicket, meineTickets, meldeTicket, schliesseTicket, weiseZu } from './helpdesk.js';
import { artikelFassungen, bearbeiteArtikel, hilfeZuBereich, legeArtikelAn, lesArtikel, listeArtikel, sucheWissen, veroeffentlicheArtikel, ziehArtikelZurueck } from './knowledge-base.js';
import { merkeOnboardingSchritt, onboardingSchritte, schliesseOnboardingAb, ueberspringeOnboardingSchritt } from './onboarding-wizard.js';
import { entscheideFahrt, erteileEinverstaendnis, fahrtenUebersicht, ladeFahrtPersonen, meineFahrten, notfallliste, planeFahrt, sageFahrtAb, sageFahrtZu, weiseFahrtNach } from './excursions.js';
import { legeModellAn, listeModelle, schalteModell } from './ai-gateway.js';
import { bestaetigeKiInhalt, evaluationsvergleich, kiBetriebsstand, kiHerkunft, laufeEvaluation, legeEvaluationsfallAn } from './ai-governance.js';
import { bindeMediumEin, entferneMedium, gibSpurFrei, legeSpurAn, lizenzlauf, medienbibliothek, nimmMediumAuf } from './media-library.js';
import { ausfallpruefung, behebeStoerung, bereiteStoerungNach, besetzeAufgabe, entbindeVonAufgabe, ergaenzeStoerung, legeAufgabeAn, meldeRelease, meldeStoerung, probeRelease, releasestand, rolleReleaseAus, rolleReleaseZurueck, stoerungsstand, vermerkeUebung } from './operations-continuity.js';
import { abonniere, busstand, ereignisspur, nimmZustellungWiederAuf, stelleZu, totfach } from './event-bus.js';
import { bearbeiteVorlage, legeVorlageAn, listeVorlagen, veroeffentlicheVorlage, vorlagenFassungen, vorschau } from './communication-editor.js';
import { entwurfsmappe, erzeugeEntwuerfe, gibEntwurfFrei, uebernimmEntwurf, verwirfEntwurf } from './ai-content-factory.js';
import { brichKiAuftragAb, kiAuftragStand, kiAuftragsmappe, kiEinstufungen, kostenschaetzung } from './ai-workload.js';
import { angebotsfassungen, ansprechbareKontakte, erfasseAktivitaet, gewinneVorgang, haltWerbewiderspruchFest,
  legeKontaktAn, legeOrganisationAn, legeVorgangAn, setzeStufe, verhandleAngebot, verknuepfeAngebot,
  vertriebsauswertung, vorgangsmappe } from './sales-pipeline.js';
import { auditmappe, bestaetigeProzesspruefung, bewertungseingaben, erfasseFeststellung, haltBewertungFest, kennzahlen,
  legeProzessAn, legeZertifikatAn, legeZielAn, planeAudit, prozessregister, schliesseAuditAb, schliesseBewertungAb,
  zertifikate, zielstand } from './quality-management.js';
import { austrittsliste, beendeVertrag, belegeNachweis, entscheideAbwesenheit, erfasseAbwesenheit, erfasseUnterweisung,
  faelligeUnterweisungen, legeAkteAn, legeVertragAn, personalakte, personalliste, schliesseAustrittAb,
  setzeUrlaubsanspruch, urlaubsstand, vollzieheAustritt } from './personnel-file.js';
import { befehlsverlauf, bestaetigeDeutung, schlageVor, verfuegbareBefehle } from './command-center.js';
import { erteileAusnahme, legeResidenzFest, residenzpruefung } from './residency-policy.js';
import { alumnistand, ansprechbareAlumni, beendeAlumnistatus, meineAbschluesse, schliesseAb, setzeKontakteinwilligung } from './alumni.js';
import { angebotsmappe, legeAnlageBei, legeAngebotAn, lehneAngebotAb, leiteMassnahmeplanAb, nimmAngebotAn, pruefeAngebotAktuell, schliesseAbgelaufeneAngebote, versendeAngebot } from './course-offers.js';
import { behebeMangel, bestelle, bucheWareneingang, erfasseGegenstand, fordereAn, gibAus, gibFrei, inventarmappe, lehneAb as lehneBeschaffungAb, meldeMangel, meldeVerlust as meldeGeraetVerlust, mustereAus, nimmZurueck as nimmGeraetZurueck, offeneAusgabenBeiAbgang } from './inventory.js';
import { bibliotheksstand, erfasseTitel, legeExemplarAn, mahneUeberfaellige, meldeVerlust as meldeBuchVerlust, merkeVor, nimmZurueck as nimmBuchZurueck, raeumeAbholfristen, verlaengere, verleihe } from './library.js';
import { baueImportarchiv, emawMappe, erzeugeAnwesenheitMonat, erzeugeAustritt, erzeugeEintritt, erzeugeNichtantritt, nimmEingangAn, ordneZu as ordneEmawZu, setzeProvider, verarbeiteQuittung } from './emaw.js';
import { bewertePlanfassung, konfliktVorschlaege, listPlanRestores, listPlanScores, simuliereFassungsRueckkehr, stellePlanfassungWiederHer, vergleichePlanfassungen } from './plan-variants.js';
import { teilNeuPlanen, teilNeuPlanenVorschau } from './plan-partial-replan.js';
import { applyRhythmToPlan, deleteRhythmRule, listRhythmRules, saveRhythmRule } from './plan-rhythms.js';
import { dokumentfassungen, holeFassungZurueck, speichereDokumentfassung, sucheDokumente } from './document-versions.js';
import { gibFehlerAuf, haengendeVorgaenge, nimmFehlerWiederAuf, offeneAutomationsfehler, vorgangsstand } from './automation-resilience.js';
import { aktiviereRegel, setzeRegelmodus, simulationsbericht } from './workflow-simulation.js';
import { archiviereBogen, beweiskette, entsiegleBogen, gibBogenFrei, protokolliereEinsicht, versiegleBogen } from './exam-custody.js';
import { gleicheErgebnisAb, offeneUnterbrechungen, setzeVersuchFort, unterbrechungen, unterbrichVersuch } from './exam-emergency.js';
import { biteZurAnhoerung, entscheideIntegritaetsfall, eroeffneIntegritaetsfall, gibStellungnahmeAb, integritaetsfallLesen, listeIntegritaetsfaelle, meinIntegritaetsfall, verzichteAufAnhoerung } from './exam-integrity.js';
import { bewerteVorfall, informiereBetroffene, meldeAnBehoerde, meldeVorfall, schliesseVorfall, vorfallLesen, vorfallNotiz, vorfallRegister } from './privacy-incidents.js';
import { bestaetigeKrise, gibEntwarnung, krisenstand, listeKrisen, loeseKriseAus, meineKrisen, setzeNotfallkontakt } from './crisis-communication.js';
import { bearbeiteBeschwerde, beschwerdeLesen, beschwerdeNachSchluessel, listeBeschwerden, meineBeschwerden, reicheBeschwerdeEin } from './complaints.js';
import { benenneFachkraft, entzieheFachkraft, fallLesen, listeFachkraefte, meineMeldungen, meldeSachverhalt, notizHinzufuegen, offeneFaelle, setzeFallstatus } from './safeguarding.js';
import { erteileSupportzugang, listeSupportzugaenge, notfallzugang, pruefeSupportzugang, supportProtokoll, widerrufeSupportzugang } from './support-access.js';
import { submitAbsenceNoticeForWard } from './attendance-classbook.js';

function err(e:unknown):Response{
  const ex=e as Error&{issues?:unknown;targeting?:unknown};const code=safeErrorCode(e);
  const status=authStatus(code)??(code==='UNAUTHENTICATED'||code==='LOGIN_REQUIRED'?401
    :code==='PASSWORD_CHANGE_REQUIRED'?428
    :code==='TRIAL_READ_ONLY'?423
    :code==='TRIAL_EXPIRED'||code==='ONBOARDING_EXPIRED'||code==='ONBOARDING_UNAVAILABLE'?410
    :code.startsWith('FORBIDDEN')||code.includes('ADMIN_REQUIRED')||code==='PLATFORM_ADMIN_REQUIRED'||code==='PLATFORM_ADMIN_RESET_FORBIDDEN'||code==='MODULE_NOT_ACTIVE'||code==='SUPPORT_READ_ONLY'?403
    :code==='RICHTLINIE_NICHT_BESTAETIGT'?403
    :code.includes('NOT_FOUND')?404
    :['ONBOARDING_ALREADY_IN_PROGRESS','ONBOARDING_ALREADY_COMPLETED','ONBOARDING_NOT_OPEN','COURSE_CODE_EXISTS','COURSE_EXTERNAL_ID_EXISTS','COURSE_LIMIT_REACHED','PRICING_NOT_CONFIGURED','SELF_SERVICE_DOWNGRADE_NOT_ALLOWED','NO_CHANGE','PAYMENT_ALREADY_PENDING','TIMETABLE_BATCH_CONFIRMATION_REQUIRED','TIMETABLE_INDIVIDUAL_CONFIRMATION_INVALID','CANNOT_REMOVE_OWN_TENANT_ADMIN','SURVEY_ALREADY_VOTED','SURVEY_CLOSED','IDEMPOTENZ_KONFLIKT'].includes(code)?409
    :code.includes('TOO_LARGE')||code.includes('TOO_MANY')?413
    :code==='LOGIN_RATE_LIMITED'?429
    :code==='INTERNAL_ERROR'?500:400);
  return json({ok:false,error:code,issues:ex?.issues,targeting:ex?.targeting},status);
}
async function body(request:Request):Promise<Record<string,unknown>>{try{const b=await request.json() as Record<string,unknown>;if(b.course_id==='')b.course_id=null;return b;}catch{return{};}}
// Dieselbe Frage wie in blockPlatformSupportWrite, dieselbe Antwortquelle: die Adresstabelle.
// Vorher stand hier ein Vergleich auf die exakte Schreibweise - /KUNDEN-admin galt damit nicht
// als Supportansicht und lieferte volle Plattformrechte in einen Kundenbereich.
function customerSupportRequest(request:Request):boolean{return refererSurface(request.headers.get('referer'))==='kunden';}

export async function handleCoreApi(request:Request,env:Env):Promise<Response|null>{
  const u=new URL(request.url);if(!u.pathname.startsWith('/api/'))return null;
  // Every handler below must be awaited inside this try. Returning a promise from a try block
  // does not route its rejection through the catch, so a thrown domain code would escape to the
  // top-level handler and be answered with 500 instead of its own status.
  try{
    assertSameOrigin(request,env.APP_ORIGIN);
    // Der Health-Endpunkt liest nur. Jede andere Methode ist ein Irrtum des Aufrufers und wird
    // wie überall sonst im Worker mit 405 beantwortet, statt sie stillschweigend zu bestätigen.
    if(u.pathname==='/api/health'){if(request.method!=='GET'&&request.method!=='HEAD')return json({ok:false,error:'METHOD_NOT_ALLOWED'},405);return json({ok:true,service:'klassenportal-commercial'});}
    if(u.pathname==='/api/auth/login'&&request.method==='POST')return await login(env,request);
    if(u.pathname==='/api/auth/logout'&&request.method==='POST')return await logout(env,request);
    if(u.pathname==='/api/auth/me'&&request.method==='GET'){
      const user=await getSession(env,request);
      if(user?.isPlatformAdmin&&customerSupportRequest(request))return json({ok:true,user:{...user,isPlatformAdmin:false,supportPlatformAdmin:true,tenantRoles:[]}});
      return json({ok:true,user});
    }
    if(u.pathname==='/api/auth/change-password'&&request.method==='POST')return await changePassword(env,request);

    const publicQuote=u.pathname.match(/^\/api\/onboarding\/([^/]+)\/quote$/);
    if(publicQuote&&request.method==='GET')return json({ok:true,quote:await getPublicOnboardingQuote(env,decodeURIComponent(publicQuote[1]),{courses:u.searchParams.get('courses')||'1',billingCycle:u.searchParams.get('billing_cycle')||'monthly',setupOptionId:u.searchParams.get('setup')||'self_service',purpose:u.searchParams.get('purpose')||'paid'})});
    const publicOnboarding=u.pathname.match(/^\/api\/onboarding\/([^/]+)$/);
    if(publicOnboarding){const token=decodeURIComponent(publicOnboarding[1]);if(request.method==='GET')return json({ok:true,invitation:await getPublicOnboarding(env,token)});if(request.method==='POST')return json(await submitPublicOnboarding(env,token,request));}

    if(u.pathname==='/api/platform/onboarding-invitations'&&request.method==='GET'){const a=await resolveCoreAuth(env,request);requirePlatform(a);return json({ok:true,invitations:await listOnboardingInvitations(env,a)});}
    if(u.pathname==='/api/platform/onboarding-invitations'&&request.method==='POST'){const a=await resolveCoreAuth(env,request);requirePlatform(a);return json({ok:true,...await createOnboardingInvitation(env,a,request)},201);}
    const revoke=u.pathname.match(/^\/api\/platform\/onboarding-invitations\/([^/]+)\/revoke$/);if(revoke&&request.method==='POST'){const a=await resolveCoreAuth(env,request);requirePlatform(a);await revokeOnboardingInvitation(env,a,decodeURIComponent(revoke[1]));return json({ok:true});}
    if(u.pathname==='/api/platform/commerce/plans'&&request.method==='GET'){const a=await resolveCoreAuth(env,request);return json({ok:true,plans:await listCommercePlans(env,a)});}
    const planCommerce=u.pathname.match(/^\/api\/platform\/commerce\/plans\/([^/]+)$/);if(planCommerce&&request.method==='PUT'){const a=await resolveCoreAuth(env,request);await updateCommercePlan(env,a,decodeURIComponent(planCommerce[1]),await body(request));return json({ok:true});}
    if(u.pathname==='/api/platform/commerce/seller'&&request.method==='GET'){const a=await resolveCoreAuth(env,request);return json({ok:true,profile:await getSellerProfile(env,a)});}
    if(u.pathname==='/api/platform/commerce/seller'&&request.method==='PUT'){const a=await resolveCoreAuth(env,request);await updateSellerProfile(env,a,await body(request));return json({ok:true});}

    const tenantId=u.searchParams.get('tenant_id')||undefined;const courseId=u.searchParams.get('course_id')||undefined;
    if(u.pathname==='/api/platform/tenants'&&request.method==='GET'){const a=await resolveCoreAuth(env,request);return json({ok:true,tenants:await listTenants(env,a)});}
    if(u.pathname==='/api/platform/tenants'&&request.method==='POST'){const a=await resolveCoreAuth(env,request);requirePlatform(a);return json({ok:true,...await provisionTenant(env,a,await body(request))},201);}
    if(!tenantId)throw new Error('TENANT_ID_REQUIRED');
    const a=await resolveCoreAuth(env,request,tenantId,courseId);

    // Das Tor vor den Mandantendaten: ein Plattformkonto ohne eigene Mitgliedschaft in diesem
    // Mandanten kommt nur mit gueltiger, befristeter Freigabe des Traegers hinein - lesend, und
    // jeder Zugriff wie jeder abgewiesene Versuch wird protokolliert.
    // Plattformwege bleiben Plattformwege - dort verwaltet der Betreiber sein eigenes System und
    // sieht keine Mandantendaten. Das Tor steht vor den Wegen des Traegers.
    if(tenantId&&!u.pathname.startsWith('/api/platform/'))await pruefeSupportzugang(env,a,tenantId,request.method,u.pathname);
    if(u.pathname==='/api/platform/support-access/emergency'&&request.method==='POST')return json({ok:true,...await notfallzugang(env,a,tenantId,(await body(request) as Record<string,unknown>).begruendung)},201);
    if(u.pathname==='/api/tenant/support-access'&&request.method==='GET')return json({ok:true,grants:await listeSupportzugaenge(env,a,tenantId),events:await supportProtokoll(env,a,tenantId,Number(u.searchParams.get('limit')||100))});
    if(u.pathname==='/api/tenant/support-access'&&request.method==='POST')return json({ok:true,grant:await erteileSupportzugang(env,a,tenantId,await body(request))},201);
    const sagRev=u.pathname.match(/^\/api\/tenant\/support-access\/([^/]+)\/revoke$/);if(sagRev&&request.method==='POST')return json({ok:true,...await widerrufeSupportzugang(env,a,tenantId,decodeURIComponent(sagRev[1]),(await body(request) as Record<string,unknown>).grund)});

    if(u.pathname==='/api/tenant/audit'&&request.method==='GET')return json({ok:true,events:await listTenantAudit(env,a,tenantId,Number(u.searchParams.get('limit')||100))});
    if(u.pathname==='/api/notifications'&&request.method==='GET')return json({ok:true,notifications:await listUserNotifications(env,a,tenantId,courseId,Number(u.searchParams.get('limit')||80))});
    const notification=u.pathname.match(/^\/api\/notifications\/([^/]+)\/read$/);if(notification&&request.method==='PATCH')return json({ok:true,notification:await markNotificationRead(env,a,tenantId,decodeURIComponent(notification[1]))});
    if(u.pathname==='/api/notifications/read-all'&&request.method==='POST')return json({ok:true,...await markAllNotificationsRead(env,a,tenantId,courseId)});

    if(u.pathname==='/api/modules/statistics'&&request.method==='GET')return json({ok:true,statistics:await statisticsSummary(env,a,tenantId)});
    if(u.pathname==='/api/surveys'&&request.method==='GET')return json({ok:true,surveys:await listSurveys(env,a,tenantId,courseId)});
    if(u.pathname==='/api/surveys'&&request.method==='POST')return json({ok:true,survey:await createSurvey(env,a,tenantId,await body(request))},201);
    const surveyClose=u.pathname.match(/^\/api\/surveys\/([^/]+)\/close$/);if(surveyClose&&request.method==='POST'){await closeSurvey(env,a,tenantId,decodeURIComponent(surveyClose[1]));return json({ok:true});}
    const surveyVote=u.pathname.match(/^\/api\/surveys\/([^/]+)\/vote$/);if(surveyVote&&request.method==='POST'){if(!courseId)throw new Error('COURSE_ID_REQUIRED');const b=await body(request);return json({ok:true,...await voteSurvey(env,a,tenantId,courseId,decodeURIComponent(surveyVote[1]),String(b.option_id||''))});}
    const survey=u.pathname.match(/^\/api\/surveys\/([^/]+)$/);if(survey&&request.method==='DELETE'){await deleteSurvey(env,a,tenantId,decodeURIComponent(survey[1]));return json({ok:true});}
    if(u.pathname==='/api/substitutions'&&request.method==='GET')return json({ok:true,updates:await listSubstitutionUpdates(env,a,tenantId,courseId)});
    if(u.pathname==='/api/substitutions'&&request.method==='POST')return json({ok:true,update:await createSubstitutionUpdate(env,a,tenantId,await body(request))},201);
    const substitution=u.pathname.match(/^\/api\/substitutions\/([^/]+)$/);if(substitution&&request.method==='DELETE'){await deleteSubstitutionUpdate(env,a,tenantId,decodeURIComponent(substitution[1]));return json({ok:true});}
    if(u.pathname==='/api/integrations/teams'&&request.method==='GET')return json({ok:true,integration:await getTeamsIntegration(env,a,tenantId)});
    if(u.pathname==='/api/integrations/teams'&&request.method==='PUT')return json({ok:true,integration:await saveTeamsIntegration(env,a,tenantId,await body(request))});
    if(u.pathname==='/api/integrations/teams/test'&&request.method==='POST')return json({ok:true,...await testTeamsIntegration(env,a,tenantId)});
    if(u.pathname==='/api/integrations/microsoft365/feeds'&&request.method==='GET')return json({ok:true,feeds:await listCalendarFeeds(env,a,tenantId,env.APP_ORIGIN||u.origin)});
    if(u.pathname==='/api/integrations/microsoft365/feeds'&&request.method==='POST'){const b=await body(request),cid=String(b.course_id||courseId||'');if(!cid)throw new Error('COURSE_ID_REQUIRED');return json({ok:true,feed:await createOrRotateCalendarFeed(env,a,tenantId,cid,env.APP_ORIGIN||u.origin)});}

    if(u.pathname==='/api/billing/summary'&&request.method==='GET')return json({ok:true,...await billingSummary(env,a,tenantId),trial:await tenantTrialSummary(env,a,tenantId),commercePolicy:await getCommercePolicy(env),setupOptions:await listManagedSetupOptions(env)});
    if(u.pathname==='/api/billing/trial-quote'&&request.method==='POST'){const b=await body(request);const trial=await tenantTrialSummary(env,a,tenantId);if(!trial||!['active','read_only'].includes(String(trial.status||'')))throw new Error('TRIAL_NOT_CONVERTIBLE');return json({ok:true,quote:await calculateCommercialOffer(env,{planId:String(b.plan_id||trial.target_plan_id),courseCount:Number(b.course_count||trial.requested_course_count),billingCycle:b.billing_cycle,setupOptionId:b.managed_setup_option_id||'self_service',purpose:'paid'})});}
    if(u.pathname==='/api/billing/change-quote'&&request.method==='POST')return json({ok:true,quote:await quoteExpansion(env,a,tenantId,await body(request))});
    if(u.pathname==='/api/billing/expand'&&request.method==='POST'){const b=await body(request);if(b.confirm_change!==true||b.confirm_costs!==true)throw new Error('DOUBLE_COST_CONFIRMATION_REQUIRED');return json({ok:true,...await requestExpansion(env,a,tenantId,b)},201);}
    if(u.pathname==='/api/billing/convert-trial'&&request.method==='POST'){const b=await body(request);if(b.confirm_change!==true||b.confirm_costs!==true)throw new Error('DOUBLE_COST_CONFIRMATION_REQUIRED');const trial=await tenantTrialSummary(env,a,tenantId);if(!trial||!['active','read_only'].includes(String(trial.status||'')))throw new Error('TRIAL_NOT_CONVERTIBLE');return json({ok:true,...await createPaidBooking(env,{tenantId,planId:String(b.plan_id||trial.target_plan_id),courseCount:Number(b.course_count||trial.requested_course_count),billingCycle:b.billing_cycle,setupOptionId:b.managed_setup_option_id,accepted:true,request,actorId:a.userId})},201);}

    if(u.pathname==='/api/timetable/preferences'&&request.method==='GET')return json({ok:true,...await getTimetableUpdatePreference(env,a,tenantId)});
    const mutating=request.method!=='GET'&&request.method!=='HEAD'&&u.pathname!=='/api/timetable/preview';if(mutating)await assertTenantWriteAllowed(env,tenantId);
    if(u.pathname==='/api/timetable/preferences'&&request.method==='PUT')return json({ok:true,...await setTimetableUpdatePreference(env,a,tenantId,await body(request))});
    if(u.pathname==='/api/tenant/logo'&&request.method==='POST')return json({ok:true,...await uploadTenantLogo(env,a,tenantId,request)});
    if(u.pathname==='/api/timetable/preview'&&request.method==='POST'){const h=await prepareHierarchyAwareTimetableRequest(env,a,tenantId,request.clone());const source=h.targeting?h.request:request;return json({ok:true,...await previewTimetable(env,a,tenantId,source),targeting:h.targeting});}
    if(u.pathname==='/api/timetable/apply'&&request.method==='POST'){const h=await prepareHierarchyAwareTimetableRequest(env,a,tenantId,request.clone());const source=h.targeting?h.request:request;return json({ok:true,...await applyTimetable(env,a,tenantId,source),targeting:h.targeting});}
    if(u.pathname==='/api/timetable/source'&&request.method==='POST')return json({ok:true,...await storeTimetableSource(env,a,tenantId,request)});
    if(u.pathname==='/api/tenant/settings'&&request.method==='GET')return json({ok:true,settings:await getSettings(env,a,tenantId)});
    if(u.pathname==='/api/tenant/settings'&&request.method==='PUT')return json({ok:true,settings:await updateSettings(env,a,tenantId,await body(request))});
    if(u.pathname==='/api/tenant/modules'&&request.method==='GET')return json({ok:true,modules:await getModules(env,a,tenantId)});
    if(u.pathname==='/api/tenant/modules'&&request.method==='PUT'){const b=await body(request);await setModule(env,a,tenantId,String(b.feature_key||''),!!b.enabled);return json({ok:true});}

    if(u.pathname==='/api/courses'&&request.method==='GET')return json({ok:true,courses:await listCourses(env,a,tenantId)});
    if(u.pathname==='/api/courses'&&request.method==='POST'){await enforceCourseEntitlement(env,tenantId);return json({ok:true,course:await createCourse(env,a,tenantId,await body(request))},201);}
    const courseRoute=u.pathname.match(/^\/api\/courses\/([^/]+)$/);
    if(courseRoute&&request.method==='PATCH')return json({ok:true,course:await updateCourse(env,a,tenantId,decodeURIComponent(courseRoute[1]),await body(request))});

    if(u.pathname==='/api/tenant/users'&&request.method==='GET')return json({ok:true,users:await listTenantUsers(env,a,tenantId)});
    if(u.pathname==='/api/tenant/users'&&request.method==='POST')return json({ok:true,...await createTenantUser(env,a,tenantId,await body(request))},201);
    const passwordReset=u.pathname.match(/^\/api\/tenant\/users\/([^/]+)\/reset-password$/);
    if(passwordReset&&request.method==='POST')return json({ok:true,...await resetTenantUserPassword(env,a,tenantId,decodeURIComponent(passwordReset[1]))});
    const membership=u.pathname.match(/^\/api\/tenant\/memberships\/([^/]+)$/);
    if(membership&&request.method==='PATCH')return json({ok:true,membership:await updateTenantMembership(env,a,tenantId,decodeURIComponent(membership[1]),await body(request))});
    if(membership&&request.method==='DELETE'){await deleteTenantMembership(env,a,tenantId,decodeURIComponent(membership[1]));return json({ok:true});}

    if(u.pathname==='/api/materials'&&request.method==='GET')return json({ok:true,materials:await listLearningMaterials(env,a,tenantId,courseId)});
    if(u.pathname==='/api/materials'&&request.method==='POST')return json({ok:true,material:await uploadLearningMaterial(env,a,tenantId,request,courseId)},201);
    const materialDownload=u.pathname.match(/^\/api\/materials\/([^/]+)\/download$/);
    if(materialDownload&&request.method==='GET')return await downloadLearningMaterial(env,a,tenantId,decodeURIComponent(materialDownload[1]));
    const material=u.pathname.match(/^\/api\/materials\/([^/]+)$/);
    if(material&&request.method==='PATCH')return json({ok:true,material:await updateLearningMaterial(env,a,tenantId,decodeURIComponent(material[1]),await body(request))});
    if(material&&request.method==='DELETE'){await deleteLearningMaterial(env,a,tenantId,decodeURIComponent(material[1]));return json({ok:true});}

    const contentRow=u.pathname.match(/^\/api\/content\/([^/]+)\/([^/]+)$/);
    if(contentRow&&request.method==='PATCH')return json({ok:true,item:await updateContent(env,a,tenantId,decodeURIComponent(contentRow[1]),decodeURIComponent(contentRow[2]),await body(request))});
    if(contentRow&&request.method==='DELETE'){await deleteContent(env,a,tenantId,decodeURIComponent(contentRow[1]),decodeURIComponent(contentRow[2]));return json({ok:true});}
    if(u.pathname.startsWith('/api/content/')){const type=u.pathname.split('/')[3]||'';if(request.method==='GET')return json({ok:true,items:await listContent(env,a,tenantId,type,courseId)});if(request.method==='POST')return json({ok:true,item:await createContent(env,a,tenantId,type,await body(request))},201);}
    if(u.pathname.match(/^\/api\/exams\/[^/]+\/visibility$/)&&request.method==='PATCH'){const examId=u.pathname.split('/')[3];const b=await body(request);await setExamVisibility(env,a,tenantId,examId,!!b.visible);return json({ok:true});}

    // Betriebsbeobachtung und Kosten - Sache der Plattformverwaltung.
    if(u.pathname==='/api/platform/health'&&request.method==='GET'){requirePlatform(a);return json({ok:true,...await pruefeGesundheit(env)});}
    if(u.pathname==='/api/platform/slo'&&request.method==='GET'){requirePlatform(a);return json({ok:true,slos:await sloStand(env),alarme:await alarmBedarf(env)});}
    if(u.pathname==='/api/platform/costs'&&request.method==='GET')return json({ok:true,...await kostenUebersicht(env,a,u.searchParams.get('for_tenant')||tenantId)});
    // Löschsperre, Aufbewahrungsfristen und Einwilligungen.
    if(u.pathname==='/api/compliance/legal-holds'&&request.method==='GET')return json({ok:true,holds:await listLegalHolds(env,a,tenantId)});
    if(u.pathname==='/api/compliance/legal-holds'&&request.method==='POST')return json({ok:true,hold:await placeLegalHold(env,a,tenantId,await body(request))},201);
    const lh=u.pathname.match(/^\/api\/compliance\/legal-holds\/([^/]+)$/);if(lh&&request.method==='DELETE')return json({ok:true,...await liftLegalHold(env,a,tenantId,decodeURIComponent(lh[1]),String((await body(request)).grund||''))});
    if(u.pathname==='/api/compliance/retention'&&request.method==='GET')return json({ok:true,policies:await listRetentionPolicies(env,a,tenantId)});
    if(u.pathname==='/api/compliance/retention'&&request.method==='PUT')return json({ok:true,policy:await saveRetentionPolicy(env,a,tenantId,await body(request))});
    if(u.pathname==='/api/compliance/retention/seed'&&request.method==='POST')return json({ok:true,policies:await seedRetentionPolicies(env,a,tenantId)},201);
    // Die Protokollkette: Stand, Pruefung auf Verlangen, Siegel. Der Kettenname kommt aus dem
    // angemeldeten Zugriff und nie aus der Anfrage - sonst waere das Protokoll fremder Traeger
    // ueber den Umweg der Pruefung lesbar.
    if(u.pathname==='/api/compliance/audit-chain'&&request.method==='GET')return json({ok:true,...await protokollkette(env,a,tenantId)});
    if(u.pathname==='/api/compliance/audit-chain/verify'&&request.method==='POST'){const b2=await body(request);return json({ok:true,bericht:await protokollkettePruefen(env,a,tenantId,Number(b2.ab||1),Number(b2.limit||500))});}
    if(u.pathname==='/api/compliance/audit-chain/seal'&&request.method==='POST')return json({ok:true,...await protokollketteSiegeln(env,a,tenantId)},201);
    if(u.pathname==='/api/platform/audit-chains'&&request.method==='GET')return json({ok:true,ketten:await protokollkettenUebersicht(env,a,Number(u.searchParams.get('grenze')||50))});
    if(u.pathname==='/api/compliance/consents'&&request.method==='POST')return json({ok:true,definition:await saveConsentDefinition(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/personal/consents'&&request.method==='GET')return json({ok:true,consents:await consentStatus(env,a,tenantId,u.searchParams.get('user_id')||a.userId)});
    if(u.pathname==='/api/personal/consents'&&request.method==='POST')return json({ok:true,record:await recordConsent(env,a,tenantId,await body(request))},201);
    // Richtlinienbestaetigung: wer hat WELCHE FASSUNG WANN bestaetigt. Eine Einwilligung ist
    // freiwillig und widerrufbar, eine Richtlinie verpflichtend und nicht widerrufbar - deshalb
    // eigene Wege und nicht ein Sonderfall der Einwilligung.
    if(u.pathname==='/api/compliance/policies'&&request.method==='GET')return json({ok:true,policies:await listPolicyDefinitions(env,a,tenantId)});
    if(u.pathname==='/api/compliance/policies'&&request.method==='POST')return json({ok:true,policy:await savePolicyDefinition(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/compliance/policies/seed'&&request.method==='POST')return json({ok:true,policies:await seedPolicyDefinitions(env,a,tenantId)},201);
    if(u.pathname==='/api/compliance/policies/overview'&&request.method==='GET')return json({ok:true,...await policyOverview(env,a,tenantId,Number(u.searchParams.get('grenze')||200))});
    if(u.pathname==='/api/personal/policies'&&request.method==='GET')return json({ok:true,policies:await policyStatus(env,a,tenantId,u.searchParams.get('user_id')||a.userId)});
    if(u.pathname==='/api/personal/policies'&&request.method==='POST')return json({ok:true,acknowledgement:await acknowledgePolicy(env,a,tenantId,await body(request))},201);
    // Schuljahr/Periode und das gemeinsame Terminobjekt.
    if(u.pathname==='/api/schedule/periods'&&request.method==='GET')return json({ok:true,periods:await listPeriods(env,a,tenantId),current:await currentPeriod(env,tenantId)});
    if(u.pathname==='/api/schedule/periods'&&request.method==='POST')return json({ok:true,period:await createPeriod(env,a,tenantId,await body(request))},201);
    const perC=u.pathname.match(/^\/api\/schedule\/periods\/([^/]+)\/current$/);if(perC&&request.method==='PUT')return json({ok:true,...await setCurrentPeriod(env,a,tenantId,decodeURIComponent(perC[1]))});
    const perK=u.pathname.match(/^\/api\/schedule\/courses\/([^/]+)\/period$/);if(perK&&request.method==='PUT'){const b=await body(request);return json({ok:true,...await assignCourseToPeriod(env,a,tenantId,decodeURIComponent(perK[1]),b.period_id?String(b.period_id):null)});}
    if(u.pathname==='/api/schedule/events'&&request.method==='GET')return json({ok:true,events:await scheduleView(env,a,tenantId,u.searchParams.get('von')||new Date().toISOString(),u.searchParams.get('bis')||new Date(Date.now()+2592000000).toISOString(),courseId||undefined)});
    if(u.pathname==='/api/schedule/events'&&request.method==='POST')return json({ok:true,event:await createEvent(env,a,tenantId,courseId||null,await body(request))},201);
    if(u.pathname==='/api/schedule/events/recurring'&&request.method==='POST'){if(!courseId)throw new Error('COURSE_ID_REQUIRED');return json({ok:true,...await createRecurringEvents(env,a,tenantId,courseId,await body(request))},201);}
    const evM=u.pathname.match(/^\/api\/schedule\/events\/([^/]+)$/);if(evM&&request.method==='PUT')return json({ok:true,event:await moveEvent(env,a,tenantId,decodeURIComponent(evM[1]),await body(request))});
    if(evM&&request.method==='DELETE')return json({ok:true,...await cancelEvent(env,a,tenantId,decodeURIComponent(evM[1]),(u.searchParams.get('grund')||undefined))});
    // Konfigurationssicherung: die Daten waren exportierbar, die Einstellungen nicht.
    if(u.pathname==='/api/tenant/configuration/export'&&request.method==='GET')return json({ok:true,configuration:await exportConfiguration(env,a,tenantId)});
    if(u.pathname==='/api/tenant/configuration/plan'&&request.method==='POST')return json({ok:true,...await planRestore(env,a,tenantId,(await body(request)).configuration as Konfigurationssicherung)});
    if(u.pathname==='/api/tenant/configuration/restore'&&request.method==='POST')return json({ok:true,...await restoreConfiguration(env,a,tenantId,(await body(request)).configuration as Konfigurationssicherung)});
    // Elternzugang. Jeder dieser Wege prueft die Verknuepfung selbst; die Kennung des Kindes wird
    // nie aus der Anfrage uebernommen, ohne dass sie gegen die Verknuepfung geprueft wurde.
    if(u.pathname==='/api/guardian/wards'&&request.method==='GET')return json({ok:true,wards:await meineMuendel(env,a,tenantId)});
    const ward=u.pathname.match(/^\/api\/guardian\/wards\/([^/]+)$/);if(ward&&request.method==='GET')return json({ok:true,...await wardOverview(env,a,tenantId,decodeURIComponent(ward[1]))});
    const wardAbs=u.pathname.match(/^\/api\/guardian\/wards\/([^/]+)\/absence-notices$/);if(wardAbs&&request.method==='POST'){if(!courseId)throw new Error('COURSE_ID_REQUIRED');return json({ok:true,notice:await submitAbsenceNoticeForWard(env,a,tenantId,courseId,decodeURIComponent(wardAbs[1]),await body(request))},201);}
    const rfvListe=u.pathname.match(/^\/api\/frameworks\/([^/]+)\/versions$/);if(rfvListe&&request.method==='GET')return json({ok:true,fassungen:await fassungen(env,a,tenantId,decodeURIComponent(rfvListe[1]))});
    if(rfvListe&&request.method==='POST')return json({ok:true,...await legeFassungAn(env,a,tenantId,decodeURIComponent(rfvListe[1]),await body(request))},201);
    const rfvInhalt=u.pathname.match(/^\/api\/framework-versions\/([^/]+)$/);if(rfvInhalt&&request.method==='GET')return json({ok:true,...await fassungsinhalt(env,a,tenantId,decodeURIComponent(rfvInhalt[1]))});
    const rfvPub=u.pathname.match(/^\/api\/framework-versions\/([^/]+)\/publish$/);if(rfvPub&&request.method==='POST')return json({ok:true,...await veroeffentlicheFassung(env,a,tenantId,decodeURIComponent(rfvPub[1]),(await body(request) as Record<string,unknown>).gueltig_ab)});
    const rfvChk=u.pathname.match(/^\/api\/framework-versions\/([^/]+)\/verify$/);if(rfvChk&&request.method==='GET')return json({ok:true,...await pruefeFassung(env,a,tenantId,decodeURIComponent(rfvChk[1]))});
    if(u.pathname==='/api/prior-learning'&&request.method==='POST')return json({ok:true,...await beantrageAnerkennung(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/prior-learning'&&request.method==='GET')return json({ok:true,antraege:await listeAnerkennungen(env,a,tenantId,u.searchParams.get('alle')!=='1')});
    if(u.pathname==='/api/personal/prior-learning'&&request.method==='GET')return json({ok:true,antraege:await meineAnerkennungen(env,a,tenantId)});
    const vorLesen=u.pathname.match(/^\/api\/prior-learning\/([^/]+)$/);if(vorLesen&&request.method==='GET')return json({ok:true,...await anerkennungLesen(env,a,tenantId,decodeURIComponent(vorLesen[1]))});
    const vorEnt=u.pathname.match(/^\/api\/prior-learning\/([^/]+)\/decision$/);if(vorEnt&&request.method==='POST')return json({ok:true,...await entscheideAnerkennung(env,a,tenantId,decodeURIComponent(vorEnt[1]),await body(request))});
    if(u.pathname==='/api/exam-sittings'&&request.method==='POST')return json({ok:true,...await legeSitzungAn(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/personal/exam-supervisions'&&request.method==='GET')return json({ok:true,sitzungen:await meineAufsichten(env,a,tenantId)});
    const psPlan=u.pathname.match(/^\/api\/exams\/([^/]+)\/sittings$/);if(psPlan&&request.method==='GET')return json({ok:true,...await pruefungsplan(env,a,tenantId,decodeURIComponent(psPlan[1]))});
    const psSitz=u.pathname.match(/^\/api\/exam-sittings\/([^/]+)\/seats$/);if(psSitz&&request.method==='POST')return json({ok:true,...await besetzePlaetze(env,a,tenantId,decodeURIComponent(psSitz[1]),((await body(request) as Record<string,unknown>).user_ids as string[])??[])});
    const psAuf=u.pathname.match(/^\/api\/exam-sittings\/([^/]+)\/supervisors$/);if(psAuf&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await teileAufsichtEin(env,a,tenantId,decodeURIComponent(psAuf[1]),String(d.user_id??''),String(d.rolle??'aufsicht'))});}
    const psBes=u.pathname.match(/^\/api\/exam-sittings\/([^/]+)\/confirm$/);if(psBes&&request.method==='POST')return json({ok:true,...await bestaetigeAufsicht(env,a,tenantId,decodeURIComponent(psBes[1]))});
    const psFrei=u.pathname.match(/^\/api\/exam-sittings\/([^/]+)\/release$/);if(psFrei&&request.method==='POST')return json({ok:true,...await gibSitzungFrei(env,a,tenantId,decodeURIComponent(psFrei[1]))});
    const psAb=u.pathname.match(/^\/api\/exam-sittings\/([^/]+)\/cancel$/);if(psAb&&request.method==='POST')return json({ok:true,...await sageSitzungAb(env,a,tenantId,decodeURIComponent(psAb[1]),String((await body(request) as Record<string,unknown>).grund??''))});
    if(u.pathname==='/api/enrollment-transitions'&&request.method==='POST')return json({ok:true,...await beantrageVorgang(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/enrollment-transitions'&&request.method==='GET')return json({ok:true,...await laufbahnUebersicht(env,a,tenantId,u.searchParams.get('heute')??undefined)});
    if(u.pathname==='/api/personal/enrollment-history'&&request.method==='GET')return json({ok:true,...await laufbahn(env,a,tenantId,u.searchParams.get('user_id')??a.userId)});
    const lbEnt=u.pathname.match(/^\/api\/enrollment-transitions\/([^/]+)\/decision$/);if(lbEnt&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await entscheideVorgang(env,a,tenantId,decodeURIComponent(lbEnt[1]),d.genehmigt===true,String(d.begruendung??''))});}
    const lbVoll=u.pathname.match(/^\/api\/enrollment-transitions\/([^/]+)\/execute$/);if(lbVoll&&request.method==='POST')return json({ok:true,...await vollzieheVorgang(env,a,tenantId,decodeURIComponent(lbVoll[1]))});
    if(u.pathname==='/api/learning-plans'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await planeLernen(env,a,tenantId,String(d.course_id??''),String(d.user_id??a.userId),d)},201);}
    if(u.pathname==='/api/personal/learning-plans'&&request.method==='GET')return json({ok:true,plaene:await meineLernplaene(env,a,tenantId)});
    const lpLesen=u.pathname.match(/^\/api\/learning-plans\/([^/]+)$/);if(lpLesen&&request.method==='GET')return json({ok:true,...await lernplan(env,a,tenantId,decodeURIComponent(lpLesen[1]))});
    const lpFertig=u.pathname.match(/^\/api\/learning-plan-steps\/([^/]+)\/done$/);if(lpFertig&&request.method==='POST')return json({ok:true,...await schrittErledigt(env,a,tenantId,decodeURIComponent(lpFertig[1]),String((await body(request) as Record<string,unknown>).bemerkung??''))});
    if(u.pathname==='/api/helpdesk/tickets'&&request.method==='POST')return json({ok:true,...await meldeTicket(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/helpdesk/tickets'&&request.method==='GET')return json({ok:true,...await helpdeskUebersicht(env,a,tenantId,u.searchParams.get('jetzt')??undefined)});
    if(u.pathname==='/api/helpdesk/escalate'&&request.method==='POST')return json({ok:true,...await eskaliereFaelligeTickets(env,tenantId)});
    if(u.pathname==='/api/personal/helpdesk/tickets'&&request.method==='GET')return json({ok:true,tickets:await meineTickets(env,a,tenantId)});
    const hdLesen=u.pathname.match(/^\/api\/helpdesk\/tickets\/([^/]+)$/);if(hdLesen&&request.method==='GET')return json({ok:true,...await meinTicket(env,a,tenantId,decodeURIComponent(hdLesen[1]))});
    const hdZu=u.pathname.match(/^\/api\/helpdesk\/tickets\/([^/]+)\/assign$/);if(hdZu&&request.method==='POST')return json({ok:true,...await weiseZu(env,a,tenantId,decodeURIComponent(hdZu[1]),String((await body(request) as Record<string,unknown>).user_id??''))});
    const hdAnt=u.pathname.match(/^\/api\/helpdesk\/tickets\/([^/]+)\/reply$/);if(hdAnt&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await antworteTicket(env,a,tenantId,decodeURIComponent(hdAnt[1]),String(d.text??''),d.intern===true)});}
    const hdLoe=u.pathname.match(/^\/api\/helpdesk\/tickets\/([^/]+)\/resolve$/);if(hdLoe&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await loeseTicket(env,a,tenantId,decodeURIComponent(hdLoe[1]),String(d.loesung??''),d.artikel_id?String(d.artikel_id):undefined)});}
    const hdNeu=u.pathname.match(/^\/api\/helpdesk\/tickets\/([^/]+)\/reopen$/);if(hdNeu&&request.method==='POST')return json({ok:true,...await eroeffneErneut(env,a,tenantId,decodeURIComponent(hdNeu[1]),String((await body(request) as Record<string,unknown>).grund??''))});
    const hdZu2=u.pathname.match(/^\/api\/helpdesk\/tickets\/([^/]+)\/close$/);if(hdZu2&&request.method==='POST')return json({ok:true,...await schliesseTicket(env,a,tenantId,decodeURIComponent(hdZu2[1]))});
    if(u.pathname==='/api/knowledge/articles'&&request.method==='POST')return json({ok:true,...await legeArtikelAn(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/knowledge/articles'&&request.method==='GET')return json({ok:true,artikel:await listeArtikel(env,a,tenantId)});
    if(u.pathname==='/api/knowledge/search'&&request.method==='GET')return json({ok:true,treffer:await sucheWissen(env,a,tenantId,u.searchParams.get('q')??'')});
    if(u.pathname==='/api/knowledge/context'&&request.method==='GET')return json({ok:true,artikel:await hilfeZuBereich(env,a,tenantId,u.searchParams.get('bereich')??'')});
    const wiLesen=u.pathname.match(/^\/api\/knowledge\/articles\/([^/]+)$/);if(wiLesen&&request.method==='GET')return json({ok:true,...await lesArtikel(env,a,tenantId,decodeURIComponent(wiLesen[1]))});
    const wiEdit=u.pathname.match(/^\/api\/knowledge\/articles\/([^/]+)$/);if(wiEdit&&request.method==='PATCH')return json({ok:true,...await bearbeiteArtikel(env,a,tenantId,decodeURIComponent(wiEdit[1]),await body(request))});
    const wiPub=u.pathname.match(/^\/api\/knowledge\/articles\/([^/]+)\/publish$/);if(wiPub&&request.method==='POST')return json({ok:true,...await veroeffentlicheArtikel(env,a,tenantId,decodeURIComponent(wiPub[1]))});
    const wiWeg=u.pathname.match(/^\/api\/knowledge\/articles\/([^/]+)\/withdraw$/);if(wiWeg&&request.method==='POST')return json({ok:true,...await ziehArtikelZurueck(env,a,tenantId,decodeURIComponent(wiWeg[1]))});
    const wiFas=u.pathname.match(/^\/api\/knowledge\/articles\/([^/]+)\/versions$/);if(wiFas&&request.method==='GET')return json({ok:true,fassungen:await artikelFassungen(env,a,tenantId,decodeURIComponent(wiFas[1]))});
    if(u.pathname==='/api/onboarding/wizard'&&request.method==='GET')return json({ok:true,...await onboardingSchritte(env,a,tenantId)});
    if(u.pathname==='/api/onboarding/wizard/position'&&request.method==='POST')return json({ok:true,...await merkeOnboardingSchritt(env,a,tenantId,String((await body(request) as Record<string,unknown>).schritt??''))});
    if(u.pathname==='/api/onboarding/wizard/skip'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await ueberspringeOnboardingSchritt(env,a,tenantId,String(d.schritt??''),String(d.grund??''))});}
    if(u.pathname==='/api/onboarding/wizard/finish'&&request.method==='POST')return json({ok:true,...await schliesseOnboardingAb(env,a,tenantId)});
    if(u.pathname==='/api/excursions'&&request.method==='POST')return json({ok:true,...await planeFahrt(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/excursions'&&request.method==='GET')return json({ok:true,...await fahrtenUebersicht(env,a,tenantId)});
    if(u.pathname==='/api/personal/excursions'&&request.method==='GET')return json({ok:true,fahrten:await meineFahrten(env,a,tenantId)});
    const exPer=u.pathname.match(/^\/api\/excursions\/([^/]+)\/participants$/);if(exPer&&request.method==='POST')return json({ok:true,...await ladeFahrtPersonen(env,a,tenantId,decodeURIComponent(exPer[1]),((await body(request) as Record<string,unknown>).personen as {user_id:string;rolle?:string}[])??[])});
    const exZu=u.pathname.match(/^\/api\/excursions\/([^/]+)\/rsvp$/);if(exZu&&request.method==='POST')return json({ok:true,...await sageFahrtZu(env,a,tenantId,decodeURIComponent(exZu[1]),(await body(request) as Record<string,unknown>).zusage===true)});
    const exEin=u.pathname.match(/^\/api\/excursions\/([^/]+)\/consent$/);if(exEin&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await erteileEinverstaendnis(env,a,tenantId,decodeURIComponent(exEin[1]),String(d.user_id??a.userId),(d.notfall as Record<string,unknown>)??{})});}
    const exkEnt=u.pathname.match(/^\/api\/excursions\/([^/]+)\/decision$/);if(exkEnt&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await entscheideFahrt(env,a,tenantId,decodeURIComponent(exkEnt[1]),d.genehmigt===true,String(d.begruendung??''))});}
    const exNot=u.pathname.match(/^\/api\/excursions\/([^/]+)\/emergency-list$/);if(exNot&&request.method==='GET')return json({ok:true,...await notfallliste(env,a,tenantId,decodeURIComponent(exNot[1]))});
    const exNach=u.pathname.match(/^\/api\/excursions\/([^/]+)\/report$/);if(exNach&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await weiseFahrtNach(env,a,tenantId,decodeURIComponent(exNach[1]),String(d.bericht??''),(d.teilgenommen as string[])??[])});}
    const exAb=u.pathname.match(/^\/api\/excursions\/([^/]+)\/cancel$/);if(exAb&&request.method==='POST')return json({ok:true,...await sageFahrtAb(env,a,tenantId,decodeURIComponent(exAb[1]),String((await body(request) as Record<string,unknown>).grund??''))});
    if(u.pathname==='/api/ai/models'&&request.method==='POST')return json({ok:true,...await legeModellAn(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/ai/models'&&request.method==='GET')return json({ok:true,modelle:await listeModelle(env,a,tenantId)});
    if(u.pathname==='/api/ai/status'&&request.method==='GET')return json({ok:true,...await kiBetriebsstand(env,a,tenantId,u.searchParams.get('seit')??undefined)});
    if(u.pathname==='/api/ai/evaluation/cases'&&request.method==='POST')return json({ok:true,...await legeEvaluationsfallAn(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/ai/evaluation/runs'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await laufeEvaluation(env,a,tenantId,String(d.modell_id??''),String(d.zweck??''))});}
    if(u.pathname==='/api/ai/evaluation/comparison'&&request.method==='GET')return json({ok:true,...await evaluationsvergleich(env,a,tenantId,u.searchParams.get('zweck')??'')});
    if(u.pathname==='/api/ai/provenance'&&request.method==='GET')return json({ok:true,herkunft:await kiHerkunft(env,tenantId,u.searchParams.get('objekt_typ')??'',u.searchParams.get('objekt_id')??'')});
    if(u.pathname==='/api/ai/provenance/confirm'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await bestaetigeKiInhalt(env,a,tenantId,String(d.objekt_typ??''),String(d.objekt_id??''),String(d.feld??''))});}
    const kiMod=u.pathname.match(/^\/api\/ai\/models\/([^/]+)\/toggle$/);if(kiMod&&request.method==='POST')return json({ok:true,...await schalteModell(env,a,tenantId,decodeURIComponent(kiMod[1]),(await body(request) as Record<string,unknown>).aktiv===true)});
    if(u.pathname==='/api/media'&&request.method==='POST')return json({ok:true,...await nimmMediumAuf(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/media'&&request.method==='GET')return json({ok:true,...await medienbibliothek(env,a,tenantId,u.searchParams.get('art')??undefined)});
    if(u.pathname==='/api/media/licence-check'&&request.method==='GET')return json({ok:true,...await lizenzlauf(env,a,tenantId,u.searchParams.get('heute')??undefined)});
    const medEin=u.pathname.match(/^\/api\/media\/([^/]+)\/usage$/);if(medEin&&request.method==='POST')return json({ok:true,...await bindeMediumEin(env,a,tenantId,decodeURIComponent(medEin[1]),await body(request))});
    const medSpur=u.pathname.match(/^\/api\/media\/([^/]+)\/tracks$/);if(medSpur&&request.method==='POST')return json({ok:true,...await legeSpurAn(env,a,tenantId,decodeURIComponent(medSpur[1]),await body(request))});
    const medFrei=u.pathname.match(/^\/api\/media\/([^/]+)\/tracks\/approve$/);if(medFrei&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await gibSpurFrei(env,a,tenantId,decodeURIComponent(medFrei[1]),String(d.art??'untertitel'),String(d.sprache??'de'))});}
    const medWeg=u.pathname.match(/^\/api\/media\/([^/]+)$/);if(medWeg&&request.method==='DELETE')return json({ok:true,...await entferneMedium(env,a,tenantId,decodeURIComponent(medWeg[1]))});
    if(u.pathname==='/api/operations/releases'&&request.method==='POST')return json({ok:true,...await meldeRelease(env,a,await body(request))},201);
    if(u.pathname==='/api/operations/releases'&&request.method==='GET')return json({ok:true,...await releasestand(env,a)});
    if(u.pathname==='/api/operations/incidents'&&request.method==='POST')return json({ok:true,...await meldeStoerung(env,a,tenantId||null,await body(request))},201);
    if(u.pathname==='/api/operations/incidents'&&request.method==='GET')return json({ok:true,...await stoerungsstand(env,a)});
    if(u.pathname==='/api/operations/duties'&&request.method==='POST')return json({ok:true,...await legeAufgabeAn(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/operations/duties'&&request.method==='GET')return json({ok:true,...await ausfallpruefung(env,a,tenantId,u.searchParams.get('heute')??undefined)});
    if(u.pathname==='/api/operations/duties/assign'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await besetzeAufgabe(env,a,tenantId,String(d.schluessel??''),String(d.user_id??''),String(d.rolle??'traeger'))});}
    if(u.pathname==='/api/operations/duties/drill'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await vermerkeUebung(env,a,tenantId,String(d.schluessel??''),String(d.user_id??''),d.am?String(d.am):undefined)});}
    if(u.pathname==='/api/operations/duties/release'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await entbindeVonAufgabe(env,a,tenantId,String(d.schluessel??''),String(d.user_id??''))});}
    const relProbe=u.pathname.match(/^\/api\/operations\/releases\/([^/]+)\/dry-run$/);if(relProbe&&request.method==='POST')return json({ok:true,...await probeRelease(env,a,decodeURIComponent(relProbe[1]))});
    const relAus=u.pathname.match(/^\/api\/operations\/releases\/([^/]+)\/rollout$/);if(relAus&&request.method==='POST')return json({ok:true,...await rolleReleaseAus(env,a,decodeURIComponent(relAus[1]))});
    const relZur=u.pathname.match(/^\/api\/operations\/releases\/([^/]+)\/rollback$/);if(relZur&&request.method==='POST')return json({ok:true,...await rolleReleaseZurueck(env,a,decodeURIComponent(relZur[1]),String((await body(request) as Record<string,unknown>).grund??''))});
    const stoErg=u.pathname.match(/^\/api\/operations\/incidents\/([^/]+)\/update$/);if(stoErg&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await ergaenzeStoerung(env,a,decodeURIComponent(stoErg[1]),String(d.text??''),d.intern===true)});}
    const stoBeh=u.pathname.match(/^\/api\/operations\/incidents\/([^/]+)\/resolve$/);if(stoBeh&&request.method==='POST')return json({ok:true,...await behebeStoerung(env,a,decodeURIComponent(stoBeh[1]),String((await body(request) as Record<string,unknown>).ursache??''))});
    const stoNach=u.pathname.match(/^\/api\/operations\/incidents\/([^/]+)\/postmortem$/);if(stoNach&&request.method==='POST')return json({ok:true,...await bereiteStoerungNach(env,a,decodeURIComponent(stoNach[1]),String((await body(request) as Record<string,unknown>).nachbetrachtung??''))});
    if(u.pathname==='/api/events/bus'&&request.method==='GET')return json({ok:true,...await busstand(env,a,tenantId)});
    if(u.pathname==='/api/events/subscriptions'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await abonniere(env,a,tenantId,String(d.art??''),String(d.verarbeiter??''),d.beschreibung?String(d.beschreibung):undefined)},201);}
    if(u.pathname==='/api/events/deliver'&&request.method==='POST')return json({ok:true,...await stelleZu(env)});
    if(u.pathname==='/api/events/dead-letter'&&request.method==='GET')return json({ok:true,zustellungen:await totfach(env,a,tenantId)});
    if(u.pathname==='/api/events/trace'&&request.method==='GET')return json({ok:true,...await ereignisspur(env,a,tenantId,u.searchParams.get('objekt_typ')??'',u.searchParams.get('objekt_id')??'')});
    const evzNeu=u.pathname.match(/^\/api\/events\/deliveries\/([^/]+)\/retry$/);if(evzNeu&&request.method==='POST')return json({ok:true,...await nimmZustellungWiederAuf(env,a,tenantId,decodeURIComponent(evzNeu[1]))});
    if(u.pathname==='/api/communication-templates'&&request.method==='POST')return json({ok:true,...await legeVorlageAn(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/communication-templates'&&request.method==='GET')return json({ok:true,vorlagen:await listeVorlagen(env,a,tenantId)});
    const ktEdit=u.pathname.match(/^\/api\/communication-templates\/([^/]+)$/);if(ktEdit&&request.method==='PATCH')return json({ok:true,...await bearbeiteVorlage(env,a,tenantId,decodeURIComponent(ktEdit[1]),await body(request))});
    const ktVor=u.pathname.match(/^\/api\/communication-templates\/([^/]+)\/preview$/);if(ktVor&&request.method==='POST')return json({ok:true,...await vorschau(env,a,tenantId,decodeURIComponent(ktVor[1]),(await body(request) as Record<string,unknown>).werte as Record<string,unknown>|undefined)});
    const ktPub=u.pathname.match(/^\/api\/communication-templates\/([^/]+)\/publish$/);if(ktPub&&request.method==='POST')return json({ok:true,...await veroeffentlicheVorlage(env,a,tenantId,decodeURIComponent(ktPub[1]))});
    const ktFas=u.pathname.match(/^\/api\/communication-templates\/([^/]+)\/versions$/);if(ktFas&&request.method==='GET')return json({ok:true,fassungen:await vorlagenFassungen(env,a,tenantId,decodeURIComponent(ktFas[1]))});
    // Vertrieb: vom Interessenten bis zum Vertrag. Alles vor dem Angebot lief in Outlook, in
    // einer Tabelle und im Kopf einer Person.
    if(u.pathname==='/api/sales/accounts'&&request.method==='POST')return json({ok:true,organisation:await legeOrganisationAn(env,a,tenantId,await body(request))},201);
    const sKontakt=u.pathname.match(/^\/api\/sales\/accounts\/([^/]+)\/contacts$/);
    if(sKontakt&&request.method==='GET')return json({ok:true,kontakte:await ansprechbareKontakte(env,a,tenantId,decodeURIComponent(sKontakt[1]))});
    if(sKontakt&&request.method==='POST')return json({ok:true,kontakt:await legeKontaktAn(env,a,tenantId,decodeURIComponent(sKontakt[1]),await body(request))},201);
    const sWiderspruch=u.pathname.match(/^\/api\/sales\/contacts\/([^/]+)\/objection$/);
    if(sWiderspruch&&request.method==='POST')return json({ok:true,...await haltWerbewiderspruchFest(env,a,tenantId,decodeURIComponent(sWiderspruch[1]),(await body(request)).am)});
    if(u.pathname==='/api/sales/leads'&&request.method==='GET')return json({ok:true,...await vorgangsmappe(env,a,tenantId)});
    if(u.pathname==='/api/sales/leads'&&request.method==='POST')return json({ok:true,vorgang:await legeVorgangAn(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/sales/report'&&request.method==='GET')
      return json({ok:true,...await vertriebsauswertung(env,a,tenantId,u.searchParams.get('von')||`${new Date().getUTCFullYear()}-01-01`,u.searchParams.get('bis')||`${new Date().getUTCFullYear()}-12-31`)});
    const sVorgang=u.pathname.match(/^\/api\/sales\/leads\/([^/]+)$/);
    if(sVorgang&&request.method==='GET')return json({ok:true,...await vorgangsmappe(env,a,tenantId,decodeURIComponent(sVorgang[1]))});
    if(sVorgang&&request.method==='PATCH')return json({ok:true,...await setzeStufe(env,a,tenantId,decodeURIComponent(sVorgang[1]),await body(request))});
    const sAktivitaet=u.pathname.match(/^\/api\/sales\/leads\/([^/]+)\/activities$/);
    if(sAktivitaet&&request.method==='POST')return json({ok:true,aktivitaet:await erfasseAktivitaet(env,a,tenantId,decodeURIComponent(sAktivitaet[1]),await body(request))},201);
    const sAngebot=u.pathname.match(/^\/api\/sales\/leads\/([^/]+)\/offer$/);
    if(sAngebot&&request.method==='POST')return json({ok:true,...await verknuepfeAngebot(env,a,tenantId,decodeURIComponent(sAngebot[1]),String((await body(request)).offer_id??''))});
    const sGewinn=u.pathname.match(/^\/api\/sales\/leads\/([^/]+)\/win$/);
    if(sGewinn&&request.method==='POST')return json({ok:true,...await gewinneVorgang(env,a,tenantId,decodeURIComponent(sGewinn[1]))});
    const sVerhandlung=u.pathname.match(/^\/api\/course-offers\/([^/]+)\/renegotiate$/);
    if(sVerhandlung&&request.method==='POST')return json({ok:true,angebot:await verhandleAngebot(env,a,tenantId,decodeURIComponent(sVerhandlung[1]),await body(request))},201);
    const sFassungen=u.pathname.match(/^\/api\/course-offers\/([^/]+)\/versions$/);
    if(sFassungen&&request.method==='GET')return json({ok:true,fassungen:await angebotsfassungen(env,a,tenantId,decodeURIComponent(sFassungen[1]))});
    // Das Qualitaetsmanagementsystem. Vorhanden war die Massnahme - das Ende der Kette; die
    // Ziele, Prozesse, Audits und die Managementbewertung davor fehlten.
    if(u.pathname==='/api/quality/objectives'&&request.method==='GET')return json({ok:true,...await zielstand(env,a,tenantId,Number(u.searchParams.get('jahr')||new Date().getUTCFullYear()))});
    if(u.pathname==='/api/quality/objectives'&&request.method==='POST')return json({ok:true,ziel:await legeZielAn(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/quality/indicators'&&request.method==='GET')return json({ok:true,kennzahlen:await kennzahlen(env,tenantId,Number(u.searchParams.get('jahr')||new Date().getUTCFullYear()))});
    if(u.pathname==='/api/quality/processes'&&request.method==='GET')return json({ok:true,prozesse:await prozessregister(env,a,tenantId)});
    if(u.pathname==='/api/quality/processes'&&request.method==='POST')return json({ok:true,prozess:await legeProzessAn(env,a,tenantId,await body(request))},201);
    const qProzess=u.pathname.match(/^\/api\/quality\/processes\/([^/]+)\/review$/);
    if(qProzess&&request.method==='POST')return json({ok:true,...await bestaetigeProzesspruefung(env,a,tenantId,decodeURIComponent(qProzess[1]),(await body(request)).am)});
    if(u.pathname==='/api/quality/audits'&&request.method==='GET')return json({ok:true,...await auditmappe(env,a,tenantId)});
    if(u.pathname==='/api/quality/audits'&&request.method==='POST')return json({ok:true,audit:await planeAudit(env,a,tenantId,await body(request))},201);
    const qAudit=u.pathname.match(/^\/api\/quality\/audits\/([^/]+)$/);
    if(qAudit&&request.method==='GET')return json({ok:true,...await auditmappe(env,a,tenantId,decodeURIComponent(qAudit[1]))});
    if(qAudit&&request.method==='PUT')return json({ok:true,...await schliesseAuditAb(env,a,tenantId,decodeURIComponent(qAudit[1]),await body(request))});
    const qFinding=u.pathname.match(/^\/api\/quality\/audits\/([^/]+)\/findings$/);
    if(qFinding&&request.method==='POST')return json({ok:true,feststellung:await erfasseFeststellung(env,a,tenantId,decodeURIComponent(qFinding[1]),await body(request))},201);
    if(u.pathname==='/api/quality/review'&&request.method==='GET')return json({ok:true,eingaben:await bewertungseingaben(env,a,tenantId,Number(u.searchParams.get('jahr')||new Date().getUTCFullYear()))});
    if(u.pathname==='/api/quality/review'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;
      return json({ok:true,...await haltBewertungFest(env,a,tenantId,Number(d.jahr||new Date().getUTCFullYear()),d)},201);}
    if(u.pathname==='/api/quality/review'&&request.method==='PUT'){const d=await body(request) as Record<string,unknown>;
      return json({ok:true,...await schliesseBewertungAb(env,a,tenantId,Number(d.jahr||new Date().getUTCFullYear()))});}
    if(u.pathname==='/api/quality/certifications'&&request.method==='GET')return json({ok:true,zertifikate:await zertifikate(env,a,tenantId)});
    if(u.pathname==='/api/quality/certifications'&&request.method==='POST')return json({ok:true,zertifikat:await legeZertifikatAn(env,a,tenantId,await body(request))},201);
    // Die Personalakte. Sie fehlte vollstaendig - und mit ihr der Weg, beim Ausscheiden den
    // Zugang zu entziehen.
    if(u.pathname==='/api/personnel'&&request.method==='GET')return json({ok:true,personen:await personalliste(env,a,tenantId,u.searchParams.get('status')||undefined)});
    if(u.pathname==='/api/personnel'&&request.method==='POST')return json({ok:true,person:await legeAkteAn(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/personnel/instructions/due'&&request.method==='GET')
      return json({ok:true,faellig:await faelligeUnterweisungen(env,a,tenantId,Number(u.searchParams.get('vorlauf')||60))});
    const pAbw=u.pathname.match(/^\/api\/personnel\/absences\/([^/]+)$/);
    if(pAbw&&request.method==='PATCH')return json({ok:true,...await entscheideAbwesenheit(env,a,tenantId,decodeURIComponent(pAbw[1]),await body(request))});
    const pNachweis=u.pathname.match(/^\/api\/personnel\/absences\/([^/]+)\/proof$/);
    if(pNachweis&&request.method==='POST')return json({ok:true,...await belegeNachweis(env,a,tenantId,decodeURIComponent(pNachweis[1]),(await body(request)).am)});
    const pVertragEnde=u.pathname.match(/^\/api\/personnel\/contracts\/([^/]+)\/end$/);
    if(pVertragEnde&&request.method==='POST')return json({ok:true,...await beendeVertrag(env,a,tenantId,decodeURIComponent(pVertragEnde[1]),(await body(request)).ende)});
    const pAkte=u.pathname.match(/^\/api\/personnel\/([^/]+)$/);
    if(pAkte&&request.method==='GET')return json({ok:true,...await personalakte(env,a,tenantId,decodeURIComponent(pAkte[1]))});
    const pVertrag=u.pathname.match(/^\/api\/personnel\/([^/]+)\/contracts$/);
    if(pVertrag&&request.method==='POST')return json({ok:true,vertrag:await legeVertragAn(env,a,tenantId,decodeURIComponent(pVertrag[1]),await body(request))},201);
    const pAbwesenheit=u.pathname.match(/^\/api\/personnel\/([^/]+)\/absences$/);
    if(pAbwesenheit&&request.method==='POST')return json({ok:true,abwesenheit:await erfasseAbwesenheit(env,a,tenantId,decodeURIComponent(pAbwesenheit[1]),await body(request))},201);
    const pUrlaub=u.pathname.match(/^\/api\/personnel\/([^/]+)\/leave$/);
    if(pUrlaub&&request.method==='GET')return json({ok:true,urlaub:await urlaubsstand(env,a,tenantId,decodeURIComponent(pUrlaub[1]),Number(u.searchParams.get('jahr')||new Date().getUTCFullYear()))});
    if(pUrlaub&&request.method==='PUT')return json({ok:true,urlaub:await setzeUrlaubsanspruch(env,a,tenantId,decodeURIComponent(pUrlaub[1]),await body(request))});
    const pUnterweisung=u.pathname.match(/^\/api\/personnel\/([^/]+)\/instructions$/);
    if(pUnterweisung&&request.method==='POST')return json({ok:true,unterweisung:await erfasseUnterweisung(env,a,tenantId,decodeURIComponent(pUnterweisung[1]),await body(request))},201);
    const pAustritt=u.pathname.match(/^\/api\/personnel\/([^/]+)\/offboarding$/);
    if(pAustritt&&request.method==='GET')return json({ok:true,...await austrittsliste(env,a,tenantId,decodeURIComponent(pAustritt[1]))});
    if(pAustritt&&request.method==='POST')return json({ok:true,...await vollzieheAustritt(env,a,tenantId,decodeURIComponent(pAustritt[1]),await body(request))},201);
    if(pAustritt&&request.method==='PUT')return json({ok:true,...await schliesseAustrittAb(env,a,tenantId,decodeURIComponent(pAustritt[1]))});
    // Die Auftragsmappe: was laeuft, wie weit, und was der naechste Aufruf kosten wuerde.
    // Ohne sie waere jede Hintergrundverarbeitung ein Fortschrittsbalken ohne Fortschritt.
    if(u.pathname==='/api/ai/jobs'&&request.method==='GET')return json({ok:true,auftraege:await kiAuftragsmappe(env,a,tenantId,Number(u.searchParams.get('grenze')||50))});
    const kiJob=u.pathname.match(/^\/api\/ai\/jobs\/([^/]+)$/);
    if(kiJob&&request.method==='GET')return json({ok:true,auftrag:await kiAuftragStand(env,a,tenantId,decodeURIComponent(kiJob[1]))});
    if(kiJob&&request.method==='DELETE')return json({ok:true,...await brichKiAuftragAb(env,a,tenantId,decodeURIComponent(kiJob[1]))});
    if(u.pathname==='/api/ai/classification'&&request.method==='GET')return json({ok:true,einstufungen:await kiEinstufungen(env,a,tenantId)});
    if(u.pathname==='/api/ai/cost-estimate'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;
      return json({ok:true,...await kostenschaetzung(env,tenantId,String(d.zweck??''),String(d.eingabe??''))});}
    if(u.pathname==='/api/ai/drafts'&&request.method==='POST')return json({ok:true,...await erzeugeEntwuerfe(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/ai/drafts'&&request.method==='GET')return json({ok:true,...await entwurfsmappe(env,a,tenantId,u.searchParams.get('status')??undefined)});
    const kefFrei=u.pathname.match(/^\/api\/ai\/drafts\/([^/]+)\/release$/);if(kefFrei&&request.method==='POST')return json({ok:true,...await gibEntwurfFrei(env,a,tenantId,decodeURIComponent(kefFrei[1]),String((await body(request) as Record<string,unknown>).anmerkung??''))});
    const kefWeg=u.pathname.match(/^\/api\/ai\/drafts\/([^/]+)\/discard$/);if(kefWeg&&request.method==='POST')return json({ok:true,...await verwirfEntwurf(env,a,tenantId,decodeURIComponent(kefWeg[1]),String((await body(request) as Record<string,unknown>).grund??''))});
    const kefUeb=u.pathname.match(/^\/api\/ai\/drafts\/([^/]+)\/adopt$/);if(kefUeb&&request.method==='POST')return json({ok:true,...await uebernimmEntwurf(env,a,tenantId,decodeURIComponent(kefUeb[1]),await body(request) as Record<string,unknown>)});
    if(u.pathname==='/api/command/suggest'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await schlageVor(env,a,tenantId,String(d.eingabe??''),d.course_id?String(d.course_id):undefined)});}
    if(u.pathname==='/api/command/confirm'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await bestaetigeDeutung(env,a,tenantId,String(d.id??''),String(d.schluessel??''))});}
    if(u.pathname==='/api/command/history'&&request.method==='GET')return json({ok:true,verlauf:await befehlsverlauf(env,a,tenantId)});
    if(u.pathname==='/api/command/available'&&request.method==='GET')return json({ok:true,befehle:verfuegbareBefehle(a,u.searchParams.get('course_id')??undefined)});
    if(u.pathname==='/api/residency'&&request.method==='GET')return json({ok:true,...await residenzpruefung(env,a,tenantId,u.searchParams.get('heute')??undefined)});
    if(u.pathname==='/api/residency'&&request.method==='POST')return json({ok:true,...await legeResidenzFest(env,a,tenantId,await body(request))});
    if(u.pathname==='/api/residency/exceptions'&&request.method==='POST')return json({ok:true,...await erteileAusnahme(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/alumni'&&request.method==='POST')return json({ok:true,...await schliesseAb(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/alumni'&&request.method==='GET')return json({ok:true,...await alumnistand(env,a,tenantId)});
    if(u.pathname==='/api/alumni/contactable'&&request.method==='GET')return json({ok:true,alumni:await ansprechbareAlumni(env,a,tenantId)});
    if(u.pathname==='/api/personal/alumni'&&request.method==='GET')return json({ok:true,abschluesse:await meineAbschluesse(env,a,tenantId)});
    if(u.pathname==='/api/personal/alumni/consent'&&request.method==='POST')return json({ok:true,...await setzeKontakteinwilligung(env,a,tenantId,(await body(request) as Record<string,unknown>).erteilt===true)});
    if(u.pathname==='/api/alumni/end'&&request.method==='POST')return json({ok:true,...await beendeAlumnistatus(env,a,tenantId,String((await body(request) as Record<string,unknown>).user_id??a.userId))});
    if(u.pathname==='/api/course-offers'&&request.method==='GET')return json({ok:true,...await angebotsmappe(env,a,tenantId)});
    if(u.pathname==='/api/course-offers'&&request.method==='POST')return json({ok:true,...await legeAngebotAn(env,a,tenantId,await body(request) as Record<string,unknown>)},201);
    if(u.pathname==='/api/course-offers/plan'&&request.method==='GET')return json({ok:true,plan:await leiteMassnahmeplanAb(env,tenantId,u.searchParams.get('course_id')??'')});
    if(u.pathname==='/api/course-offers/attachments'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await legeAnlageBei(env,a,tenantId,String(d.offer_id??''),d)},201);}
    if(u.pathname==='/api/course-offers/send'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await versendeAngebot(env,a,tenantId,String(d.offer_id??''))});}
    if(u.pathname==='/api/course-offers/check'&&request.method==='GET')return json({ok:true,...await pruefeAngebotAktuell(env,tenantId,u.searchParams.get('offer_id')??'')});
    if(u.pathname==='/api/course-offers/accept'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await nimmAngebotAn(env,a,tenantId,String(d.offer_id??''),d)},201);}
    if(u.pathname==='/api/course-offers/reject'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await lehneAngebotAb(env,a,tenantId,String(d.offer_id??''),String(d.grund??''))});}
    if(u.pathname==='/api/course-offers/expire'&&request.method==='POST')return json({ok:true,...await schliesseAbgelaufeneAngebote(env,tenantId)});
    if(u.pathname==='/api/inventory'&&request.method==='GET')return json({ok:true,...await inventarmappe(env,a,tenantId)});
    if(u.pathname==='/api/inventory'&&request.method==='POST')return json({ok:true,...await erfasseGegenstand(env,a,tenantId,await body(request) as Record<string,unknown>)},201);
    if(u.pathname==='/api/inventory/issue'&&request.method==='POST')return json({ok:true,...await gibAus(env,a,tenantId,await body(request) as Record<string,unknown>)},201);
    if(u.pathname==='/api/inventory/return'&&request.method==='POST')return json({ok:true,...await nimmGeraetZurueck(env,a,tenantId,await body(request) as Record<string,unknown>)});
    if(u.pathname==='/api/inventory/loss'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await meldeGeraetVerlust(env,a,tenantId,String(d.ausgabe_id??''),String(d.grund??''))});}
    if(u.pathname==='/api/inventory/retire'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await mustereAus(env,a,tenantId,String(d.item_id??''))});}
    if(u.pathname==='/api/inventory/open-issues'&&request.method==='GET')return json({ok:true,...await offeneAusgabenBeiAbgang(env,a,tenantId,{course_id:u.searchParams.get('course_id')??undefined,user_id:u.searchParams.get('user_id')??undefined})});
    if(u.pathname==='/api/procurement'&&request.method==='POST')return json({ok:true,...await fordereAn(env,a,tenantId,await body(request) as Record<string,unknown>)},201);
    if(u.pathname==='/api/procurement/approve'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await gibFrei(env,a,tenantId,String(d.request_id??''))});}
    if(u.pathname==='/api/procurement/reject'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await lehneBeschaffungAb(env,a,tenantId,String(d.request_id??''),String(d.grund??''))});}
    if(u.pathname==='/api/procurement/order'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await bestelle(env,a,tenantId,String(d.request_id??''))});}
    if(u.pathname==='/api/procurement/receipt'&&request.method==='POST')return json({ok:true,...await bucheWareneingang(env,a,tenantId,await body(request) as Record<string,unknown>)},201);
    if(u.pathname==='/api/maintenance'&&request.method==='POST')return json({ok:true,...await meldeMangel(env,a,tenantId,await body(request) as Record<string,unknown>)},201);
    if(u.pathname==='/api/maintenance/fix'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await behebeMangel(env,a,tenantId,String(d.ticket_id??''),String(d.text??''))});}
    if(u.pathname==='/api/library'&&request.method==='GET')return json({ok:true,...await bibliotheksstand(env,a,tenantId)});
    if(u.pathname==='/api/library/titles'&&request.method==='POST')return json({ok:true,...await erfasseTitel(env,a,tenantId,await body(request) as Record<string,unknown>)},201);
    if(u.pathname==='/api/library/copies'&&request.method==='POST')return json({ok:true,...await legeExemplarAn(env,a,tenantId,await body(request) as Record<string,unknown>)},201);
    if(u.pathname==='/api/library/loans'&&request.method==='POST')return json({ok:true,...await verleihe(env,a,tenantId,await body(request) as Record<string,unknown>)},201);
    if(u.pathname==='/api/library/extend'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await verlaengere(env,a,tenantId,String(d.loan_id??''))});}
    if(u.pathname==='/api/library/return'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await nimmBuchZurueck(env,a,tenantId,String(d.loan_id??''))});}
    if(u.pathname==='/api/library/loss'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await meldeBuchVerlust(env,a,tenantId,String(d.loan_id??''),String(d.grund??''))});}
    if(u.pathname==='/api/library/reservations'&&request.method==='POST')return json({ok:true,...await merkeVor(env,a,tenantId,await body(request) as Record<string,unknown>)},201);
    if(u.pathname==='/api/library/reminders'&&request.method==='POST')return json({ok:true,...await mahneUeberfaellige(env,a,tenantId)});
    if(u.pathname==='/api/library/pickup-expiry'&&request.method==='POST')return json({ok:true,...await raeumeAbholfristen(env,a,tenantId)});
    if(u.pathname==='/api/emaw'&&request.method==='GET')return json({ok:true,...await emawMappe(env,a,tenantId)});
    if(u.pathname==='/api/emaw/provider'&&request.method==='POST')return json({ok:true,...await setzeProvider(env,a,tenantId,await body(request) as Record<string,unknown>)});
    if(u.pathname==='/api/emaw/inbox'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await nimmEingangAn(env,a,tenantId,String(d.xml??''))},201);}
    if(u.pathname==='/api/emaw/assign'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await ordneEmawZu(env,a,tenantId,String(d.schluessel_id??''),d)});}
    if(u.pathname==='/api/emaw/events/entry'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await erzeugeEintritt(env,a,tenantId,String(d.schluessel_id??''),String(d.beginn??''))},201);}
    if(u.pathname==='/api/emaw/events/no-show'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await erzeugeNichtantritt(env,a,tenantId,String(d.schluessel_id??''),d)},201);}
    if(u.pathname==='/api/emaw/events/attendance'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await erzeugeAnwesenheitMonat(env,a,tenantId,String(d.schluessel_id??''),d)},201);}
    if(u.pathname==='/api/emaw/events/exit'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await erzeugeAustritt(env,a,tenantId,String(d.schluessel_id??''),d)},201);}
    if(u.pathname==='/api/emaw/archive'&&request.method==='POST'){const r=await baueImportarchiv(env,a,tenantId);
      return new Response(r.bytes,{status:201,headers:{'content-type':'application/zip',
        'content-disposition':`attachment; filename="${r.dateiname}"`,'x-emaw-anzahl':String(r.anzahl),
        'x-emaw-archiv':r.archiv_id}});}
    if(u.pathname==='/api/emaw/receipt'&&request.method==='POST'){const d=await body(request) as Record<string,unknown>;return json({ok:true,...await verarbeiteQuittung(env,a,tenantId,String(d.xml??''))});}
    const vorZur=u.pathname.match(/^\/api\/personal\/prior-learning\/([^/]+)\/withdraw$/);if(vorZur&&request.method==='POST')return json({ok:true,...await ziehAnerkennungZurueck(env,a,tenantId,decodeURIComponent(vorZur[1]))});
    const planBew=u.pathname.match(/^\/api\/timetable-plans\/([^/]+)\/score$/);if(planBew&&request.method==='POST')return json({ok:true,...await bewertePlanfassung(env,a,tenantId,decodeURIComponent(planBew[1]),await body(request))});
    if(planBew&&request.method==='GET')return json({ok:true,bewertungen:await listPlanScores(env,a,tenantId,decodeURIComponent(planBew[1]))});
    if(u.pathname==='/api/timetable-plans/compare'&&request.method==='GET')return json({ok:true,...await vergleichePlanfassungen(env,a,tenantId,u.searchParams.get('a')||'',u.searchParams.get('b')||'')});
    const planSim=u.pathname.match(/^\/api\/timetable-plans\/([^/]+)\/restore-preview$/);if(planSim&&request.method==='POST')return json({ok:true,vorschau:await simuliereFassungsRueckkehr(env,a,tenantId,decodeURIComponent(planSim[1]),String((await body(request) as Record<string,unknown>).quelle_plan_id||''))});
    const planWie=u.pathname.match(/^\/api\/timetable-plans\/([^/]+)\/restore$/);if(planWie&&request.method==='POST'){const b3=await body(request) as Record<string,unknown>;return json({ok:true,...await stellePlanfassungWiederHer(env,a,tenantId,decodeURIComponent(planWie[1]),String(b3.quelle_plan_id||''),String(b3.pruefsumme||''))});}
    if(u.pathname==='/api/timetable-plans/restores'&&request.method==='GET')return json({ok:true,laeufe:await listPlanRestores(env,a,tenantId,u.searchParams.get('plan_id')||undefined)});
    const planVor=u.pathname.match(/^\/api\/timetable-plans\/([^/]+)\/suggestions$/);if(planVor&&request.method==='GET')return json({ok:true,...await konfliktVorschlaege(env,a,tenantId,decodeURIComponent(planVor[1]))});
    const planTeil=u.pathname.match(/^\/api\/timetable-plans\/([^/]+)\/partial-replan\/preview$/);if(planTeil&&request.method==='POST')return json({ok:true,vorschau:await teilNeuPlanenVorschau(env,a,tenantId,decodeURIComponent(planTeil[1]),await body(request))});
    const planTeilLauf=u.pathname.match(/^\/api\/timetable-plans\/([^/]+)\/partial-replan$/);if(planTeilLauf&&request.method==='POST')return json({ok:true,...await teilNeuPlanen(env,a,tenantId,decodeURIComponent(planTeilLauf[1]),await body(request))});
    if(u.pathname==='/api/teaching-rhythms'&&request.method==='GET')return json({ok:true,regeln:await listRhythmRules(env,a,tenantId)});
    if(u.pathname==='/api/teaching-rhythms'&&request.method==='POST')return json({ok:true,...await saveRhythmRule(env,a,tenantId,await body(request))},201);
    const rhyDel=u.pathname.match(/^\/api\/teaching-rhythms\/([^/]+)$/);if(rhyDel&&request.method==='DELETE')return json({ok:true,...await deleteRhythmRule(env,a,tenantId,decodeURIComponent(rhyDel[1]))});
    const rhyAnw=u.pathname.match(/^\/api\/timetable-plans\/([^/]+)\/apply-rhythm$/);if(rhyAnw&&request.method==='POST')return json({ok:true,...await applyRhythmToPlan(env,a,tenantId,decodeURIComponent(rhyAnw[1]),await body(request))});
    if(u.pathname==='/api/documents/search'&&request.method==='GET')return json({ok:true,treffer:await sucheDokumente(env,a,tenantId,u.searchParams.get('q')||'',Number(u.searchParams.get('limit')||50))});
    const dokFass=u.pathname.match(/^\/api\/documents\/([^/]+)\/versions$/);if(dokFass&&request.method==='GET')return json({ok:true,fassungen:await dokumentfassungen(env,a,tenantId,decodeURIComponent(dokFass[1]))});
    if(dokFass&&request.method==='POST')return json({ok:true,...await speichereDokumentfassung(env,a,tenantId,decodeURIComponent(dokFass[1]),await body(request))},201);
    const dokZurueck=u.pathname.match(/^\/api\/documents\/([^/]+)\/versions\/(\d+)\/restore$/);if(dokZurueck&&request.method==='POST')return json({ok:true,...await holeFassungZurueck(env,a,tenantId,decodeURIComponent(dokZurueck[1]),Number(dokZurueck[2]),(await body(request) as Record<string,unknown>).grund)});
    if(u.pathname==='/api/automation/failures'&&request.method==='GET')return json({ok:true,fehler:await offeneAutomationsfehler(env,a,tenantId)});
    const aflWieder=u.pathname.match(/^\/api\/automation\/failures\/([^/]+)\/resume$/);if(aflWieder&&request.method==='POST')return json({ok:true,...await nimmFehlerWiederAuf(env,a,tenantId,decodeURIComponent(aflWieder[1]))});
    const aflAuf=u.pathname.match(/^\/api\/automation\/failures\/([^/]+)\/abandon$/);if(aflAuf&&request.method==='POST')return json({ok:true,...await gibFehlerAuf(env,a,tenantId,decodeURIComponent(aflAuf[1]),(await body(request) as Record<string,unknown>).grund)});
    if(u.pathname==='/api/automation/operations'&&request.method==='GET')return json({ok:true,vorgaenge:await haengendeVorgaenge(env,a,tenantId)});
    const opStand=u.pathname.match(/^\/api\/automation\/operations\/([^/]+)$/);if(opStand&&request.method==='GET')return json({ok:true,...await vorgangsstand(env,a,tenantId,decodeURIComponent(opStand[1]))});
    const wfModus=u.pathname.match(/^\/api\/workflow-rules\/([^/]+)\/mode$/);if(wfModus&&request.method==='POST')return json({ok:true,...await setzeRegelmodus(env,a,tenantId,decodeURIComponent(wfModus[1]),String((await body(request) as Record<string,unknown>).modus||''))});
    const wfSim=u.pathname.match(/^\/api\/workflow-rules\/([^/]+)\/simulation$/);if(wfSim&&request.method==='GET')return json({ok:true,...await simulationsbericht(env,a,tenantId,decodeURIComponent(wfSim[1]))});
    const wfAkt=u.pathname.match(/^\/api\/workflow-rules\/([^/]+)\/activate$/);if(wfAkt&&request.method==='POST')return json({ok:true,...await aktiviereRegel(env,a,tenantId,decodeURIComponent(wfAkt[1]),(await body(request) as Record<string,unknown>).begruendung)});
    const exFrei=u.pathname.match(/^\/api\/exams\/([^/]+)\/release$/);if(exFrei&&request.method==='POST')return json({ok:true,...await gibBogenFrei(env,a,tenantId,decodeURIComponent(exFrei[1]),(await body(request) as Record<string,unknown>).begruendung)});
    const exSieg=u.pathname.match(/^\/api\/exams\/([^/]+)\/seal$/);if(exSieg&&request.method==='POST')return json({ok:true,...await versiegleBogen(env,a,tenantId,decodeURIComponent(exSieg[1]))});
    const exEnt=u.pathname.match(/^\/api\/exams\/([^/]+)\/unseal$/);if(exEnt&&request.method==='POST')return json({ok:true,...await entsiegleBogen(env,a,tenantId,decodeURIComponent(exEnt[1]),(await body(request) as Record<string,unknown>).begruendung)});
    const exArch=u.pathname.match(/^\/api\/exams\/([^/]+)\/archive$/);if(exArch&&request.method==='POST')return json({ok:true,...await archiviereBogen(env,a,tenantId,decodeURIComponent(exArch[1]))});
    const exKette=u.pathname.match(/^\/api\/exams\/([^/]+)\/custody$/);if(exKette&&request.method==='GET')return json({ok:true,...await beweiskette(env,a,tenantId,decodeURIComponent(exKette[1]))});
    const exEins=u.pathname.match(/^\/api\/exams\/([^/]+)\/inspection$/);if(exEins&&request.method==='POST'){const b2=await body(request) as Record<string,unknown>;return json({ok:true,...await protokolliereEinsicht(env,a,tenantId,decodeURIComponent(exEins[1]),(b2.attempt_id as string)||null,b2.begruendung)});}
    const exUnt=u.pathname.match(/^\/api\/exam-attempts\/([^/]+)\/interrupt$/);if(exUnt&&request.method==='POST')return json({ok:true,...await unterbrichVersuch(env,a,tenantId,decodeURIComponent(exUnt[1]),await body(request))},201);
    const exFort=u.pathname.match(/^\/api\/exam-attempts\/([^/]+)\/resume$/);if(exFort&&request.method==='POST')return json({ok:true,...await setzeVersuchFort(env,a,tenantId,decodeURIComponent(exFort[1]),(await body(request) as Record<string,unknown>).abgleich as never)});
    const exAbg=u.pathname.match(/^\/api\/exam-attempts\/([^/]+)\/reconcile$/);if(exAbg&&request.method==='POST')return json({ok:true,...await gleicheErgebnisAb(env,a,tenantId,decodeURIComponent(exAbg[1]),((await body(request) as Record<string,unknown>).antworten as never)??[])});
    const exUnts=u.pathname.match(/^\/api\/exam-attempts\/([^/]+)\/interruptions$/);if(exUnts&&request.method==='GET')return json({ok:true,unterbrechungen:await unterbrechungen(env,a,tenantId,decodeURIComponent(exUnts[1]))});
    if(u.pathname==='/api/exam-interruptions/open'&&request.method==='GET'){if(!courseId)throw new Error('COURSE_ID_REQUIRED');return json({ok:true,offen:await offeneUnterbrechungen(env,a,tenantId,courseId)});}
    if(u.pathname==='/api/exam-integrity'&&request.method==='POST')return json({ok:true,...await eroeffneIntegritaetsfall(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/exam-integrity'&&request.method==='GET')return json({ok:true,faelle:await listeIntegritaetsfaelle(env,a,tenantId,u.searchParams.get('alle')!=='1')});
    const intLesen=u.pathname.match(/^\/api\/exam-integrity\/([^/]+)$/);if(intLesen&&request.method==='GET')return json({ok:true,...await integritaetsfallLesen(env,a,tenantId,decodeURIComponent(intLesen[1]))});
    const intAnh=u.pathname.match(/^\/api\/exam-integrity\/([^/]+)\/hearing$/);if(intAnh&&request.method==='POST')return json({ok:true,...await biteZurAnhoerung(env,a,tenantId,decodeURIComponent(intAnh[1]),Number((await body(request) as Record<string,unknown>).tage??7))});
    const intEnt=u.pathname.match(/^\/api\/exam-integrity\/([^/]+)\/decision$/);if(intEnt&&request.method==='POST')return json({ok:true,...await entscheideIntegritaetsfall(env,a,tenantId,decodeURIComponent(intEnt[1]),await body(request))});
    const intMein=u.pathname.match(/^\/api\/personal\/exam-integrity\/([^/]+)$/);if(intMein&&request.method==='GET')return json({ok:true,fall:await meinIntegritaetsfall(env,a,tenantId,decodeURIComponent(intMein[1]))});
    const intStell=u.pathname.match(/^\/api\/personal\/exam-integrity\/([^/]+)\/statement$/);if(intStell&&request.method==='POST')return json({ok:true,...await gibStellungnahmeAb(env,a,tenantId,decodeURIComponent(intStell[1]),(await body(request) as Record<string,unknown>).text)});
    const intVerz=u.pathname.match(/^\/api\/personal\/exam-integrity\/([^/]+)\/waive$/);if(intVerz&&request.method==='POST')return json({ok:true,...await verzichteAufAnhoerung(env,a,tenantId,decodeURIComponent(intVerz[1]))});
    if(u.pathname==='/api/privacy-incidents'&&request.method==='POST')return json({ok:true,...await meldeVorfall(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/privacy-incidents'&&request.method==='GET')return json({ok:true,vorfaelle:await vorfallRegister(env,a,tenantId,Number(u.searchParams.get('limit')||200))});
    const vfLesen=u.pathname.match(/^\/api\/privacy-incidents\/([^/]+)$/);if(vfLesen&&request.method==='GET')return json({ok:true,...await vorfallLesen(env,a,tenantId,decodeURIComponent(vfLesen[1]))});
    const vfBew=u.pathname.match(/^\/api\/privacy-incidents\/([^/]+)\/assessment$/);if(vfBew&&request.method==='POST')return json({ok:true,...await bewerteVorfall(env,a,tenantId,decodeURIComponent(vfBew[1]),await body(request))});
    const vfMeld=u.pathname.match(/^\/api\/privacy-incidents\/([^/]+)\/authority-report$/);if(vfMeld&&request.method==='POST')return json({ok:true,...await meldeAnBehoerde(env,a,tenantId,decodeURIComponent(vfMeld[1]),await body(request))});
    const vfInfo=u.pathname.match(/^\/api\/privacy-incidents\/([^/]+)\/inform-subjects$/);if(vfInfo&&request.method==='POST')return json({ok:true,...await informiereBetroffene(env,a,tenantId,decodeURIComponent(vfInfo[1]),(await body(request) as Record<string,unknown>).text)});
    const vfNotiz=u.pathname.match(/^\/api\/privacy-incidents\/([^/]+)\/notes$/);if(vfNotiz&&request.method==='POST')return json({ok:true,...await vorfallNotiz(env,a,tenantId,decodeURIComponent(vfNotiz[1]),await body(request))},201);
    const vfZu=u.pathname.match(/^\/api\/privacy-incidents\/([^/]+)\/close$/);if(vfZu&&request.method==='POST')return json({ok:true,...await schliesseVorfall(env,a,tenantId,decodeURIComponent(vfZu[1]),(await body(request) as Record<string,unknown>).massnahmen)});
    if(u.pathname==='/api/crisis/alerts'&&request.method==='GET')return json({ok:true,lagen:await listeKrisen(env,a,tenantId)});
    if(u.pathname==='/api/crisis/alerts'&&request.method==='POST')return json({ok:true,...await loeseKriseAus(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/crisis/my-alerts'&&request.method==='GET')return json({ok:true,lagen:await meineKrisen(env,a,tenantId)});
    if(u.pathname==='/api/crisis/emergency-contact'&&request.method==='POST')return json({ok:true,...await setzeNotfallkontakt(env,a,tenantId,await body(request))});
    const krStand=u.pathname.match(/^\/api\/crisis\/alerts\/([^/]+)$/);if(krStand&&request.method==='GET')return json({ok:true,...await krisenstand(env,a,tenantId,decodeURIComponent(krStand[1]))});
    const krBest=u.pathname.match(/^\/api\/crisis\/alerts\/([^/]+)\/confirm$/);if(krBest&&request.method==='POST')return json({ok:true,...await bestaetigeKrise(env,a,tenantId,decodeURIComponent(krBest[1]))});
    const krEnde=u.pathname.match(/^\/api\/crisis\/alerts\/([^/]+)\/all-clear$/);if(krEnde&&request.method==='POST')return json({ok:true,...await gibEntwarnung(env,a,tenantId,decodeURIComponent(krEnde[1]),(await body(request) as Record<string,unknown>).entwarnung)});
    if(u.pathname==='/api/complaints'&&request.method==='POST')return json({ok:true,...await reicheBeschwerdeEin(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/complaints'&&request.method==='GET')return json({ok:true,beschwerden:await listeBeschwerden(env,a,tenantId,u.searchParams.get('alle')!=='1')});
    if(u.pathname==='/api/complaints/mine'&&request.method==='GET')return json({ok:true,beschwerden:await meineBeschwerden(env,a,tenantId)});
    if(u.pathname==='/api/complaints/by-key'&&request.method==='POST')return json({ok:true,...await beschwerdeNachSchluessel(env,tenantId,(await body(request) as Record<string,unknown>).vorgangsschluessel)});
    const bswLesen=u.pathname.match(/^\/api\/complaints\/([^/]+)$/);if(bswLesen&&request.method==='GET')return json({ok:true,...await beschwerdeLesen(env,a,tenantId,decodeURIComponent(bswLesen[1]))});
    const bswStatus=u.pathname.match(/^\/api\/complaints\/([^/]+)\/status$/);if(bswStatus&&request.method==='POST')return json({ok:true,...await bearbeiteBeschwerde(env,a,tenantId,decodeURIComponent(bswStatus[1]),await body(request))});
    if(u.pathname==='/api/safeguarding/reports'&&request.method==='POST')return json({ok:true,...await meldeSachverhalt(env,a,tenantId,await body(request))},201);
    if(u.pathname==='/api/safeguarding/reports'&&request.method==='GET')return json({ok:true,faelle:await offeneFaelle(env,a,tenantId)});
    if(u.pathname==='/api/safeguarding/my-reports'&&request.method==='GET')return json({ok:true,meldungen:await meineMeldungen(env,a,tenantId)});
    const sgFall=u.pathname.match(/^\/api\/safeguarding\/reports\/([^/]+)$/);if(sgFall&&request.method==='GET')return json({ok:true,...await fallLesen(env,a,tenantId,decodeURIComponent(sgFall[1]))});
    const sgNotiz=u.pathname.match(/^\/api\/safeguarding\/reports\/([^/]+)\/notes$/);if(sgNotiz&&request.method==='POST')return json({ok:true,...await notizHinzufuegen(env,a,tenantId,decodeURIComponent(sgNotiz[1]),await body(request))},201);
    const sgStatus=u.pathname.match(/^\/api\/safeguarding\/reports\/([^/]+)\/status$/);if(sgStatus&&request.method==='POST')return json({ok:true,...await setzeFallstatus(env,a,tenantId,decodeURIComponent(sgStatus[1]),await body(request))});
    if(u.pathname==='/api/safeguarding/officers'&&request.method==='GET')return json({ok:true,fachkraefte:await listeFachkraefte(env,tenantId)});
    if(u.pathname==='/api/safeguarding/officers'&&request.method==='POST')return json({ok:true,...await benenneFachkraft(env,a,tenantId,await body(request))},201);
    const sgOff=u.pathname.match(/^\/api\/safeguarding\/officers\/([^/]+)$/);if(sgOff&&request.method==='DELETE')return json({ok:true,...await entzieheFachkraft(env,a,tenantId,decodeURIComponent(sgOff[1]))});
    if(u.pathname==='/api/tenant/access-restrictions'&&request.method==='GET')return json({ok:true,restrictions:await listeBeschraenkungen(env,a,tenantId)});
    if(u.pathname==='/api/tenant/access-restrictions'&&request.method==='POST')return json({ok:true,restriction:await verhaengeBeschraenkung(env,a,tenantId,await body(request))},201);
    const aspLift=u.pathname.match(/^\/api\/tenant\/access-restrictions\/([^/]+)\/lift$/);if(aspLift&&request.method==='POST')return json({ok:true,...await hebeBeschraenkungAuf(env,a,tenantId,decodeURIComponent(aspLift[1]),(await body(request) as Record<string,unknown>).grund)});
    const gHaus=u.pathname.match(/^\/api\/tenant\/guardianships\/([^/]+)\/household$/);if(gHaus&&request.method==='POST')return json({ok:true,...await setzeHaushalt(env,a,tenantId,decodeURIComponent(gHaus[1]),(await body(request) as Record<string,unknown>).haushalt)});
    if(u.pathname==='/api/tenant/guardianships'&&request.method==='GET')return json({ok:true,guardianships:await listGuardianships(env,a,tenantId)});
    if(u.pathname==='/api/tenant/guardianships'&&request.method==='POST')return json({ok:true,guardianship:await createGuardianship(env,a,tenantId,await body(request))},201);
    const gEnd=u.pathname.match(/^\/api\/tenant\/guardianships\/([^/]+)$/);if(gEnd&&request.method==='DELETE')return json({ok:true,...await endGuardianship(env,a,tenantId,decodeURIComponent(gEnd[1]))});
    // Die Einwilligung nach der Volljaehrigkeit setzt ausschliesslich die betroffene Person.
    if(u.pathname==='/api/personal/guardians'&&request.method==='GET')return json({ok:true,guardians:await myGuardians(env,a,tenantId)});
    const gCon=u.pathname.match(/^\/api\/personal\/guardians\/([^/]+)\/consent$/);if(gCon&&request.method==='PUT')return json({ok:true,...await setOwnGuardianConsent(env,a,tenantId,decodeURIComponent(gCon[1]),(await body(request)).consent===true)});
    if(u.pathname==='/api/personal/grades'&&request.method==='GET'){if(!courseId)throw new Error('COURSE_ID_REQUIRED');return json({ok:true,grades:await listPersonalGrades(env,a,tenantId,courseId)});}
    if(u.pathname==='/api/personal/grades'&&request.method==='POST'){if(!courseId)throw new Error('COURSE_ID_REQUIRED');return json({ok:true,grade:await savePersonalGrade(env,a,tenantId,courseId,await body(request))},201);}
    const gradeRoute=u.pathname.match(/^\/api\/personal\/grades\/([^/]+)$/);
    if(gradeRoute&&request.method==='PATCH'){if(!courseId)throw new Error('COURSE_ID_REQUIRED');return json({ok:true,grade:await updatePersonalGrade(env,a,tenantId,courseId,decodeURIComponent(gradeRoute[1]),await body(request))});}
    if(gradeRoute&&request.method==='DELETE'){if(!courseId)throw new Error('COURSE_ID_REQUIRED');await deletePersonalGrade(env,a,tenantId,courseId,decodeURIComponent(gradeRoute[1]));return json({ok:true});}
    return json({ok:false,error:'NOT_FOUND'},404);
  }catch(e){return err(e);}
}

export async function handlePublicApi(request:Request,env:Env):Promise<Response|null>{const u=new URL(request.url),m=u.pathname.match(/^\/public\/([^/]+)\/([^/]+)\/overview$/);if(!m)return null;try{const d=await publicOverview(env,decodeURIComponent(m[1]),decodeURIComponent(m[2]),await getSession(env,request),request.headers.get('X-Klassenportal-Access-Code')||u.searchParams.get('access_code')||undefined);return json({ok:true,...d});}catch(e){const c=safeErrorCode(e),s=authStatus(c)??(c==='ACCESS_CODE_REQUIRED'||c==='LOGIN_OR_CODE_REQUIRED'?401:c==='PORTAL_NOT_FOUND'?404:400);return json({ok:false,error:c},s);}}

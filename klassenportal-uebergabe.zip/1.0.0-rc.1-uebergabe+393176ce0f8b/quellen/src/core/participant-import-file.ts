import type { CoreAuthContext, Env } from './types.js';
import { parseCsv } from '../portability/csv.js';
import { parseXlsx } from '../portability/xlsx.js';
import { previewParticipantImport } from './participant-document-import.js';
import { canonicalColumn } from './import-column-aliases.js';

function key(v:string){return v.trim().toLowerCase().replace(/[ä]/g,'ae').replace(/[ö]/g,'oe').replace(/[ü]/g,'ue').replace(/[ß]/g,'ss').replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'');}
const ALIASES:Record<string,string>={
  name:'display_name',display_name:'display_name',teilnehmer:'display_name',teilnehmer_name:'display_name',schueler:'display_name',schueler_name:'display_name',student:'display_name',student_name:'display_name',
  vorname:'first_name',first_name:'first_name',nachname:'last_name',last_name:'last_name',
  email:'email',e_mail:'email',mail:'email',emailadresse:'email',e_mail_adresse:'email',
  external_id:'external_id',teilnehmernummer:'teilnehmernummer',teilnehmer_id:'teilnehmer_id',matrikelnummer:'matrikelnummer',schuelernummer:'schuelernummer',vertragsnummer:'vertragsnummer',
  course_id:'course_id',kurs_id:'course_id',
  course_code:'course_code',kurscode:'kurscode',klassencode:'klassencode',massnahmennummer:'massnahmennummer',
  course_name:'course_name',kurs:'kurs',klasse:'klasse',massnahme:'massnahme',bildungsgang:'bildungsgang',studiengang:'studiengang',
  beginn:'beginn',start:'start',enrollment_start:'enrollment_start',ende:'ende',enrollment_end:'enrollment_end'
};
// Die Liste oben deckt nur die Schreibweisen ab, die dieses Portal von Anfang an kannte. Eine
// Datei aus einem Fremdsystem heisst ihre Spalten anders - 'Kurs-Code' statt 'Kurscode',
// 'class_id' statt 'course_code', 'first_name' statt 'Vorname'. Fuer alles, was die eigene
// Liste nicht kennt, greift die gemeinsame, mehrsprachige Tabelle. Sie kommt bewusst danach:
// eine hier ausdruecklich getroffene Entscheidung bleibt die staerkere.
//
// Und eine bereits gefuellte Zielspalte wird nicht ueberschrieben: fuehrt eine Datei 'Name'
// UND 'Teilnehmername', gewinnt der zuerst gelesene Wert, statt dass der zweite ihn loescht.
// Welches Feld eine Spalte trifft, entscheidet in dieser Reihenfolge: die Vorgabe des Kunden aus
// der Spaltenzuordnung, dann die eigene Liste, dann die gemeinsame mehrsprachige Tabelle. Eine
// leere Vorgabe heisst ausdruecklich "diese Spalte ignorieren" - sonst koennte der Kunde eine
// falsch erkannte Spalte nur umbiegen, aber nie abschalten.
function zielFeld(header:string,overrides:Record<string,string>){
  const k=key(header);
  if(Object.prototype.hasOwnProperty.call(overrides,k))return String(overrides[k]||'')||null;
  return ALIASES[k]||canonicalColumn(header)||k;
}
// Eine bereits gefuellte Zielspalte wird nicht ueberschrieben: fuehrt eine Datei 'Name' UND
// 'Teilnehmername', gewinnt der zuerst gelesene Wert, statt dass der zweite ihn loescht.
export function mapParticipantRows(rows:Record<string,unknown>[],overrides:Record<string,string>={}){return rows.map(row=>{const out:Record<string,unknown>={};for(const [h,v] of Object.entries(row)){const target=zielFeld(h,overrides);if(!target)continue;if(out[target]!==undefined&&String(out[target]??'').trim())continue;out[target]=v;}return out;});}

// Der Kunde sah bisher nirgends, welche seiner Spalten das Portal ueberhaupt gelesen hat. Lag die
// Erkennung daneben, blieb ihm nur, die Datei umzubenennen und erneut hochzuladen. Diese Auskunft
// benennt je Quellspalte, als was sie gelesen wurde - und was in ihr steht, damit die Zuordnung
// am Beispiel nachvollziehbar ist statt nur am Spaltennamen.
export function describeParticipantColumns(rows:Record<string,unknown>[],overrides:Record<string,string>={}){
  const gesehen=new Map<string,{header:string;key:string;mapped_to:string|null;sample:string}>();
  for(const row of rows.slice(0,50))for(const [h,v] of Object.entries(row)){
    const k=key(h),vorhanden=gesehen.get(k);
    const probe=String(v??'').trim().slice(0,60);
    if(!vorhanden)gesehen.set(k,{header:h,key:k,mapped_to:zielFeld(h,overrides),sample:probe});
    else if(!vorhanden.sample&&probe)vorhanden.sample=probe;
  }
  return[...gesehen.values()];
}

// Die Vorschau gibt die eingelesenen Rohzeilen mit zurueck. Nur so kann die Oberflaeche eine
// Spaltenzuordnung anbieten, ohne dass der Kunde dieselbe Datei ein zweites Mal hochlaedt.
function mitSpalten(preview:any,rohzeilen:Record<string,unknown>[]){return{...preview,source_rows:rohzeilen,columns:describeParticipantColumns(rohzeilen)};}
// Der Weg fuer eine Vorschau, die der Kunde nach einer Spaltenzuordnung neu anstossen kann: er
// schickt dieselben Rohzeilen zurueck, dazu seine Zuordnung. Ohne diesen Weg bliebe ihm nur,
// die Datei umzubenennen und erneut hochzuladen.
export async function previewParticipantImportRows(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const roh=Array.isArray(input.rows)?input.rows as Record<string,unknown>[]:[];
  const overrides=input.column_overrides&&typeof input.column_overrides==='object'?input.column_overrides as Record<string,string>:{};
  const rows=roh.length?mapParticipantRows(roh,overrides):roh;
  const preview=await previewParticipantImport(env,auth,tenantId,{...input,rows}) as any;
  return roh.length?{...preview,source_rows:roh,columns:describeParticipantColumns(roh,overrides)}:preview;
}

export async function previewParticipantImportFile(env:Env,auth:CoreAuthContext,tenantId:string,request:Request){
  const form=await request.formData(),file=form.get('file');if(!(file instanceof File))throw new Error('IMPORT_FILE_REQUIRED');if(file.size>15*1024*1024)throw new Error('IMPORT_FILE_TOO_LARGE');const name=file.name.toLowerCase(),type=file.type.toLowerCase();
  if(name.endsWith('.csv')||type==='text/csv'){const parsed=parseCsv(await file.text());return mitSpalten(await previewParticipantImport(env,auth,tenantId,{source_name:file.name,source_kind:'structured',rows:mapParticipantRows(parsed.rows)}),parsed.rows);}
  if(name.endsWith('.xlsx')||type==='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'){const parsed=await parseXlsx(await file.arrayBuffer());return mitSpalten(await previewParticipantImport(env,auth,tenantId,{source_name:file.name,source_kind:'structured',rows:mapParticipantRows(parsed.rows)}),parsed.rows);}
  if(name.endsWith('.json')||type==='application/json'){let value:unknown;try{value=JSON.parse(await file.text());}catch{throw new Error('IMPORT_JSON_INVALID');}const rows=Array.isArray(value)?value:(value&&typeof value==='object'&&Array.isArray((value as any).rows)?(value as any).rows:null);if(!rows)throw new Error('IMPORT_JSON_ROWS_REQUIRED');return mitSpalten(await previewParticipantImport(env,auth,tenantId,{source_name:file.name,source_kind:'structured',rows:mapParticipantRows(rows as Record<string,unknown>[])}),rows as Record<string,unknown>[]);}
  if(name.endsWith('.txt')||type.startsWith('text/'))return previewParticipantImport(env,auth,tenantId,{source_name:file.name,source_kind:'pasted_text',text:await file.text()});
  if(name.endsWith('.pdf')||type==='application/pdf')throw new Error('PDF_CLIENT_EXTRACTION_REQUIRED');
  throw new Error('UNSUPPORTED_PARTICIPANT_IMPORT_FILE');
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireCourseAccess, requireRole } from './permissions.js';
import { id, nowIso, safeString, sha256Text } from './utils.js';

// Pruefungsvarianten (Master-Spec V2 §2.4, §2.5).
//
// Ohne Varianten schreiben alle dieselbe Arbeit: Nebensitzende sehen denselben Bogen, und ein
// Nachschreibtermin ist entweder dieselbe Arbeit oder eine unverbundene neue.
//
// Zwei Regeln setzt der Server durch, nicht der gute Wille:
//  - GLEICHWERTIGKEIT. Varianten mit unterschiedlicher Punktzahl oder Aufgabenzahl bewerten
//    Menschen nach verschiedenen Massstaeben (Art. 3 Abs. 1 GG). Geprueft wird beim Freigeben,
//    weil danach geschrieben wird.
//  - Die Zuteilung ist NACHVOLLZIEHBAR, nicht zufaellig. Ein Zufallsgenerator laesst sich nach der
//    Pruefung nicht mehr nachrechnen; bei einem Einspruch steht dann Aussage gegen Aussage.

export const MAX_VARIANTEN=12;
const clean=(v:unknown,n=500)=>safeString(v,n);
function manager(auth:CoreAuthContext,courseId:string){requireRole(auth,'class_admin');requireCourseAccess(auth,courseId,'class_admin');}

export type VariantenKopf={id:string;label:string;status:string;nur_auf_zuweisung:number;fragen:number;punkte:number};

/** Kopfdaten aller Varianten einer Pruefung, mit Aufgabenzahl und Punktsumme - in einer Abfrage. */
export async function variantenKoepfe(env:Env,tenantId:string,quizId:string):Promise<VariantenKopf[]>{
  return (await env.DB.prepare('SELECT v.id,v.label,v.status,v.nur_auf_zuweisung,COUNT(q.id) AS fragen,COALESCE(SUM(q.max_points),0) AS punkte FROM exam_variants v LEFT JOIN exam_variant_questions vq ON vq.variant_id=v.id LEFT JOIN quiz_questions q ON q.id=vq.question_id WHERE v.tenant_id=? AND v.quiz_id=? GROUP BY v.id ORDER BY v.label')
    .bind(tenantId,quizId).all<VariantenKopf>()).results??[];
}

export async function createVariant(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,quizId:string,input:Record<string,unknown>){
  manager(auth,courseId);
  const quiz=await env.DB.prepare('SELECT id FROM quizzes WHERE id=? AND tenant_id=? AND course_id=?').bind(quizId,tenantId,courseId).first();
  if(!quiz)throw new Error('QUIZ_NOT_FOUND');
  const label=clean(input.label,60);
  if(!label)throw new Error('VARIANT_LABEL_REQUIRED');
  const fragen=Array.isArray(input.question_ids)?[...new Set((input.question_ids as unknown[]).map(x=>clean(x,120)).filter(Boolean))]:[];
  if(!fragen.length||fragen.length>200)throw new Error('VARIANT_QUESTIONS_REQUIRED');
  if((await variantenKoepfe(env,tenantId,quizId)).length>=MAX_VARIANTEN)throw new Error('VARIANT_LIMIT_REACHED');
  // Die Aufgaben muessen aus den Katalogen DIESES Kurses stammen - sonst liesse sich ueber eine
  // Variante fremder Kursinhalt in die Pruefung holen.
  const platz=fragen.map(()=>'?').join(',');
  const gefunden=(await env.DB.prepare(`SELECT q.id FROM quiz_questions q JOIN quiz_banks b ON b.id=q.bank_id WHERE q.tenant_id=? AND b.course_id=? AND q.id IN (${platz})`)
    .bind(tenantId,courseId,...fragen).all<{id:string}>()).results??[];
  if(gefunden.length!==fragen.length)throw new Error('VARIANT_QUESTION_SCOPE_INVALID');
  const vid=id('var_'),ts=nowIso();
  try{
    await env.DB.batch([
      env.DB.prepare('INSERT INTO exam_variants(id,tenant_id,course_id,quiz_id,label,beschreibung,status,nur_auf_zuweisung,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,\'entwurf\',?,?,?,?)')
        .bind(vid,tenantId,courseId,quizId,label,clean(input.beschreibung,2000)||null,input.nur_auf_zuweisung===true?1:0,auth.userId,ts,ts),
      ...fragen.map((q,i)=>env.DB.prepare('INSERT INTO exam_variant_questions(variant_id,question_id,sort_order) VALUES(?,?,?)').bind(vid,q,i)),
    ]);
  }catch(e){
    if(/UNIQUE/i.test(String((e as Error).message)))throw new Error('VARIANT_LABEL_TAKEN');
    throw e;
  }
  await audit(env.DB,auth.userId,'exam.variant_created',tenantId,courseId,'exam_variant',vid,{label,fragen:fragen.length});
  return{id:vid,label,fragen:fragen.length};
}

/**
 * Freigeben - und genau hier wird die Gleichwertigkeit geprueft.
 *
 * Gegen die bereits freigegebenen Varianten UND gegen die Grundfassung der Pruefung: wer Variante B
 * freigibt, muss denselben Massstab treffen wie A, sonst sind die beiden Haelften der Klasse nicht
 * mehr vergleichbar.
 */
export async function activateVariant(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,quizId:string,variantId:string){
  manager(auth,courseId);
  const koepfe=await variantenKoepfe(env,tenantId,quizId);
  const meine=koepfe.find(k=>k.id===variantId);
  if(!meine)throw new Error('VARIANT_NOT_FOUND');
  if(!Number(meine.fragen))throw new Error('VARIANT_QUESTIONS_REQUIRED');
  // Die Grundfassung der Pruefung ist der Massstab, wenn es sie gibt.
  const grund=await env.DB.prepare('SELECT COUNT(l.question_id) AS fragen,COALESCE(SUM(q.max_points),0) AS punkte FROM quiz_question_links l JOIN quiz_questions q ON q.id=l.question_id WHERE l.quiz_id=?')
    .bind(quizId).first<{fragen:number;punkte:number}>();
  const massstaebe=[...koepfe.filter(k=>k.status==='aktiv'&&k.id!==variantId).map(k=>({was:`Variante ${k.label}`,fragen:Number(k.fragen),punkte:Number(k.punkte)}))];
  if(Number(grund?.fragen||0))massstaebe.push({was:'Grundfassung der Prüfung',fragen:Number(grund?.fragen),punkte:Number(grund?.punkte)});
  for(const m of massstaebe){
    if(m.fragen!==Number(meine.fragen)||Math.abs(m.punkte-Number(meine.punkte))>0.001)
      throw new Error('VARIANT_NOT_EQUIVALENT');
  }
  const ts=nowIso();
  await env.DB.prepare("UPDATE exam_variants SET status='aktiv',updated_at=? WHERE id=? AND tenant_id=?").bind(ts,variantId,tenantId).run();
  await audit(env.DB,auth.userId,'exam.variant_activated',tenantId,courseId,'exam_variant',variantId,{fragen:meine.fragen,punkte:meine.punkte});
  return{status:'aktiv',fragen:Number(meine.fragen),punkte:Number(meine.punkte)};
}

export async function archiveVariant(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,variantId:string){
  manager(auth,courseId);
  const ts=nowIso();
  // Archivieren statt loeschen: die geschriebenen Versuche zeigen auf diese Variante, und ihre
  // Aufgaben sind der Beleg dafuer, was die Person vor sich hatte.
  const r=await env.DB.prepare("UPDATE exam_variants SET status='archiviert',updated_at=? WHERE id=? AND tenant_id=? AND course_id=?").bind(ts,variantId,tenantId,courseId).run();
  if(!r.meta?.changes)throw new Error('VARIANT_NOT_FOUND');
  await audit(env.DB,auth.userId,'exam.variant_archived',tenantId,courseId,'exam_variant',variantId);
  return{status:'archiviert'};
}

export async function assignVariant(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,quizId:string,input:Record<string,unknown>){
  manager(auth,courseId);
  const userId=clean(input.user_id,120),variantId=clean(input.variant_id,120);
  if(!userId)throw new Error('VARIANT_ASSIGNMENT_INVALID');
  const ts=nowIso();
  if(!variantId){
    await env.DB.prepare('DELETE FROM exam_variant_assignments WHERE tenant_id=? AND quiz_id=? AND user_id=?').bind(tenantId,quizId,userId).run();
    await audit(env.DB,auth.userId,'exam.variant_unassigned',tenantId,courseId,'quiz',quizId,{user_id:userId});
    return{assigned:false};
  }
  const v=await env.DB.prepare("SELECT id FROM exam_variants WHERE id=? AND tenant_id=? AND quiz_id=? AND status='aktiv'").bind(variantId,tenantId,quizId).first();
  if(!v)throw new Error('VARIANT_NOT_ACTIVE');
  const mitglied=await env.DB.prepare("SELECT 1 x FROM memberships WHERE tenant_id=? AND course_id=? AND user_id=? AND role='participant'").bind(tenantId,courseId,userId).first();
  if(!mitglied)throw new Error('VARIANT_USER_NOT_IN_COURSE');
  await env.DB.prepare('INSERT INTO exam_variant_assignments(tenant_id,quiz_id,user_id,variant_id,grund,zugewiesen_von,zugewiesen_am) VALUES(?,?,?,?,?,?,?) ON CONFLICT(tenant_id,quiz_id,user_id) DO UPDATE SET variant_id=excluded.variant_id,grund=excluded.grund,zugewiesen_von=excluded.zugewiesen_von,zugewiesen_am=excluded.zugewiesen_am')
    .bind(tenantId,quizId,userId,variantId,clean(input.grund,500)||null,auth.userId,ts).run();
  await audit(env.DB,auth.userId,'exam.variant_assigned',tenantId,courseId,'exam_variant',variantId,{user_id:userId});
  return{assigned:true};
}

/**
 * Welche Variante diese Person bei diesem Versuch bekommt.
 *
 * Reihenfolge: eine ausdrueckliche Zuweisung geht vor. Sonst wird gleichmaessig verteilt - aber
 * NACHVOLLZIEHBAR, nicht zufaellig: aus Pruefung, Person und Versuchsnummer entsteht immer
 * dieselbe Zahl. Damit laesst sich nach der Pruefung nachrechnen, dass die Verteilung stimmte, und
 * ein zweiter Versuch bekommt gezielt einen anderen Bogen als der erste.
 *
 * Varianten, die nur auf Zuweisung gelten (der Nachschreibbogen), bleiben aus der Verteilung heraus.
 */
export async function variantFuerVersuch(env:Env,tenantId:string,quizId:string,userId:string,versuchsnummer:number):Promise<{variant_id:string;label:string;zugewiesen:boolean}|null>{
  const zuweisung=await env.DB.prepare('SELECT a.variant_id,v.label FROM exam_variant_assignments a JOIN exam_variants v ON v.id=a.variant_id WHERE a.tenant_id=? AND a.quiz_id=? AND a.user_id=? AND v.status=\'aktiv\'')
    .bind(tenantId,quizId,userId).first<{variant_id:string;label:string}>();
  if(zuweisung)return{variant_id:zuweisung.variant_id,label:zuweisung.label,zugewiesen:true};
  const offen=(await variantenKoepfe(env,tenantId,quizId)).filter(k=>k.status==='aktiv'&&!Number(k.nur_auf_zuweisung));
  if(!offen.length)return null;
  // sha256Text liefert Base64, nicht Hex - die Zahl wird deshalb aus den Zeichen gerechnet und
  // nicht ueber parseInt(...,16) geraten. Das war der Unterschied zwischen "gleichmaessig verteilt"
  // und "NaN, also gar kein Bogen".
  const streu=await sha256Text(`${quizId}:${userId}`);
  let zahl=0;
  for(const z of streu.slice(0,16))zahl=(zahl*31+z.charCodeAt(0))%1000003;
  // Die Versuchsnummer verschiebt die Auswahl: der zweite Versuch bekommt einen anderen Bogen.
  const gewaehlt=offen[(zahl+Math.max(0,versuchsnummer-1))%offen.length];
  return{variant_id:gewaehlt.id,label:gewaehlt.label,zugewiesen:false};
}

/** Die Aufgaben eines Bogens, in seiner Reihenfolge. */
export async function variantFragen(env:Env,variantId:string):Promise<string[]>{
  return ((await env.DB.prepare('SELECT question_id FROM exam_variant_questions WHERE variant_id=? ORDER BY sort_order').bind(variantId).all<{question_id:string}>()).results??[]).map(x=>x.question_id);
}

export async function listVariants(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,quizId:string){
  manager(auth,courseId);
  const varianten=await variantenKoepfe(env,tenantId,quizId);
  const zuweisungen=(await env.DB.prepare('SELECT a.user_id,a.variant_id,a.grund,u.display_name,v.label FROM exam_variant_assignments a JOIN users u ON u.id=a.user_id JOIN exam_variants v ON v.id=a.variant_id WHERE a.tenant_id=? AND a.quiz_id=? ORDER BY u.display_name')
    .bind(tenantId,quizId).all()).results??[];
  const teilnehmer=(await env.DB.prepare("SELECT DISTINCT u.id,u.display_name FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.tenant_id=? AND m.course_id=? AND m.role='participant' AND u.status='active' ORDER BY u.display_name")
    .bind(tenantId,courseId).all()).results??[];
  const bank=(await env.DB.prepare('SELECT q.id,q.prompt,q.max_points FROM quiz_questions q JOIN quiz_banks b ON b.id=q.bank_id WHERE q.tenant_id=? AND b.course_id=? ORDER BY q.created_at')
    .bind(tenantId,courseId).all()).results??[];
  return{varianten,zuweisungen,teilnehmer,fragen:bank};
}

// Platzhalter in Dokumentvorlagen.
//
// Die Regel, von der alles andere abhaengt: ein Platzhalter wird ERSETZT, nicht AUSGEWERTET.
// Es gibt hier keine Ausdruecke, keine Bedingungen, keine Schleifen, kein eval, keine
// Funktionsaufrufe - und damit nichts, was ein Traeger, der eine Vorlage hochlaedt, dazu bringen
// koennte, Code auszufuehren oder an fremde Daten zu kommen.
//
// Erlaubt ist ausschliesslich, was der Aufrufer vorher in die Wertetabelle gelegt hat. Diese
// Tabelle ist eine Map und kein Objekt: bei einem Objekt waeren {{constructor}}, {{__proto__}}
// oder {{toString}} ueber die Prototypkette auffindbar gewesen und haetten Funktionsquelltext in
// ein Kundendokument geschrieben. Eine Map kennt nur, was ausdruecklich hineingelegt wurde.
//
// Alles Uebrige bleibt UNVERAENDERT stehen. Das ist Absicht: ein stillschweigend geleerter
// Platzhalter hinterlaesst ein Dokument mit einer Luecke, die niemandem auffaellt; ein stehen
// gebliebenes {{...}} sieht der Sachbearbeiter im ersten Ausdruck.

// Absichtlich weit gefasst: auch {{ 1+1 }} oder {{teilnehmer.name.toUpperCase()}} werden erkannt -
// und genau deshalb von der Wertetabelle abgelehnt und stehen gelassen. Ein enges Muster wuerde
// solche Formen gar nicht erst sehen und der Sicherheitsbeweis waere ein Zufall des Musters
// statt eine Entscheidung der Wertetabelle.
const PLATZHALTER=/\{\{([^{}]{0,120}?)\}\}/g;

/**
 * Ersetzt die Platzhalter, die in `werte` stehen. Jeder andere Platzhalter bleibt wortgleich
 * erhalten.
 *
 * Der Ersatztext wird NICHT erneut durchsucht: die Ersetzung laeuft in einem Durchgang ueber die
 * Vorlage. Sonst haette ein Teilnehmer, der sich "{{traeger.name}}" nennt, seinen Namen durch
 * fremden Text ersetzen lassen. Aus demselben Grund liefert der Rueckruf den Wert unveraendert
 * zurueck - eine Zeichenkette als Ersatz wuerde $&, $1 und $` als Verweise deuten.
 */
export function renderePlatzhalter(vorlage:unknown,werte:ReadonlyMap<string,string>):string{
  return String(vorlage??'').replace(PLATZHALTER,(ganz,roh)=>{
    const wert=werte.get(String(roh).trim().toLowerCase());
    return wert===undefined?ganz:wert;
  });
}

/** Die Platzhalter einer Vorlage, die niemand fuellen kann - fuer den Hinweis beim Speichern. */
export function unbekanntePlatzhalter(vorlage:unknown,erlaubt:ReadonlySet<string>):string[]{
  const gefunden=new Set<string>();
  for(const treffer of String(vorlage??'').matchAll(PLATZHALTER)){
    const schluessel=String(treffer[1]).trim().toLowerCase();
    if(!erlaubt.has(schluessel))gefunden.add(String(treffer[1]).trim().slice(0,80));
  }
  return [...gefunden].sort();
}

export type Zielgruppe='teilnehmer'|'kurs';
export type PlatzhalterEintrag={schluessel:string;bedeutung:string;nur:Zielgruppe|'beide'};

// Die feste Liste. Was hier nicht steht, gibt es nicht - unabhaengig davon, was in einer
// hochgeladenen Vorlage steht und welche Spalten die Datenbank sonst noch hat.
export const DOKUMENT_PLATZHALTER:readonly PlatzhalterEintrag[]=[
  {schluessel:'teilnehmer.name',bedeutung:'Name der teilnehmenden Person',nur:'teilnehmer'},
  {schluessel:'teilnehmer.email',bedeutung:'E-Mail-Adresse der teilnehmenden Person',nur:'teilnehmer'},
  {schluessel:'teilnehmer.nummer',bedeutung:'Teilnehmernummer aus eurer Verwaltung',nur:'teilnehmer'},
  {schluessel:'kurs.bezeichnung',bedeutung:'Name der Klasse bzw. des Kurses',nur:'beide'},
  {schluessel:'kurs.code',bedeutung:'Kurscode',nur:'beide'},
  {schluessel:'kurs.beginn',bedeutung:'Kursbeginn (TT.MM.JJJJ)',nur:'beide'},
  {schluessel:'kurs.ende',bedeutung:'Kursende (TT.MM.JJJJ)',nur:'beide'},
  {schluessel:'kurs.teilnehmerzahl',bedeutung:'Zahl der aktiven Teilnehmenden',nur:'beide'},
  {schluessel:'zeitraum.von',bedeutung:'Beginn des Zeitraums, standardmaessig der Kursbeginn',nur:'beide'},
  {schluessel:'zeitraum.bis',bedeutung:'Ende des Zeitraums, standardmaessig das Kursende',nur:'beide'},
  {schluessel:'traeger.name',bedeutung:'Name eures Traegers',nur:'beide'},
  {schluessel:'traeger.portal',bedeutung:'Name eures Portals',nur:'beide'},
  {schluessel:'dokument.datum',bedeutung:'Ausstellungsdatum (TT.MM.JJJJ)',nur:'beide'},
  {schluessel:'dokument.nummer',bedeutung:'laufende Nummer des Dokuments',nur:'beide'},
  {schluessel:'dokument.vorlage',bedeutung:'Name der verwendeten Vorlage',nur:'beide'},
];

/**
 * Welche Platzhalter diese Zielgruppe fuellen darf.
 *
 * Eine kursweite Vorlage - der Kostentraegerbericht - erreicht teilnehmer.* NICHT. Nicht weil es
 * unschoen waere, sondern weil ein Bericht an den Kostentraeger sonst je nach Vorlage einen
 * einzelnen Namen aus der Klasse mitfuehren wuerde, ohne dass es jemand angeordnet hat.
 */
export function erlaubtePlatzhalter(zielgruppe:Zielgruppe):Set<string>{
  return new Set(DOKUMENT_PLATZHALTER.filter(p=>p.nur==='beide'||p.nur===zielgruppe).map(p=>p.schluessel));
}

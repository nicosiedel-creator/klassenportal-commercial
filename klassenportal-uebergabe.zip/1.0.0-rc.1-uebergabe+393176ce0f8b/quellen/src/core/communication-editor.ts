import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Kommunikations- und Layout-Editor (K1).
//
// Anschreiben und Aushaenge waren Freitext. Wer Gestaltung wollte, schrieb HTML hinein - und
// damit war jede Vorlage eine offene Tuer: ein <script> in einer Elternmail laeuft im Browser
// der Eltern. Platzhalter waren frei erfindbar; {{passwort}} funktionierte genau dann, wenn das
// einsetzende Modul das Feld zufaellig im Datensatz hatte.
//
// Eine Vorlage ist deshalb eine LISTE VON BLOECKEN aus einem geschlossenen Vorrat. Gestaltung
// entsteht durch die Bloecke, nicht durch eingeschleustes Markup - und alles, was aus Daten
// kommt, wird beim Rendern maskiert. Nicht "gefiltert": maskiert. Ein Filter, der boesartiges
// Markup zu erkennen versucht, verliert dieses Spiel frueher oder spaeter.

const clean=(v:unknown,n=8000)=>safeString(v,n);
export const BLOCKARTEN=['ueberschrift','absatz','liste','bild','trenner','knopf','hinweis'] as const;
export const KANAELE=['email','portal','aushang','brief'] as const;

/**
 * Welche Platzhalter es gibt - je Kanal.
 *
 * Der Vorrat ist erklaert und geschlossen. Ein unbekannter Platzhalter wird abgelehnt, statt
 * beim Einsetzen still leer zu bleiben oder - schlimmer - ein Feld zu treffen, das niemand
 * herausgeben wollte.
 */
export const PLATZHALTER:Record<string,string[]>={
  email:['anrede','vorname','nachname','kurs','traeger','datum','termin','frist','link'],
  portal:['anrede','vorname','kurs','traeger','datum','termin','frist'],
  aushang:['kurs','traeger','datum','termin','raum'],
  brief:['anrede','vorname','nachname','kurs','traeger','datum','termin','frist','adresse'],
};
// Mehr Bloecke braucht kein Anschreiben, und die Grenze haelt das Rendern billig.
const HOECHSTBLOECKE=60;

export interface Block{art:string;text?:string;punkte?:string[];asset_id?:string;alt?:string;ziel?:string;stufe?:number}

/** Maskieren, nicht filtern. Alles, was aus Daten kommt, geht hier durch. */
const maskiere=(v:unknown)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c] as string));

function pruefeBlock(block:Block,kanal:string):Block{
  const art=clean(block.art,30);
  if(!(BLOCKARTEN as readonly string[]).includes(art))throw new Error('VORLAGE_BLOCKART_UNGUELTIG');
  const erlaubt=PLATZHALTER[kanal]??[];
  const pruefeText=(t:string)=>{
    for(const m of t.matchAll(/\{\{\s*([a-z_]+)\s*\}\}/g))
      if(!erlaubt.includes(m[1]))throw new Error('VORLAGE_PLATZHALTER_UNBEKANNT');
    return t;
  };
  if(art==='bild'){
    const asset=clean(block.asset_id,120);
    if(!asset)throw new Error('VORLAGE_BILD_OHNE_MEDIUM');
    // Ohne Alternativtext ist das Bild fuer einen Screenreader nicht vorhanden. Bei einem
    // Traeger mit oeffentlicher Foerderung ist das ein Befund, kein Schoenheitsfehler.
    const alt=clean(block.alt,300);
    if(alt.length<3)throw new Error('VORLAGE_BILD_OHNE_ALT');
    return{art,asset_id:asset,alt};
  }
  if(art==='trenner')return{art};
  if(art==='liste'){
    const punkte=(Array.isArray(block.punkte)?block.punkte:[]).map(p=>pruefeText(clean(p,500))).filter(Boolean).slice(0,30);
    if(!punkte.length)throw new Error('VORLAGE_LISTE_LEER');
    return{art,punkte};
  }
  if(art==='knopf'){
    const text=pruefeText(clean(block.text,120)),ziel=clean(block.ziel,300);
    if(!text)throw new Error('VORLAGE_TEXT_ERFORDERLICH');
    // Nur Portallinks und Platzhalter. Ein freies Ziel in einer Elternmail ist ein Werkzeug
    // fuer jeden, der Zugriff auf die Vorlage hat.
    if(!/^\/[A-Za-z0-9/_.-]*$/.test(ziel)&&!/^\{\{\s*link\s*\}\}$/.test(ziel))throw new Error('VORLAGE_ZIEL_UNZULAESSIG');
    return{art,text,ziel};
  }
  const text=pruefeText(clean(block.text,4000));
  if(!text)throw new Error('VORLAGE_TEXT_ERFORDERLICH');
  if(art==='ueberschrift'){
    const stufe=Math.trunc(Number(block.stufe??2));
    if(!Number.isFinite(stufe)||stufe<2||stufe>4)throw new Error('VORLAGE_UEBERSCHRIFT_STUFE');
    return{art,text,stufe};
  }
  return{art,text};
}

export async function legeVorlageAn(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const schluessel=clean(input.schluessel,60).toLowerCase().replace(/[^a-z0-9_-]+/g,'-');
  const titel=clean(input.titel,200),kanal=clean(input.kanal,20);
  if(schluessel.length<3)throw new Error('VORLAGE_SCHLUESSEL_ERFORDERLICH');
  if(titel.length<3)throw new Error('VORLAGE_TITEL_ERFORDERLICH');
  if(!(KANAELE as readonly string[]).includes(kanal))throw new Error('VORLAGE_KANAL_UNGUELTIG');
  const vorhanden=await env.DB.prepare('SELECT 1 AS ok FROM communication_templates WHERE tenant_id=? AND schluessel=?').bind(tenantId,schluessel).first();
  if(vorhanden)throw new Error('VORLAGE_SCHLUESSEL_VERGEBEN');
  const bloecke=(Array.isArray(input.bloecke)?input.bloecke as Block[]:[]).slice(0,HOECHSTBLOECKE).map(b=>pruefeBlock(b,kanal));
  const ts=nowIso(),vorlageId=id('vrl_');
  await env.DB.prepare('INSERT INTO communication_templates(id,tenant_id,schluessel,titel,kanal,betreff,bloecke_json,fassung,status,erstellt_von,created_at,updated_at) VALUES(?,?,?,?,?,?,?,1,?,?,?,?)')
    .bind(vorlageId,tenantId,schluessel,titel,kanal,clean(input.betreff,200)||null,JSON.stringify(bloecke),'entwurf',auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'communication_template.created',tenantId,undefined,'communication_template',vorlageId,{kanal});
  return{id:vorlageId,schluessel,kanal,bloecke:bloecke.length};
}

async function ladeVorlage(env:Env,tenantId:string,vorlageId:string){
  const v=await env.DB.prepare('SELECT id,schluessel,titel,kanal,betreff,bloecke_json,fassung,status FROM communication_templates WHERE (id=? OR schluessel=?) AND tenant_id=?')
    .bind(clean(vorlageId,120),clean(vorlageId,120),tenantId).first<{id:string;schluessel:string;titel:string;kanal:string;betreff:string|null;bloecke_json:string;fassung:number;status:string}>();
  if(!v)throw new Error('VORLAGE_NICHT_GEFUNDEN');
  return v;
}

export async function bearbeiteVorlage(env:Env,auth:CoreAuthContext,tenantId:string,vorlageId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const v=await ladeVorlage(env,tenantId,vorlageId);
  if(v.status==='zurueckgezogen')throw new Error('VORLAGE_ZURUECKGEZOGEN');
  const bloecke=(Array.isArray(input.bloecke)?input.bloecke as Block[]:JSON.parse(v.bloecke_json||'[]') as Block[])
    .slice(0,HOECHSTBLOECKE).map(b=>pruefeBlock(b,v.kanal));
  const ts=nowIso();
  // Bearbeiten setzt zurueck auf Entwurf: eine veroeffentlichte Vorlage, die sich unter der
  // Hand aendert, ist genau der Brief, den hinterher niemand mehr nachvollziehen kann.
  await env.DB.prepare("UPDATE communication_templates SET titel=?,betreff=?,bloecke_json=?,status='entwurf',updated_at=? WHERE id=? AND tenant_id=?")
    .bind(clean(input.titel,200)||v.titel,input.betreff===undefined?v.betreff:clean(input.betreff,200)||null,JSON.stringify(bloecke),ts,v.id,tenantId).run();
  return{id:v.id,bloecke:bloecke.length,status:'entwurf'};
}

/**
 * Rendern.
 *
 * Bloecke werden zu Markup, Daten werden maskiert. Ein Platzhalter ohne Wert bleibt sichtbar
 * als [fehlt: name] stehen - eine leere Stelle im Elternbrief faellt niemandem auf, eine
 * markierte schon.
 */
export function rendere(bloecke:Block[],werte:Record<string,unknown>,kanal:string){
  const erlaubt=PLATZHALTER[kanal]??[];
  const fehlend=new Set<string>();
  const setzeEin=(t:string)=>maskiere(t).replace(/\{\{\s*([a-z_]+)\s*\}\}/g,(_,name:string)=>{
    if(!erlaubt.includes(name))return `[unbekannt: ${maskiere(name)}]`;
    const wert=werte[name];
    if(wert===undefined||wert===null||String(wert)===''){fehlend.add(name);return `[fehlt: ${maskiere(name)}]`;}
    return maskiere(wert);
  });
  const teile=bloecke.map(b=>{
    switch(b.art){
      case 'ueberschrift':{const n=Math.min(4,Math.max(2,Number(b.stufe??2)));return `<h${n}>${setzeEin(String(b.text??''))}</h${n}>`;}
      case 'absatz':return `<p>${setzeEin(String(b.text??''))}</p>`;
      case 'hinweis':return `<div class="notice">${setzeEin(String(b.text??''))}</div>`;
      case 'liste':return `<ul>${(b.punkte??[]).map(p=>`<li>${setzeEin(String(p))}</li>`).join('')}</ul>`;
      case 'trenner':return '<hr>';
      case 'bild':return `<img src="/api/media/${encodeURIComponent(String(b.asset_id??''))}/content" alt="${maskiere(b.alt)}">`;
      case 'knopf':{const ziel=String(b.ziel??'');
        const href=/^\{\{\s*link\s*\}\}$/.test(ziel)?setzeEin(ziel):maskiere(ziel);
        return `<p><a class="btn" href="${href}">${setzeEin(String(b.text??''))}</a></p>`;}
      default:return '';
    }
  });
  return{html:teile.join('\n'),fehlende_werte:[...fehlend]};
}

/**
 * Vorschau - mit Beispieldaten, und als Beispiel gekennzeichnet.
 *
 * Eine Vorschau, die stillschweigend die Daten einer echten Person zeigt, ist im Zweifel eine
 * Datenweitergabe an den, der gerade auf den Bildschirm sieht.
 */
export async function vorschau(env:Env,auth:CoreAuthContext,tenantId:string,vorlageId:string,werte?:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const v=await ladeVorlage(env,tenantId,vorlageId);
  const bloecke=JSON.parse(v.bloecke_json||'[]') as Block[];
  const beispiel:Record<string,unknown>={anrede:'Sehr geehrte Frau Beispiel',vorname:'Maria',nachname:'Beispiel',
    kurs:'Fachklasse Beispiel',traeger:'Ihr Bildungsträger',datum:new Date().toLocaleDateString('de-DE'),
    termin:'Montag, 9:00 Uhr',frist:'in zwei Wochen',raum:'Raum 1',adresse:'Musterstraße 1, 12345 Musterstadt',link:'/portal'};
  const eigene=werte&&Object.keys(werte).length?werte:null;
  const {html,fehlende_werte}=rendere(bloecke,eigene??beispiel,v.kanal);
  return{titel:v.titel,kanal:v.kanal,betreff:v.betreff,html,fehlende_werte,
    // Genau dieses Feld gehoert in die Oberflaeche - sonst haelt jemand die Vorschau fuer den Versand.
    beispieldaten:!eigene};
}

/**
 * Veroeffentlichen - mit Rechtepruefung fuer jedes Bild.
 *
 * Beim Anlegen zu pruefen reicht nicht: die Lizenz kann seither abgelaufen sein, und ob ein
 * Bild oeffentlich verwendet werden darf, haengt am Kanal. Ein Aushang ist oeffentlich.
 */
export async function veroeffentlicheVorlage(env:Env,auth:CoreAuthContext,tenantId:string,vorlageId:string,heute?:string){
  requireRole(auth,'class_admin');
  const v=await ladeVorlage(env,tenantId,vorlageId);
  if(v.status==='veroeffentlicht')throw new Error('VORLAGE_BEREITS_VEROEFFENTLICHT');
  const bloecke=JSON.parse(v.bloecke_json||'[]') as Block[];
  if(!bloecke.length)throw new Error('VORLAGE_LEER');
  const bilder=bloecke.filter(b=>b.art==='bild').map(b=>String(b.asset_id));
  if(bilder.length){
    const tag=clean(heute,10)||nowIso().slice(0,10);
    const zweck=v.kanal==='aushang'||v.kanal==='brief'?'druck':v.kanal==='email'?'oeffentlich':'unterricht';
    const ph=bilder.map(()=>'?').join(',');
    // Eine Abfrage fuer alle Bilder der Vorlage, nicht eine je Bild.
    const medien=((await env.DB.prepare(`SELECT id,titel,lizenz,lizenz_bis,status,verwendung_json FROM media_assets WHERE tenant_id=? AND id IN (${ph})`)
      .bind(tenantId,...bilder).all<{id:string;titel:string;lizenz:string;lizenz_bis:string|null;status:string;verwendung_json:string}>()).results)??[];
    const karte=new Map(medien.map(m=>[m.id,m]));
    for(const b of bilder){
      const m=karte.get(b);
      if(!m)throw new Error('VORLAGE_BILD_NICHT_GEFUNDEN');
      if(m.lizenz==='unklar')throw new Error('MEDIUM_LIZENZ_UNKLAR');
      if(m.status!=='aktiv'||(m.lizenz_bis&&m.lizenz_bis<tag))throw new Error('MEDIUM_LIZENZ_ABGELAUFEN');
      let erlaubt:string[]=[];try{erlaubt=JSON.parse(m.verwendung_json||'[]');}catch{}
      if(!erlaubt.includes(zweck))throw new Error('MEDIUM_ZWECK_NICHT_GEDECKT');
    }
  }
  const ts=nowIso();
  const naechste=Number((await env.DB.prepare('SELECT COALESCE(MAX(fassung),0)+1 AS n FROM communication_template_versions WHERE template_id=?').bind(v.id).first<{n:number}>())?.n??1);
  await env.DB.batch([
    env.DB.prepare('INSERT INTO communication_template_versions(id,tenant_id,template_id,fassung,titel,betreff,bloecke_json,veroeffentlicht_von,veroeffentlicht_am) VALUES(?,?,?,?,?,?,?,?,?)')
      .bind(id('vrf_'),tenantId,v.id,naechste,v.titel,v.betreff,v.bloecke_json,auth.userId,ts),
    env.DB.prepare("UPDATE communication_templates SET status='veroeffentlicht',fassung=?,veroeffentlicht_am=?,updated_at=? WHERE id=? AND tenant_id=?")
      .bind(naechste,ts,ts,v.id,tenantId)]);
  await audit(env.DB,auth.userId,'communication_template.published',tenantId,undefined,'communication_template',v.id,{fassung:naechste});
  return{fassung:naechste,status:'veroeffentlicht'};
}

/** Die veroeffentlichte Fassung fuer den Versand - Entwuerfe gehen nie hinaus. */
export async function vorlageZumVersand(env:Env,tenantId:string,schluessel:string,werte:Record<string,unknown>){
  const v=await env.DB.prepare("SELECT id,titel,kanal,betreff,bloecke_json,fassung FROM communication_templates WHERE tenant_id=? AND schluessel=? AND status='veroeffentlicht'")
    .bind(tenantId,clean(schluessel,60)).first<{id:string;titel:string;kanal:string;betreff:string|null;bloecke_json:string;fassung:number}>();
  if(!v)throw new Error('VORLAGE_NICHT_VEROEFFENTLICHT');
  const {html,fehlende_werte}=rendere(JSON.parse(v.bloecke_json||'[]') as Block[],werte,v.kanal);
  return{betreff:v.betreff,html,fassung:v.fassung,fehlende_werte};
}

export async function listeVorlagen(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  return ((await env.DB.prepare('SELECT id,schluessel,titel,kanal,status,fassung,updated_at FROM communication_templates WHERE tenant_id=? ORDER BY kanal,titel LIMIT 200')
    .bind(tenantId).all()).results)??[];
}

export async function vorlagenFassungen(env:Env,auth:CoreAuthContext,tenantId:string,vorlageId:string){
  requireRole(auth,'class_admin');
  return ((await env.DB.prepare('SELECT fassung,titel,veroeffentlicht_am FROM communication_template_versions WHERE tenant_id=? AND template_id=? ORDER BY fassung DESC LIMIT 50')
    .bind(tenantId,clean(vorlageId,120)).all()).results)??[];
}

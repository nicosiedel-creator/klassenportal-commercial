import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { kompetenzstand } from './competencies.js';
import { id, nowIso, safeString } from './utils.js';

// Individuelle Lernplanung und adaptive Wiederholung (L4, L5).
//
// Die Luecken waren sichtbar - participant-360 zeigt sie seit langem. Aber niemand plante etwas
// daraus: ein erkannter Rueckstand ohne Termin ist eine Feststellung, kein Plan. Und die
// vorhandenen learner_coach_plans und support_plans sind Betreuungsplaene ("wer kuemmert sich"),
// keine Lernplanung ("was ist bis wann nachzuholen").
//
// Gerechnet wird RUECKWAERTS vom Pruefungstermin. Drei Quellen speisen den Plan:
//  - belegte Luecken aus dem Kompetenzstand,
//  - versaeumte Einheiten aus der Anwesenheit,
//  - pruefungsrelevante Kompetenzen ohne jeden Nachweis.
//
// Die dritte Quelle bleibt bewusst getrennt: "noch nie geprueft" ist kein Rueckstand. Sie als
// Luecke zu fuehren waere eine Aussage ueber die Person, die auf nichts beruht - denselben
// Fehler vermeidet schon der Kompetenzstand.

const clean=(v:unknown,n=500)=>safeString(v,n);
const TAG=86400000;
const tagOk=(v:string)=>/^\d{4}-\d{2}-\d{2}$/.test(v);
// Mehr Schritte plant niemand sinnvoll, und die Grenze haelt den Plan innerhalb eines Batches.
const HOECHSTSCHRITTE=80;

type Schritt={quelle:'luecke'|'fehlzeit'|'ungeprueft'|'manuell';bezug_typ:string|null;bezug_id:string|null;titel:string;aufwand_minuten:number};

/**
 * Plan anlegen oder neu rechnen.
 *
 * Neu rechnen ersetzt die OFFENEN Schritte und laesst die erledigten stehen. Alles zu ersetzen
 * waere bequemer, wuerde aber die Nacharbeit unsichtbar machen, die jemand schon geleistet hat.
 */
export async function planeLernen(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,userId:string,input:Record<string,unknown>={}){
  const person=clean(userId,120)||auth.userId;
  if(person!==auth.userId)requireRole(auth,'class_admin');
  const termin=clean(input.pruefungstermin,10);
  if(!tagOk(termin))throw new Error('LERNPLAN_TERMIN_UNGUELTIG');
  const heute=clean(input.heute,10)||nowIso().slice(0,10);
  // Rueckwaerts von einem Termin, der schon war, laesst sich nichts planen.
  if(Date.parse(termin)<=Date.parse(heute))throw new Error('LERNPLAN_TERMIN_VERGANGEN');
  const wochenstunden=Math.trunc(Number(input.wochenstunden??4));
  if(!Number.isFinite(wochenstunden)||wochenstunden<1||wochenstunden>40)throw new Error('LERNPLAN_WOCHENSTUNDEN_UNGUELTIG');
  const stand=await kompetenzstand(env,auth,tenantId,courseId,person);
  const schritte:Schritt[]=[];
  for(const k of stand.kompetenzen){
    if(k.stand==='offen'||k.stand==='teilweise')
      schritte.push({quelle:'luecke',bezug_typ:'competency',bezug_id:k.competency_id,
        titel:`${k.code} ${k.title} — wiederholen (${k.prozent===null?'ohne Wert':`${k.prozent} %`})`,
        // Wer knapp unter der Schwelle liegt, braucht weniger als jemand bei null.
        aufwand_minuten:k.stand==='teilweise'?60:120});
    else if(k.stand==='ohne_nachweis')
      schritte.push({quelle:'ungeprueft',bezug_typ:'competency',bezug_id:k.competency_id,
        titel:`${k.code} ${k.title} — noch kein Nachweis`,aufwand_minuten:60});
  }
  // Versaeumte Einheiten: eine Abfrage, nicht eine je Termin.
  const fehlzeiten=((await env.DB.prepare(`SELECT s.id,s.session_date,COALESCE(s.subject,'Unterricht') AS thema,r.status
    FROM attendance_records r JOIN attendance_sessions s ON s.id=r.session_id
    WHERE r.tenant_id=? AND r.course_id=? AND r.user_id=? AND s.status='held' AND r.status IN ('excused_absent','unexcused_absent')
    ORDER BY s.session_date DESC LIMIT 40`).bind(tenantId,courseId,person).all<{id:string;session_date:string;thema:string}>()).results)??[];
  for(const f of fehlzeiten)schritte.push({quelle:'fehlzeit',bezug_typ:'attendance_session',bezug_id:f.id,
    titel:`${f.thema} vom ${f.session_date} nachholen`,aufwand_minuten:90});
  if(schritte.length>HOECHSTSCHRITTE)schritte.length=HOECHSTSCHRITTE;

  const ts=nowIso();
  let plan=await env.DB.prepare('SELECT id FROM learning_plans WHERE tenant_id=? AND user_id=? AND course_id=? AND pruefungstermin=?')
    .bind(tenantId,person,courseId,termin).first<{id:string}>();
  const planId=plan?.id??id('lpl_');
  // Die verfuegbaren Minuten bis zum Termin. Reicht es nicht, wird das GESAGT statt den Plan
  // stillschweigend zu stauchen - eine Lernplanung, die nicht aufgeht, ist eine Information.
  const tage=Math.max(1,Math.round((Date.parse(termin)-Date.parse(heute))/TAG));
  const verfuegbar=Math.round(tage/7*wochenstunden*60);
  const gebraucht=schritte.reduce((a,s)=>a+s.aufwand_minuten,0);
  const reicht=gebraucht<=verfuegbar;

  const anweisungen=[];
  if(plan)anweisungen.push(env.DB.prepare('UPDATE learning_plans SET wochenstunden=?,letzte_rechnung_am=?,reicht_die_zeit=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(wochenstunden,ts,reicht?1:0,ts,planId,tenantId));
  else anweisungen.push(env.DB.prepare('INSERT INTO learning_plans(id,tenant_id,user_id,course_id,pruefungstermin,wochenstunden,status,letzte_rechnung_am,reicht_die_zeit,erstellt_von,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(planId,tenantId,person,courseId,termin,wochenstunden,'aktiv',ts,reicht?1:0,auth.userId,ts,ts));
  // Nur die offenen Schritte weichen der neuen Rechnung. Was erledigt ist, bleibt erledigt.
  anweisungen.push(env.DB.prepare("DELETE FROM learning_plan_steps WHERE plan_id=? AND tenant_id=? AND status='offen' AND quelle<>'manuell'").bind(planId,tenantId));
  // Rueckwaerts verteilt: der letzte Schritt liegt unmittelbar vor dem Termin, die anderen
  // davor. Kein Schritt liegt nach dem Termin - das waere der haeufigste stille Planungsfehler.
  const abstand=Math.max(1,Math.floor(tage/Math.max(1,schritte.length+1)));
  schritte.forEach((s,i)=>{
    const faellig=new Date(Date.parse(termin)-(schritte.length-i)*abstand*TAG);
    const faelligTag=faellig.getTime()<Date.parse(heute)?heute:faellig.toISOString().slice(0,10);
    anweisungen.push(env.DB.prepare('INSERT INTO learning_plan_steps(id,tenant_id,plan_id,quelle,bezug_typ,bezug_id,titel,faellig_am,aufwand_minuten,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .bind(id('lps_'),tenantId,planId,s.quelle,s.bezug_typ,s.bezug_id,s.titel,faelligTag,s.aufwand_minuten,'offen',ts));
  });
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  await audit(env.DB,auth.userId,'learning_plan.calculated',tenantId,courseId,'learning_plan',planId,{schritte:schritte.length,reicht});
  return{id:planId,pruefungstermin:termin,schritte:schritte.length,benoetigte_minuten:gebraucht,verfuegbare_minuten:verfuegbar,reicht_die_zeit:reicht};
}

/**
 * Den Plan lesen - und dabei schliessen, was der Nachweis inzwischen erledigt hat.
 *
 * Das ist der Kern von L4: eine Wiederholungsaufgabe wird NICHT durch ein Haekchen erledigt,
 * sondern dadurch, dass die Kompetenz erneut erreicht ist. Ein Haekchen kann jeder setzen; ein
 * Nachweis nicht.
 */
export async function lernplan(env:Env,auth:CoreAuthContext,tenantId:string,planId:string){
  const plan=await env.DB.prepare('SELECT id,user_id,course_id,pruefungstermin,wochenstunden,status,reicht_die_zeit,letzte_rechnung_am FROM learning_plans WHERE id=? AND tenant_id=?')
    .bind(clean(planId,120),tenantId).first<{id:string;user_id:string;course_id:string;pruefungstermin:string;wochenstunden:number;status:string;reicht_die_zeit:number;letzte_rechnung_am:string|null}>();
  if(!plan)throw new Error('LERNPLAN_NICHT_GEFUNDEN');
  if(plan.user_id!==auth.userId)requireRole(auth,'class_admin');
  const schritte=((await env.DB.prepare('SELECT id,quelle,bezug_typ,bezug_id,titel,faellig_am,aufwand_minuten,status,erledigt_am,erledigt_grund FROM learning_plan_steps WHERE plan_id=? AND tenant_id=? ORDER BY faellig_am,titel')
    .bind(plan.id,tenantId).all<Record<string,unknown>>()).results)??[];
  const offeneLuecken=schritte.filter(s=>s.status==='offen'&&s.quelle==='luecke'&&s.bezug_typ==='competency');
  if(offeneLuecken.length){
    const stand=await kompetenzstand(env,auth,tenantId,plan.course_id,plan.user_id);
    const erreicht=new Set(stand.kompetenzen.filter(k=>k.stand==='erreicht').map(k=>k.competency_id));
    const jetzt=nowIso(),schliessen=offeneLuecken.filter(s=>erreicht.has(String(s.bezug_id)));
    if(schliessen.length){
      await env.DB.batch(schliessen.map(s=>env.DB.prepare("UPDATE learning_plan_steps SET status='erledigt',erledigt_am=?,erledigt_grund='nachweis' WHERE id=? AND tenant_id=?")
        .bind(jetzt,String(s.id),tenantId)));
      for(const s of schliessen){s.status='erledigt';s.erledigt_am=jetzt;s.erledigt_grund='nachweis';}
    }
  }
  const offen=schritte.filter(s=>s.status==='offen');
  return{plan,schritte,
    offen:offen.length,
    erledigt:schritte.filter(s=>s.status==='erledigt').length,
    naechster:offen[0]??null,
    ueberfaellig:offen.filter(s=>String(s.faellig_am)<nowIso().slice(0,10)).length};
}

/** Was ein Mensch ohne Nachweis erledigen kann - eine versaeumte Einheit zum Beispiel. */
export async function schrittErledigt(env:Env,auth:CoreAuthContext,tenantId:string,schrittId:string,bemerkung:string){
  const s=await env.DB.prepare('SELECT s.id,s.quelle,s.status,p.user_id FROM learning_plan_steps s JOIN learning_plans p ON p.id=s.plan_id WHERE s.id=? AND s.tenant_id=?')
    .bind(clean(schrittId,120),tenantId).first<{id:string;quelle:string;status:string;user_id:string}>();
  if(!s)throw new Error('LERNPLAN_SCHRITT_NICHT_GEFUNDEN');
  if(s.user_id!==auth.userId)requireRole(auth,'class_admin');
  if(s.status!=='offen')throw new Error('LERNPLAN_SCHRITT_NICHT_OFFEN');
  // Eine Kompetenzluecke schliesst der Nachweis, nicht die Selbstauskunft. Sonst waere der
  // ganze Mechanismus eine Liste zum Abhaken.
  if(s.quelle==='luecke')throw new Error('LERNPLAN_LUECKE_BRAUCHT_NACHWEIS');
  await env.DB.prepare("UPDATE learning_plan_steps SET status='erledigt',erledigt_am=?,erledigt_grund=? WHERE id=? AND tenant_id=?")
    .bind(nowIso(),clean(bemerkung,500)||'bestaetigt',s.id,tenantId).run();
  return{erledigt:true};
}

/** Meine Lernplaene - fuer das Portal. */
export async function meineLernplaene(env:Env,auth:CoreAuthContext,tenantId:string){
  return ((await env.DB.prepare(`SELECT p.id,p.course_id,c.name AS kurs,p.pruefungstermin,p.reicht_die_zeit,p.status,
    (SELECT COUNT(*) FROM learning_plan_steps s WHERE s.plan_id=p.id AND s.status='offen') AS offen
    FROM learning_plans p JOIN courses c ON c.id=p.course_id WHERE p.tenant_id=? AND p.user_id=? AND p.status='aktiv' ORDER BY p.pruefungstermin LIMIT 50`)
    .bind(tenantId,auth.userId).all()).results)??[];
}

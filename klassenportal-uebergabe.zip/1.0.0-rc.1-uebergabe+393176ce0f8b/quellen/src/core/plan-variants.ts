import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { hasPermission } from './enterprise-access.js';
import { stapelSchreiben } from './learning-operations.js';
import { istAbwesenheitVomUnterricht, ladeRhythmusregeln, rhythmusBefunde, type Rhythmusregel } from './plan-rhythms.js';
import { id, nowIso, safeString, sha256Text } from './utils.js';

// Planvarianten: bewerten, vergleichen, zurueckholen und Konflikte mit Vorschlaegen beantworten
// (Master-Spec V2, Block "Planung und Zeit", Luecken Z1, Z2 und Z4).
//
// Z1 Fassungen gab es, eine Aussage ueber sie nicht. Wer drei Entwuerfe nebeneinander hatte, musste
//    raten. Die einzige Zahl, die es gab, war die Zahl der offenen Konflikte - und das ist die
//    billigste aller Zahlen: ein Entwurf ohne Termine hat null Konflikte und waere damit der beste.
//    Deshalb steht hier eine zusammengesetzte Kennzahl, die ihre Bestandteile einzeln ausweist und
//    jeden Abzug begruendet. Und ein VERGLEICH, der sagt, was sich zwischen zwei Fassungen aendert -
//    nicht nur, welche "besser" ist. Die zweite Auskunft ist im Alltag die wichtigere: wer eine
//    Fassung freigibt, muss wissen, welche Klasse am Dienstag einen anderen Raum bekommt.
//
// Z2 Der Rueckweg. Gebaut nach demselben Muster wie die Mandantensicherung
//    (src/portability/restore-operations.ts): hinsehen, zurueckspielen, nachzaehlen. Die Vorschau
//    traegt eine Pruefsumme; wer den Knopf drueckt, schickt sie mit. Aendert sich der Plan
//    dazwischen, bricht der Vorgang ab, statt eine Vorschau auszufuehren, die nicht mehr stimmt.
//
// Z4 Konflikte wurden erkannt und geschrieben - und dann stand die Planung davor. Hier entstehen
//    Vorschlaege, sortiert nach Eingriffstiefe: je weniger bestehende Termine ein Vorschlag
//    anfasst, desto weiter oben steht er. Jeder Vorschlag nennt seine Kosten.
//
// Alle drei Auskuenfte rechnen im Speicher ueber wenige Abfragen. Eine Bewertung ueber 500 Stunden
// darf nicht 500 Abfragen kosten - genau daran ist die erweiterte Planpruefung schon einmal in die
// Unteranfragengrenze gelaufen.

const MAX_EINTRAEGE_BEWERTUNG=5000;
const MAX_EINTRAEGE_RUECKKEHR=3000;
const MAX_KONFLIKTE_VORSCHLAEGE=120;
const MAX_VORSCHLAEGE=300;
const MAX_VORSCHLAEGE_JE_KONFLIKT=5;
const MAX_BEISPIELE=40;

function admin(auth:CoreAuthContext){return auth.isPlatformAdmin||auth.role==='tenant_admin';}
function requireManage(auth:CoreAuthContext){if(!admin(auth)&&!hasPermission(auth,'courses.manage'))throw new Error('FORBIDDEN_PLANNING_MANAGE');}
function tagSchluessel(v:string){return String(v).slice(0,10);}
function uhrzeit(v:string){return String(v).slice(11,16);}
function minuten(a:string,b:string){return Math.max(0,Math.round((Date.parse(b)-Date.parse(a))/60000));}
function mondayKey(v:string){const d=new Date(v),tag=(d.getUTCDay()+6)%7;d.setUTCDate(d.getUTCDate()-tag);return d.toISOString().slice(0,10);}
function ueberlappt(aVon:string,aBis:string,bVon:string,bBis:string){return aVon<bBis&&bVon<aBis;}
function deutschesDatum(tag:string){return `${tag.slice(8,10)}.${tag.slice(5,7)}.${tag.slice(0,4)}`;}
function zeitpunkt(iso:string){return `${deutschesDatum(tagSchluessel(iso))} ${uhrzeit(iso)}`;}
function minutenDesTages(v:string){const [h,m]=uhrzeit(v).split(':').map(Number);return h*60+m;}

type Eintrag={
  id:string;course_id:string;course_name:string;subject_id:string|null;subject_text:string|null;
  teacher_id:string|null;teacher_name:string|null;starts_at:string;ends_at:string;room:string|null;
  activity_type:string;location_label:string|null;attendance_expected:number;published_lesson_id:string|null;
  rhythm_rule_id:string|null;rhythm_group:string|null;rhythm_position:number|null;
};

function alsEintrag(z:Record<string,unknown>):Eintrag{
  return{
    id:String(z.id),course_id:String(z.course_id),course_name:String(z.course_name??''),
    subject_id:z.subject_id===null||z.subject_id===undefined?null:String(z.subject_id),
    subject_text:z.subject_text===null||z.subject_text===undefined?null:String(z.subject_text),
    teacher_id:z.teacher_id===null||z.teacher_id===undefined?null:String(z.teacher_id),
    teacher_name:z.teacher_name===null||z.teacher_name===undefined?null:String(z.teacher_name),
    starts_at:String(z.starts_at),ends_at:String(z.ends_at),
    room:z.room===null||z.room===undefined?null:String(z.room),
    activity_type:String(z.activity_type??'classroom'),
    location_label:z.location_label===null||z.location_label===undefined?null:String(z.location_label),
    attendance_expected:Number(z.attendance_expected??1),
    published_lesson_id:z.published_lesson_id===null||z.published_lesson_id===undefined?null:String(z.published_lesson_id),
    rhythm_rule_id:z.rhythm_rule_id===null||z.rhythm_rule_id===undefined?null:String(z.rhythm_rule_id),
    rhythm_group:z.rhythm_group===null||z.rhythm_group===undefined?null:String(z.rhythm_group),
    rhythm_position:z.rhythm_position===null||z.rhythm_position===undefined?null:Number(z.rhythm_position),
  };
}

const EINTRAG_SPALTEN='e.id,e.course_id,e.subject_id,e.subject_text,e.teacher_id,e.starts_at,e.ends_at,e.room,e.activity_type,e.location_label,e.attendance_expected,e.published_lesson_id,e.rhythm_rule_id,e.rhythm_group,e.rhythm_position';

async function ladeEintraege(env:Env,tenantId:string,planId:string):Promise<Eintrag[]>{
  const r=await env.DB.prepare(`SELECT ${EINTRAG_SPALTEN},c.name course_name,t.name teacher_name FROM timetable_plan_entries e JOIN courses c ON c.id=e.course_id AND c.tenant_id=e.tenant_id LEFT JOIN teachers t ON t.id=e.teacher_id AND t.tenant_id=e.tenant_id WHERE e.tenant_id=? AND e.plan_id=? ORDER BY e.starts_at,e.id LIMIT ?`).bind(tenantId,planId,MAX_EINTRAEGE_BEWERTUNG+1).all<Record<string,unknown>>();
  const zeilen=r.results??[];
  if(zeilen.length>MAX_EINTRAEGE_BEWERTUNG)throw new Error('PLAN_VARIANT_TOO_LARGE');
  return zeilen.map(alsEintrag);
}

// ---------------------------------------------------------------------------------------------
// Z1 Bewertung
// ---------------------------------------------------------------------------------------------

export type Abzug={merkmal:string;wert:number;einheit:string;abzug:number;begruendung:string};
export type Bewertung={
  plan_id:string;plan_name:string;status:string;starts_on:string;ends_on:string;
  kennzahl:number;eintraege:number;unterrichtsminuten:number;unterrichtstage:number;
  konflikte:{fehler:number;hinweise:number;je_art:Array<{art:string;anzahl:number;severity:string}>};
  belastung:{verstoesse:number;betroffene_lehrkraefte:number;meldungen:Array<{teacher_id:string;teacher_name:string;regel:string;wert:number;grenze:number;text:string}>};
  raeume:{belegte_minuten:number;verfuegbare_minuten:number;auslastung_prozent:number;raeume:number;fenster:string};
  luecken:{teilnehmende_minuten:number;lehrkraefte_minuten:number;anteil_prozent:number;praxisphasen_minuten:number};
  wege:{raumwechsel:number;standortwechsel:number;je_tag:number};
  abzuege:Abzug[];
};

type Planzeile={id:string;name:string;status:string;starts_on:string;ends_on:string};

async function ladePlan(env:Env,tenantId:string,planId:string):Promise<Planzeile>{
  const p=await env.DB.prepare('SELECT id,name,status,starts_on,ends_on FROM timetable_plan_versions WHERE tenant_id=? AND id=?').bind(tenantId,planId).first<Planzeile>();
  if(!p)throw new Error('TIMETABLE_PLAN_NOT_FOUND');
  return p;
}

/**
 * Die Bewertung EINER Fassung.
 *
 * Sieben Abfragen, unabhaengig davon, ob der Entwurf zwanzig oder zweitausend Termine hat. Jede
 * Einzelzahl steht neben der Kennzahl, und jeder Abzug nennt seinen Grund - eine Note ohne
 * Begruendung koennte niemand pruefen und deshalb auch niemand widersprechen.
 */
async function bewerteIntern(env:Env,tenantId:string,plan:Planzeile):Promise<{bewertung:Bewertung;eintraege:Eintrag[];regeln:Map<string,Rhythmusregel>}>{
  const planId=plan.id;
  const vonIso=`${plan.starts_on}T00:00:00.000Z`,bisIso=`${plan.ends_on}T23:59:59.999Z`;
  const [eintraege,konfliktZeilen,teilnahmeZeilen,mittelZeilen,raumZeilen,lastregelZeilen,sperrZeilen,regeln]=await Promise.all([
    ladeEintraege(env,tenantId,planId),
    env.DB.prepare("SELECT conflict_type,severity,COUNT(*) n FROM timetable_plan_conflicts WHERE tenant_id=? AND plan_id=? AND resolved_at IS NULL GROUP BY conflict_type,severity").bind(tenantId,planId).all<Record<string,unknown>>(),
    env.DB.prepare("SELECT course_id,COUNT(DISTINCT user_id) n FROM memberships WHERE tenant_id=? AND role IN ('participant','class_admin') GROUP BY course_id").bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT pr.entry_id,pr.resource_id FROM timetable_plan_entry_resources pr WHERE pr.tenant_id=? AND pr.plan_id=?').bind(tenantId,planId).all<Record<string,unknown>>(),
    env.DB.prepare("SELECT id,name,code,capacity FROM planning_resources WHERE tenant_id=? AND resource_type='room' AND status='active' LIMIT 500").bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT teacher_id,max_daily_minutes,max_weekly_minutes,max_consecutive_minutes,min_break_minutes FROM teacher_workload_rules WHERE tenant_id=?').bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT course_id,title,blackout_type,starts_at,ends_at FROM planning_blackouts WHERE tenant_id=? AND starts_at<? AND ends_at>? LIMIT 2000').bind(tenantId,bisIso,vonIso).all<Record<string,unknown>>(),
    ladeRhythmusregeln(env,tenantId),
  ]);

  const teilnehmende=new Map<string,number>();
  for(const t of teilnahmeZeilen.results??[])teilnehmende.set(String(t.course_id),Number(t.n)||0);
  const raumNachName=new Map<string,string>(),raumNachCode=new Map<string,string>();
  for(const r of raumZeilen.results??[]){const n=String(r.name??'').toLowerCase(),c=String(r.code??'').toLowerCase();if(n&&!raumNachName.has(n))raumNachName.set(n,String(r.id));if(c&&!raumNachCode.has(c))raumNachCode.set(c,String(r.id));}
  const mittelJeTermin=new Map<string,string[]>();
  for(const m of mittelZeilen.results??[]){const k=String(m.entry_id),l=mittelJeTermin.get(k);if(l)l.push(String(m.resource_id));else mittelJeTermin.set(k,[String(m.resource_id)]);}
  const lastregeln=new Map<string,Record<string,unknown>>();
  for(const r of lastregelZeilen.results??[])lastregeln.set(String(r.teacher_id),r);
  const praxisSperren=(sperrZeilen.results??[]).filter(b=>String(b.blackout_type)==='practice_block');

  // Konflikte
  let fehler=0,hinweise=0;
  const jeArt:Array<{art:string;anzahl:number;severity:string}>=[];
  for(const z of konfliktZeilen.results??[]){
    const n=Number(z.n)||0,sev=String(z.severity);
    jeArt.push({art:String(z.conflict_type),anzahl:n,severity:sev});
    if(sev==='error')fehler+=n;else hinweise+=n;
  }
  jeArt.sort((a,b)=>b.anzahl-a.anzahl);

  // Unterricht und Praxisphasen trennen. Genau hier entscheidet sich, ob drei Wochen im Betrieb
  // als Luecke oder als das erscheinen, was sie sind.
  const unterricht=eintraege.filter(e=>!istAbwesenheitVomUnterricht(e,regeln));
  const praxis=eintraege.filter(e=>istAbwesenheitVomUnterricht(e,regeln));
  const unterrichtsminuten=unterricht.reduce((s,e)=>s+minuten(e.starts_at,e.ends_at),0);
  const praxisminuten=praxis.reduce((s,e)=>s+minuten(e.starts_at,e.ends_at),0);
  const tage=new Set(unterricht.map(e=>tagSchluessel(e.starts_at)));

  // Belastungsverstoesse je Lehrkraft - dieselbe Rechnung wie in der Soll-Ist-Auswertung, nur auf
  // dem Entwurf statt auf gehaltenem Unterricht.
  const jeLehrkraft=new Map<string,Eintrag[]>();
  for(const e of unterricht){if(!e.teacher_id)continue;const l=jeLehrkraft.get(e.teacher_id);if(l)l.push(e);else jeLehrkraft.set(e.teacher_id,[e]);}
  const meldungen:Bewertung['belastung']['meldungen']=[];
  for(const [teacherId,liste] of jeLehrkraft){
    const regel=lastregeln.get(teacherId);
    if(!regel)continue;
    const name=liste[0].teacher_name||'';
    const tagesSummen=new Map<string,number>(),wochenSummen=new Map<string,number>();
    for(const e of liste){const d=tagSchluessel(e.starts_at),w=mondayKey(e.starts_at),m=minuten(e.starts_at,e.ends_at);tagesSummen.set(d,(tagesSummen.get(d)||0)+m);wochenSummen.set(w,(wochenSummen.get(w)||0)+m);}
    const maxTag=regel.max_daily_minutes===null||regel.max_daily_minutes===undefined?null:Number(regel.max_daily_minutes);
    const maxWoche=regel.max_weekly_minutes===null||regel.max_weekly_minutes===undefined?null:Number(regel.max_weekly_minutes);
    const maxStueck=regel.max_consecutive_minutes===null||regel.max_consecutive_minutes===undefined?null:Number(regel.max_consecutive_minutes);
    const minPause=regel.min_break_minutes===null||regel.min_break_minutes===undefined?null:Number(regel.min_break_minutes);
    if(maxTag)for(const [d,summe] of [...tagesSummen].sort((a,b)=>a[0]<b[0]?-1:1))if(summe>maxTag)
      meldungen.push({teacher_id:teacherId,teacher_name:name,regel:'daily_limit',wert:summe,grenze:maxTag,text:`${name}: am ${deutschesDatum(d)} sind ${summe} Minuten geplant, vereinbart sind höchstens ${maxTag}.`});
    if(maxWoche)for(const [w,summe] of [...wochenSummen].sort((a,b)=>a[0]<b[0]?-1:1))if(summe>maxWoche)
      meldungen.push({teacher_id:teacherId,teacher_name:name,regel:'weekly_limit',wert:summe,grenze:maxWoche,text:`${name}: in der Woche ab ${deutschesDatum(w)} sind ${summe} Minuten geplant, vereinbart sind höchstens ${maxWoche}.`});
    if(maxStueck||minPause){
      const jeTag=new Map<string,Eintrag[]>();
      for(const e of liste){const d=tagSchluessel(e.starts_at),l=jeTag.get(d);if(l)l.push(e);else jeTag.set(d,[e]);}
      for(const [d,liste2] of [...jeTag].sort((a,b)=>a[0]<b[0]?-1:1)){
        const sortiert=[...liste2].sort((a,b)=>a.starts_at<b.starts_at?-1:1);
        // Zwei unmittelbar aneinanderliegende Einheiten sind EIN Einsatz, keine Pause von null
        // Minuten. Ohne dieses Zusammenlegen meldete jede Doppelstunde eine gerissene Mindestpause.
        const einsaetze:Array<{von:string;bis:string}>=[];
        for(const e of sortiert){const letzter=einsaetze[einsaetze.length-1];if(letzter&&minuten(letzter.bis,e.starts_at)<=0){if(e.ends_at>letzter.bis)letzter.bis=e.ends_at;}else einsaetze.push({von:e.starts_at,bis:e.ends_at});}
        if(minPause)for(let i=1;i<einsaetze.length;i++){
          const luecke=minuten(einsaetze[i-1].bis,einsaetze[i].von);
          if(luecke<minPause)meldungen.push({teacher_id:teacherId,teacher_name:name,regel:'min_break',wert:luecke,grenze:minPause,text:`${name}: am ${deutschesDatum(d)} liegen zwischen zwei Einsätzen nur ${luecke} Minuten Pause, vereinbart sind mindestens ${minPause}.`});
        }
        if(maxStueck){
          const zusammen:Array<{von:string;bis:string}>=[];
          for(const s of einsaetze){const letzter=zusammen[zusammen.length-1];if(letzter&&minuten(letzter.bis,s.von)<(minPause||1)){if(s.bis>letzter.bis)letzter.bis=s.bis;}else zusammen.push({von:s.von,bis:s.bis});}
          for(const s of zusammen){const dauer=minuten(s.von,s.bis);if(dauer>maxStueck)meldungen.push({teacher_id:teacherId,teacher_name:name,regel:'consecutive_limit',wert:dauer,grenze:maxStueck,text:`${name}: am ${deutschesDatum(d)} liegen ${dauer} Minuten am Stück, vereinbart sind höchstens ${maxStueck}.`});}
        }
      }
    }
  }

  // Raumauslastung. Das Zeitfenster kommt aus dem Plan selbst - so bleibt die Zahl auch fuer
  // Schicht- und Randzeiten ehrlich, statt eine Spaetschicht als Ueberlastung auszuweisen.
  let fensterVon=24*60,fensterBis=0;
  for(const e of unterricht){fensterVon=Math.min(fensterVon,minutenDesTages(e.starts_at));fensterBis=Math.max(fensterBis,minutenDesTages(e.ends_at)||24*60);}
  if(fensterBis<=fensterVon){fensterVon=8*60;fensterBis=16*60;}
  const fensterBreite=Math.max(60,fensterBis-fensterVon);
  const raumMinuten=new Map<string,number>();
  for(const e of unterricht){
    const dauer=minuten(e.starts_at,e.ends_at);
    const mittel=mittelJeTermin.get(e.id)??[];
    const schluessel=String(e.room??'').toLowerCase();
    const raumId=mittel[0]||raumNachName.get(schluessel)||raumNachCode.get(schluessel)||'';
    if(!raumId)continue;
    raumMinuten.set(raumId,(raumMinuten.get(raumId)||0)+dauer);
  }
  const raeumeGesamt=(raumZeilen.results??[]).length;
  const belegteMinuten=[...raumMinuten.values()].reduce((a,b)=>a+b,0);
  const verfuegbareMinuten=raeumeGesamt*tage.size*fensterBreite;
  const auslastung=verfuegbareMinuten>0?Math.round(belegteMinuten/verfuegbareMinuten*1000)/10:0;

  // Wege und Luecken. Eine Praxisphase FUELLT die Zeit - sie erzeugt keine Luecke, und der Tag,
  // an dem sie stattfindet, hat auch keine.
  const praxisJeKursUndTag=new Map<string,Array<{von:string;bis:string}>>();
  for(const p of praxis){const k=`${p.course_id}|${tagSchluessel(p.starts_at)}`,l=praxisJeKursUndTag.get(k);const w={von:p.starts_at,bis:p.ends_at};if(l)l.push(w);else praxisJeKursUndTag.set(k,[w]);}
  for(const b of praxisSperren){
    const von=String(b.starts_at),bis=String(b.ends_at);
    for(let t=Date.parse(`${tagSchluessel(von)}T00:00:00.000Z`);t<=Date.parse(`${tagSchluessel(bis)}T00:00:00.000Z`);t+=86400000){
      const tagText=new Date(t).toISOString().slice(0,10);
      for(const kurs of b.course_id?[String(b.course_id)]:[...new Set(eintraege.map(e=>e.course_id))]){
        const k=`${kurs}|${tagText}`,l=praxisJeKursUndTag.get(k),w={von,bis};
        if(l)l.push(w);else praxisJeKursUndTag.set(k,[w]);
      }
    }
  }
  const gedeckt=(kurs:string,tag:string,von:string,bis:string)=>(praxisJeKursUndTag.get(`${kurs}|${tag}`)??[]).some(p=>p.von<=von&&p.bis>=bis);

  let teilnehmendeLuecken=0,lehrkraftLuecken=0,raumwechsel=0,standortwechsel=0;
  const jeKursUndTag=new Map<string,Eintrag[]>();
  for(const e of eintraege){const k=`${e.course_id}|${tagSchluessel(e.starts_at)}`,l=jeKursUndTag.get(k);if(l)l.push(e);else jeKursUndTag.set(k,[e]);}
  for(const [k,liste] of jeKursUndTag){
    const [kurs,tag]=k.split('|');
    const sortiert=[...liste].sort((a,b)=>a.starts_at<b.starts_at?-1:1);
    for(let i=1;i<sortiert.length;i++){
      const vorher=sortiert[i-1],jetzt=sortiert[i];
      const luecke=minuten(vorher.ends_at,jetzt.starts_at);
      if(luecke>0&&!gedeckt(kurs,tag,vorher.ends_at,jetzt.starts_at))teilnehmendeLuecken+=luecke;
      if(String(vorher.room||'').toLowerCase()!==String(jetzt.room||'').toLowerCase())raumwechsel++;
      const a=String(vorher.location_label||''),b=String(jetzt.location_label||'');
      if(a&&b&&a!==b)standortwechsel++;
    }
  }
  const jeLehrkraftUndTag=new Map<string,Eintrag[]>();
  for(const e of unterricht){if(!e.teacher_id)continue;const k=`${e.teacher_id}|${tagSchluessel(e.starts_at)}`,l=jeLehrkraftUndTag.get(k);if(l)l.push(e);else jeLehrkraftUndTag.set(k,[e]);}
  for(const [,liste] of jeLehrkraftUndTag){
    const sortiert=[...liste].sort((a,b)=>a.starts_at<b.starts_at?-1:1);
    for(let i=1;i<sortiert.length;i++)lehrkraftLuecken+=minuten(sortiert[i-1].ends_at,sortiert[i].starts_at);
  }
  const teilnehmerGewicht=[...jeKursUndTag.keys()].length?1:0;
  void teilnehmerGewicht;
  const lueckenAnteil=unterrichtsminuten+teilnehmendeLuecken>0?Math.round(teilnehmendeLuecken/(unterrichtsminuten+teilnehmendeLuecken)*1000)/10:0;
  const wechselJeTag=tage.size?Math.round((raumwechsel+standortwechsel)/tage.size*10)/10:0;

  // Die Abzuege. Jeder mit Messwert und Grund - und mit einer Obergrenze, damit ein einzelnes
  // Merkmal die Kennzahl nicht allein auf null zieht.
  const abzuege:Abzug[]=[];
  const deckel=(wert:number,max:number)=>Math.min(max,Math.round(wert));
  abzuege.push({merkmal:'offene_fehler',wert:fehler,einheit:'Konflikte',abzug:deckel(fehler*6,40),begruendung:'Ein Entwurf mit offenen Fehlern lässt sich nicht veröffentlichen. Jeder Fehler kostet 6 Punkte, höchstens 40.'});
  abzuege.push({merkmal:'offene_hinweise',wert:hinweise,einheit:'Hinweise',abzug:deckel(hinweise,10),begruendung:'Hinweise blockieren die Freigabe nicht, sie kosten aber Vertrauen. Je Hinweis 1 Punkt, höchstens 10.'});
  abzuege.push({merkmal:'belastungsverstoesse',wert:meldungen.length,einheit:'Verstöße',abzug:deckel(meldungen.length*4,20),begruendung:'Überschrittene Tages-, Wochen- oder Pausengrenzen einer Lehrkraft. Je Verstoß 4 Punkte, höchstens 20.'});
  abzuege.push({merkmal:'luecken',wert:lueckenAnteil,einheit:'% Wartezeit',abzug:deckel(lueckenAnteil*0.6,18),begruendung:'Anteil der Wartezeit am verplanten Tag der Teilnehmenden. Praxisphasen zählen nicht als Wartezeit.'});
  abzuege.push({merkmal:'wege',wert:wechselJeTag,einheit:'Wechsel/Tag',abzug:deckel(wechselJeTag*2,6),begruendung:'Raum- und Standortwechsel je Unterrichtstag. Jeder Wechsel kostet Zeit zwischen zwei Einheiten.'});
  const auslastungAbzug=raeumeGesamt===0?0:auslastung>95?6:auslastung>85?3:auslastung<15&&belegteMinuten>0?3:0;
  abzuege.push({merkmal:'raumauslastung',wert:auslastung,einheit:'%',abzug:auslastungAbzug,begruendung:'Über 85 % bleibt kein Spielraum für Vertretung und Ausfall; unter 15 % stehen Räume leer, die Geld kosten.'});
  const kennzahl=Math.max(0,Math.min(100,100-abzuege.reduce((s,a)=>s+a.abzug,0)));

  const bewertung:Bewertung={
    plan_id:planId,plan_name:String(plan.name),status:String(plan.status),starts_on:String(plan.starts_on),ends_on:String(plan.ends_on),
    kennzahl,eintraege:eintraege.length,unterrichtsminuten,unterrichtstage:tage.size,
    konflikte:{fehler,hinweise,je_art:jeArt.slice(0,20)},
    belastung:{verstoesse:meldungen.length,betroffene_lehrkraefte:new Set(meldungen.map(m=>m.teacher_id)).size,meldungen:meldungen.slice(0,50)},
    raeume:{belegte_minuten:belegteMinuten,verfuegbare_minuten:verfuegbareMinuten,auslastung_prozent:auslastung,raeume:raeumeGesamt,
      fenster:`${String(Math.floor(fensterVon/60)).padStart(2,'0')}:${String(fensterVon%60).padStart(2,'0')}–${String(Math.floor(fensterBis/60)).padStart(2,'0')}:${String(fensterBis%60).padStart(2,'0')}`},
    luecken:{teilnehmende_minuten:teilnehmendeLuecken,lehrkraefte_minuten:lehrkraftLuecken,anteil_prozent:lueckenAnteil,praxisphasen_minuten:praxisminuten},
    wege:{raumwechsel,standortwechsel,je_tag:wechselJeTag},
    abzuege,
  };
  return{bewertung,eintraege,regeln};
}

export async function bewertePlanfassung(env:Env,auth:CoreAuthContext,tenantId:string,planId:string,input:Record<string,unknown>={}){
  requireManage(auth);
  const plan=await ladePlan(env,tenantId,planId);
  const {bewertung,eintraege,regeln}=await bewerteIntern(env,tenantId,plan);
  // Die Rhythmusbefunde gehoeren in die Bewertung, auch wenn die Planpruefung noch nicht gelaufen
  // ist: ein zerschnittener Block ist ein Mangel der Fassung, nicht erst der Pruefung.
  const rhythmus=rhythmusBefunde(eintraege,regeln);
  const ergebnis={...bewertung,rhythmus:{befunde:rhythmus.length,meldungen:rhythmus.slice(0,50)}};
  if(input.speichern===true||input.speichern===1||input.speichern==='1'){
    await env.DB.prepare('INSERT INTO timetable_plan_scores(id,tenant_id,plan_id,kennzahl,eintraege,unterrichtsminuten,konflikte_fehler,konflikte_hinweise,belastungsverstoesse,raumauslastung_prozent,luecken_minuten_teilnehmende,luecken_minuten_lehrkraefte,wege_wechsel,abzuege_json,berechnet_von,berechnet_am) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .bind(id('tps_'),tenantId,planId,bewertung.kennzahl,bewertung.eintraege,bewertung.unterrichtsminuten,bewertung.konflikte.fehler,bewertung.konflikte.hinweise,bewertung.belastung.verstoesse,bewertung.raeume.auslastung_prozent,bewertung.luecken.teilnehmende_minuten,bewertung.luecken.lehrkraefte_minuten,bewertung.wege.raumwechsel+bewertung.wege.standortwechsel,JSON.stringify(bewertung.abzuege),auth.userId,nowIso()).run();
    await audit(env.DB,auth.userId,'planning.plan_scored',tenantId,undefined,'timetable_plan',planId,{kennzahl:bewertung.kennzahl,fehler:bewertung.konflikte.fehler});
  }
  return ergebnis;
}

export async function listPlanScores(env:Env,auth:CoreAuthContext,tenantId:string,planId:string){
  requireManage(auth);
  return(await env.DB.prepare('SELECT s.*,u.display_name berechnet_von_name FROM timetable_plan_scores s LEFT JOIN users u ON u.id=s.berechnet_von WHERE s.tenant_id=? AND s.plan_id=? ORDER BY s.berechnet_am DESC LIMIT 50').bind(tenantId,planId).all<Record<string,unknown>>()).results??[];
}

// ---------------------------------------------------------------------------------------------
// Z1 Vergleich
// ---------------------------------------------------------------------------------------------

function inhaltsSchluessel(e:Eintrag){return `${e.subject_id??''}|${e.subject_text??''}|${e.teacher_id??''}|${String(e.room??'').toLowerCase()}|${e.activity_type}`;}
function bezeichnung(e:Eintrag){return `${e.course_name}, ${e.subject_text||e.subject_id||e.activity_type}`;}

export async function vergleichePlanfassungen(env:Env,auth:CoreAuthContext,tenantId:string,planA:string,planB:string){
  requireManage(auth);
  if(!planA||!planB)throw new Error('FIELD_REQUIRED');
  if(planA===planB)throw new Error('PLAN_VARIANT_COMPARE_SAME');
  const [a,b]=await Promise.all([ladePlan(env,tenantId,planA),ladePlan(env,tenantId,planB)]);
  const [links,rechts]=await Promise.all([bewerteIntern(env,tenantId,a),bewerteIntern(env,tenantId,b)]);

  const offenA=new Map<string,Eintrag>(),offenB=new Map<string,Eintrag>();
  for(const e of links.eintraege)offenA.set(e.id,e);
  for(const e of rechts.eintraege)offenB.set(e.id,e);
  const zeitSchluessel=(e:Eintrag)=>`${e.course_id}|${e.starts_at}|${e.ends_at}`;
  const nachZeitB=new Map<string,Eintrag[]>();
  for(const e of rechts.eintraege){const k=zeitSchluessel(e),l=nachZeitB.get(k);if(l)l.push(e);else nachZeitB.set(k,[e]);}

  const gleich:Eintrag[]=[],geaendert:Array<{a:Eintrag;b:Eintrag;felder:string[]}>=[],verschoben:Array<{a:Eintrag;b:Eintrag}>=[];
  // 1. Gleiche Zeit, gleiche Klasse: derselbe Termin. Nur der Inhalt kann sich geaendert haben.
  for(const e of links.eintraege){
    const kandidaten=nachZeitB.get(zeitSchluessel(e));
    if(!kandidaten?.length)continue;
    const treffer=kandidaten.find(k=>offenB.has(k.id)&&inhaltsSchluessel(k)===inhaltsSchluessel(e))||kandidaten.find(k=>offenB.has(k.id));
    if(!treffer)continue;
    offenA.delete(e.id);offenB.delete(treffer.id);
    if(inhaltsSchluessel(treffer)===inhaltsSchluessel(e)){gleich.push(e);continue;}
    const felder:string[]=[];
    if(String(e.teacher_id??'')!==String(treffer.teacher_id??''))felder.push('Lehrkraft');
    if(String(e.room??'').toLowerCase()!==String(treffer.room??'').toLowerCase())felder.push('Raum');
    if(String(e.subject_id??e.subject_text??'')!==String(treffer.subject_id??treffer.subject_text??''))felder.push('Fach');
    if(e.activity_type!==treffer.activity_type)felder.push('Lernform');
    geaendert.push({a:e,b:treffer,felder});
  }
  // 2. Gleiche Klasse und gleicher Inhalt zu anderer Zeit: verschoben.
  const restB=new Map<string,Eintrag[]>();
  for(const e of offenB.values()){const k=`${e.course_id}|${inhaltsSchluessel(e)}`,l=restB.get(k);if(l)l.push(e);else restB.set(k,[e]);}
  for(const e of [...offenA.values()]){
    const liste=restB.get(`${e.course_id}|${inhaltsSchluessel(e)}`);
    if(!liste?.length)continue;
    const treffer=liste.shift();
    if(!treffer)continue;
    offenA.delete(e.id);offenB.delete(treffer.id);
    verschoben.push({a:e,b:treffer});
  }
  const entfallen=[...offenA.values()],neu=[...offenB.values()];

  const beispiele:Array<{art:string;text:string}>=[];
  for(const x of geaendert.slice(0,MAX_BEISPIELE))beispiele.push({art:'geaendert',text:`${bezeichnung(x.a)} am ${zeitpunkt(x.a.starts_at)}: ${x.felder.join(' und ')||'Inhalt'} geändert (${x.felder.includes('Raum')?`Raum ${x.a.room||'—'} → ${x.b.room||'—'}`:`${x.a.teacher_name||'ohne Lehrkraft'} → ${x.b.teacher_name||'ohne Lehrkraft'}`}).`});
  for(const x of verschoben.slice(0,MAX_BEISPIELE))beispiele.push({art:'verschoben',text:`${bezeichnung(x.a)}: ${zeitpunkt(x.a.starts_at)} → ${zeitpunkt(x.b.starts_at)}.`});
  for(const x of entfallen.slice(0,MAX_BEISPIELE))beispiele.push({art:'entfallen',text:`${bezeichnung(x)} am ${zeitpunkt(x.starts_at)} entfällt in „${b.name}".`});
  for(const x of neu.slice(0,MAX_BEISPIELE))beispiele.push({art:'neu',text:`${bezeichnung(x)} am ${zeitpunkt(x.starts_at)} kommt in „${b.name}" hinzu.`});

  const d=(x:number,y:number)=>Math.round((y-x)*10)/10;
  return{
    a:links.bewertung,b:rechts.bewertung,
    aenderungen:{gleich:gleich.length,geaendert:geaendert.length,verschoben:verschoben.length,entfallen:entfallen.length,neu:neu.length,
      betroffene_klassen:new Set([...geaendert.map(x=>x.a.course_id),...verschoben.map(x=>x.a.course_id),...entfallen.map(x=>x.course_id),...neu.map(x=>x.course_id)]).size},
    beispiele:beispiele.slice(0,MAX_BEISPIELE*2),
    unterschiede:{
      kennzahl:d(links.bewertung.kennzahl,rechts.bewertung.kennzahl),
      fehler:d(links.bewertung.konflikte.fehler,rechts.bewertung.konflikte.fehler),
      hinweise:d(links.bewertung.konflikte.hinweise,rechts.bewertung.konflikte.hinweise),
      belastungsverstoesse:d(links.bewertung.belastung.verstoesse,rechts.bewertung.belastung.verstoesse),
      raumauslastung_prozent:d(links.bewertung.raeume.auslastung_prozent,rechts.bewertung.raeume.auslastung_prozent),
      luecken_minuten_teilnehmende:d(links.bewertung.luecken.teilnehmende_minuten,rechts.bewertung.luecken.teilnehmende_minuten),
      luecken_minuten_lehrkraefte:d(links.bewertung.luecken.lehrkraefte_minuten,rechts.bewertung.luecken.lehrkraefte_minuten),
      wege_je_tag:d(links.bewertung.wege.je_tag,rechts.bewertung.wege.je_tag),
      unterrichtsminuten:d(links.bewertung.unterrichtsminuten,rechts.bewertung.unterrichtsminuten),
    },
  };
}

// ---------------------------------------------------------------------------------------------
// Z2 Rueckkehr auf eine frühere Fassung
// ---------------------------------------------------------------------------------------------

export type Hinweis={code:string;text:string};
export type Rueckkehrvorschau={
  ziel_plan_id:string;ziel_name:string;ziel_status:string;quelle_plan_id:string;quelle_name:string;quelle_status:string;
  eintraege:{jetzt:number;nachher:number;entfernt:number;hinzugefuegt:number;inhaltsgleich:number};
  klassen:{betroffen:number;nur_heute:string[];nur_in_der_fassung:string[]};
  beispiele:Array<{art:string;text:string}>;
  nebenwirkungen:string[];warnungen:Hinweis[];blockiert:Hinweis[];pruefsumme:string;
};

function fingerabdruckZeile(e:Eintrag){return [e.course_id,e.starts_at,e.ends_at,e.teacher_id??'',String(e.room??'').toLowerCase(),e.activity_type,e.subject_id??'',e.subject_text??'',e.rhythm_rule_id??'',e.rhythm_position??''].join('|');}
function fingerabdruck(eintraege:Eintrag[]){return [...eintraege].map(fingerabdruckZeile).sort().join('\n');}

/**
 * Was die Rueckkehr tun WUERDE.
 *
 * Schreibt nichts. Das Ergebnis traegt eine Pruefsumme: wer den Knopf drueckt, schickt sie mit.
 * Aendert sich der Entwurf zwischen Ansehen und Klicken, passt sie nicht mehr und der Vorgang
 * bricht ab - statt eine Vorschau auszufuehren, die nicht mehr stimmt.
 */
export async function simuliereFassungsRueckkehr(env:Env,auth:CoreAuthContext,tenantId:string,zielPlanId:string,quellPlanId:string):Promise<Rueckkehrvorschau>{
  requireManage(auth);
  if(!zielPlanId||!quellPlanId)throw new Error('FIELD_REQUIRED');
  if(zielPlanId===quellPlanId)throw new Error('PLAN_RESTORE_SAME_VERSION');
  const [ziel,quelle]=await Promise.all([ladePlan(env,tenantId,zielPlanId),ladePlan(env,tenantId,quellPlanId)]);
  const [zielEintraege,quellEintraege]=await Promise.all([ladeEintraege(env,tenantId,zielPlanId),ladeEintraege(env,tenantId,quellPlanId)]);

  const warnungen:Hinweis[]=[],blockiert:Hinweis[]=[];
  if(ziel.status==='published'||ziel.status==='archived')blockiert.push({code:'PLAN_RESTORE_TARGET_LOCKED',text:'Diese Fassung ist bereits veröffentlicht oder abgelegt. Eine Rückkehr würde veröffentlichten Unterricht hinter dem Rücken der Beteiligten ändern.'});
  if(zielEintraege.some(e=>e.published_lesson_id))blockiert.push({code:'PLAN_RESTORE_PUBLISHED_ENTRIES',text:'An dieser Fassung hängen bereits veröffentlichte Unterrichtsstunden. Sie würden ihre Verbindung zum Plan verlieren.'});
  if(quellEintraege.length>MAX_EINTRAEGE_RUECKKEHR||zielEintraege.length>MAX_EINTRAEGE_RUECKKEHR)blockiert.push({code:'PLAN_RESTORE_TOO_LARGE',text:'Diese Fassung ist für eine Rückkehr in einem Durchgang zu groß. Bitte den Zeitraum der Fassung verkleinern.'});
  if(!quellEintraege.length)warnungen.push({code:'FASSUNG_LEER',text:'Die gewählte Fassung enthält keine Termine. Die Rückkehr entfernt alle heutigen Termine, ohne neue einzusetzen.'});
  if(quelle.starts_on!==ziel.starts_on||quelle.ends_on!==ziel.ends_on)warnungen.push({code:'ZEITRAUM_ABWEICHEND',text:`Die Fassung „${quelle.name}" gilt vom ${deutschesDatum(quelle.starts_on)} bis ${deutschesDatum(quelle.ends_on)}, der Entwurf vom ${deutschesDatum(ziel.starts_on)} bis ${deutschesDatum(ziel.ends_on)}. Termine außerhalb des Entwurfszeitraums werden mit übernommen.`});
  warnungen.push({code:'AENDERUNGEN_GEHEN_VERLOREN',text:'Alle Änderungen am Entwurf seit dieser Fassung gehen verloren – auch Änderungen an Terminen, die es in beiden Fassungen gibt.'});

  const zielAbdruck=new Set(zielEintraege.map(fingerabdruckZeile));
  const quellAbdruck=new Set(quellEintraege.map(fingerabdruckZeile));
  let inhaltsgleich=0;
  for(const z of zielAbdruck)if(quellAbdruck.has(z))inhaltsgleich++;
  const klassenHeute=new Map<string,string>(),klassenFassung=new Map<string,string>();
  for(const e of zielEintraege)klassenHeute.set(e.course_id,e.course_name);
  for(const e of quellEintraege)klassenFassung.set(e.course_id,e.course_name);
  const nurHeute=[...klassenHeute].filter(([k])=>!klassenFassung.has(k)).map(([,n])=>n);
  const nurFassung=[...klassenFassung].filter(([k])=>!klassenHeute.has(k)).map(([,n])=>n);
  if(nurHeute.length)warnungen.push({code:'KLASSEN_OHNE_TERMINE',text:`Diese Klassen haben heute Termine im Entwurf, in der Fassung aber keine: ${nurHeute.slice(0,10).join(', ')}.`});

  const beispiele:Array<{art:string;text:string}>=[];
  for(const e of zielEintraege){if(quellAbdruck.has(fingerabdruckZeile(e)))continue;beispiele.push({art:'entfernt',text:`${bezeichnung(e)} am ${zeitpunkt(e.starts_at)}${e.room?` (${e.room})`:''} wird entfernt.`});if(beispiele.length>=MAX_BEISPIELE)break;}
  for(const e of quellEintraege){if(beispiele.length>=MAX_BEISPIELE*2)break;if(zielAbdruck.has(fingerabdruckZeile(e)))continue;beispiele.push({art:'zurueck',text:`${bezeichnung(e)} am ${zeitpunkt(e.starts_at)}${e.room?` (${e.room})`:''} kommt zurück.`});}

  const nebenwirkungen=[
    'Vor der Rückkehr wird der heutige Stand automatisch als abgelegte Fassung gesichert.',
    'Die zu den Terminen gemerkten Räume und Geräte werden mit zurückgesetzt.',
    'Die gemeldeten Konflikte des Entwurfs werden verworfen; die Prüfung muss danach erneut laufen.',
    'Veröffentlichter Unterricht wird nicht verändert – eine Fassung mit veröffentlichten Stunden lässt sich gar nicht zurücksetzen.',
  ];

  const plan={ziel:zielPlanId,quelle:quellPlanId,ziel_status:ziel.status,jetzt:zielEintraege.length,nachher:quellEintraege.length,
    ziel_abdruck:fingerabdruck(zielEintraege),quell_abdruck:fingerabdruck(quellEintraege),blockiert:blockiert.map(x=>x.code)};
  return{
    ziel_plan_id:zielPlanId,ziel_name:String(ziel.name),ziel_status:String(ziel.status),
    quelle_plan_id:quellPlanId,quelle_name:String(quelle.name),quelle_status:String(quelle.status),
    eintraege:{jetzt:zielEintraege.length,nachher:quellEintraege.length,entfernt:zielEintraege.length,hinzugefuegt:quellEintraege.length,inhaltsgleich},
    klassen:{betroffen:new Set([...klassenHeute.keys(),...klassenFassung.keys()]).size,nur_heute:nurHeute.slice(0,20),nur_in_der_fassung:nurFassung.slice(0,20)},
    beispiele,nebenwirkungen,warnungen,blockiert,
    pruefsumme:await sha256Text(JSON.stringify(plan)),
  };
}

export type Rueckkehrergebnis={
  restored:true;lauf_id:string;sicherungs_plan_id:string;
  entfernt:number;zurueckgeholt:number;
  nachkontrolle:'bestanden'|'abweichungen';abweichungen:Array<{feld:string;erwartet:number|string;gefunden:number|string}>;
};

/**
 * Die Rueckkehr - aber kein blinder Knopf.
 *
 * Erst simulieren, dann die Pruefsumme der gezeigten Vorschau verlangen, dann sichern, dann
 * zurueckspielen, dann NACHZAEHLEN. Ohne den letzten Schritt heisst "erfolgreich" nur "es ist
 * nichts geflogen" - und genau das ist der Satz, nach dem man drei Tage spaeter merkt, dass die
 * Haelfte der Termine fehlt.
 */
export async function stellePlanfassungWiederHer(env:Env,auth:CoreAuthContext,tenantId:string,zielPlanId:string,quellPlanId:string,pruefsumme:string):Promise<Rueckkehrergebnis>{
  requireManage(auth);
  const vorschau=await simuliereFassungsRueckkehr(env,auth,tenantId,zielPlanId,quellPlanId);
  if(vorschau.blockiert.length)throw new Error(vorschau.blockiert[0].code);
  const gezeigt=safeString(pruefsumme,200);
  if(!gezeigt)throw new Error('PLAN_RESTORE_PLAN_REQUIRED');
  if(gezeigt!==vorschau.pruefsumme)throw new Error('PLAN_RESTORE_PLAN_CHANGED');

  const [ziel,zielEintraege,quellEintraege,mittelZeilen]=await Promise.all([
    ladePlan(env,tenantId,zielPlanId),
    ladeEintraege(env,tenantId,zielPlanId),
    ladeEintraege(env,tenantId,quellPlanId),
    env.DB.prepare('SELECT plan_id,entry_id,resource_id,quantity FROM timetable_plan_entry_resources WHERE tenant_id=? AND plan_id IN (?,?)').bind(tenantId,zielPlanId,quellPlanId).all<Record<string,unknown>>(),
  ]);
  const mittelJeTermin=new Map<string,Array<{resource_id:string;quantity:number}>>();
  for(const m of mittelZeilen.results??[]){const k=String(m.entry_id),w={resource_id:String(m.resource_id),quantity:Number(m.quantity)||1},l=mittelJeTermin.get(k);if(l)l.push(w);else mittelJeTermin.set(k,[w]);}

  const laufId=id('tprs_'),ts=nowIso(),sicherungId=id('tpl_');
  await env.DB.prepare('INSERT INTO timetable_plan_restores(id,tenant_id,ziel_plan_id,quelle_plan_id,sicherungs_plan_id,status,pruefsumme,simulation_json,ausgeloest_von,gestartet_am) VALUES(?,?,?,?,NULL,?,?,?,?,?)')
    .bind(laufId,tenantId,zielPlanId,quellPlanId,'laufend',vorschau.pruefsumme,JSON.stringify(vorschau),auth.userId,ts).run();
  try{
    // 1. Der heutige Stand als abgelegte Fassung. Ohne sie waere die Rueckkehr selbst der
    //    Datenverlust, den sie verhindern soll.
    const anweisungen:unknown[]=[];
    anweisungen.push(env.DB.prepare("INSERT INTO timetable_plan_versions(id,tenant_id,name,starts_on,ends_on,status,notes,published_at,published_by,created_by,created_at,updated_at) VALUES(?,?,?,?,?,'archived',?,NULL,NULL,?,?,?)")
      .bind(sicherungId,tenantId,`Sicherung vor Rückkehr: ${String(ziel.name).slice(0,240)} (${deutschesDatum(tagSchluessel(ts))})`,ziel.starts_on,ziel.ends_on,`Automatisch gesichert, bevor die Fassung „${vorschau.quelle_name}" zurückgeholt wurde.`,auth.userId,ts,ts));
    for(const e of zielEintraege){
      const neueId=id('tpe_');
      anweisungen.push(env.DB.prepare('INSERT INTO timetable_plan_entries(id,tenant_id,plan_id,course_id,subject_id,subject_text,teacher_id,teacher_text,starts_at,ends_at,room,activity_type,location_label,supervision_mode,attendance_expected,task_text,notes,source,recurrence_group,published_lesson_id,created_by,created_at,updated_at,rhythm_rule_id,rhythm_group,rhythm_position) SELECT ?,tenant_id,?,course_id,subject_id,subject_text,teacher_id,teacher_text,starts_at,ends_at,room,activity_type,location_label,supervision_mode,attendance_expected,task_text,notes,source,recurrence_group,NULL,?,?,?,rhythm_rule_id,rhythm_group,rhythm_position FROM timetable_plan_entries WHERE tenant_id=? AND id=?')
        .bind(neueId,sicherungId,auth.userId,ts,ts,tenantId,e.id));
      for(const m of mittelJeTermin.get(e.id)??[])anweisungen.push(env.DB.prepare('INSERT INTO timetable_plan_entry_resources(tenant_id,plan_id,entry_id,resource_id,quantity,created_by,created_at) VALUES(?,?,?,?,?,?,?)').bind(tenantId,sicherungId,neueId,m.resource_id,m.quantity,auth.userId,ts));
    }
    await stapelSchreiben(env,anweisungen);

    // 2. Den Entwurf leeren. Die Konflikte und die gemerkten Raeume haengen an den Terminen und
    //    gehen ueber die Loeschkaskade mit - genau richtig, sie gehoeren zum alten Stand.
    await env.DB.prepare('DELETE FROM timetable_plan_entries WHERE tenant_id=? AND plan_id=?').bind(tenantId,zielPlanId).run();

    // 3. Die alte Fassung einsetzen.
    const zurueck:unknown[]=[];
    for(const e of quellEintraege){
      const neueId=id('tpe_');
      zurueck.push(env.DB.prepare('INSERT INTO timetable_plan_entries(id,tenant_id,plan_id,course_id,subject_id,subject_text,teacher_id,teacher_text,starts_at,ends_at,room,activity_type,location_label,supervision_mode,attendance_expected,task_text,notes,source,recurrence_group,published_lesson_id,created_by,created_at,updated_at,rhythm_rule_id,rhythm_group,rhythm_position) SELECT ?,tenant_id,?,course_id,subject_id,subject_text,teacher_id,teacher_text,starts_at,ends_at,room,activity_type,location_label,supervision_mode,attendance_expected,task_text,notes,source,recurrence_group,NULL,?,?,?,rhythm_rule_id,rhythm_group,rhythm_position FROM timetable_plan_entries WHERE tenant_id=? AND id=?')
        .bind(neueId,zielPlanId,auth.userId,ts,ts,tenantId,e.id));
      for(const m of mittelJeTermin.get(e.id)??[])zurueck.push(env.DB.prepare('INSERT INTO timetable_plan_entry_resources(tenant_id,plan_id,entry_id,resource_id,quantity,created_by,created_at) VALUES(?,?,?,?,?,?,?)').bind(tenantId,zielPlanId,neueId,m.resource_id,m.quantity,auth.userId,ts));
    }
    await stapelSchreiben(env,zurueck);

    // 4. NACHZAEHLEN. Steht nach der Rueckkehr wirklich die alte Fassung im Entwurf?
    const nachher=await ladeEintraege(env,tenantId,zielPlanId);
    const abweichungen:Array<{feld:string;erwartet:number|string;gefunden:number|string}>=[];
    if(nachher.length!==quellEintraege.length)abweichungen.push({feld:'anzahl_termine',erwartet:quellEintraege.length,gefunden:nachher.length});
    const erwarteterAbdruck=fingerabdruck(quellEintraege),gefundenerAbdruck=fingerabdruck(nachher);
    if(erwarteterAbdruck!==gefundenerAbdruck){
      const erwartet=new Set(erwarteterAbdruck.split('\n').filter(Boolean)),gefunden=new Set(gefundenerAbdruck.split('\n').filter(Boolean));
      abweichungen.push({feld:'fehlende_termine',erwartet:[...erwartet].filter(x=>!gefunden.has(x)).length,gefunden:[...gefunden].filter(x=>!erwartet.has(x)).length});
    }
    const status=abweichungen.length?'abweichungen':'erfolg';
    await env.DB.prepare('UPDATE timetable_plan_restores SET status=?,sicherungs_plan_id=?,ergebnis_json=?,beendet_am=? WHERE tenant_id=? AND id=?')
      .bind(status,sicherungId,JSON.stringify({entfernt:zielEintraege.length,zurueckgeholt:quellEintraege.length,abweichungen}),nowIso(),tenantId,laufId).run();
    await audit(env.DB,auth.userId,'planning.plan_version_restored',tenantId,undefined,'timetable_plan',zielPlanId,{quellPlanId,sicherungId,entfernt:zielEintraege.length,zurueckgeholt:quellEintraege.length,nachkontrolle:status});
    return{restored:true,lauf_id:laufId,sicherungs_plan_id:sicherungId,entfernt:zielEintraege.length,zurueckgeholt:quellEintraege.length,
      nachkontrolle:abweichungen.length?'abweichungen':'bestanden',abweichungen};
  }catch(e){
    const code=String((e as Error)?.message??'PLAN_RESTORE_FAILED').split(':')[0];
    await env.DB.prepare('UPDATE timetable_plan_restores SET status=?,fehler=?,beendet_am=? WHERE tenant_id=? AND id=?').bind('fehler',code,nowIso(),tenantId,laufId).run();
    throw e;
  }
}

export async function listPlanRestores(env:Env,auth:CoreAuthContext,tenantId:string,planId?:string){
  requireManage(auth);
  const gefiltert=safeString(planId,120)||null;
  return(await env.DB.prepare('SELECT r.id,r.ziel_plan_id,r.quelle_plan_id,r.sicherungs_plan_id,r.status,r.fehler,r.gestartet_am,r.beendet_am,z.name ziel_name,q.name quelle_name FROM timetable_plan_restores r LEFT JOIN timetable_plan_versions z ON z.id=r.ziel_plan_id LEFT JOIN timetable_plan_versions q ON q.id=r.quelle_plan_id WHERE r.tenant_id=?1 AND (?2 IS NULL OR r.ziel_plan_id=?2) ORDER BY r.gestartet_am DESC LIMIT 50').bind(tenantId,gefiltert).all<Record<string,unknown>>()).results??[];
}

// ---------------------------------------------------------------------------------------------
// Z4 Loesungsvorschlaege
// ---------------------------------------------------------------------------------------------

export type Vorschlagskosten={eintraege:number;verschobene_minuten:number;betroffene_teilnehmende:number;unterricht_entfaellt_minuten:number};
export type Vorschlag={
  conflict_id:string;conflict_type:string;severity:string;entry_id:string;
  art:'raum_wechseln'|'dozent_wechseln'|'verschieben'|'tauschen'|'entfernen';
  titel:string;begruendung:string;eingriffstiefe:number;kosten:Vorschlagskosten;
  ziel:{starts_at?:string;ends_at?:string;room?:string;resource_id?:string;teacher_id?:string;teacher_name?:string;tausch_entry_id?:string};
};

const ART_GEWICHT:Record<Vorschlag['art'],number>={raum_wechseln:0,dozent_wechseln:10,verschieben:20,tauschen:5,entfernen:0};

type Belegung={von:string;bis:string;entry:string};
function frei(liste:Belegung[]|undefined,von:string,bis:string,ausser:string){
  if(!liste)return true;
  return !liste.some(b=>b.entry!==ausser&&ueberlappt(von,bis,b.von,b.bis));
}

/**
 * Vorschlaege zu den offenen Konflikten eines Entwurfs - sortiert nach Eingriffstiefe.
 *
 * Die Reihenfolge ist die eigentliche Leistung: je weniger bestehende Termine ein Vorschlag
 * anfasst, desto weiter oben steht er. Einen Raum zu tauschen verschiebt niemanden; eine Stunde zu
 * verlegen verschiebt eine Klasse; zwei Stunden zu tauschen verschiebt zwei; eine Stunde zu
 * streichen nimmt Unterricht weg und steht deshalb immer zuletzt - auch wenn sie den Konflikt am
 * schnellsten aufloest.
 *
 * Gerechnet wird im Speicher ueber zehn Abfragen. Je Konflikt nachzufragen waere bei einem
 * Jahresplan mit zweihundert Konflikten genau die Bauart, die die Plattformgrenze reisst.
 */
export async function konfliktVorschlaege(env:Env,auth:CoreAuthContext,tenantId:string,planId:string){
  requireManage(auth);
  const plan=await ladePlan(env,tenantId,planId);
  const vonIso=`${plan.starts_on}T00:00:00.000Z`,bisIso=`${plan.ends_on}T23:59:59.999Z`;
  const [eintraege,konfliktZeilen,raumZeilen,mittelZeilen,dozentZeilen,abwesenheitZeilen,zusagenZeilen,sperrZeilen,teilnahmeZeilen,unterrichtZeilen,belegungZeilen,regeln]=await Promise.all([
    ladeEintraege(env,tenantId,planId),
    env.DB.prepare('SELECT id,entry_id,conflicting_entry_id,conflict_type,severity,message FROM timetable_plan_conflicts WHERE tenant_id=? AND plan_id=? AND resolved_at IS NULL ORDER BY severity DESC,detected_at LIMIT ?').bind(tenantId,planId,MAX_KONFLIKTE_VORSCHLAEGE).all<Record<string,unknown>>(),
    env.DB.prepare("SELECT id,name,code,capacity FROM planning_resources WHERE tenant_id=? AND resource_type='room' AND status='active' ORDER BY CASE WHEN capacity IS NULL THEN 999999 ELSE capacity END,name LIMIT 300").bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT entry_id,resource_id FROM timetable_plan_entry_resources WHERE tenant_id=? AND plan_id=?').bind(tenantId,planId).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT id,name FROM teachers WHERE tenant_id=? ORDER BY name LIMIT 500').bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT teacher_id,starts_at,ends_at FROM teacher_unavailability WHERE tenant_id=? AND starts_at<? AND ends_at>? LIMIT 2000').bind(tenantId,bisIso,vonIso).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT teacher_id,weekday,starts_time,ends_time,valid_from,valid_until FROM teacher_availability WHERE tenant_id=? LIMIT 3000').bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT course_id,title,blackout_type,starts_at,ends_at FROM planning_blackouts WHERE tenant_id=? AND blocks_teaching=1 AND starts_at<? AND ends_at>? LIMIT 2000').bind(tenantId,bisIso,vonIso).all<Record<string,unknown>>(),
    env.DB.prepare("SELECT course_id,COUNT(DISTINCT user_id) n FROM memberships WHERE tenant_id=? AND role IN ('participant','class_admin') GROUP BY course_id").bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT id,teacher_id,starts_at,ends_at FROM lessons WHERE tenant_id=? AND starts_at<? AND ends_at>? LIMIT 3000').bind(tenantId,bisIso,vonIso).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT rr.resource_id,l.starts_at,l.ends_at FROM lesson_resource_reservations rr JOIN lessons l ON l.id=rr.lesson_id AND l.tenant_id=rr.tenant_id WHERE rr.tenant_id=? AND l.starts_at<? AND l.ends_at>? LIMIT 3000').bind(tenantId,bisIso,vonIso).all<Record<string,unknown>>(),
    ladeRhythmusregeln(env,tenantId),
  ]);

  const nachId=new Map(eintraege.map(e=>[e.id,e]));
  const raeume=(raumZeilen.results??[]).map(r=>({id:String(r.id),name:String(r.name??''),code:String(r.code??''),capacity:r.capacity===null||r.capacity===undefined?null:Number(r.capacity)}));
  const raumNachName=new Map<string,string>(),raumNachCode=new Map<string,string>();
  for(const r of raeume){if(r.name)raumNachName.set(r.name.toLowerCase(),r.id);if(r.code)raumNachCode.set(r.code.toLowerCase(),r.id);}
  const mittelJeTermin=new Map<string,string>();
  for(const m of mittelZeilen.results??[])if(!mittelJeTermin.has(String(m.entry_id)))mittelJeTermin.set(String(m.entry_id),String(m.resource_id));
  const raumVon=(e:Eintrag)=>mittelJeTermin.get(e.id)||raumNachName.get(String(e.room??'').toLowerCase())||raumNachCode.get(String(e.room??'').toLowerCase())||'';
  const teilnehmende=new Map<string,number>();
  for(const t of teilnahmeZeilen.results??[])teilnehmende.set(String(t.course_id),Number(t.n)||0);

  const raumBelegt=new Map<string,Belegung[]>(),dozentBelegt=new Map<string,Belegung[]>(),kursBelegt=new Map<string,Belegung[]>();
  const anfuegen=(m:Map<string,Belegung[]>,k:string,b:Belegung)=>{const l=m.get(k);if(l)l.push(b);else m.set(k,[b]);};
  for(const e of eintraege){
    const r=raumVon(e);
    if(r)anfuegen(raumBelegt,r,{von:e.starts_at,bis:e.ends_at,entry:e.id});
    if(e.teacher_id)anfuegen(dozentBelegt,e.teacher_id,{von:e.starts_at,bis:e.ends_at,entry:e.id});
    anfuegen(kursBelegt,e.course_id,{von:e.starts_at,bis:e.ends_at,entry:e.id});
  }
  for(const l of unterrichtZeilen.results??[])if(l.teacher_id)anfuegen(dozentBelegt,String(l.teacher_id),{von:String(l.starts_at),bis:String(l.ends_at),entry:`lesson:${String(l.id)}`});
  for(const b of belegungZeilen.results??[])anfuegen(raumBelegt,String(b.resource_id),{von:String(b.starts_at),bis:String(b.ends_at),entry:'lesson'});
  for(const a of abwesenheitZeilen.results??[])anfuegen(dozentBelegt,String(a.teacher_id),{von:String(a.starts_at),bis:String(a.ends_at),entry:'abwesend'});
  const zusagen=new Map<string,Array<Record<string,unknown>>>();
  for(const z of zusagenZeilen.results??[]){const k=String(z.teacher_id),l=zusagen.get(k);if(l)l.push(z);else zusagen.set(k,[z]);}
  const sperren=(sperrZeilen.results??[]).map(b=>({course_id:b.course_id===null||b.course_id===undefined?null:String(b.course_id),titel:String(b.title??''),von:String(b.starts_at),bis:String(b.ends_at)}));
  const gesperrt=(courseId:string,von:string,bis:string)=>sperren.some(s=>(s.course_id===null||s.course_id===courseId)&&ueberlappt(von,bis,s.von,s.bis));
  const zusageErfuellt=(teacherId:string,von:string,bis:string)=>{
    const liste=zusagen.get(teacherId);
    if(!liste?.length)return true;
    const tag=tagSchluessel(von),wtag=((new Date(von).getUTCDay()+6)%7)+1;
    return liste.some(z=>Number(z.weekday)===wtag&&String(z.starts_time)<=uhrzeit(von)&&String(z.ends_time)>=uhrzeit(bis)&&(z.valid_from===null||z.valid_from===undefined||String(z.valid_from)<=tag)&&(z.valid_until===null||z.valid_until===undefined||String(z.valid_until)>=tag));
  };

  const vorschlaege:Vorschlag[]=[];
  const tiefe=(art:Vorschlag['art'],kosten:Vorschlagskosten)=>kosten.eintraege*100+ART_GEWICHT[art]+Math.min(600,kosten.verschobene_minuten)+(kosten.unterricht_entfaellt_minuten?1000:0);
  const hinzu=(konflikt:Record<string,unknown>,e:Eintrag,art:Vorschlag['art'],titel:string,begruendung:string,kosten:Vorschlagskosten,ziel:Vorschlag['ziel'])=>{
    vorschlaege.push({conflict_id:String(konflikt.id),conflict_type:String(konflikt.conflict_type),severity:String(konflikt.severity),entry_id:e.id,art,titel,begruendung,eingriffstiefe:tiefe(art,kosten),kosten,ziel});
  };

  for(const k of konfliktZeilen.results??[]){
    const e=nachId.get(String(k.entry_id));
    if(!e)continue;
    const art=String(k.conflict_type),dauer=minuten(e.starts_at,e.ends_at),koepfe=teilnehmende.get(e.course_id)||0;
    const eigener=raumVon(e);
    let erzeugt=0;
    const platz=(r:{id:string;capacity:number|null})=>r.capacity===null||r.capacity>=koepfe;

    // a) Raumwechsel - verschiebt niemanden und ist deshalb der flachste Eingriff ueberhaupt.
    if(['resource_overlap','resource_capacity','resource_unavailable','resource_inactive','room_overlap'].includes(art)){
      for(const r of raeume){
        if(erzeugt>=MAX_VORSCHLAEGE_JE_KONFLIKT)break;
        if(r.id===eigener||!platz(r)||!frei(raumBelegt.get(r.id),e.starts_at,e.ends_at,e.id))continue;
        hinzu(k,e,'raum_wechseln',`Raum ${r.name} statt ${e.room||'bisher'}`,`${r.name} ist zu dieser Zeit frei${r.capacity===null?'':` und fasst ${r.capacity} Personen`}. Kein Termin muss verschoben werden.`,
          {eintraege:1,verschobene_minuten:0,betroffene_teilnehmende:0,unterricht_entfaellt_minuten:0},{room:r.name,resource_id:r.id});
        erzeugt++;
      }
    }

    // b) Dozentenwechsel - eine Person tauscht, der Termin bleibt.
    if(['teacher_unavailable','teacher_outside_availability','teacher_overlap','teacher_daily_limit','teacher_weekly_limit','missing_teacher'].includes(art)){
      for(const d of dozentZeilen.results??[]){
        if(erzeugt>=MAX_VORSCHLAEGE_JE_KONFLIKT)break;
        const did=String(d.id);
        if(did===String(e.teacher_id||''))continue;
        if(!frei(dozentBelegt.get(did),e.starts_at,e.ends_at,e.id))continue;
        if(!zusageErfuellt(did,e.starts_at,e.ends_at))continue;
        hinzu(k,e,'dozent_wechseln',`${String(d.name)} statt ${e.teacher_name||'bisher'}`,`${String(d.name)} ist zu dieser Zeit frei und innerhalb der zugesagten Arbeitszeiten. Der Termin bleibt, wo er ist.`,
          {eintraege:1,verschobene_minuten:0,betroffene_teilnehmende:0,unterricht_entfaellt_minuten:0},{teacher_id:did,teacher_name:String(d.name)});
        erzeugt++;
      }
    }

    // c) Verschieben - der Termin bewegt sich, die Klasse muss umplanen.
    if(erzeugt<MAX_VORSCHLAEGE_JE_KONFLIKT){
      const tagesBeginn=Date.parse(`${tagSchluessel(e.starts_at)}T06:00:00.000Z`),tagesEnde=Date.parse(`${tagSchluessel(e.starts_at)}T21:00:00.000Z`);
      const schritte:number[]=[];
      for(let i=1;i<=6;i++){schritte.push(i*dauer);schritte.push(-i*dauer);}
      for(const versatz of schritte){
        if(erzeugt>=MAX_VORSCHLAEGE_JE_KONFLIKT)break;
        const von=new Date(Date.parse(e.starts_at)+versatz*60000).toISOString(),bis=new Date(Date.parse(e.ends_at)+versatz*60000).toISOString();
        if(Date.parse(von)<tagesBeginn||Date.parse(bis)>tagesEnde)continue;
        if(gesperrt(e.course_id,von,bis))continue;
        if(!frei(kursBelegt.get(e.course_id),von,bis,e.id))continue;
        if(e.teacher_id&&!frei(dozentBelegt.get(e.teacher_id),von,bis,e.id))continue;
        if(e.teacher_id&&!zusageErfuellt(e.teacher_id,von,bis))continue;
        if(eigener&&!frei(raumBelegt.get(eigener),von,bis,e.id))continue;
        hinzu(k,e,'verschieben',`Auf ${uhrzeit(von)}–${uhrzeit(bis)} Uhr verschieben`,`Am selben Tag ${Math.abs(versatz)} Minuten ${versatz>0?'später':'früher'}; Klasse, Lehrkraft und Raum sind dann frei.`,
          {eintraege:1,verschobene_minuten:Math.abs(versatz),betroffene_teilnehmende:koepfe,unterricht_entfaellt_minuten:0},{starts_at:von,ends_at:bis});
        erzeugt++;
      }
    }

    // d) Tauschen - zwei Termine bewegen sich. Nur wenn beide Seiten danach frei sind.
    if(erzeugt<MAX_VORSCHLAEGE_JE_KONFLIKT){
      for(const anderer of eintraege){
        if(erzeugt>=MAX_VORSCHLAEGE_JE_KONFLIKT)break;
        if(anderer.id===e.id||anderer.course_id!==e.course_id)continue;
        if(minuten(anderer.starts_at,anderer.ends_at)!==dauer)continue;
        if(tagSchluessel(anderer.starts_at)===tagSchluessel(e.starts_at)&&anderer.starts_at===e.starts_at)continue;
        if(gesperrt(e.course_id,anderer.starts_at,anderer.ends_at))continue;
        if(e.teacher_id&&!frei(dozentBelegt.get(e.teacher_id),anderer.starts_at,anderer.ends_at,e.id))continue;
        if(anderer.teacher_id&&!frei(dozentBelegt.get(anderer.teacher_id),e.starts_at,e.ends_at,anderer.id))continue;
        const versatz=Math.abs(Math.round((Date.parse(anderer.starts_at)-Date.parse(e.starts_at))/60000));
        hinzu(k,e,'tauschen',`Mit ${bezeichnung(anderer)} am ${zeitpunkt(anderer.starts_at)} tauschen`,`Beide Termine gehören derselben Klasse und sind gleich lang. Zwei bestehende Termine bewegen sich.`,
          {eintraege:2,verschobene_minuten:versatz*2,betroffene_teilnehmende:koepfe,unterricht_entfaellt_minuten:0},{starts_at:anderer.starts_at,ends_at:anderer.ends_at,tausch_entry_id:anderer.id});
        erzeugt++;
      }
    }

    // e) Streichen - loest jeden Konflikt und kostet Unterricht. Deshalb immer ganz unten.
    hinzu(k,e,'entfernen',`Termin am ${zeitpunkt(e.starts_at)} streichen`,`Löst den Konflikt sicher, nimmt der Klasse aber ${dauer} Minuten Unterricht. Nur, wenn sich nichts anderes findet.`,
      {eintraege:1,verschobene_minuten:0,betroffene_teilnehmende:koepfe,unterricht_entfaellt_minuten:dauer},{});
    if(vorschlaege.length>=MAX_VORSCHLAEGE)break;
  }

  vorschlaege.sort((a,b)=>a.eingriffstiefe-b.eingriffstiefe
    ||(a.severity===b.severity?0:a.severity==='error'?-1:1)
    ||a.kosten.betroffene_teilnehmende-b.kosten.betroffene_teilnehmende
    ||(a.conflict_id<b.conflict_id?-1:1));
  const offen=(konfliktZeilen.results??[]).length;
  return{plan_id:planId,plan_name:String(plan.name),konflikte:offen,
    ohne_vorschlag:offen-new Set(vorschlaege.map(v=>v.conflict_id)).size,
    vorschlaege:vorschlaege.slice(0,MAX_VORSCHLAEGE),
    rhythmus_hinweise:rhythmusBefunde(eintraege,regeln).length};
}

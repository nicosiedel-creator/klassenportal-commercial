import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Medienbibliothek mit Rechteverwaltung (K8), Video und Audio in Aufgaben (K9),
// Untertitel und Transkript (K10).
//
// Bisher lag jedes Bild dort, wo es jemand hochgeladen hat. Drei Folgen, jede teuer:
//  - Niemand wusste die Lizenz. Bei einer Abmahnung ist "das hat mal jemand hochgeladen" keine
//    Auskunft, und eine befristete Lizenz lief ab, ohne dass irgendwo stand, WO das Bild
//    ueberall verwendet wird.
//  - Video und Audio waren in Aufgaben nicht vorgesehen.
//  - Untertitel fehlten. Ein Lernvideo ohne Untertitel ist fuer gehoerlose Teilnehmende kein
//    Lernvideo - und fuer einen gefoerderten Traeger ein Befund.
//
// Der Inhalt liegt in R2. D1 haelt nur, WO die Datei liegt: die Datenbank hat eine harte Grenze
// von 10 GB, ein einziges Schulungsvideo waere ein Prozent davon.

const clean=(v:unknown,n=2000)=>safeString(v,n);
export const LIZENZEN=['eigenes_werk','cc0','cc_by','cc_by_sa','cc_by_nc','gemeinfrei','lizenziert','unklar'] as const;
export const ZWECKE=['unterricht','oeffentlich','druck'] as const;
export const SPURARTEN=['untertitel','transkript','audiodeskription','uebersetzung'] as const;
// Lizenzen, die eine Quellenangabe verlangen. Ohne Urheber ist die Bedingung nicht erfuellt und
// die Nutzung damit unlizenziert - auch wenn die Lizenz "frei" heisst.
const BRAUCHT_URHEBER=new Set(['cc_by','cc_by_sa','cc_by_nc','lizenziert']);
// Diese Lizenzen decken keine oeffentliche Nutzung ohne weitere Pruefung.
const NUR_INTERN=new Set(['cc_by_nc','unklar']);

type Medium={id:string;art:string;lizenz:string;lizenz_bis:string|null;verwendung_json:string;status:string;titel:string};

async function ladeMedium(env:Env,tenantId:string,assetId:string):Promise<Medium>{
  const m=await env.DB.prepare('SELECT id,art,lizenz,lizenz_bis,verwendung_json,status,titel FROM media_assets WHERE id=? AND tenant_id=?')
    .bind(clean(assetId,120),tenantId).first<Medium>();
  if(!m)throw new Error('MEDIUM_NICHT_GEFUNDEN');
  return m;
}

/**
 * Ein Medium aufnehmen.
 *
 * Die Lizenzangabe ist Pflicht - auch 'unklar' ist eine Angabe, aber eine, die die Verwendung
 * sperrt. Das ist der Unterschied zu einem Pflichtfeld, das man mit einem Leerzeichen fuellt.
 */
export async function nimmMediumAuf(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const art=clean(input.art,20),titel=clean(input.titel,200);
  if(!['bild','video','audio','dokument'].includes(art))throw new Error('MEDIUM_ART_UNGUELTIG');
  if(titel.length<3)throw new Error('MEDIUM_TITEL_ERFORDERLICH');
  const lizenz=clean(input.lizenz,30);
  if(!(LIZENZEN as readonly string[]).includes(lizenz))throw new Error('MEDIUM_LIZENZ_ERFORDERLICH');
  const urheber=clean(input.urheber,200)||null;
  // Eine CC-BY-Datei ohne Urheber ist nicht "fast lizenziert", sondern unlizenziert: die
  // Namensnennung IST die Bedingung.
  if(BRAUCHT_URHEBER.has(lizenz)&&!urheber)throw new Error('MEDIUM_URHEBER_ERFORDERLICH');
  const lizenzBis=clean(input.lizenz_bis,10)||null;
  if(lizenzBis&&!/^\d{4}-\d{2}-\d{2}$/.test(lizenzBis))throw new Error('MEDIUM_LIZENZFRIST_UNGUELTIG');
  const r2Key=clean(input.r2_key,500),sha=clean(input.sha256,80);
  if(!r2Key||!sha)throw new Error('MEDIUM_ABLAGE_ERFORDERLICH');
  const groesse=Math.trunc(Number(input.groesse_bytes??0));
  if(!Number.isFinite(groesse)||groesse<=0)throw new Error('MEDIUM_GROESSE_UNGUELTIG');
  const rohZweck=Array.isArray(input.verwendung)?input.verwendung.map(v=>clean(v,20)):['unterricht'];
  const verwendung=[...new Set(rohZweck)].filter(z=>(ZWECKE as readonly string[]).includes(z));
  if(!verwendung.length)throw new Error('MEDIUM_VERWENDUNG_ERFORDERLICH');
  // Was die Lizenz nicht hergibt, darf auch nicht als erlaubt eingetragen werden - sonst waere
  // die Lizenzangabe Dekoration.
  if(NUR_INTERN.has(lizenz)&&verwendung.some(z=>z!=='unterricht'))throw new Error('MEDIUM_LIZENZ_DECKT_ZWECK_NICHT');
  const doppelt=await env.DB.prepare('SELECT id FROM media_assets WHERE tenant_id=? AND sha256=?').bind(tenantId,sha).first<{id:string}>();
  if(doppelt)throw new Error('MEDIUM_BEREITS_VORHANDEN');
  const ts=nowIso(),assetId=id('med_');
  await env.DB.prepare('INSERT INTO media_assets(id,tenant_id,r2_key,dateiname,content_type,groesse_bytes,sha256,art,dauer_sekunden,titel,beschreibung,lizenz,urheber,lizenz_quelle,lizenz_bis,verwendung_json,status,hochgeladen_von,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(assetId,tenantId,r2Key,clean(input.dateiname,300)||'datei',clean(input.content_type,120)||'application/octet-stream',
      groesse,sha,art,input.dauer_sekunden==null?null:Math.max(0,Math.trunc(Number(input.dauer_sekunden))),
      titel,clean(input.beschreibung,2000)||null,lizenz,urheber,clean(input.lizenz_quelle,500)||null,lizenzBis,
      JSON.stringify(verwendung),'aktiv',auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'media.added',tenantId,undefined,'media_asset',assetId,{art,lizenz});
  return{id:assetId,art,lizenz,status:'aktiv'};
}

/**
 * Ein Medium irgendwo einbinden - der Punkt, an dem die Rechte geprueft werden.
 *
 * Beim Hochladen zu pruefen reicht nicht: die Lizenz kann seither abgelaufen sein, und der
 * Zweck steht erst hier fest.
 */
export async function bindeMediumEin(env:Env,auth:CoreAuthContext,tenantId:string,assetId:string,input:Record<string,unknown>,heute?:string){
  requireRole(auth,'class_admin');
  const m=await ladeMedium(env,tenantId,assetId);
  const tag=clean(heute,10)||nowIso().slice(0,10);
  if(m.lizenz==='unklar')throw new Error('MEDIUM_LIZENZ_UNKLAR');
  if(m.status==='gesperrt')throw new Error('MEDIUM_GESPERRT');
  if(m.status==='abgelaufen'||(m.lizenz_bis&&m.lizenz_bis<tag))throw new Error('MEDIUM_LIZENZ_ABGELAUFEN');
  const objektTyp=clean(input.objekt_typ,40),objektId=clean(input.objekt_id,120);
  if(!['aufgabe','quiz_frage','kursmaterial','nachricht','seite','zeugnisvorlage'].includes(objektTyp))throw new Error('MEDIUM_OBJEKTART_UNGUELTIG');
  if(!objektId)throw new Error('MEDIUM_OBJEKT_ERFORDERLICH');
  const zweck=clean(input.zweck,20)||'unterricht';
  if(!(ZWECKE as readonly string[]).includes(zweck))throw new Error('MEDIUM_ZWECK_UNGUELTIG');
  let erlaubt:string[]=[];try{erlaubt=JSON.parse(m.verwendung_json||'[]');}catch{}
  if(!erlaubt.includes(zweck))throw new Error('MEDIUM_ZWECK_NICHT_GEDECKT');
  const ts=nowIso();
  await env.DB.prepare('INSERT INTO media_usages(id,tenant_id,asset_id,objekt_typ,objekt_id,feld,zweck,eingebunden_von,created_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(asset_id,objekt_typ,objekt_id,feld) DO UPDATE SET zweck=excluded.zweck')
    .bind(id('mvw_'),tenantId,m.id,objektTyp,objektId,clean(input.feld,60)||null,zweck,auth.userId,ts).run();
  return{eingebunden:true};
}

/** Eine Spur hinterlegen: Untertitel, Transkript, Audiodeskription. */
export async function legeSpurAn(env:Env,auth:CoreAuthContext,tenantId:string,assetId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const m=await ladeMedium(env,tenantId,assetId);
  if(m.art!=='video'&&m.art!=='audio')throw new Error('MEDIUM_SPUR_NUR_AV');
  const art=clean(input.art,30);
  if(!(SPURARTEN as readonly string[]).includes(art))throw new Error('MEDIUM_SPURART_UNGUELTIG');
  const sprache=clean(input.sprache,10)||'de';
  const inhalt=clean(input.inhalt,20000)||null,r2Key=clean(input.r2_key,500)||null;
  if(!inhalt&&!r2Key)throw new Error('MEDIUM_SPUR_INHALT_ERFORDERLICH');
  const quelle=clean(input.quelle,20)||'manuell';
  if(!['manuell','ki','import'].includes(quelle))throw new Error('MEDIUM_SPURQUELLE_UNGUELTIG');
  const ts=nowIso();
  // Manuell erstellte Spuren gelten als geprueft - jemand hat sie geschrieben. KI-Spuren nicht.
  const geprueftVon=quelle==='manuell'?auth.userId:null;
  await env.DB.prepare('INSERT INTO media_tracks(id,tenant_id,asset_id,art,sprache,inhalt,r2_key,quelle,geprueft_von,geprueft_am,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(asset_id,art,sprache) DO UPDATE SET inhalt=excluded.inhalt,r2_key=excluded.r2_key,quelle=excluded.quelle,geprueft_von=excluded.geprueft_von,geprueft_am=excluded.geprueft_am,updated_at=excluded.updated_at')
    .bind(id('msp_'),tenantId,m.id,art,sprache,inhalt,r2Key,quelle,geprueftVon,geprueftVon?ts:null,ts,ts).run();
  return{art,sprache,quelle,geprueft:Boolean(geprueftVon)};
}

/** Eine KI-Spur pruefen und freigeben. */
export async function gibSpurFrei(env:Env,auth:CoreAuthContext,tenantId:string,assetId:string,art:string,sprache:string){
  requireRole(auth,'class_admin');
  const ts=nowIso();
  const zeile=await env.DB.prepare('SELECT id,geprueft_am FROM media_tracks WHERE tenant_id=? AND asset_id=? AND art=? AND sprache=?')
    .bind(tenantId,clean(assetId,120),clean(art,30),clean(sprache,10)).first<{id:string;geprueft_am:string|null}>();
  if(!zeile)throw new Error('MEDIUM_SPUR_NICHT_GEFUNDEN');
  await env.DB.prepare('UPDATE media_tracks SET geprueft_von=?,geprueft_am=?,updated_at=? WHERE id=? AND tenant_id=?').bind(auth.userId,ts,ts,zeile.id,tenantId).run();
  return{geprueft_am:ts};
}

/**
 * Der Torwaechter vor jeder Veroeffentlichung von Video oder Audio.
 *
 * Eine automatische Untertitelung mit Fehlern ist fuer die betroffene Person schlimmer als
 * keine: sie sieht aus wie ein Angebot und ist keines. Deshalb zaehlt nur eine GEPRUEFTE Spur.
 * Eine Abfrage fuer alle Medien des Objekts - eine je Medium waere bei einer Lektion mit zehn
 * Clips schon spuerbar.
 */
export async function assertBarrierefrei(env:Env,tenantId:string,objektTyp:string,objektId:string,sprache='de'){
  const offen=((await env.DB.prepare(`SELECT a.id,a.titel,a.art FROM media_usages v JOIN media_assets a ON a.id=v.asset_id
    WHERE v.tenant_id=? AND v.objekt_typ=? AND v.objekt_id=? AND a.art IN ('video','audio')
      AND NOT EXISTS(SELECT 1 FROM media_tracks t WHERE t.asset_id=a.id AND t.art='untertitel' AND t.sprache=? AND t.geprueft_am IS NOT NULL)`)
    .bind(tenantId,clean(objektTyp,40),clean(objektId,120),clean(sprache,10)).all<{id:string;titel:string;art:string}>()).results)??[];
  if(offen.length)throw new Error('MEDIUM_UNTERTITEL_FEHLT');
  return{geprueft:true};
}

/**
 * Lizenzlauf: was laeuft ab, was ist abgelaufen - und WO wird es verwendet.
 *
 * Die Fundstellen sind der Punkt. Eine Warnung ohne sie sagt, dass etwas ersetzt werden muss,
 * aber nicht wo; und dann wird sie weggeklickt.
 */
export async function lizenzlauf(env:Env,auth:CoreAuthContext,tenantId:string,heute?:string,vorlaufTage=30){
  requireRole(auth,'class_admin');
  const tag=clean(heute,10)||nowIso().slice(0,10);
  const grenze=new Date(Date.parse(tag)+vorlaufTage*86400000).toISOString().slice(0,10);
  const betroffen=((await env.DB.prepare(`SELECT id,titel,lizenz,lizenz_bis,status FROM media_assets
    WHERE tenant_id=? AND lizenz_bis IS NOT NULL AND lizenz_bis<=? ORDER BY lizenz_bis LIMIT 200`)
    .bind(tenantId,grenze).all<{id:string;titel:string;lizenz:string;lizenz_bis:string;status:string}>()).results)??[];
  if(!betroffen.length)return{abgelaufen:[],laeuft_ab:[],gesperrt:0};
  const ph=betroffen.map(()=>'?').join(',');
  const stellen=((await env.DB.prepare(`SELECT asset_id,objekt_typ,objekt_id,feld,zweck FROM media_usages WHERE tenant_id=? AND asset_id IN (${ph})`)
    .bind(tenantId,...betroffen.map(b=>b.id)).all<Record<string,unknown>>()).results)??[];
  const karte=new Map<string,Record<string,unknown>[]>();
  for(const s of stellen){const k=String(s.asset_id);if(!karte.has(k))karte.set(k,[]);karte.get(k)!.push(s);}
  const abgelaufen=betroffen.filter(b=>b.lizenz_bis<tag);
  const laeuftAb=betroffen.filter(b=>b.lizenz_bis>=tag);
  // Abgelaufen heisst gesperrt. Das darf kein manueller Schritt sein - er bleibt sonst liegen.
  const zuSperren=abgelaufen.filter(b=>b.status!=='abgelaufen');
  if(zuSperren.length){
    const ts=nowIso();
    for(let i=0;i<zuSperren.length;i+=90)
      await env.DB.batch(zuSperren.slice(i,i+90).map(b=>env.DB.prepare("UPDATE media_assets SET status='abgelaufen',updated_at=? WHERE id=? AND tenant_id=?").bind(ts,b.id,tenantId)));
  }
  const mitStellen=(b:{id:string;titel:string;lizenz:string;lizenz_bis:string})=>({...b,fundstellen:karte.get(b.id)??[]});
  return{abgelaufen:abgelaufen.map(mitStellen),laeuft_ab:laeuftAb.map(mitStellen),gesperrt:zuSperren.length};
}

/** Ein Medium loeschen - aber nicht, solange es irgendwo haengt. */
export async function entferneMedium(env:Env,auth:CoreAuthContext,tenantId:string,assetId:string){
  requireRole(auth,'tenant_admin');
  const m=await ladeMedium(env,tenantId,assetId);
  const inGebrauch=await env.DB.prepare('SELECT COUNT(*) AS n FROM media_usages WHERE tenant_id=? AND asset_id=?').bind(tenantId,m.id).first<{n:number}>();
  // Loeschen, was noch eingebunden ist, hinterlaesst tote Verweise in Aufgaben und Zeugnissen -
  // und zwar genau dort, wo es niemand sofort sieht.
  if(Number(inGebrauch?.n??0))throw new Error('MEDIUM_IN_VERWENDUNG');
  await env.DB.prepare('DELETE FROM media_assets WHERE id=? AND tenant_id=?').bind(m.id,tenantId).run();
  await audit(env.DB,auth.userId,'media.removed',tenantId,undefined,'media_asset',m.id,{});
  return{entfernt:true};
}

/** Die Bibliothek - mit Spuren- und Verwendungszahl, in drei Abfragen. */
export async function medienbibliothek(env:Env,auth:CoreAuthContext,tenantId:string,art?:string){
  requireRole(auth,'class_admin');
  const filter=clean(art,20);
  const medien=((await env.DB.prepare(`SELECT id,titel,art,content_type,groesse_bytes,dauer_sekunden,lizenz,urheber,lizenz_bis,verwendung_json,status,created_at
    FROM media_assets WHERE tenant_id=? AND (?='' OR art=?) ORDER BY created_at DESC LIMIT 200`)
    .bind(tenantId,filter,filter).all<Record<string,unknown>>()).results)??[];
  if(!medien.length)return{medien:[]};
  const ph=medien.map(()=>'?').join(','),ids=medien.map(m=>String(m.id));
  const spuren=((await env.DB.prepare(`SELECT asset_id,art,sprache,quelle,geprueft_am FROM media_tracks WHERE tenant_id=? AND asset_id IN (${ph})`)
    .bind(tenantId,...ids).all<Record<string,unknown>>()).results)??[];
  const nutzung=((await env.DB.prepare(`SELECT asset_id,COUNT(*) AS n FROM media_usages WHERE tenant_id=? AND asset_id IN (${ph}) GROUP BY asset_id`)
    .bind(tenantId,...ids).all<{asset_id:string;n:number}>()).results)??[];
  const nkarte=new Map(nutzung.map(n=>[n.asset_id,Number(n.n)]));
  return{medien:medien.map(m=>{
    const eigene=spuren.filter(s=>s.asset_id===m.id);
    return{...m,
      spuren:eigene,
      verwendungen:nkarte.get(String(m.id))??0,
      // Der Satz, der in der Liste stehen muss: ist dieses Video verwendbar?
      barrierefrei:m.art!=='video'&&m.art!=='audio'
        ? true
        : eigene.some(s=>s.art==='untertitel'&&s.geprueft_am)};
  })};
}

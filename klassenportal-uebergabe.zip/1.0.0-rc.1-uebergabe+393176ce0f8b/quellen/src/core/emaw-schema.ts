// ERZEUGT — nicht von Hand ändern.
// Quelle: spec/emaw/emaw-v2.18.xsd (Bundesagentur für Arbeit, Schema-Version 2.18).
// Neu erzeugen mit: node scripts/emaw-schema-ableiten.mjs

export const EMAW_SCHEMA_VERSION='2.18' as const;
export const EMAW_SCHEMA_DATEI='emaw-v2.18.xsd' as const;

/** Alle Ereignisarten des Schemas, in der Reihenfolge der Schemadatei. */
export const EMAW_EREIGNISARTEN=['AnmeldungKontakt','RueckmeldungKontakt','AnmeldungBAE','AnmeldungBVB','AnmeldungABH','AnmeldungAMP','AnmeldungREHA','SVAnmeldung','FeststellungFoerderbedarfABH','Eintritt','Nichtantritt','AnwesenheitMonat','WochenFehlzeit','Beurteilung','PhaseIVerlaengerung','Verlaengerung','PhaseIEnde','Austritt','AustrittBNF','AustrittBVB','AenderungAnsprechpartnerBA','AenderungTeilnehmerdaten','MitteilungAufstockungPlatzkapazitaet','BestaetigungAufstockungPlatzkapazitaet','KooperationBetrieb','KooperationBetriebV2','FragebogenESF','MitteilungPraktikumsverguetung','WechselAusbildungsform','WechselAusbildungsformV2','AusbildungsvertragVonTraeger','AusbildungsvertragVonTraegerV2','Korrektur','Mitteilung','Zustimmung','PhaseIZustimmung','Ablehnung','PhaseIAblehnung','AGHAnmeldung','AGHAbsageTraeger','AGHZusageTraeger','AGHAbsageAA','AGHZusageAA','AGHAenderungTeilnehmerdaten','AGHAenderungAnsprechpartnerTraegerteam','AGHAenderungAnsprechpartnerBetreuerteam','AGHAnforderungMassnahmebericht','AGHMassnahmebericht','AGHErledigungMassnahmebericht','AGHVerlaengerungTeilnahme','AGHAustrittVorzeitigVonJC','AGHAustrittVorzeitigVonTraeger','AGHBestaetigungAustritt','AGHAblehnungAustritt','AGHAnforderungMonatsabrechnung','AGHMonatsabrechnung','AGHBeanstandungMonatsabrechnung','AGHKorrekturMonatsabrechnung','AGH-Neu-AnforderungMonatsabrechnung','AGH-Neu-Monatsabrechnung','AGH-Neu-BeanstandungMonatsabrechnung','AGH-Neu-KorrekturMonatsabrechnung','AGH-Neu-MonatsabrechnungOhneBeanstandung','AGH-Neu-AuszahlungMonatsabrechnung','AGHMitteilungLoeschungTeilnehmer','AGHNichtantrittVonTraeger','AGHBestaetigung','AGHAblehnung','AGH-BasisAblehnung-Massnahme','UebermittlungTeilnehmerDokumente','UebermittlungMassnahmeDokumente','AsAAufforderungBegleitungsstunden','AsABegleitungsstunden','AsAMitteilungAenderungStundenanzahl','AsAZustimmungAenderungStundenanzahl','AsAAblehnungAenderungStundenanzahl','AblehnungAufstockungPlatzkapazitaet','AsAMeldungBegleitungsstunden','AsAZustimmungMeldungBegleitungsstunden','AsAAblehnungMeldungBegleitungsstunden','AsAAenderungStundenFoerderdauer','Unterbrechungszeitraum','NachweisFoerderzielbereich'] as const;

/**
 * Die Kommunikationsrichtung je Ereignis, gelesen aus der Dokumentation des Schemas.
 *
 * 'an_ba' darf der Traeger senden. Alles andere empfaengt er nur. Ein Ereignis in der
 * falschen Richtung weist eM@w mit 'NOK' ab.
 */
export const EMAW_RICHTUNG:Record<string,'an_ba'|'an_traeger'|'beide'|'unklar'>={
  'Ablehnung':'an_traeger',
  'AenderungAnsprechpartnerBA':'an_traeger',
  'AenderungTeilnehmerdaten':'an_traeger',
  'AnmeldungABH':'an_traeger',
  'AnmeldungAMP':'an_traeger',
  'AnmeldungBAE':'an_traeger',
  'AnmeldungBVB':'an_traeger',
  'AnmeldungKontakt':'an_traeger',
  'AnmeldungREHA':'an_traeger',
  'AnwesenheitMonat':'an_ba',
  'AusbildungsvertragVonTraeger':'an_ba',
  'AusbildungsvertragVonTraegerV2':'an_ba',
  'Austritt':'an_ba',
  'AustrittBNF':'an_ba',
  'AustrittBVB':'an_ba',
  'BestaetigungAufstockungPlatzkapazitaet':'an_ba',
  'Beurteilung':'an_ba',
  'Eintritt':'an_ba',
  'FeststellungFoerderbedarf':'an_ba',
  'FeststellungFoerderbedarfABH':'an_ba',
  'FragebogenESF':'an_ba',
  'KooperationBetrieb':'an_ba',
  'KooperationBetriebV2':'an_ba',
  'MitteilungAufstockungPlatzkapazitaet':'an_traeger',
  'MitteilungPraktikumsverguetung':'an_ba',
  'NachweisFoerderzielbereich':'an_ba',
  'Nichtantritt':'an_ba',
  'PhaseIAblehnung':'an_traeger',
  'PhaseIEnde':'an_ba',
  'PhaseIVerlaengerung':'an_ba',
  'PhaseIZustimmung':'an_traeger',
  'RueckmeldungKontakt':'an_ba',
  'SVAnmeldung':'an_traeger',
  'Verlaengerung':'an_ba',
  'WechselAusbildungsform':'an_ba',
  'WechselAusbildungsformV2':'an_ba',
  'WochenFehlzeit':'an_ba',
  'Zustimmung':'an_traeger',
};

/** Die zulaessigen Auspraegungen eines Kalendertages in der Anwesenheitsmeldung. */
export const EMAW_ANWESENHEIT=['kein Termin','Anwesenheit','Anwesenheit - Praesenz','Anwesenheit - Online','Ferien','Berufsschule','Praktikum','Pruefungstag','Bekanntgabe Pruefungsergebnis','Fehlzeit - krank - Erstbescheinigung','Fehlzeit - krank - Folgebescheinigung','Fehlzeit - krank - Kind krank','Fehlzeit - entschuldigtes Fehlen - ohne AU','Fehlzeit - unentschuldigtes Fehlen - Sachverhaltsaufklaerung den Grundsaetzen des §20 SGB X entsprechend erfolgt','Fehlzeit - unentschuldigtes Fehlen - Sachverhaltsaufklaerung den Grundsaetzen des §20 SGB X entsprechend nicht erfolgt','MuSchG / Elternzeit'] as const;

/** Wertelisten, die der Traeger beim Senden ausfuellen muss - woertlich aus dem Schema. */
export const EMAW_BEENDIGUNG=['regulaer','vorzeitig - Arbeit','vorzeitig - Berufsvorbereitung','vorzeitig - Ausbildung betrieblich','vorzeitig - Ausbildung schulisch','vorzeitig - Ausbildung ausserbetrieblich','vorzeitig - Studium','vorzeitig - selbstaendige Taetigkeit','vorzeitig - gesundheitl. Beeintraechtigungen','vorzeitig - vertragswidriges Verhalten','vorzeitig - fehlende Motivation/ Mitwirkung','vorzeitig - Ueber-/ Unterforderung','vorzeitig - persoenliche Gruende (z.B. Umzug, Mutterschutz)','vorzeitig - Massnahmeziel aus anderen Gruenden nicht erreicht','vorzeitig - betriebsbedingte Kuendigung','vorzeitig - Insolvenz des Traegers','vorzeitig - Sozialvers.pfl. Beschaeft. beim Entleiher','vorzeitig - Sozialvers.pfl. Beschaeft. bei anderem durch PSA vermittelten AG','vorzeitig - Sozialvers.pfl. Beschaeft. ohne PSA-Beteilig. - Selbstsuche/andere','vorzeitig - Aufloes. Arbeitsverh./Kuend. durch PSA wegen FbW-Massnahme','vorzeitig - Aufloes. Arbeitsverh./Kuend. durch PSA wegen anderer SGB III - Massnahme','vorzeitig - Kuendigung durch Arbeitnehmer ohne Anschlussbeschaeftigung','vorzeitig - Massnahmeziel vorzeitig erreicht','vorzeitig - Werkstatt fuer behinderte Menschen','vorzeitig - fehlende Arbeitsmarkt-Faehigkeit (z. B. WfbM)'] as const;
export const EMAW_VERBLEIB=['Arbeitslosigkeit','Arbeit - versicherungspflichtig - befristet','Arbeit - versicherungspflichtig - unbefristet','Arbeit - MiniJob (-400 Euro)','Arbeit - MiniJob (-450 Euro)','Arbeit - MiniJob','Selbstaendigkeit','Ausbildung - betriebliche Ausbildung nach §4 BBiG, §25 HWO - gefoerdert','Ausbildung - betriebliche Ausbildung nach § 4 BBiG, § 25 HWO, SeeArbG, AltPflG und 2. Teil des PflBG gefoerdert','Ausbildung - betriebliche Ausbildung nach §4 BBiG, §25 HWO - ungefoerdert','Ausbildung - betriebliche Ausbildung nach § 4 BBiG, § 25 HWO, SeeArbG, AltPflG und 2. Teil des PflBG ungefoerdert','Ausbildung - betriebliche Ausbildung nach §66 BBiG, §42m HWO - gefoerdert','Ausbildung - betriebliche Ausbildung nach § 66 BBiG, § 42r HwO - gefoerdert','Ausbildung - betriebliche Ausbildung nach §66 BBiG, §42m HWO - ungefoerdert','Ausbildung - betriebliche Ausbildung nach § 66 BBiG, § 42r HwO - ungefoerdert','Ausbildung - ausserbetriebliche Ausbildung nach §4 BBiG, §25 HWO','Ausbildung - ausserbetriebliche Ausbildung nach § 4 BBiG, § 25 HWO, SeeArbG','Ausbildung - ausserbetriebliche Ausbildung nach §66 BBiG, §42m HWO','Ausbildung - ausserbetriebliche Ausbildung nach § 66 BBiG, § 42r HwO - gefoerdert','Berufsbildende Schule mit dem Ziel Schulabschluss - Hauptschulabschluss','Berufsbildende Schule mit dem Ziel Schulabschluss - Fachoberschulreife','Berufsbildende Schule mit dem Ziel Schulabschluss - Fachhochschulreife','Berufsbildende Schule mit dem Ziel Schulabschluss - Abitur','Berufsbildende Schule mit dem Ziel Berufsabschluss','Schulische Berufsausbildung','Berufsvorbereitung - schulisch','Berufsvorbereitung - nach BBiG','Berufsvorbereitung - EQJ','erneute Teilnahme/ Wechsel in andere Massnahme - Massnahmen nach SGB III','erneute Teilnahme/ Wechsel in andere Massnahme - sonstige andere Massnahmen','Werkstatt fuer behinderte Menschen','Werkstatt fuer behinderte Menschen/andere Leistungsanbieter','Mutterschutz/ Elternzeit','Arbeitsunfaehigkeit','Erwerbsunfaehigkeit','Grundwehrdienst/ Wehrersatzdienst','Studium','FSJ/FOEJ/FSTJ','Au Pair','Ausland','unbekannter Verbleib','allgemeinbildende Schule','Bundesfreiwilligendienst','Wechsel der Massnahme aufgrund Vertragsende','Berufsvorbereitung EQ'] as const;
export const EMAW_NICHTANTRITTGRUND=['Mehrfache Kontaktversuche erfolglos','Fehlende Mitwirkung','Arbeitsstelle','Ausbildungsstelle','Selbstaendigkeit','Weiterer Schulbesuch (Allg. / BBS)','Andere Massnahmen','Bundeswehr/Zivildienst','Mutterschutz','Elternzeit','Umzug','Krankheit / Tod','Ohne Angabe von Gruenden'] as const;
export const EMAW_BOOLEANSTRING=['J','N'] as const;

/** Muster einzelner Schluesselfelder, woertlich aus dem Schema. */
export const EMAW_MUSTER={
  KUNRTyp:'\\d{3}[A-Z]\\d{6}',
  coSachIDTyp:'[0-9a-f\\-]{36}|-1',
  TeilverfahrenTyp:'\\d{2}',
  VersionTyp:'2.00|2.01|2.02|2.03|2.04|2.05|2.06|2.07|2.08|2.09|2.10|2.11|2.12|2.13|2.14|2.15|2.16|2.18',
  AANRTyp:'[0-9][0-9][0-9]',
  DkzTyp:'[0-9]{4}[\\-][0-9]{3}|[0-9]{5}[\\-][0-9]{3}|[0-9]{5}-[0-9]{5}',
} as const;

/** Wie viele <tag>-Elemente ein Monatstyp verlangt. */
export const EMAW_MONATSTAGE:Record<string,{min:number;max:number}>={
  'AnwesenheitMonat28Oder29Typ':{min:28,max:29},
  'AnwesenheitMonat30Typ':{min:30,max:30},
  'AnwesenheitMonat31Typ':{min:31,max:31},
};

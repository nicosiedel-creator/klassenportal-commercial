import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireCourseAccess, requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Schuljahr/Periode und das gemeinsame Terminobjekt.
//
// Die Spec verlangt, dass Kalender, Stundenplan, Klassenbuch, Anwesenheit, Aufgaben, Pruefungen
// und Kommunikation aus DEMSELBEN Termin ableitbar sind. Bisher fuehrte jeder Bereich seine eigene
// Zeitangabe: ein verschobener Unterricht aenderte den Stundenplan, aber nicht das Klassenbuch,
// und die Anwesenheit hing an einer dritten Zeile, die niemand mitverschob.
//
// Der Termin ist ab jetzt die Quelle. Aus ihm entsteht die Anwesenheitseinheit, der Kalendereintrag
// und der Pruefungstermin - und wenn er sich verschiebt, verschiebt sich beides mit. Bestehende
// Zeilen bleiben unangetastet; sie tragen nur kein event_id und verhalten sich wie bisher.

export const ARTEN=['unterricht','pruefung','veranstaltung','beratung','termin','abgabe','sonstiges'] as const;
export const PERIODENARTEN=['schuljahr','semester','trimester','quartal','block','massnahme'] as const;
export type Art=typeof ARTEN[number];
const clean=(v:unknown,n=500)=>safeString(v,n);
function manager(auth:CoreAuthContext,courseId?:string){requireRole(auth,'class_admin');if(courseId)requireCourseAccess(auth,courseId,'class_admin');}

// ---------------------------------------------------------------------------
// Perioden
// ---------------------------------------------------------------------------

export async function createPeriod(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const name=clean(input.name,120),art=clean(input.art,40)||'schuljahr';
  const ab=clean(input.starts_on,20),bis=clean(input.ends_on,20);
  if(!name)throw new Error('PERIOD_NAME_REQUIRED');
  if(!PERIODENARTEN.includes(art as never))throw new Error('PERIOD_KIND_INVALID');
  if(!/^\d{4}-\d{2}-\d{2}$/.test(ab)||!/^\d{4}-\d{2}-\d{2}$/.test(bis)||ab>bis)throw new Error('PERIOD_RANGE_INVALID');
  const pid=id('per_'),ts=nowIso();
  try{
    await env.DB.prepare('INSERT INTO schedule_periods(id,tenant_id,name,art,starts_on,ends_on,ist_aktuell,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,0,?,?,?,?)')
      .bind(pid,tenantId,name,art,ab,bis,clean(input.status,40)||'geplant',auth.userId,ts,ts).run();
  }catch(e){
    if(/UNIQUE/i.test(String((e as Error).message)))throw new Error('PERIOD_NAME_TAKEN');
    throw e;
  }
  await audit(env.DB,auth.userId,'schedule.period_created',tenantId,undefined,'schedule_period',pid,{art,starts_on:ab,ends_on:bis});
  return env.DB.prepare('SELECT * FROM schedule_periods WHERE id=?').bind(pid).first();
}

/**
 * Die laufende Periode setzen.
 *
 * Genau eine je Mandant - die Datenbank setzt das ueber einen Teilindex durch. Deshalb muss die
 * bisherige erst abgeraeumt werden, und beides gehoert in einen Stapel: dazwischen duerfte es
 * keinen Augenblick geben, in dem zwei laufen oder keine.
 */
export async function setCurrentPeriod(env:Env,auth:CoreAuthContext,tenantId:string,periodId:string){
  requireRole(auth,'tenant_admin');
  const p=await env.DB.prepare('SELECT id FROM schedule_periods WHERE id=? AND tenant_id=?').bind(periodId,tenantId).first();
  if(!p)throw new Error('PERIOD_NOT_FOUND');
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare('UPDATE schedule_periods SET ist_aktuell=0,updated_at=? WHERE tenant_id=? AND ist_aktuell=1').bind(ts,tenantId),
    env.DB.prepare("UPDATE schedule_periods SET ist_aktuell=1,status=CASE WHEN status='geplant' THEN 'laufend' ELSE status END,updated_at=? WHERE id=?").bind(ts,periodId),
  ]);
  await audit(env.DB,auth.userId,'schedule.period_current',tenantId,undefined,'schedule_period',periodId);
  return{current:periodId};
}

export async function listPeriods(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  return (await env.DB.prepare('SELECT p.*,(SELECT COUNT(*) FROM courses c WHERE c.period_id=p.id) AS kurse,(SELECT COUNT(*) FROM schedule_events e WHERE e.period_id=p.id) AS termine FROM schedule_periods p WHERE p.tenant_id=? ORDER BY p.starts_on DESC')
    .bind(tenantId).all()).results??[];
}

export async function currentPeriod(env:Env,tenantId:string,stichtag=nowIso()){
  const gesetzt=await env.DB.prepare('SELECT * FROM schedule_periods WHERE tenant_id=? AND ist_aktuell=1').bind(tenantId).first<Record<string,unknown>>();
  if(gesetzt)return gesetzt;
  // Ist keine gesetzt, gilt die, in die der Stichtag faellt. Raten ist hier besser als nichts zu
  // liefern - aber nur in dieser Reihenfolge, damit eine ausdrueckliche Festlegung immer vorgeht.
  const tag=stichtag.slice(0,10);
  return env.DB.prepare("SELECT * FROM schedule_periods WHERE tenant_id=? AND starts_on<=? AND ends_on>=? AND status<>'archiviert' ORDER BY starts_on DESC")
    .bind(tenantId,tag,tag).first<Record<string,unknown>>();
}

export async function assignCourseToPeriod(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,periodId:string|null){
  manager(auth,courseId);
  if(periodId){
    const p=await env.DB.prepare('SELECT id FROM schedule_periods WHERE id=? AND tenant_id=?').bind(periodId,tenantId).first();
    if(!p)throw new Error('PERIOD_NOT_FOUND');
  }
  const r=await env.DB.prepare('UPDATE courses SET period_id=?,updated_at=? WHERE id=? AND tenant_id=?').bind(periodId,nowIso(),courseId,tenantId).run();
  if(!r.meta?.changes)throw new Error('COURSE_NOT_FOUND');
  await audit(env.DB,auth.userId,'schedule.course_period',tenantId,courseId,'course',courseId,{period_id:periodId});
  return{course_id:courseId,period_id:periodId};
}

// ---------------------------------------------------------------------------
// Termine
// ---------------------------------------------------------------------------

export type TerminEingabe={art:string;titel:string;starts_at:string;ends_at:string;raum?:string|null;
  anwesenheit_erwartet?:boolean;notiz?:string|null;quelle?:string;quelle_ref?:string|null};

function pruefeTermin(e:Record<string,unknown>):TerminEingabe{
  const art=clean(e.art,40),titel=clean(e.titel,250);
  const ab=clean(e.starts_at,40),bis=clean(e.ends_at,40);
  if(!ARTEN.includes(art as never))throw new Error('EVENT_KIND_INVALID');
  if(!titel)throw new Error('EVENT_TITLE_REQUIRED');
  if(!ab||!bis||Number.isNaN(Date.parse(ab))||Number.isNaN(Date.parse(bis)))throw new Error('EVENT_TIME_INVALID');
  // Ein Termin, der endet bevor er beginnt, ist keiner - und wuerde in jeder Auswertung
  // negative Dauern erzeugen.
  if(Date.parse(ab)>=Date.parse(bis))throw new Error('EVENT_TIME_INVALID');
  return{art,titel,starts_at:ab,ends_at:bis,raum:clean(e.raum,120)||null,
    anwesenheit_erwartet:e.anwesenheit_erwartet===true,notiz:clean(e.notiz,2000)||null,
    quelle:clean(e.quelle,40)||'manuell',quelle_ref:clean(e.quelle_ref,120)||null};
}

/**
 * Einen Termin anlegen - und daraus ableiten, was daran haengt.
 *
 * Bei `anwesenheit_erwartet` entsteht die Anwesenheitseinheit gleich mit: genau das meint die Spec
 * mit "aus demselben Objekt ableitbar". Wer sie spaeter von Hand nachtraegt, hat zwei Wahrheiten.
 */
export async function createEvent(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string|null,input:Record<string,unknown>){
  manager(auth,courseId??undefined);
  const t=pruefeTermin(input);
  const periode=clean(input.period_id,120)||String((await currentPeriod(env,tenantId,t.starts_at))?.id||'')||null;
  const eid=id('trm_'),ts=nowIso();
  const anweisungen=[env.DB.prepare('INSERT INTO schedule_events(id,tenant_id,period_id,course_id,art,titel,starts_at,ends_at,raum,quelle,quelle_ref,anwesenheit_erwartet,status,notiz,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(eid,tenantId,periode,courseId,t.art,t.titel,t.starts_at,t.ends_at,t.raum,t.quelle,t.quelle_ref,t.anwesenheit_erwartet?1:0,clean(input.status,40)||'geplant',t.notiz,auth.userId,ts,ts)];
  if(t.anwesenheit_erwartet&&courseId)
    anweisungen.push(env.DB.prepare("INSERT INTO attendance_sessions(id,tenant_id,course_id,session_date,starts_at,ends_at,subject,room,status,source,source_ref,created_by,created_at,updated_at,event_id) VALUES(?,?,?,?,?,?,?,?,'planned','schedule',?,?,?,?,?)")
      .bind(id('ats_'),tenantId,courseId,t.starts_at.slice(0,10),t.starts_at,t.ends_at,t.titel,t.raum,eid,auth.userId,ts,ts,eid));
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'schedule.event_created',tenantId,courseId??undefined,'schedule_event',eid,{art:t.art,anwesenheit:t.anwesenheit_erwartet});
  return env.DB.prepare('SELECT * FROM schedule_events WHERE id=?').bind(eid).first();
}

/**
 * Einen Termin verschieben - und alles Abgeleitete mit.
 *
 * DAS ist der Punkt der ganzen Uebung. Bisher verschob eine Planaenderung den Stundenplan, waehrend
 * die Anwesenheitseinheit am alten Tag stehen blieb: das Klassenbuch zeigte Unterricht, den es
 * nicht gab, und am neuen Tag fehlte er. Jetzt haengt beides am selben Objekt.
 */
export async function moveEvent(env:Env,auth:CoreAuthContext,tenantId:string,eventId:string,input:Record<string,unknown>){
  const e=await env.DB.prepare('SELECT * FROM schedule_events WHERE id=? AND tenant_id=?').bind(eventId,tenantId).first<Record<string,unknown>>();
  if(!e)throw new Error('EVENT_NOT_FOUND');
  manager(auth,e.course_id?String(e.course_id):undefined);
  const ab=clean(input.starts_at,40)||String(e.starts_at),bis=clean(input.ends_at,40)||String(e.ends_at);
  if(Number.isNaN(Date.parse(ab))||Number.isNaN(Date.parse(bis))||Date.parse(ab)>=Date.parse(bis))throw new Error('EVENT_TIME_INVALID');
  const raum=input.raum===undefined?e.raum:(clean(input.raum,120)||null);
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare('UPDATE schedule_events SET starts_at=?,ends_at=?,raum=?,status=?,updated_at=? WHERE id=?')
      .bind(ab,bis,raum,clean(input.status,40)||String(e.status),ts,eventId),
    // Die abgeleitete Anwesenheitseinheit zieht mit. Bereits erfasste Anwesenheiten haengen an ihr
    // und bleiben dadurch am richtigen Termin - sie werden nicht angefasst.
    env.DB.prepare('UPDATE attendance_sessions SET session_date=?,starts_at=?,ends_at=?,room=?,updated_at=? WHERE event_id=? AND tenant_id=?')
      .bind(ab.slice(0,10),ab,bis,raum,ts,eventId,tenantId),
    env.DB.prepare('UPDATE exams SET starts_at=?,ends_at=?,room=?,updated_at=? WHERE event_id=? AND tenant_id=?').bind(ab,bis,raum,ts,eventId,tenantId),
    env.DB.prepare('UPDATE appointments SET starts_at=?,ends_at=? WHERE event_id=? AND tenant_id=?').bind(ab,bis,eventId,tenantId),
    env.DB.prepare('UPDATE lessons SET starts_at=?,ends_at=?,room=? WHERE event_id=? AND tenant_id=?').bind(ab,bis,raum,eventId,tenantId),
  ]);
  await audit(env.DB,auth.userId,'schedule.event_moved',tenantId,e.course_id?String(e.course_id):undefined,'schedule_event',eventId,{von:e.starts_at,nach:ab});
  return env.DB.prepare('SELECT * FROM schedule_events WHERE id=?').bind(eventId).first();
}

/** Absagen heisst absagen, nicht loeschen: die Absage ist selbst eine Information. */
export async function cancelEvent(env:Env,auth:CoreAuthContext,tenantId:string,eventId:string,grund?:string){
  const e=await env.DB.prepare('SELECT course_id FROM schedule_events WHERE id=? AND tenant_id=?').bind(eventId,tenantId).first<{course_id:string|null}>();
  if(!e)throw new Error('EVENT_NOT_FOUND');
  manager(auth,e.course_id??undefined);
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE schedule_events SET status='abgesagt',notiz=COALESCE(?,notiz),updated_at=? WHERE id=?").bind(clean(grund,2000)||null,ts,eventId),
    env.DB.prepare("UPDATE attendance_sessions SET status='cancelled',updated_at=? WHERE event_id=? AND tenant_id=?").bind(ts,eventId,tenantId),
  ]);
  await audit(env.DB,auth.userId,'schedule.event_cancelled',tenantId,e.course_id??undefined,'schedule_event',eventId);
  return{status:'abgesagt'};
}

/**
 * Der Kalender - aus dem Terminobjekt, nicht aus fuenf Tabellen zusammengesucht.
 *
 * Eine Abfrage, unabhaengig davon, wie viele Termine im Zeitraum liegen.
 */
export async function scheduleView(env:Env,auth:CoreAuthContext,tenantId:string,von:string,bis:string,courseId?:string){
  if(courseId)requireCourseAccess(auth,courseId);else requireRole(auth,'class_admin');
  const sql='SELECT e.*,c.name AS kurs,p.name AS periode FROM schedule_events e LEFT JOIN courses c ON c.id=e.course_id LEFT JOIN schedule_periods p ON p.id=e.period_id'
    +' WHERE e.tenant_id=? AND e.starts_at<? AND e.ends_at>?'+(courseId?' AND e.course_id=?':'')+' ORDER BY e.starts_at LIMIT 500';
  const args:unknown[]=courseId?[tenantId,bis,von,courseId]:[tenantId,bis,von];
  return (await env.DB.prepare(sql).bind(...args).all()).results??[];
}

/**
 * Termine mehrfach anlegen - der uebliche Fall, wenn ein Unterricht woechentlich stattfindet.
 *
 * In EINEM Stapel. Ein Schuljahr mit 40 Wochen waere sonst 40 bis 80 Unteranfragen, und mit der
 * abgeleiteten Anwesenheit das Doppelte.
 */
export const MAX_WIEDERHOLUNGEN=200;
export async function createRecurringEvents(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,input:Record<string,unknown>){
  manager(auth,courseId);
  const t=pruefeTermin(input);
  const anzahl=Math.trunc(Number(input.wiederholungen??1)),abstandTage=Math.trunc(Number(input.abstand_tage??7));
  if(!Number.isFinite(anzahl)||anzahl<1||anzahl>MAX_WIEDERHOLUNGEN)throw new Error('EVENT_REPEAT_INVALID');
  if(!Number.isFinite(abstandTage)||abstandTage<1||abstandTage>366)throw new Error('EVENT_REPEAT_INVALID');
  const gruppe=id('wdh_'),ts=nowIso();
  const anweisungen:unknown[]=[];
  const kennungen:string[]=[];
  for(let i=0;i<anzahl;i++){
    const ab=new Date(Date.parse(t.starts_at)+i*abstandTage*86400000).toISOString();
    const bis=new Date(Date.parse(t.ends_at)+i*abstandTage*86400000).toISOString();
    const periode=String((await currentPeriod(env,tenantId,ab))?.id||'')||null;
    const eid=id('trm_');kennungen.push(eid);
    anweisungen.push(env.DB.prepare('INSERT INTO schedule_events(id,tenant_id,period_id,course_id,art,titel,starts_at,ends_at,raum,quelle,quelle_ref,anwesenheit_erwartet,status,notiz,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,\'wiederholung\',?,?,\'geplant\',?,?,?,?)')
      .bind(eid,tenantId,periode,courseId,t.art,t.titel,ab,bis,t.raum,gruppe,t.anwesenheit_erwartet?1:0,t.notiz,auth.userId,ts,ts));
    if(t.anwesenheit_erwartet)
      anweisungen.push(env.DB.prepare("INSERT INTO attendance_sessions(id,tenant_id,course_id,session_date,starts_at,ends_at,subject,room,status,source,source_ref,created_by,created_at,updated_at,event_id) VALUES(?,?,?,?,?,?,?,?,'planned','schedule',?,?,?,?,?)")
        .bind(id('ats_'),tenantId,courseId,ab.slice(0,10),ab,bis,t.titel,t.raum,eid,auth.userId,ts,ts,eid));
  }
  await env.DB.batch(anweisungen as never[]);
  await audit(env.DB,auth.userId,'schedule.events_recurring',tenantId,courseId,'schedule_event',gruppe,{anzahl,abstand_tage:abstandTage});
  return{gruppe,anzahl:kennungen.length,ids:kennungen};
}

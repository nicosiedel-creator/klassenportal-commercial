import type { Env } from './types.js';
import { resolveCoreAuth } from './auth.js';
import { assertTenantWriteAllowed } from './commerce-offers.js';
import { cancelReceivable, exportBookingCsv, getBillingSettings, listFeePlans, listOpenItems,
  listSepaMandates, receivableDetail, recordReceivablePayment, revokeSepaMandate, runDunning,
  runReceivableBilling, saveBillingSettings, saveFeePlan, saveSepaMandate, setFeePlanStatus } from './participant-receivables.js';
import { assertSameOrigin, authStatus, json, safeErrorCode } from './utils.js';
import { contentDisposition } from '../portability/utils.js';

// /api/receivables - der Debitorenprozess des Traegers gegenueber seinen Teilnehmenden.
//
// Bewusst nicht unter /api/payments/: dort haengt der eingefrorene Zahlungsverkehr. Dieser Bereich
// erfasst Mandate, stellt Forderungen, fuehrt Fristen und Mahnstufen und gibt eine Buchungsdatei
// aus. Er zieht nichts ein, erzeugt keine SEPA-XML und kennt weder Bank noch Zahlungsdienstleister;
// ein Zahlungseingang ist der Vermerk ueber einen Vorgang ausserhalb des Portals.

async function body(request:Request):Promise<Record<string,unknown>>{try{return await request.json() as Record<string,unknown>;}catch{return{};}}

// Ein Zustand, der die Handlung gerade nicht zulaesst, ist kein Serverfehler und keine falsche
// Eingabe: die Forderung ist storniert oder ausgeglichen, das Mandat laengst widerrufen, die
// Mahnstufe schon erteilt. Die Oberflaeche muss den Stand neu laden statt die Eingabe zu bemaengeln.
const KONFLIKT=new Set(['RECEIVABLE_NOT_OPEN','RECEIVABLE_FROZEN','RECEIVABLE_PAYMENT_EXCEEDS_OPEN',
  'SEPA_MANDATE_REFERENCE_EXISTS','SEPA_MANDATE_ALREADY_REVOKED','DUNNING_LEVEL_INVALID',
  'DUNNING_NOTICE_FROZEN','RECEIVABLE_SETTINGS_MISSING']);
function fail(e:unknown){
  const code=safeErrorCode(e);
  const status=authStatus(code)??(code==='UNAUTHENTICATED'?401
    :code.startsWith('FORBIDDEN')?403
    :code.includes('NOT_FOUND')?404
    :KONFLIKT.has(code)?409:400);
  return json({ok:false,error:code},status);
}

export async function handleParticipantReceivablesApi(request:Request,env:Env):Promise<Response|null>{
  const u=new URL(request.url),path=u.pathname;
  if(!path.startsWith('/api/receivables'))return null;
  try{
    assertSameOrigin(request,env.APP_ORIGIN);
    const tenantId=u.searchParams.get('tenant_id')||'';
    if(!tenantId)throw new Error('TENANT_ID_REQUIRED');
    const auth=await resolveCoreAuth(env,request,tenantId);
    if(request.method!=='GET'&&request.method!=='HEAD')await assertTenantWriteAllowed(env,tenantId);

    if(path==='/api/receivables/settings'&&request.method==='GET')
      return json({ok:true,...await getBillingSettings(env,auth,tenantId)});
    if(path==='/api/receivables/settings'&&request.method==='POST')
      return json({ok:true,...await saveBillingSettings(env,auth,tenantId,await body(request))});

    if(path==='/api/receivables/mandates'&&request.method==='GET')
      return json({ok:true,mandates:await listSepaMandates(env,auth,tenantId,u.searchParams.get('user_id')||undefined)});
    if(path==='/api/receivables/mandates'&&request.method==='POST')
      return json({ok:true,...await saveSepaMandate(env,auth,tenantId,await body(request))},201);

    if(path==='/api/receivables/plans'&&request.method==='GET')
      return json({ok:true,plans:await listFeePlans(env,auth,tenantId,{course_id:u.searchParams.get('course_id')||undefined,
        user_id:u.searchParams.get('user_id')||undefined,status:u.searchParams.get('status')||undefined})});
    if(path==='/api/receivables/plans'&&request.method==='POST')
      return json({ok:true,...await saveFeePlan(env,auth,tenantId,await body(request))},201);

    // Zuerst die festen Wege, dann die mit der Kennung: sonst schluckt /items/<id> den Aufruf
    // /items/export und die Verwaltung bekaeme eine Forderung namens "export" gemeldet.
    if(path==='/api/receivables/run'&&request.method==='POST')
      return json({ok:true,...await runReceivableBilling(env,auth,tenantId,await body(request))},201);
    if(path==='/api/receivables/dunning/run'&&request.method==='POST')
      return json({ok:true,...await runDunning(env,auth,tenantId,await body(request))},201);
    if(path==='/api/receivables/items'&&request.method==='GET')
      return json({ok:true,...await listOpenItems(env,auth,tenantId,{as_of:u.searchParams.get('as_of')||undefined,
        course_id:u.searchParams.get('course_id')||undefined,user_id:u.searchParams.get('user_id')||undefined,
        overdue_only:u.searchParams.get('overdue_only')==='1',include_settled:u.searchParams.get('include_settled')==='1'})});
    if(path==='/api/receivables/payments'&&request.method==='POST')
      return json({ok:true,...await recordReceivablePayment(env,auth,tenantId,await body(request))},201);

    // Der Buchungsexport als Datei zum Herunterladen. Ein vorangestelltes BOM, weil Excel eine
    // UTF-8-Datei ohne dieses Zeichen als Westeuropaeisch liest und aus "Mahngebuehr" Buchstabensalat macht.
    if(path==='/api/receivables/export.csv'&&request.method==='GET'){
      const x=await exportBookingCsv(env,auth,tenantId,{from:u.searchParams.get('from')||'',to:u.searchParams.get('to')||''});
      return new Response('\uFEFF'+x.content,{headers:{'content-type':'text/csv; charset=utf-8',
        'content-disposition':contentDisposition(x.filename),'cache-control':'no-store'}});
    }

    const mandat=path.match(/^\/api\/receivables\/mandates\/([^/]+)\/revoke$/);
    if(mandat&&request.method==='POST')
      return json({ok:true,...await revokeSepaMandate(env,auth,tenantId,decodeURIComponent(mandat[1]),(await body(request)).revoked_on)});
    const planStatus=path.match(/^\/api\/receivables\/plans\/([^/]+)\/status$/);
    if(planStatus&&request.method==='POST')
      return json({ok:true,...await setFeePlanStatus(env,auth,tenantId,decodeURIComponent(planStatus[1]),(await body(request)).status)});
    const storno=path.match(/^\/api\/receivables\/items\/([^/]+)\/cancel$/);
    if(storno&&request.method==='POST')
      return json({ok:true,...await cancelReceivable(env,auth,tenantId,decodeURIComponent(storno[1]),await body(request))});
    const posten=path.match(/^\/api\/receivables\/items\/([^/]+)$/);
    if(posten&&request.method==='GET')
      return json({ok:true,...await receivableDetail(env,auth,tenantId,decodeURIComponent(posten[1]))});

    return json({ok:false,error:'NOT_FOUND'},404);
  }catch(e){return fail(e);}
}

// Foerderfaelle und die monatliche Meldung an den Kostentraeger.
//
// Wer eine Massnahme bezahlt - Agentur fuer Arbeit, Jobcenter, Rentenversicherung, ein Betrieb -,
// will monatlich wissen: wer war da, wer hat gefehlt, wer ist gegangen und warum. Das ist der Kern
// jeder Traegerabrechnung, und es war die Arbeit, die im Portal bisher NICHT stattfand: es kannte
// Mitgliedschaften, aber keinen Foerderfall.
//
// Was dieses Modul ausdruecklich NICHT tut: es erzeugt keine eM@w-Datei und keine XBildung-Nachricht.
// Beide Verfahren brauchen eine Spezifikation und einen Vertrag mit der Stelle, an die gemeldet
// wird; ohne die echte Schnittstellenbeschreibung waere jede erzeugte Datei geraten, und ein Test
// darauf wuerde nur beweisen, dass der Code tut was er tut. Was hier entsteht, ist die INHALTLICHE
// Grundlage jeder solchen Meldung - aus den Daten, die das Portal ohnehin fuehrt. Kommt die
// Spezifikation, ist die Datei daraus eine Formatfrage und keine Datenfrage mehr.
import type { CoreAuthContext, Env } from './types.js';
import { requireRole, requireCourseAccess } from './permissions.js';
import { audit } from './audit.js';
import { id, nowIso, safeString } from './utils.js';

export const KOSTENTRAEGER = ['agentur_fuer_arbeit','jobcenter','rentenversicherung','berufsgenossenschaft','betrieb','land','selbstzahler','sonstige'] as const;
export const AUSTRITTSGRUENDE = ['regulaer','abbruch_teilnehmer','abbruch_traeger','arbeitsaufnahme','krankheit','umzug','sonstige'] as const;

const DATUM = /^\d{4}-\d{2}-\d{2}$/;
function datum(wert: unknown, feld: string, pflicht = false): string | null {
  const s = safeString(wert, 10);
  if (!s) { if (pflicht) throw new Error(`FUNDING_${feld}_REQUIRED`); return null; }
  if (!DATUM.test(s)) throw new Error(`FUNDING_${feld}_INVALID`);
  return s;
}

export async function listFundingCases(env: Env, auth: CoreAuthContext, tenantId: string, courseId: string) {
  requireRole(auth, 'class_admin'); requireCourseAccess(auth, courseId);
  return ((await env.DB.prepare(
    `SELECT f.*,u.display_name,u.email FROM participant_funding_cases f JOIN users u ON u.id=f.user_id
      WHERE f.tenant_id=? AND f.course_id=? ORDER BY f.status,u.display_name`
  ).bind(tenantId, courseId).all<Record<string, unknown>>()).results) ?? [];
}

export async function saveFundingCase(env: Env, auth: CoreAuthContext, tenantId: string, courseId: string, input: Record<string, unknown>) {
  requireRole(auth, 'class_admin'); requireCourseAccess(auth, courseId);
  const userId = safeString(input.user_id, 120);
  if (!userId) throw new Error('FUNDING_PARTICIPANT_REQUIRED');
  const traeger = String(input.cost_bearer || '');
  if (!(KOSTENTRAEGER as readonly string[]).includes(traeger)) throw new Error('FUNDING_COST_BEARER_INVALID');
  // Die Person muss wirklich in diesem Kurs sein. Ein Foerderfall fuer jemanden, der nicht
  // teilnimmt, waere eine Abrechnung ohne Leistung.
  const drin = await env.DB.prepare("SELECT 1 ok FROM memberships WHERE tenant_id=? AND course_id=? AND user_id=? AND role='participant'").bind(tenantId, courseId, userId).first();
  if (!drin) throw new Error('FUNDING_PARTICIPANT_NOT_IN_COURSE');

  const eintritt = datum(input.entered_on, 'ENTRY_DATE', true)!;
  const geplant = datum(input.planned_exit_on, 'PLANNED_EXIT');
  const austritt = datum(input.exited_on, 'EXIT_DATE');
  const grund = input.exit_reason ? String(input.exit_reason) : null;
  if (grund && !(AUSTRITTSGRUENDE as readonly string[]).includes(grund)) throw new Error('FUNDING_EXIT_REASON_INVALID');
  // Ein Austritt ohne Grund ist fuer den Kostentraeger wertlos - er entscheidet ueber die
  // Abrechnung des angefangenen Monats.
  if (austritt && !grund) throw new Error('FUNDING_EXIT_REASON_REQUIRED');
  if (grund && !austritt) throw new Error('FUNDING_EXIT_DATE_REQUIRED');
  if (geplant && geplant < eintritt) throw new Error('FUNDING_PLANNED_EXIT_INVALID');
  if (austritt && austritt < eintritt) throw new Error('FUNDING_EXIT_DATE_INVALID');

  const status = austritt ? (grund === 'regulaer' ? 'beendet' : 'abgebrochen') : 'aktiv';
  const vorhanden = safeString(input.id, 120);
  const ts = nowIso();
  if (vorhanden) {
    const r = await env.DB.prepare(
      `UPDATE participant_funding_cases SET cost_bearer=?,cost_bearer_name=?,case_number=?,voucher_number=?,measure_number=?,
        entered_on=?,planned_exit_on=?,exited_on=?,exit_reason=?,exit_note=?,status=?,updated_at=? WHERE tenant_id=? AND course_id=? AND id=?`
    ).bind(traeger, safeString(input.cost_bearer_name, 200) || null, safeString(input.case_number, 60) || null, safeString(input.voucher_number, 60) || null,
      safeString(input.measure_number, 60) || null, eintritt, geplant, austritt, grund, safeString(input.exit_note, 1000) || null, status, ts, tenantId, courseId, vorhanden).run();
    if (!Number(r.meta?.changes || 0)) throw new Error('FUNDING_CASE_NOT_FOUND');
    await audit(env.DB, auth.userId, 'funding.case_updated', tenantId, courseId, 'funding_case', vorhanden, { status });
    return { id: vorhanden, status };
  }
  const neu = id('fnd_');
  await env.DB.prepare(
    `INSERT INTO participant_funding_cases (id,tenant_id,course_id,user_id,cost_bearer,cost_bearer_name,case_number,voucher_number,measure_number,
      entered_on,planned_exit_on,exited_on,exit_reason,exit_note,status,created_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  ).bind(neu, tenantId, courseId, userId, traeger, safeString(input.cost_bearer_name, 200) || null, safeString(input.case_number, 60) || null,
    safeString(input.voucher_number, 60) || null, safeString(input.measure_number, 60) || null, eintritt, geplant, austritt, grund,
    safeString(input.exit_note, 1000) || null, status, auth.userId, ts, ts).run();
  await audit(env.DB, auth.userId, 'funding.case_created', tenantId, courseId, 'funding_case', neu, { cost_bearer: traeger });
  return { id: neu, status };
}

function monatsgrenzen(monat: string): { von: string; bis: string } {
  if (!/^\d{4}-\d{2}$/.test(monat)) throw new Error('FUNDING_MONTH_INVALID');
  const [j, m] = monat.split('-').map(Number);
  const letzter = new Date(Date.UTC(j, m, 0)).getUTCDate();
  return { von: `${monat}-01`, bis: `${monat}-${String(letzter).padStart(2, '0')}` };
}

// Die monatliche Meldung. Genau die Zahlen, die jeder Kostentraeger sehen will - und zwar aus der
// tatsaechlich erfassten Anwesenheit, nicht aus einer zweiten, nebenher gepflegten Liste. Eine
// Meldung, die von Hand entsteht, weicht frueher oder spaeter vom Klassenbuch ab; dann steht
// Aussage gegen Aussage, und im Zweifel zahlt der Traeger zurueck.
export async function fundingMonthlyReport(env: Env, auth: CoreAuthContext, tenantId: string, monat: string, filter: { course_id?: string; cost_bearer?: string } = {}) {
  requireRole(auth, 'tenant_admin');
  const { von, bis } = monatsgrenzen(monat);
  const bedingungen = ['f.tenant_id=?'], werte: unknown[] = [tenantId];
  if (filter.course_id) { bedingungen.push('f.course_id=?'); werte.push(filter.course_id); }
  if (filter.cost_bearer) {
    if (!(KOSTENTRAEGER as readonly string[]).includes(filter.cost_bearer)) throw new Error('FUNDING_COST_BEARER_INVALID');
    bedingungen.push('f.cost_bearer=?'); werte.push(filter.cost_bearer);
  }
  // Nur Faelle, die im Monat ueberhaupt liefen: eingetreten vor Monatsende, nicht vor Monatsbeginn
  // ausgetreten.
  bedingungen.push('f.entered_on<=?'); werte.push(bis);
  bedingungen.push('(f.exited_on IS NULL OR f.exited_on>=?)'); werte.push(von);

  // Eine Abfrage fuer alle Faelle des Monats. Die Anwesenheit kommt aus demselben Bestand, aus dem
  // auch das Klassenbuch und das Berichtsheft entstehen.
  const zeilen = ((await env.DB.prepare(
    `SELECT f.id,f.user_id,f.course_id,f.cost_bearer,f.cost_bearer_name,f.case_number,f.voucher_number,f.measure_number,
            f.entered_on,f.planned_exit_on,f.exited_on,f.exit_reason,f.status,u.display_name,c.name course_name,c.code course_code,
            COALESCE(SUM(CASE WHEN ar.status IN ('present','remote_present','late') THEN 1 ELSE 0 END),0) anwesend,
            COALESCE(SUM(CASE WHEN ar.status='excused_absent' THEN 1 ELSE 0 END),0) entschuldigt,
            COALESCE(SUM(CASE WHEN ar.status='unexcused_absent' THEN 1 ELSE 0 END),0) unentschuldigt,
            COALESCE(SUM(ar.minutes_late),0) verspaetung_minuten,
            COUNT(ar.session_id) erfasst
       FROM participant_funding_cases f
       JOIN users u ON u.id=f.user_id
       JOIN courses c ON c.id=f.course_id
       LEFT JOIN attendance_sessions s ON s.tenant_id=f.tenant_id AND s.course_id=f.course_id AND s.status='held'
            AND s.session_date BETWEEN ? AND ? AND s.session_date>=f.entered_on AND (f.exited_on IS NULL OR s.session_date<=f.exited_on)
       LEFT JOIN attendance_records ar ON ar.session_id=s.id AND ar.user_id=f.user_id AND ar.status<>'not_recorded'
      WHERE ${bedingungen.join(' AND ')}
      GROUP BY f.id ORDER BY c.name,u.display_name`
  ).bind(von, bis, ...werte).all<Record<string, unknown>>()).results) ?? [];

  const summe = zeilen.reduce((n: {anwesend:number;entschuldigt:number;unentschuldigt:number}, z) => ({
    anwesend: n.anwesend + Number(z.anwesend || 0),
    entschuldigt: n.entschuldigt + Number(z.entschuldigt || 0),
    unentschuldigt: n.unentschuldigt + Number(z.unentschuldigt || 0),
  }), { anwesend: 0, entschuldigt: 0, unentschuldigt: 0 });

  return {
    monat, von, bis,
    faelle: zeilen.map(z => ({
      ...z,
      // Eintritte und Austritte IN diesem Monat sind das, was eine Meldung besonders auszeichnen
      // muss: fuer sie wird anteilig abgerechnet.
      eintritt_im_monat: String(z.entered_on) >= von && String(z.entered_on) <= bis,
      austritt_im_monat: !!z.exited_on && String(z.exited_on) >= von && String(z.exited_on) <= bis,
    })),
    anzahl: zeilen.length,
    summe,
    // Ehrlich benannt: was hier fehlt, ist das Dateiformat - nicht der Inhalt.
    hinweis: 'Inhaltliche Grundlage einer Kostenträgermeldung. Das Dateiformat einer konkreten Schnittstelle (zum Beispiel eM@w) setzt die jeweilige Schnittstellenbeschreibung und den Vertrag mit der meldenden Stelle voraus.',
  };
}

import type { Env } from './types.js';
import { resolveCoreAuth } from './auth.js';
import { assertTenantWriteAllowed } from './commerce-offers.js';
import { createFeeCollection, deleteFeePayment, feeCollectionDetail, listFeeCollections, recordFeePayment, setFeeCollectionStatus } from './course-fees.js';
import { assertSameOrigin, authStatus, json, safeErrorCode } from './utils.js';

// /api/course-fees - Kleinbetraege der Klassenkasse. Bewusst nicht unter /api/payments/: dort
// haengt der eingefrorene Zahlungsverkehr, dieser Bereich loest nie eine Zahlung aus.

async function body(request:Request):Promise<Record<string,unknown>>{try{return await request.json() as Record<string,unknown>;}catch{return{};}}

// Ein zu hoher oder ein den Anteil uebersteigender Betrag ist kein Serverfehler, sondern eine
// Eingabe, die der Mensch am Bildschirm selbst korrigieren kann.
const KONFLIKT=new Set(['FEE_PAYMENT_EXCEEDS_SHARE','FEE_COLLECTION_NOT_OPEN','FEE_NO_PARTICIPANTS']);
function fail(e:unknown){
  const code=safeErrorCode(e);
  const status=authStatus(code)??(code==='UNAUTHENTICATED'?401
    :code.startsWith('FORBIDDEN')?403
    :code.includes('NOT_FOUND')?404
    :KONFLIKT.has(code)?409:400);
  return json({ok:false,error:code},status);
}

export async function handleCourseFeesApi(request:Request,env:Env):Promise<Response|null>{
  const u=new URL(request.url),path=u.pathname;
  if(!path.startsWith('/api/course-fees'))return null;
  try{
    assertSameOrigin(request,env.APP_ORIGIN);
    const tenantId=u.searchParams.get('tenant_id')||'';
    if(!tenantId)throw new Error('TENANT_ID_REQUIRED');
    const courseId=u.searchParams.get('course_id')||undefined;
    const auth=await resolveCoreAuth(env,request,tenantId,courseId);
    if(request.method!=='GET'&&request.method!=='HEAD')await assertTenantWriteAllowed(env,tenantId);

    if(path==='/api/course-fees'&&request.method==='GET')
      return json({ok:true,collections:await listFeeCollections(env,auth,tenantId,courseId)});
    if(path==='/api/course-fees'&&request.method==='POST'){
      const b=await body(request);
      return json({ok:true,...await createFeeCollection(env,auth,tenantId,{...b,course_id:b.course_id||courseId})},201);
    }
    // Zuerst die laengere Form pruefen: sonst schluckt /api/course-fees/<id> den Pfad
    // /api/course-fees/payments/<id> nicht - aber die Reihenfolge bleibt der Lesbarkeit halber gleich.
    const zahlungWeg=path.match(/^\/api\/course-fees\/payments\/([^/]+)$/);
    if(zahlungWeg&&request.method==='DELETE')
      return json({ok:true,...await deleteFeePayment(env,auth,tenantId,decodeURIComponent(zahlungWeg[1]))});
    const zahlung=path.match(/^\/api\/course-fees\/([^/]+)\/payments$/);
    if(zahlung&&request.method==='POST')
      return json({ok:true,...await recordFeePayment(env,auth,tenantId,decodeURIComponent(zahlung[1]),await body(request))},201);
    const sammlung=path.match(/^\/api\/course-fees\/([^/]+)$/);
    if(sammlung&&request.method==='GET')
      return json({ok:true,...await feeCollectionDetail(env,auth,tenantId,decodeURIComponent(sammlung[1]))});
    if(sammlung&&request.method==='PATCH')
      return json({ok:true,...await setFeeCollectionStatus(env,auth,tenantId,decodeURIComponent(sammlung[1]),await body(request))});

    return json({ok:false,error:'NOT_FOUND'},404);
  }catch(e){return fail(e);}
}

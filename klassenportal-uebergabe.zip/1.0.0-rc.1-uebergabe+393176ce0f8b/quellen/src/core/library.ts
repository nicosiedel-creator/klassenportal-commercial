import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Bibliothek und Medienausleihe.
//
// Die Ausleihe selbst ist einfach. Zwei Stellen sind es nicht:
//
//  1. DIE VORMERKUNG. Wer seit drei Wochen wartet, bekommt das zurueckgegebene Exemplar - nicht
//     der Naechste, der zufaellig am Tresen steht. Und eine Verlaengerung geht nur, solange
//     niemand wartet; sonst ist die Vormerkung eine Zusage, die nie eintritt.
//  2. WER WAS GELESEN HAT. Das ist eine der empfindlichsten Angaben, die eine Einrichtung ueber
//     einen Menschen fuehren kann - in oeffentlichen Bibliotheken ist die Loeschung nach
//     Rueckgabe seit Jahrzehnten Standard, in Schulverwaltungen fast nie. Deshalb: sobald eine
//     Ausleihe abgeschlossen ist und nichts mehr offen steht, wird die Person aus der Zeile
//     entfernt. Die Zeile bleibt - fuer die Frage, wie oft ein Titel lief. Wer das Buch hatte,
//     beantwortet danach niemand mehr, auch nicht auf Nachfrage.

const clean=(v:unknown,n=2000)=>safeString(v,n);
export const MEDIENARTEN=['buch','zeitschrift','medium','geraet'] as const;

/** Wie oft verlaengert werden darf, bevor ein Titel zurueck in den Bestand muss. */
export const MAX_VERLAENGERUNGEN=2;
/** Wie lange ein bereitgelegtes Exemplar auf seine Vormerkerin wartet. */
export const ABHOLFRIST_TAGE=7;

const tagAus=(iso:string)=>iso.slice(0,10);
const plusTage=(tag:string,n:number)=>new Date(Date.parse(`${tag}T00:00:00.000Z`)+n*86400000).toISOString().slice(0,10);
const istTag=(v:unknown)=>/^\d{4}-\d{2}-\d{2}$/.test(String(v??''));
const heuteOder=(v:unknown)=>istTag(v)?String(v):tagAus(nowIso());

export async function erfasseTitel(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const titel=clean(input.titel,300);
  if(!titel)throw new Error('BIBLIOTHEK_TITEL_ERFORDERLICH');
  const art=clean(input.art,20)||'buch';
  if(!(MEDIENARTEN as readonly string[]).includes(art))throw new Error('BIBLIOTHEK_ART_UNGUELTIG');
  const dauer=input.leihdauer_tage==null?28:Math.round(Number(input.leihdauer_tage)||0);
  if(!(dauer>0&&dauer<=365))throw new Error('BIBLIOTHEK_LEIHDAUER_UNGUELTIG');
  const titleId=id('bibt_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO library_titles(id,tenant_id,titel,urheber,isbn,jahr,signatur,art,leihdauer_tage,
      erfasst_von,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(titleId,tenantId,titel,clean(input.urheber,200)||null,clean(input.isbn,40)||null,
      input.jahr==null?null:Math.round(Number(input.jahr)||0),clean(input.signatur,80)||null,art,dauer,auth.userId,ts,ts).run();
  return{id:titleId,titel,leihdauer_tage:dauer};
}

export async function legeExemplarAn(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const titleId=clean(input.title_id,120);
  const t=await env.DB.prepare('SELECT 1 x FROM library_titles WHERE id=? AND tenant_id=?').bind(titleId,tenantId).first();
  if(!t)throw new Error('BIBLIOTHEK_TITEL_NICHT_GEFUNDEN');
  const nummer=clean(input.exemplarnummer,80);
  if(!nummer)throw new Error('BIBLIOTHEK_EXEMPLARNUMMER_ERFORDERLICH');
  if(await env.DB.prepare('SELECT 1 x FROM library_copies WHERE tenant_id=? AND exemplarnummer=?').bind(tenantId,nummer).first())
    throw new Error('BIBLIOTHEK_EXEMPLARNUMMER_VERGEBEN');
  const copyId=id('bibe_'),ts=nowIso();
  await env.DB.prepare("INSERT INTO library_copies(id,tenant_id,title_id,exemplarnummer,status,created_at,updated_at) VALUES(?,?,?,?,'verfuegbar',?,?)")
    .bind(copyId,tenantId,titleId,nummer,ts,ts).run();
  return{id:copyId,exemplarnummer:nummer};
}

/**
 * Verleihen.
 *
 * Bereitgelegte Exemplare gehoeren ihrer Vormerkerin - wer nicht vorgemerkt ist, bekommt sie
 * nicht, auch wenn sie im Regal stehen.
 */
export async function verleihe(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const titleId=clean(input.title_id,120),userId=clean(input.user_id,120);
  const t=await env.DB.prepare('SELECT id,leihdauer_tage FROM library_titles WHERE id=? AND tenant_id=?')
    .bind(titleId,tenantId).first<{id:string;leihdauer_tage:number}>();
  if(!t)throw new Error('BIBLIOTHEK_TITEL_NICHT_GEFUNDEN');
  const gehoertDazu=await env.DB.prepare("SELECT 1 x FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'")
    .bind(tenantId,userId).first();
  if(!gehoertDazu)throw new Error('BIBLIOTHEK_PERSON_NICHT_IM_TRAEGER');
  const heute=heuteOder(input.heute);

  // Zuerst: liegt fuer genau diese Person etwas bereit? Dann ist das ihr Exemplar.
  const bereit=await env.DB.prepare(`SELECT id,bereit_copy_id FROM library_reservations
    WHERE tenant_id=? AND title_id=? AND user_id=? AND status='bereit' AND bereit_copy_id IS NOT NULL LIMIT 1`)
    .bind(tenantId,titleId,userId).first<{id:string;bereit_copy_id:string}>();
  let copyId=bereit?.bereit_copy_id??null;
  if(!copyId){
    // Wartet jemand anderes, ist der Bestand nicht frei - sonst laeuft die Vormerkung leer.
    const fremd=await env.DB.prepare(`SELECT 1 x FROM library_reservations
      WHERE tenant_id=? AND title_id=? AND user_id<>? AND status IN ('offen','bereit') LIMIT 1`)
      .bind(tenantId,titleId,userId).first();
    const frei=await env.DB.prepare("SELECT id FROM library_copies WHERE tenant_id=? AND title_id=? AND status='verfuegbar' ORDER BY exemplarnummer LIMIT 1")
      .bind(tenantId,titleId).first<{id:string}>();
    const liegtBereit=await env.DB.prepare("SELECT 1 x FROM library_copies WHERE tenant_id=? AND title_id=? AND status='bereitgelegt' LIMIT 1")
      .bind(tenantId,titleId).first();
    // Die beiden Faelle sind am Tresen verschieden: nichts da, oder etwas da, das jemand
    // anderem gehoert. Wer beides gleich beantwortet, schickt Menschen zweimal vergeblich hin.
    if(!frei&&!liegtBereit)throw new Error('BIBLIOTHEK_KEIN_EXEMPLAR_FREI');
    if(fremd)throw new Error('BIBLIOTHEK_VORGEMERKT_FUER_ANDERE');
    if(!frei)throw new Error('BIBLIOTHEK_KEIN_EXEMPLAR_FREI');
    copyId=frei.id;
  }
  const faellig=plusTage(heute,Number(t.leihdauer_tage)||28);
  const loanId=id('bibl_'),ts=nowIso();
  const anweisungen=[
    env.DB.prepare("INSERT INTO library_loans(id,tenant_id,copy_id,user_id,ausgeliehen_am,faellig_am,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'offen',?,?)")
      .bind(loanId,tenantId,copyId,userId,heute,faellig,ts,ts),
    env.DB.prepare("UPDATE library_copies SET status='ausgeliehen',updated_at=? WHERE id=? AND tenant_id=?").bind(ts,copyId,tenantId),
  ];
  if(bereit)anweisungen.push(env.DB.prepare("UPDATE library_reservations SET status='abgeholt',updated_at=? WHERE id=? AND tenant_id=?")
    .bind(ts,bereit.id,tenantId));
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'library.loaned',tenantId,undefined,'library_copy',copyId,{});
  return{loan_id:loanId,copy_id:copyId,faellig_am:faellig,aus_vormerkung:Boolean(bereit)};
}

export async function verlaengere(env:Env,auth:CoreAuthContext,tenantId:string,loanId:string,heute?:string){
  requireRole(auth,'class_admin');
  const l=await env.DB.prepare(`SELECT l.*,c.title_id,t.leihdauer_tage FROM library_loans l
    JOIN library_copies c ON c.id=l.copy_id JOIN library_titles t ON t.id=c.title_id
    WHERE l.id=? AND l.tenant_id=? AND l.status='offen'`)
    .bind(clean(loanId,120),tenantId).first<Record<string,unknown>>();
  if(!l)throw new Error('BIBLIOTHEK_AUSLEIHE_NICHT_OFFEN');
  if(Number(l.verlaengerungen)>=MAX_VERLAENGERUNGEN)throw new Error('BIBLIOTHEK_VERLAENGERUNG_AUSGESCHOEPFT');
  // Der Punkt, den fast jede selbstgebaute Ausleihe vergisst: eine Verlaengerung nimmt der
  // Person in der Schlange genau das weg, worauf sie wartet.
  const wartet=await env.DB.prepare(`SELECT 1 x FROM library_reservations
    WHERE tenant_id=? AND title_id=? AND user_id<>? AND status IN ('offen','bereit') LIMIT 1`)
    .bind(tenantId,String(l.title_id),String(l.user_id)).first();
  if(wartet)throw new Error('BIBLIOTHEK_VERLAENGERUNG_VORGEMERKT');
  const basis=heuteOder(heute),neu=plusTage(basis>String(l.faellig_am)?basis:String(l.faellig_am),Number(l.leihdauer_tage)||28);
  await env.DB.prepare('UPDATE library_loans SET faellig_am=?,verlaengerungen=verlaengerungen+1,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(neu,nowIso(),String(l.id),tenantId).run();
  return{loan_id:String(l.id),faellig_am:neu,verlaengerungen:Number(l.verlaengerungen)+1};
}

export async function merkeVor(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const titleId=clean(input.title_id,120),userId=clean(input.user_id,120);
  if(!await env.DB.prepare('SELECT 1 x FROM library_titles WHERE id=? AND tenant_id=?').bind(titleId,tenantId).first())
    throw new Error('BIBLIOTHEK_TITEL_NICHT_GEFUNDEN');
  if(await env.DB.prepare("SELECT 1 x FROM library_reservations WHERE tenant_id=? AND title_id=? AND user_id=? AND status IN ('offen','bereit')")
    .bind(tenantId,titleId,userId).first())throw new Error('BIBLIOTHEK_BEREITS_VORGEMERKT');
  const resId=id('bibv_'),ts=nowIso();
  await env.DB.prepare("INSERT INTO library_reservations(id,tenant_id,title_id,user_id,vorgemerkt_am,status,created_at,updated_at) VALUES(?,?,?,?,?,'offen',?,?)")
    .bind(resId,tenantId,titleId,userId,ts,ts,ts).run();
  const platz=await env.DB.prepare("SELECT COUNT(*) n FROM library_reservations WHERE tenant_id=? AND title_id=? AND status IN ('offen','bereit') AND vorgemerkt_am<=?")
    .bind(tenantId,titleId,ts).first<{n:number}>();
  return{id:resId,platz:Number(platz?.n??1)};
}

/**
 * Rueckgabe.
 *
 * Zwei Dinge passieren hier zusammen, und die Reihenfolge ist keine Geschmacksfrage: das
 * Exemplar geht an die erste wartende Person, und die Person verschwindet aus der
 * abgeschlossenen Ausleihe.
 */
export async function nimmZurueck(env:Env,auth:CoreAuthContext,tenantId:string,loanId:string,heute?:string){
  requireRole(auth,'class_admin');
  const l=await env.DB.prepare(`SELECT l.*,c.title_id FROM library_loans l JOIN library_copies c ON c.id=l.copy_id
    WHERE l.id=? AND l.tenant_id=? AND l.status='offen'`)
    .bind(clean(loanId,120),tenantId).first<Record<string,unknown>>();
  if(!l)throw new Error('BIBLIOTHEK_AUSLEIHE_NICHT_OFFEN');
  const tag=heuteOder(heute),ts=nowIso();
  // Die erste in der Schlange, nach Zeitpunkt der Vormerkung - nicht nach Zufall.
  //
  // Der zweite Sortierschluessel ist rowid und nicht id: zwei Vormerkungen koennen in dieselbe
  // Millisekunde fallen, und id ist eine Zufallskennung. Dann haette das Los entschieden, wer
  // seit drei Wochen wartet - selten, aber genau unter Andrang, wo es auffaellt. rowid ist die
  // Reihenfolge des Eintragens und damit die Reihenfolge, in der die Menschen da waren.
  const naechste=await env.DB.prepare(`SELECT id,user_id FROM library_reservations
    WHERE tenant_id=? AND title_id=? AND status='offen' ORDER BY vorgemerkt_am,rowid LIMIT 1`)
    .bind(tenantId,String(l.title_id)).first<{id:string;user_id:string}>();
  const anweisungen=[
    // user_id=NULL: wer was gelesen hat, beantwortet nach dem Abschluss niemand mehr.
    env.DB.prepare("UPDATE library_loans SET status='zurueck',zurueck_am=?,user_id=NULL,mahnstufe=0,updated_at=? WHERE id=? AND tenant_id=?")
      .bind(tag,ts,String(l.id),tenantId),
    env.DB.prepare('UPDATE library_copies SET status=?,updated_at=? WHERE id=? AND tenant_id=?')
      .bind(naechste?'bereitgelegt':'verfuegbar',ts,String(l.copy_id),tenantId),
  ];
  if(naechste)anweisungen.push(env.DB.prepare("UPDATE library_reservations SET status='bereit',bereit_copy_id=?,bereit_bis=?,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(String(l.copy_id),plusTage(tag,ABHOLFRIST_TAGE),ts,naechste.id,tenantId));
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'library.returned',tenantId,undefined,'library_copy',String(l.copy_id),{});
  return{loan_id:String(l.id),bereitgelegt_fuer:naechste?naechste.user_id:null};
}

export async function meldeVerlust(env:Env,auth:CoreAuthContext,tenantId:string,loanId:string,grund:string){
  requireRole(auth,'tenant_admin');
  const l=await env.DB.prepare("SELECT * FROM library_loans WHERE id=? AND tenant_id=? AND status='offen'")
    .bind(clean(loanId,120),tenantId).first<Record<string,unknown>>();
  if(!l)throw new Error('BIBLIOTHEK_AUSLEIHE_NICHT_OFFEN');
  const text=clean(grund,2000);
  if(text.length<5)throw new Error('BIBLIOTHEK_VERLUSTGRUND_ERFORDERLICH');
  const ts=nowIso();
  // Hier bleibt die Person stehen. Ein Verlust ist eine offene Forderung, und eine Forderung
  // ohne Schuldner ist keine.
  await env.DB.batch([
    env.DB.prepare("UPDATE library_loans SET status='verloren',updated_at=? WHERE id=? AND tenant_id=?").bind(ts,String(l.id),tenantId),
    env.DB.prepare("UPDATE library_copies SET status='vermisst',updated_at=? WHERE id=? AND tenant_id=?").bind(ts,String(l.copy_id),tenantId),
  ]);
  return{loan_id:String(l.id),status:'verloren'};
}

/**
 * Ueberfaellige finden und mahnen - ein Lauf, kein Rundschreiben.
 *
 * Die Mahnstufe steigt hoechstens einmal je Lauf und hoechstens bis drei; danach ist es ein Fall
 * fuer einen Menschen, nicht fuer die naechste automatische Stufe.
 */
export async function mahneUeberfaellige(env:Env,auth:CoreAuthContext,tenantId:string,heute?:string){
  requireRole(auth,'class_admin');
  const tag=heuteOder(heute),ts=nowIso();
  const faellig=((await env.DB.prepare(`SELECT id,user_id,mahnstufe,faellig_am FROM library_loans
    WHERE tenant_id=? AND status='offen' AND faellig_am<? AND mahnstufe<3
      AND (gemahnt_am IS NULL OR gemahnt_am<?) ORDER BY faellig_am LIMIT 500`)
    .bind(tenantId,tag,tag).all<Record<string,unknown>>()).results)??[];
  if(!faellig.length)return{gemahnt:0,offen:[]};
  const anweisungen=faellig.map(f=>env.DB.prepare('UPDATE library_loans SET mahnstufe=mahnstufe+1,gemahnt_am=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(tag,ts,String(f.id),tenantId));
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  return{gemahnt:faellig.length,offen:faellig.map(f=>({loan_id:String(f.id),user_id:String(f.user_id),
    stufe:Number(f.mahnstufe)+1,faellig_am:String(f.faellig_am)}))};
}

/** Abgelaufene Bereitlegungen geben das Exemplar wieder frei - an die naechste in der Schlange. */
export async function raeumeAbholfristen(env:Env,auth:CoreAuthContext,tenantId:string,heute?:string){
  requireRole(auth,'class_admin');
  const tag=heuteOder(heute),ts=nowIso();
  const abgelaufen=((await env.DB.prepare(`SELECT id,title_id,bereit_copy_id FROM library_reservations
    WHERE tenant_id=? AND status='bereit' AND bereit_bis IS NOT NULL AND bereit_bis<? ORDER BY bereit_bis LIMIT 200`)
    .bind(tenantId,tag).all<{id:string;title_id:string;bereit_copy_id:string}>()).results)??[];
  if(!abgelaufen.length)return{abgelaufen:0};
  const anweisungen=[];
  for(const r of abgelaufen){
    anweisungen.push(env.DB.prepare("UPDATE library_reservations SET status='abgelaufen',bereit_copy_id=NULL,updated_at=? WHERE id=? AND tenant_id=?")
      .bind(ts,r.id,tenantId));
    const naechste=await env.DB.prepare(`SELECT id FROM library_reservations WHERE tenant_id=? AND title_id=? AND status='offen'
      AND id<>? ORDER BY vorgemerkt_am,rowid LIMIT 1`).bind(tenantId,r.title_id,r.id).first<{id:string}>();
    if(naechste)anweisungen.push(env.DB.prepare("UPDATE library_reservations SET status='bereit',bereit_copy_id=?,bereit_bis=?,updated_at=? WHERE id=? AND tenant_id=?")
      .bind(r.bereit_copy_id,plusTage(tag,ABHOLFRIST_TAGE),ts,naechste.id,tenantId));
    else anweisungen.push(env.DB.prepare("UPDATE library_copies SET status='verfuegbar',updated_at=? WHERE id=? AND tenant_id=?")
      .bind(ts,r.bereit_copy_id,tenantId));
  }
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  return{abgelaufen:abgelaufen.length};
}

export async function bibliotheksstand(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  const [titel,offene,vormerkungen]=await Promise.all([
    env.DB.prepare(`SELECT t.id,t.titel,t.urheber,t.signatur,t.art,
        COUNT(c.id) exemplare,
        SUM(CASE WHEN c.status='verfuegbar' THEN 1 ELSE 0 END) frei
      FROM library_titles t LEFT JOIN library_copies c ON c.title_id=t.id AND c.tenant_id=t.tenant_id
      WHERE t.tenant_id=? GROUP BY t.id ORDER BY t.titel LIMIT 300`).bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare(`SELECT l.id,l.faellig_am,l.mahnstufe,u.display_name,t.titel,c.exemplarnummer
      FROM library_loans l JOIN library_copies c ON c.id=l.copy_id JOIN library_titles t ON t.id=c.title_id
      LEFT JOIN users u ON u.id=l.user_id WHERE l.tenant_id=? AND l.status='offen'
      ORDER BY l.faellig_am LIMIT 300`).bind(tenantId).all<Record<string,unknown>>(),
    env.DB.prepare(`SELECT r.id,r.status,r.bereit_bis,u.display_name,t.titel FROM library_reservations r
      JOIN library_titles t ON t.id=r.title_id JOIN users u ON u.id=r.user_id
      WHERE r.tenant_id=? AND r.status IN ('offen','bereit') ORDER BY r.vorgemerkt_am LIMIT 300`)
      .bind(tenantId).all<Record<string,unknown>>(),
  ]);
  return{titel:titel.results??[],ausleihen:offene.results??[],vormerkungen:vormerkungen.results??[]};
}

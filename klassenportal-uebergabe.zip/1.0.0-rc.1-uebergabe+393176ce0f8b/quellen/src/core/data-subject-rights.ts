import type { CoreAuthContext, Env } from './types.js';
import { requireRole } from './permissions.js';
import { kalteDatenFuerPerson } from './cold-storage.js';

// Artikel 15 DSGVO: eine Person darf erfahren, welche Daten ueber sie verarbeitet werden. Bisher
// konnte dieses System nur einen GANZEN MANDANTEN loeschen - fuer eine einzelne Person gab es
// nichts. Fuer einen oeffentlichen Traeger ist das ein Ausschlusskriterium.
//
// Der Personenbezug steckt in 104 der 254 Tabellen. Eine handgepflegte Liste veraltet mit der
// naechsten Migration, und niemand merkt es: die Auskunft waere dann still unvollstaendig - genau
// der Fehler, den man erst vor Gericht bemerkt. Deshalb wird die Liste gegen das tatsaechliche
// Schema geprueft (siehe unklassifizierteTabellen und den zugehoerigen Test): eine neue Tabelle mit
// Personenspalte MUSS hier eingetragen werden, sonst schlaegt der Test fehl.
//
// Drei Behandlungsarten, weil eine Auskunft zwei Dinge nicht tun darf:
//   voll        - alle Spalten. Der Regelfall.
//   ohne_inhalt - Existenz, Zeitpunkte und Art ja, Inhalt nein. Fuer Sitzungen, Token und
//                 Kennungen: die Person darf wissen, DASS es sie gibt, aber ein ausgeliefertes
//                 Token waere ein Schluessel zu ihrem eigenen Konto.
//   nur_anzahl  - nur die Zahl der Eintraege. Fuer Protokolle, in denen am selben Objekt auch
//                 Handlungen Dritter stehen; eine vollstaendige Ausgabe wuerde fremde
//                 Personendaten mit herausgeben.
export type Behandlung='voll'|'ohne_inhalt'|'nur_anzahl';
export type Eintrag={spalten:string[];art:Behandlung;mandant:boolean;ueber?:Kette};

// Manche Daten benennen die betroffene Person nicht selbst - sie haengen an einer Zeile, die es
// tut. Eine Mahnung nennt nur die Forderung, die Forderung nennt den Schuldner. Wer nur nach
// Personenspalten sucht, findet die Mahnung nie, und die Auskunft sagt "keine Mahnungen", waehrend
// drei im System stehen. Dasselbe gilt fuer die Eintraege im Berichtsheft, die Antworten in einem
// Test und die hochgeladenen Abgabedateien - also fuer genau die Daten, um die es geht.
export type Kette={spalte:string;tabelle:string;fremdspalte?:string};

// Spalten, die niemals hinausgehen - auch nicht bei art:'voll'.
// 'iban_fingerprint_hash' ist der mandantenbezogene Hash der IBAN aus dem SEPA-Mandat. Die volle
// Nummer wird nirgends gespeichert (siehe Migration 0114); der Hash selbst sagt der Person nichts
// und gehoert deshalb auch in ihrer eigenen Auskunft nicht ausgegeben.
export const GEHEIME_SPALTEN=new Set(['password_hash','token_hash','secret','client_secret','private_key','signature','iban_fingerprint_hash']);

export const PERSONENDATEN:Record<string,Eintrag>={
  absence_notices:{spalten:['user_id'],art:'voll',mandant:true},
  account_action_tokens:{spalten:['user_id','created_by'],art:'ohne_inhalt',mandant:false},
  accounting_entries:{spalten:['created_by'],art:'voll',mandant:true},
  // Nachteilsausgleich: die Person, fuer die er gilt, und die Person, die ihn gewaehrt oder
  // widerrufen hat. Die Auskunft gibt den Inhalt voll heraus - es ist die eigene Entscheidung
  // ueber die eigene Pruefung, und wer sie anfechten will, braucht sie.
  exam_accommodations:{spalten:['user_id','granted_by','revoked_by'],art:'voll',mandant:true},
  // Der Einspruch ist die Anfechtung dieser Person und gehoert vollstaendig in ihre Auskunft -
  // einschliesslich der Begruendung des Bescheids, denn genau die wuerde sie vor Gericht brauchen.
  exam_appeals:{spalten:['user_id','entschieden_von'],art:'voll',mandant:true},
  // Die Sorgeverknuepfung fuehrt ZWEI Personen: den Sorgeberechtigten und das Kind. Beide muessen
  // sie in ihrer Auskunft finden - das Kind, weil daraus hervorgeht, wer Einblick in seine Daten
  // hatte, der Elternteil, weil es seine eigene Rechtsstellung ist.
  guardianships:{spalten:['guardian_user_id','participant_user_id','angelegt_von','beendet_von'],art:'voll',mandant:true},
  // Das Raster selbst fuehrt keine Personendaten ausser der anlegenden Lehrkraft.
  grading_rubrics:{spalten:['created_by'],art:'voll',mandant:true},
  // Die Kompetenz selbst beschreibt eine Faehigkeit, keine Person - ausser der anlegenden Lehrkraft.
  competencies:{spalten:['created_by'],art:'voll',mandant:true},
  // Die Variante selbst beschreibt einen Aufgabenbogen, keine Person - ausser der anlegenden Lehrkraft.
  exam_variants:{spalten:['created_by'],art:'voll',mandant:true},
  // Die Periode ist ein Zeitraum des Traegers, keine Angabe ueber eine Person.
  schedule_periods:{spalten:['created_by'],art:'voll',mandant:true},
  // Eine Loeschsperre ist eine Angabe UEBER die betroffene Person - sie erklaert, warum ihre
  // Daten trotz Frist noch da sind. Sie gehoert deshalb in ihre Auskunft.
  // Betriebstabellen: sie fuehren keine Daten UEBER eine Person, wohl aber die Kennung dessen,
  // der die Einstellung vorgenommen hat. Das ist eine Angabe ueber Beschaeftigte und gehoert
  // deshalb in deren Auskunft.
  provider_bindings:{spalten:['created_by'],art:'voll',mandant:true},
  cost_budgets:{spalten:['created_by'],art:'voll',mandant:true},
  legal_holds:{spalten:['verhaengt_von','aufgehoben_von'],art:'voll',mandant:true},
  // Wer eine Wiederherstellung ausgeloest hat, steht drin - der Lauf selbst ist ein Betriebsvorgang,
  // kein Datenbestand ueber die Person. Die Auskunft gibt ihn voll heraus; er enthaelt nur Zahlen.
  restore_runs:{spalten:['ausgeloest_von'],art:'voll',mandant:true},
  // Die Sperre nennt DREI Personen: die geschuetzte, die ausgeschlossene und die anordnende. Alle
  // drei muessen sie in ihrer Auskunft finden - die geschuetzte, weil es ihr Schutz ist, die
  // ausgeschlossene, weil es ihr Recht beschneidet.
  access_restrictions:{spalten:['betroffene_person','gegen_user_id','angelegt_von','aufgehoben_von'],art:'voll',mandant:true},
  // Die Freigabe nennt das Supportkonto und die Person, die sie erteilt hat. Fuer den Mandanten-
  // Admin ist sie die Auskunft darueber, wem er wann Einblick gegeben hat - das gehoert ihm.
  support_access_grants:{spalten:['support_user_id','erteilt_von','widerrufen_von'],art:'voll',mandant:true},
  // Eine Kinderschutzmeldung nennt die betroffene Person, die meldende und die bearbeitende. Sie
  // geht NUR als Anzahl heraus: der Sachverhalt beschreibt regelmaessig Dritte - eine Vollauskunft
  // an die betroffene Person gaebe preis, wer gemeldet hat, und das ist genau der Grund, aus dem
  // in der Praxis niemand meldet.
  safeguarding_reports:{spalten:['betroffene_person','gemeldet_von','zugewiesen_an'],art:'nur_anzahl',mandant:true},
  safeguarding_notes:{spalten:['verfasst_von'],art:'nur_anzahl',mandant:true},
  safeguarding_officers:{spalten:['user_id','benannt_von'],art:'voll',mandant:true},
  // Die Notfallnummer gehoert der Person - sie muss sie in ihrer Auskunft finden.
  emergency_contacts:{spalten:['user_id','erfasst_von'],art:'voll',mandant:true},
  // Wer eine Krisenmeldung bekam und ob er bestaetigt hat: die eigene Zustellung, voll.
  crisis_alert_recipients:{spalten:['user_id'],art:'voll',mandant:true},
  crisis_alerts:{spalten:['ausgeloest_von','beendet_von'],art:'voll',mandant:true},
  // Die eigene Beschwerde gehoert der einreichenden Person vollstaendig. Anonyme Vorgaenge fuehren
  // gar keine Kennung und tauchen in keiner Auskunft auf - das ist der Sinn der Anonymitaet.
  complaints:{spalten:['eingereicht_von','zugewiesen_an'],art:'voll',mandant:true},
  // Im Verlauf steht auch interne Abstimmung ueber Dritte - deshalb nur die Anzahl.
  complaint_notes:{spalten:['verfasst_von'],art:'nur_anzahl',mandant:true},
  // Der Vorfall nennt die meldende und die bewertende Person. Er geht nur als Anzahl heraus: die
  // Beschreibung betrifft regelmaessig ANDERE Betroffene, und eine Vollauskunft an eine von ihnen
  // waere selbst eine Offenlegung.
  privacy_incidents:{spalten:['gemeldet_von','bewertet_von'],art:'nur_anzahl',mandant:true},
  privacy_incident_notes:{spalten:['verfasst_von'],art:'nur_anzahl',mandant:true},
  // Die Beweiskette nennt nur die handelnden Lehrkraefte - der Bogen selbst ist keine Person.
  exam_custody_events:{spalten:['akteur'],art:'voll',mandant:true},
  // Die Unterbrechung gehoert zum Versuch der Person und belegt, dass ihr keine Zeit fehlte.
  exam_interruptions:{spalten:['unterbrochen_von','fortgesetzt_von'],art:'voll',mandant:true},
  // Der Taeuschungsvorwurf gehoert der betroffenen Person VOLLSTAENDIG - genau das ist ihr
  // Anhoerungsrecht. Wer sich aeussern soll, muss den Vorwurf und die Beweise kennen.
  exam_integrity_cases:{spalten:['betroffene_person','eroeffnet_von','entschieden_von'],art:'voll',mandant:true},
  automation_failures:{spalten:['aufgegeben_von'],art:'voll',mandant:true},
  operation_journal:{spalten:['gestartet_von'],art:'voll',mandant:true},
  document_versions:{spalten:['geaendert_von'],art:'voll',mandant:true},
  // Die Fassung eines Rahmens nennt nur, wer sie veroeffentlicht hat - der Rahmen selbst ist keine
  // Angabe ueber eine Person.
  curriculum_framework_versions:{spalten:['created_by','veroeffentlicht_von'],art:'voll',mandant:true},
  // Der Antrag auf Anerkennung gehoert der antragstellenden Person vollstaendig: er enthaelt ihren
  // Bildungsweg, und die Entscheidung darueber ist ein Verwaltungsakt gegen sie.
  prior_learning_claims:{spalten:['user_id','geprueft_von'],art:'voll',mandant:true},
  // Wer wann in welchem Raum geprueft wurde, ist eine Angabe ueber die Person - und der
  // festgeschriebene Zeitzuschlag verraet, dass ein Nachteilsausgleich bewilligt war.
  exam_sitting_seats:{spalten:['user_id'],art:'voll',mandant:true},
  // Die Aufsicht ist eine Dienstzuteilung - fuer die eingeteilte Person eine Angabe ueber sie.
  exam_supervisions:{spalten:['user_id','eingeteilt_von'],art:'voll',mandant:true},
  exam_sittings:{spalten:['created_by','freigegeben_von'],art:'voll',mandant:true},
  // Der Laufbahnvorgang gehoert der Person: er sagt, warum sie gewechselt oder unterbrochen hat.
  enrollment_transitions:{spalten:['user_id','beantragt_von','entschieden_von'],art:'voll',mandant:true},
  learning_plans:{spalten:['user_id','erstellt_von'],art:'voll',mandant:true},
  // Was jemand gemeldet hat, ist eine Angabe ueber ihn - samt Verlauf.
  helpdesk_tickets:{spalten:['melder_user_id','zustaendig_user_id'],art:'voll',mandant:true},
  helpdesk_ticket_events:{spalten:['akteur_user_id'],art:'voll',mandant:true,ueber:{spalte:'ticket_id',tabelle:'helpdesk_tickets'}},
  // Wer an einer Fahrt teilnahm - samt Notfallhinweis, der ein Gesundheitsdatum sein kann.
  excursion_participants:{spalten:['user_id','einverstaendnis_von'],art:'voll',mandant:true},
  excursions:{spalten:['leitung_user_id','created_by','entschieden_von'],art:'voll',mandant:true},
  // Wer eine KI-Auswertung ausgeloest hat und mit welchem Eingabehash - die Eingabe selbst wird
  // bewusst nicht gespeichert.
  ai_invocations:{spalten:['akteur'],art:'voll',mandant:true},
  ai_generated_content:{spalten:['bestaetigt_von'],art:'voll',mandant:true},
  ai_evaluation_runs:{spalten:['gelaufen_von'],art:'voll',mandant:true},
  course_offers:{spalten:['erstellt_von'],art:'voll',mandant:true},
  // Die eM@w-Tabellen fuehren echte Sozialdaten: Kundennummer der BA, Name, Vorname, dazu im
  // Ereignis-XML die Anwesenheit Tag fuer Tag. Sie gehoeren in jede Auskunft.
  emaw_schluessel:{spalten:['user_id'],art:'voll',mandant:true},
  emaw_ereignisse:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'schluessel_id',tabelle:'emaw_schluessel'}},
  emaw_provider:{spalten:['angelegt_von'],art:'voll',mandant:true},
  emaw_archive:{spalten:['gebaut_von'],art:'voll',mandant:true},
  inventory_items:{spalten:['erfasst_von'],art:'voll',mandant:true},
  inventory_issues:{spalten:['user_id','ausgegeben_von'],art:'voll',mandant:true},
  procurement_requests:{spalten:['angefordert_von','freigegeben_von','zweitfreigabe_von'],art:'voll',mandant:true},
  procurement_receipts:{spalten:['erfasst_von'],art:'voll',mandant:true},
  maintenance_tickets:{spalten:['gemeldet_von','behoben_von'],art:'voll',mandant:true},
  library_titles:{spalten:['erfasst_von'],art:'voll',mandant:true},
  // library_loans.user_id ist nach der Rueckgabe leer - genau deshalb steht die Tabelle hier:
  // solange sie belegt ist, gehoert sie in jede Auskunft.
  library_loans:{spalten:['user_id'],art:'voll',mandant:true},
  library_reservations:{spalten:['user_id'],art:'voll',mandant:true},
  course_offer_attachments:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'offer_id',tabelle:'course_offers'}},
  course_contracts:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'offer_id',tabelle:'course_offers'}},
  media_assets:{spalten:['hochgeladen_von'],art:'voll',mandant:true},
  media_usages:{spalten:['eingebunden_von'],art:'voll',mandant:true,ueber:{spalte:'asset_id',tabelle:'media_assets'}},
  media_tracks:{spalten:['geprueft_von'],art:'voll',mandant:true,ueber:{spalte:'asset_id',tabelle:'media_assets'}},
  // Wer eine kritische Betriebsaufgabe wahrnimmt und wann zuletzt geuebt hat.
  operations_duty_holders:{spalten:['user_id'],art:'voll',mandant:true},
  operations_incidents:{spalten:['gemeldet_von'],art:'voll',mandant:true},
  // Plattformweit: eine Aktualisierung betrifft alle Mandanten, die Zeile gehoert keinem.
  operations_releases:{spalten:['created_by','ausgerollt_von'],art:'voll',mandant:false},
  // Ereignisse koennen eine Person nennen (wer es ausgeloest hat) und ueber objekt_id auf sie
  // zeigen; die Zustellzeilen haengen daran.
  domain_events:{spalten:['ausgeloest_von'],art:'voll',mandant:true},
  communication_templates:{spalten:['erstellt_von'],art:'voll',mandant:true},
  ai_content_drafts:{spalten:['erzeugt_von','freigegeben_von'],art:'voll',mandant:true},
  // Der Alumni-Eintrag gehoert der Person: er sagt, dass und wie sie abgeschlossen hat.
  alumni_records:{spalten:['user_id','angelegt_von'],art:'voll',mandant:true},
  residency_policies:{spalten:['festgelegt_von'],art:'voll',mandant:true},
  residency_exceptions:{spalten:['erteilt_von'],art:'voll',mandant:true},
  // Was jemand in die Befehlszeile geschrieben hat, ist eine Angabe ueber ihn.
  command_interpretations:{spalten:['user_id'],art:'voll',mandant:true},
  communication_template_versions:{spalten:['veroeffentlicht_von'],art:'voll',mandant:true,ueber:{spalte:'template_id',tabelle:'communication_templates'}},
  event_deliveries:{spalten:[],art:'nur_anzahl',mandant:true,ueber:{spalte:'event_id',tabelle:'domain_events'}},
  operations_incident_updates:{spalten:['verfasst_von'],art:'voll',mandant:false,ueber:{spalte:'incident_id',tabelle:'operations_incidents'}},
  // Die Schritte haengen am Plan und sagen, was jemand nachzuholen hatte - ohne sie waere die
  // Auskunft ueber den Plan eine leere Huelse.
  learning_plan_steps:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'plan_id',tabelle:'learning_plans'}},
  teaching_rhythm_rules:{spalten:['created_by'],art:'voll',mandant:true},
  timetable_plan_restores:{spalten:['ausgeloest_von'],art:'voll',mandant:true},
  timetable_plan_scores:{spalten:['berechnet_von'],art:'voll',mandant:true},
  retention_policies:{spalten:['created_by'],art:'voll',mandant:true},
  retention_runs:{spalten:['ausgeloest_von'],art:'nur_anzahl',mandant:true},
  consent_definitions:{spalten:['created_by'],art:'voll',mandant:true},
  // Was jemand erklaert hat und wozu - der Kern jeder Auskunft nach Artikel 15.
  consent_records:{spalten:['user_id','erklaert_von'],art:'voll',mandant:true},
  // Richtlinienbestaetigung. Die Richtlinie selbst ist eine Ordnung des Traegers und keine
  // Angabe ueber eine Person - ausser der Kennung dessen, der sie erlassen hat.
  policy_definitions:{spalten:['created_by'],art:'voll',mandant:true},
  // Die Bestaetigung dagegen IST eine Angabe ueber die Person: sie belegt, dass genau sie genau
  // diese Fassung an genau diesem Tag anerkannt hat. Im Streitfall wird sie gegen die Person
  // verwendet - dann muss die Person sie auch in ihrer eigenen Auskunft finden koennen.
  policy_acknowledgements:{spalten:['user_id'],art:'voll',mandant:true},
  // Wiedererkennung wiederholter Schreibversuche. Die Person darf wissen, DASS und WANN etwas
  // unter ihrem Konto gespeichert wurde - der hinterlegte Antwortinhalt bleibt draussen: er
  // gehoert zu einem fachlichen Vorgang (etwa einer ganzen Anwesenheitsliste) und enthielte
  // damit die Daten Dritter, die in einer Einzelauskunft nichts zu suchen haben.
  idempotency_keys:{spalten:['user_id'],art:'ohne_inhalt',mandant:true},
  // Der Termin sagt, wann eine Gruppe zusammenkommt - personenbezogen wird er erst ueber die
  // Anwesenheit, die an ihm haengt. Die anlegende Person steht darin.
  schedule_events:{spalten:['created_by'],art:'voll',mandant:true},
  // WELCHEN Bogen eine Person bekommen hat, ist eine Angabe ueber sie: bei einem Einspruch ist es
  // die Frage, welche Aufgaben sie ueberhaupt vor sich hatte.
  exam_variant_assignments:{spalten:['user_id','zugewiesen_von'],art:'voll',mandant:true},
  competency_links:{spalten:['verknuepft_von'],art:'nur_anzahl',mandant:true},
  // Die ausgefuellte Rasterbewertung ist die Begruendung der Note dieser Person - und die
  // korrigierende Person steht als Beschaeftigte darin. Der Bezug laeuft ueber die Note, weil das
  // Raster selbst nicht weiss, wer bewertet wurde.
  rubric_assessments:{spalten:['bewertete_person','bewertet_von'],art:'voll',mandant:true},
  // Die einzelnen Kriterienurteile haengen an der Bewertung - sie sind das eigentliche "warum".
  rubric_assessment_items:{spalten:[],art:'voll',mandant:false,ueber:{spalte:'assessment_id',tabelle:'rubric_assessments'}},
  // Die Zweitkorrektur haengt am Einspruch; die korrigierenden Personen stehen als Beschaeftigte
  // darin, die betroffene Person ueber den Einspruch.
  exam_second_markings:{spalten:['erstkorrektur_von','zweitkorrektur_von','beauftragt_von'],art:'voll',mandant:true,ueber:{spalte:'appeal_id',tabelle:'exam_appeals'}},
  accounting_expenses:{spalten:['created_by'],art:'voll',mandant:false},
  accounting_export_runs:{spalten:['created_by'],art:'nur_anzahl',mandant:false},
  // Bewerbertrichter: die Bewerbung fuehrt Name, Adresse, Telefon und die Nachricht der Person im
  // Klartext, und nach der Zusage zeigt enrolled_user_id auf ihr Konto. Ohne diese Zeile waere
  // jede Auskunft ueber eine Person, die sich beworben hat, ab hier unvollstaendig - und zwar
  // ausgerechnet ueber den Abschnitt vor ihrer Aufnahme.
  admission_forms:{spalten:['created_by'],art:'voll',mandant:true},
  admissions:{spalten:['enrolled_user_id','decided_by'],art:'voll',mandant:true},
  // Der Schriftwechsel mit der bewerbenden Person - Anrede, Betreff, Text und die Frist einer
  // Nachforderung. Er haengt an der Bewerbung und gehoert in jede Auskunft: dort steht, was der
  // Traeger dieser Person geschrieben hat. Die interne Entscheidungsnotiz steht NICHT hier,
  // sondern in admissions.
  admission_messages:{spalten:['gesendet_von'],art:'voll',mandant:true,ueber:{spalte:'admission_id',tabelle:'admissions'}},
  // Der KI-Auftrag traegt, WER ihn gestellt hat, und in der Eingabe steht, was die Person
  // erzeugen lassen wollte. Beides gehoert in ihre Auskunft - und zwar mit Inhalt: die Frage
  // "was habe ich eigentlich in diese Maschine gegeben" ist genau die, die gestellt wird.
  ai_jobs:{spalten:['angefordert_von'],art:'voll',mandant:true},
  // Die Personalakte. Sie gehoert VOLLSTAENDIG in die Auskunft: Beschaeftigte sind betroffene
  // Personen wie alle anderen, und was ueber sie gespeichert ist - Vertrag, Krankheitstage,
  // Unterweisungen, Austrittsgrund - ist genau das, wonach gefragt wird. Der Austrittsgrund und
  // die Ablehnung eines Urlaubsantrags sind dabei die heikelsten Felder und deshalb ausdruecklich
  // 'voll': sie zu verschweigen waere die Luecke, die eine Auskunft wertlos macht.
  personnel_records:{spalten:['user_id','created_by'],art:'voll',mandant:true},
  // Das Qualitaetsmanagement fuehrt keine Daten UEBER Personen, aber es nennt die Personen, die
  // etwas verantworten, auditieren oder abschliessen. Das ist Beschaeftigtendatenverarbeitung und
  // gehoert in die Auskunft - mit Inhalt, denn "Sie waren Auditor in Audit X" ist die Aussage,
  // nicht die Kennung.
  // Der Vertrieb fuehrt Personendaten, auch wenn alle Beteiligten "geschaeftlich" handeln: Name,
  // Funktion, Durchwahl und dienstliche Adresse einer natuerlichen Person. "Ist ja B2B" ist keine
  // Rechtsgrundlage. Der Werbewiderspruch steht im Kontakt und gehoert ausdruecklich mit in die
  // Auskunft - er ist die Aussage, auf die es ankommt.
  sales_accounts:{spalten:['created_by'],art:'voll',mandant:true},
  sales_contacts:{spalten:['created_by'],art:'voll',mandant:true,ueber:{spalte:'account_id',tabelle:'sales_accounts'}},
  sales_leads:{spalten:['verantwortlich','created_by'],art:'voll',mandant:true},
  sales_activities:{spalten:['erfasst_von'],art:'voll',mandant:true,ueber:{spalte:'lead_id',tabelle:'sales_leads'}},
  quality_objectives:{spalten:['verantwortlich','created_by'],art:'voll',mandant:true},
  quality_processes:{spalten:['verantwortlich','created_by'],art:'voll',mandant:true},
  quality_audits:{spalten:['auditor_user_id','abgeschlossen_von','created_by'],art:'voll',mandant:true},
  quality_findings:{spalten:['created_by'],art:'voll',mandant:true,ueber:{spalte:'audit_id',tabelle:'quality_audits'}},
  quality_reviews:{spalten:['abgeschlossen_von','created_by'],art:'voll',mandant:true},
  quality_certifications:{spalten:['created_by'],art:'nur_anzahl',mandant:true},
  personnel_contracts:{spalten:['created_by'],art:'voll',mandant:true,ueber:{spalte:'personnel_id',tabelle:'personnel_records'}},
  personnel_absences:{spalten:['created_by','entschieden_von'],art:'voll',mandant:true,ueber:{spalte:'personnel_id',tabelle:'personnel_records'}},
  personnel_instructions:{spalten:['created_by'],art:'voll',mandant:true,ueber:{spalte:'personnel_id',tabelle:'personnel_records'}},
  // Der Urlaubsanspruch traegt keine eigene Personenspalte - er haengt ueber personnel_id an der
  // Akte. Ohne diese Zeile fehlte ausgerechnet die Zahl, nach der am haeufigsten gefragt wird.
  personnel_leave_years:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'personnel_id',tabelle:'personnel_records'}},
  personnel_offboarding:{spalten:['created_by','zugang_entzogen_von','abgeschlossen_von'],art:'voll',mandant:true,ueber:{spalte:'personnel_id',tabelle:'personnel_records'}},
  api_tokens:{spalten:['created_by'],art:'ohne_inhalt',mandant:true},
  assignment_participant_state:{spalten:['user_id'],art:'voll',mandant:true},
  assignment_submissions:{spalten:['user_id'],art:'voll',mandant:true},
  attendance_events:{spalten:['user_id','created_by'],art:'nur_anzahl',mandant:true},
  attendance_records:{spalten:['user_id','recorded_by'],art:'voll',mandant:true},
  attendance_sessions:{spalten:['created_by'],art:'voll',mandant:true},
  calendar_feeds:{spalten:['created_by'],art:'voll',mandant:true},
  certificate_records:{spalten:['user_id'],art:'voll',mandant:true},
  certificate_templates:{spalten:['created_by'],art:'voll',mandant:true},
  classbook_export_runs:{spalten:['created_by'],art:'nur_anzahl',mandant:true},
  communication_email_deliveries:{spalten:['user_id'],art:'voll',mandant:true},
  communication_events:{spalten:['user_id'],art:'nur_anzahl',mandant:true},
  // Was NICHT an diese Person hinausging und warum - unterdrueckt wegen Themenabwahl, wegen
  // abgeschaltetem Weg, oder verzoegert wegen Ruhezeit. Die Auskunft gibt das voll heraus: es
  // ist die Folge ihrer eigenen Einstellung, und wer sagt "ich habe nie etwas bekommen", hat
  // ein Recht darauf zu erfahren, warum.
  communication_channel_decisions:{spalten:['user_id'],art:'voll',mandant:true},
  // Die eigenen Benachrichtigungseinstellungen. Voll - es sind ihre eigenen Angaben.
  notification_preferences:{spalten:['user_id'],art:'voll',mandant:true},
  notification_topic_preferences:{spalten:['user_id'],art:'voll',mandant:true},
  communication_messages:{spalten:['created_by'],art:'voll',mandant:true},
  communication_recipients:{spalten:['user_id'],art:'voll',mandant:true},
  compliance_evidence:{spalten:['created_by'],art:'voll',mandant:true},
  compliance_evidence_packages:{spalten:['created_by'],art:'voll',mandant:true},
  compliance_requirements:{spalten:['created_by'],art:'voll',mandant:true},
  // Sprechtag: die Buchung nennt die Familie im Klartext, das Fenster die Dozentin oder den
  // Dozenten. Ohne diese drei Zeilen waere jede Auskunft nach Artikel 15 ab hier unvollstaendig.
  consultation_bookings:{spalten:['user_id','teacher_id','created_by'],art:'voll',mandant:true},
  consultation_days:{spalten:['created_by'],art:'voll',mandant:true},
  consultation_slots:{spalten:['teacher_id'],art:'voll',mandant:true},
  // Klassenkasse: der Anteil nennt die Person, der Eingang die Verantwortliche, die ihn eintrug.
  // Ohne diese drei Zeilen waere jede Auskunft nach Artikel 15 ab hier unvollstaendig.
  course_fee_collections:{spalten:['created_by'],art:'voll',mandant:true},
  course_fee_payments:{spalten:['recorded_by'],art:'voll',mandant:true},
  course_fee_shares:{spalten:['user_id'],art:'voll',mandant:true},
  course_templates:{spalten:['created_by'],art:'voll',mandant:true},
  curriculum_frameworks:{spalten:['created_by'],art:'voll',mandant:true},
  digital_signatures:{spalten:['signer_user_id'],art:'voll',mandant:true},
  discussion_messages:{spalten:['user_id'],art:'voll',mandant:true},
  discussion_participants:{spalten:['user_id'],art:'voll',mandant:false},
  discussion_threads:{spalten:['created_by'],art:'voll',mandant:true},
  document_run_items:{spalten:['user_id'],art:'voll',mandant:true},
  document_runs:{spalten:['created_by'],art:'voll',mandant:true},
  document_templates:{spalten:['created_by'],art:'voll',mandant:true},
  education_document_registry:{spalten:['teacher_id','created_by'],art:'voll',mandant:true},
  education_scenarios:{spalten:['created_by'],art:'voll',mandant:true},
  exam_authority_profiles:{spalten:['created_by'],art:'voll',mandant:true},
  exam_workflows:{spalten:['created_by'],art:'voll',mandant:true},
  excursion_events:{spalten:['created_by'],art:'voll',mandant:true},
  external_identities:{spalten:['user_id'],art:'ohne_inhalt',mandant:true},
  gradebook_events:{spalten:['user_id'],art:'voll',mandant:true},
  gradebook_items:{spalten:['created_by'],art:'voll',mandant:true},
  gradebook_scores:{spalten:['user_id'],art:'voll',mandant:true},
  instruction_activity_details:{spalten:['created_by'],art:'voll',mandant:true},
  intake_channels:{spalten:['created_by'],art:'voll',mandant:true},
  intake_submitters:{spalten:['created_by'],art:'voll',mandant:true},
  intake_upload_links:{spalten:['created_by'],art:'voll',mandant:true},
  integration_exports:{spalten:['created_by'],art:'voll',mandant:true},
  learning_progress:{spalten:['user_id'],art:'voll',mandant:true},
  legacy_baselines:{spalten:['created_by'],art:'voll',mandant:true},
  legacy_import_batches:{spalten:['created_by'],art:'voll',mandant:true},
  lesson_hub_links:{spalten:['created_by'],art:'voll',mandant:true},
  lesson_online_meetings:{spalten:['created_by'],art:'voll',mandant:true},
  lesson_private_notes:{spalten:['user_id'],art:'voll',mandant:true},
  lessons:{spalten:['teacher_id'],art:'voll',mandant:true},
  memberships:{spalten:['user_id'],art:'voll',mandant:true},
  microsoft_graph_accounts:{spalten:['user_id'],art:'voll',mandant:true},
  microsoft_oauth_states:{spalten:['user_id'],art:'voll',mandant:true},
  migration_quality_runs:{spalten:['created_by'],art:'voll',mandant:true},
  notifications:{spalten:['user_id'],art:'voll',mandant:true},
  onboarding_invitations:{spalten:['created_by'],art:'voll',mandant:true},
  operational_deadlines:{spalten:['created_by'],art:'voll',mandant:true},
  org_import_batches:{spalten:['created_by'],art:'nur_anzahl',mandant:true},
  org_permission_grants:{spalten:['user_id'],art:'voll',mandant:true},
  organization_import_batches:{spalten:['created_by'],art:'voll',mandant:true},
  participant_import_batches:{spalten:['created_by'],art:'nur_anzahl',mandant:true},
  participant_import_results:{spalten:['user_id'],art:'nur_anzahl',mandant:true},
  // Debitorenprozess des Traegers: Schulgeld und Kursgebuehr gegenueber der teilnehmenden Person.
  // Die Vereinbarung, die gestellte Forderung und das SEPA-Mandat nennen sie unmittelbar; der
  // Eingang und die Mahnung nennen die Person der Verwaltung, die sie eingetragen hat. Die
  // Mahnungen zu einer Forderung haengen an participant_receivables und erscheinen dort mit.
  participant_billing_settings:{spalten:['updated_by'],art:'voll',mandant:true},
  participant_fee_plans:{spalten:['user_id','created_by'],art:'voll',mandant:true},
  participant_receivable_payments:{spalten:['recorded_by'],art:'voll',mandant:true},
  participant_receivables:{spalten:['user_id','created_by'],art:'voll',mandant:true},
  participant_sepa_mandates:{spalten:['user_id','created_by'],art:'voll',mandant:true},
  partner_access_grants:{spalten:['created_by'],art:'voll',mandant:true},
  personal_grades:{spalten:['user_id'],art:'voll',mandant:true},
  pilot_programs:{spalten:['created_by'],art:'voll',mandant:true},
  planning_blackouts:{spalten:['created_by'],art:'voll',mandant:true},
  planning_resource_unavailability:{spalten:['created_by'],art:'voll',mandant:true},
  planning_resources:{spalten:['created_by'],art:'voll',mandant:true},
  portability_audit_events:{spalten:['actor_id'],art:'nur_anzahl',mandant:true},
  portability_backups:{spalten:['created_by'],art:'voll',mandant:true},
  portability_import_runs:{spalten:['created_by'],art:'nur_anzahl',mandant:true},
  portal_language_preferences:{spalten:['user_id'],art:'voll',mandant:true},
  practice_phases:{spalten:['created_by'],art:'voll',mandant:true},
  push_outbox:{spalten:['user_id'],art:'voll',mandant:true},
  push_subscriptions:{spalten:['user_id'],art:'voll',mandant:true},
  quality_actions:{spalten:['created_by'],art:'voll',mandant:true},
  quiz_attempt_security_events:{spalten:['user_id'],art:'voll',mandant:true},
  quiz_attempts:{spalten:['user_id'],art:'voll',mandant:true},
  quiz_banks:{spalten:['created_by'],art:'voll',mandant:true},
  quiz_questions:{spalten:['created_by'],art:'voll',mandant:true},
  quizzes:{spalten:['created_by'],art:'voll',mandant:true},
  report_definitions:{spalten:['created_by'],art:'voll',mandant:true},
  responsibility_assignments:{spalten:['user_id'],art:'voll',mandant:true},
  scim_group_members:{spalten:['user_id'],art:'voll',mandant:true},
  scim_tokens:{spalten:['created_by'],art:'ohne_inhalt',mandant:true},
  sessions:{spalten:['user_id'],art:'ohne_inhalt',mandant:false},
  signature_documents:{spalten:['created_by'],art:'voll',mandant:true},
  signature_requests:{spalten:['signer_user_id'],art:'ohne_inhalt',mandant:true},
  substitution_cases:{spalten:['created_by'],art:'voll',mandant:true},
  substitution_updates:{spalten:['created_by'],art:'voll',mandant:true},
  // Foerderplanung: Ziele und Massnahmen wurden MIT der Person vereinbart, sie gehoeren in jede
  // Auskunft. Die Beratungsdokumentation dagegen nur als Anzahl - ihr Inhalt ist genau das, was
  // support-planning.ts hinter der Sichtbarkeitsstufe 'counseling_team' haelt. Eine Sammelausgabe
  // liefe hier ueber den Mandantenadmin, der das Beratungsrecht in aller Regel NICHT hat; sie
  // wuerde die Stufe still aushebeln und dazu die Einschaetzungen Dritter mit herausgeben. Die
  // Person erfaehrt, DASS und wie oft dokumentiert wurde - den Inhalt gibt das Beratungsteam
  // heraus, das die Erwaehnung Dritter beurteilen kann.
  support_counseling_access:{spalten:['user_id','granted_by'],art:'voll',mandant:true},
  support_journal_entries:{spalten:['user_id','created_by'],art:'nur_anzahl',mandant:true},
  support_plan_goals:{spalten:['created_by'],art:'voll',mandant:true},
  support_plan_measures:{spalten:['responsible_user_id','created_by'],art:'voll',mandant:true},
  support_plans:{spalten:['user_id','created_by'],art:'voll',mandant:true},
  survey_votes:{spalten:['user_id'],art:'voll',mandant:false},
  surveys:{spalten:['created_by'],art:'voll',mandant:true},
  teacher_availability:{spalten:['teacher_id','created_by'],art:'voll',mandant:true},
  // Honorarabrechnung: Satz und Abrechnung nennen immer eine dritte Person - die Honorarkraft,
  // um deren Geld es geht - und daneben die Verwaltung, die eingetragen, freigegeben und den
  // Auszahlungsvermerk gesetzt hat. Deshalb nur die Anzahl, aus demselben Grund wie beim
  // Anwesenheitsprotokoll: eine Sammelauskunft ueber die Verwaltungskraft wuerde sonst die
  // Saetze und Betraege des halben Kollegiums mit herausgeben. Die Honorarkraft selbst verliert
  // dadurch nichts - ihre eigene Abrechnung samt Zeilen und eingefrorenem Satz steht ihr im
  // Portal jederzeit vollstaendig offen (listTeacherFeePeriods, teacherFeePeriodDetail).
  teacher_fee_periods:{spalten:['teacher_id','created_by','confirmed_by','approved_by','paid_by'],art:'nur_anzahl',mandant:true},
  teacher_fee_rates:{spalten:['teacher_id','created_by'],art:'nur_anzahl',mandant:true},
  teacher_message_reads:{spalten:['user_id'],art:'voll',mandant:false},
  teacher_messages:{spalten:['created_by'],art:'voll',mandant:true},
  teacher_portal_assignments:{spalten:['teacher_id','user_id'],art:'voll',mandant:true},
  teacher_qualifications:{spalten:['teacher_id','created_by'],art:'voll',mandant:true},
  teacher_unavailability:{spalten:['teacher_id','created_by'],art:'voll',mandant:true},
  teacher_workload_rules:{spalten:['teacher_id'],art:'voll',mandant:true},
  tenant_users:{spalten:['user_id'],art:'voll',mandant:true},
  timetable_import_runs:{spalten:['created_by'],art:'nur_anzahl',mandant:true},
  timetable_plan_entries:{spalten:['teacher_id','created_by'],art:'voll',mandant:true},
  timetable_plan_entry_resources:{spalten:['created_by'],art:'voll',mandant:true},
  timetable_plan_versions:{spalten:['created_by'],art:'voll',mandant:true},
  user_portal_layouts:{spalten:['user_id'],art:'voll',mandant:true},
  workflow_rules:{spalten:['created_by'],art:'voll',mandant:true},
  // Nachgetragen, als die Spaltenerkennung vom Ratewort auf den Fremdschluessel umgestellt wurde.
  // Alle 23 fuehren eine Personenspalte mit Fremdschluessel auf users(id), die vorher niemand
  // gesehen hat - allen voran das Berichtsheft, das ueber participant_user_id komplett an einer
  // Person haengt und in keiner Auskunft auftauchte.
  // Der Foerderfall einer Person: Kostentraeger, Zuweisungsnummern, Eintritt und Austritt samt
  // Grund. Das gehoert vollstaendig in ihre Auskunft - der Austrittsgrund entscheidet mit
  // darueber, wie sie beim Kostentraeger gefuehrt wird.
  participant_funding_cases:{spalten:[],art:'voll',mandant:true},
  attendance_policies:{spalten:[],art:'voll',mandant:true},
  classbook_entries:{spalten:[],art:'voll',mandant:true},
  classbook_entry_reviews:{spalten:[],art:'voll',mandant:true},
  course_curriculum_bindings:{spalten:[],art:'voll',mandant:true},
  course_exam_authority_profiles:{spalten:[],art:'voll',mandant:true},
  course_lifecycle:{spalten:[],art:'voll',mandant:true},
  course_lifecycle_items:{spalten:[],art:'voll',mandant:true},
  course_scheduling_rules:{spalten:[],art:'voll',mandant:true},
  curriculum_session_links:{spalten:[],art:'voll',mandant:true},
  education_autopilot_executions:{spalten:[],art:'voll',mandant:true},
  education_autopilot_policies:{spalten:[],art:'voll',mandant:true},
  education_guardrail_evaluations:{spalten:[],art:'voll',mandant:true},
  education_proof_packages:{spalten:[],art:'voll',mandant:true},
  education_readiness_snapshots:{spalten:[],art:'voll',mandant:true},
  education_scenario_approvals:{spalten:[],art:'voll',mandant:true},
  education_twin_snapshots:{spalten:[],art:'voll',mandant:true},
  exam_workflow_requirements:{spalten:[],art:'voll',mandant:true},
  lesson_hub_details:{spalten:[],art:'voll',mandant:true},
  lesson_hub_materials:{spalten:[],art:'voll',mandant:true},
  // Das Berichtsheft der lernenden Person - der schwerste der nachgetragenen Faelle.
  report_book_periods:{spalten:[],art:'voll',mandant:true},
  timetable_target_aliases:{spalten:[],art:'voll',mandant:true},
  // Die SSO-Einrichtung traegt Geheimnisse des Anmeldeverfahrens. Dass es sie gibt und wer sie
  // zuletzt geaendert hat, darf die Person erfahren - der Inhalt waere ein Schluessel.
  tenant_sso_configs:{spalten:[],art:'ohne_inhalt',mandant:true},
  // Freigabe einer Produktionsversion: eine Plattformsache ohne Mandantenspalte.
  production_release_approvals:{spalten:[],art:'ohne_inhalt',mandant:false},
  // Ueber eine Kette erreichbar: die Zeile selbst nennt die Person nicht, die Zeile, an der sie
  // haengt, tut es. Ohne diese Angabe meldet die Auskunft "nichts vorhanden", waehrend die Daten
  // da sind - der teuerste Fehler, den eine Auskunft machen kann.
  // Die Eintraege im Berichtsheft - was die lernende Person selbst geschrieben hat.
  report_book_entries:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'period_id',tabelle:'report_book_periods'}},
  // Die hochgeladenen Abgabedateien der lernenden Person.
  assignment_submission_files:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'submission_id',tabelle:'assignment_submissions'}},
  // Die Antworten der lernenden Person in einem Test.
  quiz_answers:{spalten:[],art:'voll',mandant:false,ueber:{spalte:'attempt_id',tabelle:'quiz_attempts'}},
  // Mahnungen nennen nur die Forderung; der Schuldner steht an der Forderung.
  participant_dunning_notices:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'receivable_id',tabelle:'participant_receivables'}},
  // Der Lebenslauf der Bescheinigung dieser Person.
  certificate_events:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'certificate_id',tabelle:'certificate_records'}},
  // Die Abrechnungszeilen der Honorarkraft.
  teacher_fee_period_lines:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'period_id',tabelle:'teacher_fee_periods'}},
  communication_targets:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'message_id',tabelle:'communication_messages'}},
  timetable_import_lessons:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'lesson_id',tabelle:'lessons'}},
  accounting_lines:{spalten:[],art:'voll',mandant:false,ueber:{spalte:'entry_id',tabelle:'accounting_entries'}},
  accounting_reconciliation:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'accounting_entry_id',tabelle:'accounting_entries'}},
  accounting_bank_transactions:{spalten:[],art:'voll',mandant:false,ueber:{spalte:'accounting_entry_id',tabelle:'accounting_entries'}},
  education_autopilot_execution_steps:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'execution_id',tabelle:'education_autopilot_executions'}},
  education_autopilot_locks:{spalten:[],art:'ohne_inhalt',mandant:true,ueber:{spalte:'execution_id',tabelle:'education_autopilot_executions'}},
  education_scenario_options:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'scenario_id',tabelle:'education_scenarios'}},
  workflow_runs:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'rule_id',tabelle:'workflow_rules'}},
  survey_options:{spalten:[],art:'voll',mandant:false,ueber:{spalte:'survey_id',tabelle:'surveys'}},
  quiz_question_options:{spalten:[],art:'voll',mandant:false,ueber:{spalte:'question_id',tabelle:'quiz_questions'}},
  quiz_question_links:{spalten:[],art:'voll',mandant:false,ueber:{spalte:'quiz_id',tabelle:'quizzes'}},
  curriculum_items:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'framework_id',tabelle:'curriculum_frameworks'}},
  report_runs:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'report_id',tabelle:'report_definitions'}},
  course_clone_jobs:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'template_id',tabelle:'course_templates'}},
  backup_verifications:{spalten:[],art:'ohne_inhalt',mandant:true,ueber:{spalte:'backup_id',tabelle:'portability_backups'}},
  intake_batches:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'channel_id',tabelle:'intake_channels'}},
  organization_import_results:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'batch_id',tabelle:'organization_import_batches'}},
  legacy_import_rows:{spalten:[],art:'voll',mandant:false,ueber:{spalte:'batch_id',tabelle:'legacy_import_batches'}},
  lesson_resource_reservations:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'lesson_id',tabelle:'lessons'}},
  timetable_plan_conflicts:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'plan_id',tabelle:'timetable_plan_versions'}},
  timetable_update_decisions:{spalten:[],art:'voll',mandant:true,ueber:{spalte:'run_id',tabelle:'timetable_import_runs'}},
  onboarding_claim_tombstones:{spalten:[],art:'ohne_inhalt',mandant:false,ueber:{spalte:'invitation_id',tabelle:'onboarding_invitations'}},
  // Wer eine Auslagerung in den Objektspeicher angestossen hat. Personenbezug ist allein der
  // handelnde Plattformadministrator; der Inhalt des Archivs gehoert nicht hierher, er steht
  // ueber kalteDatenFuerPerson bereits vollstaendig in der Auskunft.
  cold_archives:{spalten:['archived_by'],art:'ohne_inhalt',mandant:true},
  // Rechtsnachfolge: die Zeile beschreibt zwei Traeger, nicht eine Person. Personenbezug ist
  // allein, wer den Vorgang angelegt hat. Die Tabelle fuehrt bewusst KEINE Spalte tenant_id -
  // sie muss den geloeschten Vorgaenger ueberleben.
  tenant_successions:{spalten:['created_by'],art:'ohne_inhalt',mandant:false},
};

// Spalten ohne Fremdschluessel, die trotzdem eine Person benennen. Nur diese Handvoll muss
// gepflegt werden - alles andere kommt aus dem Schema.
// Kinder von personenbezogenen Tabellen, die selbst KEINE Person betreffen - mit Begruendung.
// Fail closed: was weder hier noch in PERSONENDATEN steht, laesst die Pruefung durchfallen.
export const OHNE_EIGENEN_PERSONENBEZUG:Record<string,string>={
  tenant_profiles:'Stammdaten des Traegers, keine Daten einer im Portal gefuehrten Person.',
  library_copies:'Ein Exemplar im Regal: Nummer und Zustand. Wer es hatte, steht in library_loans - und dort nur, solange die Ausleihe laeuft.',
  commercial_quotes:'Angebot an den Traeger; die Person darin ist die Vertragsanschrift, kein Nutzerkonto.',
  tenant_succession_courses:'Nur Kursnamen eines Nachfolgevorgangs, keine Personendaten.',
  rubric_criteria:'Kriterium und Erwartungshorizont einer Aufgabe - fuer alle Teilnehmenden gleich, keine Daten einer Person.',
  rubric_levels:'Niveaustufen eines Kriteriums, fuer alle Teilnehmenden gleich.',
  provider_health_samples:'Messreihe, ob ein Anbieter geantwortet hat - keine Person darin.',
  workflow_simulations:'Probelauf einer Automatikregel: was sie getan haette. Keine Person darin.',
  document_search_terms:'Wortliste fuer die Dokumentsuche - ueber das Dokument erreichbar, kein eigener Personenbezug.',
  operation_journal_steps:'Schritte eines Vorgangs, ohne eigenen Personenbezug.',
  restore_drill_policy:'Turnus und Ergebnis der Wiederanlaufprobe eines Mandanten - keine Person darin.',
  cost_usage:'Verbrauchszahlen je Dienst und Funktion - keine Person darin.',
  service_health_checks:'Messreihe des Betriebszustands - keine Person darin.',
  service_level_objectives:'Zielwerte des Betriebs, plattformweit.',
  exam_variant_questions:'Welche Aufgaben auf einem Pruefungsbogen stehen - fuer alle, die ihn bekommen, dieselben.',
};

export const PERSONENSPALTEN=['user_id','signer_user_id','created_by','recorded_by','teacher_id','participant_id','actor_id','archived_by'];

// Welche Spalte eine Person benennt, weiss das Schema besser als eine gepflegte Liste: jede Spalte
// mit Fremdschluessel auf users(id) IST eine Personenspalte.
//
// Gemessen, als das hier entstand: 48 Tabellen fuehrten so eine Spalte, die die Auskunft nie
// angesehen hat - darunter participant_user_id am Berichtsheft, enrolled_user_id an der Bewerbung
// und reviewed_by an jeder Genehmigung. Die Auskunft war damit still unvollstaendig, und die Liste
// oben haette das nie gemeldet, weil sie diese Namen schlicht nicht kannte. Namen zu erraten ist
// der falsche Weg; der Fremdschluessel steht im Schema und luegt nicht.
export async function personenSpaltenJeTabelle(env:Env):Promise<Record<string,string[]>>{
  const tabellen=((await env.DB.prepare("SELECT name,sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all<{name:string;sql:string|null}>()).results)??[];
  const out:Record<string,string[]>={};
  for(const t of tabellen){
    const quelltext=t.sql??'',spalten=new Set<string>();
    for(const m of quelltext.matchAll(/FOREIGN KEY\s*\(\s*(\w+)\s*\)\s*REFERENCES\s+users\s*\(/gi))spalten.add(m[1]);
    for(const m of quelltext.matchAll(/(?:^|,)\s*(\w+)\s+TEXT[^,\n]*REFERENCES\s+users\s*\(/gi))spalten.add(m[1]);
    for(const m of quelltext.matchAll(/(?:^|,)\s*(\w+)\s+\w+/g))if(PERSONENSPALTEN.includes(m[1]))spalten.add(m[1]);
    if(spalten.size)out[t.name]=[...spalten].sort();
  }
  return out;
}

// Liest das TATSAECHLICHE Schema und meldet jede Tabelle mit Personenbezug, die oben fehlt.
// Fail closed: was hier auftaucht, fehlt in jeder Auskunft.
export async function unklassifizierteTabellen(env:Env):Promise<string[]>{
  const jeTabelle=await personenSpaltenJeTabelle(env);
  return Object.keys(jeTabelle).filter(name=>!PERSONENDATEN[name]).sort();
}

// Zweite Luecke derselben Art: eine Tabelle ohne eigene Personenspalte, die aber an einer
// personenbezogenen Zeile haengt. Die Mahnung nennt nur die Forderung, der Berichtsheft-Eintrag nur
// den Zeitraum. Wer nur nach Personenspalten sucht, meldet "nichts vorhanden", waehrend die Daten
// da sind. Fail closed: jedes solche Kind braucht entweder eine Kette oder eine Begruendung.
export async function unerklaerteKindtabellen(env:Env):Promise<string[]>{
  const jeTabelle=await personenSpaltenJeTabelle(env);
  const tabellen=((await env.DB.prepare("SELECT name,sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all<{name:string;sql:string|null}>()).results)??[];
  const offen:string[]=[];
  for(const t of tabellen){
    if(jeTabelle[t.name]||OHNE_EIGENEN_PERSONENBEZUG[t.name])continue;
    if(PERSONENDATEN[t.name]?.ueber)continue;
    const eltern=[...String(t.sql??'').matchAll(/FOREIGN KEY\s*\(\s*\w+\s*\)\s*REFERENCES\s+(\w+)\s*\(/gi)].map(m=>m[1]);
    if(eltern.some(e=>jeTabelle[e]))offen.push(t.name);
  }
  return offen;
}

// Die Auskunft selbst. Sie laeuft im Mandanten des Aufrufers und nur ueber eine Person.
export async function exportPersonalData(env:Env,auth:CoreAuthContext,tenantId:string,userId:string){
  requireRole(auth,'tenant_admin');
  // Die Person muss zu DIESEM Mandanten gehoeren. Ohne diese Pruefung koennte ein Mandantenadmin
  // ueber eine geratene oder anderswo erfahrene Kennung Adresse, Anzeigename, Kontostatus,
  // Sitzungszeitpunkte und offene Passwort-Token JEDES Kontos der Plattform abrufen - die Auskunft
  // waere selbst das Datenleck, das sie verhindern soll.
  const gehoert=await env.DB.prepare('SELECT 1 ok FROM tenant_users WHERE tenant_id=? AND user_id=? UNION SELECT 1 ok FROM memberships WHERE tenant_id=? AND user_id=? LIMIT 1').bind(tenantId,userId,tenantId,userId).first();
  if(!gehoert)throw new Error('PERSON_NOT_IN_TENANT');
  const person=await env.DB.prepare('SELECT id,email,display_name,status,created_at,updated_at FROM users WHERE id=?').bind(userId).first<Record<string,unknown>>();
  if(!person)throw new Error('PERSON_NOT_FOUND');
  const daten:Record<string,unknown>={},anzahlen:Record<string,number>={};
  // Welche Spalten eine Person benennen, kommt aus dem Schema, nicht aus dem Eintrag: sonst haette
  // ein Eintrag mit spalten:['user_id'] die vier weiteren Personenspalten derselben Tabelle
  // uebersehen - und wer eine Bescheinigung vorbereitet, freigegeben oder widerrufen hat, waere
  // in seiner eigenen Auskunft nicht vorgekommen.
  const ausSchema=await personenSpaltenJeTabelle(env);
  for(const [tabelle,e] of Object.entries(PERSONENDATEN)){
    const spalten=[...new Set([...e.spalten,...(ausSchema[tabelle]??[])])];
    const bedingungen:string[]=[],werte:unknown[]=[];
    if(spalten.length){bedingungen.push(spalten.map(s=>`${s}=?`).join(' OR '));for(const _ of spalten)werte.push(userId);}
    // Ueber eine Kette: die Zeile selbst nennt die Person nicht, die Zeile daneben tut es. Eine
    // Mahnung nennt nur die Forderung - ohne diesen Schritt meldet die Auskunft "keine Mahnungen",
    // waehrend drei im System stehen.
    if(e.ueber){
      const eltern=PERSONENDATEN[e.ueber.tabelle];
      const elternSpalten=[...new Set([...(eltern?.spalten??[]),...(ausSchema[e.ueber.tabelle]??[])])];
      if(elternSpalten.length){
        const elternWo=elternSpalten.map(s=>`${s}=?`).join(' OR ');
        const elternFilter=eltern?.mandant?`tenant_id=? AND (${elternWo})`:`(${elternWo})`;
        bedingungen.push(`${e.ueber.spalte} IN (SELECT ${e.ueber.fremdspalte??'id'} FROM ${e.ueber.tabelle} WHERE ${elternFilter})`);
        if(eltern?.mandant)werte.push(tenantId);
        for(const _ of elternSpalten)werte.push(userId);
      }
    }
    if(!bedingungen.length)continue;
    const wo=bedingungen.map(x=>`(${x})`).join(' OR ');
    // Sieben Tabellen fuehren keine eigene Mandantenspalte. Fuer sie wurde ohne Mandantenfilter
    // gesucht - richtig ist das nur, weil die Zugehoerigkeit der Person oben bereits geprueft ist.
    const filter=e.mandant?`tenant_id=? AND (${wo})`:`(${wo})`;
    const binden=e.mandant?[tenantId,...werte]:werte;
    if(e.art==='nur_anzahl'){
      const r=await env.DB.prepare(`SELECT COUNT(*) n FROM ${tabelle} WHERE ${filter}`).bind(...binden).first<{n:number}>();
      if(r?.n)anzahlen[tabelle]=Number(r.n);
      continue;
    }
    const r=((await env.DB.prepare(`SELECT * FROM ${tabelle} WHERE ${filter}`).bind(...binden).all<Record<string,unknown>>()).results)??[];
    if(!r.length)continue;
    daten[tabelle]=r.map(zeile=>{
      const raus:Record<string,unknown>={};
      for(const [k,v] of Object.entries(zeile)){
        if(GEHEIME_SPALTEN.has(k))continue;
        // Bei 'ohne_inhalt' bleiben nur Kennung, Art und Zeitpunkte stehen.
        if(e.art==='ohne_inhalt'&&!/^(id|type|kind|status|scope|name|label|created_at|updated_at|expires_at|used_at|last_seen_at|revoked_at)$/.test(k))continue;
        raus[k]=v;
      }
      return raus;
    });
  }
  // Ausgelagerte Zeilen gehoeren in die Auskunft. Ohne das haette die Auslagerung in den
  // Objektspeicher die Auskunftspflicht ausgehebelt, ohne dass es jemand merkt.
  const kalt=await kalteDatenFuerPerson(env,tenantId,userId);
  for(const [tabelle,zeilen] of Object.entries(kalt)){
    if(!zeilen.length)continue;
    const bisher=Array.isArray(daten[tabelle])?daten[tabelle] as Record<string,unknown>[]:[];
    daten[tabelle]=[...bisher,...zeilen];
  }
  return{person,erstellt_am:new Date().toISOString(),mandant:tenantId,daten,nur_anzahl:anzahlen,ausgelagert:Object.fromEntries(Object.entries(kalt).map(([t,z])=>[t,z.length]))};
}

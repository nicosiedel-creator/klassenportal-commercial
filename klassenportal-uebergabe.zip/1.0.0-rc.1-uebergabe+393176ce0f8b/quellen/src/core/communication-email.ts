import type { Env } from './types.js';
import { mailConfigured, sendMail } from './mail.js';
import { bloeckeLesen, darstellungen } from './communication-content.js';
import { id, nowIso,inBloecken} from './utils.js';

type MessageLike={id:string;tenant_id:string;title:string;body:string;bloecke_json?:string|null;priority:string;send_email:number};
type Recipient={id:string;email:string;display_name:string};
type RetryRow={id:string;message_id:string;tenant_id:string;user_id:string;email:string;attempts:number;title:string;body:string;bloecke_json:string|null;priority:string};

function esc(v:unknown){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));}
function chunks<T>(values:T[],size=100){const out:T[][]=[];for(let i=0;i<values.length;i+=size)out.push(values.slice(i,i+size));return out;}
function retryAt(attempts:number){const delay=attempts<=1?15*60_000:attempts===2?60*60_000:6*60*60_000;return new Date(Date.now()+delay).toISOString();}
function subject(message:MessageLike){return message.priority==='urgent'?`Dringend: ${message.title}`:`Klassenportal: ${message.title}`;}
// HTML- und Textteil werden aus DEMSELBEN Inhaltsobjekt gerechnet wie die Portalansicht und die
// Kurzmeldung (K2). Frueher schrieb der Versand hier seine eigene Fassung des Rumpfes; damit gab
// es zwei Texte, die nach der ersten Korrektur nicht mehr dasselbe sagten.
function inhalt(message:MessageLike,origin:string){return darstellungen(bloeckeLesen(message.bloecke_json,message.body),message.title,{betreff:subject(message),herkunft:origin});}
function textBody(message:MessageLike,origin:string){return inhalt(message,origin).mail.text;}
function htmlBody(message:MessageLike,origin:string){return inhalt(message,origin).mail.html;}
async function ensureFailureTask(env:Env,tenantId:string,messageId:string,title:string,failed:number){const existing=await env.DB.prepare("SELECT id FROM automation_tasks WHERE tenant_id=? AND source_type='communication' AND source_id=? AND task_type='communication_email_delivery_failed' AND status IN ('open','in_progress') LIMIT 1").bind(tenantId,messageId).first();if(existing)return;const ts=nowIso();await env.DB.prepare("INSERT INTO automation_tasks(id,tenant_id,task_type,severity,title,detail_json,source_type,source_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'communication',?,'open',?,?)").bind(id('tsk_'),tenantId,'communication_email_delivery_failed','important',`${failed} E-Mail-Zustellung(en) endgültig fehlgeschlagen: ${title}`,JSON.stringify({failed}),messageId,ts,ts).run();}
// Wie viele Zustellungen ein Aufruf hoechstens selbst uebernimmt. Jede kostet einen Aufruf beim
// Mailanbieter und eine Datenbankschreibung; 150 lassen genug Luft unter der Grenze von 1000.
export const VERSAND_JE_LAUF=150;

// Dieselbe Schreibung als Anweisung, damit viele davon in einen Stapel passen.
function deliveryStatement(env:Env,args:{messageId:string;tenantId:string;userId:string;email:string;status:'sent'|'failed'|'queued';providerId?:string|null;error?:string|null;attempts:number;nextRetry?:string|null},ts:string){
  return env.DB.prepare(`INSERT INTO communication_email_deliveries(id,message_id,tenant_id,user_id,email,status,provider_message_id,error_code,attempts,last_attempt_at,next_retry_at,created_at,updated_at)
  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(message_id,user_id) DO UPDATE SET email=excluded.email,status=excluded.status,provider_message_id=excluded.provider_message_id,error_code=excluded.error_code,attempts=excluded.attempts,last_attempt_at=excluded.last_attempt_at,next_retry_at=excluded.next_retry_at,updated_at=excluded.updated_at`)
    .bind(id('ced_'),args.messageId,args.tenantId,args.userId,args.email,args.status,args.providerId||null,args.error||null,args.attempts,args.status==='queued'?null:ts,args.nextRetry||null,ts,ts);
}
async function saveDelivery(env:Env,args:{messageId:string;tenantId:string;userId:string;email:string;status:'sent'|'failed'|'queued';providerId?:string|null;error?:string|null;attempts:number;nextRetry?:string|null}){const ts=nowIso();await env.DB.prepare(`INSERT INTO communication_email_deliveries(id,message_id,tenant_id,user_id,email,status,provider_message_id,error_code,attempts,last_attempt_at,next_retry_at,created_at,updated_at)
  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(message_id,user_id) DO UPDATE SET email=excluded.email,status=excluded.status,provider_message_id=excluded.provider_message_id,error_code=excluded.error_code,attempts=excluded.attempts,last_attempt_at=excluded.last_attempt_at,next_retry_at=excluded.next_retry_at,updated_at=excluded.updated_at`).bind(id('ced_'),args.messageId,args.tenantId,args.userId,args.email,args.status,args.providerId||null,args.error||null,args.attempts,ts,args.nextRetry||null,ts,ts).run();}
async function sendOne(env:Env,message:MessageLike,r:Recipient,attempts:number){if(!r.email){await saveDelivery(env,{messageId:message.id,tenantId:message.tenant_id,userId:r.id,email:'',status:'failed',error:'EMAIL_MISSING',attempts:3});return{sent:false,final:true};}try{const providerId=await sendMail(env,r.email,subject(message),textBody(message,String(env.APP_ORIGIN||'')),htmlBody(message,String(env.APP_ORIGIN||'')),`communication:${message.id}:${r.id}`);await saveDelivery(env,{messageId:message.id,tenantId:message.tenant_id,userId:r.id,email:r.email,status:'sent',providerId,attempts});return{sent:true,final:true};}catch(e){const nextAttempts=attempts,final=nextAttempts>=3,error=String((e as Error).message||'MAIL_FAILED').slice(0,100);await saveDelivery(env,{messageId:message.id,tenantId:message.tenant_id,userId:r.id,email:r.email,status:'failed',error,attempts:nextAttempts,nextRetry:final?null:retryAt(nextAttempts)});return{sent:false,final};}}

export async function deliverCommunicationEmails(env:Env,message:MessageLike,userIds:string[],verzoegert?:Map<string,string>){if(!message.send_email)return{sent:0,failed:0,pending:0};if(!mailConfigured(env))throw new Error('COMMUNICATION_MAIL_NOT_CONFIGURED');const recipients:Recipient[]=[];for(const part of chunks([...new Set(userIds)])){const marks=part.map(()=>'?').join(','),rows=(await env.DB.prepare(`SELECT id,email,display_name FROM users WHERE id IN (${marks}) AND status='active'`).bind(...part).all<Recipient>()).results??[];recipients.push(...rows);}let sent=0,failed=0,pending=0;const found=new Set(recipients.map(x=>x.id));
  const fehlend=userIds.filter(x=>!found.has(x)),ts0=nowIso();
  for(const teil of inBloecken(fehlend,50))await env.DB.batch(teil.map(missing=>deliveryStatement(env,{messageId:message.id,tenantId:message.tenant_id,userId:missing,email:'',status:'failed',error:'USER_OR_EMAIL_MISSING',attempts:3},ts0)));
  failed+=fehlend.length;
  // Eine Rundmail an einen ganzen Traeger ging frueher Empfaenger fuer Empfaenger an den
  // Mailanbieter. Cloudflare erlaubt 1000 Unteranfragen je Aufruf; ab etwa 400 Empfaengern brach
  // der Versand mitten in der Liste ab - ein Teil bekam die Nachricht, der Rest nicht, und
  // niemand konnte sagen wo die Grenze lag. Der Rest wird jetzt vorgemerkt und vom vorhandenen
  // Wiederholungslauf abgearbeitet; 'queued' heisst dabei wirklich vorgemerkt, nicht gescheitert.
  // Ruhezeit (K3): fuer eine normale oder wichtige Meldung wird die Mail nicht unterdrueckt,
  // sondern auf das Ende der Ruhezeit vorgemerkt - in genau dieselbe Schlange, die auch den
  // Massenversand abarbeitet. Eine verbindliche Meldung kommt hier gar nicht erst an.
  const wartend=recipients.filter(r=>verzoegert?.has(r.id)),moeglich=recipients.filter(r=>!verzoegert?.has(r.id));
  for(const teil of inBloecken(wartend,50))await env.DB.batch(teil.map(r=>deliveryStatement(env,{messageId:message.id,tenantId:message.tenant_id,userId:r.id,email:r.email,status:'queued',attempts:0,nextRetry:String(verzoegert?.get(r.id)||ts0)},ts0)));
  pending+=wartend.length;
  const sofort=moeglich.slice(0,VERSAND_JE_LAUF),spaeter=moeglich.slice(VERSAND_JE_LAUF);
  for(const r of sofort){const x=await sendOne(env,message,r,1);if(x.sent)sent++;else if(x.final)failed++;else pending++;}
  const ts1=nowIso();
  for(const teil of inBloecken(spaeter,50))await env.DB.batch(teil.map(r=>deliveryStatement(env,{messageId:message.id,tenantId:message.tenant_id,userId:r.id,email:r.email,status:'queued',attempts:0,nextRetry:ts1},ts1)));
  pending+=spaeter.length;if(failed)await ensureFailureTask(env,message.tenant_id,message.id,message.title,failed);return{sent,failed,pending};}
export async function communicationEmailStats(env:Env,messageId:string){const x=await env.DB.prepare("SELECT COUNT(*) total,SUM(CASE WHEN status='sent' THEN 1 ELSE 0 END) sent,SUM(CASE WHEN status='failed' AND attempts>=3 THEN 1 ELSE 0 END) failed,SUM(CASE WHEN status='failed' AND attempts<3 THEN 1 ELSE 0 END) pending FROM communication_email_deliveries WHERE message_id=?").bind(messageId).first<Record<string,unknown>>();return{total:Number(x?.total||0),sent:Number(x?.sent||0),failed:Number(x?.failed||0),pending:Number(x?.pending||0)};}
export async function retryFailedCommunicationEmails(env:Env){if(!mailConfigured(env))return;const now=nowIso(),rows=(await env.DB.prepare(`SELECT d.id,d.message_id,d.tenant_id,d.user_id,d.email,d.attempts,m.title,m.body,m.bloecke_json,m.priority FROM communication_email_deliveries d JOIN communication_messages m ON m.id=d.message_id WHERE d.status IN ('failed','queued') AND d.attempts<3 AND d.next_retry_at IS NOT NULL AND d.next_retry_at<=? AND m.status='published' AND m.send_email=1 ORDER BY d.next_retry_at LIMIT 200`).bind(now).all<RetryRow>()).results??[],finalByMessage=new Map<string,{tenantId:string;title:string;count:number}>();for(const r of rows){const message:MessageLike={id:r.message_id,tenant_id:r.tenant_id,title:r.title,body:r.body,bloecke_json:r.bloecke_json,priority:r.priority,send_email:1},x=await sendOne(env,message,{id:r.user_id,email:r.email,display_name:''},Number(r.attempts||0)+1);if(!x.sent&&x.final){const m=finalByMessage.get(r.message_id)||{tenantId:r.tenant_id,title:r.title,count:0};m.count++;finalByMessage.set(r.message_id,m);}}for(const [messageId,m] of finalByMessage)await ensureFailureTask(env,m.tenantId,messageId,m.title,m.count);}

import type { CoreAuthContext, Env } from './types.js';
import { authStatus, safeErrorCode } from './utils.js';
import { createAdmissionForm, decideAdmission, enrollAdmission, getAdmission, getPublicAdmissionForm, listAdmissionForms, listAdmissions, setAdmissionFormStatus, submitPublicAdmission } from './admissions.js';
import { bestaetigeEingangZuVorgang, bewerbungsverlauf, fordereUnterlagenNach, nachreichenAnfrage, nimmNachgereichtesAn, sendeBewerbernachricht } from './admission-communication.js';

function json(data:unknown,status=200){return new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});}
function fail(e:unknown){
  const code=safeErrorCode(e);
  const status=authStatus(code)??(code==='UNAUTHENTICATED'?401
    :code.startsWith('FORBIDDEN')||code.includes('ADMIN_REQUIRED')?403
    :code.includes('NOT_FOUND')?404
    :code.includes('RATE_LIMITED')?429
    :code.includes('CLOSED')?410
    :code.includes('TOO_LARGE')||code.includes('TOO_MANY')?413
    :code.includes('INVALID')||code.includes('REQUIRED')||code.includes('REJECTED')||code.includes('FAILED')?400
    :500);
  return json({ok:false,error:code},status);
}

// Der oeffentliche Trichter. Genau zwei Verben auf genau einer Adresse:
//   GET  gibt das EINE, ausdruecklich veroeffentlichte Formular aus - Titel, Einleitung, welche
//        Angaben erwartet werden. Keine Kursliste, keine Zahlen, keine Kennungen.
//   POST nimmt eine Bewerbung entgegen.
// Weitere Leserouten gibt es hier bewusst nicht: es gibt keinen oeffentlichen Weg, den Stand
// einer Bewerbung abzufragen, denn eine solche Abfrage waere ein Leseweg in fremde Daten.
export async function handlePublicAdmissionRoute(request:Request,env:Env):Promise<Response|null>{
  const pfad=new URL(request.url).pathname;
  // Der Rueckweg einer Nachforderung. Er laesst ausschliesslich einreichen: GET gibt die
  // Vorgangsnummer zurueck, damit der Einreichende sieht, dass er richtig ist - und sonst nichts.
  const nachreichen=pfad.match(/^\/api\/bewerbung\/nachreichen\/([A-Za-z0-9]{20,64})$/);
  if(nachreichen){
    if(request.method!=='GET'&&request.method!=='POST')return json({ok:false,error:'METHOD_NOT_ALLOWED'},405);
    try{
      if(request.method==='GET')return json({ok:true,...await nachreichenAnfrage(env,nachreichen[1])});
      return json({ok:true,...await nimmNachgereichtesAn(env,nachreichen[1],request)},201);
    }catch(e){return fail(e);}
  }
  const treffer=pfad.match(/^\/api\/bewerbung\/([^/]+)$/);
  if(!treffer)return null;
  const slug=decodeURIComponent(treffer[1]);
  if(request.method!=='GET'&&request.method!=='POST')return json({ok:false,error:'METHOD_NOT_ALLOWED'},405);
  try{
    if(request.method==='GET')return json({ok:true,form:await getPublicAdmissionForm(env,slug)});
    const eingang=await submitPublicAdmission(env,slug,request);
    // Die Eingangsbestaetigung haengt NICHT an der Annahme: wenn der Mailweg klemmt, ist die
    // Bewerbung trotzdem eingegangen. Der Fehlschlag steht in der Akte, nicht in der Antwort.
    // Nur der Fehlercode ins Protokoll, nie die Rohmeldung: in einer Routerdatei darf nichts
    // stehen, was versehentlich in eine Antwort geraten kann.
    await bestaetigeEingangZuVorgang(env,slug,eingang.reference)
      .catch(e=>console.error('Eingangsbestaetigung fehlgeschlagen',{code:safeErrorCode(e)}));
    return json({ok:true,...eingang},201);
  }catch(e){return fail(e);}
}

export async function handleEnterpriseAdmissionRoute(request:Request,env:Env,auth:CoreAuthContext,tenantId:string):Promise<Response|null>{
  const url=new URL(request.url),path=url.pathname;
  if(!path.startsWith('/api/enterprise/admissions'))return null;
  const body=async()=>{try{return await request.json() as Record<string,unknown>;}catch{return{};}};
  try{
    if(path==='/api/enterprise/admissions/forms'&&request.method==='GET')
      return json({ok:true,forms:await listAdmissionForms(env,auth,tenantId,env.APP_ORIGIN||url.origin)});
    if(path==='/api/enterprise/admissions/forms'&&request.method==='POST')
      return json({ok:true,form:await createAdmissionForm(env,auth,tenantId,await body())},201);
    const formStatus=path.match(/^\/api\/enterprise\/admissions\/forms\/([^/]+)\/status$/);
    if(formStatus&&request.method==='PUT')
      return json({ok:true,form:await setAdmissionFormStatus(env,auth,tenantId,decodeURIComponent(formStatus[1]),await body())});
    if(path==='/api/enterprise/admissions'&&request.method==='GET')
      return json({ok:true,admissions:await listAdmissions(env,auth,tenantId,{status:url.searchParams.get('status'),form_id:url.searchParams.get('form_id')})});
    const entscheidung=path.match(/^\/api\/enterprise\/admissions\/([^/]+)\/decision$/);
    if(entscheidung&&request.method==='POST')
      return json({ok:true,admission:await decideAdmission(env,auth,tenantId,decodeURIComponent(entscheidung[1]),await body())});
    const uebernahme=path.match(/^\/api\/enterprise\/admissions\/([^/]+)\/enroll$/);
    if(uebernahme&&request.method==='POST')
      return json({ok:true,admission:await enrollAdmission(env,auth,tenantId,decodeURIComponent(uebernahme[1]),await body())});
    const nachricht=path.match(/^\/api\/enterprise\/admissions\/([^/]+)\/messages$/);
    if(nachricht&&request.method==='GET')
      return json({ok:true,verlauf:await bewerbungsverlauf(env,auth,tenantId,decodeURIComponent(nachricht[1]))});
    if(nachricht&&request.method==='POST')
      return json({ok:true,nachricht:await sendeBewerbernachricht(env,auth,tenantId,decodeURIComponent(nachricht[1]),await body())},201);
    const nachforderung=path.match(/^\/api\/enterprise\/admissions\/([^/]+)\/request-documents$/);
    if(nachforderung&&request.method==='POST')
      return json({ok:true,nachforderung:await fordereUnterlagenNach(env,auth,tenantId,decodeURIComponent(nachforderung[1]),await body())},201);
    const einzeln=path.match(/^\/api\/enterprise\/admissions\/([^/]+)$/);
    if(einzeln&&request.method==='GET')
      return json({ok:true,...await getAdmission(env,auth,tenantId,decodeURIComponent(einzeln[1]))});
    return json({ok:false,error:'ADMISSION_ROUTE_NOT_FOUND'},404);
  }catch(e){return fail(e);}
}

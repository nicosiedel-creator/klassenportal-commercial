import type { CoreAuthContext, Env } from './types.js';
import { roleInCourse } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Befehlszentrale in natuerlicher Sprache (K14).
//
// Eine Befehlszeile, die versteht, was man ihr sagt, ist bequem - und gefaehrlich. Sie bleibt
// ungefaehrlich unter drei Bedingungen, und alle drei sind hier eingebaut:
//
//  1. Sie SCHLAEGT VOR und fuehrt nichts aus. Dieselbe Zusage, die das Education-OS schon gibt:
//     "keine automatische irreversible Umbuchung ohne Bestaetigung". Dieses Modul schreibt
//     ausschliesslich in seine eigene Vorschlagstabelle.
//  2. Jeder Vorschlag zeigt auf eine BESTEHENDE Route aus einem geschlossenen Vorrat. Eine
//     Befehlszeile, die frei gebauten Code ausfuehrt, ist eine Fernsteuerung fuer jeden, der
//     eine Eingabe unterschieben kann.
//  3. Die Rechte der fragenden Person entscheiden, was ueberhaupt vorgeschlagen wird. Sonst
//     erfaehrt eine Teilnehmerin ueber die Vorschlagsliste, welche Verwaltungsfunktionen es gibt.

const clean=(v:unknown,n=1000)=>safeString(v,n);

export interface Befehl{
  schluessel:string;
  beschreibung:string;
  /** Die Route, die dieser Befehl bedeutet - Anzeige, nicht Ausfuehrung. */
  route:string;
  methode:'GET'|'POST';
  /** Wer ihn ueberhaupt vorgeschlagen bekommt. */
  rolle:'teilnehmer'|'class_admin'|'tenant_admin';
  /** Woran die Absicht erkannt wird. Bewusst Wortlisten statt eines Modells: das Ergebnis ist
   * nachvollziehbar, und eine Befehlszentrale, die raet, ist schlimmer als keine. */
  woerter:string[][];
  /** Ob der Vorschlag etwas veraendern wuerde. Eine Anzeige braucht keine Rueckfrage. */
  veraendert:boolean;
}

export const BEFEHLE:Befehl[]=[
  {schluessel:'meine_fehlzeiten',beschreibung:'Meine Fehlzeiten anzeigen',route:'/api/personal/attendance',methode:'GET',
    rolle:'teilnehmer',woerter:[['fehlzeit','fehlzeiten','fehltage','abwesenheit'],['mein','meine','ich']],veraendert:false},
  {schluessel:'mein_lernplan',beschreibung:'Meinen Lernplan anzeigen',route:'/api/personal/learning-plans',methode:'GET',
    rolle:'teilnehmer',woerter:[['lernplan','lernplaene','lernen']],veraendert:false},
  {schluessel:'meine_meldungen',beschreibung:'Meine Meldungen im Helpdesk anzeigen',route:'/api/personal/helpdesk/tickets',methode:'GET',
    rolle:'teilnehmer',woerter:[['meldung','meldungen','ticket','tickets','problem']],veraendert:false},
  {schluessel:'ueberfaellige_tickets',beschreibung:'Überfällige Meldungen im Helpdesk anzeigen',route:'/api/helpdesk/tickets',methode:'GET',
    rolle:'class_admin',woerter:[['ueberfaellig','überfällig','offen','faellig','fällig'],['meldung','meldungen','ticket','tickets','helpdesk']],veraendert:false},
  {schluessel:'pruefungsplan',beschreibung:'Prüfungsplan einer Prüfung anzeigen',route:'/api/exams/{exam_id}/sittings',methode:'GET',
    rolle:'class_admin',woerter:[['pruefung','prüfung','pruefungen','klausur'],['plan','raum','aufsicht','sitzung']],veraendert:false},
  {schluessel:'lizenzlauf',beschreibung:'Ablaufende Bildlizenzen anzeigen',route:'/api/media/licence-check',methode:'GET',
    rolle:'class_admin',woerter:[['lizenz','lizenzen','bildrechte'],['ablauf','abgelaufen','pruefen','prüfen','laufen']],veraendert:false},
  {schluessel:'laufbahn_offen',beschreibung:'Offene Kurswechsel und Unterbrechungen anzeigen',route:'/api/enrollment-transitions',methode:'GET',
    rolle:'class_admin',woerter:[['wechsel','unterbrechung','laufbahn','wiederaufnahme']],veraendert:false},
  {schluessel:'vorlage_anlegen',beschreibung:'Ein Anschreiben anlegen',route:'/api/communication-templates',methode:'POST',
    rolle:'class_admin',woerter:[['anschreiben','vorlage','aushang','elternbrief'],['anlegen','erstellen','neu','schreiben']],veraendert:true},
  {schluessel:'ausfallpruefung',beschreibung:'Prüfen, ob der Betrieb an einer Person hängt',route:'/api/operations/duties',methode:'GET',
    rolle:'tenant_admin',woerter:[['vertretung','ausfall','betrieb','notfallzugriff'],['pruefen','prüfen','wer','hängt','haengt']],veraendert:false},
  {schluessel:'ki_stand',beschreibung:'KI-Nutzung und Kosten anzeigen',route:'/api/ai/status',methode:'GET',
    rolle:'tenant_admin',woerter:[['ki','modell','modelle'],['kosten','stand','nutzung','verbrauch']],veraendert:false},
];

const RANG:Record<string,number>={teilnehmer:0,class_admin:1,tenant_admin:2};

function eigenerRang(auth:CoreAuthContext,courseId?:string):number{
  if(auth.isPlatformAdmin||auth.role==='tenant_admin')return 2;
  const rolle=courseId?roleInCourse(auth,courseId):auth.role;
  return rolle==='class_admin'?1:0;
}

/** Wortnahe Normalisierung. Umlaute bleiben - sie gehoeren zum Wort. */
const zerlege=(text:string)=>String(text??'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').split(' ').filter(Boolean);

/**
 * Deuten - und beim geringsten Zweifel fragen statt raten.
 *
 * Die Sicherheit ist der Anteil der Wortgruppen, die getroffen wurden. Trifft mehr als ein
 * Befehl gleich gut, ist die Eingabe unklar: dann wird die Auswahl vorgelegt. Eine
 * Befehlszentrale, die bei Gleichstand eines auswaehlt, macht irgendwann das Falsche - und
 * niemand weiss warum.
 */
export function deute(eingabe:string,rang:number){
  const woerter=new Set(zerlege(eingabe));
  // Deutsche Beugung: "ueberfaelligen" soll "ueberfaellig" treffen. Vorsilbenvergleich ab vier
  // Zeichen - bei kuerzeren Woertern traefe er zu viel.
  const passt=(w:string)=>woerter.has(w)||(w.length>=4&&[...woerter].some(t=>t.startsWith(w)));
  const treffer=BEFEHLE
    .filter(b=>RANG[b.rolle]<=rang)
    .map(b=>{
      const getroffen=b.woerter.filter(gruppe=>gruppe.some(passt)).length;
      return{befehl:b,getroffen,sicherheit:b.woerter.length?Math.round(getroffen/b.woerter.length*100):0};
    })
    .filter(t=>t.sicherheit>0)
    // Bei gleicher Trefferquote gewinnt die SPEZIFISCHERE Deutung - die, die mehr Wortgruppen
    // getroffen hat. "Ueberfaellige Meldungen" von einer Verwaltung meint die Warteschlange,
    // nicht die eigenen zwei Tickets.
    .sort((a,b)=>b.sicherheit-a.sicherheit||b.getroffen-a.getroffen);
  if(!treffer.length)return{status:'abgelehnt' as const,treffer:[]};
  const beste=treffer[0].sicherheit,besteTiefe=treffer[0].getroffen;
  const gleichauf=treffer.filter(t=>t.sicherheit===beste&&t.getroffen===besteTiefe);
  // Eine Eingabe, die nur eine von zwei Wortgruppen trifft, ist ein Stichwort, keine Anweisung.
  if(beste<100||gleichauf.length>1)return{status:'unklar' as const,treffer:gleichauf.slice(0,5)};
  return{status:'vorgeschlagen' as const,treffer:[treffer[0]]};
}

/**
 * Einen Vorschlag erzeugen.
 *
 * Schreibt AUSSCHLIESSLICH in command_interpretations. Diese Funktion fuehrt nichts aus; die
 * Route wird genannt, damit die Oberflaeche sie nach Bestaetigung mit den ueblichen
 * Rechtepruefungen aufruft.
 */
export async function schlageVor(env:Env,auth:CoreAuthContext,tenantId:string,eingabe:string,courseId?:string){
  const text=clean(eingabe,1000);
  if(text.trim().length<3)throw new Error('BEFEHL_EINGABE_ERFORDERLICH');
  const rang=eigenerRang(auth,courseId);
  const gedeutet=deute(text,rang);
  const ts=nowIso(),vorschlagId=id('bef_');
  const erster=gedeutet.treffer[0];
  await env.DB.prepare('INSERT INTO command_interpretations(id,tenant_id,user_id,eingabe,absicht,aktion,parameter_json,sicherheit,status,hinweis,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
    .bind(vorschlagId,tenantId,auth.userId,text,
      gedeutet.status==='vorgeschlagen'?erster.befehl.beschreibung:null,
      gedeutet.status==='vorgeschlagen'?erster.befehl.schluessel:null,
      JSON.stringify(courseId?{course_id:courseId}:{}),
      erster?.sicherheit??0,gedeutet.status,
      gedeutet.status==='abgelehnt'?'BEFEHL_NICHT_VERSTANDEN':gedeutet.status==='unklar'?'BEFEHL_MEHRDEUTIG':null,ts).run();
  return{id:vorschlagId,status:gedeutet.status,
    vorschlaege:gedeutet.treffer.map(t=>({schluessel:t.befehl.schluessel,beschreibung:t.befehl.beschreibung,
      route:t.befehl.route,methode:t.befehl.methode,veraendert:t.befehl.veraendert,sicherheit:t.sicherheit})),
    // Der Satz, der in der Oberflaeche stehen muss: hier passiert noch nichts.
    ausgefuehrt:false};
}

/**
 * Eine Deutung bestaetigen.
 *
 * Auch das fuehrt NICHTS aus - es haelt nur fest, welche Route die Person gemeint hat. Die
 * Ausfuehrung ist der ganz normale Aufruf dieser Route, mit allen Rechtepruefungen, die dort
 * ohnehin stehen.
 */
export async function bestaetigeDeutung(env:Env,auth:CoreAuthContext,tenantId:string,vorschlagId:string,schluessel:string){
  const v=await env.DB.prepare('SELECT id,user_id,status FROM command_interpretations WHERE id=? AND tenant_id=?')
    .bind(clean(vorschlagId,120),tenantId).first<{id:string;user_id:string;status:string}>();
  if(!v)throw new Error('BEFEHL_NICHT_GEFUNDEN');
  // Eine fremde Deutung zu bestaetigen hiesse, jemandem eine Handlung unterzuschieben.
  if(v.user_id!==auth.userId)throw new Error('BEFEHL_FREMDE_DEUTUNG');
  if(v.status!=='vorgeschlagen'&&v.status!=='unklar')throw new Error('BEFEHL_NICHT_OFFEN');
  const befehl=BEFEHLE.find(b=>b.schluessel===clean(schluessel,60));
  if(!befehl)throw new Error('BEFEHL_UNBEKANNT');
  // Auch bei der Bestaetigung gilt der Rang - zwischen Vorschlag und Bestaetigung kann sich
  // die Rolle geaendert haben.
  if(RANG[befehl.rolle]>eigenerRang(auth))throw new Error('BEFEHL_NICHT_ERLAUBT');
  const ts=nowIso();
  await env.DB.prepare("UPDATE command_interpretations SET status='bestaetigt',aktion=?,absicht=?,bestaetigt_am=? WHERE id=? AND tenant_id=?")
    .bind(befehl.schluessel,befehl.beschreibung,ts,v.id,tenantId).run();
  return{route:befehl.route,methode:befehl.methode,veraendert:befehl.veraendert,ausgefuehrt:false};
}

/** Was jemand zuletzt gefragt hat - und was daraus geworden ist. */
export async function befehlsverlauf(env:Env,auth:CoreAuthContext,tenantId:string){
  return ((await env.DB.prepare('SELECT id,eingabe,absicht,aktion,sicherheit,status,hinweis,created_at FROM command_interpretations WHERE tenant_id=? AND user_id=? ORDER BY created_at DESC LIMIT 50')
    .bind(tenantId,auth.userId).all()).results)??[];
}

/** Welche Befehle diese Person ueberhaupt kennt - fuer die Hilfe im Eingabefeld. */
export function verfuegbareBefehle(auth:CoreAuthContext,courseId?:string){
  const rang=eigenerRang(auth,courseId);
  return BEFEHLE.filter(b=>RANG[b.rolle]<=rang).map(b=>({schluessel:b.schluessel,beschreibung:b.beschreibung,veraendert:b.veraendert}));
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Simulationsmodus vor der Aktivierung (W1).
//
// Bisher wurde eine Regel angelegt und war scharf. Bei einer Regel, die Bescheinigungen vorbereitet
// oder Menschen anschreibt, ist das ein Blindflug ueber echte Daten: Man sieht erst hinterher, wen
// sie erwischt hat - und eine versehentlich an 300 Leute gegangene Mail nimmt niemand zurueck.
//
// Deshalb hier zwei Dinge, die zusammengehoeren:
//  1. Der Modus 'simulation': die Regel wertet ihre Ausloeser aus und schreibt auf, was sie TUN
//     WUERDE - sie tut es nicht.
//  2. Die Aktivierung setzt voraus, dass es diesen Probelauf gegeben hat. Wer ohne Probelauf scharf
//     schalten will, muss das ausdruecklich begruenden; die Begruendung steht im Protokoll.
//
// Das ist bewusst unbequem. Genau dafuer ist es da.

export const MODI=['aktiv','simulation','aus'] as const;
const clean=(v:unknown,n=2000)=>safeString(v,n);

export async function setzeRegelmodus(env:Env,auth:CoreAuthContext,tenantId:string,ruleId:string,modus:string){
  requireRole(auth,'tenant_admin');
  if(!MODI.includes(modus as never))throw new Error('WORKFLOW_MODUS_UNGUELTIG');
  const ts=nowIso();
  const r=await env.DB.prepare('UPDATE workflow_rules SET modus=?,enabled=?,updated_by=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(modus,modus==='aus'?0:1,auth.userId,ts,ruleId,tenantId).run();
  if(!r.meta?.changes)throw new Error('WORKFLOW_REGEL_NICHT_GEFUNDEN');
  await audit(env.DB,auth.userId,'workflow.mode_set',tenantId,undefined,'workflow_rule',ruleId,{modus});
  return{modus};
}

/**
 * Was die Regel im Probelauf getan haette.
 *
 * Die Eintraege sind je Ausloeser eindeutig: ein zweiter Probelauf ueber denselben Ausloeser
 * verdoppelt die Liste nicht.
 */
export async function haltSimulationFest(env:Env,tenantId:string,ruleId:string,triggerKey:string,wuerde:string,daten?:unknown){
  await env.DB.prepare('INSERT INTO workflow_simulations(id,tenant_id,rule_id,trigger_key,wuerde,wuerde_json,erfasst_am) VALUES(?,?,?,?,?,?,?) ON CONFLICT(rule_id,trigger_key) DO NOTHING')
    .bind(id('wsim_'),tenantId,ruleId,triggerKey,wuerde.slice(0,500),daten?JSON.stringify(daten):null,nowIso()).run();
}

export async function simulationsbericht(env:Env,auth:CoreAuthContext,tenantId:string,ruleId:string){
  requireRole(auth,'class_admin');
  const regel=await env.DB.prepare('SELECT id,name,trigger_type,action_type,modus,enabled,aktiviert_am FROM workflow_rules WHERE id=? AND tenant_id=?').bind(ruleId,tenantId).first<Record<string,unknown>>();
  if(!regel)throw new Error('WORKFLOW_REGEL_NICHT_GEFUNDEN');
  const zeilen=((await env.DB.prepare('SELECT trigger_key,wuerde,wuerde_json,erfasst_am FROM workflow_simulations WHERE rule_id=? ORDER BY erfasst_am DESC LIMIT 200').bind(ruleId).all()).results)??[];
  return{regel,faelle:zeilen,anzahl:zeilen.length};
}

/**
 * Scharf schalten.
 *
 * Ohne Probelauf nur mit ausdruecklicher Begruendung - und die steht anschliessend im Protokoll.
 * Eine Regel, die ueber echte Menschen laeuft, soll nicht versehentlich scharf werden.
 */
export async function aktiviereRegel(env:Env,auth:CoreAuthContext,tenantId:string,ruleId:string,begruendungOhneProbelauf?:unknown){
  requireRole(auth,'tenant_admin');
  const regel=await env.DB.prepare('SELECT id,modus FROM workflow_rules WHERE id=? AND tenant_id=?').bind(ruleId,tenantId).first<{id:string;modus:string}>();
  if(!regel)throw new Error('WORKFLOW_REGEL_NICHT_GEFUNDEN');
  const proben=Number((await env.DB.prepare('SELECT COUNT(*) n FROM workflow_simulations WHERE rule_id=?').bind(ruleId).first<{n:number}>())?.n??0);
  const grund=clean(begruendungOhneProbelauf,500);
  if(!proben&&grund.length<20)throw new Error('WORKFLOW_PROBELAUF_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.prepare("UPDATE workflow_rules SET modus='aktiv',enabled=1,aktiviert_von=?,aktiviert_am=?,updated_by=?,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(auth.userId,ts,auth.userId,ts,ruleId,tenantId).run();
  await audit(env.DB,auth.userId,'workflow.activated',tenantId,undefined,'workflow_rule',ruleId,{probelaeufe:proben,ohne_probelauf_grund:proben?null:grund});
  return{modus:'aktiv',probelaeufe:proben,ohne_probelauf:!proben};
}

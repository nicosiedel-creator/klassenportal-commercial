import type { CoreAuthContext, Env } from './types.js';
import { sperrlage } from './legal-hold-retention.js';
import { audit } from './audit.js';
import { enforcePublicWriteLimit, storeIntakeSubmissionDocuments } from './intake-center.js';
import { applyParticipantImport, ersatzAdresse, istErsatzAdresse, previewParticipantImport } from './participant-document-import.js';
import { b64, id, normalizeEmail, nowIso, randomBytes, safeString } from './utils.js';

// Bewerber- und Anmeldetrichter.
//
// Der Trichter ist der Eintritt in den Datenbestand: ein Interessent fuellt ein oeffentliches
// Formular aus, ohne Konto, und laedt Nachweise hoch. Daraus entsteht eine Bewerbung mit Status.
// Erst die Zusage macht daraus eine teilnehmende Person - und zwar ueber genau denselben Weg, den
// der Teilnehmerimport schon geht, damit niemand dieselben Angaben ein zweites Mal eintippt.
//
// Wiederverwendet statt daneben gebaut:
//   - die Ablage der Nachweise: intake_batches/intake_documents ueber
//     storeIntakeSubmissionDocuments (dieselben Groessen- und Typgrenzen, dieselbe Ausgabe als
//     Anhang, dieselbe Aufraeumregel).
//   - die Ratenbegrenzung: enforcePublicWriteLimit auf intake_public_rate_limits.
//   - die Uebernahme bei Zusage: previewParticipantImport/applyParticipantImport und darueber
//     createTenantUser samt Ersatzadresse fuer Personen ohne eigene E-Mail.
//
// Der oeffentliche Pfad ist der heikelste Teil des Produkts, weil er unauthentifiziert schreibt.
// Deshalb gilt hier durchgaengig:
//   - er liest nur das eine, ausdruecklich veroeffentlichte Formular und sonst keine Kundendaten;
//   - seine Antwort ist unabhaengig davon, was schon im Bestand steht;
//   - bis zur Zusage entsteht kein users-Eintrag und keine Mitgliedschaft.

// Grenzen des oeffentlichen Schreibpfads. Bewusst enger als beim angemeldeten Upload-Link: dort
// laedt ein bekannter Traeger seine Vertragsmappe hoch, hier ein Unbekannter ein Zeugnis.
export const MAX_ADMISSION_FILES=8;
export const MAX_ADMISSION_DOCUMENT_BYTES=10*1024*1024;
export const MAX_ADMISSION_TOTAL_BYTES=25*1024*1024;
const BEWERBUNGEN_JE_ABSENDER_STUNDE=5;
const BEWERBUNGEN_JE_MANDANT_STUNDE=200;
const MAX_NOTIZ_ZEICHEN=2000;

// Erlaubte Nachweise. Eine ausdrueckliche Liste statt "alles, was der Auswerter kennt": der
// Auswerter darf Archive auspacken und Tabellen lesen, was fuer einen Fremden am oeffentlichen
// Formular nichts zu suchen hat. HTML, RTF und SVG stehen bewusst NICHT darin - eine Datei, die
// ein Browser als Markup ausfuehren koennte, wird hier gar nicht erst angenommen.
const ERLAUBTE_ENDUNGEN=['.pdf','.jpg','.jpeg','.png','.webp','.heic','.docx','.odt','.txt','.csv','.xlsx'];
const ERLAUBTE_TYPEN=new Set(['application/pdf','image/jpeg','image/png','image/webp','image/heic','image/heif',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.oasis.opendocument.text',
  'text/plain','text/csv','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/octet-stream','']);

type Formular={id:string;tenant_id:string;course_id:string|null;title:string;intro:string|null;documents_required:number;
  max_applications:number;application_count:number;document_retention_days:number;status:string};
type Bewerbung={id:string;tenant_id:string;form_id:string;course_id:string|null;reference_code:string;applicant_name:string;
  applicant_email:string|null;status:string;intake_batch_id:string|null;enrolled_user_id:string|null};

// Wer Bewerbungen sehen und entscheiden darf - dieselbe Schwelle wie fuer die Teilnehmerpflege,
// denn eine Bewerbung wird genau dort zur Teilnahme.
function requireBewerbungsPruefer(auth:CoreAuthContext){if(auth.isPlatformAdmin||auth.role==='tenant_admin'||auth.permissions?.includes('participants.manage'))return;throw new Error('FORBIDDEN_PERMISSION');}
// Ein Formular oeffentlich zu schalten heisst, einen unauthentifizierten Schreibpfad in den
// eigenen Mandanten zu oeffnen. Das darf nur die Mandantenleitung.
function requireBewerbungsAdmin(auth:CoreAuthContext){if(auth.isPlatformAdmin||auth.role==='tenant_admin')return;throw new Error('TENANT_ADMIN_REQUIRED');}

function zufallsKennung(laenge:number){return b64(randomBytes(laenge*2)).replace(/[^a-zA-Z0-9]/g,'').slice(0,laenge);}
// Die Vorgangsnummer ist zufaellig und nicht fortlaufend: aus einer fortlaufenden Nummer liesse
// sich ablesen, wie viele sich beworben haben und in welcher Reihenfolge.
function referenznummer(){return `BW-${zufallsKennung(12).toUpperCase()}`;}
function oeffentlicherSchluessel(){return `bewerbung-${zufallsKennung(20).toLowerCase()}`;}
function text(v:unknown,max:number){return safeString(v,max).replace(/\s+/g,' ').trim();}
function alsDatum(v:unknown):string|null{
  const s=safeString(v,40).trim();
  let m=s.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);
  if(m)return`${m[3]}-${String(m[2]).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}`;
  m=s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  return m?`${m[1]}-${m[2]}-${m[3]}`:null;
}

// --- oeffentlicher Pfad -----------------------------------------------------------------------

// Das Formular wird ueber seinen zufaelligen, nicht zu erratenden Schluessel gefunden - dieselbe
// Bauart wie beim sicheren Upload-Link. Diese eine Abfrage kann keinen Mandantenfilter tragen,
// weil sie den Mandanten gerade erst bestimmt; ab hier bindet jede weitere Abfrage form.tenant_id.
//
// Ein Formular im Entwurf und ein geschlossenes Formular antworten wie ein nicht vorhandenes.
// Sonst waere aus der Antwort ablesbar, welche Schluessel es gibt.
async function veroeffentlichtesFormular(env:Env,slugRoh:string):Promise<Formular>{
  const slug=safeString(slugRoh,80).toLowerCase();
  if(!/^[a-z0-9-]{8,80}$/.test(slug))throw new Error('ADMISSION_FORM_NOT_FOUND');
  const form=await env.DB.prepare("SELECT id,tenant_id,course_id,title,intro,documents_required,max_applications,application_count,document_retention_days,status FROM admission_forms WHERE public_slug=? AND status='published'").bind(slug).first<Formular>();
  if(!form)throw new Error('ADMISSION_FORM_NOT_FOUND');
  return form;
}

// Was der oeffentliche Pfad ueberhaupt ausgibt. Eine feste, im Quelltext stehende Auswahl: kein
// Bezeichner, keine Zahl der bisherigen Bewerbungen, kein Kurs, kein Mandant. Wer den Link kennt,
// erfaehrt genau das, was der Traeger veroeffentlicht hat, und sonst nichts.
export async function getPublicAdmissionForm(env:Env,slug:string){
  const form=await veroeffentlichtesFormular(env,slug);
  return{
    title:form.title,
    intro:form.intro,
    documents_required:!!form.documents_required,
    max_documents:MAX_ADMISSION_FILES,
    max_document_mb:Math.round(MAX_ADMISSION_DOCUMENT_BYTES/(1024*1024)),
    accepted_file_types:ERLAUBTE_ENDUNGEN,
    fields:['name','email','birth_date','phone','note'],
  };
}

async function leseAntrag(request:Request):Promise<{felder:Record<string,unknown>;dateien:File[]}>{
  const typ=(request.headers.get('content-type')||'').toLowerCase();
  if(typ.includes('multipart/form-data')){
    const fd=await request.formData(),felder:Record<string,unknown>={};
    for(const [k,v] of (fd as unknown as {entries():Iterable<[string,unknown]>}).entries())if(typeof v==='string')felder[k]=v;
    return{felder,dateien:fd.getAll('files').filter(x=>x instanceof File) as File[]};
  }
  try{const j=await request.json();return{felder:j&&typeof j==='object'?j as Record<string,unknown>:{},dateien:[]};}
  catch{return{felder:{},dateien:[]};}
}

function nachweisErlaubt(file:File){
  const name=String(file.name||'').toLowerCase(),typ=String(file.type||'').toLowerCase().split(';')[0].trim();
  return ERLAUBTE_ENDUNGEN.some(x=>name.endsWith(x))&&ERLAUBTE_TYPEN.has(typ);
}

// Eine Bewerbung entgegennehmen. Der einzige unauthentifizierte Schreibpfad dieses Moduls.
export async function submitPublicAdmission(env:Env,slug:string,request:Request){
  const form=await veroeffentlichtesFormular(env,slug),tenantId=String(form.tenant_id),formId=String(form.id);
  // Zwei Begrenzungen, weil eine allein nicht genuegt: die je Absender haelt den einzelnen
  // Wiederholer auf, die je Mandant den verteilten Andrang aus vielen Adressen. Beide laufen
  // ueber dieselbe Tabelle und dieselbe Fensterlogik wie der vorhandene Eingangskanal.
  const absender=request.headers.get('CF-Connecting-IP')||'unbekannt';
  await enforcePublicWriteLimit(env,`bewerbung:absender:${formId}:${absender}`,BEWERBUNGEN_JE_ABSENDER_STUNDE,'ADMISSION_RATE_LIMITED');
  await enforcePublicWriteLimit(env,`bewerbung:mandant:${tenantId}`,BEWERBUNGEN_JE_MANDANT_STUNDE,'ADMISSION_RATE_LIMITED');
  if(Number(form.application_count)>=Number(form.max_applications))throw new Error('ADMISSION_FORM_CLOSED');

  const{felder,dateien}=await leseAntrag(request);
  const name=text(felder.name??felder.display_name,200);
  if(!name)throw new Error('ADMISSION_NAME_REQUIRED');
  const angegebene=normalizeEmail(felder.email);
  if(angegebene&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(angegebene))throw new Error('ADMISSION_EMAIL_INVALID');
  const geburtsdatum=alsDatum(felder.birth_date??felder.geburtsdatum);
  // Ohne eine der beiden Angaben laesst sich spaeter keine Person daraus machen - weder mit
  // Portalzugang noch ohne. Das faellt jetzt auf und nicht erst bei der Zusage.
  if(!angegebene&&!geburtsdatum)throw new Error('ADMISSION_CONTACT_REQUIRED');
  // Ein Bewerber ohne eigene Adresse bekommt schon hier die Ersatzadresse des Teilnehmerimports.
  // Das Geburtsdatum selbst wird nirgends gespeichert: es geht nur als Einwegschluessel in die
  // Adresse ein und ist aus ihr nicht zurueckzurechnen.
  const email=angegebene||await ersatzAdresse(tenantId,name,geburtsdatum as string);

  if(dateien.length>MAX_ADMISSION_FILES)throw new Error('ADMISSION_TOO_MANY_DOCUMENTS');
  if(dateien.some(f=>!nachweisErlaubt(f)))throw new Error('ADMISSION_DOCUMENT_REJECTED');
  if(form.documents_required&&!dateien.length)throw new Error('ADMISSION_DOCUMENTS_REQUIRED');

  // Der Duplikathinweis ist fuer die Pruefung, nie fuer den Absender. Er wird deshalb IMMER
  // ermittelt - auch wenn niemand danach fragt: liefe die Abfrage nur in einem der beiden Faelle,
  // waere schon an der Antwortzeit ablesbar, ob die Adresse bekannt ist.
  const doppelt=await env.DB.prepare('SELECT 1 ok FROM admissions WHERE tenant_id=? AND form_id=? AND applicant_email=? LIMIT 1').bind(tenantId,formId,email).first<{ok:number}>();

  const referenz=referenznummer(),admissionId=id('adm_'),ts=nowIso();
  let batchId:string|null=null,gespeichert=0;
  if(dateien.length){
    const abgelegt=await storeIntakeSubmissionDocuments(env,tenantId,dateien,{
      subject:`Bewerbung ${referenz}`,sender:`admission-form:${formId}`,courseId:form.course_id?String(form.course_id):null,
      retentionDays:Number(form.document_retention_days)||90,maxFiles:MAX_ADMISSION_FILES,
      maxFileBytes:MAX_ADMISSION_DOCUMENT_BYTES,maxTotalBytes:MAX_ADMISSION_TOTAL_BYTES});
    batchId=abgelegt.batch_id;gespeichert=abgelegt.stored;
    if(!gespeichert)throw new Error('ADMISSION_DOCUMENT_REJECTED');
  }

  // Drei Anweisungen, ein Stapel: auf Cloudflare zaehlt das als EINE Unteranfrage. Das ist der
  // Unterschied zwischen einem Formular, das unter Andrang traegt, und einem, das an der Grenze
  // von 1000 Unteranfragen je Aufruf zerbricht.
  await env.DB.batch([
    env.DB.prepare("INSERT INTO admissions(id,tenant_id,form_id,course_id,reference_code,applicant_name,applicant_email,applicant_phone,applicant_note,status,possible_duplicate,intake_batch_id,document_count,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,'received',?,?,?,?,?)")
      .bind(admissionId,tenantId,formId,form.course_id?String(form.course_id):null,referenz,name,email,
        text(felder.phone??felder.telefon,60)||null,safeString(felder.note??felder.nachricht,MAX_NOTIZ_ZEICHEN)||null,
        doppelt?1:0,batchId,gespeichert,ts,ts),
    env.DB.prepare('UPDATE admission_forms SET application_count=application_count+1,updated_at=? WHERE tenant_id=? AND id=?').bind(ts,tenantId,formId),
    // Kein audit_log: dort steht ein handelnder Mensch. Hier handelt niemand aus dem Portal, also
    // gehoert der Vorgang in dasselbe Ereignisbuch wie der uebrige automatische Eingang.
    env.DB.prepare('INSERT INTO automation_events(id,tenant_id,event_type,source_type,source_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)')
      .bind(id('aev_'),tenantId,'admission.received','admission',admissionId,JSON.stringify({documents:gespeichert,possible_duplicate:!!doppelt}),ts),
  ]);

  // Die Antwort ist in jedem Fall dieselbe: sie nennt die Vorgangsnummer und den Stand, sonst
  // nichts. Ob die Adresse dem Portal schon bekannt ist, ob es zu ihr eine frueherer Bewerbung
  // gibt, ob eine Person dieses Namens teilnimmt - davon steht hier nichts, und es wird auf
  // diesem Pfad auch nirgends nachgesehen.
  return{reference:referenz,status:'eingegangen',received_at:ts};
}

// --- Verwaltung -------------------------------------------------------------------------------

export async function createAdmissionForm(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireBewerbungsAdmin(auth);
  const title=text(input.title,160);if(!title)throw new Error('ADMISSION_FORM_TITLE_REQUIRED');
  const courseId=safeString(input.course_id,100)||null;
  if(courseId&&!await env.DB.prepare('SELECT id FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,courseId).first())throw new Error('COURSE_NOT_FOUND');
  const formId=id('adf_'),slug=oeffentlicherSchluessel(),ts=nowIso();
  const max=Math.max(1,Math.min(100000,Math.round(Number(input.max_applications||500))));
  const aufbewahrung=Math.max(1,Math.min(365,Math.round(Number(input.document_retention_days||90))));
  await env.DB.prepare("INSERT INTO admission_forms(id,tenant_id,course_id,title,intro,public_slug,status,documents_required,max_applications,application_count,document_retention_days,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,'draft',?,?,0,?,?,?,?)")
    .bind(formId,tenantId,courseId,title,safeString(input.intro,2000)||null,slug,input.documents_required===true?1:0,max,aufbewahrung,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'admission.form.created',tenantId,courseId??undefined,'admission_form',formId,{title,courseId,max});
  return{id:formId,title,status:'draft',public_slug:slug,course_id:courseId,max_applications:max,document_retention_days:aufbewahrung};
}

// Veroeffentlichen, schliessen, zurueck in den Entwurf. Ein geschlossenes Formular nimmt nichts
// mehr an und ist von aussen nicht mehr von einem nie vorhandenen zu unterscheiden.
export async function setAdmissionFormStatus(env:Env,auth:CoreAuthContext,tenantId:string,formId:string,input:Record<string,unknown>){
  requireBewerbungsAdmin(auth);
  const status=String(input.status||'');
  if(!['draft','published','closed'].includes(status))throw new Error('ADMISSION_FORM_STATUS_INVALID');
  // Erst lesen, dann schreiben: die Zeitpunkte haengen vom bisherigen Stand ab, und ein
  // Formular eines fremden Mandanten darf gar nicht erst gefunden werden.
  const vorher=await env.DB.prepare('SELECT id,status,published_at FROM admission_forms WHERE tenant_id=? AND id=?').bind(tenantId,formId).first<{id:string;status:string;published_at:string|null}>();
  if(!vorher)throw new Error('ADMISSION_FORM_NOT_FOUND');
  const ts=nowIso();
  const veroeffentlicht=status==='published'?(vorher.published_at||ts):vorher.published_at;
  const geschlossen=status==='closed'?ts:null;
  await env.DB.prepare('UPDATE admission_forms SET status=?,published_at=?,closed_at=?,updated_at=? WHERE tenant_id=? AND id=?')
    .bind(status,veroeffentlicht,geschlossen,ts,tenantId,formId).run();
  await audit(env.DB,auth.userId,'admission.form.status',tenantId,undefined,'admission_form',formId,{status});
  return{id:formId,status};
}

export async function listAdmissionForms(env:Env,auth:CoreAuthContext,tenantId:string,origin:string){
  requireBewerbungsPruefer(auth);
  const rows=(await env.DB.prepare('SELECT id,course_id,title,intro,public_slug,status,documents_required,max_applications,application_count,document_retention_days,created_at,published_at,closed_at FROM admission_forms WHERE tenant_id=? ORDER BY created_at DESC LIMIT 200').bind(tenantId).all<Record<string,unknown>>()).results??[];
  // Die Adresse, die ein Mensch bekommt - die Seite, nicht die Schnittstelle. Vorher stand hier
  // /api/bewerbung/<slug>: wer den Link weitergab, schickte Bewerber auf eine JSON-Antwort.
  return rows.map(x=>({...x,public_url:`${origin}/bewerbung/${String(x.public_slug)}`}));
}

export async function listAdmissions(env:Env,auth:CoreAuthContext,tenantId:string,filter:Record<string,string|null>){
  requireBewerbungsPruefer(auth);
  const status=String(filter.status||''),formId=String(filter.form_id||'');
  const bedingungen=['tenant_id=?'],werte:unknown[]=[tenantId];
  if(['received','in_review','offered','waitlisted','rejected','enrolled'].includes(status)){bedingungen.push('status=?');werte.push(status);}
  if(formId){bedingungen.push('form_id=?');werte.push(formId);}
  const rows=(await env.DB.prepare(`SELECT id,form_id,course_id,reference_code,applicant_name,applicant_email,applicant_phone,status,possible_duplicate,document_count,decision_note,decided_at,enrolled_user_id,enrolled_at,created_at,updated_at FROM admissions WHERE ${bedingungen.join(' AND ')} ORDER BY created_at DESC LIMIT 500`).bind(...werte).all<Record<string,unknown>>()).results??[];
  return rows.map(x=>({...x,no_portal_access:istErsatzAdresse(String(x.applicant_email||''))}));
}

async function ladeBewerbung(env:Env,tenantId:string,admissionId:string):Promise<Bewerbung>{
  const row=await env.DB.prepare('SELECT id,tenant_id,form_id,course_id,reference_code,applicant_name,applicant_email,status,intake_batch_id,enrolled_user_id FROM admissions WHERE tenant_id=? AND id=?').bind(tenantId,admissionId).first<Bewerbung>();
  if(!row)throw new Error('ADMISSION_NOT_FOUND');
  return row;
}

export async function getAdmission(env:Env,auth:CoreAuthContext,tenantId:string,admissionId:string){
  requireBewerbungsPruefer(auth);
  const row=await env.DB.prepare('SELECT * FROM admissions WHERE tenant_id=? AND id=?').bind(tenantId,admissionId).first<Record<string,unknown>>();
  if(!row)throw new Error('ADMISSION_NOT_FOUND');
  // Die Nachweise liegen im vorhandenen Eingang. Ausgegeben werden nur ihre Kennungen; der Inhalt
  // laeuft ueber die bestehende Dokumentroute, die ihn als Anhang und mit nosniff ausliefert.
  const documents=row.intake_batch_id
    ?(await env.DB.prepare("SELECT id,filename,content_type,size_bytes,extraction_state,created_at FROM intake_documents WHERE tenant_id=? AND batch_id=? AND extraction_state<>'purged' ORDER BY created_at").bind(tenantId,String(row.intake_batch_id)).all<Record<string,unknown>>()).results??[]
    :[];
  return{admission:{...row,no_portal_access:istErsatzAdresse(String(row.applicant_email||''))},documents};
}

// Von wo nach wo eine Bewerbung wandern darf. Eine Absage ist endgueltig, und 'enrolled' setzt
// nur die Uebernahme - sonst stuende eine Bewerbung als uebernommen da, ohne dass jemand angelegt
// wurde.
const UEBERGAENGE:Record<string,string[]>={
  received:['in_review','offered','waitlisted','rejected'],
  in_review:['offered','waitlisted','rejected'],
  waitlisted:['in_review','offered','rejected'],
  offered:['waitlisted','rejected'],
  rejected:[],
  enrolled:[],
};

export async function decideAdmission(env:Env,auth:CoreAuthContext,tenantId:string,admissionId:string,input:Record<string,unknown>){
  requireBewerbungsPruefer(auth);
  const ziel=String(input.status||'');
  if(!Object.keys(UEBERGAENGE).includes(ziel))throw new Error('ADMISSION_STATUS_INVALID');
  const bewerbung=await ladeBewerbung(env,tenantId,admissionId);
  if(!UEBERGAENGE[bewerbung.status]?.includes(ziel))throw new Error('ADMISSION_TRANSITION_INVALID');
  const ts=nowIso(),notiz=safeString(input.note,1000)||null;
  await env.DB.prepare('UPDATE admissions SET status=?,decision_note=?,decided_by=?,decided_at=?,updated_at=? WHERE tenant_id=? AND id=?')
    .bind(ziel,notiz,auth.userId,ts,ts,tenantId,admissionId).run();
  await audit(env.DB,auth.userId,'admission.decided',tenantId,bewerbung.course_id??undefined,'admission',admissionId,{from:bewerbung.status,to:ziel});
  return{id:admissionId,status:ziel,decided_at:ts};
}

// Die Zusage in eine Teilnahme ueberfuehren.
//
// Hier wird bewusst NICHTS eigenes angelegt. Die Bewerbung wird zu genau einer Zeile, wie sie auch
// aus einer Teilnehmerliste kaeme, und geht durch previewParticipantImport/applyParticipantImport.
// Damit gelten fuer sie automatisch dieselben Regeln wie fuer jeden Import: createTenantUser findet
// ein vorhandenes Konto wieder statt es zu verdoppeln, eine Ersatzadresse bekommt keinen
// Portalzugang und keine Einladung, und jede angelegte Person steht anschliessend in
// participant_import_results - nachlesbar, wer wann woraus entstanden ist.
export async function enrollAdmission(env:Env,auth:CoreAuthContext,tenantId:string,admissionId:string,input:Record<string,unknown>){
  requireBewerbungsPruefer(auth);
  const bewerbung=await ladeBewerbung(env,tenantId,admissionId);
  if(bewerbung.status!=='offered')throw new Error('ADMISSION_NOT_OFFERED');
  const courseId=safeString(input.course_id,100)||(bewerbung.course_id?String(bewerbung.course_id):'');
  if(!courseId)throw new Error('ADMISSION_COURSE_REQUIRED');
  if(!await env.DB.prepare('SELECT id FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,courseId).first())throw new Error('COURSE_NOT_FOUND');
  const email=String(bewerbung.applicant_email||'');
  if(!email)throw new Error('ADMISSION_CONTACT_REQUIRED');

  const vorschau=await previewParticipantImport(env,auth,tenantId,{
    source_name:`Bewerbung ${bewerbung.reference_code}`,source_kind:'api',default_course_id:courseId,
    rows:[{display_name:bewerbung.applicant_name,email,course_id:courseId}]});
  const ergebnis=await applyParticipantImport(env,auth,tenantId,{batch_id:vorschau.batch_id,digest:vorschau.digest});
  const zeile=(ergebnis.results||[])[0] as{action?:string;user_id?:string;invitation_sent?:boolean}|undefined;
  if(!zeile?.user_id||zeile.action==='skipped')throw new Error('ADMISSION_ENROLLMENT_FAILED');

  const ts=nowIso();
  await env.DB.prepare("UPDATE admissions SET status='enrolled',course_id=?,enrolled_user_id=?,enrolled_at=?,updated_at=? WHERE tenant_id=? AND id=? AND status='offered'")
    .bind(courseId,zeile.user_id,ts,ts,tenantId,admissionId).run();
  await audit(env.DB,auth.userId,'admission.enrolled',tenantId,courseId,'admission',admissionId,{userId:zeile.user_id,invitationSent:!!zeile.invitation_sent});
  return{id:admissionId,status:'enrolled',user_id:zeile.user_id,course_id:courseId,invitation_sent:!!zeile.invitation_sent,no_portal_access:istErsatzAdresse(email)};
}

// ---------------------------------------------------------------------------------------------
// Aufbewahrung: § 15 AGG
// ---------------------------------------------------------------------------------------------

/**
 * Wie lange eine abgelehnte Bewerbung aufbewahrt wird, wenn der Traeger nichts anderes festlegt.
 *
 * Sechs Monate nach der Absage - die Frist des § 15 Abs. 4 AGG, innerhalb derer ein abgelehnter
 * Bewerber Ansprueche geltend machen kann. Danach gibt es keinen Grund mehr, seinen Namen zu
 * kennen; vorher schon, denn ohne die Unterlagen laesst sich gegen einen Vorwurf nichts sagen.
 */
export const AGG_MONATE_STANDARD=6;

async function aufbewahrungsmonate(env:Env,tenantId:string){
  const regel=await env.DB.prepare("SELECT aufbewahrung_monate FROM retention_policies WHERE tenant_id=? AND datenart='bewerbungen' AND aktiv=1")
    .bind(tenantId).first<{aufbewahrung_monate:number}>();
  const monate=Number(regel?.aufbewahrung_monate);
  return Number.isFinite(monate)&&monate>0?monate:AGG_MONATE_STANDARD;
}

/**
 * Welche abgelehnten Bewerbungen faellig sind.
 *
 * Nur abgelehnte: eine aufgenommene Bewerbung ist in den Teilnehmerdatensatz uebergegangen und
 * unterliegt dessen Fristen, eine offene laeuft noch. Und nur solche ohne Loeschsperre - eine
 * Sperre schlaegt jede Frist, auch diese.
 */
export async function faelligeBewerbungen(env:Env,tenantId:string,jetzt=nowIso()){
  const monate=await aufbewahrungsmonate(env,tenantId);
  const stichtag=new Date(jetzt);
  stichtag.setUTCMonth(stichtag.getUTCMonth()-monate);
  const zeilen=((await env.DB.prepare(`SELECT id,reference_code,decided_at,intake_batch_id FROM admissions
    WHERE tenant_id=? AND status='rejected' AND anonymisiert_am IS NULL
      AND decided_at IS NOT NULL AND decided_at<=? ORDER BY decided_at LIMIT 200`)
    .bind(tenantId,stichtag.toISOString()).all<{id:string;reference_code:string;decided_at:string;intake_batch_id:string|null}>()).results)??[];
  if(!zeilen.length)return{monate,faellig:[],gesperrt:0};
  const lage=await sperrlage(env,tenantId,zeilen.map(z=>({umfang:'vorgang',bezug_id:z.id})));
  const frei=zeilen.filter(z=>!(lage.get(`vorgang:${z.id}`)?.gesperrt));
  return{monate,faellig:frei,gesperrt:zeilen.length-frei.length};
}

/**
 * Den Personenbezug einer abgelehnten Bewerbung entfernen.
 *
 * Die Zeile bleibt: Vorgangsnummer, Stand und Zeitpunkte sind die Trichterzahlen des Traegers,
 * und eine geloeschte Zeile waere spaeter nicht von einer nie eingegangenen zu unterscheiden.
 * Was geht, ist alles, was auf einen Menschen zeigt - einschliesslich der Absagenotiz, in der
 * erfahrungsgemaess der eigentliche Grund steht.
 */
export async function anonymisiereBewerbung(env:Env,tenantId:string,admissionId:string,jetzt=nowIso()){
  const zeile=await env.DB.prepare('SELECT id,intake_batch_id FROM admissions WHERE tenant_id=? AND id=? AND anonymisiert_am IS NULL')
    .bind(tenantId,safeString(admissionId,120)).first<{id:string;intake_batch_id:string|null}>();
  if(!zeile)throw new Error('ADMISSION_NOT_FOUND');
  const anweisungen=[env.DB.prepare(`UPDATE admissions SET applicant_name='(geloescht)',applicant_email='(geloescht)',
      applicant_phone=NULL,applicant_note=NULL,decision_note=NULL,anonymisiert_am=?,updated_at=? WHERE tenant_id=? AND id=?`)
    .bind(jetzt,jetzt,tenantId,zeile.id)];
  // Der Schriftwechsel geht mit: dort stehen Name, Anrede und oft der ganze Fall. Die Zeilen
  // bleiben stehen, damit nachvollziehbar bleibt, DASS und WANN geschrieben wurde - der Inhalt
  // geht. Und der Einmal-Link stirbt, sonst koennte jemand nach der Loeschung noch einreichen.
  anweisungen.push(env.DB.prepare(`UPDATE admission_messages SET text='(geloescht)',betreff='(geloescht)',
    token_hash=NULL,token_expires_at=NULL WHERE tenant_id=? AND admission_id=?`).bind(tenantId,zeile.id));
  // Die Unterlagen gehen mit. Sie laufen sonst noch bis zu ihrer eigenen Frist weiter - und sie
  // sind der Teil, der am meisten ueber einen Menschen sagt.
  if(zeile.intake_batch_id)anweisungen.push(
    env.DB.prepare("UPDATE intake_documents SET expires_at=? WHERE tenant_id=? AND batch_id=?").bind(jetzt,tenantId,zeile.intake_batch_id),
    env.DB.prepare("UPDATE intake_batches SET expires_at=? WHERE tenant_id=? AND id=?").bind(jetzt,tenantId,zeile.intake_batch_id));
  // Nachgereichtes liegt in eigenen Stapeln. Sie zu vergessen hiesse, ausgerechnet die Unterlagen
  // zu behalten, um die eigens gebeten wurde.
  anweisungen.push(
    env.DB.prepare(`UPDATE intake_documents SET expires_at=? WHERE tenant_id=? AND batch_id IN
      (SELECT intake_batch_id FROM admission_messages WHERE tenant_id=? AND admission_id=? AND intake_batch_id IS NOT NULL)`)
      .bind(jetzt,tenantId,tenantId,zeile.id),
    env.DB.prepare(`UPDATE intake_batches SET expires_at=? WHERE tenant_id=? AND id IN
      (SELECT intake_batch_id FROM admission_messages WHERE tenant_id=? AND admission_id=? AND intake_batch_id IS NOT NULL)`)
      .bind(jetzt,tenantId,tenantId,zeile.id));
  await env.DB.batch(anweisungen);
  return{id:zeile.id,anonymisiert_am:jetzt};
}

/**
 * Der Lauf. Gehoert in denselben Turnus wie die uebrige Aufbewahrung.
 *
 * Er meldet, was er getan hat UND was eine Loeschsperre zurueckgehalten hat - das Zweite ist der
 * Nachweis, dass die Sperre gewirkt hat.
 */
export async function raeumeBewerbungenAuf(env:Env,tenantId:string,jetzt=nowIso(),hoechstens=200){
  const {monate,faellig:alle,gesperrt}=await faelligeBewerbungen(env,tenantId,jetzt);
  const faellig=alle.slice(0,Math.max(0,hoechstens));
  for(const b of faellig)await anonymisiereBewerbung(env,tenantId,b.id,jetzt);
  if(faellig.length||gesperrt)
    await env.DB.prepare('INSERT INTO automation_events(id,tenant_id,event_type,source_type,source_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)')
      .bind(id('aev_'),tenantId,'admission.retention','admission',null,
        JSON.stringify({monate,anonymisiert:faellig.length,wegen_sperre_zurueckgehalten:gesperrt}),jetzt).run();
  return{monate,anonymisiert:faellig.length,wegen_sperre_zurueckgehalten:gesperrt};
}

/**
 * Der taegliche Lauf ueber alle Mandanten. Ohne ihn ist die Frist nur eine Zeile im Katalog.
 *
 * Er nimmt bewusst nur einen Ausschnitt je Aufruf: ein Aufruf der Plattform hat 1000
 * Unteranfragen fuer alle Arbeiten zusammen, und die taegliche Runde teilt sie sich mit allem
 * anderen. Die Mandanten kommen in der Reihenfolge ihrer aeltesten offenen Absage dran, damit
 * zuerst geloescht wird, was am laengsten liegt. Was heute liegen bleibt, ist morgen wieder
 * dran - eine Frist von sechs Monaten vertraegt einen Tag Verzug, ein Zusammenbruch der
 * taeglichen Runde nicht.
 */
export async function raeumeBewerbungenAllerMandantenAuf(env:Env,maxMandanten=40,maxBewerbungen=40,jetzt=nowIso()){
  const mandanten=((await env.DB.prepare(`SELECT tenant_id FROM admissions
    WHERE status='rejected' AND anonymisiert_am IS NULL AND decided_at IS NOT NULL
    GROUP BY tenant_id ORDER BY MIN(decided_at) LIMIT ?`)
    .bind(Math.max(1,maxMandanten)).all<{tenant_id:string}>()).results)??[];
  let anonymisiert=0,gesperrt=0,geprueft=0;
  for(const m of mandanten){
    if(anonymisiert>=maxBewerbungen)break;
    geprueft++;
    // Ein Mandant, der stolpert, darf die uebrigen nicht mitnehmen - sonst haengt die Frist
    // aller an der schwaechsten Zeile.
    const lauf=await raeumeBewerbungenAuf(env,m.tenant_id,jetzt,maxBewerbungen-anonymisiert)
      .catch(e=>{console.error('Bewerber-Aufbewahrung',{error:String((e as Error)?.message||e)});return null;});
    if(!lauf)continue;
    anonymisiert+=lauf.anonymisiert;gesperrt+=lauf.wegen_sperre_zurueckgehalten;
  }
  return{mandanten:geprueft,anonymisiert,wegen_sperre_zurueckgehalten:gesperrt};
}

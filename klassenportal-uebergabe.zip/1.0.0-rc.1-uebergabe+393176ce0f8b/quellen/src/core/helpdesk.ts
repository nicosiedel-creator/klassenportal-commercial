import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Helpdesk mit Frist und Eskalation (S1).
//
// Bisher gab es keinen Weg, auf dem ein Anwender ein Problem meldet und jemand dafuer
// verantwortlich ist. Gemeldet wurde per Zuruf: wer es zuerst hoerte, kuemmerte sich - oder
// auch nicht. Bei hundert Lehrkraeften verschwindet so jede zweite Meldung.
//
// Zwei Dinge machen den Unterschied zu einer Kommentarliste:
//  - Die Frist steht FEST, sobald das Ticket angelegt ist. Sie aus der jeweils aktuellen
//    Dringlichkeit zu rechnen hiesse, dass ein Herunterstufen die Verspaetung wegzaubert.
//  - Eskaliert wird ohne Zutun. Eine Eskalation, die jemand ausloesen muss, findet nicht statt.

const clean=(v:unknown,n=4000)=>safeString(v,n);
export const KATEGORIEN=['technik','daten','abrechnung','unterricht','pruefung','zugang','sonstiges'] as const;
export const DRINGLICHKEITEN=['kritisch','hoch','normal','niedrig'] as const;
// Fristen in Stunden. Bewusst grosszuegig: eine Frist, die niemand halten kann, wird ignoriert.
export const FRIST_STUNDEN:Record<string,number>={kritisch:4,hoch:24,normal:72,niedrig:168};
const STUNDE=3600000;

const frist=(erstellt:string,dringlichkeit:string)=>new Date(Date.parse(erstellt)+(FRIST_STUNDEN[dringlichkeit]??72)*STUNDE).toISOString();

export async function meldeTicket(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const kategorie=clean(input.kategorie,40),dringlichkeit=clean(input.dringlichkeit,20)||'normal';
  if(!(KATEGORIEN as readonly string[]).includes(kategorie))throw new Error('TICKET_KATEGORIE_UNGUELTIG');
  if(!(DRINGLICHKEITEN as readonly string[]).includes(dringlichkeit))throw new Error('TICKET_DRINGLICHKEIT_UNGUELTIG');
  const betreff=clean(input.betreff,200),beschreibung=clean(input.beschreibung,8000);
  if(betreff.length<5)throw new Error('TICKET_BETREFF_ERFORDERLICH');
  // Eine Meldung ohne Beschreibung kostet die Bearbeitung eine Rueckfrage - und den Melder einen Tag.
  if(beschreibung.length<20)throw new Error('TICKET_BESCHREIBUNG_ERFORDERLICH');
  const ts=nowIso(),ticketId=id('tkt_');
  // Die laufende Nummer in derselben Anweisung ermitteln: ein getrenntes SELECT+INSERT vergibt
  // unter Last zweimal dieselbe Nummer, und dann ist "Ticket 42" nicht mehr eindeutig.
  await env.DB.prepare(`INSERT INTO helpdesk_tickets(id,tenant_id,nummer,melder_user_id,kategorie,dringlichkeit,betreff,beschreibung,bereich,status,frist_am,created_at,updated_at)
    SELECT ?,?,COALESCE(MAX(nummer),0)+1,?,?,?,?,?,?,'offen',?,?,? FROM helpdesk_tickets WHERE tenant_id=?`)
    .bind(ticketId,tenantId,auth.userId,kategorie,dringlichkeit,betreff,beschreibung,clean(input.bereich,80)||null,frist(ts,dringlichkeit),ts,ts,tenantId).run();
  const zeile=await env.DB.prepare('SELECT nummer,frist_am FROM helpdesk_tickets WHERE id=? AND tenant_id=?').bind(ticketId,tenantId).first<{nummer:number;frist_am:string}>();
  await env.DB.prepare("INSERT INTO helpdesk_ticket_events(id,tenant_id,ticket_id,art,intern,text,akteur_user_id,created_at) VALUES(?,?,?,'angelegt',0,?,?,?)")
    .bind(id('tev_'),tenantId,ticketId,betreff,auth.userId,ts).run();
  await audit(env.DB,auth.userId,'helpdesk.filed',tenantId,undefined,'helpdesk_ticket',ticketId,{kategorie,dringlichkeit});
  return{id:ticketId,nummer:Number(zeile?.nummer??0),frist_am:String(zeile?.frist_am??''),status:'offen'};
}

async function ladeTicket(env:Env,tenantId:string,ticketId:string){
  const t=await env.DB.prepare('SELECT id,melder_user_id,status,dringlichkeit,frist_am,zustaendig_user_id FROM helpdesk_tickets WHERE id=? AND tenant_id=?')
    .bind(clean(ticketId,120),tenantId).first<{id:string;melder_user_id:string;status:string;dringlichkeit:string;frist_am:string;zustaendig_user_id:string|null}>();
  if(!t)throw new Error('TICKET_NICHT_GEFUNDEN');
  return t;
}

/** Zustaendig ist genau eine Person. "Das Team" ist niemand. */
export async function weiseZu(env:Env,auth:CoreAuthContext,tenantId:string,ticketId:string,userId:string){
  requireRole(auth,'class_admin');
  const t=await ladeTicket(env,tenantId,ticketId);
  if(t.status==='geschlossen')throw new Error('TICKET_GESCHLOSSEN');
  const person=clean(userId,120);
  const gehoert=await env.DB.prepare("SELECT 1 AS ok FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'").bind(tenantId,person).first();
  if(!gehoert)throw new Error('TICKET_ZUSTAENDIG_NICHT_GEFUNDEN');
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE helpdesk_tickets SET zustaendig_user_id=?,status=CASE WHEN status='offen' THEN 'in_arbeit' ELSE status END,updated_at=? WHERE id=? AND tenant_id=?").bind(person,ts,t.id,tenantId),
    env.DB.prepare("INSERT INTO helpdesk_ticket_events(id,tenant_id,ticket_id,art,intern,text,akteur_user_id,created_at) VALUES(?,?,?,'zuweisung',0,?,?,?)")
      .bind(id('tev_'),tenantId,t.id,'Zuständigkeit übernommen',auth.userId,ts)]);
  return{zustaendig:person};
}

/** Antworten - der Melder darf selbst nur oeffentlich schreiben. */
export async function antworteTicket(env:Env,auth:CoreAuthContext,tenantId:string,ticketId:string,text:string,intern=false){
  const t=await ladeTicket(env,tenantId,ticketId);
  const istMelder=t.melder_user_id===auth.userId;
  if(!istMelder)requireRole(auth,'class_admin');
  if(intern&&istMelder&&!(auth.role==='class_admin'||auth.role==='tenant_admin'||auth.isPlatformAdmin))throw new Error('TICKET_INTERN_NICHT_ERLAUBT');
  const inhalt=clean(text,8000);
  if(inhalt.length<2)throw new Error('TICKET_TEXT_ERFORDERLICH');
  if(t.status==='geschlossen')throw new Error('TICKET_GESCHLOSSEN');
  await env.DB.prepare("INSERT INTO helpdesk_ticket_events(id,tenant_id,ticket_id,art,intern,text,akteur_user_id,created_at) VALUES(?,?,?,'kommentar',?,?,?,?)")
    .bind(id('tev_'),tenantId,t.id,intern?1:0,inhalt,auth.userId,nowIso()).run();
  return{gespeichert:true};
}

/**
 * Loesen - mit Loesungstext, und wenn moeglich mit dem Artikel, der es beantwortet.
 *
 * Der Artikelbezug ist kein Schmuck: haeufen sich Tickets ohne Artikel, fehlt ein Artikel;
 * haeufen sich Tickets MIT Artikel, ist der Artikel schlecht auffindbar. Beides ist eine
 * konkrete Aufgabe.
 */
export async function loeseTicket(env:Env,auth:CoreAuthContext,tenantId:string,ticketId:string,loesung:string,artikelId?:string){
  requireRole(auth,'class_admin');
  const t=await ladeTicket(env,tenantId,ticketId);
  if(t.status==='geschlossen')throw new Error('TICKET_GESCHLOSSEN');
  if(t.status==='geloest')throw new Error('TICKET_BEREITS_GELOEST');
  const text=clean(loesung,8000);
  if(text.length<10)throw new Error('TICKET_LOESUNG_ERFORDERLICH');
  const artikel=clean(artikelId,120)||null;
  if(artikel){
    const a=await env.DB.prepare("SELECT 1 AS ok FROM knowledge_articles WHERE id=? AND (tenant_id=? OR plattformweit=1) AND status='veroeffentlicht'").bind(artikel,tenantId).first();
    if(!a)throw new Error('TICKET_ARTIKEL_NICHT_GEFUNDEN');
  }
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE helpdesk_tickets SET status='geloest',loesung=?,artikel_id=?,geloest_am=?,updated_at=? WHERE id=? AND tenant_id=?").bind(text,artikel,ts,ts,t.id,tenantId),
    env.DB.prepare("INSERT INTO helpdesk_ticket_events(id,tenant_id,ticket_id,art,intern,text,akteur_user_id,created_at) VALUES(?,?,?,'geloest',0,?,?,?)")
      .bind(id('tev_'),tenantId,t.id,text,auth.userId,ts),
    env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'helpdesk_resolved',?,?,?)")
      .bind(id('ntf_'),tenantId,t.melder_user_id,'Ihre Meldung ist gelöst','Zu Ihrer Meldung liegt eine Lösung vor. Wenn sie nicht passt, können Sie den Vorgang wieder öffnen.',ts)]);
  await audit(env.DB,auth.userId,'helpdesk.resolved',tenantId,undefined,'helpdesk_ticket',t.id,{});
  return{status:'geloest'};
}

/**
 * Wiedereroeffnen darf der MELDER.
 *
 * Ob ein Problem geloest ist, entscheidet nicht, wer es bearbeitet hat. Ohne dieses Recht ist
 * jede Loesungsquote eine Selbstauskunft.
 */
export async function eroeffneErneut(env:Env,auth:CoreAuthContext,tenantId:string,ticketId:string,grund:string){
  const t=await ladeTicket(env,tenantId,ticketId);
  if(t.melder_user_id!==auth.userId)requireRole(auth,'class_admin');
  if(t.status!=='geloest')throw new Error('TICKET_NICHT_GELOEST');
  const text=clean(grund,4000);
  if(text.length<10)throw new Error('TICKET_GRUND_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE helpdesk_tickets SET status='in_arbeit',geloest_am=NULL,updated_at=? WHERE id=? AND tenant_id=?").bind(ts,t.id,tenantId),
    env.DB.prepare("INSERT INTO helpdesk_ticket_events(id,tenant_id,ticket_id,art,intern,text,akteur_user_id,created_at) VALUES(?,?,?,'wiedereroeffnet',0,?,?,?)")
      .bind(id('tev_'),tenantId,t.id,text,auth.userId,ts)]);
  return{status:'in_arbeit'};
}

/** Geschlossen wird erst nach der Loesung - und dann endgueltig. */
export async function schliesseTicket(env:Env,auth:CoreAuthContext,tenantId:string,ticketId:string){
  requireRole(auth,'class_admin');
  const t=await ladeTicket(env,tenantId,ticketId);
  if(t.status!=='geloest')throw new Error('TICKET_NICHT_GELOEST');
  const ts=nowIso();
  await env.DB.prepare("UPDATE helpdesk_tickets SET status='geschlossen',updated_at=? WHERE id=? AND tenant_id=?").bind(ts,t.id,tenantId).run();
  return{status:'geschlossen'};
}

/**
 * Eskalation - ohne Zutun, in Stufen.
 *
 * Eine Eskalation, die jemand ausloesen muss, findet nicht statt. Gezaehlt wird ab der
 * festgeschriebenen Frist; jede angefangene Fristlaenge darueber ist eine Stufe mehr.
 */
export async function eskaliereFaelligeTickets(env:Env,tenantId:string,jetzt?:string){
  const ts=jetzt??nowIso();
  const faellig=((await env.DB.prepare(`SELECT id,nummer,dringlichkeit,frist_am,eskalationsstufe,zustaendig_user_id FROM helpdesk_tickets
    WHERE tenant_id=? AND status IN ('offen','in_arbeit') AND frist_am<? ORDER BY frist_am LIMIT 200`)
    .bind(tenantId,ts).all<{id:string;nummer:number;dringlichkeit:string;frist_am:string;eskalationsstufe:number;zustaendig_user_id:string|null}>()).results)??[];
  const anweisungen=[];let eskaliert=0;
  for(const t of faellig){
    const stunden=FRIST_STUNDEN[t.dringlichkeit]??72;
    const ueber=(Date.parse(ts)-Date.parse(t.frist_am))/STUNDE;
    const stufe=Math.min(3,1+Math.floor(ueber/stunden));
    if(stufe<=t.eskalationsstufe)continue;
    eskaliert++;
    anweisungen.push(env.DB.prepare('UPDATE helpdesk_tickets SET eskalationsstufe=?,eskaliert_am=?,updated_at=? WHERE id=? AND tenant_id=?').bind(stufe,ts,ts,t.id,tenantId));
    anweisungen.push(env.DB.prepare("INSERT INTO helpdesk_ticket_events(id,tenant_id,ticket_id,art,intern,text,akteur_user_id,created_at) VALUES(?,?,?,'eskalation',0,?,NULL,?)")
      .bind(id('tev_'),tenantId,t.id,`Frist überschritten, Eskalationsstufe ${stufe}.`,ts));
  }
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  return{geprueft:faellig.length,eskaliert};
}

/** Die ehrliche Sicht: was ist offen, was ist ueberfaellig, wie lange dauert es wirklich. */
export async function helpdeskUebersicht(env:Env,auth:CoreAuthContext,tenantId:string,jetzt?:string){
  requireRole(auth,'class_admin');
  const ts=jetzt??nowIso();
  const offen=((await env.DB.prepare(`SELECT t.id,t.nummer,t.betreff,t.kategorie,t.dringlichkeit,t.status,t.frist_am,t.eskalationsstufe,t.bereich,
    u.display_name AS melder,z.display_name AS zustaendig, CASE WHEN t.frist_am<? THEN 1 ELSE 0 END AS ueberfaellig
    FROM helpdesk_tickets t JOIN users u ON u.id=t.melder_user_id LEFT JOIN users z ON z.id=t.zustaendig_user_id
    WHERE t.tenant_id=? AND t.status IN ('offen','in_arbeit','wartet_auf_melder') ORDER BY t.frist_am LIMIT 200`)
    .bind(ts,tenantId).all<Record<string,unknown>>()).results)??[];
  const kennzahlen=await env.DB.prepare(`SELECT COUNT(*) AS gesamt,
    SUM(CASE WHEN status IN ('offen','in_arbeit','wartet_auf_melder') THEN 1 ELSE 0 END) AS offen,
    SUM(CASE WHEN status IN ('offen','in_arbeit','wartet_auf_melder') AND frist_am<? THEN 1 ELSE 0 END) AS ueberfaellig,
    SUM(CASE WHEN status IN ('geloest','geschlossen') AND geloest_am IS NOT NULL AND geloest_am<=frist_am THEN 1 ELSE 0 END) AS in_frist_geloest,
    SUM(CASE WHEN status IN ('geloest','geschlossen') THEN 1 ELSE 0 END) AS geloest,
    SUM(CASE WHEN artikel_id IS NULL AND status IN ('geloest','geschlossen') THEN 1 ELSE 0 END) AS ohne_artikel
    FROM helpdesk_tickets WHERE tenant_id=?`).bind(ts,tenantId).first<Record<string,number>>();
  return{offen,kennzahlen:kennzahlen??{}};
}

/** Meine Meldungen - mit dem Verlauf, aber ohne die internen Notizen. */
export async function meinTicket(env:Env,auth:CoreAuthContext,tenantId:string,ticketId:string){
  const t=await env.DB.prepare('SELECT * FROM helpdesk_tickets WHERE id=? AND tenant_id=?').bind(clean(ticketId,120),tenantId).first<Record<string,unknown>>();
  if(!t)throw new Error('TICKET_NICHT_GEFUNDEN');
  const istMelder=String(t.melder_user_id)===auth.userId;
  if(!istMelder)requireRole(auth,'class_admin');
  // Der Melder sieht den Verlauf ohne interne Notizen - nicht durch Ausfiltern im Client,
  // sondern weil die Abfrage sie gar nicht erst holt.
  const verlauf=((await env.DB.prepare(`SELECT e.art,e.text,e.created_at,e.intern,u.display_name AS akteur FROM helpdesk_ticket_events e
    LEFT JOIN users u ON u.id=e.akteur_user_id WHERE e.tenant_id=? AND e.ticket_id=? ${istMelder?'AND e.intern=0':''} ORDER BY e.created_at`)
    .bind(tenantId,t.id).all<Record<string,unknown>>()).results)??[];
  return{ticket:t,verlauf};
}

export async function meineTickets(env:Env,auth:CoreAuthContext,tenantId:string){
  return ((await env.DB.prepare('SELECT id,nummer,betreff,kategorie,dringlichkeit,status,frist_am,created_at FROM helpdesk_tickets WHERE tenant_id=? AND melder_user_id=? ORDER BY created_at DESC LIMIT 100')
    .bind(tenantId,auth.userId).all()).results)??[];
}

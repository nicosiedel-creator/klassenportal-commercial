import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Aktualisierung und Vorfallbehandlung im Cockpit (B2) und Betrieb ohne Einzelperson (B11).
//
// B2 fehlte an zwei Stellen:
//  - Eine AKTUALISIERUNG war ein Vorgang ausserhalb des Systems. Welcher Stand laeuft, welche
//    Migration er erwartet und wie zurueckgerollt wird, stand nirgends. Ein Rollback, der erst
//    im Ernstfall erdacht wird, ist keiner.
//  - Eine STOERUNG hatte keinen Ort. Wer betroffen ist, was den Anwendern gesagt wurde und was
//    danach geaendert wurde, lag in Chatverlaeufen.
//
// B11 ist der unbequemste Punkt der ganzen Liste: der Betrieb haengt an Personen. Wenn genau
// ein Mensch den Notfallzugriff hat oder die Wiederherstellung kennt, ist der Ausfall dieser
// Person ein Betriebsausfall. Das laesst sich messen - und wer es nicht misst, erfaehrt es am
// ersten Krankheitstag.

const clean=(v:unknown,n=4000)=>safeString(v,n);
export const SCHWEREGRADE=['kritisch','hoch','mittel','niedrig'] as const;
// Ab dieser Schwere ist die Nachbetrachtung Pflicht. Ohne sie wiederholt sich der Vorfall, und
// beim zweiten Mal ist er kein Unglueck mehr.
const NACHBETRACHTUNG_PFLICHT=new Set(['kritisch','hoch']);
// Eine Vertretung, die nie geuebt hat, ist eine Zeile in einer Liste. Nach einem Jahr ohne
// Uebung zaehlt sie nicht mehr als Absicherung.
export const UEBUNG_GUELTIG_TAGE=365;

/** Eine Aktualisierung anmelden - mit Rueckweg, sonst gar nicht. */
export async function meldeRelease(env:Env,auth:CoreAuthContext,input:Record<string,unknown>){
  if(!auth.isPlatformAdmin)throw new Error('BETRIEB_NUR_PLATTFORM');
  const fassung=clean(input.fassung,60),bezeichnung=clean(input.bezeichnung,200);
  if(!fassung||bezeichnung.length<3)throw new Error('RELEASE_UNVOLLSTAENDIG');
  const aenderungen=clean(input.aenderungen,8000);
  if(aenderungen.length<20)throw new Error('RELEASE_AENDERUNGEN_ERFORDERLICH');
  const rueckweg=clean(input.rueckweg,4000);
  // Der Rueckweg ist das eigentliche Pflichtfeld. Er zwingt dazu, VOR dem Ausrollen zu
  // beantworten, was bei einer Migration ohne Umkehr geschieht.
  if(rueckweg.length<20)throw new Error('RELEASE_RUECKWEG_ERFORDERLICH');
  const vorhanden=await env.DB.prepare('SELECT id FROM operations_releases WHERE fassung=?').bind(fassung).first();
  if(vorhanden)throw new Error('RELEASE_FASSUNG_VERGEBEN');
  const ts=nowIso(),relId=id('rel_');
  await env.DB.prepare('INSERT INTO operations_releases(id,bezeichnung,fassung,build_ref,erwartete_migration,aenderungen,rueckweg,status,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
    .bind(relId,bezeichnung,fassung,clean(input.build_ref,120)||null,clean(input.erwartete_migration,120)||null,
      aenderungen,rueckweg,'geplant',auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'release.planned',undefined,undefined,'operations_release',relId,{fassung});
  return{id:relId,fassung,status:'geplant'};
}

/**
 * Probelauf: passt das Schema zu dem, was der Stand erwartet?
 *
 * Code gegen ein Schema laufen zu lassen, das er nicht kennt, ist der teuerste aller
 * Betriebsfehler - er faellt erst auf, wenn Daten schon falsch geschrieben sind.
 */
export async function probeRelease(env:Env,auth:CoreAuthContext,releaseId:string){
  if(!auth.isPlatformAdmin)throw new Error('BETRIEB_NUR_PLATTFORM');
  const rel=await ladeRelease(env,releaseId);
  if(rel.status!=='geplant'&&rel.status!=='probelauf')throw new Error('RELEASE_NICHT_MEHR_GEPLANT');
  const letzte=await env.DB.prepare('SELECT name FROM d1_migrations ORDER BY name DESC LIMIT 1').first<{name:string}>();
  const ist=String(letzte?.name??'');
  const befunde:string[]=[];
  if(!rel.erwartete_migration)befunde.push('RELEASE_OHNE_ERWARTETE_MIGRATION');
  else if(!ist)befunde.push('RELEASE_KEINE_MIGRATION_GEFUNDEN');
  else if(ist<rel.erwartete_migration)befunde.push(`RELEASE_MIGRATION_FEHLT:${rel.erwartete_migration}`);
  const offeneStoerung=await env.DB.prepare("SELECT COUNT(*) AS n FROM operations_incidents WHERE status IN ('offen','erkannt') AND schwere IN ('kritisch','hoch')").first<{n:number}>();
  // Waehrend einer schweren Stoerung auszurollen heisst, zwei Fehlerquellen zu mischen und
  // hinterher keine davon zuordnen zu koennen.
  if(Number(offeneStoerung?.n??0))befunde.push('RELEASE_STOERUNG_OFFEN');
  const ts=nowIso(),ergebnis=befunde.length?befunde.join('; '):'ok';
  await env.DB.prepare("UPDATE operations_releases SET status='probelauf',probelauf_am=?,probelauf_ergebnis=?,updated_at=? WHERE id=?")
    .bind(ts,ergebnis,ts,rel.id).run();
  return{bestanden:!befunde.length,befunde,ist_migration:ist};
}

async function ladeRelease(env:Env,releaseId:string){
  const r=await env.DB.prepare('SELECT id,fassung,status,erwartete_migration,probelauf_ergebnis FROM operations_releases WHERE id=?')
    .bind(clean(releaseId,120)).first<{id:string;fassung:string;status:string;erwartete_migration:string|null;probelauf_ergebnis:string|null}>();
  if(!r)throw new Error('RELEASE_NICHT_GEFUNDEN');
  return r;
}

/** Ausrollen - nur nach bestandenem Probelauf. */
export async function rolleReleaseAus(env:Env,auth:CoreAuthContext,releaseId:string){
  if(!auth.isPlatformAdmin)throw new Error('BETRIEB_NUR_PLATTFORM');
  const rel=await ladeRelease(env,releaseId);
  if(rel.status==='ausgerollt')throw new Error('RELEASE_BEREITS_AUSGEROLLT');
  // Ohne Probelauf gibt es keine Aussage darueber, ob das Schema passt. Ein Ausrollen "auf
  // Verdacht" ist genau der Vorgang, den dieses Modul verhindern soll.
  if(rel.status!=='probelauf')throw new Error('RELEASE_PROBELAUF_FEHLT');
  if(rel.probelauf_ergebnis!=='ok')throw new Error('RELEASE_PROBELAUF_MIT_BEFUND');
  const ts=nowIso();
  await env.DB.prepare("UPDATE operations_releases SET status='ausgerollt',ausgerollt_am=?,ausgerollt_von=?,updated_at=? WHERE id=?")
    .bind(ts,auth.userId,ts,rel.id).run();
  await audit(env.DB,auth.userId,'release.rolled_out',undefined,undefined,'operations_release',rel.id,{fassung:rel.fassung});
  return{status:'ausgerollt',fassung:rel.fassung};
}

/** Zurueckrollen - mit Grund, und nur was ausgerollt war. */
export async function rolleReleaseZurueck(env:Env,auth:CoreAuthContext,releaseId:string,grund:string){
  if(!auth.isPlatformAdmin)throw new Error('BETRIEB_NUR_PLATTFORM');
  const rel=await ladeRelease(env,releaseId);
  if(rel.status!=='ausgerollt')throw new Error('RELEASE_NICHT_AUSGEROLLT');
  const text=clean(grund,4000);
  if(text.length<10)throw new Error('RELEASE_RUECKROLLGRUND_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.prepare("UPDATE operations_releases SET status='zurueckgerollt',zurueckgerollt_am=?,zurueckgerollt_grund=?,updated_at=? WHERE id=?")
    .bind(ts,text,ts,rel.id).run();
  await audit(env.DB,auth.userId,'release.rolled_back',undefined,undefined,'operations_release',rel.id,{});
  return{status:'zurueckgerollt'};
}

/** Was laeuft, was steht an - zwei Abfragen fuer das Cockpit. */
export async function releasestand(env:Env,auth:CoreAuthContext){
  if(!auth.isPlatformAdmin)throw new Error('BETRIEB_NUR_PLATTFORM');
  const laufend=await env.DB.prepare("SELECT id,bezeichnung,fassung,build_ref,erwartete_migration,ausgerollt_am FROM operations_releases WHERE status='ausgerollt' ORDER BY ausgerollt_am DESC LIMIT 1").first<Record<string,unknown>>();
  const offen=((await env.DB.prepare("SELECT id,bezeichnung,fassung,status,probelauf_ergebnis FROM operations_releases WHERE status IN ('geplant','probelauf') ORDER BY created_at LIMIT 20").all<Record<string,unknown>>()).results)??[];
  const letzte=await env.DB.prepare('SELECT name FROM d1_migrations ORDER BY name DESC LIMIT 1').first<{name:string}>();
  const istMigration=String(letzte?.name??'');
  return{laufend:laufend??null,offen,ist_migration:istMigration,
    // Der Satz, der im Cockpit stehen muss: laeuft der Code gegen das Schema, das er erwartet?
    schema_passt:!laufend?.erwartete_migration||istMigration>=String(laufend.erwartete_migration)};
}

/** Eine Stoerung eroeffnen. */
export async function meldeStoerung(env:Env,auth:CoreAuthContext,tenantId:string|null,input:Record<string,unknown>){
  if(tenantId)requireRole(auth,'tenant_admin');else if(!auth.isPlatformAdmin)throw new Error('BETRIEB_NUR_PLATTFORM');
  const titel=clean(input.titel,200),auswirkung=clean(input.auswirkung,4000);
  if(titel.length<5)throw new Error('STOERUNG_TITEL_ERFORDERLICH');
  // Die Auswirkung ist das, was auf die Statusseite gehoert - und das Einzige, was Anwender
  // interessiert. Eine Stoerung ohne sie ist eine technische Notiz.
  if(auswirkung.length<10)throw new Error('STOERUNG_AUSWIRKUNG_ERFORDERLICH');
  const schwere=clean(input.schwere,20)||'mittel';
  if(!(SCHWEREGRADE as readonly string[]).includes(schwere))throw new Error('STOERUNG_SCHWERE_UNGUELTIG');
  const ts=nowIso(),vorfallId=id('sto_');
  await env.DB.prepare('INSERT INTO operations_incidents(id,tenant_id,titel,schwere,auswirkung,status,entdeckt_am,release_id,gemeldet_von,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
    .bind(vorfallId,tenantId,titel,schwere,auswirkung,'offen',clean(input.entdeckt_am,40)||ts,clean(input.release_id,120)||null,auth.userId,ts,ts).run();
  await env.DB.prepare("INSERT INTO operations_incident_updates(id,incident_id,sichtbarkeit,text,verfasst_von,created_at) VALUES(?,?,'extern',?,?,?)")
    .bind(id('stu_'),vorfallId,auswirkung,auth.userId,ts).run();
  await audit(env.DB,auth.userId,'incident.opened',tenantId??undefined,undefined,'operations_incident',vorfallId,{schwere});
  return{id:vorfallId,status:'offen',schwere};
}

export async function ergaenzeStoerung(env:Env,auth:CoreAuthContext,vorfallId:string,text:string,intern=false){
  if(!auth.isPlatformAdmin)requireRole(auth,'tenant_admin');
  const inhalt=clean(text,4000);
  if(inhalt.length<5)throw new Error('STOERUNG_TEXT_ERFORDERLICH');
  const v=await ladeStoerung(env,vorfallId);
  await env.DB.prepare('INSERT INTO operations_incident_updates(id,incident_id,sichtbarkeit,text,verfasst_von,created_at) VALUES(?,?,?,?,?,?)')
    .bind(id('stu_'),v.id,intern?'intern':'extern',inhalt,auth.userId,nowIso()).run();
  return{ergaenzt:true};
}

async function ladeStoerung(env:Env,vorfallId:string){
  const v=await env.DB.prepare('SELECT id,tenant_id,schwere,status,nachbetrachtung FROM operations_incidents WHERE id=?')
    .bind(clean(vorfallId,120)).first<{id:string;tenant_id:string|null;schwere:string;status:string;nachbetrachtung:string|null}>();
  if(!v)throw new Error('STOERUNG_NICHT_GEFUNDEN');
  return v;
}

/** Beheben - die Ursache gehoert dazu, nicht erst in die Nachbetrachtung. */
export async function behebeStoerung(env:Env,auth:CoreAuthContext,vorfallId:string,ursache:string){
  if(!auth.isPlatformAdmin)requireRole(auth,'tenant_admin');
  const v=await ladeStoerung(env,vorfallId);
  if(v.status==='behoben'||v.status==='nachbereitet')throw new Error('STOERUNG_BEREITS_BEHOBEN');
  const text=clean(ursache,4000);
  if(text.length<10)throw new Error('STOERUNG_URSACHE_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare("UPDATE operations_incidents SET status='behoben',ursache=?,behoben_am=?,updated_at=? WHERE id=?").bind(text,ts,ts,v.id),
    env.DB.prepare("INSERT INTO operations_incident_updates(id,incident_id,sichtbarkeit,text,verfasst_von,created_at) VALUES(?,?,'extern','Die Störung ist behoben.',?,?)")
      .bind(id('stu_'),v.id,auth.userId,ts)]);
  return{status:'behoben'};
}

/**
 * Nachbetrachtung - bei schweren Stoerungen Pflicht.
 *
 * "Abgeschlossen" ohne sie waere die bequemste Luege des Betriebs: der Vorfall ist aus der
 * Liste, die Ursache bleibt im System.
 */
export async function bereiteStoerungNach(env:Env,auth:CoreAuthContext,vorfallId:string,nachbetrachtung:string){
  if(!auth.isPlatformAdmin)requireRole(auth,'tenant_admin');
  const v=await ladeStoerung(env,vorfallId);
  if(v.status!=='behoben')throw new Error('STOERUNG_NICHT_BEHOBEN');
  const text=clean(nachbetrachtung,8000);
  if(text.length<50)throw new Error('STOERUNG_NACHBETRACHTUNG_ZU_KURZ');
  const ts=nowIso();
  await env.DB.prepare("UPDATE operations_incidents SET status='nachbereitet',nachbetrachtung=?,nachbetrachtung_am=?,updated_at=? WHERE id=?")
    .bind(text,ts,ts,v.id).run();
  return{status:'nachbereitet'};
}

/** Der Stoerungsstand - mit dem, was noch aussteht. */
export async function stoerungsstand(env:Env,auth:CoreAuthContext){
  if(!auth.isPlatformAdmin)throw new Error('BETRIEB_NUR_PLATTFORM');
  const offen=((await env.DB.prepare("SELECT id,tenant_id,titel,schwere,status,entdeckt_am,auswirkung FROM operations_incidents WHERE status IN ('offen','erkannt') ORDER BY entdeckt_am LIMIT 100").all<Record<string,unknown>>()).results)??[];
  const nachbereitung=((await env.DB.prepare(`SELECT id,titel,schwere,behoben_am FROM operations_incidents
    WHERE status='behoben' AND schwere IN ('kritisch','hoch') ORDER BY behoben_am LIMIT 100`).all<Record<string,unknown>>()).results)??[];
  return{offen,nachbetrachtung_offen:nachbereitung};
}

/** Kritische Betriebsaufgaben festlegen. */
export async function legeAufgabeAn(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const schluessel=clean(input.schluessel,60),bezeichnung=clean(input.bezeichnung,200);
  if(!schluessel||bezeichnung.length<3)throw new Error('AUFGABE_UNVOLLSTAENDIG');
  const mindest=Math.trunc(Number(input.mindestbesetzung??2));
  if(!Number.isFinite(mindest)||mindest<1||mindest>10)throw new Error('AUFGABE_MINDESTBESETZUNG_UNGUELTIG');
  const ts=nowIso(),aufgabeId=id('auf_');
  await env.DB.prepare('INSERT INTO operations_duties(id,tenant_id,schluessel,bezeichnung,mindestbesetzung,beschreibung,aktiv,created_at,updated_at) VALUES(?,?,?,?,?,?,1,?,?) ON CONFLICT(tenant_id,schluessel) DO UPDATE SET bezeichnung=excluded.bezeichnung,mindestbesetzung=excluded.mindestbesetzung,updated_at=excluded.updated_at')
    .bind(aufgabeId,tenantId,schluessel,bezeichnung,mindest,clean(input.beschreibung,2000)||null,ts,ts).run();
  return{schluessel,mindestbesetzung:mindest};
}

export async function besetzeAufgabe(env:Env,auth:CoreAuthContext,tenantId:string,schluessel:string,userId:string,rolle='traeger'){
  requireRole(auth,'tenant_admin');
  const aufgabe=await env.DB.prepare('SELECT id FROM operations_duties WHERE tenant_id=? AND schluessel=?').bind(tenantId,clean(schluessel,60)).first<{id:string}>();
  if(!aufgabe)throw new Error('AUFGABE_NICHT_GEFUNDEN');
  if(!['traeger','vertretung'].includes(rolle))throw new Error('AUFGABE_ROLLE_UNGUELTIG');
  const person=clean(userId,120);
  const gehoert=await env.DB.prepare("SELECT 1 AS ok FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'").bind(tenantId,person).first();
  if(!gehoert)throw new Error('AUFGABE_PERSON_NICHT_GEFUNDEN');
  const ts=nowIso();
  await env.DB.prepare('INSERT INTO operations_duty_holders(id,tenant_id,duty_id,user_id,rolle,created_at,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(duty_id,user_id) DO UPDATE SET rolle=excluded.rolle,updated_at=excluded.updated_at')
    .bind(id('auh_'),tenantId,aufgabe.id,person,rolle,ts,ts).run();
  return{besetzt:true};
}

/** Eine Uebung festhalten - erst sie macht aus einer Liste eine Zusicherung. */
export async function vermerkeUebung(env:Env,auth:CoreAuthContext,tenantId:string,schluessel:string,userId:string,am?:string){
  requireRole(auth,'tenant_admin');
  const zeile=await env.DB.prepare('SELECT h.id FROM operations_duty_holders h JOIN operations_duties d ON d.id=h.duty_id WHERE h.tenant_id=? AND d.schluessel=? AND h.user_id=?')
    .bind(tenantId,clean(schluessel,60),clean(userId,120)).first<{id:string}>();
  if(!zeile)throw new Error('AUFGABE_BESETZUNG_NICHT_GEFUNDEN');
  const tag=clean(am,10)||nowIso().slice(0,10);
  await env.DB.prepare('UPDATE operations_duty_holders SET zuletzt_geuebt_am=?,updated_at=? WHERE id=? AND tenant_id=?').bind(tag,nowIso(),zeile.id,tenantId).run();
  return{zuletzt_geuebt_am:tag};
}

/**
 * Die Entlassung aus einer kritischen Aufgabe - und der Punkt, an dem B11 wirkt.
 *
 * Die letzte Person aus einer kritischen Aufgabe zu entfernen ist kein Verwaltungsvorgang,
 * sondern die Entscheidung, den Betrieb unbesetzt zu lassen. Sie wird verweigert.
 */
export async function entbindeVonAufgabe(env:Env,auth:CoreAuthContext,tenantId:string,schluessel:string,userId:string){
  requireRole(auth,'tenant_admin');
  const aufgabe=await env.DB.prepare('SELECT id,mindestbesetzung FROM operations_duties WHERE tenant_id=? AND schluessel=? AND aktiv=1')
    .bind(tenantId,clean(schluessel,60)).first<{id:string;mindestbesetzung:number}>();
  if(!aufgabe)throw new Error('AUFGABE_NICHT_GEFUNDEN');
  const anzahl=await env.DB.prepare('SELECT COUNT(*) AS n FROM operations_duty_holders WHERE duty_id=? AND tenant_id=?').bind(aufgabe.id,tenantId).first<{n:number}>();
  if(Number(anzahl?.n??0)<=1)throw new Error('AUFGABE_LETZTE_BESETZUNG');
  await env.DB.prepare('DELETE FROM operations_duty_holders WHERE duty_id=? AND tenant_id=? AND user_id=?').bind(aufgabe.id,tenantId,clean(userId,120)).run();
  return{entbunden:true};
}

/**
 * Die Ausfallpruefung: woran haengt der Betrieb an einer einzelnen Person?
 *
 * Zwei Abfragen fuer alle Aufgaben. Das Ergebnis ist bewusst unbequem formuliert - "erfuellt"
 * heisst genau dann erfuellt, wenn die Mindestbesetzung steht UND die Personen geuebt haben.
 */
export async function ausfallpruefung(env:Env,auth:CoreAuthContext,tenantId:string,heute?:string){
  requireRole(auth,'tenant_admin');
  const tag=clean(heute,10)||nowIso().slice(0,10);
  const grenze=new Date(Date.parse(tag)-UEBUNG_GUELTIG_TAGE*86400000).toISOString().slice(0,10);
  const aufgaben=((await env.DB.prepare('SELECT id,schluessel,bezeichnung,mindestbesetzung FROM operations_duties WHERE (tenant_id=? OR tenant_id IS NULL) AND aktiv=1 ORDER BY schluessel')
    .bind(tenantId).all<{id:string;schluessel:string;bezeichnung:string;mindestbesetzung:number}>()).results)??[];
  if(!aufgaben.length)return{aufgaben:[],unbesetzt:[],einzelpersonen:[],erfuellt:false,hinweis:'AUFGABEN_NICHT_FESTGELEGT'};
  const ph=aufgaben.map(()=>'?').join(',');
  const traeger=((await env.DB.prepare(`SELECT h.duty_id,h.user_id,u.display_name,h.rolle,h.zuletzt_geuebt_am
    FROM operations_duty_holders h JOIN users u ON u.id=h.user_id WHERE h.tenant_id=? AND h.duty_id IN (${ph})`)
    .bind(tenantId,...aufgaben.map(a=>a.id)).all<Record<string,unknown>>()).results)??[];
  const karte=new Map<string,Record<string,unknown>[]>();
  for(const t of traeger){const k=String(t.duty_id);if(!karte.has(k))karte.set(k,[]);karte.get(k)!.push(t);}
  const zeilen=aufgaben.map(a=>{
    const eigene=karte.get(a.id)??[];
    const geuebt=eigene.filter(t=>t.zuletzt_geuebt_am&&String(t.zuletzt_geuebt_am)>=grenze);
    return{schluessel:a.schluessel,bezeichnung:a.bezeichnung,mindestbesetzung:a.mindestbesetzung,
      besetzt:eigene.length,geuebt:geuebt.length,
      personen:eigene.map(t=>({user_id:t.user_id,name:t.display_name,rolle:t.rolle,zuletzt_geuebt_am:t.zuletzt_geuebt_am})),
      // Wer die Aufgabe nie geuebt hat, ist keine Absicherung - er ist ein Name in einer Liste.
      erfuellt:eigene.length>=a.mindestbesetzung&&geuebt.length>=a.mindestbesetzung};
  });
  return{aufgaben:zeilen,
    unbesetzt:zeilen.filter(z=>z.besetzt===0).map(z=>z.schluessel),
    einzelpersonen:zeilen.filter(z=>z.besetzt===1).map(z=>z.schluessel),
    ungeuebt:zeilen.filter(z=>z.besetzt>=z.mindestbesetzung&&z.geuebt<z.mindestbesetzung).map(z=>z.schluessel),
    erfuellt:zeilen.every(z=>z.erfuellt)};
}

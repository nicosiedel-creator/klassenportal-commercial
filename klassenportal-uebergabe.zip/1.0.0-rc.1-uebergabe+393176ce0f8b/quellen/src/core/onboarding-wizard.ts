import type { CoreAuthContext, Env } from './types.js';
import { requireRole } from './permissions.js';
import { nowIso, safeString } from './utils.js';

// Gefuehrtes Onboarding mit Abhaengigkeiten und ehrlichem Startverdikt (S3).
//
// Der Fortschritt wurde schon aus dem echten Datenbestand abgeleitet - das ist richtig und
// bleibt so: abgehakte Kaestchen luegen, gezaehlte Kurse nicht. Was fehlte, war die
// REIHENFOLGE. Ein neuer Traeger sah vier Punkte nebeneinander und probierte den
// Teilnehmerimport, bevor es einen Kurs gab; das schlaegt fehl und sieht aus wie ein Fehler
// des Systems.
//
// Und es fehlte die klare Aussage: darf ich produktiv arbeiten? Ein Fortschrittsbalken bei
// 80 Prozent beantwortet das nicht.

const clean=(v:unknown,n=500)=>safeString(v,n);

type Schritt={schluessel:string;titel:string;pflicht:boolean;braucht:string[];erledigt:boolean;hinweis:string};

/**
 * Die Schritte in Abhaengigkeit voneinander - in EINER Abfrage je Zaehlung, nicht je Schritt.
 *
 * 'braucht' ist keine Anzeigehilfe: ein Schritt, dessen Voraussetzung fehlt, ist gesperrt. Wer
 * ihn trotzdem oeffnet, erlebt einen Fehler, den er sich selbst zuschreibt.
 */
export async function onboardingSchritte(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  const z=await env.DB.prepare(`SELECT
    (SELECT COUNT(*) FROM courses WHERE tenant_id=? AND is_active=1) AS kurse,
    (SELECT COUNT(*) FROM memberships WHERE tenant_id=? AND role='class_admin') AS leitungen,
    (SELECT COUNT(*) FROM memberships WHERE tenant_id=? AND role='participant') AS teilnehmer,
    (SELECT COUNT(*) FROM lessons WHERE tenant_id=?) AS stunden,
    (SELECT COUNT(*) FROM tenant_settings WHERE tenant_id=? AND logo_url IS NOT NULL AND logo_url<>'') AS branding,
    (SELECT COUNT(*) FROM policy_definitions WHERE tenant_id=? AND status='aktiv') AS regelwerke,
    (SELECT COUNT(*) FROM retention_policies WHERE tenant_id=?) AS aufbewahrung`)
    .bind(tenantId,tenantId,tenantId,tenantId,tenantId,tenantId,tenantId).first<Record<string,number>>();
  const n=(k:string)=>Number(z?.[k]??0);
  const zustand=await env.DB.prepare('SELECT aktueller_schritt,uebersprungen_json,abgeschlossen_am FROM onboarding_wizard_state WHERE tenant_id=?')
    .bind(tenantId).first<{aktueller_schritt:string|null;uebersprungen_json:string;abgeschlossen_am:string|null}>();
  let uebersprungen:Record<string,string>={};
  try{uebersprungen=JSON.parse(String(zustand?.uebersprungen_json??'{}'));}catch{}

  const roh:Schritt[]=[
    {schluessel:'kurse',titel:'Klassen und Kurse anlegen',pflicht:true,braucht:[],erledigt:n('kurse')>0,
      hinweis:'Alles Weitere haengt daran: ohne Kurs gibt es niemanden, dem ein Stundenplan oder eine Teilnehmerliste gehoert.'},
    {schluessel:'leitungen',titel:'Klassenverantwortliche festlegen',pflicht:true,braucht:['kurse'],erledigt:n('leitungen')>0,
      hinweis:'Ohne verantwortliche Person hat im Betrieb niemand Zugriff auf Klassenbuch und Bewertung.'},
    {schluessel:'teilnehmer',titel:'Teilnehmende einlesen',pflicht:true,braucht:['kurse'],erledigt:n('teilnehmer')>0,
      hinweis:'Der Import ordnet die Personen den Kursen zu - deshalb muessen die Kurse vorher stehen.'},
    {schluessel:'stundenplan',titel:'Stundenplan einlesen',pflicht:true,braucht:['kurse','teilnehmer'],erledigt:n('stunden')>0,
      hinweis:'Der Plan verweist auf Kurse und erzeugt die Termine, aus denen die Anwesenheit entsteht.'},
    {schluessel:'regelwerke',titel:'Hausordnung und Nutzungsregeln hinterlegen',pflicht:true,braucht:['kurse'],erledigt:n('regelwerke')>0,
      hinweis:'Eine Regel, die niemand bestaetigt hat, laesst sich spaeter nicht durchsetzen.'},
    {schluessel:'aufbewahrung',titel:'Aufbewahrungsfristen festlegen',pflicht:true,braucht:[],erledigt:n('aufbewahrung')>0,
      hinweis:'Ohne Frist wird nichts geloescht - und Daten ohne Loeschfrist sind ein Befund in jeder Pruefung.'},
    {schluessel:'branding',titel:'Logo und Farben festlegen',pflicht:false,braucht:[],erledigt:n('branding')>0,
      hinweis:'Kosmetik, aber das Erste, was Teilnehmende sehen.'},
  ];
  const fertig=new Set(roh.filter(s=>s.erledigt||uebersprungen[s.schluessel]).map(s=>s.schluessel));
  const schritte=roh.map(s=>({...s,
    uebersprungen:uebersprungen[s.schluessel]??null,
    // Gesperrt heisst gesperrt: ein Schritt, dessen Voraussetzung fehlt, wird nicht angeboten.
    gesperrt:!s.erledigt&&s.braucht.some(b=>!fertig.has(b)),
    fehlt:s.braucht.filter(b=>!fertig.has(b))}));
  const offenePflicht=schritte.filter(s=>s.pflicht&&!s.erledigt&&!s.uebersprungen);
  const naechster=schritte.find(s=>!s.erledigt&&!s.uebersprungen&&!s.gesperrt)??null;
  return{schritte,
    erledigt:schritte.filter(s=>s.erledigt).length,gesamt:schritte.length,
    naechster:naechster?.schluessel??null,
    // Das Verdikt, das ein Fortschrittsbalken nicht gibt.
    betriebsbereit:offenePflicht.length===0,
    fehlt_fuer_betrieb:offenePflicht.map(s=>s.titel),
    zuletzt:zustand?.aktueller_schritt??null,
    abgeschlossen_am:zustand?.abgeschlossen_am??null};
}

/** Den Stand merken, damit nach einer Unterbrechung nicht von vorn begonnen wird. */
export async function merkeOnboardingSchritt(env:Env,auth:CoreAuthContext,tenantId:string,schluessel:string){
  requireRole(auth,'tenant_admin');
  const s=clean(schluessel,60);
  const ts=nowIso();
  await env.DB.prepare(`INSERT INTO onboarding_wizard_state(tenant_id,aktueller_schritt,uebersprungen_json,zuletzt_am) VALUES(?,?,'{}',?)
    ON CONFLICT(tenant_id) DO UPDATE SET aktueller_schritt=excluded.aktueller_schritt,zuletzt_am=excluded.zuletzt_am`)
    .bind(tenantId,s,ts).run();
  return{zuletzt:s};
}

/**
 * Einen Schritt bewusst uebergehen - mit Grund.
 *
 * Ohne Grund waere spaeter nicht unterscheidbar, ob der Punkt entschieden oder vergessen wurde.
 * Ein Pflichtschritt laesst sich nicht uebergehen: sonst waere "betriebsbereit" wertlos.
 */
export async function ueberspringeOnboardingSchritt(env:Env,auth:CoreAuthContext,tenantId:string,schluessel:string,grund:string){
  requireRole(auth,'tenant_admin');
  const s=clean(schluessel,60),text=clean(grund,500);
  const alle=await onboardingSchritte(env,auth,tenantId);
  const schritt=alle.schritte.find(x=>x.schluessel===s);
  if(!schritt)throw new Error('ONBOARDING_SCHRITT_UNBEKANNT');
  if(schritt.pflicht)throw new Error('ONBOARDING_PFLICHTSCHRITT');
  if(text.length<10)throw new Error('ONBOARDING_GRUND_ERFORDERLICH');
  const zustand=await env.DB.prepare('SELECT uebersprungen_json FROM onboarding_wizard_state WHERE tenant_id=?').bind(tenantId).first<{uebersprungen_json:string}>();
  let karte:Record<string,string>={};
  try{karte=JSON.parse(String(zustand?.uebersprungen_json??'{}'));}catch{}
  karte[s]=text;
  const ts=nowIso();
  await env.DB.prepare(`INSERT INTO onboarding_wizard_state(tenant_id,aktueller_schritt,uebersprungen_json,zuletzt_am) VALUES(?,NULL,?,?)
    ON CONFLICT(tenant_id) DO UPDATE SET uebersprungen_json=excluded.uebersprungen_json,zuletzt_am=excluded.zuletzt_am`)
    .bind(tenantId,JSON.stringify(karte),ts).run();
  return{uebersprungen:s};
}

/** Abschliessen geht nur, wenn es wirklich geht. */
export async function schliesseOnboardingAb(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  const stand=await onboardingSchritte(env,auth,tenantId);
  if(!stand.betriebsbereit)throw new Error('ONBOARDING_NICHT_BETRIEBSBEREIT');
  const ts=nowIso();
  await env.DB.prepare(`INSERT INTO onboarding_wizard_state(tenant_id,aktueller_schritt,uebersprungen_json,zuletzt_am,abgeschlossen_am) VALUES(?,NULL,'{}',?,?)
    ON CONFLICT(tenant_id) DO UPDATE SET abgeschlossen_am=excluded.abgeschlossen_am,zuletzt_am=excluded.zuletzt_am`)
    .bind(tenantId,ts,ts).run();
  return{abgeschlossen_am:ts};
}

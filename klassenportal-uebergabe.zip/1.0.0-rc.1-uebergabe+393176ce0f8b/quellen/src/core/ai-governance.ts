import type { CoreAuthContext, Env } from './types.js';
import { requireRole } from './permissions.js';
import { frageKiGesteuert, registriereKiLauf, stelleKiAuftragEin, type Laufauftrag, type Laufschritt } from './ai-workload.js';
import { id, nowIso, safeString } from './utils.js';

// KI-Steuerung: Provenienz und Evaluation (K12).
//
// Das Kostenbudget und die Datenklassifizierung sitzen im Gateway, weil sie VOR dem Aufruf
// greifen muessen. Hier stehen die beiden Dinge, die DANACH zaehlen:
//
//  - PROVENIENZ. Was die KI geschrieben hat, bleibt als KI-erzeugt erkennbar - mit Modell,
//    Zeitpunkt und Eingabehash. Ein Zeugnistext oder eine Bewertungsbegruendung, die unmarkiert
//    aus einem Modell stammt, ist eine Aussage des Traegers, die niemand geprueft hat. Genau
//    daran zerbricht die Beurteilung im Widerspruchsverfahren.
//  - EVALUATION. Feste Faelle, wiederholbarer Lauf. Ohne sie ist jeder Modellwechsel ein
//    Blindflug: die Antworten sehen weiter gut aus, und dass sie schlechter geworden sind,
//    merkt der Traeger an der ersten Beschwerde.

const clean=(v:unknown,n=2000)=>safeString(v,n);
// Felder, in denen unmarkierter KI-Text nichts zu suchen hat. Die Liste ist bewusst eng: sie
// nennt die Stellen, an denen ein Text zur rechtsverbindlichen Aussage des Traegers wird.
export const NACHWEISFELDER=new Set<string>(['zeugnis_text','bewertung_begruendung','beurteilung','entscheidung_begruendung','zertifikat_text']);

/** Eine Ausgabe als KI-erzeugt vermerken. */
export async function markiereKiInhalt(env:Env,tenantId:string,eintrag:{objekt_typ:string;objekt_id:string;feld:string;
  invocation_id?:string|null;anbieter:string;modell:string;eingabe_hash:string}){
  const ts=nowIso();
  await env.DB.prepare('INSERT INTO ai_generated_content(id,tenant_id,objekt_typ,objekt_id,feld,invocation_id,anbieter,modell,eingabe_hash,erzeugt_am) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,objekt_typ,objekt_id,feld) DO UPDATE SET invocation_id=excluded.invocation_id,anbieter=excluded.anbieter,modell=excluded.modell,eingabe_hash=excluded.eingabe_hash,erzeugt_am=excluded.erzeugt_am,bestaetigt_von=NULL,bestaetigt_am=NULL')
    .bind(id('kig_'),tenantId,clean(eintrag.objekt_typ,60),clean(eintrag.objekt_id,120),clean(eintrag.feld,60),
      eintrag.invocation_id??null,clean(eintrag.anbieter,60),clean(eintrag.modell,120),clean(eintrag.eingabe_hash,80),ts).run();
  return{markiert:true,erzeugt_am:ts};
}

/**
 * Ein Mensch bestaetigt den Text - und erst damit wird er zur Aussage des Traegers.
 *
 * Die Markierung bleibt trotzdem stehen. Sie zu loeschen hiesse, die Herkunft zu verwischen;
 * bestaetigt heisst "geprueft und uebernommen", nicht "war nie KI".
 */
export async function bestaetigeKiInhalt(env:Env,auth:CoreAuthContext,tenantId:string,objektTyp:string,objektId:string,feld:string){
  requireRole(auth,'class_admin');
  const zeile=await env.DB.prepare('SELECT id,bestaetigt_am FROM ai_generated_content WHERE tenant_id=? AND objekt_typ=? AND objekt_id=? AND feld=?')
    .bind(tenantId,clean(objektTyp,60),clean(objektId,120),clean(feld,60)).first<{id:string;bestaetigt_am:string|null}>();
  if(!zeile)throw new Error('KI_HERKUNFT_NICHT_GEFUNDEN');
  const ts=nowIso();
  await env.DB.prepare('UPDATE ai_generated_content SET bestaetigt_von=?,bestaetigt_am=? WHERE id=? AND tenant_id=?').bind(auth.userId,ts,zeile.id,tenantId).run();
  return{bestaetigt_am:ts};
}

/** Die Herkunft eines Feldes - fuer die Anzeige neben dem Text. */
export async function kiHerkunft(env:Env,tenantId:string,objektTyp:string,objektId:string){
  return ((await env.DB.prepare('SELECT feld,anbieter,modell,eingabe_hash,erzeugt_am,bestaetigt_von,bestaetigt_am FROM ai_generated_content WHERE tenant_id=? AND objekt_typ=? AND objekt_id=? ORDER BY feld')
    .bind(tenantId,clean(objektTyp,60),clean(objektId,120)).all<Record<string,unknown>>()).results)??[];
}

/**
 * Der Torwaechter vor jedem Nachweis.
 *
 * Wer ein Zeugnis erzeugt oder eine Bewertung festschreibt, ruft das hier auf. Unbestaetigter
 * KI-Text in einem Nachweisfeld fuehrt zur Verweigerung - nicht zu einer Warnung, die niemand
 * liest. EINE Abfrage fuer alle Felder des Objekts.
 */
export async function assertKeinUngepruefterKiText(env:Env,tenantId:string,objektTyp:string,objektId:string){
  const offen=((await env.DB.prepare('SELECT feld FROM ai_generated_content WHERE tenant_id=? AND objekt_typ=? AND objekt_id=? AND bestaetigt_am IS NULL')
    .bind(tenantId,clean(objektTyp,60),clean(objektId,120)).all<{feld:string}>()).results)??[];
  const kritisch=offen.filter(z=>NACHWEISFELDER.has(z.feld));
  if(kritisch.length)throw new Error('KI_TEXT_UNBESTAETIGT');
  return{geprueft:true};
}

/** Evaluationsfaelle pflegen. */
export async function legeEvaluationsfallAn(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const zweck=clean(input.zweck,80),bezeichnung=clean(input.bezeichnung,200),eingabe=clean(input.eingabe,8000);
  if(!zweck||bezeichnung.length<3||eingabe.length<10)throw new Error('KI_FALL_UNVOLLSTAENDIG');
  const erwartet=(Array.isArray(input.erwartet)?input.erwartet:[]).map(v=>clean(v,200)).filter(Boolean).slice(0,20);
  const verboten=(Array.isArray(input.verboten)?input.verboten:[]).map(v=>clean(v,200)).filter(Boolean).slice(0,20);
  // Ein Fall ohne jede Erwartung prueft nichts. Er wuerde die Quote schoenrechnen.
  if(!erwartet.length&&!verboten.length)throw new Error('KI_FALL_OHNE_ERWARTUNG');
  const ts=nowIso(),fallId=id('kie_');
  await env.DB.prepare('INSERT INTO ai_evaluation_cases(id,tenant_id,zweck,bezeichnung,eingabe,erwartet_json,verboten_json,aktiv,created_at) VALUES(?,?,?,?,?,?,?,1,?)')
    .bind(fallId,tenantId,zweck,bezeichnung,eingabe,JSON.stringify(erwartet),JSON.stringify(verboten),ts).run();
  return{id:fallId};
}

/**
 * Den Pruefsatz laufen lassen.
 *
 * Gegen ein KONKRETES Modell, nicht gegen die Kette: sonst misst der Lauf das Ausweichen mit und
 * sagt nichts ueber das Modell, das man bewerten wollte. Verbotene Inhalte wiegen schwerer als
 * fehlende erwartete - bei einem Bildungstraeger ist eine falsche Auskunft teurer als eine
 * unvollstaendige.
 */
/**
 * Den Bewertungslauf EINSTELLEN - nicht ausfuehren.
 *
 * Vorher lief er im Vordergrund: bis zu fuenfzig Modellaufrufe nacheinander, waehrend die
 * Traegerleitung auf eine Antwort wartete. Das war nicht nur zumutungsseitig falsch, es sprengte
 * auch das Unteranfragenbudget eines Aufrufs - 1000 gelten fuer ALLE Arbeiten zusammen.
 *
 * Jetzt entsteht ein Auftrag, der in Haeppchen laeuft und seinen Fortschritt meldet.
 */
export async function laufeEvaluation(env:Env,auth:CoreAuthContext,tenantId:string,modellId:string,zweck:string){
  requireRole(auth,'tenant_admin');
  const modell=await env.DB.prepare('SELECT id,anbieter,modell FROM ai_models WHERE id=? AND (tenant_id=? OR tenant_id IS NULL)')
    .bind(clean(modellId,120),tenantId).first<{id:string;anbieter:string;modell:string}>();
  if(!modell)throw new Error('KI_MODELL_NICHT_GEFUNDEN');
  const anzahl=await env.DB.prepare('SELECT COUNT(*) n FROM ai_evaluation_cases WHERE (tenant_id=? OR tenant_id IS NULL) AND zweck=? AND aktiv=1')
    .bind(tenantId,clean(zweck,80)).first<{n:number}>();
  const faelle=Number(anzahl?.n??0);
  if(!faelle)throw new Error('KI_KEINE_FAELLE');
  const auftrag=await stelleKiAuftragEin(env,auth,tenantId,{zweck:`eval:${clean(zweck,60)}`,
    eingabe:JSON.stringify({modell_id:modell.id,zweck:clean(zweck,80)}),
    teile:Math.min(20,faelle)});
  return{...auftrag,modell:`${modell.anbieter}/${modell.modell}`,faelle};
}

/** Wie viele Testfaelle ein einzelner Lauf hoechstens abarbeitet. */
export const FAELLE_JE_HAEPPCHEN=10;
/** Wie viele Testfaelle ein Bewertungslauf insgesamt umfasst. */
export const FAELLE_HOECHSTENS=50;

/**
 * Der Lauf selbst - in Haeppchen, mit Fortschritt und Wiederaufnahme.
 *
 * Nach jedem Haeppchen wird der Zwischenstand festgehalten. Bricht der Aufruf danach ab, macht der
 * naechste Lauf bei Fall 11 weiter und nicht bei Fall 1: fuer die Kosten ist das der Unterschied
 * zwischen einem halben und drei ganzen Bewertungslaeufen.
 */
async function bewertungslauf(env:Env,auftrag:Laufauftrag,melde:Laufschritt){
  let vorgabe:{modell_id:string;zweck:string};
  try{vorgabe=JSON.parse(auftrag.eingabe);}catch{throw new Error('KI_EVAL_AUFTRAG_UNLESBAR');}
  const tenantId=auftrag.tenant_id;
  const alle=((await env.DB.prepare('SELECT id,bezeichnung,eingabe,erwartet_json,verboten_json FROM ai_evaluation_cases WHERE (tenant_id=? OR tenant_id IS NULL) AND zweck=? AND aktiv=1 ORDER BY bezeichnung LIMIT ?')
    .bind(tenantId,clean(vorgabe.zweck,80),FAELLE_HOECHSTENS)
    .all<{id:string;bezeichnung:string;eingabe:string;erwartet_json:string;verboten_json:string}>()).results)??[];
  if(!alle.length)throw new Error('KI_KEINE_FAELLE');

  // Der Zwischenstand liegt am Auftrag. Er ist der Grund, warum eine Wiederaufnahme nicht von
  // vorn anfaengt.
  const zwischen=await env.DB.prepare('SELECT ergebnis_json FROM ai_jobs WHERE id=?').bind(auftrag.id).first<{ergebnis_json:string|null}>();
  let befunde:{fall:string;bestanden:boolean;grund:string}[]=[];
  try{befunde=zwischen?.ergebnis_json?(JSON.parse(zwischen.ergebnis_json).befunde??[]):[];}catch{befunde=[];}

  const ab=befunde.length;
  const haeppchen=alle.slice(ab,ab+FAELLE_JE_HAEPPCHEN);
  for(const f of haeppchen){
    let text='';
    try{
      // Der Pruefsatz laeuft mit der Einstufung aus dem Register: ein Testfall enthaelt keine
      // Personendaten, und enthielte er welche, waere er als Testfall schon falsch.
      const a=await frageKiGesteuert(env,tenantId,{zweck:auftrag.zweck,eingabe:f.eingabe,akteur:auftrag.angefordert_von,imHintergrund:true});
      text=String(a.text??'').toLowerCase();
    }catch(e){
      befunde.push({fall:f.bezeichnung,bestanden:false,grund:String((e as Error)?.message??'FEHLER')});
      continue;
    }
    let erwartet:string[]=[],verboten:string[]=[];
    try{erwartet=JSON.parse(f.erwartet_json||'[]');}catch{}
    try{verboten=JSON.parse(f.verboten_json||'[]');}catch{}
    const fehltErwartet=erwartet.filter(e=>!text.includes(String(e).toLowerCase()));
    const trifftVerboten=verboten.filter(v=>text.includes(String(v).toLowerCase()));
    if(trifftVerboten.length)befunde.push({fall:f.bezeichnung,bestanden:false,grund:`verboten: ${trifftVerboten.join(', ')}`});
    else if(fehltErwartet.length)befunde.push({fall:f.bezeichnung,bestanden:false,grund:`fehlt: ${fehltErwartet.join(', ')}`});
    else befunde.push({fall:f.bezeichnung,bestanden:true,grund:''});
  }

  const bestanden=befunde.filter(b=>b.bestanden).length;
  const fertig=befunde.length>=alle.length;
  const teilstand=JSON.stringify({befunde,faelle:alle.length});
  await env.DB.prepare('UPDATE ai_jobs SET ergebnis_json=? WHERE id=?').bind(teilstand,auftrag.id).run();
  await melde(Math.round(befunde.length/alle.length*100),`Fall ${befunde.length} von ${alle.length}`,befunde.length);
  if(!fertig)return{fertig:false,schritt:`Fall ${befunde.length} von ${alle.length} - macht im naechsten Lauf weiter`};

  const quote=Math.round(bestanden/befunde.length*100);
  const ts=nowIso(),laufId=id('kil_');
  await env.DB.prepare('INSERT INTO ai_evaluation_runs(id,tenant_id,modell_id,zweck,faelle,bestanden,quote_prozent,befunde_json,gelaufen_von,gelaufen_am) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .bind(laufId,tenantId,clean(vorgabe.modell_id,120),clean(vorgabe.zweck,80),befunde.length,bestanden,quote,JSON.stringify(befunde),auftrag.angefordert_von,ts).run();
  return{fertig:true,ergebnis:{id:laufId,faelle:befunde.length,bestanden,quote_prozent:quote,befunde}};
}

registriereKiLauf('eval:',bewertungslauf);

/**
 * Wurde es schlechter?
 *
 * Der Vergleich ist der eigentliche Zweck der Evaluation. Zwei Abfragen fuer beliebig viele
 * Laeufe - eine je Modell waere bei fuenf Modellen schon Unfug.
 */
export async function evaluationsvergleich(env:Env,auth:CoreAuthContext,tenantId:string,zweck:string){
  requireRole(auth,'tenant_admin');
  const laeufe=((await env.DB.prepare(`SELECT r.id,r.modell_id,m.anbieter,m.modell,r.quote_prozent,r.faelle,r.bestanden,r.gelaufen_am
    FROM ai_evaluation_runs r JOIN ai_models m ON m.id=r.modell_id WHERE (r.tenant_id=? OR r.tenant_id IS NULL) AND r.zweck=?
    ORDER BY r.gelaufen_am DESC LIMIT 50`).bind(tenantId,clean(zweck,80)).all<Record<string,unknown>>()).results)??[];
  const jeModell=new Map<string,Record<string,unknown>[]>();
  for(const l of laeufe){
    const k=String(l.modell_id);
    if(!jeModell.has(k))jeModell.set(k,[]);
    jeModell.get(k)!.push(l);
  }
  const zeilen=[...jeModell.values()].map(ls=>{
    const neu=ls[0],alt=ls[1]??null;
    const veraenderung=alt?Number(neu.quote_prozent)-Number(alt.quote_prozent):null;
    return{modell:`${neu.anbieter}/${neu.modell}`,quote_prozent:Number(neu.quote_prozent),
      vorher_prozent:alt?Number(alt.quote_prozent):null,veraenderung,
      // Das ist der Satz, der im Cockpit stehen muss - nicht die Zahl allein.
      schlechter_geworden:veraenderung!==null&&veraenderung<0,gelaufen_am:String(neu.gelaufen_am)};
  }).sort((a,b)=>b.quote_prozent-a.quote_prozent);
  return{zweck,modelle:zeilen,bestes:zeilen[0]??null,verschlechterungen:zeilen.filter(z=>z.schlechter_geworden)};
}

/** Was hat die KI diesen Monat gekostet und wie oft ist sie ausgewichen? */
export async function kiBetriebsstand(env:Env,auth:CoreAuthContext,tenantId:string,seit?:string){
  requireRole(auth,'tenant_admin');
  const von=clean(seit,40)||new Date(Date.now()-30*86400000).toISOString();
  const z=await env.DB.prepare(`SELECT COUNT(*) AS aufrufe,
    SUM(CASE WHEN status='erfolg' THEN 1 ELSE 0 END) AS erfolg,
    SUM(CASE WHEN status='abgelehnt' THEN 1 ELSE 0 END) AS abgelehnt,
    SUM(CASE WHEN status='fehler' THEN 1 ELSE 0 END) AS fehler,
    SUM(CASE WHEN ausgewichen_json<>'[]' THEN 1 ELSE 0 END) AS mit_ausweichen,
    SUM(kosten_cent) AS kosten_cent
    FROM ai_invocations WHERE tenant_id=? AND created_at>=?`).bind(tenantId,von).first<Record<string,number>>();
  const unbestaetigt=await env.DB.prepare('SELECT COUNT(*) AS n FROM ai_generated_content WHERE tenant_id=? AND bestaetigt_am IS NULL')
    .bind(tenantId).first<{n:number}>();
  return{seit:von,...(z??{}),unbestaetigte_texte:Number(unbestaetigt?.n??0)};
}

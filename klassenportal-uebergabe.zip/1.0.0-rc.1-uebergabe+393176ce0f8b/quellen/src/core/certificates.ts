import type { CoreAuthContext, Env } from './types.js';
import { certificateEligibleParticipants } from './certificate-eligible.js';
import { renderePlatzhalter } from './document-placeholders.js';
import { audit } from './audit.js';
import { requireCourseAccess, requireRole } from './permissions.js';
import { b64, id, nowIso, randomBytes, safeString, sha256Text } from './utils.js';
import { baueNachweis, ladeSignierschluessel, pruefeNachweis, signiereNachweis, type Nachweisdokument, type Schluesselverzeichnis, type Signierschluessel } from './certificate-credentials.js';
import { nachfolgeFuerAussteller } from './tenant-succession.js';
import { lernfortschritt } from './learning-progress.js';

const SYSTEM='system_workflow_service';
type Template={id:string;tenant_id:string;name:string;document_type:string;title_template:string;body_template:string;min_attendance_percent:number|null;require_progress_complete:number;approval_mode:'manual'|'objective_auto';is_active:number;version:number};
type RecordRow={id:string;tenant_id:string;course_id:string;user_id:string;template_id:string;template_version:number;status:'prepared'|'approved'|'issued'|'revoked';serial_number:string;snapshot_json:string;prepared_by:string;prepared_at:string;approved_by:string|null;approved_at:string|null;issued_by:string|null;issued_at:string|null;revoked_at:string|null;revocation_reason:string|null};

function serial(){const d=new Date().toISOString().slice(0,10).replaceAll('-','');return `KP-${d}-${crypto.randomUUID().replaceAll('-','').slice(0,12).toUpperCase()}`;}
// Es gibt im Portal genau EINEN Platzhalter-Renderer (document-placeholders.ts): ersetzt wird nur,
// was ausdruecklich in der Wertetabelle steht, ausgewertet wird nichts. Hier stand bis dahin eine
// eigene, laxere Fassung - sie ersetzte einen unbekannten Platzhalter still durch nichts und liess
// damit eine Luecke im Zeugnis, die niemandem auffiel. Jetzt bleibt er sichtbar stehen.
function render(template:string,data:Record<string,string|number>){return renderePlatzhalter(template,new Map(Object.entries(data).map(([k,v])=>[k.toLowerCase(),String(v)])));}
async function ensureCourse(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){const c=await env.DB.prepare('SELECT id,name,code,start_date,end_date FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,courseId).first<Record<string,unknown>>();if(!c)throw new Error('COURSE_NOT_FOUND');requireCourseAccess(auth,courseId);return c;}
async function participant(env:Env,tenantId:string,courseId:string,userId:string){const p=await env.DB.prepare("SELECT u.id,u.display_name FROM memberships m JOIN users u ON u.id=m.user_id JOIN tenant_users tu ON tu.tenant_id=m.tenant_id AND tu.user_id=m.user_id WHERE m.tenant_id=? AND m.course_id=? AND m.user_id=? AND m.role='participant' AND u.status='active' AND tu.status='active' LIMIT 1").bind(tenantId,courseId,userId).first<Record<string,unknown>>();if(!p)throw new Error('PARTICIPANT_NOT_FOUND');return p;}
async function template(env:Env,tenantId:string,templateId:string,activeOnly=true){const t=await env.DB.prepare(`SELECT * FROM certificate_templates WHERE tenant_id=? AND id=?${activeOnly?' AND is_active=1':''}`).bind(tenantId,templateId).first<Template>();if(!t)throw new Error('CERTIFICATE_TEMPLATE_NOT_FOUND');return t;}
async function metrics(env:Env,tenantId:string,courseId:string,userId:string){const a=await env.DB.prepare("SELECT COUNT(*) recorded,SUM(CASE WHEN status IN ('present','remote_present','late') THEN 1 ELSE 0 END) attended FROM attendance_records WHERE tenant_id=? AND course_id=? AND user_id=? AND status<>'not_recorded'").bind(tenantId,courseId,userId).first<Record<string,unknown>>(),p=await lernfortschritt(env,tenantId,courseId,userId),recorded=Number(a?.recorded||0),attended=Number(a?.attended||0),progressTotal=p.total,progressDone=p.done;return{attendancePercent:recorded?Math.round(attended/recorded*1000)/10:0,progressTotal,progressDone,progressComplete:p.complete};}
function criteria(t:Template,m:{attendancePercent:number;progressComplete:boolean}){const attendanceOk=t.min_attendance_percent===null||m.attendancePercent>=Number(t.min_attendance_percent),progressOk=!t.require_progress_complete||m.progressComplete;return{attendanceOk,progressOk,passed:attendanceOk&&progressOk};}
async function event(env:Env,tenantId:string,certificateId:string,type:string,actor:string|null,detail?:unknown){await env.DB.prepare('INSERT INTO certificate_events(id,tenant_id,certificate_id,event_type,actor_user_id,detail_json,created_at) VALUES(?,?,?,?,?,?,?)').bind(id('cer_'),tenantId,certificateId,type,actor,detail===undefined?null:JSON.stringify(detail),nowIso()).run();}

// --- Selbsttragender Nachweis ------------------------------------------------------------------
// Warum das hier ueberhaupt steht: die Pruefung ueber verification_token_hash findet den Nachweis
// in certificate_records. Diese Tabelle haengt mit ON DELETE CASCADE an tenants. Loescht der
// Betreiber am Vertragsende den Mandanten, sind alle Zeugnisse dieses Traegers unpruefbar - bei
// Abschlusszeugnissen mit bis zu 60 Jahren Aufbewahrungsfrist ist das kein Randfall, sondern der
// Regelfall. Deshalb bekommt jedes AUSGESTELLTE Zeugnis zusaetzlich ein Dokument mit, das sich
// selbst traegt. Die Tokenpruefung bleibt daneben bestehen; sie ist die bequeme, der signierte
// Nachweis die dauerhafte Antwort.

/** Wo der oeffentliche Schluessel und die Widerrufsliste dauerhaft liegen. */
function nachweisAdressen(env:Env){const origin=safeString(env.APP_ORIGIN,300);return{schluessel:origin?`${origin}/api/certificates/issuer-keys`:null,widerruf:origin?`${origin}/api/certificates/revocations`:null,betreiber:origin||null};}

// Der oeffentliche Schluessel gehoert dorthin, wo er den Mandanten UEBERLEBT: in eine Tabelle des
// Betreibers ohne tenant_id (certificate_issuer_keys, Migration 0117). Er ist kein Mandantendatum -
// er ist das Gegenstueck zu einer Unterschrift, die der Betreiber geleistet hat, und ohne ihn ist
// jeder alte Nachweis wertlos. Deshalb wird er beim ersten Gebrauch eingetragen und danach nie
// wieder geloescht; ausser Dienst gestellt wird er ueber retired_at.
async function schluesselHinterlegen(env:Env,s:Signierschluessel,ts:string){
  await env.DB.prepare('INSERT INTO certificate_issuer_keys(key_id,algorithm,public_jwk,thumbprint,first_used_at,last_used_at) VALUES(?,?,?,?,?,?) ON CONFLICT(key_id) DO UPDATE SET last_used_at=excluded.last_used_at')
    .bind(s.keyId,s.algorithmus,JSON.stringify(s.oeffentlichJwk),s.fingerabdruck,ts,ts).run();
}

/**
 * Erzeugt und signiert das Nachweisdokument. Wird VOR dem Schreiben des Zeugnisses aufgerufen:
 * fehlt der Signierschluessel, bricht das Ausstellen hier ab - laut und ohne halbe Zeile in der
 * Datenbank. Ein stillschweigend unsigniertes Zeugnis waere das schlechteste Ergebnis: es saehe
 * fertig aus und waere genau dann wertlos, wenn es nach Jahren geprueft werden soll.
 */
async function nachweisSignieren(env:Env,tenantId:string,tenantName:string,serialNumber:string,snapshot:Record<string,unknown>,ausgestelltAm:string){
  const schluessel=await ladeSignierschluessel(env);
  const vorlage=(snapshot.template??{}) as Record<string,unknown>;
  const dokument=baueNachweis({
    seriennummer:serialNumber,
    ausgestelltAm,
    ausstellerId:tenantId,
    ausstellerName:String(tenantName||snapshot.provider||''),
    betreiber:nachweisAdressen(env).betreiber,
    inhalt:{
      name:String(snapshot.participantName||''),
      documentTitle:String(snapshot.title||''),
      documentType:String(vorlage.type||''),
      statement:String(snapshot.body||''),
      courseName:String(snapshot.courseName||''),
      courseCode:String(snapshot.courseCode||''),
      courseStart:snapshot.courseStart??null,
      courseEnd:snapshot.courseEnd??null,
      attendancePercent:Number(snapshot.attendancePercent??0),
      issuedAt:ausgestelltAm,
    },
    widerrufslisteUrl:nachweisAdressen(env).widerruf,
    schluesselverzeichnisUrl:nachweisAdressen(env).schluessel,
  });
  const signiert=await signiereNachweis(dokument,schluessel,'assertionMethod',ausgestelltAm);
  return{schluessel,dokument:signiert};
}

/** Das Schluesselverzeichnis des Betreibers - oeffentlich, ohne Mandantenbezug, dauerhaft. */
export async function certificateIssuerKeys(env:Env){
  const r=await env.DB.prepare('SELECT key_id,algorithm,public_jwk,thumbprint,first_used_at,retired_at FROM certificate_issuer_keys ORDER BY first_used_at').all<Record<string,unknown>>();
  return{keys:(r.results??[]).map(k=>({keyId:String(k.key_id),algorithm:String(k.algorithm),thumbprint:String(k.thumbprint),firstUsedAt:String(k.first_used_at),retiredAt:k.retired_at??null,publicKeyJwk:JSON.parse(String(k.public_jwk||'{}'))}))};
}

/**
 * Die Widerrufsliste. Sie fuehrt bewusst nur Seriennummer und Datum: der Widerrufsgrund kann
 * Gesundheits- oder Disziplinardaten enthalten und hat in einer oeffentlichen Liste nichts zu
 * suchen. Was diese Liste NICHT leisten kann, steht offen in "note" - ein Dokument, das vor dem
 * Widerruf ausgestellt wurde, bleibt mathematisch gueltig; nur diese Liste sagt, dass es nicht
 * mehr gilt.
 */
export async function certificateRevocationList(env:Env){
  const r=await env.DB.prepare('SELECT serial_number,revoked_at FROM certificate_revocations ORDER BY revoked_at DESC LIMIT 5000').all<Record<string,unknown>>();
  return{
    issuedAt:nowIso(),
    entries:(r.results??[]).map(x=>({serialNumber:String(x.serial_number),revokedAt:String(x.revoked_at)})),
    note:'Diese Liste ist der einzige Ort, an dem ein Widerruf sichtbar wird. Ein bereits ausgestelltes Nachweisdokument bleibt auch nach dem Widerruf technisch echt; gueltig ist es nur, solange seine Seriennummer hier nicht steht.',
  };
}

/** Das ausgestellte Dokument zum erneuten Herunterladen. Bequemlichkeit - der Nachweis ist das Dokument in der Hand der Person. */
export async function certificateCredential(env:Env,auth:CoreAuthContext,tenantId:string,certificateId:string){
  requireRole(auth,'participant');
  const r=await env.DB.prepare('SELECT id,course_id,user_id,status,credential_json FROM certificate_records WHERE tenant_id=? AND id=?').bind(tenantId,certificateId).first<Record<string,unknown>>();
  if(!r)throw new Error('CERTIFICATE_NOT_FOUND');
  if(auth.role==='participant'){if(String(r.user_id)!==auth.userId)throw new Error('FORBIDDEN_CERTIFICATE');}
  else requireCourseAccess(auth,String(r.course_id));
  if(!r.credential_json)throw new Error('CERTIFICATE_CREDENTIAL_NOT_AVAILABLE');
  return JSON.parse(String(r.credential_json)) as Nachweisdokument;
}

/**
 * Prueft ein vorgelegtes Dokument. Dieser Server ist dabei nur eine BEQUEMLICHKEIT: er haelt das
 * Schluesselverzeichnis und die Widerrufsliste bereit. Die Pruefung selbst (pruefeNachweis)
 * braucht keine Datenbankzeile des Zeugnisses - sie funktioniert genauso in fremder Hand, mit
 * einer archivierten Kopie des oeffentlichen Schluessels und ohne diesen Server.
 */
export async function verifyCertificateDocument(env:Env,roh:unknown){
  const verzeichnis=(await certificateIssuerKeys(env)).keys as unknown as Schluesselverzeichnis;
  const befund=await pruefeNachweis(roh,verzeichnis);
  const widerruf=befund.serialNumber?await env.DB.prepare('SELECT revoked_at FROM certificate_revocations WHERE serial_number=?').bind(befund.serialNumber).first<Record<string,unknown>>():null;
  return{...befund,revoked:Boolean(widerruf),revokedAt:widerruf?String(widerruf.revoked_at):null,revocationListChecked:true};
}

export async function listCertificateTemplates(env:Env,auth:CoreAuthContext,tenantId:string){requireRole(auth,'class_admin');const r=await env.DB.prepare('SELECT * FROM certificate_templates WHERE tenant_id=? ORDER BY is_active DESC,name,version DESC').bind(tenantId).all<Record<string,unknown>>();return r.results??[];}
export async function saveCertificateTemplate(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){requireRole(auth,'tenant_admin');const templateId=safeString(input.id,120),name=safeString(input.name,200),title=safeString(input.title_template,500),body=safeString(input.body_template,5000),type=String(input.document_type||'participation'),approval=String(input.approval_mode||'manual');if(!name||!title||!body)throw new Error('CERTIFICATE_TEMPLATE_FIELDS_REQUIRED');if(!['participation','completion','achievement','custom'].includes(type))throw new Error('CERTIFICATE_TEMPLATE_TYPE_INVALID');if(!['manual','objective_auto'].includes(approval))throw new Error('CERTIFICATE_APPROVAL_MODE_INVALID');const min=input.min_attendance_percent===null||input.min_attendance_percent===''||input.min_attendance_percent===undefined?null:Number(input.min_attendance_percent);if(min!==null&&(!Number.isFinite(min)||min<0||min>100))throw new Error('CERTIFICATE_ATTENDANCE_CRITERION_INVALID');const progress=input.require_progress_complete===true?1:0;if(approval==='objective_auto'&&(min===null||min<=0)&&!progress)throw new Error('CERTIFICATE_AUTO_CRITERIA_REQUIRED');const active=input.is_active===false?0:1,ts=nowIso();if(templateId){const old=await template(env,tenantId,templateId,false);const version=old.version+1;await env.DB.prepare('UPDATE certificate_templates SET name=?,document_type=?,title_template=?,body_template=?,min_attendance_percent=?,require_progress_complete=?,approval_mode=?,is_active=?,version=?,updated_by=?,updated_at=? WHERE tenant_id=? AND id=?').bind(name,type,title,body,min,progress,approval,active,version,auth.userId,ts,tenantId,templateId).run();await audit(env.DB,auth.userId,'certificate.template.updated',tenantId,undefined,'certificate_template',templateId,{version,approval});return template(env,tenantId,templateId,false);}const newId=id('ctp_');await env.DB.prepare('INSERT INTO certificate_templates(id,tenant_id,name,document_type,title_template,body_template,min_attendance_percent,require_progress_complete,approval_mode,is_active,version,created_by,created_at,updated_by,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,1,?,?,?,?)').bind(newId,tenantId,name,type,title,body,min,progress,approval,active,auth.userId,ts,auth.userId,ts).run();await audit(env.DB,auth.userId,'certificate.template.created',tenantId,undefined,'certificate_template',newId,{approval});return template(env,tenantId,newId,false);}

export async function prepareCertificate(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,userId:string,templateId:string,actorId=auth.userId){requireRole(auth,'class_admin');const [c,p,t,m]=await Promise.all([ensureCourse(env,auth,tenantId,courseId),participant(env,tenantId,courseId,userId),template(env,tenantId,templateId),metrics(env,tenantId,courseId,userId)]),check=criteria(t,m),existing=await env.DB.prepare('SELECT * FROM certificate_records WHERE tenant_id=? AND course_id=? AND user_id=? AND template_id=? AND template_version=?').bind(tenantId,courseId,userId,templateId,t.version).first<RecordRow>();if(existing)return{...existing,snapshot:JSON.parse(existing.snapshot_json),criteria:check};const tenant=await env.DB.prepare('SELECT name FROM tenants WHERE id=?').bind(tenantId).first<{name:string}>(),data={name:String(p.display_name||''),course:String(c.name||''),code:String(c.code||''),start_date:String(c.start_date||''),end_date:String(c.end_date||''),attendance_percent:m.attendancePercent},snapshot={provider:String(tenant?.name||''),participantName:data.name,courseName:data.course,courseCode:data.code,courseStart:data.start_date||null,courseEnd:data.end_date||null,attendancePercent:m.attendancePercent,progress:{total:m.progressTotal,done:m.progressDone,complete:m.progressComplete},template:{id:t.id,name:t.name,type:t.document_type,version:t.version},title:render(t.title_template,data),body:render(t.body_template,data),criteria:check},certId=id('crt_'),ts=nowIso(),serialNo=serial(),autoIssue=t.approval_mode==='objective_auto'&&check.passed,status=autoIssue?'issued':'prepared',systemActor=actorId||SYSTEM;
  // Bei automatischer Ausstellung entsteht das Zeugnis in einem Zug - dann muss auch der
  // selbsttragende Nachweis in diesem Zug entstehen. Signiert wird VOR dem Schreiben: fehlt der
  // Schluessel, bricht der Vorgang ab, statt eine ausgestellte Zeile ohne Nachweis zu hinterlassen.
  const nachweis=autoIssue?await nachweisSignieren(env,tenantId,String(tenant?.name||''),serialNo,snapshot as unknown as Record<string,unknown>,ts):null;
  if(nachweis)await schluesselHinterlegen(env,nachweis.schluessel,ts);
  await env.DB.prepare(`INSERT INTO certificate_records(id,tenant_id,course_id,user_id,template_id,template_version,status,serial_number,snapshot_json,prepared_by,prepared_at,approved_by,approved_at,issued_by,issued_at,credential_json,credential_key_id,credential_algorithm,credential_issued_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(certId,tenantId,courseId,userId,t.id,t.version,status,serialNo,JSON.stringify(snapshot),systemActor,ts,autoIssue?systemActor:null,autoIssue?ts:null,autoIssue?systemActor:null,autoIssue?ts:null,nachweis?JSON.stringify(nachweis.dokument):null,nachweis?nachweis.schluessel.keyId:null,nachweis?nachweis.schluessel.algorithmus:null,nachweis?ts:null,ts,ts).run();await event(env,tenantId,certId,'prepared',systemActor,{criteria:check});if(autoIssue){await event(env,tenantId,certId,'approved',systemActor,{automatic:true,criteria:check});await event(env,tenantId,certId,'issued',systemActor,{automatic:true});await env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,?,?, 'certificate_issued',?,?,?)").bind(id('ntf_'),tenantId,courseId,userId,'Neue Bescheinigung verfügbar',`Die Bescheinigung „${snapshot.title}“ wurde bereitgestellt.`,ts).run();}await audit(env.DB,systemActor,'certificate.prepared',tenantId,courseId,'certificate',certId,{templateId:t.id,templateVersion:t.version,autoIssue});return{...(await env.DB.prepare('SELECT * FROM certificate_records WHERE id=?').bind(certId).first<RecordRow>()),snapshot,criteria:check};}
// Zeugnisse fuer eine ganze Klasse vorbereiten - genau das, was ein Traeger am Ende eines
// Jahrgangs tut. Vorbereitet wird nur; freigegeben und ausgestellt wird weiterhin einzeln und
// ausdruecklich. Wer die Kriterien der Vorlage nicht erfuellt, bekommt kein Zeugnis, sondern
// steht mit Grund in der Liste - geraten wird nichts.
// Cloudflare begrenzt die Zahl der Unteranfragen je Aufruf; jede Datenbankabfrage zaehlt dazu.
// Gemessen kostet eine vorbereitete Bescheinigung rund 11 Abfragen. Eine Obergrenze von 500 haette
// den Lauf mitten im Schreiben abgebrochen - ein Teil der Klasse haette eine Bescheinigung, der
// Rest nicht, und niemand koennte sagen wo die Grenze lag. 70 Personen bleiben sicher darunter und
// decken jede uebliche Klasse ab; groessere Jahrgaenge lassen sich ueber user_ids in Gruppen
// vorbereiten.
const CERTIFICATE_BATCH_MAX=70;
export async function prepareCertificatesForCourse(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,templateId:string,userIds?:unknown){
  requireRole(auth,'class_admin');
  const alle=await certificateEligibleParticipants(env,auth,tenantId,courseId);
  const gewuenscht=Array.isArray(userIds)?new Set(userIds.map(x=>safeString(x,120)).filter(Boolean)):null;
  const teilnehmende=gewuenscht?alle.filter(t=>gewuenscht.has(String(t.id))):alle;
  if(teilnehmende.length>CERTIFICATE_BATCH_MAX)throw new Error('CERTIFICATE_BATCH_TOO_LARGE');
  const vorbereitet:Array<{user_id:string;display_name:string;certificate_id:string;status:string}>=[];
  const offen:Array<{user_id:string;display_name:string;reason:string}>=[];
  for(const t of teilnehmende){
    const userId=String(t.id),name=String(t.display_name||'');
    const zeugnis=await prepareCertificate(env,auth,tenantId,courseId,userId,templateId) as Record<string,unknown>;
    const pruef=zeugnis.criteria as {attendanceOk:boolean;progressOk:boolean;passed:boolean}|undefined;
    if(pruef&&!pruef.passed)offen.push({user_id:userId,display_name:name,reason:!pruef.attendanceOk?'ATTENDANCE_BELOW_MINIMUM':'PROGRESS_INCOMPLETE'});
    else vorbereitet.push({user_id:userId,display_name:name,certificate_id:String(zeugnis.id||''),status:String(zeugnis.status||'')});
  }
  await audit(env.DB,auth.userId,'certificate.batch_prepared',tenantId,courseId,'course',courseId,{templateId,prepared:vorbereitet.length,open:offen.length});
  return{course_id:courseId,template_id:templateId,participants:teilnehmende.length,course_participants:alle.length,prepared:vorbereitet,open:offen,approved:0,issued:0};
}

export async function listCertificateRecords(env:Env,auth:CoreAuthContext,tenantId:string,courseId?:string){requireRole(auth,'class_admin');let sql='SELECT r.*,u.display_name participant_name,u.email,c.name course_name,t.name template_name FROM certificate_records r JOIN users u ON u.id=r.user_id JOIN courses c ON c.id=r.course_id JOIN certificate_templates t ON t.id=r.template_id WHERE r.tenant_id=?',args:unknown[]=[tenantId];if(courseId){requireCourseAccess(auth,courseId,'class_admin');sql+=' AND r.course_id=?';args.push(courseId);}else if(!auth.isPlatformAdmin&&auth.role!=='tenant_admin'){if(!auth.courseIds.length)return[];sql+=` AND r.course_id IN (${auth.courseIds.map(()=>'?').join(',')})`;args.push(...auth.courseIds);}sql+=' ORDER BY r.prepared_at DESC LIMIT 1000';return (await env.DB.prepare(sql).bind(...args).all<Record<string,unknown>>()).results??[];}
async function recordScoped(env:Env,auth:CoreAuthContext,tenantId:string,certificateId:string){const r=await env.DB.prepare('SELECT * FROM certificate_records WHERE tenant_id=? AND id=?').bind(tenantId,certificateId).first<RecordRow>();if(!r)throw new Error('CERTIFICATE_NOT_FOUND');requireCourseAccess(auth,r.course_id);return r;}
export async function approveCertificate(env:Env,auth:CoreAuthContext,tenantId:string,certificateId:string){requireRole(auth,'class_admin');const r=await recordScoped(env,auth,tenantId,certificateId);if(r.status!=='prepared')throw new Error('CERTIFICATE_NOT_APPROVABLE');const snapshot=JSON.parse(r.snapshot_json),check=snapshot.criteria||{};if(check.passed===false)throw new Error('CERTIFICATE_CRITERIA_NOT_MET');const ts=nowIso();await env.DB.prepare("UPDATE certificate_records SET status='approved',approved_by=?,approved_at=?,updated_at=? WHERE id=? AND status='prepared'").bind(auth.userId,ts,ts,certificateId).run();await event(env,tenantId,certificateId,'approved',auth.userId,{manual:true});await audit(env.DB,auth.userId,'certificate.approved',tenantId,r.course_id,'certificate',certificateId);return recordScoped(env,auth,tenantId,certificateId);}
// Ausstellen heisst ab jetzt: unterschreiben. Die Zeile in der Datenbank ist danach nur noch die
// Kopie des Betreibers - der Nachweis selbst ist das signierte Dokument, das die teilnehmende
// Person bekommt und das ohne diese Zeile, ohne diese Datenbank und ohne diesen Server geprueft
// werden kann. Ohne Signierschluessel wird nicht ausgestellt (CERTIFICATE_SIGNING_KEY_MISSING);
// ein unsigniertes Zeugnis waere genau dann wertlos, wenn es Jahre spaeter geprueft wird.
export async function issueCertificate(env:Env,auth:CoreAuthContext,tenantId:string,certificateId:string){
  requireRole(auth,'class_admin');
  const r=await recordScoped(env,auth,tenantId,certificateId);
  if(r.status!=='approved')throw new Error('CERTIFICATE_NOT_ISSUABLE');
  const ts=nowIso(),snapshot=JSON.parse(r.snapshot_json) as Record<string,unknown>;
  const tenant=await env.DB.prepare('SELECT name FROM tenants WHERE id=?').bind(tenantId).first<{name:string}>();
  const nachweis=await nachweisSignieren(env,tenantId,String(tenant?.name||''),r.serial_number,snapshot,ts);
  await schluesselHinterlegen(env,nachweis.schluessel,ts);
  await env.DB.prepare("UPDATE certificate_records SET status='issued',issued_by=?,issued_at=?,credential_json=?,credential_key_id=?,credential_algorithm=?,credential_issued_at=?,updated_at=? WHERE tenant_id=? AND id=? AND status='approved'")
    .bind(auth.userId,ts,JSON.stringify(nachweis.dokument),nachweis.schluessel.keyId,nachweis.schluessel.algorithmus,ts,ts,tenantId,certificateId).run();
  await event(env,tenantId,certificateId,'issued',auth.userId,{manual:true,credential:{keyId:nachweis.schluessel.keyId,algorithm:nachweis.schluessel.algorithmus}});
  await env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,?,?, 'certificate_issued',?,?,?)").bind(id('ntf_'),tenantId,r.course_id,r.user_id,'Neue Bescheinigung verf\u00fcgbar',`Die Bescheinigung \u201e${snapshot.title||'Bescheinigung'}\u201c wurde bereitgestellt.`,ts).run();
  await audit(env.DB,auth.userId,'certificate.issued',tenantId,r.course_id,'certificate',certificateId,{credentialKeyId:nachweis.schluessel.keyId,credentialAlgorithm:nachweis.schluessel.algorithmus});
  return recordScoped(env,auth,tenantId,certificateId);
}
export async function revokeCertificate(env:Env,auth:CoreAuthContext,tenantId:string,certificateId:string,reasonRaw:unknown){requireRole(auth,'tenant_admin');const r=await recordScoped(env,auth,tenantId,certificateId);if(r.status!=='issued')throw new Error('CERTIFICATE_NOT_REVOCABLE');const reason=safeString(reasonRaw,1000);if(!reason)throw new Error('CERTIFICATE_REVOCATION_REASON_REQUIRED');const ts=nowIso();await env.DB.prepare("UPDATE certificate_records SET status='revoked',revoked_by=?,revoked_at=?,revocation_reason=?,verification_token_hash=NULL,updated_at=? WHERE id=? AND status='issued'").bind(auth.userId,ts,reason,ts,certificateId).run();// Der Widerruf muss den Mandanten ueberleben: ein selbsttragendes Dokument kann nicht wissen,
  // dass es widerrufen wurde, und die Zeile in certificate_records verschwindet am Vertragsende
  // mit dem Mandanten. certificate_revocations gehoert deshalb dem Betreiber und traegt bewusst
  // keine tenant_id und keinen Grund - nur Seriennummer und Datum, damit die Liste oeffentlich
  // stehen kann, ohne Gesundheits- oder Disziplinardaten zu offenbaren.
  await env.DB.prepare('INSERT INTO certificate_revocations(serial_number,revoked_at,created_at) VALUES(?,?,?) ON CONFLICT(serial_number) DO UPDATE SET revoked_at=excluded.revoked_at').bind(r.serial_number,ts,ts).run();
  await event(env,tenantId,certificateId,'revoked',auth.userId,{reason});await audit(env.DB,auth.userId,'certificate.revoked',tenantId,r.course_id,'certificate',certificateId,{reason});return recordScoped(env,auth,tenantId,certificateId);}
export async function createVerificationLink(env:Env,auth:CoreAuthContext,tenantId:string,certificateId:string,request:Request){requireRole(auth,'participant');const r=await env.DB.prepare('SELECT * FROM certificate_records WHERE tenant_id=? AND id=?').bind(tenantId,certificateId).first<RecordRow>();if(!r||r.status!=='issued')throw new Error('CERTIFICATE_NOT_FOUND');if(auth.role==='participant'&&r.user_id!==auth.userId)throw new Error('FORBIDDEN_CERTIFICATE');if(auth.role!=='participant')requireCourseAccess(auth,r.course_id);const raw=b64(randomBytes(32)).replace(/[+/=]/g,'').slice(0,43),hash=await sha256Text(raw),ts=nowIso();await env.DB.prepare('UPDATE certificate_records SET verification_token_hash=?,verification_issued_at=?,updated_at=? WHERE id=?').bind(hash,ts,ts,certificateId).run();await event(env,tenantId,certificateId,'verification_rotated',auth.userId);const origin=env.APP_ORIGIN||new URL(request.url).origin;// Ausgeliefert wird die Pruefseite unter /certificate-verify (src/core/page-routes.ts); ein Pfad
// /zertifikat/pruefen gibt es nirgends. Der weitergegebene Link lief also ins Leere - und zwar
// genau der Link, den jemand bekommt, der ein Zeugnis nachpruefen will.
return{url:`${origin}/certificate-verify?nachweis=${encodeURIComponent(raw)}`};}
export async function myCertificates(env:Env,auth:CoreAuthContext,tenantId:string,courseId?:string){requireRole(auth,'participant');let sql="SELECT r.id,r.course_id,r.serial_number,r.status,r.snapshot_json,r.issued_at,c.name course_name FROM certificate_records r JOIN courses c ON c.id=r.course_id WHERE r.tenant_id=? AND r.user_id=? AND r.status IN ('issued','revoked')",args:unknown[]=[tenantId,auth.userId];if(courseId){requireCourseAccess(auth,courseId);sql+=' AND r.course_id=?';args.push(courseId);}sql+=' ORDER BY r.issued_at DESC';const rows=(await env.DB.prepare(sql).bind(...args).all<Record<string,unknown>>()).results??[];return rows.map(r=>({...r,snapshot:JSON.parse(String(r.snapshot_json||'{}'))}));}
export async function verifyCertificate(env:Env,token:string){if(token.length<20||token.length>100)throw new Error('CERTIFICATE_NOT_FOUND');const hash=await sha256Text(token),r=await env.DB.prepare('SELECT r.tenant_id,r.serial_number,r.status,r.snapshot_json,r.issued_at,r.revoked_at,r.revocation_reason FROM certificate_records r WHERE r.verification_token_hash=?').bind(hash).first<Record<string,unknown>>();if(!r)throw new Error('CERTIFICATE_NOT_FOUND');const s=JSON.parse(String(r.snapshot_json||'{}'));return{serialNumber:r.serial_number,status:r.status,issuedAt:r.issued_at,revokedAt:r.revoked_at,revocationReason:r.status==='revoked'?r.revocation_reason:null,document:{title:s.title,participantName:s.participantName,courseName:s.courseName,courseCode:s.courseCode,courseStart:s.courseStart,courseEnd:s.courseEnd,provider:s.provider},
  // Wer ein Zeugnis eines Traegers in der Hand haelt, den es nicht mehr gibt, muss erfahren, wer
  // heute zustaendig ist. Ohne diese Angabe endet die Pruefung bei einem Namen, den niemand mehr
  // findet - und genau das macht ein Zeugnis wertlos.
  nachfolge:await nachfolgeFuerAussteller(env,String(r.tenant_id||''))};}

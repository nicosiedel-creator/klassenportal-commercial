import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { hasPermission } from './enterprise-access.js';
import { SPRACHEN, openQcatPruefen, xmlDokument, type Befund, type XmlKnoten } from './kursnet-open-qcat.js';
import { id, nowIso, safeString } from './utils.js';

// Aus den Portaldaten einen KURSNET-Katalog im Format open-Qcat V1.1 bauen.
//
// WARUM ueberhaupt: ein Angebot, das nicht in KURSNET steht, ist fuer Menschen mit
// Bildungsgutschein nicht auffindbar - die Arbeitsagentur vermittelt ausschliesslich aus diesem
// Verzeichnis heraus. Traeger pflegen ihre Kurse deshalb heute doppelt, einmal im Portal und
// einmal von Hand in der Eingabemaske der Bundesagentur.
//
// WARUM NICHTS ERFUNDEN WIRD: die Zahlenschluessel der Bundesagentur (Bildungsanbieternummer,
// Eingabeverfahren, Institution, Unterrichtsform, Bildungsart, Zeitraumklasse) stehen in KEINER
// Portaltabelle und lassen sich aus Kurs, Unterricht, Standort oder Organisationseinheit auch
// nicht ableiten. Ein geratener Schluessel waere kein Schoenheitsfehler: er meldete das Angebot
// unter einer falschen Bildungsart an die Arbeitsagentur, und der Traeger merkte es erst, wenn
// sich die Falschen bewerben. Fehlt ein solcher Schluessel, bleibt das Angebot deshalb LIEGEN -
// mit einem deutschen Satz, der sagt, was zu hinterlegen ist. Der Katalog wird dadurch kleiner,
// aber nie falsch.
//
// Gebaut gegen dieselbe Schemafassung wie kursnet-open-qcat.ts (open-Qcat V1.1, Fraunhofer IAO,
// Aenderungshistorie bis 14.11.2025). Die Schemadatei liegt aus Urheberrechtsgruenden nicht im
// Repository.

type Row=Record<string,unknown>;

// Ein liegengebliebenes Angebot. Der Grund ist ein Fehlercode, den public/kp-error-text.js in
// einen deutschen Satz uebersetzt - dieselbe Uebersetzung wie fuer jeden anderen Fehler.
export interface Ausgelassen { course_id:string; course_code:string; course_name:string; grund:string }
export interface Katalog {
  xml:string;
  dateiname:string;
  angebote:number;
  ausgelassen:Ausgelassen[];
  gueltig:boolean;
  befunde:Befund[];
}

function tenantAdmin(auth:CoreAuthContext){return auth.isPlatformAdmin||auth.role==='tenant_admin';}
// Wer den Katalog erzeugen darf: die Verwaltung des Traegers. Der Export traegt den Traeger nach
// aussen - das ist keine Entscheidung einer einzelnen Klassenleitung.
function assertExport(auth:CoreAuthContext){
  if(!tenantAdmin(auth)&&!hasPermission(auth,'courses.manage'))throw new Error('FORBIDDEN_KURSNET_EXPORT');
}

// Werte aus der Datenbank werden gekuerzt, nicht abgewiesen: safeString wirft ab einer Laenge,
// und ein einziger zu langer Kursname darf nicht den ganzen Katalog des Traegers verhindern.
// Gekuerzt wird auf genau die Laenge, die die Schemadatei fuer das Zielfeld erlaubt.
function text(v:unknown,max:number):string|null{
  const s=String(v??'').trim();
  return s?s.slice(0,max):null;
}
// Number('') ist 0, nicht NaN. Ohne die erste Zeile wuerde ein LEERER Schluessel zur gueltigen
// Null - und ein Angebot, dessen Bildungsart noch niemand herausgesucht hat, ginge als
// "Bildungsart 0" an die Arbeitsagentur, statt liegen zu bleiben.
function ganzzahl(v:unknown):number|null{
  if(v===null||v===undefined||(typeof v==='string'&&!v.trim()))return null;
  const n=typeof v==='number'?v:Number(String(v).trim());
  return Number.isInteger(n)?n:null;
}

// xsd:dateTime verlangt JJJJ-MM-TThh:mm:ss. Das Portal fuehrt Kurstage als reines Datum und
// Unterrichtszeiten als ISO-Zeitpunkt mit Millisekunden und Z. Beides wird hier auf die Form
// gebracht, die die Schemadatei kennt - und ein Wert, der kein Kalendertag ist, wird verworfen
// statt umgebogen: ein stillschweigend korrigiertes Datum waere im Katalog nicht mehr zu finden.
function alsZeitpunkt(v:unknown):string|null{
  const s=String(v??'').trim();
  if(!s)return null;
  const nurTag=/^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  const roh=nurTag?`${s}T00:00:00`:s;
  const m=/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?/.exec(roh);
  if(!m)return null;
  const [,j,mo,t]=m;
  const d=new Date(Date.UTC(Number(j),Number(mo)-1,Number(t)));
  if(d.getUTCFullYear()!==Number(j)||d.getUTCMonth()!==Number(mo)-1||d.getUTCDate()!==Number(t))return null;
  return `${j}-${mo}-${t}T${m[4]}:${m[5]}:${m[6]??'00'}`;
}

// Ein Standort steht im Portal als EINE freie Zeile ("Musterweg 3, 12345 Musterstadt"), KURSNET
// will Strasse, Postleitzahl und Ort getrennt. Zerlegt wird nur, was sich eindeutig zerlegen
// laesst: eine deutsche fuenfstellige Postleitzahl mit Ort dahinter. Passt die Zeile nicht,
// wandert sie unveraendert nach ADDRESS_REMARKS, statt sie zu zerschneiden - ein falsch
// geratener Ort schickte Teilnehmende in die falsche Stadt.
export function anschriftZerlegen(freitext:string|null):{street:string|null;zip:string|null;city:string|null;remarks:string|null}{
  const roh=String(freitext??'').trim();
  if(!roh)return{street:null,zip:null,city:null,remarks:null};
  const eine=roh.replace(/\s+/g,' ').trim();
  const m=/^(.*?)[,;]?\s*(\d{5})\s+([^,;]+?)$/.exec(eine);
  if(!m||!m[1].trim())return{street:null,zip:null,city:null,remarks:eine.slice(0,4000)};
  return{street:m[1].trim().slice(0,30),zip:m[2],city:m[3].trim().slice(0,36),remarks:null};
}

const kn=(name:string,text:string|number|null|undefined):XmlKnoten|null=>
  (text===null||text===undefined||text===''?null:{name,text});
// Zahlenschluessel der Bundesagentur: Textinhalt plus Pflichtattribut type.
const schluessel=(name:string,typ:number,inhalt=''):XmlKnoten=>({name,attrs:{type:String(typ)},text:inhalt});

interface Einstellungen { institution_number:string; input_type:number; catalog_id:string; catalog_name:string|null; contact_email:string|null }
interface Anbieter { name:string; street:string|null; zip:string|null; city:string|null; country:string|null; phone:string|null; email:string|null; url:string|null }

// Mandantentrennung: jede Abfrage filtert auf tenant_id, und ausschliesslich mit unnummerierten
// Platzhaltern. Gemischte Platzhalter (? neben ?2) haben in einem anderen Modul dafuer gesorgt,
// dass die Abfrage bei jedem Aufruf abbrach.
async function einstellungenLaden(env:Env,tenantId:string):Promise<Einstellungen>{
  const row=await env.DB.prepare(
    'SELECT institution_number,input_type,catalog_id,catalog_name,contact_email FROM kursnet_export_settings WHERE tenant_id=?'
  ).bind(tenantId).first<Row>();
  if(!row)throw new Error('KURSNET_SETTINGS_MISSING');
  const nummer=text(row.institution_number,8);
  if(!nummer)throw new Error('KURSNET_INSTITUTION_NUMBER_MISSING');
  const eingabe=ganzzahl(row.input_type);
  if(eingabe===null)throw new Error('KURSNET_INPUT_TYPE_MISSING');
  const katalog=text(row.catalog_id,50);
  if(!katalog)throw new Error('KURSNET_CATALOG_ID_MISSING');
  return{institution_number:nummer,input_type:eingabe,catalog_id:katalog,
    catalog_name:text(row.catalog_name,255),contact_email:text(row.contact_email,255)};
}

async function anbieterLaden(env:Env,tenantId:string):Promise<Anbieter>{
  const mandant=await env.DB.prepare('SELECT id,name FROM tenants WHERE id=?').bind(tenantId).first<Row>();
  if(!mandant)throw new Error('TENANT_NOT_FOUND');
  const profil=await env.DB.prepare(
    'SELECT legal_name,contact_email,phone,website,street,postal_code,city,country FROM tenant_profiles WHERE tenant_id=?'
  ).bind(tenantId).first<Row>();
  const anbieter:Anbieter={
    name:text(profil?.legal_name,255)||text(mandant.name,255)||'',
    street:text(profil?.street,30),zip:text(profil?.postal_code,14),city:text(profil?.city,36),
    country:text(profil?.country,50),phone:text(profil?.phone,30),
    email:text(profil?.contact_email,255),url:text(profil?.website,255),
  };
  if(!anbieter.name)throw new Error('KURSNET_SUPPLIER_NAME_MISSING');
  // Ohne Anschrift ist der Anbieter in KURSNET nicht zuzuordnen. Das ist kein Feld, das dieser
  // Export erfinden darf - der ganze Katalog bleibt liegen, bis der Traeger sie gepflegt hat.
  if(!anbieter.street||!anbieter.zip||!anbieter.city)throw new Error('KURSNET_SUPPLIER_ADDRESS_MISSING');
  return anbieter;
}

// COUNTRY_CODED verlangt einen ISO-3166-Code, das Portal fuehrt einen Landesnamen im Klartext.
// Uebersetzt wird nur, was eindeutig ist; alles andere bleibt als Klartext in COUNTRY stehen.
// Nachgeschlagen wird ohne Umlaute: der Kunde schreibt mal "Oesterreich" und mal "\u00d6sterreich",
// und beides meint dasselbe Land. Die Zerlegung in NFD trennt den Umlautpunkt vom Buchstaben ab,
// danach faellt er als kombinierendes Zeichen weg - so bleibt diese Datei ausserdem reines ASCII.
const LAENDER:Record<string,string>={deutschland:'DE',germany:'DE',de:'DE',
  oesterreich:'AT',osterreich:'AT',austria:'AT',at:'AT',schweiz:'CH',switzerland:'CH',ch:'CH'};
function landCode(name:string|null):string|null{
  if(!name)return null;
  const gesucht=name.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  return LAENDER[gesucht]??null;
}

function anschriftKnoten(name:string,a:{name?:string|null;name2?:string|null;street:string|null;zip:string|null;city:string|null;country?:string|null;phone?:string|null;email?:string|null;url?:string|null;remarks?:string|null}):XmlKnoten{
  // Die Reihenfolge ist die Folge aus typeADDRESS. Jedes Feld ist dort einzeln optional, also
  // entscheidet allein sie darueber, ob die Datei angenommen wird.
  return{name,kinder:[
    kn('NAME',a.name?.slice(0,30)),kn('NAME2',a.name2?.slice(0,30)),
    kn('STREET',a.street),kn('ZIP',a.zip),kn('CITY',a.city),
    kn('COUNTRY_CODED',landCode(a.country??null)),kn('COUNTRY',a.country??null),
    kn('PHONE',a.phone??null),
    a.email?{name:'EMAILS',kinder:[kn('EMAIL',a.email)]}:null,
    kn('URL',a.url??null),kn('ADDRESS_REMARKS',a.remarks??null),
  ]};
}

interface Kurs {
  id:string;name:string;code:string;start_date:string|null;end_date:string|null;
  location_name:string|null;location_address:string|null;org_unit_name:string|null;
  course_type:unknown;institution_key:unknown;instruction_form_key:unknown;education_type_key:unknown;
  duration_type:unknown;teaching_language:string|null;
  measure_number:string|null;description:string|null;requirements:string|null;target_group:string|null;
  lesson_start:string|null;lesson_end:string|null;
}

// Nur Kurse, fuer die ueberhaupt ein KURSNET-Angebot hinterlegt ist. Ein JOIN statt eines LEFT
// JOIN: wer den Kurs nicht gemeldet haben will, hat keine Zeile - das ist die Entscheidung des
// Traegers und keine Luecke, ueber die berichtet werden muesste.
async function kurseLaden(env:Env,tenantId:string,courseIds:string[]):Promise<Kurs[]>{
  const marks=courseIds.map(()=>'?').join(',');
  const sql=
    `SELECT c.id,c.name,c.code,c.start_date,c.end_date,
            l.name location_name,l.address location_address,
            (SELECT o.name FROM course_org_units cou JOIN org_units o ON o.id=cou.org_unit_id AND o.tenant_id=cou.tenant_id
              WHERE cou.tenant_id=c.tenant_id AND cou.course_id=c.id AND cou.is_primary=1) org_unit_name,
            -- Der Zeitraum aus dem echten Unterricht wird MIT geladen, nicht je Kurs nachgefragt.
            -- Eine Abfrage pro Angebot waere bei einem Traeger mit vielen Kursen der schnellste
            -- Weg in die Obergrenze fuer Unteranfragen - und der Export braeche mittendrin ab.
            (SELECT MIN(le.starts_at) FROM lessons le WHERE le.tenant_id=c.tenant_id AND le.course_id=c.id) lesson_start,
            (SELECT MAX(le.ends_at) FROM lessons le WHERE le.tenant_id=c.tenant_id AND le.course_id=c.id) lesson_end,
            k.course_type,k.institution_key,k.instruction_form_key,k.education_type_key,k.duration_type,
            k.teaching_language,k.measure_number,k.description,k.requirements,k.target_group
       FROM kursnet_course_offers k
       JOIN courses c ON c.id=k.course_id AND c.tenant_id=k.tenant_id
       LEFT JOIN locations l ON l.id=c.location_id AND l.tenant_id=c.tenant_id
      WHERE k.tenant_id=? AND k.is_active=1`;
  const ende=' ORDER BY c.code';
  const rows=courseIds.length
    ?((await env.DB.prepare(`${sql} AND c.id IN (${marks})${ende}`).bind(tenantId,...courseIds).all<Row>()).results)??[]
    :((await env.DB.prepare(`${sql}${ende}`).bind(tenantId).all<Row>()).results)??[];
  return rows as unknown as Kurs[];
}

function angebotKnoten(kurs:Kurs,start:string,ende:string|null,dauerTyp:number,schluesselWerte:{institution:number;form:number;bildungsart:number},courseType:number):XmlKnoten{
  const ort=anschriftZerlegen(kurs.location_address);
  // MODULE_COURSE in der Folge der Schemadatei: LOCATION vor DURATION, EXTENDED_INFO zuletzt.
  const modul:XmlKnoten={name:'MODULE_COURSE',kinder:[
    (kurs.location_name||ort.street||ort.remarks)
      ?anschriftKnoten('LOCATION',{name:kurs.location_name,name2:kurs.org_unit_name,street:ort.street,zip:ort.zip,city:ort.city,remarks:ort.remarks})
      :null,
    {name:'DURATION',attrs:{type:String(dauerTyp)},kinder:[kn('START_DATE',start),kn('END_DATE',ende)]},
  ]};
  // Die Unterrichtssprache wird NUR geschrieben, wenn sie am Angebot hinterlegt ist. Ein
  // pauschales "deu" waere geraten: dass ein Portal auf Deutsch bedient wird, sagt nichts
  // darueber, in welcher Sprache unterrichtet wird - gerade Integrations- und Sprachkurse
  // werden ganz oder teilweise in einer anderen gehalten. Beide Elemente sind im Schema
  // optional, das Weglassen also zulaessig; eine falsche Angabe waere es nicht.
  const sprache=kurs.teaching_language?text(kurs.teaching_language,3):null;
  const bildung:XmlKnoten={name:'EDUCATION',kinder:[
    kn('COURSE_ID',kurs.code.slice(0,255)),
    sprache?{name:'LANGUAGE',text:sprache}:null,
    {name:'EXTENDED_INFO',kinder:[
      schluessel('INSTITUTION',schluesselWerte.institution),
      schluessel('INSTRUCTION_FORM',schluesselWerte.form),
      // TEACHING_LANGUAGES steht laut Schemafolge VOR EDUCATION_TYPE (Aenderung vom 14.11.2025).
      sprache?{name:'TEACHING_LANGUAGES',text:sprache}:null,
      schluessel('EDUCATION_TYPE',schluesselWerte.bildungsart),
      kn('MEASURE_NUMBER',kurs.measure_number?.slice(0,30)),
    ]},
    modul,
  ]};
  return{name:'SERVICE',attrs:{mode:'new'},kinder:[
    {name:'PRODUCT_ID',text:kurs.code.slice(0,255)},
    {name:'COURSE_TYPE',text:String(courseType)},
    {name:'SERVICE_DETAILS',kinder:[
      {name:'TITLE',text:kurs.name.slice(0,255)},
      kn('DESCRIPTION_LONG',kurs.description?.slice(0,30000)),
      kn('REQUIREMENTS',kurs.requirements?.slice(0,10000)),
      kurs.target_group?{name:'TARGET_GROUP',kinder:[kn('TARGET_GROUP_TEXT',kurs.target_group.slice(0,4000))]}:null,
      {name:'SERVICE_MODULE',kinder:[bildung]},
    ]},
  ]};
}

/**
 * Baut den Katalog eines Mandanten. Angebote, denen ein Pflichtwert fehlt, bleiben mit Grund
 * liegen; die Datei selbst wird zum Schluss durch openQcatPruefen geschickt, damit der Traeger
 * VOR dem Hochladen weiss, ob KURSNET sie annimmt.
 */
export async function kursnetKatalogBauen(env:Env,auth:CoreAuthContext,tenantId:string,courseIds:string[]=[]):Promise<Katalog>{
  assertExport(auth);
  const einstellungen=await einstellungenLaden(env,tenantId);
  const anbieter=await anbieterLaden(env,tenantId);
  const kurse=await kurseLaden(env,tenantId,courseIds);

  const ausgelassen:Ausgelassen[]=[];
  const angebote:XmlKnoten[]=[];
  for(const kurs of kurse){
    const notiz=(grund:string)=>ausgelassen.push({course_id:kurs.id,course_code:kurs.code,course_name:kurs.name,grund});
    const courseType=ganzzahl(kurs.course_type);
    const institution=ganzzahl(kurs.institution_key);
    const form=ganzzahl(kurs.instruction_form_key);
    const bildungsart=ganzzahl(kurs.education_type_key);
    if(courseType===null||courseType<1||courseType>5){notiz('KURSNET_COURSE_TYPE_MISSING');continue;}
    if(institution===null||form===null||bildungsart===null){notiz('KURSNET_EDUCATION_KEYS_MISSING');continue;}
    if(!text(kurs.name,255)){notiz('KURSNET_TITLE_MISSING');continue;}

    // Steht am Kurs selbst kein Zeitraum, ist der geplante Unterricht die ehrlichere Quelle: er
    // ist das, was wirklich stattfindet. Erfunden wird nichts - gibt es beides nicht, bleibt das
    // Angebot liegen.
    let start=alsZeitpunkt(kurs.start_date);
    let ende=alsZeitpunkt(kurs.end_date);
    if(!start){start=alsZeitpunkt(kurs.lesson_start);ende=ende??alsZeitpunkt(kurs.lesson_end);}
    // Ohne Beginn ist das Angebot in KURSNET nicht buchbar - und ein erfundener Beginn waere ein
    // Termin, zu dem Teilnehmende erschienen.
    if(!start){notiz('KURSNET_COURSE_PERIOD_MISSING');continue;}
    const dauerTyp=ganzzahl(kurs.duration_type);
    // DURATION traegt die Zeitraumklasse als PFLICHTattribut. Ohne sie liesse sich der Termin
    // ueberhaupt nicht schreiben, und ein Angebot ohne Termin ist kein Angebot.
    if(dauerTyp===null){notiz('KURSNET_DURATION_TYPE_MISSING');continue;}
    angebote.push(angebotKnoten(kurs,start,ende,dauerTyp,{institution,form,bildungsart},courseType));
  }

  const erzeugt=nowIso().replace(/\.\d+Z$/,'');
  const wurzel:XmlKnoten={name:'OPENQCAT',attrs:{version:'1.1'},kinder:[
    {name:'HEADER',kinder:[
      {name:'GENERATOR_INFO',text:'Klassenportal open-Qcat Export'},
      {name:'CATALOG',kinder:[
        // Der Katalog wird in deutscher Sprache geschrieben - eine Tatsache ueber diese Ausgabe.
        {name:'LANGUAGE',text:'deu'},
        {name:'CATALOG_ID',text:einstellungen.catalog_id},
        // Die Katalogfassung ist der Erzeugungszeitpunkt: der Empfaenger kann zwei Lieferungen
        // damit sicher unterscheiden, ohne dass jemand einen Zaehler pflegen muss.
        {name:'CATALOG_VERSION',text:erzeugt},
        kn('CATALOG_NAME',einstellungen.catalog_name??anbieter.name.slice(0,255)),
        {name:'GENERATION_DATE',text:erzeugt},
      ]},
      {name:'SUPPLIER',kinder:[
        {name:'SUPPLIER_ID',attrs:{type:'institution_number'},text:einstellungen.institution_number},
        {name:'SUPPLIER_NAME',text:anbieter.name.slice(0,255)},
        anschriftKnoten('ADDRESS',{name:anbieter.name,street:anbieter.street,zip:anbieter.zip,city:anbieter.city,
          country:anbieter.country,phone:anbieter.phone,email:einstellungen.contact_email??anbieter.email,url:anbieter.url}),
        {name:'EXTENDED_INFO',attrs:{input_type:String(einstellungen.input_type)},kinder:[
          kn('INSTITUTION_NUMBER',einstellungen.institution_number.slice(0,8)),
        ]},
      ]},
    ]},
    {name:'NEW_CATALOG',attrs:{FULLCATALOG:courseIds.length?'false':'true'},kinder:angebote},
  ]};

  const xml=xmlDokument(wurzel);
  // Die eigene Ausgabe wird gegen dieselben Regeln geprueft, die KURSNET anwendet. Ohne diesen
  // Schritt erfuehre der Traeger von einem Formfehler erst beim Hochladen - und bis dahin ist
  // sein Angebot fuer Menschen mit Bildungsgutschein nicht auffindbar.
  const {gueltig,befunde}=openQcatPruefen(xml);
  return{xml,dateiname:`kursnet-${einstellungen.catalog_id.replace(/[^A-Za-z0-9._-]/g,'-')}-${erzeugt.slice(0,10)}.xml`,
    angebote:angebote.length,ausgelassen,gueltig,befunde};
}

/** Die hinterlegten Anbieterschluessel eines Mandanten. */
export async function kursnetEinstellungenLesen(env:Env,auth:CoreAuthContext,tenantId:string){
  assertExport(auth);
  const row=await env.DB.prepare(
    'SELECT institution_number,input_type,catalog_id,catalog_name,contact_email,updated_at FROM kursnet_export_settings WHERE tenant_id=?'
  ).bind(tenantId).first<Row>();
  return{settings:row??null};
}

/** Die Anbieterschluessel hinterlegen. Ohne sie kann kein Katalog entstehen. */
export async function kursnetEinstellungenSchreiben(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  assertExport(auth);
  if(!tenantAdmin(auth))throw new Error('FORBIDDEN_KURSNET_SETTINGS');
  const nummer=text(input.institution_number,8);
  if(!nummer)throw new Error('KURSNET_INSTITUTION_NUMBER_MISSING');
  const eingabe=ganzzahl(input.input_type);
  if(eingabe===null||eingabe<0)throw new Error('KURSNET_INPUT_TYPE_MISSING');
  const katalog=text(input.catalog_id,50);
  if(!katalog)throw new Error('KURSNET_CATALOG_ID_MISSING');
  const ts=nowIso();
  await env.DB.prepare(
    `INSERT INTO kursnet_export_settings(tenant_id,institution_number,input_type,catalog_id,catalog_name,contact_email,updated_at)
     VALUES(?,?,?,?,?,?,?)
     ON CONFLICT(tenant_id) DO UPDATE SET institution_number=excluded.institution_number,input_type=excluded.input_type,
       catalog_id=excluded.catalog_id,catalog_name=excluded.catalog_name,contact_email=excluded.contact_email,updated_at=excluded.updated_at`
  ).bind(tenantId,nummer,eingabe,katalog,text(input.catalog_name,255),text(input.contact_email,255),ts).run();
  await audit(env.DB,auth.userId,'kursnet.settings.saved',tenantId,undefined,'kursnet_export_settings',tenantId);
  return{saved:true};
}

/** Die gemeldeten Angebote eines Mandanten - je Kurs die Schluessel, die KURSNET verlangt. */
export async function kursnetAngeboteLesen(env:Env,auth:CoreAuthContext,tenantId:string){
  assertExport(auth);
  const rows=((await env.DB.prepare(
    `SELECT k.id,k.course_id,k.course_type,k.institution_key,k.instruction_form_key,k.education_type_key,
            k.duration_type,k.teaching_language,k.measure_number,k.is_active,k.updated_at,c.code course_code,c.name course_name
       FROM kursnet_course_offers k JOIN courses c ON c.id=k.course_id AND c.tenant_id=k.tenant_id
      WHERE k.tenant_id=? ORDER BY c.code`
  ).bind(tenantId).all<Row>()).results)??[];
  return{offers:rows};
}

/** Einen Kurs fuer KURSNET melden oder die Schluessel aendern. */
export async function kursnetAngebotSchreiben(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  assertExport(auth);
  const courseId=safeString(input.course_id,120);
  if(!courseId)throw new Error('KURSNET_COURSE_REQUIRED');
  // Erst gegen den Mandanten pruefen, dann weiterarbeiten: eine Kurskennung aus einem fremden
  // Mandanten darf nicht einmal bis zum Schreiben kommen.
  const kurs=await env.DB.prepare('SELECT id FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,courseId).first<Row>();
  if(!kurs)throw new Error('COURSE_NOT_FOUND');
  // Ein Schluessel darf fehlen - der Traeger sucht die Nummern der Arbeitsagentur oft erst
  // nachtraeglich heraus. Was aber DA ist, muss eine nicht negative ganze Zahl sein: eine "3a"
  // waere im Katalog eine falsche Eingruppierung, die hinterher niemand mehr bemerkt.
  // leer() unterscheidet dabei "nicht angegeben" von "falsch angegeben" - ganzzahl() allein
  // koennte das nicht, weil beides null ergibt.
  const leer=(wert:unknown)=>wert===undefined||wert===null||wert==='';
  const geprueft=(wert:unknown)=>{const n=ganzzahl(wert);return n!==null&&n>=0?n:null;};
  const courseType=leer(input.course_type)?null:geprueft(input.course_type);
  if(!leer(input.course_type)&&(courseType===null||courseType<1||courseType>5))throw new Error('KURSNET_COURSE_TYPE_INVALID');
  const institution=leer(input.institution_key)?null:geprueft(input.institution_key);
  const form=leer(input.instruction_form_key)?null:geprueft(input.instruction_form_key);
  const art=leer(input.education_type_key)?null:geprueft(input.education_type_key);
  if((!leer(input.institution_key)&&institution===null)||(!leer(input.instruction_form_key)&&form===null)
    ||(!leer(input.education_type_key)&&art===null))throw new Error('KURSNET_EDUCATION_KEYS_INVALID');
  const dauer=leer(input.duration_type)?null:geprueft(input.duration_type);
  if(!leer(input.duration_type)&&dauer===null)throw new Error('KURSNET_DURATION_TYPE_INVALID');
  // Die Unterrichtssprache muss ein Code aus der Werteliste der Schemadatei sein. Hier
  // abzuweisen ist der billigste Zeitpunkt: ein falscher Code macht sonst spaeter den GANZEN
  // Katalog ungueltig, also auch jedes andere Angebot des Traegers.
  const sprache=leer(input.teaching_language)?null:text(input.teaching_language,3);
  if(sprache!==null&&!(SPRACHEN as readonly string[]).includes(sprache))throw new Error('KURSNET_LANGUAGE_INVALID');
  const ts=nowIso();
  await env.DB.prepare(
    `INSERT INTO kursnet_course_offers(id,tenant_id,course_id,course_type,institution_key,instruction_form_key,education_type_key,
        duration_type,teaching_language,measure_number,description,requirements,target_group,is_active,created_at,updated_at)
     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)
     ON CONFLICT(tenant_id,course_id) DO UPDATE SET course_type=excluded.course_type,institution_key=excluded.institution_key,
       instruction_form_key=excluded.instruction_form_key,education_type_key=excluded.education_type_key,
       duration_type=excluded.duration_type,teaching_language=excluded.teaching_language,
       measure_number=excluded.measure_number,description=excluded.description,
       requirements=excluded.requirements,target_group=excluded.target_group,is_active=1,updated_at=excluded.updated_at`
  ).bind(id('kno_'),tenantId,courseId,courseType,institution,form,art,dauer,sprache,
    text(input.measure_number,30),text(input.description,30000),text(input.requirements,10000),text(input.target_group,4000),ts,ts).run();
  await audit(env.DB,auth.userId,'kursnet.offer.saved',tenantId,courseId,'kursnet_course_offers',courseId);
  return{saved:true};
}

/** Ein Angebot wieder aus der Meldung nehmen. */
export async function kursnetAngebotEntfernen(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  assertExport(auth);
  const treffer=await env.DB.prepare('SELECT id FROM kursnet_course_offers WHERE tenant_id=? AND course_id=?')
    .bind(tenantId,courseId).first<Row>();
  if(!treffer)throw new Error('KURSNET_OFFER_NOT_FOUND');
  await env.DB.prepare('DELETE FROM kursnet_course_offers WHERE tenant_id=? AND course_id=?').bind(tenantId,courseId).run();
  await audit(env.DB,auth.userId,'kursnet.offer.removed',tenantId,courseId,'kursnet_course_offers',courseId);
  return{removed:true};
}

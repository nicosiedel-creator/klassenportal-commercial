import type { Env } from './types.js';
import { resolveCoreAuth } from './auth.js';
import { assertTenantWriteAllowed } from './commerce-offers.js';
import { fundingMonthlyReport, listFundingCases, saveFundingCase } from './funding-cases.js';
import { assertSameOrigin, authStatus, json, safeErrorCode } from './utils.js';

// /api/funding - Foerderfaelle und die monatliche Grundlage einer Kostentraegermeldung.
async function body(request:Request):Promise<Record<string,unknown>>{try{return await request.json() as Record<string,unknown>;}catch{return{};}}

// Fehlende Pflichtangaben und unmoegliche Datumsfolgen sind Eingaben, die der Mensch am Bildschirm
// selbst korrigieren kann - kein Serverfehler.
function fail(e:unknown){
  const code=safeErrorCode(e);
  const status=authStatus(code)??(code==='UNAUTHENTICATED'?401
    :code.startsWith('FORBIDDEN')||code.includes('ADMIN_REQUIRED')?403
    :code.includes('NOT_FOUND')?404
    :code==='FUNDING_PARTICIPANT_NOT_IN_COURSE'?409:400);
  return json({ok:false,error:code},status);
}

export async function handleFundingCasesApi(request:Request,env:Env):Promise<Response|null>{
  const u=new URL(request.url),path=u.pathname;
  if(!path.startsWith('/api/funding'))return null;
  try{
    assertSameOrigin(request,env.APP_ORIGIN);
    const tenantId=u.searchParams.get('tenant_id')||'';
    if(!tenantId)throw new Error('TENANT_ID_REQUIRED');
    const courseId=u.searchParams.get('course_id')||undefined;
    const auth=await resolveCoreAuth(env,request,tenantId,courseId);
    if(request.method!=='GET'&&request.method!=='HEAD')await assertTenantWriteAllowed(env,tenantId);

    if(path==='/api/funding/cases'&&request.method==='GET'){
      if(!courseId)throw new Error('COURSE_ID_REQUIRED');
      return json({ok:true,cases:await listFundingCases(env,auth,tenantId,courseId)});
    }
    if(path==='/api/funding/cases'&&request.method==='POST'){
      if(!courseId)throw new Error('COURSE_ID_REQUIRED');
      return json({ok:true,...await saveFundingCase(env,auth,tenantId,courseId,await body(request))},201);
    }
    if(path==='/api/funding/report'&&request.method==='GET')
      return json({ok:true,report:await fundingMonthlyReport(env,auth,tenantId,u.searchParams.get('month')||'',{course_id:courseId,cost_bearer:u.searchParams.get('cost_bearer')||undefined})});
    return new Response('Methode nicht erlaubt',{status:405});
  }catch(e){return fail(e);}
}

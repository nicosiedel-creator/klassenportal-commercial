import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';
import { sha256Text } from '../portability/backup-integrity.js';

// Beschwerdemanagement mit Frist und Eskalation.
//
// Zwei Dinge entscheiden, ob ein Beschwerdeverfahren benutzt wird:
//
//  1. Anonym muss gehen. Eine Beschwerde ueber die eigene Lehrkraft reicht sonst niemand ein - und
//     der Traeger erfaehrt von dem Problem erst, wenn es die Aufsicht erfaehrt. Die anonyme Person
//     bekommt einen Vorgangsschluessel; gespeichert wird nur sein Hash, damit er sich aus der
//     Datenbank nicht zurueckrechnen laesst.
//  2. Eine Frist, die von selbst laeuft. "Wir kuemmern uns" ohne Datum ist keine Zusage. Nach
//     Ablauf eskaliert der Vorgang sichtbar - er verschwindet nicht.

export const KATEGORIEN=['unterricht','organisation','verhalten','abrechnung','barrierefreiheit','datenschutz','sonstiges'] as const;
// Werktage sind nicht abbildbar ohne Feiertagskalender; 14 Kalendertage ist die ehrliche Vorgabe.
export const FRIST_TAGE=14;
const clean=(v:unknown,n=5000)=>safeString(v,n);

function schluessel():string{
  const zeichen='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',roh=new Uint8Array(12);
  crypto.getRandomValues(roh);
  return Array.from(roh,b=>zeichen[b%zeichen.length]).join('').replace(/(.{4})(?=.)/g,'$1-');
}

/**
 * Beschwerde einreichen - mit oder ohne Namen.
 *
 * Anonym heisst wirklich anonym: es wird keine Kennung gespeichert. Der Vorgangsschluessel geht
 * EINMAL an die einreichende Person zurueck; wer ihn verliert, hat keinen Zugang mehr zum Vorgang.
 * Das ist der Preis der Anonymitaet und wird auch so gesagt.
 */
export async function reicheBeschwerdeEin(env:Env,auth:CoreAuthContext|null,tenantId:string,input:Record<string,unknown>){
  const kategorie=clean(input.kategorie,40),betreff=clean(input.betreff,200),text=clean(input.text,5000);
  if(!KATEGORIEN.includes(kategorie as never))throw new Error('BESCHWERDE_KATEGORIE_UNGUELTIG');
  if(betreff.length<3||text.length<20)throw new Error('BESCHWERDE_TEXT_ERFORDERLICH');
  const anonym=input.anonym===true||!auth;
  const jetzt=new Date(),ts=jetzt.toISOString(),vorgangId=id('bsw_');
  const frist=new Date(jetzt.getTime()+FRIST_TAGE*864e5).toISOString();
  const klartext=anonym?schluessel():null;
  const hash=klartext?await sha256Text(`${tenantId}:${klartext}`):null;
  await env.DB.prepare('INSERT INTO complaints(id,tenant_id,eingereicht_von,vorgangsschluessel_hash,kategorie,betreff,text,status,frist_am,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
    .bind(vorgangId,tenantId,anonym?null:auth!.userId,hash,kategorie,betreff,text,'eingegangen',frist,ts,ts).run();
  // Im Protokoll steht der Vorgang, nicht sein Inhalt - und bei einer anonymen Beschwerde auch
  // keine handelnde Person, sonst waere die Anonymitaet ueber das Protokoll aufgehoben.
  await audit(env.DB,anonym?undefined:auth!.userId,'complaint.filed',tenantId,undefined,'complaint',vorgangId,{kategorie,anonym});
  return{id:vorgangId,frist_am:frist,vorgangsschluessel:klartext,
    hinweis:klartext?'Bitte den Vorgangsschlüssel notieren. Er ist der einzige Weg zurück zu diesem Vorgang – wir können ihn nicht wiederherstellen.':null};
}

/** Der eigene Vorgang: ueber das Konto oder ueber den Vorgangsschluessel. */
export async function meineBeschwerden(env:Env,auth:CoreAuthContext,tenantId:string){
  return ((await env.DB.prepare('SELECT id,kategorie,betreff,status,frist_am,antwort,beantwortet_am,created_at FROM complaints WHERE tenant_id=? AND eingereicht_von=? ORDER BY created_at DESC LIMIT 100')
    .bind(tenantId,auth.userId).all()).results)??[];
}

export async function beschwerdeNachSchluessel(env:Env,tenantId:string,vorgangsschluessel:unknown){
  const text=clean(vorgangsschluessel,80);
  if(!text)throw new Error('BESCHWERDE_SCHLUESSEL_ERFORDERLICH');
  const hash=await sha256Text(`${tenantId}:${text}`);
  const vorgang=await env.DB.prepare('SELECT id,kategorie,betreff,status,frist_am,antwort,beantwortet_am,created_at FROM complaints WHERE tenant_id=? AND vorgangsschluessel_hash=?')
    .bind(tenantId,hash).first<Record<string,unknown>>();
  if(!vorgang)throw new Error('BESCHWERDE_NICHT_GEFUNDEN');
  const verlauf=((await env.DB.prepare('SELECT art,text,erfasst_am FROM complaint_notes WHERE complaint_id=? AND fuer_einreicher=1 ORDER BY erfasst_am').bind(vorgang.id).all()).results)??[];
  return{vorgang,verlauf};
}

export async function listeBeschwerden(env:Env,auth:CoreAuthContext,tenantId:string,nurOffen=true){
  requireRole(auth,'tenant_admin');
  const sql=nurOffen
    ? "SELECT id,eingereicht_von,kategorie,betreff,status,frist_am,zugewiesen_an,created_at FROM complaints WHERE tenant_id=? AND status<>'abgeschlossen' ORDER BY frist_am"
    : 'SELECT id,eingereicht_von,kategorie,betreff,status,frist_am,zugewiesen_an,created_at FROM complaints WHERE tenant_id=? ORDER BY created_at DESC LIMIT 200';
  return ((await env.DB.prepare(sql).bind(tenantId).all()).results)??[];
}

export async function beschwerdeLesen(env:Env,auth:CoreAuthContext,tenantId:string,complaintId:string){
  requireRole(auth,'tenant_admin');
  const vorgang=await env.DB.prepare('SELECT * FROM complaints WHERE id=? AND tenant_id=?').bind(complaintId,tenantId).first<Record<string,unknown>>();
  if(!vorgang)throw new Error('BESCHWERDE_NICHT_GEFUNDEN');
  const verlauf=((await env.DB.prepare('SELECT id,verfasst_von,art,text,fuer_einreicher,erfasst_am FROM complaint_notes WHERE complaint_id=? ORDER BY erfasst_am').bind(complaintId).all()).results)??[];
  // Der Hash des Vorgangsschluessels geht nie hinaus - er waere ein Weg, den Zugang zu uebernehmen.
  delete (vorgang as Record<string,unknown>).vorgangsschluessel_hash;
  return{vorgang,verlauf};
}

export async function bearbeiteBeschwerde(env:Env,auth:CoreAuthContext,tenantId:string,complaintId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const vorgang=await env.DB.prepare('SELECT status,eingereicht_von FROM complaints WHERE id=? AND tenant_id=?').bind(complaintId,tenantId).first<{status:string;eingereicht_von:string|null}>();
  if(!vorgang)throw new Error('BESCHWERDE_NICHT_GEFUNDEN');
  if(vorgang.status==='abgeschlossen')throw new Error('BESCHWERDE_ABGESCHLOSSEN');
  const status=clean(input.status,30),text=clean(input.text,5000);
  if(!['in_bearbeitung','eskaliert','beantwortet','abgeschlossen'].includes(status))throw new Error('BESCHWERDE_STATUS_UNGUELTIG');
  const ts=nowIso(),anweisungen=[];
  if(status==='beantwortet'){
    // Eine Beschwerde gilt erst als beantwortet, wenn es eine Antwort gibt, die die einreichende
    // Person auch lesen kann. Sonst waere "beantwortet" nur ein Haken in der Statistik.
    if(text.length<10)throw new Error('BESCHWERDE_ANTWORT_ERFORDERLICH');
    anweisungen.push(env.DB.prepare("UPDATE complaints SET status='beantwortet',antwort=?,beantwortet_am=?,updated_at=? WHERE id=? AND tenant_id=?").bind(text,ts,ts,complaintId,tenantId));
    anweisungen.push(env.DB.prepare("INSERT INTO complaint_notes(id,tenant_id,complaint_id,verfasst_von,art,text,fuer_einreicher,erfasst_am) VALUES(?,?,?,?,'antwort',?,1,?)").bind(id('bsn_'),tenantId,complaintId,auth.userId,text,ts));
    if(vorgang.eingereicht_von)anweisungen.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'complaint_answered',?,?,?)")
      .bind(id('ntf_'),tenantId,vorgang.eingereicht_von,'Antwort auf Ihre Beschwerde','Zu Ihrer Beschwerde liegt eine Antwort vor.',ts));
  }else if(status==='eskaliert'){
    const stelle=clean(input.eskaliert_an,200);
    if(!stelle)throw new Error('BESCHWERDE_ESKALATIONSZIEL_ERFORDERLICH');
    anweisungen.push(env.DB.prepare("UPDATE complaints SET status='eskaliert',eskaliert_an=?,eskaliert_am=?,updated_at=? WHERE id=? AND tenant_id=?").bind(stelle,ts,ts,complaintId,tenantId));
    anweisungen.push(env.DB.prepare("INSERT INTO complaint_notes(id,tenant_id,complaint_id,verfasst_von,art,text,fuer_einreicher,erfasst_am) VALUES(?,?,?,?,'eskalation',?,1,?)").bind(id('bsn_'),tenantId,complaintId,auth.userId,`An ${stelle} weitergegeben.`,ts));
  }else if(status==='abgeschlossen'){
    if(text.length<10)throw new Error('BESCHWERDE_ABSCHLUSSGRUND_ERFORDERLICH');
    anweisungen.push(env.DB.prepare("UPDATE complaints SET status='abgeschlossen',abgeschlossen_am=?,updated_at=? WHERE id=? AND tenant_id=?").bind(ts,ts,complaintId,tenantId));
    anweisungen.push(env.DB.prepare("INSERT INTO complaint_notes(id,tenant_id,complaint_id,verfasst_von,art,text,fuer_einreicher,erfasst_am) VALUES(?,?,?,?,'statuswechsel',?,?,?)").bind(id('bsn_'),tenantId,complaintId,auth.userId,text,input.fuer_einreicher===false?0:1,ts));
  }else{
    anweisungen.push(env.DB.prepare("UPDATE complaints SET status='in_bearbeitung',zugewiesen_an=COALESCE(zugewiesen_an,?),updated_at=? WHERE id=? AND tenant_id=?").bind(auth.userId,ts,complaintId,tenantId));
    anweisungen.push(env.DB.prepare("INSERT INTO complaint_notes(id,tenant_id,complaint_id,verfasst_von,art,text,fuer_einreicher,erfasst_am) VALUES(?,?,?,?,'statuswechsel',?,?,?)").bind(id('bsn_'),tenantId,complaintId,auth.userId,text||'In Bearbeitung genommen.',input.fuer_einreicher===true?1:0,ts));
  }
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,`complaint.${status}`,tenantId,undefined,'complaint',complaintId);
  return{status};
}

/**
 * Ueberfaellige Vorgaenge.
 *
 * Sie werden nicht still eskaliert: die Leitung wird benachrichtigt, der Vorgang bleibt offen und
 * traegt seine Ueberschreitung sichtbar. Eine Frist, die im Hintergrund "erledigt" wird, ist keine.
 */
export async function ueberfaelligeBeschwerden(env:Env,grenze=20,jetzt=nowIso()){
  return ((await env.DB.prepare("SELECT id,tenant_id,betreff,frist_am,status FROM complaints WHERE status IN ('eingegangen','in_bearbeitung') AND frist_am<=? ORDER BY frist_am LIMIT ?")
    .bind(jetzt,Math.max(1,Math.min(100,grenze))).all<{id:string;tenant_id:string;betreff:string;frist_am:string;status:string}>()).results)??[];
}

export async function mahneBeschwerdenAn(env:Env,grenze=20,jetzt=nowIso()):Promise<{gemahnt:number;vorgaenge:number}>{
  const offen=await ueberfaelligeBeschwerden(env,grenze,jetzt);
  if(!offen.length)return{gemahnt:0,vorgaenge:0};
  const jeMandant=new Map<string,number>();
  for(const v of offen)jeMandant.set(v.tenant_id,(jeMandant.get(v.tenant_id)??0)+1);
  const anweisungen=[];let gemahnt=0;
  for(const [tenantId,anzahl] of jeMandant){
    const leitung=((await env.DB.prepare("SELECT DISTINCT user_id FROM memberships WHERE tenant_id=? AND role='tenant_admin' LIMIT 20").bind(tenantId).all<{user_id:string}>()).results)??[];
    for(const l of leitung){
      anweisungen.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'complaint_overdue',?,?,?)")
        .bind(id('ntf_'),tenantId,l.user_id,'Beschwerde: Frist überschritten',`${anzahl} Beschwerde(n) sind über die zugesagte Frist von ${FRIST_TAGE} Tagen hinaus unbeantwortet.`,jetzt));
      gemahnt++;
    }
  }
  if(anweisungen.length)await env.DB.batch(anweisungen);
  return{gemahnt,vorgaenge:offen.length};
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Fehlerwarteschlange (W2), Eskalation (W3) und der Vorgangsbegriff (W4).
//
// Der Ausgangszustand stand woertlich im Regelmotor: `catch(e){console.error(...)}`. Ein Fehler in
// einer Automatik verschwand in einem Log, das niemand liest. Eine Regel, die seit drei Wochen bei
// jedem Lauf scheitert, sah von aussen aus wie eine, die nichts zu tun hat - und das ist der
// Unterschied zwischen "die Automatik laeuft" und "die Automatik arbeitet".
//
// Drei Gedanken tragen diese Datei:
//  1. Ein Fehler wird EINMAL gefuehrt, nicht hundertfach. Derselbe Fehler unter demselben
//     Schluessel zaehlt hoch und wartet laenger (2, 4, 8, ... Minuten), statt die Liste zu fluten.
//  2. Nach fuenf Versuchen wird nicht weiter blind wiederholt, sondern liegengelassen - sichtbar,
//     mit Knopf zum Wiederaufnehmen. Endlose Wiederholung ist kein Betrieb, sondern Laerm.
//  3. Ein mehrschrittiger Vorgang bekommt ein Journal. Kein verteiltes Transaktionsprotokoll - das
//     gibt es hier nicht und die Behauptung waere gelogen -, sondern ein wiederaufsetzbarer,
//     idempotenter Ablauf: was schon erledigt ist, wird uebersprungen statt doppelt getan.

export const HOECHSTVERSUCHE=5;
export const ESKALATION_STUFEN=[24,72,168]; // Stunden nach Frist, bis zur naechsten Stufe
const clean=(v:unknown,n=2000)=>safeString(v,n);

function wartezeitMinuten(versuche:number):number{return Math.min(240,2**Math.max(0,versuche-1));}

/**
 * Einen Fehler festhalten - der Ersatz fuer console.error.
 *
 * Der Schluessel entscheidet, ob es derselbe Fehler ist: Quelle plus Bezug. Dieselbe Regel, die
 * seit drei Wochen scheitert, ist EIN Eintrag mit 47 Versuchen - nicht 47 Eintraege.
 */
export async function meldeAutomationsfehler(env:Env,eingabe:{quelle:string;quelle_id?:string|null;tenant_id?:string|null;fehler:unknown;nutzlast?:unknown}):Promise<{schluessel:string;versuche:number;liegengeblieben:boolean}>{
  const quelle=clean(eingabe.quelle,60)||'unbekannt',quelleId=clean(eingabe.quelle_id,120)||null;
  const roh=eingabe.fehler instanceof Error?eingabe.fehler.message:String(eingabe.fehler??'');
  // Nur der Code geht in die Warteschlange, nicht die ganze Meldung: sie kann Pfade, Kennungen
  // oder Datenbanktexte enthalten, und diese Liste liest ein Mensch im Betrieb.
  const code=(roh.split(':')[0]||'FEHLER').slice(0,80);
  const schluessel=`${quelle}:${quelleId??''}:${code}`,ts=nowIso();
  const vorhanden=await env.DB.prepare('SELECT id,versuche,status FROM automation_failures WHERE schluessel=?').bind(schluessel).first<{id:string;versuche:number;status:string}>();
  if(!vorhanden){
    await env.DB.prepare("INSERT INTO automation_failures(id,tenant_id,quelle,quelle_id,schluessel,fehler_code,fehler_text,nutzlast_json,versuche,naechster_versuch_am,status,erster_fehler_am,letzter_fehler_am) VALUES(?,?,?,?,?,?,?,?,1,?,'offen',?,?)")
      .bind(id('afl_'),clean(eingabe.tenant_id,120)||null,quelle,quelleId,schluessel,code,roh.slice(0,500),eingabe.nutzlast?JSON.stringify(eingabe.nutzlast):null,
        new Date(Date.parse(ts)+wartezeitMinuten(1)*60000).toISOString(),ts,ts).run();
    return{schluessel,versuche:1,liegengeblieben:false};
  }
  const versuche=Number(vorhanden.versuche)+1,liegen=versuche>=HOECHSTVERSUCHE;
  await env.DB.prepare('UPDATE automation_failures SET versuche=?,fehler_code=?,fehler_text=?,letzter_fehler_am=?,naechster_versuch_am=?,status=? WHERE id=?')
    .bind(versuche,code,roh.slice(0,500),ts,liegen?null:new Date(Date.parse(ts)+wartezeitMinuten(versuche)*60000).toISOString(),liegen?'liegengeblieben':'offen',vorhanden.id).run();
  return{schluessel,versuche,liegengeblieben:liegen};
}

/**
 * Ein Automatiklauf mit Fehlerauffang.
 *
 * Scheitert der Lauf, wird der Fehler festgehalten und NICHT weitergeworfen - sonst reisst ein
 * defekter Teil den ganzen Fuenfminutenlauf mit, und die uebrigen Aufgaben fallen mit aus.
 * Gelingt er, wird ein frueherer Fehler desselben Schluessels als erledigt markiert: eine Liste,
 * aus der nichts verschwindet, wird nicht gelesen.
 */
export async function mitFehlerauffang<T>(env:Env,quelle:string,quelleId:string|null,lauf:()=>Promise<T>,tenantId?:string|null):Promise<T|null>{
  try{
    const ergebnis=await lauf();
    await env.DB.prepare("UPDATE automation_failures SET status='erledigt',erledigt_am=? WHERE quelle=? AND COALESCE(quelle_id,'')=? AND status IN ('offen','liegengeblieben','wiederaufgenommen')")
      .bind(nowIso(),quelle,quelleId??'').run().catch(()=>undefined);
    return ergebnis;
  }catch(e){
    await meldeAutomationsfehler(env,{quelle,quelle_id:quelleId,tenant_id:tenantId,fehler:e});
    return null;
  }
}

export async function offeneAutomationsfehler(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return ((await env.DB.prepare("SELECT id,quelle,quelle_id,fehler_code,fehler_text,versuche,status,naechster_versuch_am,erster_fehler_am,letzter_fehler_am FROM automation_failures WHERE (tenant_id=? OR tenant_id IS NULL) AND status IN ('offen','liegengeblieben','wiederaufgenommen') ORDER BY status,letzter_fehler_am DESC LIMIT 200")
    .bind(tenantId).all()).results)??[];
}

/** Wiederaufnehmen: der Zaehler wird zurueckgesetzt, der naechste Lauf versucht es erneut. */
export async function nimmFehlerWiederAuf(env:Env,auth:CoreAuthContext,tenantId:string,failureId:string){
  requireRole(auth,'tenant_admin');
  const ts=nowIso();
  const r=await env.DB.prepare("UPDATE automation_failures SET status='wiederaufgenommen',versuche=0,naechster_versuch_am=? WHERE id=? AND (tenant_id=? OR tenant_id IS NULL) AND status IN ('offen','liegengeblieben','aufgegeben')")
    .bind(ts,failureId,tenantId).run();
  if(!r.meta?.changes)throw new Error('AUTOMATION_FEHLER_NICHT_GEFUNDEN');
  await audit(env.DB,auth.userId,'automation.failure_resumed',tenantId,undefined,'automation_failure',failureId);
  return{wiederaufgenommen:true};
}

/** Aufgeben - mit Grund. Ein Fehler, den man wegklickt, ohne zu sagen warum, kommt wieder. */
export async function gibFehlerAuf(env:Env,auth:CoreAuthContext,tenantId:string,failureId:string,grund:unknown){
  requireRole(auth,'tenant_admin');
  const text=clean(grund,500);
  if(text.length<10)throw new Error('AUTOMATION_AUFGABEGRUND_ERFORDERLICH');
  const r=await env.DB.prepare("UPDATE automation_failures SET status='aufgegeben',aufgegeben_von=?,aufgegeben_grund=?,naechster_versuch_am=NULL WHERE id=? AND (tenant_id=? OR tenant_id IS NULL) AND status<>'aufgegeben'")
    .bind(auth.userId,text,failureId,tenantId).run();
  if(!r.meta?.changes)throw new Error('AUTOMATION_FEHLER_NICHT_GEFUNDEN');
  await audit(env.DB,auth.userId,'automation.failure_abandoned',tenantId,undefined,'automation_failure',failureId,{grund:text});
  return{aufgegeben:true};
}

// ---------------------------------------------------------------------------
// W3: Eskalation
// ---------------------------------------------------------------------------

/**
 * Ueberfaellige Aufgaben eskalieren.
 *
 * Stufenweise: nach 24 Stunden an die Verantwortlichen des Kurses, nach 72 an die Leitung, nach
 * einer Woche als dringend markiert. Eine Frist, die niemand eskaliert, ist eine Notiz - und eine
 * Eskalation, die jeden Tag dasselbe meldet, wird weggeklickt. Deshalb steigt die Stufe, statt zu
 * wiederholen.
 */
export async function eskaliereUeberfaelligeAufgaben(env:Env,grenze=30,jetzt=nowIso()):Promise<{eskaliert:number;aufgaben:number}>{
  const faellig=((await env.DB.prepare("SELECT id,tenant_id,course_id,title,severity,due_at,eskalationsstufe FROM automation_tasks WHERE status IN ('open','in_progress') AND due_at IS NOT NULL AND due_at<=? ORDER BY due_at LIMIT ?")
    .bind(jetzt,Math.max(1,Math.min(200,grenze))).all<{id:string;tenant_id:string;course_id:string|null;title:string;severity:string;due_at:string;eskalationsstufe:number}>()).results)??[];
  if(!faellig.length)return{eskaliert:0,aufgaben:0};
  const anweisungen=[];let eskaliert=0;
  for(const a of faellig){
    const stunden=(Date.parse(jetzt)-Date.parse(a.due_at))/36e5;
    let stufe=0;
    for(let i=0;i<ESKALATION_STUFEN.length;i++)if(stunden>=ESKALATION_STUFEN[i])stufe=i+1;
    if(stufe<=Number(a.eskalationsstufe))continue;
    const empfaenger=((await env.DB.prepare("SELECT DISTINCT user_id FROM memberships WHERE tenant_id=? AND role='tenant_admin' LIMIT 20").bind(a.tenant_id).all<{user_id:string}>()).results)??[];
    for(const e of empfaenger)anweisungen.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,?,?,'automation_task_escalated',?,?,?)")
      .bind(id('ntf_'),a.tenant_id,a.course_id,e.user_id,`Aufgabe überfällig (Stufe ${stufe}): ${a.title}`,`Fällig seit ${a.due_at}. Bitte übernehmen oder abschließen.`,jetzt));
    anweisungen.push(env.DB.prepare("UPDATE automation_tasks SET eskalationsstufe=?,eskaliert_am=?,severity=CASE WHEN ?>=3 THEN 'urgent' ELSE severity END,updated_at=? WHERE id=?")
      .bind(stufe,jetzt,stufe,jetzt,a.id));
    eskaliert++;
  }
  for(let i=0;i<anweisungen.length;i+=80)await env.DB.batch(anweisungen.slice(i,i+80));
  return{eskaliert,aufgaben:faellig.length};
}

// ---------------------------------------------------------------------------
// W4: Der Vorgangsbegriff
// ---------------------------------------------------------------------------

export type Vorgang={id:string;neu:boolean};

/**
 * Einen mehrschrittigen Vorgang beginnen - oder den laufenden wiederfinden.
 *
 * Derselbe fachliche Vorgang zweimal angestossen ergibt denselben Eintrag. Das ist die halbe Miete:
 * ohne diesen Schluessel wuerde ein Wiederanlauf alles noch einmal tun.
 */
export async function starteVorgang(env:Env,tenantId:string,vorgang:string,vorgangsschluessel:string,gestartetVon?:string|null):Promise<Vorgang>{
  const ts=nowIso(),vid=id('vgg_');
  const vorhanden=await env.DB.prepare('SELECT id,status FROM operation_journal WHERE tenant_id=? AND vorgang=? AND vorgangsschluessel=?')
    .bind(tenantId,vorgang,vorgangsschluessel).first<{id:string;status:string}>();
  if(vorhanden){
    if(vorhanden.status==='fehler')await env.DB.prepare("UPDATE operation_journal SET status='laufend',fehler_code=NULL WHERE id=?").bind(vorhanden.id).run();
    return{id:vorhanden.id,neu:false};
  }
  await env.DB.prepare("INSERT INTO operation_journal(id,tenant_id,vorgang,vorgangsschluessel,status,gestartet_von,gestartet_am) VALUES(?,?,?,?,'laufend',?,?)")
    .bind(vid,tenantId,vorgang,vorgangsschluessel,gestartetVon??null,ts).run();
  return{id:vid,neu:true};
}

/**
 * Einen Schritt ausfuehren - genau einmal.
 *
 * Steht der Schritt schon als 'erfolg' im Journal, wird er UEBERSPRUNGEN und sein gespeichertes
 * Ergebnis zurueckgegeben. Genau daran haengt die Wiederaufsetzbarkeit: 30 von 60 Bescheinigungen,
 * Abbruch, Wiederanlauf - und die 30 werden nicht noch einmal geschrieben.
 */
export async function schritt<T>(env:Env,journalId:string,name:string,nr:number,lauf:()=>Promise<T>):Promise<T>{
  const vorhanden=await env.DB.prepare('SELECT status,ergebnis_json FROM operation_journal_steps WHERE journal_id=? AND schritt=?').bind(journalId,name).first<{status:string;ergebnis_json:string|null}>();
  if(vorhanden?.status==='erfolg')return (vorhanden.ergebnis_json?JSON.parse(vorhanden.ergebnis_json):null) as T;
  const ts=nowIso();
  if(!vorhanden)await env.DB.prepare("INSERT INTO operation_journal_steps(id,journal_id,schritt,schritt_nr,status,begonnen_am) VALUES(?,?,?,?,'begonnen',?)").bind(id('vgs_'),journalId,name,nr,ts).run();
  try{
    const ergebnis=await lauf();
    await env.DB.prepare("UPDATE operation_journal_steps SET status='erfolg',ergebnis_json=?,beendet_am=? WHERE journal_id=? AND schritt=?")
      .bind(ergebnis===undefined?null:JSON.stringify(ergebnis),nowIso(),journalId,name).run();
    return ergebnis;
  }catch(e){
    const code=String((e as Error)?.message??'FEHLER').split(':')[0].slice(0,80);
    await env.DB.batch([
      env.DB.prepare("UPDATE operation_journal_steps SET status='fehler',fehler_code=?,beendet_am=? WHERE journal_id=? AND schritt=?").bind(code,nowIso(),journalId,name),
      env.DB.prepare("UPDATE operation_journal SET status='fehler',fehler_code=?,beendet_am=? WHERE id=?").bind(code,nowIso(),journalId),
    ]);
    throw e;
  }
}

export async function beendeVorgang(env:Env,journalId:string){
  await env.DB.prepare("UPDATE operation_journal SET status='erfolg',beendet_am=? WHERE id=? AND status='laufend'").bind(nowIso(),journalId).run();
  return{beendet:true};
}

/** Der Stand eines Vorgangs: welcher Schritt haelt, und woran es gescheitert ist. */
export async function vorgangsstand(env:Env,auth:CoreAuthContext,tenantId:string,journalId:string){
  requireRole(auth,'tenant_admin');
  const kopf=await env.DB.prepare('SELECT * FROM operation_journal WHERE id=? AND tenant_id=?').bind(journalId,tenantId).first<Record<string,unknown>>();
  if(!kopf)throw new Error('VORGANG_NICHT_GEFUNDEN');
  const schritte=((await env.DB.prepare('SELECT schritt,schritt_nr,status,fehler_code,begonnen_am,beendet_am FROM operation_journal_steps WHERE journal_id=? ORDER BY schritt_nr').bind(journalId).all()).results)??[];
  return{vorgang:kopf,schritte};
}

export async function haengendeVorgaenge(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return ((await env.DB.prepare("SELECT j.id,j.vorgang,j.vorgangsschluessel,j.status,j.fehler_code,j.gestartet_am,(SELECT COUNT(*) FROM operation_journal_steps s WHERE s.journal_id=j.id AND s.status='erfolg') erledigt,(SELECT COUNT(*) FROM operation_journal_steps s WHERE s.journal_id=j.id) schritte FROM operation_journal j WHERE j.tenant_id=? AND j.status IN ('laufend','fehler') ORDER BY j.gestartet_am DESC LIMIT 100")
    .bind(tenantId).all()).results)??[];
}

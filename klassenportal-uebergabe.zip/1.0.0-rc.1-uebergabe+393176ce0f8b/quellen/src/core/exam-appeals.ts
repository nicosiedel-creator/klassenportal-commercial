import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireCourseAccess, requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Einspruch und Zweitkorrektur (Master-Spec V2 §2.4).
//
// Die Beweislast fuer ein ordnungsgemaesses Pruefungsverfahren liegt beim Pruefenden. Wer eine
// Pruefung nicht besteht, muss sie anfechten koennen, und der Traeger muss belegen koennen, dass er
// die Anfechtung bearbeitet hat - wann, durch wen und mit welchem Ergebnis.
//
// Zwei Dinge macht dieses Modul deshalb nicht als Empfehlung, sondern als Regel:
//  - die Frist zaehlt ab der Bekanntgabe des Ergebnisses, nicht ab dem Einspruch;
//  - die Zweitkorrektur ist unabhaengig: eine andere Person, und sie sieht die erste Bewertung
//    erst nach ihrer eigenen Abgabe. Eine Zweitkorrektur, die die erste Note kennt, ist keine.

export const FRIST_TAGE_VORGABE=30;
export const STATUS_OFFEN=['eingelegt','zweitkorrektur'];
const clean=(v:unknown,n=500)=>safeString(v,n);
function manager(auth:CoreAuthContext,courseId:string){requireRole(auth,'class_admin');requireCourseAccess(auth,courseId,'class_admin');}

export type Bewertung={punkte:number|null;graded_at:string|null;graded_by:string|null;course_id:string;user_id:string};

/** Die angefochtene Bewertung - aus der Quelle, nicht aus einer Kopie. */
async function bewertung(env:Env,tenantId:string,gegenstand:string,bezugId:string):Promise<Bewertung|null>{
  if(gegenstand==='quiz_attempt')
    return env.DB.prepare("SELECT total_points AS punkte,graded_at,graded_by,course_id,user_id FROM quiz_attempts WHERE tenant_id=? AND id=? AND status='graded'").bind(tenantId,bezugId).first<Bewertung>();
  return env.DB.prepare("SELECT points AS punkte,graded_at,graded_by,course_id,user_id FROM gradebook_scores WHERE tenant_id=? AND id=? AND status='published'").bind(tenantId,bezugId).first<Bewertung>();
}

async function fristTage(env:Env,tenantId:string):Promise<number>{
  const r=await env.DB.prepare('SELECT einspruchsfrist_tage FROM tenant_settings WHERE tenant_id=?').bind(tenantId).first<{einspruchsfrist_tage:number}>();
  return Number(r?.einspruchsfrist_tage||FRIST_TAGE_VORGABE);
}

const plusTage=(iso:string,tage:number)=>new Date(Date.parse(iso)+tage*86400000).toISOString();

/**
 * Einspruch einlegen. Nur die betroffene Person selbst - eine Anfechtung ist ihre Entscheidung.
 */
export async function fileAppeal(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,input:Record<string,unknown>,jetzt=nowIso()){
  requireCourseAccess(auth,courseId);
  const gegenstand=clean(input.gegenstand,40);
  if(!['quiz_attempt','gradebook_score'].includes(gegenstand))throw new Error('APPEAL_SUBJECT_INVALID');
  const bezugId=clean(input.bezug_id,120),begruendung=clean(input.begruendung,5000);
  if(!bezugId)throw new Error('APPEAL_SUBJECT_INVALID');
  // Ein Einspruch ohne Begruendung laesst sich nicht bescheiden - und die Person haette nichts in
  // der Hand, wenn der Traeger spaeter behauptet, es sei nie einer gekommen.
  if(begruendung.length<20)throw new Error('APPEAL_REASON_REQUIRED');
  const b=await bewertung(env,tenantId,gegenstand,bezugId);
  if(!b||b.course_id!==courseId)throw new Error('APPEAL_SUBJECT_NOT_FOUND');
  if(b.user_id!==auth.userId)throw new Error('APPEAL_NOT_OWN_RESULT');
  // Ohne Bekanntgabe laeuft keine Frist. Eine Bewertung ohne Datum ist noch nicht bekanntgegeben -
  // die Person kann dann nicht zu spaet sein.
  const bekanntgabe=b.graded_at||jetzt;
  const frist=plusTage(bekanntgabe,await fristTage(env,tenantId));
  if(Date.parse(jetzt)>Date.parse(frist))throw new Error('APPEAL_DEADLINE_PASSED');
  const aid=id('eins_');
  try{
    await env.DB.prepare('INSERT INTO exam_appeals(id,tenant_id,course_id,user_id,gegenstand,bezug_id,begruendung,bekanntgabe_am,frist_bis,eingelegt_am,status,urspruengliche_punkte,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,\'eingelegt\',?,?)')
      .bind(aid,tenantId,courseId,auth.userId,gegenstand,bezugId,begruendung,bekanntgabe,frist,jetzt,b.punkte,jetzt).run();
  }catch(e){
    if(/UNIQUE/i.test(String((e as Error).message)))throw new Error('APPEAL_ALREADY_FILED');
    throw e;
  }
  await audit(env.DB,auth.userId,'exam.appeal_filed',tenantId,courseId,'exam_appeal',aid,{gegenstand});
  return env.DB.prepare('SELECT * FROM exam_appeals WHERE id=?').bind(aid).first();
}

/** Zweitkorrektur beauftragen. Nicht bei derselben Person, die zuerst bewertet hat. */
export async function orderSecondMarking(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,appealId:string,input:Record<string,unknown>){
  manager(auth,courseId);
  const a=await env.DB.prepare('SELECT * FROM exam_appeals WHERE id=? AND tenant_id=? AND course_id=?').bind(appealId,tenantId,courseId).first<Record<string,unknown>>();
  if(!a)throw new Error('APPEAL_NOT_FOUND');
  if(a.status!=='eingelegt')throw new Error('APPEAL_NOT_OPEN');
  const zweit=clean(input.zweitkorrektur_von,120);
  if(!zweit)throw new Error('APPEAL_SECOND_MARKER_REQUIRED');
  const b=await bewertung(env,tenantId,String(a.gegenstand),String(a.bezug_id));
  // Der Kern der Sache: wer zuerst bewertet hat, kann nicht sein eigenes Urteil ueberpruefen.
  if(b?.graded_by&&b.graded_by===zweit)throw new Error('APPEAL_SECOND_MARKER_SAME_PERSON');
  if(zweit===a.user_id)throw new Error('APPEAL_SECOND_MARKER_SAME_PERSON');
  const lehrt=await env.DB.prepare("SELECT 1 x FROM memberships WHERE tenant_id=? AND user_id=? AND role IN ('class_admin','tenant_admin')").bind(tenantId,zweit).first();
  if(!lehrt)throw new Error('APPEAL_SECOND_MARKER_NOT_ALLOWED');
  const ts=nowIso();
  await env.DB.batch([
    env.DB.prepare('INSERT INTO exam_second_markings(id,appeal_id,tenant_id,erstkorrektur_von,zweitkorrektur_von,beauftragt_von,beauftragt_am) VALUES(?,?,?,?,?,?,?)')
      .bind(id('zwk_'),appealId,tenantId,b?.graded_by??null,zweit,auth.userId,ts),
    env.DB.prepare("UPDATE exam_appeals SET status='zweitkorrektur',updated_at=? WHERE id=?").bind(ts,appealId),
  ]);
  await audit(env.DB,auth.userId,'exam.second_marking_ordered',tenantId,courseId,'exam_appeal',appealId,{zweitkorrektur_von:zweit});
  return{ordered:true};
}

/**
 * Die eigene Zweitkorrektur abgeben.
 *
 * Bewusst OHNE die erste Bewertung im Rueckgabewert der Auftragsliste: wer die erste Note kennt,
 * korrigiert nicht mehr unabhaengig. Erst nach der eigenen Abgabe wird sie sichtbar.
 */
export async function submitSecondMarking(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,appealId:string,input:Record<string,unknown>){
  manager(auth,courseId);
  const m=await env.DB.prepare('SELECT * FROM exam_second_markings WHERE appeal_id=? AND tenant_id=?').bind(appealId,tenantId).first<Record<string,unknown>>();
  if(!m)throw new Error('SECOND_MARKING_NOT_FOUND');
  if(m.zweitkorrektur_von!==auth.userId)throw new Error('SECOND_MARKING_NOT_ASSIGNED');
  if(m.abgeschlossen_am)throw new Error('SECOND_MARKING_ALREADY_DONE');
  const punkte=Number(input.punkte);
  if(!Number.isFinite(punkte)||punkte<0)throw new Error('SECOND_MARKING_POINTS_INVALID');
  const ts=nowIso();
  await env.DB.prepare('UPDATE exam_second_markings SET punkte=?,kommentar=?,abgeschlossen_am=? WHERE appeal_id=?')
    .bind(punkte,clean(input.kommentar,5000)||null,ts,appealId).run();
  await audit(env.DB,auth.userId,'exam.second_marking_submitted',tenantId,courseId,'exam_appeal',appealId,{punkte});
  // Jetzt - und keinen Schritt frueher - darf die erste Bewertung gezeigt werden.
  return env.DB.prepare('SELECT zweitkorrektur_von,punkte,kommentar,abgeschlossen_am,erstkorrektur_von,(SELECT urspruengliche_punkte FROM exam_appeals WHERE id=?) AS erstbewertung FROM exam_second_markings WHERE appeal_id=?').bind(appealId,appealId).first();
}

/** Die eigenen Auftraege zur Zweitkorrektur - ohne die erste Bewertung, solange nicht abgegeben. */
export async function mySecondMarkings(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  manager(auth,courseId);
  return (await env.DB.prepare('SELECT m.appeal_id,m.beauftragt_am,m.abgeschlossen_am,a.gegenstand,a.bezug_id,a.begruendung,u.display_name,gi.rubric_id,CASE WHEN m.abgeschlossen_am IS NULL THEN NULL ELSE a.urspruengliche_punkte END AS erstbewertung,CASE WHEN m.abgeschlossen_am IS NULL THEN NULL ELSE m.punkte END AS meine_punkte FROM exam_second_markings m JOIN exam_appeals a ON a.id=m.appeal_id JOIN users u ON u.id=a.user_id LEFT JOIN gradebook_scores gs ON gs.id=a.bezug_id AND a.gegenstand=\'gradebook_score\' LEFT JOIN gradebook_items gi ON gi.id=gs.item_id WHERE m.tenant_id=? AND a.course_id=? AND m.zweitkorrektur_von=? ORDER BY m.beauftragt_am DESC')
    .bind(tenantId,courseId,auth.userId).all()).results??[];
}

/**
 * Bescheiden. Bei Abhilfe wird die Bewertung in der Quelle geaendert - sonst waere der Bescheid
 * eine Zusage, die sich im Zeugnis nicht wiederfindet.
 */
export async function decideAppeal(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,appealId:string,input:Record<string,unknown>){
  manager(auth,courseId);
  const a=await env.DB.prepare('SELECT * FROM exam_appeals WHERE id=? AND tenant_id=? AND course_id=?').bind(appealId,tenantId,courseId).first<Record<string,unknown>>();
  if(!a)throw new Error('APPEAL_NOT_FOUND');
  if(!STATUS_OFFEN.includes(String(a.status)))throw new Error('APPEAL_ALREADY_DECIDED');
  const ergebnis=clean(input.status,40);
  if(!['abgeholfen','zurueckgewiesen'].includes(ergebnis))throw new Error('APPEAL_DECISION_INVALID');
  const text=clean(input.entscheidung,5000);
  // Eine Zurueckweisung ohne Begruendung ist im Streitfall wertlos - und genau sie wird angegriffen.
  if(text.length<20)throw new Error('APPEAL_DECISION_REASON_REQUIRED');
  // Wer entschieden hat, darf nicht die Person sein, die den Einspruch eingelegt hat.
  if(a.user_id===auth.userId)throw new Error('APPEAL_DECIDER_IS_APPELLANT');
  const ts=nowIso();
  const anweisungen=[] as unknown[];
  let neue:number|null=null;
  if(ergebnis==='abgeholfen'){
    const zwk=await env.DB.prepare('SELECT punkte,abgeschlossen_am FROM exam_second_markings WHERE appeal_id=?').bind(appealId).first<{punkte:number|null;abgeschlossen_am:string|null}>();
    const roh=input.neue_punkte===undefined||input.neue_punkte===null||input.neue_punkte===''?(zwk?.abgeschlossen_am?zwk.punkte:null):Number(input.neue_punkte);
    if(roh===null||!Number.isFinite(Number(roh))||Number(roh)<0)throw new Error('APPEAL_NEW_POINTS_REQUIRED');
    neue=Number(roh);
    anweisungen.push(a.gegenstand==='quiz_attempt'
      ?env.DB.prepare('UPDATE quiz_attempts SET total_points=?,manual_points=?-auto_points,graded_at=?,graded_by=? WHERE id=? AND tenant_id=?').bind(neue,neue,ts,auth.userId,a.bezug_id,tenantId)
      :env.DB.prepare('UPDATE gradebook_scores SET points=?,graded_at=?,graded_by=?,updated_at=? WHERE id=? AND tenant_id=?').bind(neue,ts,auth.userId,ts,a.bezug_id,tenantId));
  }
  anweisungen.push(env.DB.prepare('UPDATE exam_appeals SET status=?,entscheidung=?,entschieden_von=?,entschieden_am=?,neue_punkte=?,updated_at=? WHERE id=?')
    .bind(ergebnis,text,auth.userId,ts,neue,ts,appealId));
  await env.DB.batch(anweisungen as never[]);
  await audit(env.DB,auth.userId,'exam.appeal_decided',tenantId,courseId,'exam_appeal',appealId,{status:ergebnis,neue_punkte:neue});
  return env.DB.prepare('SELECT * FROM exam_appeals WHERE id=?').bind(appealId).first();
}

export async function withdrawAppeal(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,appealId:string){
  requireCourseAccess(auth,courseId);
  const ts=nowIso();
  const r=await env.DB.prepare("UPDATE exam_appeals SET status='zurueckgenommen',updated_at=? WHERE id=? AND tenant_id=? AND user_id=? AND status IN ('eingelegt','zweitkorrektur')")
    .bind(ts,appealId,tenantId,auth.userId).run();
  if(!r.meta?.changes)throw new Error('APPEAL_NOT_FOUND');
  await audit(env.DB,auth.userId,'exam.appeal_withdrawn',tenantId,courseId,'exam_appeal',appealId);
  return{withdrawn:true};
}

export async function listAppeals(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  manager(auth,courseId);
  const appeals=(await env.DB.prepare('SELECT a.*,u.display_name,m.zweitkorrektur_von,m.abgeschlossen_am AS zweitkorrektur_am,z.display_name AS zweitkorrektur_name,CASE WHEN m.abgeschlossen_am IS NULL THEN NULL ELSE m.punkte END AS zweitkorrektur_punkte FROM exam_appeals a JOIN users u ON u.id=a.user_id LEFT JOIN exam_second_markings m ON m.appeal_id=a.id LEFT JOIN users z ON z.id=m.zweitkorrektur_von WHERE a.tenant_id=? AND a.course_id=? ORDER BY a.eingelegt_am DESC')
    .bind(tenantId,courseId).all()).results??[];
  const korrigierende=(await env.DB.prepare("SELECT DISTINCT u.id,u.display_name FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.tenant_id=? AND m.role IN ('class_admin','tenant_admin') AND u.status='active' ORDER BY u.display_name")
    .bind(tenantId).all()).results??[];
  return{appeals,korrigierende};
}

/** Die eigene Sicht: welche Einsprueche laufen, und was ist daraus geworden. */
export async function myAppeals(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  requireCourseAccess(auth,courseId);
  return (await env.DB.prepare('SELECT id,gegenstand,bezug_id,begruendung,bekanntgabe_am,frist_bis,eingelegt_am,status,urspruengliche_punkte,neue_punkte,entscheidung,entschieden_am FROM exam_appeals WHERE tenant_id=? AND course_id=? AND user_id=? ORDER BY eingelegt_am DESC')
    .bind(tenantId,courseId,auth.userId).all()).results??[];
}

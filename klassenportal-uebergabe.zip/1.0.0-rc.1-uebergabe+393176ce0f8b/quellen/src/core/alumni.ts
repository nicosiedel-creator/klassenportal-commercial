import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Alumni-Status nach Abschluss (L1).
//
// Nach dem Abschluss endet die Mitgliedschaft - und mit ihr heute der Zugang zum eigenen
// Zeugnis. Das ist der Moment, in dem der Traeger Anrufe bekommt: "Ich brauche mein Zeugnis
// noch einmal", zwei Jahre spaeter, fuer eine Bewerbung.
//
// Ein Alumni-Status loest das. Aber nur, wenn er den Umfang WIRKLICH einschraenkt - sonst ist
// er eine unbefristete Vollmitgliedschaft unter anderem Namen, und der Traeger fuehrt
// Personendaten von Menschen, zu denen er kein Verhaeltnis mehr hat.
//
// Drei Regeln tragen das:
//  - Der Umfang ist eine geschlossene, kurze Liste. Alles, was nicht darin steht, ist zu.
//  - Die Kontaktaufnahme braucht eine widerrufliche Einwilligung. Ohne sie ist die Alumniliste
//    ein Adressbestand ohne Grundlage.
//  - Ein Alumnus zaehlt in keiner Betriebsstatistik mehr mit. Sonst schoent die Abschlussquote
//    sich selbst.

const clean=(v:unknown,n=2000)=>safeString(v,n);
export const ABSCHLUSSARTEN=['bestanden','teilnahme','abgebrochen'] as const;
/**
 * Was ein Alumnus noch sehen darf.
 *
 * Bewusst kurz. 'zeugnis' und 'nachweise' sind der Grund, warum es den Status gibt;
 * 'veranstaltungen' ist die Einladung zum Ehemaligentreffen. Mehr braucht niemand, und jedes
 * weitere Recht muesste erklaeren, warum es den Abschluss ueberdauert.
 */
export const UMFANG=['zeugnis','nachweise','veranstaltungen'] as const;

/**
 * Den Abschluss vollziehen.
 *
 * Die Mitgliedschaft im Kurs endet, der Alumni-Eintrag beginnt. Die Leistungen bleiben stehen -
 * sie sind der Grund fuer den ganzen Vorgang.
 */
export async function schliesseAb(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const userId=clean(input.user_id,120),courseId=clean(input.course_id,120)||null;
  const art=clean(input.abschlussart,30);
  if(!(ABSCHLUSSARTEN as readonly string[]).includes(art))throw new Error('ALUMNI_ABSCHLUSSART_UNGUELTIG');
  const am=clean(input.abschluss_am,10)||nowIso().slice(0,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(am))throw new Error('ALUMNI_DATUM_UNGUELTIG');
  const mitglied=await env.DB.prepare("SELECT 1 AS ok FROM memberships WHERE tenant_id=? AND user_id=? AND role='participant' AND (course_id=? OR ? IS NULL)")
    .bind(tenantId,userId,courseId,courseId).first();
  if(!mitglied)throw new Error('ALUMNI_KEINE_TEILNAHME');
  const rohUmfang=Array.isArray(input.umfang)?input.umfang.map(v=>clean(v,40)):['zeugnis','nachweise'];
  const umfang=[...new Set(rohUmfang)].filter(u=>(UMFANG as readonly string[]).includes(u));
  if(!umfang.length)throw new Error('ALUMNI_UMFANG_ERFORDERLICH');
  const ts=nowIso(),eintragId=id('alu_');
  await env.DB.batch([
    env.DB.prepare('INSERT INTO alumni_records(id,tenant_id,user_id,course_id,abschluss_am,abschlussart,umfang_json,kontakt_einwilligung,status,angelegt_von,created_at,updated_at) VALUES(?,?,?,?,?,?,?,0,?,?,?,?) ON CONFLICT(tenant_id,user_id,course_id) DO UPDATE SET abschluss_am=excluded.abschluss_am,abschlussart=excluded.abschlussart,umfang_json=excluded.umfang_json,status=\'aktiv\',updated_at=excluded.updated_at')
      .bind(eintragId,tenantId,userId,courseId,am,art,JSON.stringify(umfang),'aktiv',auth.userId,ts,ts),
    // Die Mitgliedschaft endet. Die Leistungen im Kurs bleiben stehen - sie zu loeschen waere
    // genau die Geschichtsfaelschung, die der Alumni-Status verhindern soll.
    env.DB.prepare("DELETE FROM memberships WHERE tenant_id=? AND user_id=? AND role='participant' AND (course_id=? OR ? IS NULL)")
      .bind(tenantId,userId,courseId,courseId)]);
  await audit(env.DB,auth.userId,'alumni.graduated',tenantId,courseId??undefined,'alumni_record',eintragId,{art});
  return{id:eintragId,status:'aktiv',umfang};
}

/**
 * Darf dieser Alumnus das noch?
 *
 * Der Torwaechter. Ohne ihn waere der Umfang eine Angabe in einer Spalte, die niemand liest.
 */
export async function assertAlumniZugriff(env:Env,tenantId:string,userId:string,bereich:string){
  const zeile=await env.DB.prepare("SELECT umfang_json FROM alumni_records WHERE tenant_id=? AND user_id=? AND status='aktiv' ORDER BY abschluss_am DESC LIMIT 1")
    .bind(tenantId,clean(userId,120)).first<{umfang_json:string}>();
  if(!zeile)throw new Error('ALUMNI_KEIN_EINTRAG');
  let umfang:string[]=[];try{umfang=JSON.parse(zeile.umfang_json||'[]');}catch{}
  if(!umfang.includes(clean(bereich,40)))throw new Error('ALUMNI_AUSSERHALB_UMFANG');
  return{erlaubt:true};
}

/** Die Einwilligung zur Kontaktaufnahme - erteilt und widerrufen von der Person selbst. */
export async function setzeKontakteinwilligung(env:Env,auth:CoreAuthContext,tenantId:string,erteilt:boolean){
  const zeile=await env.DB.prepare("SELECT id FROM alumni_records WHERE tenant_id=? AND user_id=? AND status='aktiv' ORDER BY abschluss_am DESC LIMIT 1")
    .bind(tenantId,auth.userId).first<{id:string}>();
  if(!zeile)throw new Error('ALUMNI_KEIN_EINTRAG');
  const ts=nowIso();
  await env.DB.prepare('UPDATE alumni_records SET kontakt_einwilligung=?,einwilligung_am=?,einwilligung_widerrufen_am=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(erteilt?1:0,erteilt?ts:null,erteilt?null:ts,ts,zeile.id,tenantId).run();
  return{kontakt_einwilligung:erteilt};
}

/**
 * Die Alumniliste fuer eine Ansprache.
 *
 * Nur Eingewilligte. Das ist keine Filterbequemlichkeit: die Liste OHNE diesen Filter waere ein
 * Adressbestand, fuer den der Traeger keine Grundlage hat - und genau dafuer wird sie benutzt.
 */
export async function ansprechbareAlumni(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return ((await env.DB.prepare(`SELECT a.user_id,u.display_name,a.course_id,a.abschluss_am,a.abschlussart
    FROM alumni_records a JOIN users u ON u.id=a.user_id
    WHERE a.tenant_id=? AND a.status='aktiv' AND a.kontakt_einwilligung=1 ORDER BY a.abschluss_am DESC LIMIT 500`)
    .bind(tenantId).all()).results)??[];
}

/** Den Status beenden - auf Wunsch der Person oder nach Ablauf der Aufbewahrung. */
export async function beendeAlumnistatus(env:Env,auth:CoreAuthContext,tenantId:string,userId:string){
  const person=clean(userId,120);
  if(person!==auth.userId)requireRole(auth,'tenant_admin');
  const ts=nowIso();
  const r=await env.DB.prepare("UPDATE alumni_records SET status='beendet',beendet_am=?,kontakt_einwilligung=0,updated_at=? WHERE tenant_id=? AND user_id=? AND status='aktiv'")
    .bind(ts,ts,tenantId,person).run();
  if(!Number(r?.meta?.changes??0))throw new Error('ALUMNI_KEIN_EINTRAG');
  return{status:'beendet'};
}

/**
 * Der Jahrgangsstand - und der Punkt, an dem ein Alumnus NICHT mehr mitzaehlt.
 *
 * Zwei Abfragen. Die Trennung ist der Kern: wer abgeschlossen hat, ist kein laufender
 * Teilnehmer mehr. Beides zusammenzuzaehlen schoent die Abschlussquote gegen sich selbst.
 */
export async function alumnistand(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  const alumni=await env.DB.prepare(`SELECT COUNT(*) AS gesamt,
    SUM(CASE WHEN abschlussart='bestanden' THEN 1 ELSE 0 END) AS bestanden,
    SUM(CASE WHEN abschlussart='abgebrochen' THEN 1 ELSE 0 END) AS abgebrochen,
    SUM(CASE WHEN kontakt_einwilligung=1 THEN 1 ELSE 0 END) AS ansprechbar
    FROM alumni_records WHERE tenant_id=? AND status='aktiv'`).bind(tenantId).first<Record<string,number>>();
  const laufend=await env.DB.prepare("SELECT COUNT(DISTINCT user_id) AS n FROM memberships WHERE tenant_id=? AND role='participant'")
    .bind(tenantId).first<{n:number}>();
  const gesamt=Number(alumni?.gesamt??0);
  return{...(alumni??{}),laufende_teilnehmer:Number(laufend?.n??0),
    // Die Quote rechnet ueber die Abgeschlossenen, nicht ueber alle Koepfe im Haus.
    abschlussquote_prozent:gesamt?Math.round(Number(alumni?.bestanden??0)/gesamt*100):null};
}

/** Meine eigenen Abschluesse - fuer das Portal. */
export async function meineAbschluesse(env:Env,auth:CoreAuthContext,tenantId:string){
  return ((await env.DB.prepare('SELECT id,course_id,abschluss_am,abschlussart,umfang_json,kontakt_einwilligung,status FROM alumni_records WHERE tenant_id=? AND user_id=? ORDER BY abschluss_am DESC LIMIT 50')
    .bind(tenantId,auth.userId).all()).results)??[];
}

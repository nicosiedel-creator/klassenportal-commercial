import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { dataResidencyStatus } from './data-residency.js';
import { id, nowIso, safeString } from './utils.js';

// Datenresidenz nachvollziehbar konfigurierbar (R11).
//
// data-residency.ts gibt es schon: es prueft die ZUSICHERUNGEN der Plattform gegen die
// Umgebung - ist die D1 mit EU-Jurisdiktion angelegt, ist R2 belegt, ist der Mailversand
// eingerichtet. Das ist die technische Seite und bleibt, wie sie ist.
//
// Was fehlte, ist die Seite des TRAEGERS: was hat er zugesagt, und haelt der tatsaechliche
// Bestand das ein?
//
// Die Frage "wo liegen unsere Daten" beantwortet ein Traeger heute mit einem Satz aus dem
// Angebot. Fuer die Auftragsverarbeitung reicht das nicht: er muss sagen koennen, WELCHE
// Bestandteile wo liegen - und es muss auffallen, wenn ein neu eingetragener Anbieter die
// Zusage bricht.
//
// Genau dieser Fall ist der haeufige. Nicht die Ersteinrichtung ist das Risiko, sondern der
// Anbieter, den ein halbes Jahr spaeter jemand dazustellt, weil er billiger ist. Deshalb
// verweigert dieses Modul die EINTRAGUNG, statt hinterher zu melden - ausser der Traeger hat
// Ausnahmen ausdruecklich erlaubt und diese eine begruendet.

const clean=(v:unknown,n=2000)=>safeString(v,n);
export const REGIONEN=['eu','de','us','weltweit'] as const;
/**
 * Welche Region welche abdeckt.
 *
 * 'de' ist enger als 'eu': wer Deutschland zusagt, hat mit Irland seine Zusage gebrochen. Die
 * umgekehrte Richtung gilt: ein deutscher Standort erfuellt eine EU-Zusage.
 */
export const DECKT:Record<string,string[]>={de:['de'],eu:['de','eu'],us:['us'],weltweit:['de','eu','us','weltweit']};

/** Die Bestandteile, die eine Region haben. Wer hier fehlt, faellt in der Pruefung auf. */
export const BESTANDTEILE=['datenbank','dateien','mailversand','ki','sicherung'] as const;

export async function legeResidenzFest(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const region=clean(input.zugesagte_region,20);
  if(!(REGIONEN as readonly string[]).includes(region))throw new Error('RESIDENZ_REGION_UNGUELTIG');
  const ts=nowIso();
  await env.DB.prepare(`INSERT INTO residency_policies(tenant_id,zugesagte_region,rechtsgrundlage,ausnahmen_erlaubt,festgelegt_von,festgelegt_am,updated_at) VALUES(?,?,?,?,?,?,?)
    ON CONFLICT(tenant_id) DO UPDATE SET zugesagte_region=excluded.zugesagte_region,rechtsgrundlage=excluded.rechtsgrundlage,ausnahmen_erlaubt=excluded.ausnahmen_erlaubt,updated_at=excluded.updated_at`)
    .bind(tenantId,region,clean(input.rechtsgrundlage,1000)||null,input.ausnahmen_erlaubt===true?1:0,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'residency.set',tenantId,undefined,'residency_policy',tenantId,{region});
  return{zugesagte_region:region};
}

export async function residenzzusage(env:Env,tenantId:string){
  return await env.DB.prepare('SELECT zugesagte_region,rechtsgrundlage,ausnahmen_erlaubt FROM residency_policies WHERE tenant_id=?')
    .bind(tenantId).first<{zugesagte_region:string;rechtsgrundlage:string|null;ausnahmen_erlaubt:number}>();
}

/**
 * Der Torwaechter: darf dieser Bestandteil in dieser Region liegen?
 *
 * Ohne Zusage gibt es nichts zu brechen - dann ist alles erlaubt, und die Pruefung sagt das
 * ausdruecklich. Eine erfundene Vorgabe waere schlimmer: sie verspraeche eine Sicherheit, die
 * niemand zugesagt hat.
 */
export async function assertResidenz(env:Env,tenantId:string,bestandteil:string,region:string,heute?:string){
  const zusage=await residenzzusage(env,tenantId);
  if(!zusage)return{geprueft:false,grund:'RESIDENZ_OHNE_ZUSAGE'};
  const erlaubt=DECKT[zusage.zugesagte_region]??[];
  if(erlaubt.includes(region))return{geprueft:true};
  const tag=clean(heute,10)||nowIso().slice(0,10);
  const ausnahme=await env.DB.prepare('SELECT region,gueltig_bis FROM residency_exceptions WHERE tenant_id=? AND bestandteil=?')
    .bind(tenantId,clean(bestandteil,60)).first<{region:string;gueltig_bis:string|null}>();
  // Eine abgelaufene Ausnahme ist keine. Ohne dieses Datum bliebe die erste Ausnahme fuer immer.
  if(ausnahme&&ausnahme.region===region&&(!ausnahme.gueltig_bis||ausnahme.gueltig_bis>=tag))return{geprueft:true,ausnahme:true};
  throw new Error('RESIDENZ_REGION_NICHT_ZUGESAGT');
}

/** Eine Ausnahme erteilen - nur wenn der Traeger Ausnahmen ueberhaupt zulaesst, und nur begruendet. */
export async function erteileAusnahme(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const zusage=await residenzzusage(env,tenantId);
  if(!zusage)throw new Error('RESIDENZ_OHNE_ZUSAGE');
  if(!zusage.ausnahmen_erlaubt)throw new Error('RESIDENZ_AUSNAHMEN_GESPERRT');
  const bestandteil=clean(input.bestandteil,60),region=clean(input.region,20);
  if(!(BESTANDTEILE as readonly string[]).includes(bestandteil))throw new Error('RESIDENZ_BESTANDTEIL_UNGUELTIG');
  if(!(REGIONEN as readonly string[]).includes(region))throw new Error('RESIDENZ_REGION_UNGUELTIG');
  const begruendung=clean(input.begruendung,2000);
  // Eine Ausnahme ohne Begruendung ist im Verzeichnis der Verarbeitungstaetigkeiten wertlos -
  // und genau dort wird sie gebraucht.
  if(begruendung.length<20)throw new Error('RESIDENZ_BEGRUENDUNG_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.prepare('INSERT INTO residency_exceptions(id,tenant_id,bestandteil,region,begruendung,gueltig_bis,erteilt_von,erteilt_am) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(tenant_id,bestandteil) DO UPDATE SET region=excluded.region,begruendung=excluded.begruendung,gueltig_bis=excluded.gueltig_bis,erteilt_von=excluded.erteilt_von,erteilt_am=excluded.erteilt_am')
    .bind(id('res_'),tenantId,bestandteil,region,begruendung,clean(input.gueltig_bis,10)||null,auth.userId,ts).run();
  await audit(env.DB,auth.userId,'residency.exception',tenantId,undefined,'residency_exception',bestandteil,{region});
  return{bestandteil,region};
}

/**
 * Wo liegen die Daten wirklich?
 *
 * Aus dem tatsaechlichen Bestand abgeleitet, nicht aus einer gepflegten Liste: eine gepflegte
 * Liste ist am Tag nach dem naechsten Anbieterwechsel falsch. Drei Abfragen fuer alle
 * Bestandteile.
 */
export async function residenzpruefung(env:Env,auth:CoreAuthContext,tenantId:string,heute?:string){
  requireRole(auth,'tenant_admin');
  const zusage=await residenzzusage(env,tenantId);
  const tag=clean(heute,10)||nowIso().slice(0,10);
  const erlaubt=zusage?DECKT[zusage.zugesagte_region]??[]:[];
  const ausnahmen=new Map(((await env.DB.prepare('SELECT bestandteil,region,gueltig_bis,begruendung FROM residency_exceptions WHERE tenant_id=?')
    .bind(tenantId).all<{bestandteil:string;region:string;gueltig_bis:string|null;begruendung:string}>()).results??[]).map(a=>[a.bestandteil,a]));
  // Die KI-Modelle tragen ihre Region selbst; der Rest kommt aus der Plattformkonfiguration.
  const modelle=((await env.DB.prepare('SELECT DISTINCT region FROM ai_models WHERE aktiv=1 AND (tenant_id=? OR tenant_id IS NULL)')
    .bind(tenantId).all<{region:string}>()).results)??[];
  // Die Plattformregion wird nicht geraten, sondern aus den Zusicherungen abgeleitet, die
  // data-residency.ts ohnehin prueft: erst wenn D1 und R2 mit EU-Jurisdiktion belegt sind,
  // ist 'eu' eine Aussage und keine Hoffnung.
  const technisch=dataResidencyStatus(env);
  const belegt=(schluessel:string)=>technisch.checks.find(c=>c.key===schluessel)?.ok===true;

  const zeilen:{bestandteil:string;region:string;zugesagt:boolean;ausnahme:string|null}[]=[];
  const bewerte=(bestandteil:string,region:string)=>{
    const a=ausnahmen.get(bestandteil);
    const gedeckt=erlaubt.includes(region);
    const durchAusnahme=!gedeckt&&!!a&&a.region===region&&(!a.gueltig_bis||a.gueltig_bis>=tag);
    zeilen.push({bestandteil,region,zugesagt:gedeckt||durchAusnahme,ausnahme:durchAusnahme?a!.begruendung:null});
  };
  bewerte('datenbank',belegt('d1_eu')?'eu':'weltweit');
  bewerte('dateien',belegt('r2_eu')?'eu':'weltweit');
  bewerte('sicherung',belegt('backup_eu')?'eu':'weltweit');
  // Fuer den Mailversand behauptet die Plattform ausdruecklich KEINE reine EU-Verarbeitung -
  // das steht so in data-residency.ts. Diese Ehrlichkeit hier zu ueberschreiben waere die
  // teuerste Zeile des ganzen Moduls.
  bewerte('mailversand',belegt('mail_eu')?'eu':'weltweit');
  for(const m of modelle)bewerte('ki',m.region);
  if(!modelle.length)zeilen.push({bestandteil:'ki',region:'—',zugesagt:true,ausnahme:null});
  const verstoesse=zeilen.filter(z=>!z.zugesagt);
  return{zugesagte_region:zusage?.zugesagte_region??null,
    // Ohne Zusage gibt es nichts zu brechen - und das ist die ehrliche Auskunft, keine
    // erfundene Sicherheit.
    hinweis:zusage?null:'RESIDENZ_OHNE_ZUSAGE',
    bestandteile:zeilen,verstoesse,eingehalten:Boolean(zusage)&&!verstoesse.length};
}

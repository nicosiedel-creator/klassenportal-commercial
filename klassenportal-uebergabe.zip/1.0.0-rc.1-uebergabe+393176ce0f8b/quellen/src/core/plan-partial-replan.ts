import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { hasPermission } from './enterprise-access.js';
import { stapelSchreiben } from './learning-operations.js';
import { planningSuggestions } from './planning-constraints.js';
import { id, nowIso, safeString, sha256Text } from './utils.js';

// Nur den betroffenen Bereich neu planen (Master-Spec V2, Block "Planung und Zeit", Luecke Z3).
//
// Die Spec verlangt woertlich "keine unnoetige Zerstoerung bestehender Plaene". Heute gibt es genau
// zwei Knoepfe: den Entwurf automatisch fuellen - oder von Hand jeden Termin anfassen. Faellt ein
// Raum fuer zwei Wochen aus, war die einzige angebotene Antwort, den ganzen Plan noch einmal zu
// erzeugen. Damit verliert die Planung jede Handarbeit der letzten Wochen, und der Kunde merkt es
// erst, wenn drei Klassen fragen, warum ihr Stundenplan anders aussieht.
//
// Dieser Lauf fasst NUR an, was benannt wurde: bestimmte Klassen, bestimmte Raeume, ein bestimmtes
// Zeitfenster. Und er belegt es: ueber alle Termine AUSSERHALB des Umfangs wird vorher und nachher
// ein Fingerabdruck gebildet. Stimmen beide nicht ueberein, sagt das Ergebnis es - statt dass es
// jemand drei Wochen spaeter bemerkt.
//
// Zwei Entscheidungen, die den Unterschied zum Rundumschlag ausmachen:
//   * MINIMALE AENDERUNG. Ist die bisherige Lehrkraft bzw. der bisherige Raum weiterhin frei, bleibt
//     alles, wie es ist. Nur wo die bisherige Zuordnung nicht mehr traegt, wird neu zugeordnet.
//   * KEIN ERSATZ HEISST NICHT LOESCHEN. Findet sich nichts Freies, bleibt der bestehende Termin
//     stehen und wird als "ohne Ersatz" ausgewiesen. Ein geloeschter Termin waere die Zerstoerung,
//     die dieser Lauf verhindern soll.

const MAX_TAGE=120;
const MAX_EINTRAEGE=4000;
// Gemessen wie die Plattform zaehlt: ein Vorschlag kostet drei Abfragen (Teilnehmerzahl, Personen,
// Raeume), hier mit Reserve als vier gefuehrt. Geschrieben wird ausschliesslich gestapelt, ein
// Stapel zaehlt als eine Unteranfrage. Die Plattform laesst 1000 je Aufruf zu; der Lauf hoert
// vorher auf und sagt, wo er fortsetzt.
const ABFRAGE_BUDGET=700,KOSTEN_VORSCHLAG=4;

function admin(auth:CoreAuthContext){return auth.isPlatformAdmin||auth.role==='tenant_admin';}
function requireManage(auth:CoreAuthContext){if(!admin(auth)&&!hasPermission(auth,'courses.manage'))throw new Error('FORBIDDEN_PLANNING_MANAGE');}
function tagSchluessel(v:string){return String(v).slice(0,10);}
function liste(v:unknown,max=200):string[]{return Array.isArray(v)?[...new Set(v.map(x=>safeString(x,120)).filter((x):x is string=>!!x))].slice(0,max):[];}

type Eintrag={id:string;course_id:string;course_name:string;subject_id:string|null;teacher_id:string|null;teacher_name:string|null;
  starts_at:string;ends_at:string;room:string|null;activity_type:string;published_lesson_id:string|null;resource_id:string|null};

function fingerabdruckZeile(e:Eintrag){return [e.id,e.course_id,e.starts_at,e.ends_at,e.teacher_id??'',String(e.room??'').toLowerCase(),e.activity_type,e.subject_id??'',e.resource_id??''].join('|');}
async function fingerabdruck(eintraege:Eintrag[]){return sha256Text([...eintraege].map(fingerabdruckZeile).sort().join('\n'));}

export type Teilumfang={kurse:string[];raeume:string[];von:string;bis:string};
export type Aenderung={entry_id:string;course_name:string;zeitpunkt:string;was:'lehrkraft'|'raum'|'lehrkraft_und_raum'|'neu';vorher:string;nachher:string};

async function ladeLage(env:Env,auth:CoreAuthContext,tenantId:string,planId:string,input:Record<string,unknown>){
  requireManage(auth);
  const von=safeString(input.from,10),bis=safeString(input.to,10);
  if(!von||!bis||!/^\d{4}-\d\d-\d\d$/.test(von)||!/^\d{4}-\d\d-\d\d$/.test(bis)||von>bis)throw new Error('PARTIAL_REPLAN_RANGE_INVALID');
  if(Math.round((Date.parse(`${bis}T00:00:00.000Z`)-Date.parse(`${von}T00:00:00.000Z`))/86400000)+1>MAX_TAGE)throw new Error('PARTIAL_REPLAN_RANGE_TOO_LONG');
  const kurse=liste(input.course_ids),raeume=liste(input.resource_ids),raumNamen=liste(input.rooms).map(x=>x.toLowerCase());
  // Ohne benannten Umfang waere das hier kein Teil-Neuplanen, sondern genau der Rundumschlag, den
  // es ersetzen soll. Deshalb ist der Umfang Pflicht und nicht optional.
  if(!kurse.length&&!raeume.length&&!raumNamen.length)throw new Error('PARTIAL_REPLAN_SCOPE_REQUIRED');
  for(const k of kurse)if(!admin(auth)&&!auth.courseIds.includes(k))throw new Error('FORBIDDEN_COURSE_SCOPE');

  const plan=await env.DB.prepare('SELECT id,name,starts_on,ends_on,status FROM timetable_plan_versions WHERE tenant_id=? AND id=?').bind(tenantId,planId).first<{id:string;name:string;starts_on:string;ends_on:string;status:string}>();
  if(!plan)throw new Error('TIMETABLE_PLAN_NOT_FOUND');
  if(plan.status==='published'||plan.status==='archived')throw new Error('PARTIAL_REPLAN_PLAN_LOCKED');

  const [eintragZeilen,mittelZeilen,raumZeilen]=await Promise.all([
    env.DB.prepare('SELECT e.id,e.course_id,e.subject_id,e.teacher_id,e.starts_at,e.ends_at,e.room,e.activity_type,e.published_lesson_id,c.name course_name,t.name teacher_name FROM timetable_plan_entries e JOIN courses c ON c.id=e.course_id AND c.tenant_id=e.tenant_id LEFT JOIN teachers t ON t.id=e.teacher_id AND t.tenant_id=e.tenant_id WHERE e.tenant_id=? AND e.plan_id=? ORDER BY e.starts_at,e.id LIMIT ?').bind(tenantId,planId,MAX_EINTRAEGE+1).all<Record<string,unknown>>(),
    env.DB.prepare('SELECT entry_id,resource_id FROM timetable_plan_entry_resources WHERE tenant_id=? AND plan_id=?').bind(tenantId,planId).all<Record<string,unknown>>(),
    env.DB.prepare("SELECT id,name,code FROM planning_resources WHERE tenant_id=? AND resource_type='room' LIMIT 500").bind(tenantId).all<Record<string,unknown>>(),
  ]);
  const roh=eintragZeilen.results??[];
  if(roh.length>MAX_EINTRAEGE)throw new Error('PARTIAL_REPLAN_PLAN_TOO_LARGE');
  const mittelJeTermin=new Map<string,string>();
  for(const m of mittelZeilen.results??[])if(!mittelJeTermin.has(String(m.entry_id)))mittelJeTermin.set(String(m.entry_id),String(m.resource_id));
  const raumNachId=new Map<string,{id:string;name:string;code:string}>();
  for(const r of raumZeilen.results??[])raumNachId.set(String(r.id),{id:String(r.id),name:String(r.name??''),code:String(r.code??'')});
  const raumNachSchluessel=new Map<string,string>();
  for(const r of raumNachId.values()){if(r.name)raumNachSchluessel.set(r.name.toLowerCase(),r.id);if(r.code)raumNachSchluessel.set(r.code.toLowerCase(),r.id);}

  const eintraege:Eintrag[]=roh.map(z=>({
    id:String(z.id),course_id:String(z.course_id),course_name:String(z.course_name??''),
    subject_id:z.subject_id===null||z.subject_id===undefined?null:String(z.subject_id),
    teacher_id:z.teacher_id===null||z.teacher_id===undefined?null:String(z.teacher_id),
    teacher_name:z.teacher_name===null||z.teacher_name===undefined?null:String(z.teacher_name),
    starts_at:String(z.starts_at),ends_at:String(z.ends_at),
    room:z.room===null||z.room===undefined?null:String(z.room),
    activity_type:String(z.activity_type??'classroom'),
    published_lesson_id:z.published_lesson_id===null||z.published_lesson_id===undefined?null:String(z.published_lesson_id),
    resource_id:mittelJeTermin.get(String(z.id))||raumNachSchluessel.get(String(z.room??'').toLowerCase())||null,
  }));

  const imUmfang=(e:Eintrag)=>{
    const tag=tagSchluessel(e.starts_at);
    if(tag<von||tag>bis)return false;
    if(kurse.length&&kurse.includes(e.course_id))return true;
    if(raeume.length&&e.resource_id&&raeume.includes(e.resource_id))return true;
    if(raumNamen.length&&raumNamen.includes(String(e.room??'').toLowerCase()))return true;
    return false;
  };
  const betroffen=eintraege.filter(imUmfang),ausserhalb=eintraege.filter(e=>!imUmfang(e));
  return{plan,von,bis,kurse,raeume,raumNamen,eintraege,betroffen,ausserhalb,raumNachId,raumNachSchluessel};
}

/** Was der Lauf anfassen wuerde - ohne etwas zu schreiben. */
export async function teilNeuPlanenVorschau(env:Env,auth:CoreAuthContext,tenantId:string,planId:string,input:Record<string,unknown>){
  const lage=await ladeLage(env,auth,tenantId,planId,input);
  const veroeffentlicht=lage.betroffen.filter(e=>e.published_lesson_id).length;
  return{
    plan_id:planId,plan_name:String(lage.plan.name),von:lage.von,bis:lage.bis,
    umfang:{kurse:lage.kurse,raeume:lage.raeume,raumnamen:lage.raumNamen},
    im_umfang:lage.betroffen.length,
    ausserhalb_unveraendert:lage.ausserhalb.length,
    ausserhalb_pruefsumme:await fingerabdruck(lage.ausserhalb),
    bereits_veroeffentlicht:veroeffentlicht,
    betroffene_klassen:[...new Set(lage.betroffen.map(e=>e.course_name))].slice(0,50),
    beispiele:lage.betroffen.slice(0,40).map(e=>({entry_id:e.id,text:`${e.course_name} am ${tagSchluessel(e.starts_at)} ${String(e.starts_at).slice(11,16)} Uhr${e.room?` (${e.room})`:''}${e.teacher_name?` · ${e.teacher_name}`:''}`})),
    hinweis:'Angefasst werden ausschließlich die hier gezählten Termine. Alles andere im Entwurf bleibt unverändert; die Prüfsumme über die übrigen Termine wird nach dem Lauf erneut gebildet und verglichen.',
  };
}

/**
 * Der Lauf selbst.
 *
 * Je Termin im Umfang genau ein Vorschlag (drei Abfragen). Geschrieben wird am Ende gestapelt.
 * Damit zwei Termine desselben Laufs nicht dieselbe freie Person oder denselben freien Raum
 * bekommen, fuehrt der Lauf eine eigene Belegung im Speicher mit - die Datenbank weiss von den
 * Entscheidungen dieses Laufs ja noch nichts.
 */
export async function teilNeuPlanen(env:Env,auth:CoreAuthContext,tenantId:string,planId:string,input:Record<string,unknown>){
  const lage=await ladeLage(env,auth,tenantId,planId,input);
  if(!lage.betroffen.length)throw new Error('PARTIAL_REPLAN_NOTHING_IN_SCOPE');
  const vorher=await fingerabdruck(lage.ausserhalb);
  const ts=nowIso(),anweisungen:unknown[]=[],aenderungen:Aenderung[]=[];
  const belegtDozent=new Map<string,Array<{von:string;bis:string}>>(),belegtRaum=new Map<string,Array<{von:string;bis:string}>>();
  const merken=(m:Map<string,Array<{von:string;bis:string}>>,k:string,von:string,bis:string)=>{const l=m.get(k);if(l)l.push({von,bis});else m.set(k,[{von,bis}]);};
  const kollidiert=(m:Map<string,Array<{von:string;bis:string}>>,k:string,von:string,bis:string)=>(m.get(k)??[]).some(b=>von<b.bis&&b.von<bis);
  // Die Zuordnungen, die es schon gibt, gelten auch fuer diesen Lauf als belegt - sonst bekaeme der
  // zweite Termin denselben Raum wie der erste, nur weil die Datenbank ihn noch als frei fuehrt.
  for(const e of lage.eintraege){if(e.teacher_id)merken(belegtDozent,e.teacher_id,e.starts_at,e.ends_at);if(e.resource_id)merken(belegtRaum,e.resource_id,e.starts_at,e.ends_at);}
  const freigeben=(m:Map<string,Array<{von:string;bis:string}>>,k:string,von:string,bis:string)=>{const l=m.get(k);if(!l)return;const i=l.findIndex(b=>b.von===von&&b.bis===bis);if(i>=0)l.splice(i,1);};

  let budget=0,geprueft=0,neuZugeordnet=0,unveraendert=0,ohneErsatz=0,fortsetzenAb='';
  const fortsetzen=safeString(input.resume_after,40)||'';
  const zuPruefen=lage.betroffen.filter(e=>!fortsetzen||e.starts_at>fortsetzen);
  for(const e of zuPruefen){const vorschlag=budget+KOSTEN_VORSCHLAG>ABFRAGE_BUDGET?null:await planningSuggestions(env,auth,tenantId,{course_id:e.course_id,subject_id:e.subject_id,starts_at:e.starts_at,ends_at:e.ends_at});
    if(!vorschlag){fortsetzenAb=e.starts_at;break;}
    budget+=KOSTEN_VORSCHLAG;geprueft++;
    // Die eigene Zuordnung zaehlt fuer diesen Termin nicht als Belegung.
    if(e.teacher_id)freigeben(belegtDozent,e.teacher_id,e.starts_at,e.ends_at);
    if(e.resource_id)freigeben(belegtRaum,e.resource_id,e.starts_at,e.ends_at);
    const personen=(vorschlag.teachers as Array<Record<string,unknown>>).filter(t=>!kollidiert(belegtDozent,String(t.id),e.starts_at,e.ends_at));
    const raeume=(vorschlag.rooms as Array<Record<string,unknown>>).filter(r=>!kollidiert(belegtRaum,String(r.id),e.starts_at,e.ends_at));
    // MINIMALE AENDERUNG: traegt die bisherige Zuordnung noch, bleibt sie. Nur was nicht mehr
    // moeglich ist, wird ersetzt.
    const personBleibt=e.teacher_id&&personen.some(t=>String(t.id)===e.teacher_id)?e.teacher_id:null;
    const raumBleibt=e.resource_id&&raeume.some(r=>String(r.id)===e.resource_id)?e.resource_id:null;
    const neuePerson=personBleibt?null:(personen[0]?String(personen[0].id):null);
    const neuerRaum=raumBleibt?null:(raeume[0]?String(raeume[0].id):null);
    const personId=personBleibt||neuePerson,raumId=raumBleibt||neuerRaum;
    if((!personId&&e.teacher_id)||(!raumId&&e.resource_id))ohneErsatz++;
    if(!neuePerson&&!neuerRaum){
      unveraendert++;
      if(personId)merken(belegtDozent,personId,e.starts_at,e.ends_at);
      if(raumId)merken(belegtRaum,raumId,e.starts_at,e.ends_at);
      continue;
    }
    const raumZeile=raumId?lage.raumNachId.get(raumId):undefined;
    const raumName=neuerRaum?String((raeume.find(r=>String(r.id)===neuerRaum)?.name)||raumZeile?.name||e.room||''):e.room;
    const personName=neuePerson?String(personen.find(t=>String(t.id)===neuePerson)?.name||''):e.teacher_name||'';
    anweisungen.push(env.DB.prepare('UPDATE timetable_plan_entries SET teacher_id=?,room=?,updated_at=? WHERE tenant_id=? AND plan_id=? AND id=?').bind(personId,raumName,ts,tenantId,planId,e.id));
    if(neuerRaum){
      anweisungen.push(env.DB.prepare('DELETE FROM timetable_plan_entry_resources WHERE tenant_id=? AND entry_id=?').bind(tenantId,e.id));
      anweisungen.push(env.DB.prepare('INSERT INTO timetable_plan_entry_resources(tenant_id,plan_id,entry_id,resource_id,quantity,created_by,created_at) VALUES(?,?,?,?,1,?,?)').bind(tenantId,planId,e.id,neuerRaum,auth.userId,ts));
    }
    aenderungen.push({entry_id:e.id,course_name:e.course_name,zeitpunkt:`${tagSchluessel(e.starts_at)} ${String(e.starts_at).slice(11,16)}`,
      was:neuePerson&&neuerRaum?'lehrkraft_und_raum':neuePerson?'lehrkraft':'raum',
      vorher:`${e.teacher_name||'ohne Lehrkraft'} · ${e.room||'ohne Raum'}`,
      nachher:`${personName||'ohne Lehrkraft'} · ${raumName||'ohne Raum'}`});
    neuZugeordnet++;
    if(personId)merken(belegtDozent,personId,e.starts_at,e.ends_at);
    if(raumId)merken(belegtRaum,raumId,e.starts_at,e.ends_at);
  }
  await stapelSchreiben(env,anweisungen);

  // NACHKONTROLLE. Der Fingerabdruck ueber alle Termine ausserhalb des Umfangs muss derselbe sein
  // wie vor dem Lauf. Ohne diese Zahl waere "nur der betroffene Bereich" eine Behauptung.
  const nachZeilen=await env.DB.prepare('SELECT e.id,e.course_id,e.subject_id,e.teacher_id,e.starts_at,e.ends_at,e.room,e.activity_type,e.published_lesson_id,c.name course_name,pr.resource_id FROM timetable_plan_entries e JOIN courses c ON c.id=e.course_id AND c.tenant_id=e.tenant_id LEFT JOIN timetable_plan_entry_resources pr ON pr.tenant_id=e.tenant_id AND pr.entry_id=e.id WHERE e.tenant_id=? AND e.plan_id=? ORDER BY e.starts_at,e.id LIMIT ?').bind(tenantId,planId,MAX_EINTRAEGE+1).all<Record<string,unknown>>();
  const nachher:Eintrag[]=(nachZeilen.results??[]).map(z=>({
    id:String(z.id),course_id:String(z.course_id),course_name:String(z.course_name??''),
    subject_id:z.subject_id===null||z.subject_id===undefined?null:String(z.subject_id),
    teacher_id:z.teacher_id===null||z.teacher_id===undefined?null:String(z.teacher_id),teacher_name:null,
    starts_at:String(z.starts_at),ends_at:String(z.ends_at),
    room:z.room===null||z.room===undefined?null:String(z.room),
    activity_type:String(z.activity_type??'classroom'),
    published_lesson_id:z.published_lesson_id===null||z.published_lesson_id===undefined?null:String(z.published_lesson_id),
    resource_id:z.resource_id===null||z.resource_id===undefined?null:String(z.resource_id),
  }));
  const imUmfangIds=new Set(lage.betroffen.map(e=>e.id));
  const ausserhalbNachher=nachher.filter(e=>!imUmfangIds.has(e.id));
  const jetzt=await fingerabdruck(ausserhalbNachher);
  const abweichungen:Array<{feld:string;erwartet:number|string;gefunden:number|string}>=[];
  if(ausserhalbNachher.length!==lage.ausserhalb.length)abweichungen.push({feld:'anzahl_ausserhalb',erwartet:lage.ausserhalb.length,gefunden:ausserhalbNachher.length});
  if(jetzt!==vorher)abweichungen.push({feld:'pruefsumme_ausserhalb',erwartet:vorher.slice(0,16),gefunden:jetzt.slice(0,16)});
  const nachkontrolle=abweichungen.length?'abweichungen':'bestanden';

  await audit(env.DB,auth.userId,'planning.partial_replanned',tenantId,undefined,'timetable_plan',planId,
    {von:lage.von,bis:lage.bis,kurse:lage.kurse.length,raeume:lage.raeume.length+lage.raumNamen.length,
     im_umfang:lage.betroffen.length,neu_zugeordnet:neuZugeordnet,unveraendert,ohne_ersatz:ohneErsatz,
     ausserhalb_unveraendert:ausserhalbNachher.length,nachkontrolle});

  return{plan_id:planId,plan_name:String(lage.plan.name),von:lage.von,bis:lage.bis,
    umfang:{kurse:lage.kurse,raeume:lage.raeume,raumnamen:lage.raumNamen},
    im_umfang:lage.betroffen.length,geprueft,neu_zugeordnet:neuZugeordnet,
    unveraendert_im_umfang:unveraendert,ohne_ersatz:ohneErsatz,
    ausserhalb_unveraendert:ausserhalbNachher.length,
    ausserhalb_pruefsumme_vorher:vorher,ausserhalb_pruefsumme_nachher:jetzt,
    nachkontrolle,abweichungen,
    limit_reached:Boolean(fortsetzenAb),resume_after:fortsetzenAb||null,
    aenderungen:aenderungen.slice(0,200)};
}

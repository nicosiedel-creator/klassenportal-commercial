import type { CoreAuthContext, Env } from './types.js';
import { DATENKLASSEN, FAEHIGKEITEN, frageKi, modellkette } from './ai-gateway.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString, sha256Text } from './utils.js';

// Leistung durch Bauart, nicht durch Hoffnung.
//
// Drei Befunde standen am Anfang, und alle drei waren keine Geschmacksfragen:
//
// 1. KEINE EINSTUFUNG. Jede KI-Funktion lief sofort und im Vordergrund. Die Entwurfsfabrik rief
//    bis zu fuenf Modelle nacheinander auf, waehrend ein Mensch vor dem Ladebalken sass.
// 2. KEINE WIEDERVERWENDUNG. Der Eingabehash wurde protokolliert, aber nie nachgeschlagen -
//    dieselbe Frage zur selben Grundlage wurde jedes Mal neu bezahlt und jedes Mal anders
//    beantwortet.
// 3. DIE DATENKLASSE KAM VOM AUFRUFER. Wer 'oeffentlich' hineinschrieb, bekam ein Modell
//    ausserhalb der EU, auch wenn im Auftrag Namen standen.
//
// Die Antwort auf alle drei ist dieses Register. Es ist FAIL CLOSED: ein Zweck, der hier nicht
// steht, wird nicht ausgefuehrt. Das ist unbequem - genau deshalb wirkt es. Eine Vorgabe
// ("im Zweifel sofort, im Zweifel oeffentlich") waere die Regel, die sich beim ersten Zeitdruck
// selbst aushebelt.

export const VERARBEITUNGSARTEN=['sofort','hintergrund','freigabe'] as const;
export type Verarbeitungsart=(typeof VERARBEITUNGSARTEN)[number];

export interface Zweckprofil{
  /**
   * sofort      - der Mensch wartet darauf, und das ist vertretbar: eine Anfrage, kurze Antwort.
   * hintergrund - laeuft als Auftrag mit Fortschritt; die Oberflaeche wartet NIE darauf.
   * freigabe    - laeuft im Hintergrund UND darf erst nach Freigabe durch einen Menschen wirken.
   */
  verarbeitung:Verarbeitungsart;
  faehigkeit:'text'|'vision'|'einbettung';
  /** Die Klasse kommt aus dem Register, nie aus dem Aufruf. Das ist der Kern des Ganzen. */
  datenklasse:'oeffentlich'|'intern'|'personenbezogen'|'besonders';
  /** Darf ein frueheres Ergebnis zu derselben Eingabe wiederverwendet werden? */
  wiederverwendbar:boolean;
  /** Wie lange ein wiederverwendbares Ergebnis gilt. 0 = altert nicht. */
  gueltig_tage:number;
  /** Obergrenze je Aufruf. Darueber wird nicht ausgefuehrt, sondern gemeldet. */
  hoechstkosten_cent:number;
  /** Warum diese Einstufung - fuer den, der sie spaeter anzweifelt. */
  grund:string;
}

/**
 * Das Register. Schluessel ohne Doppelpunkt sind ganze Zwecke, Schluessel MIT abschliessendem
 * Doppelpunkt decken eine Familie ab ('fabrik:' deckt 'fabrik:quizfrage').
 */
export const KI_ZWECKE:Record<string,Zweckprofil>={
  // Die Entwurfsfabrik. Hintergrund, weil sie bis zu fuenf Modelle nacheinander aufruft, und
  // Freigabe, weil aus einem Entwurf eine Pruefungsfrage werden kann: was die Maschine geschrieben
  // hat, wird von einem Menschen angesehen, bevor es zaehlt.
  'fabrik:':{verarbeitung:'freigabe',faehigkeit:'text',datenklasse:'intern',wiederverwendbar:true,gueltig_tage:180,
    hoechstkosten_cent:50,
    grund:'Erzeugt Unterrichtsmaterial aus Lernfeldern und Kompetenzen - keine Personendaten, aber Hausinterna. Wiederverwendbar: dasselbe Lernfeld ergibt dieselbe Aufgabe, und ein halbes Jahr haelt ein Curriculum allemal.'},
  // Die Modellbewertung faehrt bewusst feste, oeffentliche Testfaelle gegen ein Modell. Sie darf
  // NICHT wiederverwenden: sie misst gerade, was ein Modell heute antwortet.
  'eval:':{verarbeitung:'hintergrund',faehigkeit:'text',datenklasse:'oeffentlich',wiederverwendbar:false,gueltig_tage:0,
    hoechstkosten_cent:100,
    grund:'Bewertungslauf ueber eine ganze Fallsammlung - dauert lange und wartet auf niemanden. Keine Wiederverwendung: gemessen wird, was das Modell HEUTE antwortet.'},
};

/** Die Einstufung zu einem Zweck - oder nichts. Nichts heisst: wird nicht ausgefuehrt. */
export function zweckprofil(zweck:string):Zweckprofil|null{
  const z=safeString(zweck,80);
  if(KI_ZWECKE[z])return KI_ZWECKE[z];
  const doppelpunkt=z.indexOf(':');
  if(doppelpunkt>0){const familie=z.slice(0,doppelpunkt+1);if(KI_ZWECKE[familie])return KI_ZWECKE[familie];}
  return null;
}

function fordereProfil(zweck:string){
  const p=zweckprofil(zweck);
  if(!p)throw new Error('KI_ZWECK_NICHT_EINGESTUFT');
  return p;
}

// ---------------------------------------------------------------------------------------------
// Wiederverwendung
// ---------------------------------------------------------------------------------------------

export interface Wiederverwendet{
  id:string;text:string;anbieter:string;modell:string;fassung:number;erzeugt_am:string;
  kosten_cent:number;treffer:number;
}

/**
 * Das neueste gueltige Ergebnis zu derselben Frage.
 *
 * Gesucht wird ueber (Mandant, Zweck, Eingabehash) - nie ueber den Klartext. Das ist nicht nur
 * schneller: der Klartext einer Eingabe kann Personendaten enthalten, der Hash nicht.
 */
export async function findeWiederverwendbares(env:Env,tenantId:string,zweck:string,eingabeHash:string,jetzt=nowIso()):Promise<Wiederverwendet|null>{
  const p=zweckprofil(zweck);
  if(!p?.wiederverwendbar)return null;
  const z=await env.DB.prepare(`SELECT id,text,anbieter,modell,fassung,erzeugt_am,kosten_cent,treffer FROM ai_results
    WHERE tenant_id=? AND zweck=? AND eingabe_hash=? AND (gueltig_bis IS NULL OR gueltig_bis>?)
    ORDER BY fassung DESC LIMIT 1`).bind(tenantId,safeString(zweck,80),eingabeHash,jetzt)
    .first<Wiederverwendet>();
  return z??null;
}

async function haltErgebnisFest(env:Env,tenantId:string,zweck:string,eingabeHash:string,
  d:{text:string;anbieter:string;modell:string;invocation_id:string;kosten_cent:number},jetzt=nowIso()){
  const p=fordereProfil(zweck);
  if(!p.wiederverwendbar)return null;
  const letzte=await env.DB.prepare('SELECT MAX(fassung) f FROM ai_results WHERE tenant_id=? AND zweck=? AND eingabe_hash=?')
    .bind(tenantId,safeString(zweck,80),eingabeHash).first<{f:number|null}>();
  const fassung=Number(letzte?.f??0)+1;
  const ergebnisId=id('kir_');
  const gueltig=p.gueltig_tage>0?new Date(new Date(jetzt).getTime()+p.gueltig_tage*86400000).toISOString():null;
  await env.DB.prepare(`INSERT INTO ai_results(id,tenant_id,zweck,eingabe_hash,fassung,text,anbieter,modell,invocation_id,kosten_cent,erzeugt_am,gueltig_bis)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(ergebnisId,tenantId,safeString(zweck,80),eingabeHash,fassung,d.text,d.anbieter,d.modell,d.invocation_id,d.kosten_cent,jetzt,gueltig).run();
  return{id:ergebnisId,fassung};
}

// ---------------------------------------------------------------------------------------------
// Kosten VOR der Ausfuehrung
// ---------------------------------------------------------------------------------------------

/** Vier Zeichen je Token - grob, aber in der richtigen Groessenordnung und ohne Zaehlwerk. */
export const ZEICHEN_JE_TOKEN=4;
/** Was eine Antwort hoechstens kostet, wenn niemand sie begrenzt. */
export const ERWARTETE_AUSGABE_TOKEN=1200;

/**
 * Was dieser Aufruf voraussichtlich kostet - vor dem ersten Byte nach draussen.
 *
 * Der Kostenwaechter kennt nur das Monatsbudget. Er faengt den Aufruf, der das Budget sprengt,
 * aber nicht den einzelnen Auftrag, der fuer sich genommen absurd teuer ist: eine versehentlich
 * mitgeschickte 300-Seiten-Datei kostet einmal so viel wie ein Monat normaler Nutzung und ist
 * beim Kostenwaechter trotzdem "im Rahmen".
 */
export async function kostenschaetzung(env:Env,tenantId:string|null,zweck:string,eingabe:string){
  const p=fordereProfil(zweck);
  const kette=await modellkette(env,tenantId,p.faehigkeit,p.datenklasse);
  const eingabeToken=Math.ceil(String(eingabe).length/ZEICHEN_JE_TOKEN);
  const erste=kette[0];
  const cent=erste
    ?Math.ceil(eingabeToken/1000*Number(erste.kosten_je_1k_eingabe_cent||0)
      +ERWARTETE_AUSGABE_TOKEN/1000*Number(erste.kosten_je_1k_ausgabe_cent||0))
    :0;
  return{eingabe_token:eingabeToken,erwartete_ausgabe_token:ERWARTETE_AUSGABE_TOKEN,
    kosten_cent:cent,hoechstkosten_cent:p.hoechstkosten_cent,modelle:kette.length,
    im_rahmen:cent<=p.hoechstkosten_cent};
}

// ---------------------------------------------------------------------------------------------
// Der gesteuerte Aufruf
// ---------------------------------------------------------------------------------------------

export interface GesteuerteAntwort{
  text:string;anbieter:string;modell:string;invocation_id:string|null;
  kosten_cent:number;wiederverwendet:boolean;fassung:number;eingabe_hash:string;
}

/**
 * Der einzige Weg zur KI, den Fachmodule benutzen duerfen.
 *
 * Reihenfolge, und sie ist nicht beliebig:
 *   1. Einstufung holen - ohne sie laeuft nichts.
 *   2. Vorhandenes Ergebnis suchen. Der billigste Aufruf ist der, der nicht stattfindet.
 *   3. Hintergrundzwecke abweisen, wenn sie aus einem wartenden Aufruf kommen.
 *   4. Kosten schaetzen und gegen die Obergrenze halten.
 *   5. Erst dann hinaus - mit Faehigkeit und Datenklasse AUS DEM REGISTER.
 */
export async function frageKiGesteuert(env:Env,tenantId:string,auftrag:{zweck:string;eingabe:string;akteur?:string;imHintergrund?:boolean}):Promise<GesteuerteAntwort>{
  const zweck=safeString(auftrag.zweck,80);
  const p=fordereProfil(zweck);
  const eingabe=String(auftrag.eingabe??'');
  if(!eingabe.trim())throw new Error('KI_EINGABE_ERFORDERLICH');
  const eingabeHash=await sha256Text(eingabe);

  const vorhanden=await findeWiederverwendbares(env,tenantId,zweck,eingabeHash);
  if(vorhanden){
    await env.DB.prepare('UPDATE ai_results SET treffer=treffer+1,letzter_treffer=? WHERE id=?').bind(nowIso(),vorhanden.id).run();
    return{text:vorhanden.text,anbieter:vorhanden.anbieter,modell:vorhanden.modell,invocation_id:null,
      kosten_cent:0,wiederverwendet:true,fassung:Number(vorhanden.fassung),eingabe_hash:eingabeHash};
  }

  // Ein Hintergrundzweck aus einem wartenden Aufruf heraus ist der Fehler, gegen den die
  // Einstufung gebaut ist. Er wird gemeldet und nicht "ausnahmsweise" doch ausgefuehrt.
  if(p.verarbeitung!=='sofort'&&!auftrag.imHintergrund)throw new Error('KI_NUR_IM_HINTERGRUND');

  const schaetzung=await kostenschaetzung(env,tenantId,zweck,eingabe);
  if(!schaetzung.im_rahmen)throw new Error('KI_KOSTEN_ZU_HOCH');

  const antwort=await frageKi(env,tenantId,{zweck,faehigkeit:p.faehigkeit,datenklasse:p.datenklasse,eingabe,akteur:auftrag.akteur});
  const abgelegt=await haltErgebnisFest(env,tenantId,zweck,eingabeHash,
    {text:antwort.text,anbieter:antwort.anbieter,modell:antwort.modell,invocation_id:antwort.invocation_id,kosten_cent:antwort.kosten_cent});
  return{text:antwort.text,anbieter:antwort.anbieter,modell:antwort.modell,invocation_id:antwort.invocation_id,
    kosten_cent:antwort.kosten_cent,wiederverwendet:false,fassung:abgelegt?.fassung??1,eingabe_hash:eingabeHash};
}

// ---------------------------------------------------------------------------------------------
// Auftraege statt Wartezimmer
// ---------------------------------------------------------------------------------------------

/** Nach so langer Stille gilt ein laufender Auftrag als abgestuerzt und wird neu aufgenommen. */
export const PULS_GRENZE_MINUTEN=10;
/** Wie viele Auftraege ein Lauf hoechstens anfasst - das Unteranfragenbudget teilt sich alles. */
export const AUFTRAEGE_JE_LAUF=3;

export interface Auftragsstand{
  id:string;zweck:string;status:string;fortschritt:number;schritt:string|null;
  versuche:number;max_versuche:number;letzter_fehler:string|null;
  wiederverwendet:boolean;ergebnis:unknown;created_at:string;fertig_am:string|null;
}

/**
 * Einen Auftrag einstellen - oder sofort liefern, wenn die Antwort schon dasteht.
 *
 * Der zweite Fall ist der haeufigere und der wichtigere: wer dieselbe Zusammenfassung zum zweiten
 * Mal anfordert, soll keinen Auftrag bekommen, sondern das Ergebnis.
 */
export async function stelleKiAuftragEin(env:Env,auth:CoreAuthContext,tenantId:string,eingabe:{zweck:string;eingabe:string;ziel_typ?:string|null;ziel_id?:string|null;teile?:number}){
  requireRole(auth,'class_admin');
  const zweck=safeString(eingabe.zweck,80);
  const p=fordereProfil(zweck);
  const text=String(eingabe.eingabe??'');
  if(!text.trim())throw new Error('KI_EINGABE_ERFORDERLICH');
  const eingabeHash=await sha256Text(text);

  const vorhanden=await findeWiederverwendbares(env,tenantId,zweck,eingabeHash);
  if(vorhanden){
    await env.DB.prepare('UPDATE ai_results SET treffer=treffer+1,letzter_treffer=? WHERE id=?').bind(nowIso(),vorhanden.id).run();
    return{status:'fertig',wiederverwendet:true,fortschritt:100,
      ergebnis:{text:vorhanden.text,anbieter:vorhanden.anbieter,modell:vorhanden.modell,fassung:Number(vorhanden.fassung)},
      job_id:null,verarbeitung:p.verarbeitung};
  }

  // Die Schaetzung sagt schon hier Nein, wenn sie Nein sagen muss. Einen Auftrag anzulegen, der
  // beim ersten Lauf an der Kostengrenze scheitert, waere ein Fortschrittsbalken bis zum Fehler.
  const schaetzung=await kostenschaetzung(env,tenantId,zweck,text);
  if(!schaetzung.im_rahmen)throw new Error('KI_KOSTEN_ZU_HOCH');

  const jobId=id('kij_'),ts=nowIso();
  const teile=Math.max(1,Math.min(20,Math.trunc(Number(eingabe.teile??1))||1));
  await env.DB.prepare(`INSERT INTO ai_jobs(id,tenant_id,zweck,eingabe,eingabe_hash,ziel_typ,ziel_id,status,fortschritt,schritt,teile,angefordert_von,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,'offen',0,?,?,?,?,?)`)
    .bind(jobId,tenantId,zweck,text,eingabeHash,safeString(eingabe.ziel_typ,60)||null,safeString(eingabe.ziel_id,120)||null,
      'wartet auf den naechsten Lauf',teile,auth.userId,ts,ts).run();
  return{status:'offen',wiederverwendet:false,fortschritt:0,ergebnis:null,job_id:jobId,
    verarbeitung:p.verarbeitung,kosten_schaetzung_cent:schaetzung.kosten_cent};
}

/** Wie weit ist mein Auftrag? Die Frage, die eine Oberflaeche beantworten koennen muss. */
export async function kiAuftragStand(env:Env,auth:CoreAuthContext,tenantId:string,jobId:string):Promise<Auftragsstand>{
  requireRole(auth,'class_admin');
  const z=await env.DB.prepare(`SELECT id,zweck,status,fortschritt,schritt,versuche,max_versuche,letzter_fehler,wiederverwendet,ergebnis_json,created_at,fertig_am
    FROM ai_jobs WHERE tenant_id=? AND id=?`).bind(tenantId,safeString(jobId,120)).first<Record<string,unknown>>();
  if(!z)throw new Error('KI_AUFTRAG_NICHT_GEFUNDEN');
  let ergebnis:unknown=null;
  try{ergebnis=z.ergebnis_json?JSON.parse(String(z.ergebnis_json)):null;}catch{ergebnis=null;}
  return{id:String(z.id),zweck:String(z.zweck),status:String(z.status),fortschritt:Number(z.fortschritt??0),
    schritt:z.schritt===null||z.schritt===undefined?null:String(z.schritt),
    versuche:Number(z.versuche??0),max_versuche:Number(z.max_versuche??3),
    letzter_fehler:z.letzter_fehler===null||z.letzter_fehler===undefined?null:String(z.letzter_fehler),
    wiederverwendet:Number(z.wiederverwendet??0)===1,ergebnis,
    created_at:String(z.created_at),fertig_am:z.fertig_am===null||z.fertig_am===undefined?null:String(z.fertig_am)};
}

/** Die Auftragsmappe eines Mandanten - was laeuft, was haengt, was fertig ist. */
export async function kiAuftragsmappe(env:Env,auth:CoreAuthContext,tenantId:string,grenze=50){
  requireRole(auth,'class_admin');
  return ((await env.DB.prepare(`SELECT id,zweck,status,fortschritt,schritt,versuche,max_versuche,letzter_fehler,wiederverwendet,created_at,fertig_am
    FROM ai_jobs WHERE tenant_id=? ORDER BY created_at DESC LIMIT ?`)
    .bind(tenantId,Math.max(1,Math.min(200,grenze))).all<Record<string,unknown>>()).results)??[];
}

export async function brichKiAuftragAb(env:Env,auth:CoreAuthContext,tenantId:string,jobId:string){
  requireRole(auth,'class_admin');
  const ts=nowIso();
  const r=await env.DB.prepare(`UPDATE ai_jobs SET status='abgebrochen',schritt='von Hand abgebrochen',updated_at=?
    WHERE tenant_id=? AND id=? AND status IN ('offen','laeuft','fehler')`).bind(ts,tenantId,safeString(jobId,120)).run();
  if(!r.meta?.changes)throw new Error('KI_AUFTRAG_NICHT_GEFUNDEN');
  return{status:'abgebrochen'};
}

/**
 * Der Lauf. Nimmt offene Auftraege und die, deren Puls stehen geblieben ist.
 *
 * Die zweite Haelfte ist die Wiederaufnahme: ein Auftrag, der in 'laeuft' steht und sich seit
 * zehn Minuten nicht geruehrt hat, hat seinen Lauf nicht ueberlebt - der Aufruf wurde beendet,
 * der Anbieter haengt, der Worker ist neu gestartet. Ohne diese Regel bliebe er fuer immer bei
 * 47 Prozent stehen, und niemand koennte sagen, warum.
 */
export async function arbeiteKiAuftraegeAb(env:Env,grenze=AUFTRAEGE_JE_LAUF,jetzt=nowIso()){
  const tot=new Date(new Date(jetzt).getTime()-PULS_GRENZE_MINUTEN*60000).toISOString();
  const auftraege=((await env.DB.prepare(`SELECT id,tenant_id,zweck,eingabe,eingabe_hash,versuche,max_versuche,angefordert_von,status,ziel_typ,ziel_id,fertige_teile,teile
    FROM ai_jobs WHERE status='offen' OR (status='laeuft' AND COALESCE(puls_am,created_at)<?)
    ORDER BY created_at LIMIT ?`).bind(tot,Math.max(1,Math.min(20,grenze)))
    .all<{id:string;tenant_id:string;zweck:string;eingabe:string;eingabe_hash:string;versuche:number;max_versuche:number;angefordert_von:string;status:string;ziel_typ:string|null;ziel_id:string|null;fertige_teile:number;teile:number}>()).results)??[];
  let fertig=0,gescheitert=0,wiederaufgenommen=0;
  for(const a of auftraege){
    if(a.status==='laeuft')wiederaufgenommen++;
    const start=nowIso();
    await env.DB.prepare(`UPDATE ai_jobs SET status='laeuft',fortschritt=MAX(fortschritt,5),schritt=?,
      gestartet_am=COALESCE(gestartet_am,?),puls_am=?,updated_at=? WHERE id=?`)
      .bind(a.status==='laeuft'?'wieder aufgenommen':'laeuft',start,start,start,a.id).run();
    try{
      const lauf=laufZuZweck(a.zweck);
      let ergebnis:unknown=null,wiederverwendet=false;
      if(lauf){
        // Ein Lauf in Haeppchen. Er meldet selbst, wie weit er ist.
        const melde:Laufschritt=async (fortschritt,schritt,fertigeTeile)=>{
          await env.DB.prepare('UPDATE ai_jobs SET fortschritt=?,schritt=?,fertige_teile=COALESCE(?,fertige_teile),puls_am=?,updated_at=? WHERE id=?')
            .bind(Math.max(0,Math.min(100,Math.round(fortschritt))),safeString(schritt,200),
              fertigeTeile===undefined?null:Math.max(0,Math.trunc(fertigeTeile)),nowIso(),nowIso(),a.id).run();
        };
        const stand=await lauf(env,{id:a.id,tenant_id:a.tenant_id,zweck:a.zweck,eingabe:a.eingabe,
          angefordert_von:a.angefordert_von,fertige_teile:Number(a.fertige_teile??0),teile:Number(a.teile??1)},melde);
        if(!stand.fertig){
          // Noch nicht durch: zurueck in die Warteschlange, Fortschritt bleibt stehen. Das ist
          // kein Fehlversuch und zaehlt auch nicht als einer.
          const weiter=nowIso();
          await env.DB.prepare("UPDATE ai_jobs SET status='offen',schritt=?,puls_am=?,updated_at=? WHERE id=?")
            .bind(safeString(stand.schritt??'macht im naechsten Lauf weiter',200),weiter,weiter,a.id).run();
          continue;
        }
        ergebnis=stand.ergebnis??null;
      }else{
        const antwort=await frageKiGesteuert(env,a.tenant_id,{zweck:a.zweck,eingabe:a.eingabe,akteur:a.angefordert_von,imHintergrund:true});
        // Erst ablegen, dann fertig melden. Andersherum stuende ein Auftrag auf "fertig", waehrend
        // das Ergebnis nirgends angekommen ist - und niemand wuerde es je bemerken.
        if(a.ziel_typ){
          const behandlung=ZIELE[String(a.ziel_typ)];
          if(!behandlung)throw new Error('KI_ZIEL_UNBEKANNT');
          await behandlung(env,a.tenant_id,String(a.ziel_id??''),antwort);
        }
        wiederverwendet=antwort.wiederverwendet;
        ergebnis={text:antwort.text,anbieter:antwort.anbieter,modell:antwort.modell,
          fassung:antwort.fassung,kosten_cent:antwort.kosten_cent};
      }
      const ts=nowIso();
      await env.DB.batch([
        env.DB.prepare(`UPDATE ai_jobs SET status='fertig',fortschritt=100,fertige_teile=teile,schritt='fertig',
          ergebnis_json=?,wiederverwendet=?,letzter_fehler=NULL,puls_am=?,fertig_am=?,updated_at=? WHERE id=?`)
          .bind(JSON.stringify(ergebnis??{}),wiederverwendet?1:0,ts,ts,ts,a.id),
        // Die Benachrichtigung. Sie ist der Grund, warum niemand warten muss: wer den Auftrag
        // gestellt hat, erfaehrt von selbst, dass er fertig ist.
        env.DB.prepare('INSERT INTO automation_events(id,tenant_id,event_type,source_type,source_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)')
          .bind(id('aev_'),a.tenant_id,'ai.job.fertig','ai_job',a.id,
            JSON.stringify({zweck:a.zweck,wiederverwendet,fuer:a.angefordert_von}),ts),
      ]);
      await env.DB.prepare('UPDATE ai_jobs SET benachrichtigt_am=? WHERE id=?').bind(ts,a.id).run();
      fertig++;
    }catch(e){
      // Erst JETZT zaehlt der Versuch. Ihn beim Start hochzuzaehlen haette jede Wiederaufnahme
      // eines Haeppchenlaufs wie einen Fehlschlag aussehen lassen.
      const code=String((e as Error)?.message||'KI_FEHLER').slice(0,80);
      const ts=nowIso(),aufgeben=Number(a.versuche)+1>=Number(a.max_versuche);
      await env.DB.prepare(`UPDATE ai_jobs SET status=?,versuche=versuche+1,schritt=?,letzter_fehler=?,puls_am=?,fertig_am=?,updated_at=? WHERE id=?`)
        .bind(aufgeben?'fehler':'offen',aufgeben?'aufgegeben':`wird erneut versucht (${Number(a.versuche)+1} von ${Number(a.max_versuche)})`,
          code,ts,aufgeben?ts:null,ts,a.id).run();
      if(aufgeben){
        gescheitert++;
        await env.DB.prepare('INSERT INTO automation_events(id,tenant_id,event_type,source_type,source_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)')
          .bind(id('aev_'),a.tenant_id,'ai.job.fehler','ai_job',a.id,JSON.stringify({zweck:a.zweck,fehler:code,fuer:a.angefordert_von}),ts).run();
      }
    }
  }
  return{angefasst:auftraege.length,fertig,gescheitert,wiederaufgenommen};
}

// ---------------------------------------------------------------------------------------------
// Wohin das Ergebnis gehoert
// ---------------------------------------------------------------------------------------------
//
// Der Lauf weiss nichts ueber Entwuerfe, Zeugnisse oder Zusammenfassungen - er soll es auch nicht
// wissen. Ein Fachmodul meldet an, was mit einem fertigen Ergebnis zu geschehen hat; genauso, wie
// sich ein KI-Anbieter beim Gateway anmeldet.

export type Zielbehandlung=(env:Env,tenantId:string,zielId:string,antwort:GesteuerteAntwort)=>Promise<void>;
const ZIELE:Record<string,Zielbehandlung>={};
export function registriereKiZiel(typ:string,behandlung:Zielbehandlung){ZIELE[safeString(typ,60)]=behandlung;}
export function bekannteKiZiele(){return Object.keys(ZIELE).sort();}

/**
 * Manche Auftraege sind nicht EIN Modellaufruf, sondern viele.
 *
 * Ein Bewertungslauf faehrt fuenfzig Testfaelle gegen ein Modell. Als ein Aufruf gedacht waere er
 * entweder ein Zeitlimit oder ein gesprengtes Unteranfragenbudget - ein Worker-Aufruf hat 1000
 * fuer alle Arbeiten zusammen. Deshalb darf ein Lauf in Haeppchen arbeiten: er meldet, wie weit
 * er ist, und sagt, ob er fertig ist. Ist er es nicht, kommt der Auftrag zurueck in die
 * Warteschlange und macht beim naechsten Mal dort weiter, wo er aufgehoert hat - OHNE dass das
 * als Fehlversuch zaehlt.
 */
export interface Laufauftrag{id:string;tenant_id:string;zweck:string;eingabe:string;angefordert_von:string;fertige_teile:number;teile:number}
export type Laufschritt=(fortschritt:number,schritt:string,fertigeTeile?:number)=>Promise<void>;
export type Auftragslauf=(env:Env,auftrag:Laufauftrag,melde:Laufschritt)=>Promise<{fertig:boolean;ergebnis?:unknown;schritt?:string}>;
const LAEUFE:Record<string,Auftragslauf>={};
export function registriereKiLauf(zweck:string,lauf:Auftragslauf){LAEUFE[safeString(zweck,80)]=lauf;}
export function bekannteKiLaeufe(){return Object.keys(LAEUFE).sort();}
function laufZuZweck(zweck:string){
  if(LAEUFE[zweck])return LAEUFE[zweck];
  const d=zweck.indexOf(':');
  return d>0?LAEUFE[zweck.slice(0,d+1)]:undefined;
}

/** Was die Einstufung fuer diesen Mandanten bedeutet - die Uebersicht fuer die Leitung. */
export async function kiEinstufungen(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  const nutzung=((await env.DB.prepare(`SELECT zweck,COUNT(*) fassungen,SUM(treffer) treffer,SUM(kosten_cent) kosten_cent
    FROM ai_results WHERE tenant_id=? GROUP BY zweck`).bind(tenantId).all<{zweck:string;fassungen:number;treffer:number;kosten_cent:number}>()).results)??[];
  const jeZweck=new Map(nutzung.map(n=>[String(n.zweck),n]));
  return Object.entries(KI_ZWECKE).map(([zweck,p])=>{
    const n=jeZweck.get(zweck)??[...jeZweck.entries()].find(([k])=>k.startsWith(zweck))?.[1];
    return{zweck,...p,
      fassungen:Number(n?.fassungen??0),treffer:Number(n?.treffer??0),
      gesparte_aufrufe:Number(n?.treffer??0),kosten_cent:Number(n?.kosten_cent??0)};
  });
}

// Fuer den Vertragstest: die Klassen, die das Register benutzen darf.
export const ERLAUBTE_FAEHIGKEITEN=FAEHIGKEITEN;
export const ERLAUBTE_DATENKLASSEN=DATENKLASSEN;

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Das Qualitaetsmanagementsystem.
//
// Vorhanden war die Massnahme (quality_actions) - das Ende der Kette. Alles davor fehlte: die
// Ziele, an denen gemessen wird, die Prozesse, die Audits, die Managementbewertung und die
// Zertifizierung, an der die Zulassung haengt.
//
// Drei Regeln tragen dieses Modul:
//
//  1. EINE KENNZAHL, DIE JEMAND EINTIPPT, IST KEINE KENNZAHL. Abbruch-, Erfolgs- und
//     Vermittlungsquote werden aus den Foerderfaellen gerechnet, die ohnehin gefuehrt werden.
//     Eine gepflegte Zahl daneben weicht nach dem zweiten Monat ab - und vor der fachkundigen
//     Stelle ist sie wertlos, weil niemand sagen kann, woher sie kommt.
//  2. EINE ABWEICHUNG BRAUCHT EINE MASSNAHME. Das Audit laesst sich nicht abschliessen, solange
//     eine ohne dasteht. Genau daran scheitern Traeger im Ueberwachungsaudit.
//  3. DIE MANAGEMENTBEWERTUNG ZIEHT IHRE EINGABEN SELBST - und friert sie ein. Eine Bewertung
//     muss auch in zwei Jahren noch zeigen, worauf sie sich gestuetzt hat.

const clean=(v:unknown,n=2000)=>safeString(v,n);
export const MESSGROESSEN=['abbruchquote','erfolgsquote','vermittlungsquote','anwesenheitsquote','beschwerdequote','manuell'] as const;
export const PROZESSARTEN=['fuehrung','kern','unterstuetzung'] as const;
export const AUDITARTEN=['intern','extern','zertifizierung','ueberwachung'] as const;
export const EINSTUFUNGEN=['abweichung_schwer','abweichung','beobachtung','chance','konform'] as const;
export const ZERTIFIKATSARTEN=['traegerzulassung','massnahmezulassung','iso9001','anerkennung','sonstiges'] as const;
/** Einstufungen, die ohne Massnahme nicht abgeschlossen werden duerfen. */
export const MASSNAHMEPFLICHTIG=new Set(['abweichung_schwer','abweichung']);
/** Wie lange vor Ablauf eines Zertifikats erinnert wird - drei Monate sind die uebliche Vorlaufzeit fuer ein Ueberwachungsaudit. */
export const ZERTIFIKAT_VORLAUF_TAGE=90;

function datum(v:unknown,feld:string){
  const s=clean(v,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(s))throw new Error(`QM_${feld}_UNGUELTIG`);
  return s;
}
function monateSpaeter(tag:string,monate:number){
  const d=new Date(`${tag}T00:00:00.000Z`);d.setUTCMonth(d.getUTCMonth()+monate);return d.toISOString().slice(0,10);
}
const quote=(zaehler:number,nenner:number)=>nenner>0?Math.round(zaehler/nenner*1000)/10:null;

// ---------------------------------------------------------------------------------------------
// Kennzahlen aus dem Bestand
// ---------------------------------------------------------------------------------------------

export interface Kennzahlen{
  jahr:number;eintritte:number;austritte:number;abbrueche:number;regulaer:number;arbeitsaufnahme:number;
  abbruchquote:number|null;erfolgsquote:number|null;vermittlungsquote:number|null;
  anwesenheitsquote:number|null;beschwerden:number;beschwerdequote:number|null;
}

/**
 * Die Erfolgskennzahlen eines Jahres - gerechnet, nicht gepflegt.
 *
 * Grundlage sind die Foerderfaelle: sie tragen Eintritt, Austritt und Austrittsgrund und werden
 * ohnehin gefuehrt, weil der Kostentraeger sie verlangt. Vier Abfragen, unabhaengig davon, wie
 * viele Teilnehmende der Traeger hat.
 *
 * Die Vermittlungsquote rechnet auf die BEENDETEN, nicht auf die Eintritte: wer noch im Kurs ist,
 * kann noch keine Arbeit aufgenommen haben, und ihn mitzuzaehlen redet die Quote klein.
 */
export async function kennzahlen(env:Env,tenantId:string,jahr:number):Promise<Kennzahlen>{
  const j=Math.trunc(Number(jahr)),von=`${j}-01-01`,bis=`${j}-12-31`;
  const ein=await env.DB.prepare('SELECT COUNT(*) n FROM participant_funding_cases WHERE tenant_id=? AND entered_on BETWEEN ? AND ?')
    .bind(tenantId,von,bis).first<{n:number}>();
  const aus=await env.DB.prepare(`SELECT
      COUNT(*) n,
      SUM(CASE WHEN exit_reason IN ('abbruch_teilnehmer','abbruch_traeger') THEN 1 ELSE 0 END) abbrueche,
      SUM(CASE WHEN exit_reason='regulaer' THEN 1 ELSE 0 END) regulaer,
      SUM(CASE WHEN exit_reason='arbeitsaufnahme' THEN 1 ELSE 0 END) arbeit
    FROM participant_funding_cases WHERE tenant_id=? AND exited_on BETWEEN ? AND ?`)
    .bind(tenantId,von,bis).first<{n:number;abbrueche:number;regulaer:number;arbeit:number}>();
  const anwesenheit=await env.DB.prepare(`SELECT
      SUM(CASE WHEN status IN ('present','remote_present','late') THEN 1 ELSE 0 END) da,
      SUM(CASE WHEN status<>'not_recorded' THEN 1 ELSE 0 END) erfasst
    FROM attendance_records WHERE tenant_id=? AND recorded_at BETWEEN ? AND ?`)
    .bind(tenantId,`${von}T00:00:00.000Z`,`${bis}T23:59:59.999Z`).first<{da:number;erfasst:number}>();
  const beschwerden=await env.DB.prepare('SELECT COUNT(*) n FROM complaints WHERE tenant_id=? AND created_at BETWEEN ? AND ?')
    .bind(tenantId,`${von}T00:00:00.000Z`,`${bis}T23:59:59.999Z`).first<{n:number}>();

  const eintritte=Number(ein?.n??0),austritte=Number(aus?.n??0);
  const abbrueche=Number(aus?.abbrueche??0),regulaer=Number(aus?.regulaer??0),arbeit=Number(aus?.arbeit??0);
  return{jahr:j,eintritte,austritte,abbrueche,regulaer,arbeitsaufnahme:arbeit,
    // Die Abbruchquote bezieht sich auf die Austritte des Jahres: auf die Eintritte gerechnet
    // waere sie bei wachsenden Jahrgaengen systematisch zu klein.
    abbruchquote:quote(abbrueche,austritte),
    erfolgsquote:quote(regulaer+arbeit,austritte),
    vermittlungsquote:quote(arbeit,austritte),
    anwesenheitsquote:quote(Number(anwesenheit?.da??0),Number(anwesenheit?.erfasst??0)),
    beschwerden:Number(beschwerden?.n??0),
    beschwerdequote:quote(Number(beschwerden?.n??0),eintritte)};
}

// ---------------------------------------------------------------------------------------------
// Ziele
// ---------------------------------------------------------------------------------------------

export async function legeZielAn(env:Env,auth:CoreAuthContext,tenantId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const bezeichnung=clean(eingabe.bezeichnung,200);
  if(bezeichnung.length<5)throw new Error('QM_ZIEL_BEZEICHNUNG_ERFORDERLICH');
  const messgroesse=clean(eingabe.messgroesse,40);
  if(!(MESSGROESSEN as readonly string[]).includes(messgroesse))throw new Error('QM_MESSGROESSE_UNGUELTIG');
  const jahr=Math.trunc(Number(eingabe.jahr));
  if(!Number.isFinite(jahr)||jahr<2000||jahr>2100)throw new Error('QM_JAHR_UNGUELTIG');
  const zielwert=Number(eingabe.zielwert);
  if(!Number.isFinite(zielwert))throw new Error('QM_ZIELWERT_ERFORDERLICH');
  // Ein gerechnetes Ziel bekommt keinen getippten Istwert. Sonst stuenden zwei Zahlen fuer
  // dieselbe Sache nebeneinander, und die fachkundige Stelle fragt genau danach.
  if(messgroesse!=='manuell'&&eingabe.istwert_manuell!==undefined&&eingabe.istwert_manuell!==null)
    throw new Error('QM_ISTWERT_WIRD_GERECHNET');
  const richtung=clean(eingabe.richtung,20)||(messgroesse==='abbruchquote'||messgroesse==='beschwerdequote'?'niedriger_besser':'hoeher_besser');
  const zielId=id('qzl_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO quality_objectives(id,tenant_id,jahr,bezeichnung,messgroesse,richtung,zielwert,istwert_manuell,verantwortlich,status,bemerkung,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,'aktiv',?,?,?,?)`)
    .bind(zielId,tenantId,jahr,bezeichnung,messgroesse,richtung,zielwert,
      messgroesse==='manuell'&&eingabe.istwert_manuell!==undefined?Number(eingabe.istwert_manuell):null,
      clean(eingabe.verantwortlich,120)||null,clean(eingabe.bemerkung,1000)||null,auth.userId,ts,ts).run();
  return{id:zielId,bezeichnung,messgroesse,zielwert,richtung};
}

/** Die Ziele eines Jahres mit ihrem Istwert - gerechnet, wo es geht. */
export async function zielstand(env:Env,auth:CoreAuthContext,tenantId:string,jahr:number){
  requireRole(auth,'tenant_admin');
  const j=Math.trunc(Number(jahr))||Number(nowIso().slice(0,4));
  const ziele=((await env.DB.prepare('SELECT * FROM quality_objectives WHERE tenant_id=? AND jahr=? ORDER BY bezeichnung')
    .bind(tenantId,j).all<Record<string,unknown>>()).results)??[];
  if(!ziele.length)return{jahr:j,kennzahlen:await kennzahlen(env,tenantId,j),ziele:[]};
  const z=await kennzahlen(env,tenantId,j);
  return{jahr:j,kennzahlen:z,ziele:ziele.map((ziel:Record<string,unknown>)=>{
    const messgroesse=String(ziel.messgroesse);
    const ist=messgroesse==='manuell'
      ?(ziel.istwert_manuell===null||ziel.istwert_manuell===undefined?null:Number(ziel.istwert_manuell))
      :(z[messgroesse as keyof Kennzahlen] as number|null);
    const zielwert=Number(ziel.zielwert);
    const erreicht=ist===null?null:(String(ziel.richtung)==='niedriger_besser'?ist<=zielwert:ist>=zielwert);
    return{...ziel,istwert:ist,erreicht,gerechnet:messgroesse!=='manuell'} as Record<string,unknown>;
  })};
}

// ---------------------------------------------------------------------------------------------
// Prozesse
// ---------------------------------------------------------------------------------------------

export async function legeProzessAn(env:Env,auth:CoreAuthContext,tenantId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const schluessel=clean(eingabe.schluessel,60).toLowerCase().replace(/[^a-z0-9_-]/g,'');
  if(schluessel.length<2)throw new Error('QM_PROZESS_SCHLUESSEL_ERFORDERLICH');
  const bezeichnung=clean(eingabe.bezeichnung,200);
  if(bezeichnung.length<5)throw new Error('QM_PROZESS_BEZEICHNUNG_ERFORDERLICH');
  const art=clean(eingabe.art,30)||'kern';
  if(!(PROZESSARTEN as readonly string[]).includes(art))throw new Error('QM_PROZESSART_UNGUELTIG');
  const intervall=Math.trunc(Number(eingabe.pruefintervall_monate??12));
  if(!Number.isFinite(intervall)||intervall<1||intervall>60)throw new Error('QM_INTERVALL_UNGUELTIG');
  const gepruet=eingabe.letzte_pruefung_am?datum(eingabe.letzte_pruefung_am,'PRUEFUNG'):null;
  const prozessId=id('qpr_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO quality_processes(id,tenant_id,schluessel,bezeichnung,art,verantwortlich,beschreibung,mitgeltende_unterlagen,letzte_pruefung_am,pruefintervall_monate,naechste_pruefung_am,status,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,'aktiv',?,?,?)`)
    .bind(prozessId,tenantId,schluessel,bezeichnung,art,clean(eingabe.verantwortlich,120)||null,
      clean(eingabe.beschreibung,4000)||null,clean(eingabe.mitgeltende_unterlagen,2000)||null,
      gepruet,intervall,gepruet?monateSpaeter(gepruet,intervall):null,auth.userId,ts,ts).run();
  return{id:prozessId,schluessel,bezeichnung,art,naechste_pruefung_am:gepruet?monateSpaeter(gepruet,intervall):null};
}

export async function bestaetigeProzesspruefung(env:Env,auth:CoreAuthContext,tenantId:string,prozessId:string,am:unknown){
  requireRole(auth,'tenant_admin');
  const tag=datum(am,'PRUEFUNG');
  const z=await env.DB.prepare('SELECT pruefintervall_monate FROM quality_processes WHERE tenant_id=? AND id=?')
    .bind(tenantId,clean(prozessId,120)).first<{pruefintervall_monate:number}>();
  if(!z)throw new Error('QM_PROZESS_NICHT_GEFUNDEN');
  const naechste=monateSpaeter(tag,Number(z.pruefintervall_monate));
  await env.DB.prepare('UPDATE quality_processes SET letzte_pruefung_am=?,naechste_pruefung_am=?,updated_at=? WHERE tenant_id=? AND id=?')
    .bind(tag,naechste,nowIso(),tenantId,clean(prozessId,120)).run();
  return{letzte_pruefung_am:tag,naechste_pruefung_am:naechste};
}

export async function prozessregister(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return((await env.DB.prepare('SELECT * FROM quality_processes WHERE tenant_id=? ORDER BY art,bezeichnung LIMIT 200')
    .bind(tenantId).all<Record<string,unknown>>()).results)??[];
}

// ---------------------------------------------------------------------------------------------
// Audits und Feststellungen
// ---------------------------------------------------------------------------------------------

export async function planeAudit(env:Env,auth:CoreAuthContext,tenantId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const art=clean(eingabe.art,30);
  if(!(AUDITARTEN as readonly string[]).includes(art))throw new Error('QM_AUDITART_UNGUELTIG');
  const bezeichnung=clean(eingabe.bezeichnung,200);
  if(bezeichnung.length<5)throw new Error('QM_AUDIT_BEZEICHNUNG_ERFORDERLICH');
  const geplant=datum(eingabe.geplant_am,'GEPLANT');
  const auditId=id('qau_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO quality_audits(id,tenant_id,art,bezeichnung,geplant_am,auditor,auditor_user_id,umfang,status,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,'geplant',?,?,?)`)
    .bind(auditId,tenantId,art,bezeichnung,geplant,clean(eingabe.auditor,200)||null,
      clean(eingabe.auditor_user_id,120)||null,clean(eingabe.umfang,2000)||null,auth.userId,ts,ts).run();
  return{id:auditId,art,bezeichnung,geplant_am:geplant};
}

/**
 * Eine Feststellung erfassen - und bei einer Abweichung gleich die Massnahme.
 *
 * Die Massnahme entsteht in quality_actions, wo schon alle Massnahmen des Hauses liegen. Ein
 * zweites Massnahmenregister waere die Stelle, an der die Haelfte vergessen wird.
 */
export async function erfasseFeststellung(env:Env,auth:CoreAuthContext,tenantId:string,auditId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const auditRow=await env.DB.prepare('SELECT id,status FROM quality_audits WHERE tenant_id=? AND id=?')
    .bind(tenantId,clean(auditId,120)).first<{id:string;status:string}>();
  if(!auditRow)throw new Error('QM_AUDIT_NICHT_GEFUNDEN');
  if(auditRow.status==='abgeschlossen')throw new Error('QM_AUDIT_ABGESCHLOSSEN');
  const einstufung=clean(eingabe.einstufung,30);
  if(!(EINSTUFUNGEN as readonly string[]).includes(einstufung))throw new Error('QM_EINSTUFUNG_UNGUELTIG');
  const bezeichnung=clean(eingabe.bezeichnung,500);
  if(bezeichnung.length<10)throw new Error('QM_FESTSTELLUNG_BEZEICHNUNG_ERFORDERLICH');

  const ts=nowIso(),findingId=id('qfe_');
  let actionId:string|null=null;
  if(MASSNAHMEPFLICHTIG.has(einstufung)){
    // Eine Abweichung ohne Massnahme ist eine Notiz. Deshalb entsteht die Massnahme hier - mit
    // Frist, denn eine Massnahme ohne Frist ist wieder nur eine Notiz.
    actionId=id('qac_');
    const frist=clean(eingabe.frist_am,10)||monateSpaeter(ts.slice(0,10),einstufung==='abweichung_schwer'?1:3);
    await env.DB.prepare(`INSERT INTO quality_actions(id,tenant_id,category,title,description,priority,status,due_at,source_type,source_id,owner_user_id,created_by,created_at,updated_at)
      VALUES(?,?,'audit',?,?,?,'open',?,'quality_finding',?,?,?,?,?)`)
      .bind(actionId,tenantId,`Abweichung: ${bezeichnung.slice(0,150)}`,clean(eingabe.massnahme,2000)||null,
        einstufung==='abweichung_schwer'?'critical':'high',frist,findingId,
        clean(eingabe.verantwortlich,120)||null,auth.userId,ts,ts).run();
  }
  await env.DB.prepare(`INSERT INTO quality_findings(id,tenant_id,audit_id,process_id,einstufung,bezeichnung,nachweis,action_id,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
    .bind(findingId,tenantId,auditRow.id,clean(eingabe.process_id,120)||null,einstufung,bezeichnung,
      clean(eingabe.nachweis,2000)||null,actionId,auth.userId,ts,ts).run();
  return{id:findingId,einstufung,action_id:actionId};
}

/**
 * Das Audit abschliessen.
 *
 * Nicht, solange eine Abweichung ohne erledigte Massnahme dasteht. Das ist die Regel, an der
 * Traeger im Ueberwachungsaudit scheitern: die Abweichung von vor einem Jahr steht noch da,
 * unerledigt, weil niemand sie an eine Massnahme gebunden hat.
 */
export async function schliesseAuditAb(env:Env,auth:CoreAuthContext,tenantId:string,auditId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const a=await env.DB.prepare('SELECT id,status FROM quality_audits WHERE tenant_id=? AND id=?')
    .bind(tenantId,clean(auditId,120)).first<{id:string;status:string}>();
  if(!a)throw new Error('QM_AUDIT_NICHT_GEFUNDEN');
  if(a.status==='abgeschlossen')throw new Error('QM_AUDIT_ABGESCHLOSSEN');
  const ergebnis=clean(eingabe.ergebnis,4000);
  if(ergebnis.length<20)throw new Error('QM_AUDIT_ERGEBNIS_ERFORDERLICH');
  const durchgefuehrt=datum(eingabe.durchgefuehrt_am,'DURCHGEFUEHRT');
  const offen=await env.DB.prepare(`SELECT COUNT(*) n FROM quality_findings f
    LEFT JOIN quality_actions m ON m.id=f.action_id
    WHERE f.tenant_id=? AND f.audit_id=? AND f.einstufung IN ('abweichung','abweichung_schwer')
      AND (f.action_id IS NULL OR m.status NOT IN ('resolved','cancelled'))`)
    .bind(tenantId,a.id).first<{n:number}>();
  if(Number(offen?.n??0)>0)throw new Error('QM_ABWEICHUNG_OHNE_ERLEDIGTE_MASSNAHME');
  const ts=nowIso();
  await env.DB.prepare(`UPDATE quality_audits SET status='abgeschlossen',durchgefuehrt_am=?,ergebnis=?,abgeschlossen_am=?,abgeschlossen_von=?,updated_at=?
    WHERE tenant_id=? AND id=?`).bind(durchgefuehrt,ergebnis,ts,auth.userId,ts,tenantId,a.id).run();
  await audit(env.DB,auth.userId,'quality.audit.closed',tenantId,undefined,'quality_audit',a.id,{});
  return{status:'abgeschlossen',durchgefuehrt_am:durchgefuehrt};
}

export async function auditmappe(env:Env,auth:CoreAuthContext,tenantId:string,auditId?:string){
  requireRole(auth,'tenant_admin');
  if(auditId){
    const a=await env.DB.prepare('SELECT * FROM quality_audits WHERE tenant_id=? AND id=?').bind(tenantId,clean(auditId,120)).first<Record<string,unknown>>();
    if(!a)throw new Error('QM_AUDIT_NICHT_GEFUNDEN');
    const f=((await env.DB.prepare(`SELECT f.*,m.status massnahme_status,m.due_at massnahme_frist FROM quality_findings f
      LEFT JOIN quality_actions m ON m.id=f.action_id WHERE f.tenant_id=? AND f.audit_id=? ORDER BY f.einstufung,f.created_at`)
      .bind(tenantId,a.id).all<Record<string,unknown>>()).results)??[];
    return{audit:a,feststellungen:f};
  }
  const liste=((await env.DB.prepare(`SELECT a.*,
      (SELECT COUNT(*) FROM quality_findings f WHERE f.audit_id=a.id AND f.einstufung IN ('abweichung','abweichung_schwer')) abweichungen
    FROM quality_audits a WHERE a.tenant_id=? ORDER BY a.geplant_am DESC LIMIT 100`)
    .bind(tenantId).all<Record<string,unknown>>()).results)??[];
  return{audits:liste};
}

// ---------------------------------------------------------------------------------------------
// Managementbewertung
// ---------------------------------------------------------------------------------------------

/**
 * Die Eingaben der Managementbewertung - zum Stichtag aus dem Bestand.
 *
 * ISO 9001 Kapitel 9.3.2 zaehlt sie auf: Stand aus vorangegangenen Bewertungen, Aenderungen,
 * Leistungsinformationen (Kundenzufriedenheit, Zielerreichung, Prozessleistung,
 * Nichtkonformitaeten, Auditergebnisse) und Verbesserungsmoeglichkeiten. Was hier fehlt, fehlt
 * in der Bewertung - und das faellt der fachkundigen Stelle auf, nicht dem Traeger.
 */
export async function bewertungseingaben(env:Env,auth:CoreAuthContext,tenantId:string,jahr:number){
  requireRole(auth,'tenant_admin');
  const j=Math.trunc(Number(jahr))||Number(nowIso().slice(0,4));
  const [ziele,audits,massnahmen,beschwerden,prozesse,zertifikate]=await Promise.all([
    zielstand(env,auth,tenantId,j),
    env.DB.prepare(`SELECT COUNT(*) gesamt,
        SUM(CASE WHEN status='abgeschlossen' THEN 1 ELSE 0 END) abgeschlossen,
        (SELECT COUNT(*) FROM quality_findings f JOIN quality_audits x ON x.id=f.audit_id
          WHERE x.tenant_id=? AND f.einstufung IN ('abweichung','abweichung_schwer') AND x.geplant_am BETWEEN ? AND ?) abweichungen
      FROM quality_audits WHERE tenant_id=? AND geplant_am BETWEEN ? AND ?`)
      .bind(tenantId,`${j}-01-01`,`${j}-12-31`,tenantId,`${j}-01-01`,`${j}-12-31`).first<Record<string,unknown>>(),
    env.DB.prepare(`SELECT COUNT(*) gesamt,
        SUM(CASE WHEN status IN ('resolved','cancelled') THEN 1 ELSE 0 END) erledigt,
        SUM(CASE WHEN status NOT IN ('resolved','cancelled') AND due_at IS NOT NULL AND due_at<? THEN 1 ELSE 0 END) ueberfaellig
      FROM quality_actions WHERE tenant_id=? AND created_at BETWEEN ? AND ?`)
      .bind(nowIso(),tenantId,`${j}-01-01T00:00:00.000Z`,`${j}-12-31T23:59:59.999Z`).first<Record<string,unknown>>(),
    env.DB.prepare(`SELECT COUNT(*) gesamt,
        SUM(CASE WHEN status='abgeschlossen' THEN 1 ELSE 0 END) abgeschlossen
      FROM complaints WHERE tenant_id=? AND created_at BETWEEN ? AND ?`)
      .bind(tenantId,`${j}-01-01T00:00:00.000Z`,`${j}-12-31T23:59:59.999Z`).first<Record<string,unknown>>(),
    env.DB.prepare(`SELECT COUNT(*) gesamt,
        SUM(CASE WHEN naechste_pruefung_am IS NOT NULL AND naechste_pruefung_am<? THEN 1 ELSE 0 END) ueberfaellig
      FROM quality_processes WHERE tenant_id=? AND status='aktiv'`)
      .bind(`${j}-12-31`,tenantId).first<Record<string,unknown>>(),
    env.DB.prepare("SELECT art,bezeichnung,gueltig_bis,status FROM quality_certifications WHERE tenant_id=? ORDER BY gueltig_bis").bind(tenantId).all<Record<string,unknown>>(),
  ]);
  return{jahr:j,stichtag:nowIso(),
    kennzahlen:ziele.kennzahlen,
    ziele:ziele.ziele.map(z=>({bezeichnung:z.bezeichnung,zielwert:z.zielwert,istwert:z.istwert,erreicht:z.erreicht})),
    audits:{gesamt:Number(audits?.gesamt??0),abgeschlossen:Number(audits?.abgeschlossen??0),abweichungen:Number(audits?.abweichungen??0)},
    massnahmen:{gesamt:Number(massnahmen?.gesamt??0),erledigt:Number(massnahmen?.erledigt??0),ueberfaellig:Number(massnahmen?.ueberfaellig??0)},
    beschwerden:{gesamt:Number(beschwerden?.gesamt??0),abgeschlossen:Number(beschwerden?.abgeschlossen??0)},
    prozesse:{gesamt:Number(prozesse?.gesamt??0),ueberfaellig:Number(prozesse?.ueberfaellig??0)},
    zertifikate:zertifikate.results??[]};
}

export async function haltBewertungFest(env:Env,auth:CoreAuthContext,tenantId:string,jahr:number,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const j=Math.trunc(Number(jahr));
  if(!Number.isFinite(j)||j<2000||j>2100)throw new Error('QM_JAHR_UNGUELTIG');
  const eingaben=await bewertungseingaben(env,auth,tenantId,j);
  const ts=nowIso(),reviewId=id('qmb_');
  await env.DB.prepare(`INSERT INTO quality_reviews(id,tenant_id,jahr,stichtag,eingaben_json,bewertung,entscheidungen,status,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,'entwurf',?,?,?)
    ON CONFLICT(tenant_id,jahr) DO UPDATE SET stichtag=excluded.stichtag,eingaben_json=excluded.eingaben_json,
      bewertung=COALESCE(excluded.bewertung,quality_reviews.bewertung),
      entscheidungen=COALESCE(excluded.entscheidungen,quality_reviews.entscheidungen),updated_at=excluded.updated_at`)
    .bind(reviewId,tenantId,j,ts,JSON.stringify(eingaben),clean(eingabe.bewertung,8000)||null,
      clean(eingabe.entscheidungen,8000)||null,auth.userId,ts,ts).run();
  return{jahr:j,stichtag:ts,eingaben};
}

export async function schliesseBewertungAb(env:Env,auth:CoreAuthContext,tenantId:string,jahr:number){
  requireRole(auth,'tenant_admin');
  const j=Math.trunc(Number(jahr));
  const z=await env.DB.prepare('SELECT id,bewertung,entscheidungen,status FROM quality_reviews WHERE tenant_id=? AND jahr=?')
    .bind(tenantId,j).first<{id:string;bewertung:string|null;entscheidungen:string|null;status:string}>();
  if(!z)throw new Error('QM_BEWERTUNG_NICHT_GEFUNDEN');
  if(z.status==='abgeschlossen')throw new Error('QM_BEWERTUNG_ABGESCHLOSSEN');
  // Eine Bewertung ohne Bewertung und ohne Entscheidungen waere ein leeres Blatt mit
  // Unterschrift - und genau das legen Traeger vor, wenn niemand es verlangt.
  if(!z.bewertung||z.bewertung.length<50)throw new Error('QM_BEWERTUNG_ERFORDERLICH');
  if(!z.entscheidungen||z.entscheidungen.length<20)throw new Error('QM_ENTSCHEIDUNGEN_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.prepare("UPDATE quality_reviews SET status='abgeschlossen',abgeschlossen_am=?,abgeschlossen_von=?,updated_at=? WHERE id=?")
    .bind(ts,auth.userId,ts,z.id).run();
  await audit(env.DB,auth.userId,'quality.review.closed',tenantId,undefined,'quality_review',z.id,{jahr:j});
  return{status:'abgeschlossen',jahr:j};
}

// ---------------------------------------------------------------------------------------------
// Zertifizierung
// ---------------------------------------------------------------------------------------------

export async function legeZertifikatAn(env:Env,auth:CoreAuthContext,tenantId:string,eingabe:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const art=clean(eingabe.art,40);
  if(!(ZERTIFIKATSARTEN as readonly string[]).includes(art))throw new Error('QM_ZERTIFIKATSART_UNGUELTIG');
  const zertifizierer=clean(eingabe.zertifizierer,200);
  if(zertifizierer.length<3)throw new Error('QM_ZERTIFIZIERER_ERFORDERLICH');
  const von=datum(eingabe.gueltig_von,'GUELTIG_VON'),bis=datum(eingabe.gueltig_bis,'GUELTIG_BIS');
  if(bis<von)throw new Error('QM_ZEITRAUM_UNGUELTIG');
  const zertId=id('qze_'),ts=nowIso();
  await env.DB.prepare(`INSERT INTO quality_certifications(id,tenant_id,art,bezeichnung,zertifizierer,zertifikatsnummer,gueltig_von,gueltig_bis,naechste_ueberwachung_am,geltungsbereich,status,created_by,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,'gueltig',?,?,?)`)
    .bind(zertId,tenantId,art,clean(eingabe.bezeichnung,200)||art,zertifizierer,clean(eingabe.zertifikatsnummer,120)||null,
      von,bis,eingabe.naechste_ueberwachung_am?datum(eingabe.naechste_ueberwachung_am,'UEBERWACHUNG'):null,
      clean(eingabe.geltungsbereich,2000)||null,auth.userId,ts,ts).run();
  return{id:zertId,art,gueltig_bis:bis};
}

export async function zertifikate(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return((await env.DB.prepare('SELECT * FROM quality_certifications WHERE tenant_id=? ORDER BY gueltig_bis').bind(tenantId).all<Record<string,unknown>>()).results)??[];
}

/**
 * Der taegliche Lauf: ablaufende Zertifikate, faellige Prozesspruefungen, ueberfaellige Audits.
 *
 * Eine abgelaufene Traegerzulassung heisst: keine Foerderung mehr, ab dem Tag. Drei Monate
 * Vorlauf sind das Mindeste, weil ein Ueberwachungsaudit terminiert werden muss.
 */
export async function erinnereAnQmFristen(env:Env,grenze=30,heute=nowIso().slice(0,10)){
  const vorlauf=new Date(Date.parse(`${heute}T00:00:00Z`)+ZERTIFIKAT_VORLAUF_TAGE*86400000).toISOString().slice(0,10);
  const ts=nowIso();
  const zertifikate=((await env.DB.prepare(`SELECT id,tenant_id,art,bezeichnung,gueltig_bis FROM quality_certifications
    WHERE status='gueltig' AND gueltig_bis<=? AND (erinnert_am IS NULL OR erinnert_am<?) ORDER BY gueltig_bis LIMIT ?`)
    .bind(vorlauf,`${heute}T00:00:00.000Z`,Math.max(1,Math.min(100,grenze)))
    .all<{id:string;tenant_id:string;art:string;bezeichnung:string;gueltig_bis:string}>()).results)??[];
  for(const z of zertifikate){
    await env.DB.batch([
      env.DB.prepare('INSERT INTO automation_events(id,tenant_id,event_type,source_type,source_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)')
        .bind(id('aev_'),z.tenant_id,'quality.certification.expiring','quality_certification',z.id,
          JSON.stringify({art:z.art,bezeichnung:z.bezeichnung,gueltig_bis:z.gueltig_bis}),ts),
      env.DB.prepare('UPDATE quality_certifications SET erinnert_am=? WHERE id=?').bind(ts,z.id),
    ]);
  }
  // Abgelaufene werden nicht nur gemeldet, sondern als abgelaufen gefuehrt: ein Zertifikat, das
  // im System noch "gueltig" heisst, ist die Zeile, auf die sich am Ende jemand verlaesst.
  const abgelaufen=await env.DB.prepare("UPDATE quality_certifications SET status='abgelaufen',updated_at=? WHERE status='gueltig' AND gueltig_bis<?")
    .bind(ts,heute).run();
  const prozesse=((await env.DB.prepare(`SELECT id,tenant_id,bezeichnung,naechste_pruefung_am FROM quality_processes
    WHERE status='aktiv' AND naechste_pruefung_am IS NOT NULL AND naechste_pruefung_am<=? LIMIT ?`)
    .bind(heute,Math.max(1,Math.min(100,grenze))).all<{id:string;tenant_id:string;bezeichnung:string;naechste_pruefung_am:string}>()).results)??[];
  for(const p of prozesse)
    await env.DB.prepare('INSERT INTO automation_events(id,tenant_id,event_type,source_type,source_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?)')
      .bind(id('aev_'),p.tenant_id,'quality.process.review_due','quality_process',p.id,
        JSON.stringify({bezeichnung:p.bezeichnung,faellig_am:p.naechste_pruefung_am}),ts).run();
  return{zertifikate:zertifikate.length,abgelaufen:Number(abgelaufen.meta?.changes??0),prozesse:prozesse.length};
}

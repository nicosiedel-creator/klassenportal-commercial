import type { CoreAuthContext, Env } from './types.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Durchgaengiger Ereignisbus (W5).
//
// Bisher rief jedes Modul die anderen direkt auf. Drei Folgen:
//  - Jede Erweiterung fasst fremden Code an.
//  - Faellt ein nachgelagerter Schritt aus, faellt der ausloesende Vorgang mit aus, obwohl er
//    fachlich abgeschlossen war.
//  - Niemand kann sagen, was auf ein Ereignis hin GESCHEHEN IST.
//
// Ein Bus loest das nur, wenn drei Dinge stimmen:
//  1. GENAU EINMAL je Abonnent. "Mindestens einmal" heisst in der Praxis "so oft, wie der Lauf
//     zufaellig anlaeuft" - und dann geht eine Mail dreimal raus.
//  2. NICHTS GEHT STILL VERLOREN. Was nach den Versuchen nicht durchkommt, liegt sichtbar im
//     Totfach, nicht im Nirgendwo.
//  3. REIHENFOLGE JE OBJEKT. Ohne sie wird "Kurs beendet" vor "Note eingetragen" zugestellt,
//     und das faellt erst im Zeugnis auf.

const clean=(v:unknown,n=2000)=>safeString(v,n);
export const HOECHSTVERSUCHE=5;
// Wartezeiten in Minuten zwischen den Versuchen. Wachsend, damit ein laengerer Ausfall nicht
// jede Minute erneut gegen dieselbe Wand laeuft.
export const RUECKSTAU_MINUTEN=[1,5,30,120,480];
// Wie viele Zustellungen ein Lauf hoechstens versucht. Jede kann eine ausgehende Anfrage
// ausloesen, und ein Worker-Aufruf hat 1000 Unteranfragen fuer ALLE Jobs zusammen.
export const HOECHSTZUSTELLUNGEN=50;

export type Verarbeiter=(env:Env,ereignis:Ereignis)=>Promise<void>;
export interface Ereignis{id:string;tenant_id:string|null;art:string;objekt_typ:string;objekt_id:string;
  nutzlast:Record<string,unknown>;folge:number;quelle:string;created_at:string}

const VERARBEITER:Record<string,Verarbeiter>={};
export function registriereVerarbeiter(name:string,fn:Verarbeiter){VERARBEITER[name]=fn;}
export function bekannteVerarbeiter(){return Object.keys(VERARBEITER).sort();}

/**
 * Ein Ereignis veroeffentlichen.
 *
 * Die Zustellzeilen werden GLEICH MIT angelegt, in einem Stapel. Sie spaeter aus den Abonnements
 * abzuleiten waere bequem und falsch: ein Abonnement, das nach dem Ereignis angelegt wird,
 * bekaeme dann rueckwirkend alles - und ein geloeschtes liesse die Zustellung verschwinden.
 */
export async function veroeffentliche(env:Env,tenantId:string|null,eingabe:{art:string;objekt_typ:string;objekt_id:string;
  nutzlast?:Record<string,unknown>;quelle:string;ausgeloest_von?:string|null}){
  const art=clean(eingabe.art,80),objektTyp=clean(eingabe.objekt_typ,60),objektId=clean(eingabe.objekt_id,120);
  if(!art||!objektTyp||!objektId)throw new Error('EREIGNIS_UNVOLLSTAENDIG');
  const quelle=clean(eingabe.quelle,80);
  if(!quelle)throw new Error('EREIGNIS_QUELLE_ERFORDERLICH');
  const ts=nowIso(),eventId=id('evt_');
  // Die laufende Nummer in derselben Anweisung: ein getrenntes SELECT+INSERT vergibt unter Last
  // zweimal dieselbe, und dann hat die Reihenfolge keine Grundlage mehr.
  await env.DB.prepare(`INSERT INTO domain_events(id,tenant_id,art,objekt_typ,objekt_id,nutzlast_json,folge,quelle,ausgeloest_von,created_at)
    SELECT ?,?,?,?,?,?,COALESCE(MAX(folge),0)+1,?,?,? FROM domain_events WHERE tenant_id IS ?`)
    .bind(eventId,tenantId,art,objektTyp,objektId,JSON.stringify(eingabe.nutzlast??{}),quelle,eingabe.ausgeloest_von??null,ts,tenantId).run();
  const abos=((await env.DB.prepare('SELECT id FROM event_subscriptions WHERE art=? AND aktiv=1 AND (tenant_id=? OR tenant_id IS NULL)')
    .bind(art,tenantId).all<{id:string}>()).results)??[];
  if(abos.length){
    // naechster_versuch_am bleibt leer: eine frische Zustellung ist sofort faellig. Den
    // Erstellungszeitpunkt einzutragen waere subtil falsch - ein Lauf, der kurz vorher startet,
    // uebersaehe sie.
    const anweisungen=abos.map(ab=>env.DB.prepare("INSERT INTO event_deliveries(id,tenant_id,event_id,subscription_id,status,versuche,naechster_versuch_am,created_at,updated_at) VALUES(?,?,?,?,'offen',0,NULL,?,?)")
      .bind(id('evz_'),tenantId,eventId,ab.id,ts,ts));
    for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  }
  return{id:eventId,abonnenten:abos.length};
}

export async function abonniere(env:Env,auth:CoreAuthContext,tenantId:string,art:string,verarbeiter:string,beschreibung?:string){
  requireRole(auth,'tenant_admin');
  const name=clean(verarbeiter,80);
  // Ein Abonnement auf einen Verarbeiter, den es nicht gibt, ist eine Zeile, die nie etwas tut -
  // und beim naechsten Betriebsfehler sucht jemand eine Stunde danach.
  if(!VERARBEITER[name])throw new Error('EREIGNIS_VERARBEITER_UNBEKANNT');
  const ts=nowIso();
  await env.DB.prepare('INSERT INTO event_subscriptions(id,tenant_id,art,verarbeiter,beschreibung,aktiv,created_at,updated_at) VALUES(?,?,?,?,?,1,?,?) ON CONFLICT(tenant_id,art,verarbeiter) DO UPDATE SET aktiv=1,beschreibung=excluded.beschreibung,updated_at=excluded.updated_at')
    .bind(id('eab_'),tenantId,clean(art,80),name,clean(beschreibung,500)||null,ts,ts).run();
  return{abonniert:true};
}

/**
 * Der Zustelllauf.
 *
 * Die Reihenfolge je Objekt ist der unbequeme Teil: eine Zustellung wird zurueckgestellt,
 * solange zum SELBEN Objekt eine frueher entstandene Zustellung desselben Abonnenten noch offen
 * ist. Ohne diese Bedingung kommt bei einem Ausfall die spaetere Nachricht zuerst durch.
 */
export async function stelleZu(env:Env,jetzt?:string){
  const ts=jetzt??nowIso();
  // Die Reihenfolge JE OBJEKT haelt auch ueber Laeufe hinweg. Zwei Bedingungen zusammen:
  //  - In der Abfrage: eine Zustellung wird gar nicht erst geholt, solange zum selben Objekt
  //    eine frueher entstandene desselben Empfaengers im RUECKSTAU liegt. Nur im Lauf zu ordnen
  //    reichte nicht - beim naechsten Lauf waere die spaetere faellig und die fruehere noch
  //    zurueckgestellt.
  //  - Im Lauf: ORDER BY folge holt Geschwister in der richtigen Reihenfolge, und der
  //    blockiert-Satz haelt die spaeteren zurueck, sobald eine fruehere hier scheitert.
  const faellig=((await env.DB.prepare(`SELECT z.id,z.event_id,z.subscription_id,z.versuche,e.tenant_id,e.art,e.objekt_typ,e.objekt_id,e.nutzlast_json,e.folge,e.quelle,e.created_at,s.verarbeiter
    FROM event_deliveries z JOIN domain_events e ON e.id=z.event_id JOIN event_subscriptions s ON s.id=z.subscription_id
    WHERE z.status IN ('offen','wiederholung') AND (z.naechster_versuch_am IS NULL OR z.naechster_versuch_am<=?) AND s.aktiv=1
      AND NOT EXISTS(SELECT 1 FROM event_deliveries z2 JOIN domain_events e2 ON e2.id=z2.event_id JOIN event_subscriptions s2 ON s2.id=z2.subscription_id
        WHERE s2.verarbeiter=s.verarbeiter AND e2.objekt_typ=e.objekt_typ AND e2.objekt_id=e.objekt_id AND e2.tenant_id IS e.tenant_id
          AND z2.status='wiederholung' AND e2.folge<e.folge)
    ORDER BY e.folge LIMIT ?`).bind(ts,HOECHSTZUSTELLUNGEN)
    .all<{id:string;event_id:string;subscription_id:string;versuche:number;tenant_id:string|null;art:string;objekt_typ:string;objekt_id:string;nutzlast_json:string;folge:number;quelle:string;created_at:string;verarbeiter:string}>()).results)??[];
  let erfolg=0,fehler=0,zurueckgestellt=0,totfach=0;
  // Je VERARBEITER und Objekt merken, ob schon etwas haengengeblieben ist. Alles Spaetere zu
  // diesem Objekt wartet dann - genau das ist die Reihenfolgegarantie. Der Schluessel ist
  // bewusst der Verarbeiter und nicht die Abonnementzeile: derselbe Empfaenger hat fuer
  // 'note.eingetragen' und 'kurs.beendet' zwei Zeilen, ist aber EIN Empfaenger. Ueber die
  // Abonnementzeile zu ordnen hiesse, ihm "Kurs beendet" vor "Note eingetragen" zu schicken.
  const blockiert=new Set<string>();
  for(const z of faellig){
    const schluessel=`${z.verarbeiter}|${z.objekt_typ}|${z.objekt_id}`;
    if(blockiert.has(schluessel)){zurueckgestellt++;continue;}
    const fn=VERARBEITER[z.verarbeiter];
    if(!fn){
      // Ein unbekannter Verarbeiter blockiert nicht die anderen: er wird uebersprungen und
      // sichtbar vermerkt.
      await env.DB.prepare("UPDATE event_deliveries SET status='uebersprungen',letzter_fehler='EREIGNIS_VERARBEITER_UNBEKANNT',updated_at=? WHERE id=?").bind(ts,z.id).run();
      fehler++;continue;
    }
    let nutzlast:Record<string,unknown>={};
    try{nutzlast=JSON.parse(z.nutzlast_json||'{}');}catch{}
    try{
      await fn(env,{id:z.event_id,tenant_id:z.tenant_id,art:z.art,objekt_typ:z.objekt_typ,objekt_id:z.objekt_id,
        nutzlast,folge:z.folge,quelle:z.quelle,created_at:z.created_at});
      await env.DB.prepare("UPDATE event_deliveries SET status='erfolg',versuche=versuche+1,zugestellt_am=?,letzter_fehler=NULL,updated_at=? WHERE id=?")
        .bind(ts,ts,z.id).run();
      erfolg++;
    }catch(e){
      const versuche=z.versuche+1;
      const grund=String((e as Error)?.message??e??'FEHLER').slice(0,300);
      if(versuche>=HOECHSTVERSUCHE){
        // Totfach heisst sichtbar liegen, nicht verschwinden. Was hier landet, wird von Hand
        // entschieden - und genau deshalb steht der Fehler dabei.
        await env.DB.prepare("UPDATE event_deliveries SET status='totfach',versuche=?,letzter_fehler=?,updated_at=? WHERE id=?").bind(versuche,grund,ts,z.id).run();
        totfach++;
      }else{
        const warte=RUECKSTAU_MINUTEN[Math.min(versuche-1,RUECKSTAU_MINUTEN.length-1)];
        await env.DB.prepare("UPDATE event_deliveries SET status='wiederholung',versuche=?,letzter_fehler=?,naechster_versuch_am=?,updated_at=? WHERE id=?")
          .bind(versuche,grund,new Date(Date.parse(ts)+warte*60000).toISOString(),ts,z.id).run();
      }
      blockiert.add(schluessel);
      fehler++;
    }
  }
  return{geprueft:faellig.length,erfolg,fehler,zurueckgestellt,totfach};
}

/** Was liegt im Totfach - und warum? */
export async function totfach(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return ((await env.DB.prepare(`SELECT z.id,e.art,e.objekt_typ,e.objekt_id,s.verarbeiter,z.versuche,z.letzter_fehler,z.updated_at
    FROM event_deliveries z JOIN domain_events e ON e.id=z.event_id JOIN event_subscriptions s ON s.id=z.subscription_id
    WHERE z.tenant_id=? AND z.status IN ('totfach','uebersprungen') ORDER BY z.updated_at DESC LIMIT 200`)
    .bind(tenantId).all()).results)??[];
}

/** Eine Zustellung aus dem Totfach erneut einreihen - nach dem Beheben der Ursache. */
export async function nimmZustellungWiederAuf(env:Env,auth:CoreAuthContext,tenantId:string,zustellungId:string){
  requireRole(auth,'tenant_admin');
  const z=await env.DB.prepare('SELECT id,status FROM event_deliveries WHERE id=? AND tenant_id=?').bind(clean(zustellungId,120),tenantId).first<{id:string;status:string}>();
  if(!z)throw new Error('EREIGNIS_ZUSTELLUNG_NICHT_GEFUNDEN');
  if(z.status!=='totfach'&&z.status!=='uebersprungen')throw new Error('EREIGNIS_NICHT_IM_TOTFACH');
  const ts=nowIso();
  await env.DB.prepare("UPDATE event_deliveries SET status='offen',versuche=0,naechster_versuch_am=?,letzter_fehler=NULL,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(ts,ts,z.id,tenantId).run();
  return{wieder_eingereiht:true};
}

/**
 * Was ist auf ein Ereignis hin geschehen?
 *
 * Die Frage, die vorher niemand beantworten konnte. Zwei Abfragen fuer die ganze Spur.
 */
export async function ereignisspur(env:Env,auth:CoreAuthContext,tenantId:string,objektTyp:string,objektId:string){
  requireRole(auth,'class_admin');
  const ereignisse=((await env.DB.prepare(`SELECT id,art,folge,quelle,created_at,nutzlast_json FROM domain_events
    WHERE tenant_id=? AND objekt_typ=? AND objekt_id=? ORDER BY folge LIMIT 200`)
    .bind(tenantId,clean(objektTyp,60),clean(objektId,120)).all<Record<string,unknown>>()).results)??[];
  if(!ereignisse.length)return{ereignisse:[]};
  const ph=ereignisse.map(()=>'?').join(',');
  const zustellungen=((await env.DB.prepare(`SELECT z.event_id,s.verarbeiter,z.status,z.versuche,z.letzter_fehler,z.zugestellt_am
    FROM event_deliveries z JOIN event_subscriptions s ON s.id=z.subscription_id WHERE z.event_id IN (${ph})`)
    .bind(...ereignisse.map(e=>String(e.id))).all<Record<string,unknown>>()).results)??[];
  return{ereignisse:ereignisse.map(e=>({...e,zustellungen:zustellungen.filter(z=>z.event_id===e.id)}))};
}

/** Der Busstand fuers Cockpit. */
export async function busstand(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  const z=await env.DB.prepare(`SELECT
    SUM(CASE WHEN status IN ('offen','wiederholung') THEN 1 ELSE 0 END) AS offen,
    SUM(CASE WHEN status='totfach' THEN 1 ELSE 0 END) AS totfach,
    SUM(CASE WHEN status='uebersprungen' THEN 1 ELSE 0 END) AS uebersprungen,
    SUM(CASE WHEN status='erfolg' THEN 1 ELSE 0 END) AS erfolg
    FROM event_deliveries WHERE tenant_id=?`).bind(tenantId).first<Record<string,number>>();
  const abos=((await env.DB.prepare('SELECT art,verarbeiter,aktiv,beschreibung FROM event_subscriptions WHERE tenant_id=? OR tenant_id IS NULL ORDER BY art')
    .bind(tenantId).all()).results)??[];
  return{...(z??{}),abonnements:abos,verarbeiter:bekannteVerarbeiter()};
}

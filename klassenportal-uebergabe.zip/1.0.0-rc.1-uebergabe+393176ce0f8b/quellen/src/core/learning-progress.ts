// Lernfortschritt - bis hierher eine Kennzahl ohne Quelle.
//
// Die Tabelle learning_progress wurde an zwei Stellen GELESEN: bei den Kennzahlen fuer eine
// Bescheinigung und in der Teilnehmerakte. Geschrieben hat sie nie jemand. Damit war
// progressTotal immer 0 und progressComplete immer falsch - und eine Vorlage mit dem Haken
// "Lernfortschritt muss vollstaendig sein" bei automatischer Ausstellung konnte NIE ausloesen.
// Die Oberflaeche bietet den Haken an, der Server lehnt jede Bescheinigung mit
// PROGRESS_INCOMPLETE ab, und niemand kann sagen warum. Ein Versprechen, das die Software nicht
// halten kann, ist schlimmer als eine fehlende Funktion.
//
// Erfunden wird hier nichts. Der Fortschritt wird aus Daten abgeleitet, die es schon gibt und die
// bereits genau das bedeuten:
//   - Der Kurs haengt an einem Lehrplan (course_curriculum_bindings -> curriculum_items).
//   - Eine Lehrplanposition wird durch Unterrichtseinheiten abgedeckt (curriculum_session_links).
//   - Ob eine Person dabei war, steht in der Anwesenheit (attendance_records).
// Eine Pflichtposition gilt fuer eine Person als erledigt, wenn sie bei JEDER gehaltenen Einheit,
// die diese Position abdeckt, anwesend war. Wer fehlte, hat den Stoff nicht gehabt - das ist die
// gleiche Aussage, die auch das Berichtsheft und die Anwesenheitsquote treffen.
//
// Bereits vorhandene Zeilen in learning_progress werden weiter mitgezaehlt: wer den Fortschritt
// von Hand oder ueber eine Schnittstelle pflegt, verliert nichts.
import type { Env } from './types.js';

export type Fortschritt = { total: number; done: number; complete: boolean };

// Eine einzige Abfrage. Die Plattform zaehlt Unteranfragen, und diese Zahl wird je Bescheinigung
// gebraucht - bei einer ganzen Klasse waeren mehrere Abfragen je Person sofort das Budget.
const ABGELEITET =
  `SELECT COUNT(*) total, SUM(CASE WHEN gehalten>0 AND anwesend=gehalten THEN 1 ELSE 0 END) done FROM (
     SELECT ci.id AS position,
            COUNT(DISTINCT s.id) AS gehalten,
            COUNT(DISTINCT CASE WHEN ar.status IN ('present','remote_present','late') THEN s.id END) AS anwesend
       FROM course_curriculum_bindings ccb
       JOIN curriculum_items ci ON ci.framework_id=ccb.framework_id AND ci.mandatory=1
       JOIN curriculum_session_links csl ON csl.curriculum_item_id=ci.id AND csl.course_id=ccb.course_id AND csl.tenant_id=ccb.tenant_id
       JOIN attendance_sessions s ON s.id=csl.session_id AND s.status='held'
       LEFT JOIN attendance_records ar ON ar.session_id=s.id AND ar.user_id=?
      WHERE ccb.tenant_id=? AND ccb.course_id=?
      GROUP BY ci.id)`;

export async function lernfortschritt(env: Env, tenantId: string, courseId: string, userId: string): Promise<Fortschritt> {
  const abgeleitet = await env.DB.prepare(ABGELEITET).bind(userId, tenantId, courseId).first<{ total: number; done: number }>();
  const gepflegt = await env.DB.prepare('SELECT COUNT(*) total,SUM(done) done FROM learning_progress WHERE tenant_id=? AND course_id=? AND user_id=?')
    .bind(tenantId, courseId, userId).first<{ total: number; done: number }>();
  const total = Number(abgeleitet?.total || 0) + Number(gepflegt?.total || 0);
  const done = Number(abgeleitet?.done || 0) + Number(gepflegt?.done || 0);
  return { total, done, complete: total > 0 && done === total };
}

// Fuer die Teilnehmerakte: derselbe Fortschritt fuer mehrere Kurse einer Person.
export async function lernfortschrittJeKurs(env: Env, tenantId: string, userId: string, courseIds: string[]): Promise<Record<string, Fortschritt>> {
  const out: Record<string, Fortschritt> = {};
  for (const kurs of courseIds) out[kurs] = await lernfortschritt(env, tenantId, kurs, userId);
  return out;
}

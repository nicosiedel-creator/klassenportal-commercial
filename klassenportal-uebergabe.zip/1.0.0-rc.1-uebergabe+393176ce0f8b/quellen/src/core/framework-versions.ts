import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';
import { sha256Text } from '../portability/backup-integrity.js';

// Versionierung von Rahmenlehrplaenen und Kompetenzrahmen (P6).
//
// Bisher wurden Lernfelder und Kompetenzen an Ort und Stelle geaendert. Das heisst: aendert der
// Traeger 2027 den Wortlaut eines Lernfelds, aendert sich rueckwirkend, WOFUER jemand 2024 eine
// Note bekommen hat. Ein Zeugnis, dessen Bezugsgroesse sich nachtraeglich verschiebt, ist kein
// Nachweis mehr - und genau deshalb verbietet die Spec das ("historische Bewertungen duerfen nicht
// kippen").
//
// Die Loesung ist eine Momentaufnahme: beim Veroeffentlichen wird der Stand eingefroren und
// gehasht. Eine veroeffentlichte Fassung ist unveraenderlich - die Datenbank laesst sie nicht mehr
// anfassen. Wer etwas aendern will, legt eine neue Fassung an; die alte bleibt, weil die
// Bewertungen von damals auf sie zeigen.

const clean=(v:unknown,n=2000)=>safeString(v,n);

export type Fassung={id:string;framework_id:string;fassung:number;bezeichnung:string;status:string;gueltig_ab:string|null;gueltig_bis:string|null;inhalt_hash:string|null};

async function ladeRahmen(env:Env,tenantId:string,frameworkId:string){
  const r=await env.DB.prepare('SELECT id,name,version,status FROM curriculum_frameworks WHERE id=? AND tenant_id=?').bind(frameworkId,tenantId).first<{id:string;name:string;version:string|null;status:string}>();
  if(!r)throw new Error('RAHMEN_NICHT_GEFUNDEN');
  return r;
}

async function momentaufnahme(env:Env,tenantId:string,frameworkId:string):Promise<{art:'lernfeld'|'kompetenz';bezug_id:string;code:string|null;titel:string;daten:Record<string,unknown>;sort:number}[]>{
  const lernfelder=((await env.DB.prepare('SELECT id,code,title,description,learning_objectives,target_minutes,exam_relevant,mandatory,sort_order FROM curriculum_items WHERE tenant_id=? AND framework_id=? ORDER BY sort_order,code')
    .bind(tenantId,frameworkId).all<Record<string,unknown>>()).results)??[];
  const kompetenzen=((await env.DB.prepare('SELECT id,code,title,beschreibung,dqr_niveau,art,status,sort_order FROM competencies WHERE tenant_id=? AND framework_id=? ORDER BY sort_order,code')
    .bind(tenantId,frameworkId).all<Record<string,unknown>>()).results)??[];
  return [
    ...lernfelder.map(z=>({art:'lernfeld' as const,bezug_id:String(z.id),code:z.code===null?null:String(z.code),titel:String(z.title??''),daten:z,sort:Number(z.sort_order??0)})),
    ...kompetenzen.map(z=>({art:'kompetenz' as const,bezug_id:String(z.id),code:z.code===null?null:String(z.code),titel:String(z.title??''),daten:z,sort:Number(z.sort_order??0)})),
  ];
}

/**
 * Eine neue Fassung als ENTWURF anlegen - mit dem heutigen Stand als Momentaufnahme.
 *
 * Der Entwurf ist noch aenderbar. Erst das Veroeffentlichen macht ihn zum Nachweis.
 */
export async function legeFassungAn(env:Env,auth:CoreAuthContext,tenantId:string,frameworkId:string,input:Record<string,unknown>={}){
  requireRole(auth,'tenant_admin');
  await ladeRahmen(env,tenantId,frameworkId);
  const offen=await env.DB.prepare("SELECT id FROM curriculum_framework_versions WHERE framework_id=? AND status='entwurf'").bind(frameworkId).first();
  if(offen)throw new Error('RAHMEN_ENTWURF_VORHANDEN');
  const hoechste=Number((await env.DB.prepare('SELECT MAX(fassung) f FROM curriculum_framework_versions WHERE framework_id=?').bind(frameworkId).first<{f:number|null}>())?.f??0);
  const nummer=hoechste+1,versionId=id('rfv_'),ts=nowIso();
  const eintraege=await momentaufnahme(env,tenantId,frameworkId);
  if(!eintraege.length)throw new Error('RAHMEN_LEER');
  const bezeichnung=clean(input.bezeichnung,200)||`Fassung ${nummer}`;
  const anweisungen=[env.DB.prepare("INSERT INTO curriculum_framework_versions(id,tenant_id,framework_id,fassung,bezeichnung,status,kommentar,created_by,created_at,updated_at) VALUES(?,?,?,?,?,'entwurf',?,?,?,?)")
    .bind(versionId,tenantId,frameworkId,nummer,bezeichnung,clean(input.kommentar,1000)||null,auth.userId,ts,ts)];
  for(const e of eintraege)anweisungen.push(env.DB.prepare('INSERT INTO framework_version_entries(id,framework_version_id,art,bezug_id,code,titel,daten_json,sort_order) VALUES(?,?,?,?,?,?,?,?)')
    .bind(id('rfe_'),versionId,e.art,e.bezug_id,e.code,e.titel,JSON.stringify(e.daten),e.sort));
  // In Stapeln: ein Rahmenlehrplan mit dreihundert Lernfeldern darf das Budget nicht sprengen.
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  await audit(env.DB,auth.userId,'framework.version_drafted',tenantId,undefined,'curriculum_framework',frameworkId,{fassung:nummer,eintraege:eintraege.length});
  return{id:versionId,fassung:nummer,eintraege:eintraege.length};
}

/**
 * Veroeffentlichen: der Stand wird eingefroren und gehasht.
 *
 * Ab hier ist die Fassung unveraenderlich, und die bisher gueltige wird abgeloest - aber nicht
 * geloescht: die Bewertungen von damals zeigen auf sie.
 */
export async function veroeffentlicheFassung(env:Env,auth:CoreAuthContext,tenantId:string,versionId:string,gueltigAb?:unknown){
  requireRole(auth,'tenant_admin');
  const fassung=await env.DB.prepare('SELECT id,framework_id,fassung,status FROM curriculum_framework_versions WHERE id=? AND tenant_id=?').bind(versionId,tenantId).first<Fassung>();
  if(!fassung)throw new Error('RAHMEN_FASSUNG_NICHT_GEFUNDEN');
  if(fassung.status!=='entwurf')throw new Error('RAHMEN_FASSUNG_VEROEFFENTLICHT');
  const eintraege=((await env.DB.prepare('SELECT art,bezug_id,code,titel,daten_json,sort_order FROM framework_version_entries WHERE framework_version_id=? ORDER BY art,sort_order,bezug_id')
    .bind(versionId).all<Record<string,unknown>>()).results)??[];
  if(!eintraege.length)throw new Error('RAHMEN_LEER');
  const hash=await sha256Text(JSON.stringify(eintraege));
  const ts=nowIso(),ab=clean(gueltigAb,40)||ts;
  await env.DB.batch([
    env.DB.prepare("UPDATE curriculum_framework_versions SET status='abgeloest',gueltig_bis=? WHERE framework_id=? AND status='gueltig'").bind(ab,fassung.framework_id),
    env.DB.prepare("UPDATE curriculum_framework_versions SET status='gueltig',gueltig_ab=?,inhalt_hash=?,veroeffentlicht_von=?,veroeffentlicht_am=?,updated_at=? WHERE id=?")
      .bind(ab,hash,auth.userId,ts,ts,versionId),
    env.DB.prepare('UPDATE curriculum_frameworks SET version=?,updated_at=? WHERE id=? AND tenant_id=?').bind(String(fassung.fassung),ts,fassung.framework_id,tenantId),
  ]);
  await audit(env.DB,auth.userId,'framework.version_published',tenantId,undefined,'curriculum_framework',fassung.framework_id,{fassung:fassung.fassung});
  return{fassung:fassung.fassung,inhalt_hash:hash,gueltig_ab:ab};
}

export async function fassungen(env:Env,auth:CoreAuthContext,tenantId:string,frameworkId:string){
  requireRole(auth,'class_admin');
  return ((await env.DB.prepare('SELECT v.id,v.fassung,v.bezeichnung,v.status,v.gueltig_ab,v.gueltig_bis,v.inhalt_hash,v.kommentar,v.veroeffentlicht_am,(SELECT COUNT(*) FROM framework_version_entries e WHERE e.framework_version_id=v.id) eintraege FROM curriculum_framework_versions v WHERE v.framework_id=? AND v.tenant_id=? ORDER BY v.fassung DESC')
    .bind(frameworkId,tenantId).all()).results)??[];
}

export async function fassungsinhalt(env:Env,auth:CoreAuthContext,tenantId:string,versionId:string){
  requireRole(auth,'class_admin');
  const kopf=await env.DB.prepare('SELECT * FROM curriculum_framework_versions WHERE id=? AND tenant_id=?').bind(versionId,tenantId).first<Record<string,unknown>>();
  if(!kopf)throw new Error('RAHMEN_FASSUNG_NICHT_GEFUNDEN');
  const eintraege=((await env.DB.prepare('SELECT art,bezug_id,code,titel,daten_json,sort_order FROM framework_version_entries WHERE framework_version_id=? ORDER BY art,sort_order,bezug_id')
    .bind(versionId).all()).results)??[];
  return{fassung:kopf,eintraege};
}

/**
 * Welche Fassung galt an diesem Tag?
 *
 * Genau diese Frage stellt sich, wenn eine Bewertung von 2024 angezeigt werden soll: nicht der
 * heutige Wortlaut, sondern der von damals.
 */
export async function gueltigeFassungZum(env:Env,tenantId:string,frameworkId:string,stichtag=nowIso()):Promise<Fassung|null>{
  return await env.DB.prepare("SELECT id,framework_id,fassung,bezeichnung,status,gueltig_ab,gueltig_bis,inhalt_hash FROM curriculum_framework_versions WHERE tenant_id=? AND framework_id=? AND status IN ('gueltig','abgeloest') AND COALESCE(gueltig_ab,'')<=? AND (gueltig_bis IS NULL OR gueltig_bis>?) ORDER BY fassung DESC LIMIT 1")
    .bind(tenantId,frameworkId,stichtag,stichtag).first<Fassung>()??null;
}

/**
 * Der Wortlaut, auf den sich eine Bewertung von damals bezog.
 *
 * Findet sich die Fassung nicht mehr, wird NICHT stillschweigend der heutige Text genommen - das
 * waere genau das Kippen, das hier verhindert werden soll.
 */
export async function wortlautZurBewertung(env:Env,tenantId:string,frameworkVersionId:string|null,art:'lernfeld'|'kompetenz',bezugId:string):Promise<{titel:string;daten:Record<string,unknown>;fassung:number|null}|null>{
  if(!frameworkVersionId)return null;
  const zeile=await env.DB.prepare('SELECT e.titel,e.daten_json,v.fassung FROM framework_version_entries e JOIN curriculum_framework_versions v ON v.id=e.framework_version_id WHERE e.framework_version_id=? AND e.art=? AND e.bezug_id=?')
    .bind(frameworkVersionId,art,bezugId).first<{titel:string;daten_json:string;fassung:number}>();
  if(!zeile)return null;
  return{titel:String(zeile.titel),daten:JSON.parse(String(zeile.daten_json)) as Record<string,unknown>,fassung:Number(zeile.fassung)};
}

/** Ist die veroeffentlichte Fassung seit dem Einfrieren unveraendert? */
export async function pruefeFassung(env:Env,auth:CoreAuthContext,tenantId:string,versionId:string){
  requireRole(auth,'class_admin');
  const kopf=await env.DB.prepare('SELECT id,inhalt_hash,status FROM curriculum_framework_versions WHERE id=? AND tenant_id=?').bind(versionId,tenantId).first<{id:string;inhalt_hash:string|null;status:string}>();
  if(!kopf)throw new Error('RAHMEN_FASSUNG_NICHT_GEFUNDEN');
  const eintraege=((await env.DB.prepare('SELECT art,bezug_id,code,titel,daten_json,sort_order FROM framework_version_entries WHERE framework_version_id=? ORDER BY art,sort_order,bezug_id')
    .bind(versionId).all<Record<string,unknown>>()).results)??[];
  const jetzt=await sha256Text(JSON.stringify(eintraege));
  return{unveraendert:!!kopf.inhalt_hash&&kopf.inhalt_hash===jetzt,erwartet:kopf.inhalt_hash,gefunden:jetzt,status:kopf.status};
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Sperren zwischen "alles" und "nichts".
//
// Eine Sorgeverknuepfung war bisher ein Schalter: an oder aus. Die Faelle, um die es rechtlich
// geht, liegen dazwischen - der beschraenkte Umgang, die Auskunftssperre, die getrennten
// Haushalte. Diese Datei fuehrt die Sperren und setzt sie SERVERSEITIG durch: die Oberfaeche ist
// kein Schutz, sie ist nur die Anzeige.
//
// Grundsatz: fail closed. Ist eine Sperre aktiv und ihr Umfang deckt den angefragten Bereich, gibt
// es die Daten nicht - auch nicht "nur zur Ansicht", auch nicht gekuerzt.

export const BEREICHE=['anwesenheit','noten','abwesenheiten','kontaktdaten','stundenplan','dokumente','kommunikation'] as const;
export type Bereich=(typeof BEREICHE)[number];
export const ARTEN=['sorgerechtsbeschraenkung','auskunftssperre','kontaktverbot'] as const;

export type Sperre={id:string;art:string;umfang:string;aktenzeichen:string|null;gueltig_bis:string|null;gegen_user_id:string|null};

const clean=(v:unknown,n=500)=>safeString(v,n);

function umfangLesen(roh:unknown):string{
  const text=String(roh??'alle').trim().toLowerCase();
  if(!text||text==='alle')return 'alle';
  const teile=text.split(',').map(x=>x.trim()).filter(Boolean);
  if(!teile.length)return 'alle';
  for(const t of teile)if(!(BEREICHE as readonly string[]).includes(t))throw new Error('RESTRICTION_SCOPE_INVALID');
  return [...new Set(teile)].join(',');
}

/**
 * Deckt diese Sperre den angefragten Bereich?
 *
 * Ohne Bereich ist die Frage "gilt sie fuer den Zugang als Ganzes" - und die beantwortet nur eine
 * Sperre ueber alle Bereiche mit ja. Eine Beschraenkung auf Noten darf den Elternzugang nicht
 * insgesamt schliessen; sie nimmt die Noten heraus, mehr nicht.
 */
export function deckt(sperre:{umfang:string},bereich?:Bereich):boolean{
  const u=String(sperre.umfang||'alle');
  if(!bereich)return u==='alle';
  return u==='alle'||u.split(',').includes(bereich);
}

/**
 * Alle aktiven Sperren einer Person - in EINER Abfrage.
 *
 * Die Alternative waere eine Abfrage je Bereich und je Sorgeberechtigtem. Bei einer Klassenliste
 * mit dreissig Kindern und zwei Elternteilen je Kind waeren das sechzig statt einer.
 */
export async function sperrenFuerPersonen(env:Env,tenantId:string,personIds:string[],stichtag=nowIso()):Promise<Map<string,Sperre[]>>{
  const karte=new Map<string,Sperre[]>();
  const ids=[...new Set(personIds.filter(Boolean))];
  if(!ids.length)return karte;
  const marks=ids.map(()=>'?').join(',');
  const tag=stichtag.slice(0,10);
  const rows=(await env.DB.prepare(`SELECT id,betroffene_person,art,umfang,aktenzeichen,gueltig_bis,gegen_user_id FROM access_restrictions WHERE tenant_id=? AND status='aktiv' AND betroffene_person IN (${marks}) AND substr(gueltig_ab,1,10)<=? AND (gueltig_bis IS NULL OR substr(gueltig_bis,1,10)>=?)`).bind(tenantId,...ids,tag,tag).all<Sperre&{betroffene_person:string}>()).results??[];
  for(const r of rows){const liste=karte.get(r.betroffene_person)??[];liste.push({id:r.id,art:r.art,umfang:r.umfang,aktenzeichen:r.aktenzeichen,gueltig_bis:r.gueltig_bis,gegen_user_id:r.gegen_user_id});karte.set(r.betroffene_person,liste);}
  return karte;
}

/**
 * Darf dieser Zugriff stattfinden?
 *
 * Wirft, wenn eine Sperre greift. Der Fehler nennt weder das Aktenzeichen noch die Person, die die
 * Sperre veranlasst hat - das waere selbst eine Auskunft ueber einen geschuetzten Vorgang.
 */
export async function pruefeZugriff(env:Env,tenantId:string,betroffenePerson:string,zugreifer:string,bereich?:Bereich,stichtag=nowIso()):Promise<void>{
  const karte=await sperrenFuerPersonen(env,tenantId,[betroffenePerson],stichtag);
  const sperren=karte.get(betroffenePerson)??[];
  for(const s of sperren){
    if(s.gegen_user_id!==null&&s.gegen_user_id!==zugreifer)continue;
    // Eine Auskunftssperre gegen alle Dritten schuetzt die Anschrift, nicht das Verhaeltnis selbst:
    // sie darf einem Sorgeberechtigten nicht den Zugang zum eigenen Kind nehmen.
    if(s.art==='auskunftssperre'&&s.gegen_user_id===null){if(bereich==='kontaktdaten')throw new Error('ACCESS_RESTRICTED');continue;}
    // Ein Kontaktverbot gilt immer ganz. Es teilweise gelten zu lassen hiesse, es nicht zu haben.
    if(s.art==='kontaktverbot')throw new Error('ACCESS_RESTRICTED');
    if(deckt(s,bereich))throw new Error('ACCESS_RESTRICTED');
  }
}

/** Wie pruefeZugriff, aber ohne Wurf: fuer Sichten, die Teile ausblenden statt ganz zu schliessen. */
export async function gesperrteBereiche(env:Env,tenantId:string,betroffenePerson:string,zugreifer:string,stichtag=nowIso()):Promise<Set<string>>{
  const sperren=(await sperrenFuerPersonen(env,tenantId,[betroffenePerson],stichtag)).get(betroffenePerson)??[];
  const raus=new Set<string>();
  for(const s of sperren){
    if(s.gegen_user_id!==null&&s.gegen_user_id!==zugreifer)continue;
    if(s.art==='auskunftssperre'&&s.gegen_user_id===null){raus.add('kontaktdaten');continue;}
    if(String(s.umfang)==='alle')for(const b of BEREICHE)raus.add(b);
    else for(const b of String(s.umfang).split(','))raus.add(b);
  }
  return raus;
}

export async function verhaengeBeschraenkung(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const person=clean(input.betroffene_person,120),art=clean(input.art,40),gegen=clean(input.gegen_user_id,120)||null;
  const grundlage=clean(input.rechtsgrundlage,500),aktenzeichen=clean(input.aktenzeichen,120)||null;
  if(!person||!(ARTEN as readonly string[]).includes(art))throw new Error('RESTRICTION_INPUT_INVALID');
  // Eine Sperre ohne Rechtsgrundlage ist eine Meinung. Sie greift in ein Elternrecht ein und muss
  // belegt sein - im Zweifel vor Gericht.
  if(grundlage.length<10)throw new Error('RESTRICTION_LEGAL_BASIS_REQUIRED');
  const umfang=umfangLesen(input.umfang);
  const ab=clean(input.gueltig_ab,40)||nowIso(),bis=clean(input.gueltig_bis,40)||null;
  if(bis&&bis<=ab)throw new Error('RESTRICTION_PERIOD_INVALID');
  const betroffen=await env.DB.prepare("SELECT 1 AS ok FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'").bind(tenantId,person).first();
  if(!betroffen)throw new Error('RESTRICTION_PERSON_NOT_FOUND');
  if(gegen){const g=await env.DB.prepare("SELECT 1 AS ok FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'").bind(tenantId,gegen).first();if(!g)throw new Error('RESTRICTION_PERSON_NOT_FOUND');}
  const sid=id('asp_'),ts=nowIso();
  await env.DB.prepare('INSERT INTO access_restrictions(id,tenant_id,betroffene_person,art,gegen_user_id,umfang,rechtsgrundlage,aktenzeichen,gueltig_ab,gueltig_bis,status,angelegt_von,angelegt_am,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(sid,tenantId,person,art,gegen,umfang,grundlage,aktenzeichen,ab,bis,'aktiv',auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'access_restriction.placed',tenantId,undefined,'access_restriction',sid,{art,umfang,gegen:!!gegen});
  return{id:sid,art,umfang};
}

export async function hebeBeschraenkungAuf(env:Env,auth:CoreAuthContext,tenantId:string,restrictionId:string,grund:unknown){
  requireRole(auth,'tenant_admin');
  const text=clean(grund,500);
  if(text.length<10)throw new Error('RESTRICTION_LIFT_REASON_REQUIRED');
  const ts=nowIso();
  const r=await env.DB.prepare("UPDATE access_restrictions SET status='aufgehoben',aufgehoben_von=?,aufgehoben_am=?,aufhebungsgrund=?,updated_at=? WHERE id=? AND tenant_id=? AND status='aktiv'")
    .bind(auth.userId,ts,text,ts,restrictionId,tenantId).run();
  if(!r.meta?.changes)throw new Error('RESTRICTION_NOT_FOUND');
  await audit(env.DB,auth.userId,'access_restriction.lifted',tenantId,undefined,'access_restriction',restrictionId);
  return{aufgehoben:true};
}

export async function listeBeschraenkungen(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return (await env.DB.prepare('SELECT r.id,r.betroffene_person,p.display_name AS betroffene_name,r.art,r.gegen_user_id,g.display_name AS gegen_name,r.umfang,r.aktenzeichen,r.gueltig_ab,r.gueltig_bis,r.status FROM access_restrictions r JOIN users p ON p.id=r.betroffene_person LEFT JOIN users g ON g.id=r.gegen_user_id WHERE r.tenant_id=? ORDER BY r.status,r.angelegt_am DESC')
    .bind(tenantId).all()).results??[];
}

export type Empfaengergruppe={haushalt:string;empfaenger:{user_id:string;display_name:string;verhaeltnis:string}[]};

/**
 * Die Sorgeberechtigten eines Kindes - nach Haushalten getrennt und um Sperren bereinigt.
 *
 * Getrennte Haushalte heisst nicht "beide anschreiben", sondern "beide getrennt anschreiben". Ein
 * gemeinsamer Verteiler gibt die Anschrift des einen an den anderen weiter, und das laesst sich
 * nicht zuruecknehmen. Deshalb liefert diese Funktion Gruppen, nie eine Liste.
 */
export async function empfaengergruppenFuerKind(env:Env,tenantId:string,kindId:string,stichtag=nowIso()):Promise<Empfaengergruppe[]>{
  const tag=stichtag.slice(0,10);
  const rows=(await env.DB.prepare("SELECT g.guardian_user_id,u.display_name,g.verhaeltnis,COALESCE(g.haushalt,'haushalt_1') AS haushalt FROM guardianships g JOIN users u ON u.id=g.guardian_user_id WHERE g.tenant_id=? AND g.participant_user_id=? AND g.status='aktiv' AND u.status='active' AND (g.gueltig_bis IS NULL OR substr(g.gueltig_bis,1,10)>=? OR g.einwilligung_der_person_am IS NOT NULL) ORDER BY g.haushalt,u.display_name")
    .bind(tenantId,kindId,tag).all<{guardian_user_id:string;display_name:string;verhaeltnis:string;haushalt:string}>()).results??[];
  if(!rows.length)return[];
  const sperren=(await sperrenFuerPersonen(env,tenantId,[kindId],stichtag)).get(kindId)??[];
  const gruppen=new Map<string,Empfaengergruppe>();
  for(const r of rows){
    // Kontaktverbot und eine Sperre, die die Kommunikation umfasst, schliessen diese Person aus -
    // nicht nur in der Anzeige, sondern im Verteiler selbst.
    const gesperrt=sperren.some(s=>(s.gegen_user_id===null||s.gegen_user_id===r.guardian_user_id)&&(s.art==='kontaktverbot'||deckt(s,'kommunikation'))&&s.art!=='auskunftssperre');
    if(gesperrt)continue;
    const gruppe=gruppen.get(r.haushalt)??{haushalt:r.haushalt,empfaenger:[]};
    gruppe.empfaenger.push({user_id:r.guardian_user_id,display_name:r.display_name,verhaeltnis:r.verhaeltnis});
    gruppen.set(r.haushalt,gruppe);
  }
  return [...gruppen.values()];
}

/**
 * Sorgeberechtigte vieler Kinder auf einmal - fuer den Versand an eine ganze Klasse.
 *
 * Eine Abfrage fuer alle Kinder, eine fuer alle Sperren. Sonst waere jeder Klassenversand eine
 * Schleife mit zwei Abfragen je Kind.
 */
export async function sorgeberechtigteFuerTeilnehmer(env:Env,tenantId:string,kindIds:string[],stichtag=nowIso()):Promise<string[]>{
  const ids=[...new Set(kindIds.filter(Boolean))];
  if(!ids.length)return[];
  const marks=ids.map(()=>'?').join(','),tag=stichtag.slice(0,10);
  const rows=(await env.DB.prepare(`SELECT DISTINCT g.guardian_user_id,g.participant_user_id FROM guardianships g JOIN users u ON u.id=g.guardian_user_id JOIN tenant_users tu ON tu.tenant_id=g.tenant_id AND tu.user_id=g.guardian_user_id WHERE g.tenant_id=? AND g.participant_user_id IN (${marks}) AND g.status='aktiv' AND u.status='active' AND tu.status='active' AND (g.gueltig_bis IS NULL OR substr(g.gueltig_bis,1,10)>=? OR g.einwilligung_der_person_am IS NOT NULL)`).bind(tenantId,...ids,tag).all<{guardian_user_id:string;participant_user_id:string}>()).results??[];
  if(!rows.length)return[];
  const sperren=await sperrenFuerPersonen(env,tenantId,ids,stichtag);
  const raus=new Set<string>();
  for(const r of rows){
    const liste=sperren.get(r.participant_user_id)??[];
    const gesperrt=liste.some(s=>(s.gegen_user_id===null||s.gegen_user_id===r.guardian_user_id)&&s.art!=='auskunftssperre'&&(s.art==='kontaktverbot'||deckt(s,'kommunikation')));
    if(!gesperrt)raus.add(r.guardian_user_id);
  }
  return [...raus];
}

/**
 * Wer steht unter einem aktiven Kontaktverbot - und ist nur als Sorgeberechtigter im Mandanten?
 *
 * Die Abgrenzung ist eine bewusste Entscheidung und keine technische: ein Kontaktverbot schuetzt
 * eine bestimmte Person, nicht die Welt. Eine allgemeine Mitteilung des Traegers ist davon nicht
 * erfasst - eine KRISENMELDUNG aber schon, denn sie sagt regelmaessig, wo Menschen gerade sind
 * ("Evakuierung, Betreuung in der Turnhalle"). Deshalb faellt hier zu, und zwar nur fuer die, die
 * ausschliesslich ueber die Sorgeverknuepfung im Mandanten sind. Wer dort selbst lernt oder
 * arbeitet, bleibt erreichbar - sein eigenes Recht auf die Warnung wiegt schwerer.
 */
export async function ausgeschlosseneKontakte(env:Env,tenantId:string):Promise<Set<string>>{
  const zeilen=((await env.DB.prepare("SELECT DISTINCT r.gegen_user_id AS person FROM access_restrictions r WHERE r.tenant_id=? AND r.status='aktiv' AND r.art='kontaktverbot' AND r.gegen_user_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM memberships m WHERE m.tenant_id=r.tenant_id AND m.user_id=r.gegen_user_id AND m.role<>'guest')")
    .bind(tenantId).all<{person:string}>()).results)??[];
  return new Set(zeilen.map(z=>String(z.person)));
}

export async function setzeHaushalt(env:Env,auth:CoreAuthContext,tenantId:string,guardianshipId:string,haushalt:unknown){
  requireRole(auth,'tenant_admin');
  const wert=clean(haushalt,60)||null;
  const r=await env.DB.prepare("UPDATE guardianships SET haushalt=?,updated_at=? WHERE id=? AND tenant_id=? AND status='aktiv'").bind(wert,nowIso(),guardianshipId,tenantId).run();
  if(!r.meta?.changes)throw new Error('GUARDIANSHIP_NOT_FOUND');
  await audit(env.DB,auth.userId,'guardianship.household_set',tenantId,undefined,'guardianship',guardianshipId,{haushalt:wert});
  return{gespeichert:true};
}

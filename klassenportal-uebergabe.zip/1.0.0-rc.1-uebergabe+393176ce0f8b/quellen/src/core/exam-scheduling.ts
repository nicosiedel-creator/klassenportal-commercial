import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Pruefungsplanung: Raum, Aufsicht, Zeit (P5).
//
// Eine Pruefung war bis hierher ein Termin mit einem Raumnamen als Freitext. Was am
// Pruefungstag wirklich zaehlt - passt die Gruppe in den Raum, steht eine Aufsicht darin,
// reicht die gebuchte Zeit fuer den laengsten Nachteilsausgleich - stand nirgends.
//
// Der Punkt, an dem dieses Modul verweigert, ist die FREIGABE, nicht der Pruefungstag. Ein
// Entwurf darf unvollstaendig sein; freigegeben wird nur, was durchfuehrbar ist. Und freigegeben
// heisst festgeschrieben: die Zeitzuschlaege stehen dann je Person in der Platzliste, damit ein
// spaeter geaenderter Bescheid nicht rueckwirkend aendert, wie lange jemand sitzen durfte.

const clean=(v:unknown,n=200)=>safeString(v,n);
export const ROLLEN=['pruefungsleitung','aufsicht','ergaenzende_aufsicht'] as const;
// Mehr als das plant niemand als eine Sitzung; die Grenze haelt zugleich das Subrequest-Budget.
const HOECHSTPLAETZE=400;

type Sitzung={id:string;exam_id:string;resource_id:string;beginnt_am:string;endet_am:string;plaetze:number;art:string;status:string};

const zeit=(s:string)=>Date.parse(s);
function pruefeZeitraum(von:string,bis:string){
  const a=zeit(von),b=zeit(bis);
  if(!Number.isFinite(a)||!Number.isFinite(b))throw new Error('PRUEFPLAN_ZEIT_UNGUELTIG');
  if(b<=a)throw new Error('PRUEFPLAN_ZEIT_UNGUELTIG');
  return{a,b};
}

/**
 * Sitzung anlegen: eine Pruefung in einem konkreten Raum zu einer konkreten Zeit.
 *
 * Schon hier wird der Raum geprueft - nicht erst bei der Freigabe. Wer einen gesperrten oder
 * doppelt belegten Raum eintraegt, plant sonst eine Stunde lang um einen Fehler herum.
 */
export async function legeSitzungAn(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const examId=clean(input.exam_id,120),resourceId=clean(input.resource_id,120);
  const beginn=clean(input.beginnt_am,40),ende=clean(input.endet_am,40);
  pruefeZeitraum(beginn,ende);
  const plaetze=Math.trunc(Number(input.plaetze??0));
  if(!Number.isFinite(plaetze)||plaetze<1||plaetze>HOECHSTPLAETZE)throw new Error('PRUEFPLAN_PLAETZE_UNGUELTIG');
  const art=clean(input.art,30)||'regulaer';
  if(!['regulaer','einzelraum','nachholtermin'].includes(art))throw new Error('PRUEFPLAN_ART_UNGUELTIG');
  const pruefung=await env.DB.prepare('SELECT id,course_id FROM exams WHERE id=? AND tenant_id=?').bind(examId,tenantId).first<{id:string;course_id:string}>();
  if(!pruefung)throw new Error('PRUEFPLAN_PRUEFUNG_NICHT_GEFUNDEN');
  const raum=await env.DB.prepare("SELECT id,status,capacity FROM planning_resources WHERE id=? AND tenant_id=? AND resource_type IN ('room','online_room')")
    .bind(resourceId,tenantId).first<{id:string;status:string;capacity:number|null}>();
  if(!raum)throw new Error('PRUEFPLAN_RAUM_NICHT_GEFUNDEN');
  if(raum.status!=='active')throw new Error('PRUEFPLAN_RAUM_GESPERRT');
  // Ein Einzelraum-Nachteilsausgleich ist genau ein Platz. Zehn Plaetze im "Einzelraum" waeren
  // die Umgehung des Bescheids.
  if(art==='einzelraum'&&plaetze!==1)throw new Error('PRUEFPLAN_EINZELRAUM_EIN_PLATZ');
  if(raum.capacity!==null&&plaetze>raum.capacity)throw new Error('PRUEFPLAN_RAUM_ZU_KLEIN');
  await pruefeRaumFrei(env,tenantId,resourceId,beginn,ende,null);
  const ts=nowIso(),sid=id('psz_');
  await env.DB.prepare('INSERT INTO exam_sittings(id,tenant_id,exam_id,resource_id,beginnt_am,endet_am,plaetze,art,status,hinweis,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(sid,tenantId,examId,resourceId,beginn,ende,plaetze,art,'entwurf',clean(input.hinweis,1000)||null,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'exam_sitting.created',tenantId,pruefung.course_id,'exam_sitting',sid,{art,plaetze});
  return{id:sid,status:'entwurf'};
}

/**
 * Ist der Raum in diesem Zeitfenster frei?
 *
 * Drei Quellen, eine Antwort: andere Sitzungen, Unterricht und eingetragene Sperrungen. Die
 * Ueberschneidungsbedingung ist bewusst offen an den Raendern - wer um 11:00 endet, blockiert
 * den 11:00-Beginn nicht.
 */
async function pruefeRaumFrei(env:Env,tenantId:string,resourceId:string,von:string,bis:string,ausserSitzung:string|null){
  const belegt=await env.DB.prepare(`SELECT 1 AS ok FROM exam_sittings WHERE tenant_id=? AND resource_id=? AND status<>'abgesagt' AND id<>COALESCE(?,'') AND beginnt_am<? AND endet_am>? LIMIT 1`)
    .bind(tenantId,resourceId,ausserSitzung,bis,von).first();
  if(belegt)throw new Error('PRUEFPLAN_RAUM_BELEGT');
  const gesperrt=await env.DB.prepare('SELECT 1 AS ok FROM planning_resource_unavailability WHERE tenant_id=? AND resource_id=? AND starts_at<? AND ends_at>? LIMIT 1')
    .bind(tenantId,resourceId,bis,von).first();
  if(gesperrt)throw new Error('PRUEFPLAN_RAUM_GESPERRT');
}

/**
 * Plaetze besetzen.
 *
 * Der Zeitzuschlag kommt aus dem Nachteilsausgleich und wird HIER in Minuten umgerechnet und
 * festgeschrieben. Ein Bescheid, der morgen geaendert wird, aendert nicht, wie lange jemand
 * heute sitzen durfte.
 */
export async function besetzePlaetze(env:Env,auth:CoreAuthContext,tenantId:string,sittingId:string,userIds:string[]){
  requireRole(auth,'class_admin');
  const s=await ladeSitzung(env,tenantId,sittingId);
  if(s.status!=='entwurf')throw new Error('PRUEFPLAN_BEREITS_FREIGEGEBEN');
  const personen=[...new Set(userIds.map(v=>clean(v,120)).filter(Boolean))];
  if(!personen.length)throw new Error('PRUEFPLAN_KEINE_TEILNEHMER');
  if(personen.length>s.plaetze)throw new Error('PRUEFPLAN_KAPAZITAET_UEBERSCHRITTEN');
  const pruefung=await env.DB.prepare('SELECT course_id FROM exams WHERE id=? AND tenant_id=?').bind(s.exam_id,tenantId).first<{course_id:string}>();
  if(!pruefung)throw new Error('PRUEFPLAN_PRUEFUNG_NICHT_GEFUNDEN');
  const platzhalter=personen.map(()=>'?').join(',');
  // Eine Abfrage fuer die Mitgliedschaft, eine fuer die Nachteilsausgleiche - nicht je Person.
  const mitglieder=new Set((((await env.DB.prepare(`SELECT user_id FROM memberships WHERE tenant_id=? AND course_id=? AND role='participant' AND user_id IN (${platzhalter})`)
    .bind(tenantId,pruefung.course_id,...personen).all<{user_id:string}>()).results)??[]).map(r=>r.user_id));
  for(const p of personen)if(!mitglieder.has(p))throw new Error('PRUEFPLAN_NICHT_IM_KURS');
  const dauerMin=Math.round((zeit(s.endet_am)-zeit(s.beginnt_am))/60000);
  const ausgleiche=(((await env.DB.prepare(`SELECT user_id,MAX(zeitzuschlag_prozent) AS prozent,MAX(CASE WHEN format='einzelraum' THEN 1 ELSE 0 END) AS einzelraum FROM exam_accommodations WHERE tenant_id=? AND course_id=? AND status='aktiv' AND user_id IN (${platzhalter}) GROUP BY user_id`)
    .bind(tenantId,pruefung.course_id,...personen).all<{user_id:string;prozent:number;einzelraum:number}>()).results)??[]);
  const nach=new Map(ausgleiche.map(r=>[r.user_id,r]));
  // Wer einen Einzelraum zugesprochen bekommen hat, sitzt nicht mit anderen. Das ist der ganze
  // Sinn des Bescheids; ein "geht schon" waere seine Aushebelung.
  if(personen.length>1)for(const p of personen)if(Number(nach.get(p)?.einzelraum??0)===1)throw new Error('PRUEFPLAN_EINZELRAUM_ERFORDERLICH');
  const ts=nowIso(),anweisungen=[env.DB.prepare('DELETE FROM exam_sitting_seats WHERE sitting_id=? AND tenant_id=?').bind(sittingId,tenantId)];
  let nr=0;
  for(const p of personen){
    const prozent=Math.max(0,Math.trunc(Number(nach.get(p)?.prozent??0)));
    const zuschlag=Math.round(dauerMin*prozent/100);
    const endet=new Date(zeit(s.beginnt_am)+(dauerMin+zuschlag)*60000).toISOString();
    anweisungen.push(env.DB.prepare('INSERT INTO exam_sitting_seats(id,tenant_id,sitting_id,user_id,platz_nr,zeitzuschlag_minuten,endet_am,created_at) VALUES(?,?,?,?,?,?,?,?)')
      .bind(id('psp_'),tenantId,sittingId,p,++nr,zuschlag,endet,ts));
  }
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  await audit(env.DB,auth.userId,'exam_sitting.seated',tenantId,pruefung.course_id,'exam_sitting',sittingId,{anzahl:personen.length});
  return{besetzt:personen.length,plaetze:s.plaetze};
}

/**
 * Aufsicht einteilen.
 *
 * Befangenheit wird hier geprueft, nicht spaeter im Widerspruch: wer selbst mitschreibt oder
 * Sorgeberechtigter einer pruefenden Person ist, beaufsichtigt sie nicht.
 */
export async function teileAufsichtEin(env:Env,auth:CoreAuthContext,tenantId:string,sittingId:string,userId:string,rolle='aufsicht'){
  requireRole(auth,'class_admin');
  const s=await ladeSitzung(env,tenantId,sittingId);
  if(s.status==='abgesagt')throw new Error('PRUEFPLAN_ABGESAGT');
  const person=clean(userId,120);
  if(!(ROLLEN as readonly string[]).includes(rolle))throw new Error('PRUEFPLAN_ROLLE_UNGUELTIG');
  const gehoert=await env.DB.prepare("SELECT 1 AS ok FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'").bind(tenantId,person).first();
  if(!gehoert)throw new Error('PRUEFPLAN_AUFSICHT_NICHT_GEFUNDEN');
  // Eine Aufsicht steht in einem Raum, nicht in zweien. Geprueft wird ueber alle Sitzungen des
  // Traegers, nicht nur ueber diese Pruefung.
  const doppelt=await env.DB.prepare(`SELECT 1 AS ok FROM exam_supervisions a JOIN exam_sittings z ON z.id=a.sitting_id
    WHERE a.tenant_id=? AND a.user_id=? AND a.sitting_id<>? AND z.status<>'abgesagt' AND z.beginnt_am<? AND z.endet_am>? LIMIT 1`)
    .bind(tenantId,person,sittingId,s.endet_am,s.beginnt_am).first();
  if(doppelt)throw new Error('PRUEFPLAN_AUFSICHT_DOPPELT');
  const befangen=await env.DB.prepare(`SELECT 1 AS ok FROM exam_sitting_seats p WHERE p.sitting_id=? AND p.tenant_id=? AND (p.user_id=? OR EXISTS(
      SELECT 1 FROM guardianships g WHERE g.tenant_id=p.tenant_id AND g.status='aktiv' AND g.guardian_user_id=? AND g.participant_user_id=p.user_id)) LIMIT 1`)
    .bind(sittingId,tenantId,person,person).first();
  if(befangen)throw new Error('PRUEFPLAN_AUFSICHT_BEFANGEN');
  const ts=nowIso();
  await env.DB.prepare('INSERT INTO exam_supervisions(id,tenant_id,sitting_id,user_id,rolle,eingeteilt_von,created_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(sitting_id,user_id) DO UPDATE SET rolle=excluded.rolle')
    .bind(id('pau_'),tenantId,sittingId,person,rolle,auth.userId,ts).run();
  await audit(env.DB,auth.userId,'exam_sitting.supervisor_assigned',tenantId,undefined,'exam_sitting',sittingId,{rolle});
  return{eingeteilt:true,rolle};
}

/** Die Aufsicht bestaetigt selbst - eine fremde Zusage ist keine. */
export async function bestaetigeAufsicht(env:Env,auth:CoreAuthContext,tenantId:string,sittingId:string){
  const zeile=await env.DB.prepare('SELECT id FROM exam_supervisions WHERE sitting_id=? AND tenant_id=? AND user_id=?').bind(sittingId,tenantId,auth.userId).first<{id:string}>();
  if(!zeile)throw new Error('PRUEFPLAN_AUFSICHT_NICHT_EINGETEILT');
  await env.DB.prepare('UPDATE exam_supervisions SET bestaetigt_am=? WHERE id=? AND tenant_id=?').bind(nowIso(),zeile.id,tenantId).run();
  return{bestaetigt:true};
}

async function ladeSitzung(env:Env,tenantId:string,sittingId:string):Promise<Sitzung>{
  const s=await env.DB.prepare('SELECT id,exam_id,resource_id,beginnt_am,endet_am,plaetze,art,status FROM exam_sittings WHERE id=? AND tenant_id=?')
    .bind(clean(sittingId,120),tenantId).first<Sitzung>();
  if(!s)throw new Error('PRUEFPLAN_SITZUNG_NICHT_GEFUNDEN');
  return s;
}

/**
 * Freigabe - der Punkt, an dem das System verweigert.
 *
 * Alles, was hier scheitert, waere sonst am Pruefungstag gescheitert, und dort kostet es die
 * Pruefung. Die Pruefungen laufen in fester Reihenfolge, damit die Meldung den ersten echten
 * Grund nennt und nicht irgendeinen.
 */
export async function gibSitzungFrei(env:Env,auth:CoreAuthContext,tenantId:string,sittingId:string){
  requireRole(auth,'class_admin');
  const s=await ladeSitzung(env,tenantId,sittingId);
  if(s.status==='freigegeben')throw new Error('PRUEFPLAN_BEREITS_FREIGEGEBEN');
  if(s.status==='abgesagt')throw new Error('PRUEFPLAN_ABGESAGT');
  const plaetze=((await env.DB.prepare('SELECT user_id,endet_am FROM exam_sitting_seats WHERE sitting_id=? AND tenant_id=?')
    .bind(sittingId,tenantId).all<{user_id:string;endet_am:string}>()).results)??[];
  if(!plaetze.length)throw new Error('PRUEFPLAN_KEINE_TEILNEHMER');
  if(plaetze.length>s.plaetze)throw new Error('PRUEFPLAN_KAPAZITAET_UEBERSCHRITTEN');
  // Der Raum muss so lange gebucht sein, wie die laengste Person sitzt. Sonst wird der
  // Nachteilsausgleich am Pruefungstag stillschweigend gekuerzt.
  const spaetestes=plaetze.reduce((m,p)=>Math.max(m,zeit(p.endet_am)),0);
  if(spaetestes>zeit(s.endet_am))throw new Error('PRUEFPLAN_ZEIT_ZU_KURZ');
  const aufsicht=await env.DB.prepare('SELECT COUNT(*) AS n FROM exam_supervisions WHERE sitting_id=? AND tenant_id=?').bind(sittingId,tenantId).first<{n:number}>();
  if(!Number(aufsicht?.n??0))throw new Error('PRUEFPLAN_AUFSICHT_FEHLT');
  await pruefeRaumFrei(env,tenantId,s.resource_id,s.beginnt_am,s.endet_am,sittingId);
  // Niemand schreibt zwei Pruefungen gleichzeitig. Eine Abfrage ueber alle Plaetze dieser
  // Sitzung, nicht je Person.
  const ph=plaetze.map(()=>'?').join(',');
  const kollision=await env.DB.prepare(`SELECT 1 AS ok FROM exam_sitting_seats p JOIN exam_sittings z ON z.id=p.sitting_id
    WHERE p.tenant_id=? AND p.sitting_id<>? AND z.status='freigegeben' AND z.beginnt_am<? AND z.endet_am>? AND p.user_id IN (${ph}) LIMIT 1`)
    .bind(tenantId,sittingId,s.endet_am,s.beginnt_am,...plaetze.map(p=>p.user_id)).first();
  if(kollision)throw new Error('PRUEFPLAN_TEILNEHMER_DOPPELT');
  const ts=nowIso();
  await env.DB.prepare("UPDATE exam_sittings SET status='freigegeben',freigegeben_von=?,freigegeben_am=?,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(auth.userId,ts,ts,sittingId,tenantId).run();
  await audit(env.DB,auth.userId,'exam_sitting.released',tenantId,undefined,'exam_sitting',sittingId,{teilnehmer:plaetze.length});
  return{status:'freigegeben',teilnehmer:plaetze.length};
}

/** Eine Sitzung absagen gibt den Raum wieder frei - und sagt ehrlich, dass sie abgesagt ist. */
export async function sageSitzungAb(env:Env,auth:CoreAuthContext,tenantId:string,sittingId:string,grund:string){
  requireRole(auth,'class_admin');
  const s=await ladeSitzung(env,tenantId,sittingId);
  if(s.status==='abgesagt')throw new Error('PRUEFPLAN_ABGESAGT');
  const text=clean(grund,1000);
  if(text.length<10)throw new Error('PRUEFPLAN_ABSAGEGRUND_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.prepare("UPDATE exam_sittings SET status='abgesagt',hinweis=?,updated_at=? WHERE id=? AND tenant_id=?").bind(text,ts,sittingId,tenantId).run();
  await audit(env.DB,auth.userId,'exam_sitting.cancelled',tenantId,undefined,'exam_sitting',sittingId,{});
  return{status:'abgesagt'};
}

/**
 * Der Pruefungsplan einer Pruefung - fuer die Planung wie fuer den Aushang.
 *
 * Drei Abfragen fuer beliebig viele Sitzungen: Sitzungen, Plaetze, Aufsichten. Eine Abfrage je
 * Sitzung waere bei einem Pruefungstag mit 20 Raeumen schon die halbe Miete des Budgets.
 */
export async function pruefungsplan(env:Env,auth:CoreAuthContext,tenantId:string,examId:string){
  requireRole(auth,'class_admin');
  const sitzungen=((await env.DB.prepare(`SELECT z.id,z.resource_id,r.name AS raum,z.beginnt_am,z.endet_am,z.plaetze,z.art,z.status,z.hinweis
    FROM exam_sittings z JOIN planning_resources r ON r.id=z.resource_id WHERE z.tenant_id=? AND z.exam_id=? ORDER BY z.beginnt_am,r.name`)
    .bind(tenantId,clean(examId,120)).all<Record<string,unknown>>()).results)??[];
  if(!sitzungen.length)return{sitzungen:[],offen:['PRUEFPLAN_KEINE_SITZUNG']};
  const ph=sitzungen.map(()=>'?').join(','),ids=sitzungen.map(z=>String(z.id));
  const plaetze=((await env.DB.prepare(`SELECT p.sitting_id,p.user_id,u.display_name,p.platz_nr,p.zeitzuschlag_minuten,p.endet_am
    FROM exam_sitting_seats p JOIN users u ON u.id=p.user_id WHERE p.tenant_id=? AND p.sitting_id IN (${ph}) ORDER BY p.platz_nr`)
    .bind(tenantId,...ids).all<Record<string,unknown>>()).results)??[];
  const aufsichten=((await env.DB.prepare(`SELECT a.sitting_id,a.user_id,u.display_name,a.rolle,a.bestaetigt_am
    FROM exam_supervisions a JOIN users u ON u.id=a.user_id WHERE a.tenant_id=? AND a.sitting_id IN (${ph}) ORDER BY a.rolle`)
    .bind(tenantId,...ids).all<Record<string,unknown>>()).results)??[];
  const offen:string[]=[];
  for(const z of sitzungen){
    if(z.status==='abgesagt')continue;
    const eigenePlaetze=plaetze.filter(p=>p.sitting_id===z.id),eigeneAufsicht=aufsichten.filter(a=>a.sitting_id===z.id);
    if(!eigenePlaetze.length)offen.push(`PRUEFPLAN_KEINE_TEILNEHMER:${z.id}`);
    if(!eigeneAufsicht.length)offen.push(`PRUEFPLAN_AUFSICHT_FEHLT:${z.id}`);
    else if(!eigeneAufsicht.some(a=>a.bestaetigt_am))offen.push(`PRUEFPLAN_AUFSICHT_UNBESTAETIGT:${z.id}`);
    if(eigenePlaetze.some(p=>zeit(String(p.endet_am))>zeit(String(z.endet_am))))offen.push(`PRUEFPLAN_ZEIT_ZU_KURZ:${z.id}`);
  }
  return{sitzungen:sitzungen.map(z=>({...z,
    teilnehmer:plaetze.filter(p=>p.sitting_id===z.id),
    aufsicht:aufsichten.filter(a=>a.sitting_id===z.id)})),offen};
}

/** Was steht heute fuer mich an - als Aufsicht? */
export async function meineAufsichten(env:Env,auth:CoreAuthContext,tenantId:string){
  return ((await env.DB.prepare(`SELECT z.id,e.title,r.name AS raum,z.beginnt_am,z.endet_am,z.status,a.rolle,a.bestaetigt_am
    FROM exam_supervisions a JOIN exam_sittings z ON z.id=a.sitting_id JOIN exams e ON e.id=z.exam_id JOIN planning_resources r ON r.id=z.resource_id
    WHERE a.tenant_id=? AND a.user_id=? AND z.status<>'abgesagt' ORDER BY z.beginnt_am LIMIT 200`)
    .bind(tenantId,auth.userId).all()).results)??[];
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { registriereKiZiel, stelleKiAuftragEin } from './ai-workload.js';
import { markiereKiInhalt } from './ai-governance.js';
import { id, nowIso, safeString } from './utils.js';

// Multimodale Aufgabenfabrik und KI-Medienproduktion (K13).
//
// Aufgaben entstehen von Hand. Das ist nicht das Problem - das Problem ist, dass eine
// Lehrkraft fuer vierzig Lernfelder Aufgaben braucht und die Zeit dafuer nicht hat.
//
// Eine Fabrik hilft dabei nur unter drei Bedingungen, und alle drei stehen hier im Code:
//  - Es entstehen ENTWUERFE. Nie eine fertige Aufgabe, nie eine Frage, die schon in einem
//    Quiz steht. Die Uebernahme ist ein eigener, bewusster Schritt.
//  - Jeder Entwurf traegt seine Herkunft: Modell, Zeitpunkt, Eingabehash - ueber dieselbe
//    Provenienz, die auch fuer Zeugnistexte gilt.
//  - Freigeben darf nicht, wer erzeugt hat. Bei einer Pruefungsfrage ist das keine Formalie:
//    sonst prueft niemand, was die Maschine geschrieben hat.

const clean=(v:unknown,n=8000)=>safeString(v,n);
export const ENTWURFSARTEN=['aufgabe','quizfrage','lernmaterial','zusammenfassung','bild'] as const;
export const QUELLARTEN=['curriculum_item','competency','media_asset','dokument','freitext'] as const;
// Mehr Entwuerfe auf einmal erzeugt niemand sinnvoll - und jeder kostet einen KI-Aufruf, der
// gegen das Unteranfragenbudget des Aufrufs zaehlt.
export const HOECHSTMENGE=5;

/**
 * Entwuerfe erzeugen.
 *
 * Die Datenklasse geht ausdruecklich an das Gateway. Ein Lernfeldtext ist 'intern'; sobald
 * jemand Teilnehmerdaten hineinkopiert, muss er das sagen - und dann entscheidet die
 * Modellkette, ob ueberhaupt ein zugelassenes Modell existiert.
 */
export async function erzeugeEntwuerfe(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const art=clean(input.art,30);
  if(!(ENTWURFSARTEN as readonly string[]).includes(art))throw new Error('FABRIK_ART_UNGUELTIG');
  const quelleTyp=clean(input.quelle_typ,40);
  if(!(QUELLARTEN as readonly string[]).includes(quelleTyp))throw new Error('FABRIK_QUELLE_UNGUELTIG');
  const auftrag=clean(input.auftrag,4000);
  if(auftrag.length<10)throw new Error('FABRIK_AUFTRAG_ERFORDERLICH');
  // Die Datenklasse kommt NICHT mehr aus der Anfrage. Sie stand dort, und wer 'oeffentlich'
  // hineinschrieb, bekam ein Modell ausserhalb der EU - auch wenn im Auftrag Namen standen. Die
  // Einstufung eines Zwecks gehoert ins Register und nicht an die Stelle, die absendet.
  const menge=Math.trunc(Number(input.menge??1));
  if(!Number.isFinite(menge)||menge<1||menge>HOECHSTMENGE)throw new Error('FABRIK_MENGE_UNGUELTIG');

  // Die Quelle muss es geben. Ein Entwurf "zu Lernfeld 7", das es nicht gibt, ist der Anfang
  // einer Aufgabensammlung, die zu nichts passt.
  let quellText='';
  const quelleId=clean(input.quelle_id,120)||null;
  if(quelleTyp==='curriculum_item'){
    const z=await env.DB.prepare('SELECT title,description FROM curriculum_items WHERE id=? AND tenant_id=?').bind(quelleId,tenantId).first<{title:string;description:string|null}>();
    if(!z)throw new Error('FABRIK_QUELLE_NICHT_GEFUNDEN');
    quellText=`${z.title}\n${z.description??''}`;
  }else if(quelleTyp==='competency'){
    const z=await env.DB.prepare('SELECT title,beschreibung FROM competencies WHERE id=? AND tenant_id=?').bind(quelleId,tenantId).first<{title:string;beschreibung:string|null}>();
    if(!z)throw new Error('FABRIK_QUELLE_NICHT_GEFUNDEN');
    quellText=`${z.title}\n${z.beschreibung??''}`;
  }else if(quelleTyp==='media_asset'){
    const z=await env.DB.prepare('SELECT titel,beschreibung FROM media_assets WHERE id=? AND tenant_id=?').bind(quelleId,tenantId).first<{titel:string;beschreibung:string|null}>();
    if(!z)throw new Error('FABRIK_QUELLE_NICHT_GEFUNDEN');
    quellText=`${z.titel}\n${z.beschreibung??''}`;
  }else quellText=clean(input.quelltext,8000);
  if(!quellText.trim())throw new Error('FABRIK_QUELLE_LEER');

  // Hier wartet niemand mehr.
  //
  // Vorher lief diese Schleife im Vordergrund: bis zu fuenf Modellaufrufe nacheinander, je bis zu
  // zwanzig Sekunden Zeitlimit, waehrend ein Mensch vor dem Ladebalken sass. Jetzt entstehen die
  // Entwurfszeilen sofort und leer, und ein Auftrag je Entwurf fuellt sie. Die Mappe zeigt den
  // Fortschritt; wer will, geht weg und kommt wieder.
  const ts=nowIso(),entwuerfe=[];
  for(let i=0;i<menge;i++){
    const entwurfId=id('kef_');
    await env.DB.prepare('INSERT INTO ai_content_drafts(id,tenant_id,art,quelle_typ,quelle_id,course_id,titel,inhalt_json,status,erzeugt_von,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')
      .bind(entwurfId,tenantId,art,quelleTyp,quelleId,clean(input.course_id,120)||null,`${ART_NAME[art]??art} ${i+1} (wird erzeugt)`,
        JSON.stringify({}),'entwurf',auth.userId,ts,ts).run();
    const auftragsstand=await stelleKiAuftragEin(env,auth,tenantId,{zweck:`fabrik:${art}`,
      eingabe:`${auftrag}\n\nGrundlage:\n${quellText}\n\nVariante ${i+1} von ${menge}.`,
      ziel_typ:'ai_content_draft',ziel_id:entwurfId});
    // Lag die Antwort schon vor, ist der Entwurf hier bereits fertig - dann gibt es keinen
    // Auftrag, sondern ein Ergebnis.
    if(auftragsstand.status==='fertig'&&auftragsstand.ergebnis)
      await fuelleEntwurf(env,tenantId,entwurfId,auftragsstand.ergebnis as {text:string;anbieter:string;modell:string});
    entwuerfe.push({id:entwurfId,job_id:auftragsstand.job_id,status:auftragsstand.status,
      wiederverwendet:!!auftragsstand.wiederverwendet});
  }
  await audit(env.DB,auth.userId,'ai_factory.drafted',tenantId,clean(input.course_id,120)||undefined,'ai_content_draft',entwuerfe[0]?.id??'',{art,menge});
  return{entwuerfe,menge:entwuerfe.length,verarbeitung:'hintergrund'};
}

async function ladeEntwurf(env:Env,tenantId:string,entwurfId:string){
  const e=await env.DB.prepare('SELECT id,art,status,erzeugt_von,course_id,titel,inhalt_json FROM ai_content_drafts WHERE id=? AND tenant_id=?')
    .bind(clean(entwurfId,120),tenantId).first<{id:string;art:string;status:string;erzeugt_von:string;course_id:string|null;titel:string;inhalt_json:string}>();
  if(!e)throw new Error('FABRIK_ENTWURF_NICHT_GEFUNDEN');
  return e;
}

/**
 * Freigeben - durch jemand anderen als den Erzeuger.
 *
 * Wer eine Maschine anwirft und ihr Ergebnis selbst freigibt, hat nichts geprueft, sondern
 * zweimal auf denselben Knopf gedrueckt.
 */
export async function gibEntwurfFrei(env:Env,auth:CoreAuthContext,tenantId:string,entwurfId:string,anmerkung?:string){
  requireRole(auth,'class_admin');
  const e=await ladeEntwurf(env,tenantId,entwurfId);
  if(e.status!=='entwurf')throw new Error('FABRIK_NICHT_MEHR_ENTWURF');
  if(e.erzeugt_von===auth.userId&&!auth.isPlatformAdmin)throw new Error('FABRIK_EIGENER_ENTWURF');
  const ts=nowIso();
  await env.DB.prepare("UPDATE ai_content_drafts SET status='freigegeben',freigegeben_von=?,freigegeben_am=?,verworfen_grund=?,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(auth.userId,ts,clean(anmerkung,2000)||null,ts,e.id,tenantId).run();
  await audit(env.DB,auth.userId,'ai_factory.released',tenantId,e.course_id??undefined,'ai_content_draft',e.id,{});
  return{status:'freigegeben'};
}

export async function verwirfEntwurf(env:Env,auth:CoreAuthContext,tenantId:string,entwurfId:string,grund:string){
  requireRole(auth,'class_admin');
  const e=await ladeEntwurf(env,tenantId,entwurfId);
  if(e.status==='uebernommen')throw new Error('FABRIK_BEREITS_UEBERNOMMEN');
  const text=clean(grund,2000);
  // Der Grund ist die einzige Rueckmeldung, aus der sich der Auftrag verbessern laesst.
  if(text.length<5)throw new Error('FABRIK_VERWERFGRUND_ERFORDERLICH');
  await env.DB.prepare("UPDATE ai_content_drafts SET status='verworfen',verworfen_grund=?,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(text,nowIso(),e.id,tenantId).run();
  return{status:'verworfen'};
}

/**
 * Uebernehmen - der bewusste Schritt vom Entwurf in den Betrieb.
 *
 * Nur Freigegebenes, und in eine versiegelte Pruefung gar nicht: dort haengt die
 * Chain-of-Custody daran, und eine Frage, die nach dem Siegel hineinkommt, bricht sie.
 */
export async function uebernimmEntwurf(env:Env,auth:CoreAuthContext,tenantId:string,entwurfId:string,ziel:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const e=await ladeEntwurf(env,tenantId,entwurfId);
  if(e.status!=='freigegeben')throw new Error('FABRIK_NICHT_FREIGEGEBEN');
  const quizId=clean(ziel.quiz_id,120)||null;
  if(quizId){
    const versiegelt=await env.DB.prepare("SELECT 1 AS ok FROM exam_custody_events WHERE tenant_id=? AND quiz_id=? AND ereignis='versiegelt' LIMIT 1")
      .bind(tenantId,quizId).first();
    if(versiegelt)throw new Error('FABRIK_PRUEFUNG_VERSIEGELT');
  }
  const ts=nowIso();
  await env.DB.prepare("UPDATE ai_content_drafts SET status='uebernommen',uebernommen_als=?,updated_at=? WHERE id=? AND tenant_id=?")
    .bind(clean(ziel.ziel_id,120)||quizId,ts,e.id,tenantId).run();
  await audit(env.DB,auth.userId,'ai_factory.adopted',tenantId,e.course_id??undefined,'ai_content_draft',e.id,{quiz_id:quizId});
  return{status:'uebernommen'};
}

/** Die Entwurfsmappe - mit Herkunft, in zwei Abfragen. */
export async function entwurfsmappe(env:Env,auth:CoreAuthContext,tenantId:string,status?:string){
  requireRole(auth,'class_admin');
  const filter=clean(status,30);
  const entwuerfe=((await env.DB.prepare(`SELECT d.id,d.art,d.titel,d.status,d.quelle_typ,d.quelle_id,d.created_at,u.display_name AS erzeuger
    FROM ai_content_drafts d JOIN users u ON u.id=d.erzeugt_von WHERE d.tenant_id=? AND (?='' OR d.status=?)
    ORDER BY d.created_at DESC LIMIT 200`).bind(tenantId,filter,filter).all<Record<string,unknown>>()).results)??[];
  if(!entwuerfe.length)return{entwuerfe:[]};
  const ph=entwuerfe.map(()=>'?').join(',');
  const herkunft=((await env.DB.prepare(`SELECT objekt_id,anbieter,modell,erzeugt_am FROM ai_generated_content
    WHERE tenant_id=? AND objekt_typ='ai_content_draft' AND objekt_id IN (${ph})`)
    .bind(tenantId,...entwuerfe.map(e=>String(e.id))).all<Record<string,unknown>>()).results)??[];
  const karte=new Map(herkunft.map(h=>[String(h.objekt_id),h]));
  return{entwuerfe:entwuerfe.map(e=>({...e,herkunft:karte.get(String(e.id))??null}))};
}

const ART_NAME:Record<string,string>={aufgabe:'Aufgabe',quizfrage:'Quizfrage',lernmaterial:'Lernmaterial',zusammenfassung:'Zusammenfassung',bild:'Bild'};

/**
 * Den leeren Entwurf mit dem Ergebnis fuellen - und mit seiner Herkunft.
 *
 * Die Herkunft ist kein Beiwerk: ohne Modell, Zeitpunkt und Eingabehash laesst sich spaeter nicht
 * sagen, woher eine Pruefungsfrage stammt, und genau das ist die Frage, die im Zweifel gestellt
 * wird.
 */
async function fuelleEntwurf(env:Env,tenantId:string,entwurfId:string,antwort:{text:string;anbieter:string;modell:string;invocation_id?:string|null;eingabe_hash?:string}){
  const titel=clean(String(antwort.text).split('\n')[0],200)||'Entwurf';
  await env.DB.prepare("UPDATE ai_content_drafts SET titel=?,inhalt_json=?,invocation_id=?,updated_at=? WHERE id=? AND tenant_id=? AND status='entwurf'")
    .bind(titel,JSON.stringify({text:antwort.text,anbieter:antwort.anbieter,modell:antwort.modell}),
      antwort.invocation_id??null,nowIso(),entwurfId,tenantId).run();
  await markiereKiInhalt(env,tenantId,{objekt_typ:'ai_content_draft',objekt_id:entwurfId,feld:'inhalt',
    invocation_id:antwort.invocation_id??null,anbieter:antwort.anbieter,modell:antwort.modell,
    eingabe_hash:antwort.eingabe_hash??''});
}

// Der Lauf kennt keine Entwuerfe. Er kennt nur Ziele, die sich angemeldet haben - so wie sich ein
// KI-Anbieter beim Gateway anmeldet.
registriereKiZiel('ai_content_draft',async (env,tenantId,zielId,antwort)=>{
  await fuelleEntwurf(env,tenantId,zielId,antwort);
});

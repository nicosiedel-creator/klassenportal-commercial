import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Dokumentversionierung (D1) und Volltextsuche ueber Dokumentinhalte (D2).
//
// Bisher hatte ein Dokument eine Versionsnummer, aber keine Historie: die alte Fassung wurde beim
// Ersetzen ueberschrieben. Fuer ein Zeugnis oder einen Foerderbescheid ist das der Unterschied
// zwischen einer Akte und einem Zettel.
//
// Zwei Regeln tragen das hier:
//  1. Eine Fassung wird nie geaendert und nie geloescht - auch das Zurueckholen einer alten Fassung
//     schreibt eine NEUE. Eine Historie, in der man zuruecksetzen kann, ist keine.
//  2. Gesucht wird ueber eine eigene Wortliste, nicht ueber FTS5. Weniger maechtig, dafuer ohne
//     Schattentabellen, die kein fail-closed-Register kennt - der Grund steht in der Migration.

export const MINDESTLAENGE=3;          // kuerzere Woerter sind als Suchbegriff wertlos
export const HOECHSTWOERTER=2000;      // je Dokument; darueber wird abgeschnitten, nicht abgebrochen
export const TITELGEWICHT=5;           // ein Treffer im Titel wiegt schwerer als einer im Fliesstext
const clean=(v:unknown,n=2000)=>safeString(v,n);

// Fuellwoerter, die jedes deutsche Dokument enthaelt und die deshalb nichts unterscheiden.
const STOPPWOERTER=new Set(['und','oder','der','die','das','den','dem','des','ein','eine','einer','eines','einem','einen','fuer','für','mit','von','vom','zum','zur','bei','auf','aus','nach','ueber','über','unter','ist','sind','war','waren','wird','werden','nicht','auch','sich','dass','als','wie','sowie','bis','durch','gegen','ohne','hat','haben','kann','koennen','können']);

/** Text in Suchwoerter zerlegen. Umlaute bleiben - sie gehoeren zum Wort, nicht zum Rauschen. */
export function woerter(text:unknown):Map<string,number>{
  const karte=new Map<string,number>();
  const roh=String(text??'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').split(' ');
  for(const w of roh){
    if(w.length<MINDESTLAENGE||STOPPWOERTER.has(w))continue;
    karte.set(w,(karte.get(w)??0)+1);
    if(karte.size>=HOECHSTWOERTER)break;
  }
  return karte;
}

/**
 * Eine neue Fassung anlegen.
 *
 * Die Registrierung fuehrt immer die AKTUELLE Fassung; die Historie liegt daneben. Beim Anlegen
 * wird die bisherige Fassung mitgeschrieben, falls sie noch keinen Eintrag hat - sonst begaenne die
 * Historie erst mit der ersten Aenderung, und ausgerechnet das Original fehlte.
 */
export async function speichereDokumentfassung(env:Env,auth:CoreAuthContext,tenantId:string,documentId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const dok=await env.DB.prepare('SELECT id,title,version,file_id,external_reference,created_by,created_at FROM education_document_registry WHERE id=? AND tenant_id=?')
    .bind(documentId,tenantId).first<{id:string;title:string;version:number;file_id:string|null;external_reference:string|null;created_by:string;created_at:string}>();
  if(!dok)throw new Error('DOKUMENT_NICHT_GEFUNDEN');
  const titel=clean(input.titel,200)||String(dok.title);
  const kommentar=clean(input.kommentar,1000);
  if(kommentar.length<5)throw new Error('DOKUMENT_KOMMENTAR_ERFORDERLICH');
  // Die Registrierung fuehrt `version` als TEXT - ein Etikett wie "1.0", kein Zaehler. Die
  // verbindliche Zaehlung steht deshalb in der Historie selbst; das Etikett folgt ihr. Sonst haenge
  // die Akte an einer Zeichenkette, die irgendwann jemand von Hand gesetzt hat.
  const ts=nowIso();
  const hoechste=Number((await env.DB.prepare('SELECT MAX(version) v FROM document_versions WHERE document_id=?').bind(documentId).first<{v:number|null}>())?.v??0);
  const bisherige=Math.max(hoechste,1);
  const anweisungen=[];
  if(!hoechste)anweisungen.push(env.DB.prepare('INSERT INTO document_versions(id,tenant_id,document_id,version,titel,file_id,external_reference,kommentar,geaendert_von,geaendert_am) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .bind(id('dvs_'),tenantId,documentId,bisherige,String(dok.title),dok.file_id,dok.external_reference,'Urspruengliche Fassung',String(dok.created_by),String(dok.created_at)));
  const neu=bisherige+1;
  anweisungen.push(env.DB.prepare('INSERT INTO document_versions(id,tenant_id,document_id,version,titel,file_id,external_reference,sha256,kommentar,hergestellt_aus,geaendert_von,geaendert_am) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')
    .bind(id('dvs_'),tenantId,documentId,neu,titel,clean(input.file_id,120)||null,clean(input.external_reference,200)||null,clean(input.sha256,80)||null,kommentar,
      Number.isFinite(Number(input.hergestellt_aus))?Math.trunc(Number(input.hergestellt_aus)):null,auth.userId,ts));
  anweisungen.push(env.DB.prepare('UPDATE education_document_registry SET version=?,title=?,file_id=COALESCE(?,file_id),external_reference=COALESCE(?,external_reference),updated_at=? WHERE id=? AND tenant_id=?')
    .bind(String(neu),titel,clean(input.file_id,120)||null,clean(input.external_reference,200)||null,ts,documentId,tenantId));
  await env.DB.batch(anweisungen);
  await audit(env.DB,auth.userId,'document.version_saved',tenantId,undefined,'education_document',documentId,{version:neu});
  return{version:neu};
}

export async function dokumentfassungen(env:Env,auth:CoreAuthContext,tenantId:string,documentId:string){
  requireRole(auth,'class_admin');
  return ((await env.DB.prepare('SELECT v.version,v.titel,v.file_id,v.external_reference,v.kommentar,v.hergestellt_aus,v.geaendert_von,u.display_name AS geaendert_name,v.geaendert_am FROM document_versions v JOIN users u ON u.id=v.geaendert_von WHERE v.document_id=? AND v.tenant_id=? ORDER BY v.version DESC')
    .bind(documentId,tenantId).all()).results)??[];
}

/**
 * Eine aeltere Fassung zurueckholen.
 *
 * Sie wird als NEUE Fassung angelegt, nicht als Ruecksetzen. Wer zuruecksetzt, verliert den Beleg
 * dafuer, dass es die spaetere Fassung gab - und genau die ist im Streitfall die interessante.
 */
export async function holeFassungZurueck(env:Env,auth:CoreAuthContext,tenantId:string,documentId:string,version:number,grund:unknown){
  requireRole(auth,'class_admin');
  const alt=await env.DB.prepare('SELECT version,titel,file_id,external_reference,sha256 FROM document_versions WHERE document_id=? AND tenant_id=? AND version=?')
    .bind(documentId,tenantId,Math.trunc(Number(version))).first<{version:number;titel:string;file_id:string|null;external_reference:string|null;sha256:string|null}>();
  if(!alt)throw new Error('DOKUMENT_FASSUNG_NICHT_GEFUNDEN');
  const text=clean(grund,1000);
  if(text.length<10)throw new Error('DOKUMENT_RUECKHOLGRUND_ERFORDERLICH');
  return speichereDokumentfassung(env,auth,tenantId,documentId,{titel:alt.titel,file_id:alt.file_id,external_reference:alt.external_reference,
    sha256:alt.sha256,kommentar:`Fassung ${alt.version} zurueckgeholt: ${text}`,hergestellt_aus:alt.version});
}

/**
 * Ein Dokument durchsuchbar machen.
 *
 * Der Index wird je Dokument komplett ersetzt - eine Teilaktualisierung liesse Woerter stehen, die
 * im Dokument laengst nicht mehr vorkommen, und die Suche fuehrte auf Dokumente, die den Begriff
 * gar nicht enthalten.
 */
export async function indexiereDokument(env:Env,tenantId:string,documentId:string,felder:{titel?:unknown;inhalt?:unknown;kennzeichen?:unknown}):Promise<{woerter:number}>{
  const anweisungen=[env.DB.prepare('DELETE FROM document_search_terms WHERE tenant_id=? AND document_id=?').bind(tenantId,documentId)];
  let gesamt=0;
  for(const [quelle,text] of [['titel',felder.titel],['inhalt',felder.inhalt],['kennzeichen',felder.kennzeichen]] as const){
    if(!text)continue;
    for(const [wort,anzahl] of woerter(text)){
      anweisungen.push(env.DB.prepare('INSERT INTO document_search_terms(tenant_id,document_id,wort,quelle,anzahl) VALUES(?,?,?,?,?) ON CONFLICT(tenant_id,document_id,wort,quelle) DO UPDATE SET anzahl=excluded.anzahl')
        .bind(tenantId,documentId,wort,quelle,anzahl));
      gesamt++;
    }
  }
  // In Stapeln: ein Dokument mit zweitausend Woertern darf das Unteranfragen-Budget nicht sprengen.
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  return{woerter:gesamt};
}

export type Suchtreffer={document_id:string;titel:string;kategorie:string;punkte:number;treffer:number};

/**
 * Suchen.
 *
 * UND-Verknuepfung: wer zwei Begriffe eingibt, meint beide. Ein Dokument, das nur einen enthaelt,
 * ist kein Treffer, sondern Rauschen. Rang nach Haeufigkeit, Titel wiegt schwerer.
 */
export async function sucheDokumente(env:Env,auth:CoreAuthContext,tenantId:string,frage:unknown,grenze=50):Promise<Suchtreffer[]>{
  requireRole(auth,'class_admin');
  const begriffe=[...woerter(frage).keys()].slice(0,8);
  if(!begriffe.length)throw new Error('SUCHE_BEGRIFF_ERFORDERLICH');
  const n=Math.min(Math.max(Number(grenze)||50,1),200);
  const marken=begriffe.map(()=>'?').join(',');
  // Eine Abfrage, unabhaengig von der Zahl der Begriffe und der Dokumente: die Gruppierung zaehlt,
  // wie viele der gesuchten Woerter ein Dokument traegt, und HAVING verlangt alle.
  const zeilen=((await env.DB.prepare(`SELECT t.document_id,d.title AS titel,d.category AS kategorie,COUNT(DISTINCT t.wort) AS treffer,SUM(t.anzahl*CASE t.quelle WHEN 'titel' THEN ${TITELGEWICHT} WHEN 'kennzeichen' THEN ${TITELGEWICHT} ELSE 1 END) AS punkte FROM document_search_terms t JOIN education_document_registry d ON d.id=t.document_id AND d.tenant_id=t.tenant_id WHERE t.tenant_id=? AND t.wort IN (${marken}) GROUP BY t.document_id,d.title,d.category HAVING COUNT(DISTINCT t.wort)=? ORDER BY punkte DESC,d.title LIMIT ?`)
    .bind(tenantId,...begriffe,begriffe.length,n).all<Suchtreffer>()).results)??[];
  return zeilen;
}

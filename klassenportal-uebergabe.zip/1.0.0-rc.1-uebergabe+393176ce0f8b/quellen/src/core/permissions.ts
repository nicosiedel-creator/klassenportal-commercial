import type { CoreAuthContext } from './types.js';

const ranks: Record<string,number>={platform_admin:5,tenant_admin:4,class_admin:3,participant:2,guest:1};
export function requireRole(auth: CoreAuthContext, minimum: 'tenant_admin'|'class_admin'|'participant'|'guest'): void {
  if((ranks[auth.role]??0)<ranks[minimum]) throw new Error('FORBIDDEN_ROLE');
}
export function requirePlatform(auth: CoreAuthContext): void { if(!auth.isPlatformAdmin) throw new Error('PLATFORM_ADMIN_REQUIRED'); }
/**
 * Zugang zu einem Kurs. Mit `minimum` wird zusaetzlich die Rolle geprueft, die der Aufrufer IN
 * DIESEM Kurs hat - nicht die hoechste ueber alle Kurse.
 *
 * Ohne diese Unterscheidung reichte es, ?course_id= aus der Anfrage wegzulassen: auth.role meldete
 * dann die hoechste Rolle des Nutzers, und ein Klassensprecher der einen Klasse handelte in jeder
 * anderen, in der er blosser Teilnehmer ist. Die Berechtigung darf nicht davon abhaengen, welche
 * Parameter der Client mitschickt.
 */
export function requireCourseAccess(auth: CoreAuthContext, courseId: string, minimum?: 'class_admin'|'participant'|'guest'): void {
  if(auth.isPlatformAdmin || auth.role==='tenant_admin') return;
  if(!auth.courseIds.includes(courseId)) throw new Error('FORBIDDEN_COURSE');
  if(!minimum) return;
  // Fehlt die Kursrolle (aeltere Sitzung, anderer Aufbauweg), gilt die mandantenweite Rolle - aber
  // nur, wenn der Nutzer ueberhaupt nur einen Kurs hat. Sonst waere wieder alles verschmolzen.
  const inKurs=auth.courseRoles?.[courseId] ?? (auth.courseIds.length<=1?auth.role:'guest');
  if((ranks[inKurs]??0)<ranks[minimum]) throw new Error('FORBIDDEN_COURSE_ROLE');
}
/** Die tatsaechliche Rolle in genau diesem Kurs. */
export function roleInCourse(auth: CoreAuthContext, courseId: string): string {
  if(auth.isPlatformAdmin) return 'platform_admin';
  if(auth.role==='tenant_admin') return 'tenant_admin';
  return auth.courseRoles?.[courseId] ?? (auth.courseIds.length<=1?auth.role:'guest');
}

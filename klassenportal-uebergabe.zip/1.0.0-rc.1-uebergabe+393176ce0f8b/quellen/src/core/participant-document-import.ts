import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { createTenantUser } from './users.js';
import { createParticipantTargetResolver, splitOrgPath } from './participant-hierarchy-targeting.js';
import { id, normalizeEmail, nowIso, safeString, sha256Text } from './utils.js';
import { assertSpeicherFuerMassenimport } from './storage-growth.js';

export type ParticipantCandidate={
  display_name:string;email:string;external_id:string|null;course_id:string|null;course_code:string|null;course_name:string|null;
  org_context:string[];org_path:string|null;enrollment_start:string|null;enrollment_end:string|null;confidence:number;warnings:string[];source_excerpt:string|null;
  detected_not_imported:{birth_date?:string;address?:string;bank_data?:boolean;special_category_hint?:boolean};
};

function canImport(auth:CoreAuthContext){if(auth.isPlatformAdmin||auth.role==='tenant_admin'||auth.permissions?.includes('participants.manage'))return;throw new Error('FORBIDDEN_PERMISSION');}
const norm=(v:unknown)=>safeString(v,500).replace(/\s+/g,' ').trim();
function emailOf(v:unknown){const e=normalizeEmail(v);return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)?e:'';}
function isoDate(raw:string):string|null{const s=raw.trim();let m=s.match(/\b(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})\b/);if(m){const d=new Date(Date.UTC(Number(m[3]),Number(m[2])-1,Number(m[1])));return Number.isNaN(d.getTime())?null:d.toISOString().slice(0,10);}m=s.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);return m?`${m[1]}-${m[2]}-${m[3]}`:null;}
function label(text:string,labels:string[],max=180):string{
  const stop='(?=\\s{2,}|\\n|\\r|(?:E-?Mail|Geburtsdatum|Anschrift|Adresse|Standort|Campus|Bereich|Fachbereich|Abteilung|Kurs(?:code)?|Klasse|Maßnahme|Bildungsgang|Studiengang|Beginn|Ende|Vertragsnummer|Teilnehmernummer|Matrikelnummer)\\s*[:\\-]|$)';
  for(const l of labels){for(const source of [`(?:^|\\n)\\s*${l}\\s*[:\\-]?\\s*([^\\n]{1,${max}})`,`\\b${l}\\s*[:\\-]\\s*(.{1,${max}}?)${stop}`]){const m=text.match(new RegExp(source,'im'));if(m){const value=norm(m[1]);if(value)return value;}}}return'';
}
function detectSensitive(text:string){const birth=label(text,['Geburtsdatum','Geboren am','Date of birth'],40),address=label(text,['Anschrift','Adresse','Wohnanschrift'],220),bank=/\b(?:IBAN|BIC|Kontonummer|Bankverbindung)\b/i.test(text),special=/\b(?:Gesundheit|Diagnose|Behinderung|Schwerbehindert|Religion|Konfession|ethnisch|Gewerkschaft|sexuelle Orientierung)\b/i.test(text);return{...(birth?{birth_date:isoDate(birth)||birth}:{}),...(address?{address}:{}),...(bank?{bank_data:true}:{}),...(special?{special_category_hint:true}:{})};}
function contractOrgContext(text:string){const path=label(text,['Organisationspfad','Strukturpfad','Hierarchiepfad'],260),site=label(text,['Standort','Schulstandort','Campus','Filiale','Niederlassung','Betriebsstätte','Betriebsstaette'],160),area=label(text,['Bereich','Fachbereich','Abteilung','Organisationseinheit','Department'],160),measure=label(text,['Maßnahme','Massnahme','Bildungsgang','Studiengang','Programm','Projekt'],200);return[...new Set([...(path?splitOrgPath(path):[]),site,area,measure].map(x=>norm(x)).filter(Boolean))];}
function extractContract(textRaw:string):ParticipantCandidate{
  const text=textRaw.replace(/\r/g,'\n').replace(/\u00a0/g,' '),emails=[...new Set((text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)||[]).map(x=>x.toLowerCase()))];
  const name=label(text,['Teilnehmer(?:in)?','Teilnehmende(?:r)?','Name(?: des Teilnehmers| der Teilnehmerin)?','Vertragspartner(?:in)?','Schüler(?:in)?','Student(?:in)?'],160);
  const external=label(text,['Teilnehmernummer','Teilnehmer-ID','Teilnehmer ID','Vertragsnummer','Matrikelnummer','Schülernummer'],100);
  const courseCode=label(text,['Kurscode','Kurs-Code','Klassencode','Klassen-Code','Maßnahmennummer','Maßnahme-Nr\\.?','Lehrgangsnummer'],100);
  const courseName=label(text,['Kurs','Klasse','Lehrgang'],200);
  const orgContext=contractOrgContext(text),start=label(text,['Beginn','Vertragsbeginn','Maßnahmebeginn','Kursbeginn','Start'],80),end=label(text,['Ende','Vertragsende','Maßnahmeende','Kursende'],80);
  const warnings:string[]=[];if(!name)warnings.push('NAME_NOT_DETECTED');if(emails.length!==1)warnings.push(emails.length?'MULTIPLE_EMAILS':'EMAIL_NOT_DETECTED');if(!courseCode&&!courseName&&!orgContext.length)warnings.push('COURSE_NOT_DETECTED');
  const confidence=Math.max(0,Math.min(100,(name?35:0)+(emails.length===1?35:0)+(courseCode||courseName||orgContext.length?20:0)+(external?10:0)));
  return{display_name:name,email:emails.length===1?emails[0]:'',external_id:external||null,course_id:null,course_code:courseCode||null,course_name:courseName||null,org_context:orgContext,org_path:null,enrollment_start:isoDate(start),enrollment_end:isoDate(end),confidence,warnings,source_excerpt:text.slice(0,500),detected_not_imported:detectSensitive(text)};
}
function splitList(v:string):string[]{const parts=v.split(/[;,|\n]+/).map(x=>norm(x)).filter(Boolean);return parts.length?[...new Set(parts)]:[];}
// Eine Person kann in mehreren Kursen zugleich stehen. Traegt die Kurs-Zelle mehrere durch
// Semikolon/Komma/Pipe/Zeilenumbruch getrennte Werte, wird daraus je Kurs ein eigener Kandidat -
// sonst verliert die Zeile alle Kurse bis auf den zuletzt aufgeloesten.
function fromRow(row:Record<string,unknown>):ParticipantCandidate[]{
  const pick=(...keys:string[])=>{for(const k of keys)if(row[k]!==undefined&&row[k]!==null&&String(row[k]).trim())return row[k];return'';};
  const first=norm(pick('first_name','vorname')),last=norm(pick('last_name','nachname')),name=norm(pick('display_name','name','teilnehmer','schueler','student'))||[first,last].filter(Boolean).join(' '),email=emailOf(pick('email','e_mail','mail','emailadresse'));
  // Eine Teilnehmerliste verweist auf ihre Klasse fast nie ueber den Kurscode, sondern ueber die
// eigene Kennung des Traegers ('class_id', 'course_external_id'). Fehlten diese Spalten hier,
// stand bei jeder Zeile "Kein Kurs erkannt" - gemessen am Kundenpaket bei allen 1537.
  const courseCodeRaw=norm(pick('course_code','kurscode','klassencode','massnahmennummer','course_external_id','class_id','klassen_id','kurs_external_id','class_external_id')),courseNameRaw=norm(pick('course_name','kurs','klasse','lehrgang')),courseId=norm(pick('course_id'))||null,external=norm(pick('external_id','teilnehmernummer','teilnehmer_id','matrikelnummer','schuelernummer','vertragsnummer'))||null;
  const path=pick('org_path','organisationspfad','strukturpfad','hierarchiepfad'),orgContext=[...new Set([...splitOrgPath(path),norm(pick('site','standort','schulstandort','campus','filiale','niederlassung')),norm(pick('area','bereich','fachbereich','abteilung','organisationseinheit')),norm(pick('measure','massnahme','maßnahme','bildungsgang','studiengang','programm','projekt'))].filter(Boolean))];
  const enrollmentStart=isoDate(norm(pick('enrollment_start','beginn','start'))),enrollmentEnd=isoDate(norm(pick('enrollment_end','ende')));
  // Das Geburtsdatum wird gelesen, aber nicht uebernommen - es bleibt Vorschau-Metadatum wie
  // bisher. Es dient allein dazu, eine Person ohne E-Mail eindeutig zu machen; in die Datenbank
  // geht davon nur ein Einwegschluessel, nie das Datum selbst.
  const geburtsdatum=isoDate(norm(pick('birth_date','geburtsdatum','geburtstag','date_of_birth','dob','geboren_am','geburts_datum')));
  const codes=splitList(courseCodeRaw),names=splitList(courseNameRaw),n=Math.max(codes.length,names.length,1);
  const kurse=n<=1?[{code:courseCodeRaw||null,name:courseNameRaw||null,id:courseId}]:Array.from({length:n},(_,i)=>({code:codes[i]??null,name:names[i]??null,id:null}));
  return kurse.map(k=>{
    const warnings:string[]=[];if(!name)warnings.push('NAME_NOT_DETECTED');if(!email)warnings.push('EMAIL_NOT_DETECTED');if(!k.code&&!k.name&&!k.id&&!orgContext.length)warnings.push('COURSE_NOT_DETECTED');
    return{display_name:name,email,external_id:external,course_id:k.id,course_code:k.code,course_name:k.name,org_context:orgContext,org_path:null,enrollment_start:enrollmentStart,enrollment_end:enrollmentEnd,confidence:Math.max(0,100-warnings.length*30),warnings,source_excerpt:null,detected_not_imported:geburtsdatum?{birth_date:geburtsdatum}:{}};
  });
}
async function resolveCourses(env:Env,auth:CoreAuthContext,tenantId:string,candidates:ParticipantCandidate[],fallbackCourseId:string|null,fallbackOrgUnitId:string|null){
  const resolve=await createParticipantTargetResolver(env,auth,tenantId);for(const c of candidates){const target=resolve({courseId:c.course_id,courseCode:c.course_code,courseName:c.course_name,orgContext:c.org_context,fallbackCourseId,fallbackOrgUnitId});c.course_id=target.courseId;c.org_path=target.orgPath;if(target.warning)c.warnings.push(target.warning);if(c.course_id)c.warnings=c.warnings.filter(x=>x!=='COURSE_NOT_DETECTED'&&x!=='COURSE_NOT_RESOLVED'&&x!=='ORG_CONTEXT_UNRESOLVED');}
}
function canonical(candidates:ParticipantCandidate[]){return candidates.map(c=>({display_name:c.display_name,email:c.email,external_id:c.external_id,course_id:c.course_id,course_code:c.course_code,course_name:c.course_name,org_context:c.org_context,org_path:c.org_path,enrollment_start:c.enrollment_start,enrollment_end:c.enrollment_end,confidence:c.confidence,warnings:[...new Set(c.warnings)].sort()}));}
// So viele Zeilen nimmt eine Vorschau auf einmal an. Groessere Listen werden in Teilen
// eingelesen - abgeschnitten wird nie.
// Ein Grundschueler oder Berufsschueler hat oft keine eigene E-Mail. Ohne sie entstand bisher gar
// keine Person: die Zeile blieb mit EMAIL_NOT_DETECTED liegen, und ein ganzer Jahrgang liess sich
// nicht einlesen.
//
// users.email ist NOT NULL UNIQUE - eine Person ohne Adresse kann es im Datenmodell nicht geben.
// Statt das Schema umzubauen (Auth, Einladungen, jede Verknuepfung haengen daran) bekommt sie eine
// erkennbare Ersatzadresse in einer nicht zustellbaren Domain. Sie wird aus Mandant, Name und
// Geburtsdatum abgeleitet und ist deshalb bei jedem weiteren Import DIESELBE - der zweite Einwurf
// findet die Person wieder, statt sie ein zweites Mal anzulegen.
//
// Das Geburtsdatum selbst wird NICHT gespeichert. Es geht als Einwegschluessel in die Adresse ein
// und bleibt ansonsten das, was es heute ist: erkannt, nicht uebernommen. Aus der Adresse laesst es
// sich nicht zurueckrechnen.
//
// Die Anschrift bleibt bewusst aussen vor: Geschwister teilen sie, und zwei Kinder derselben
// Familie waeren sonst dieselbe Person.
export const ERSATZ_DOMAIN='kein-login.invalid';
export function istErsatzAdresse(email:string){return String(email||'').toLowerCase().endsWith('@'+ERSATZ_DOMAIN);}
// Der Bewerbungstrichter braucht dieselbe Ableitung: ein Bewerber ohne eigene Adresse bekommt
// schon bei der Bewerbung die Ersatzadresse, damit bei der Zusage nichts erneut geraten oder
// eingetippt werden muss - und damit das Geburtsdatum auch dort nur als Einwegschluessel eingeht.
export async function ersatzAdresse(tenantId:string,name:string,geburtsdatum:string){
  const roh=`${tenantId}|${name.trim().toLocaleLowerCase('de-DE').replace(/\s+/g,' ')}|${geburtsdatum.trim()}`;
  // sha256Text liefert Base64 - darin kommen '/' und '+' vor. Im lokalen Teil einer Adresse ist
  // '+' Plus-Adressierung und '/' bringt jeden zweiten Leser durcheinander. Nur Buchstaben und
  // Ziffern, klein geschrieben: die Adresse wird an vielen Stellen verglichen und angezeigt.
  const schluessel=(await sha256Text(roh)).replace(/[^a-zA-Z0-9]/g,'').toLowerCase().slice(0,24);
  return `tn-${schluessel}@${ERSATZ_DOMAIN}`;
}
// So viele Zeilen fasst EINE Seite einer Vorschau. Groessere Listen werden in mehrere Seiten
// zerlegt, nicht abgewiesen.
export const MAX_IMPORT_ROWS=5000;
// Eine Obergrenze bleibt - aber weit oben. Sie schuetzt vor einer versehentlich eingeworfenen
// Datei mit Millionen Zeilen, nicht vor einem echten Traeger.
export const MAX_IMPORT_TOTAL=200000;
export async function previewParticipantImport(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  canImport(auth);const sourceName=safeString(input.source_name,250)||'Import',kind=String(input.source_kind||'structured'),fallbackCourseId=safeString(input.default_course_id,100)||null,fallbackOrgUnitId=safeString(input.default_org_unit_id,100)||null;let candidates:ParticipantCandidate[]=[];
  // Die Grenze wird geprueft, nicht stillschweigend angewandt. Vorher schnitt .slice(0,5000)
  // die Liste ab, BEVOR der Waechter darunter sie messen konnte - eine Hochschule lud 6200
  // Studierende hoch, 5000 kamen an, 1200 verschwanden ohne ein Wort, und in der Antwort stand
  // nichts davon. Lieber ein klarer Abbruch mit Zahlen als ein stiller Verlust.
  const rohZeilen=Array.isArray(input.rows)?input.rows as Record<string,unknown>[]:[];
  // Frueher wurde hier abgewiesen. Jetzt ist MAX_IMPORT_ROWS nur noch die Seitengroesse; die
  // Notbremse unten faengt eine versehentlich eingeworfene Riesendatei ab.
  if(rohZeilen.length)candidates.push(...rohZeilen.flatMap(fromRow));
  if(Array.isArray(input.documents))candidates.push(...(input.documents as unknown[]).slice(0,500).map(x=>extractContract(String(x||''))));
  if(typeof input.text==='string'&&input.text.trim())candidates.push(extractContract(input.text));
  if(!candidates.length)throw new Error('PARTICIPANT_IMPORT_DATA_REQUIRED');if(candidates.length>MAX_IMPORT_TOTAL)throw new Error(`PARTICIPANT_IMPORT_TOO_LARGE:${candidates.length}:${MAX_IMPORT_TOTAL}`);
  // Die Kurszuordnung und die Duplikat-/Sensibeldaten-Pruefung haengen neue Warnungen erst nach
  // der ersten, in fromRow()/extractContract() gesetzten Einschaetzung an - ohne Neuberechnung
  // bliebe die angezeigte Prozentzahl auf dem Stand vor der Kurszuordnung stehen, waehrend
  // darunter laengst ein neuer, dort noch unbekannter Befund steht.
  await resolveCourses(env,auth,tenantId,candidates,fallbackCourseId,fallbackOrgUnitId);
  // Wer keine E-Mail nennt, aber Name und Geburtsdatum, ist eindeutig genug fuer einen Datensatz -
  // nur eben ohne Portalzugang. Das ist kein Mangel, der die Zeile blockiert, sondern eine
  // Eigenschaft, die der Kunde sehen soll.
  for(const c of candidates){
    if(c.email||!c.display_name)continue;
    const geb=c.detected_not_imported?.birth_date;if(!geb)continue;
    c.email=await ersatzAdresse(tenantId,c.display_name,geb);
    c.warnings=c.warnings.filter(w=>w!=='EMAIL_NOT_DETECTED');
    c.warnings.push('NO_PORTAL_ACCESS_WITHOUT_EMAIL');
  }
  const seen=new Set<string>();for(const c of candidates){if(c.email){const k=`${c.email}|${c.course_id||''}`;if(seen.has(k))c.warnings.push('DUPLICATE_IN_IMPORT');seen.add(k);}if(c.detected_not_imported.special_category_hint)c.warnings.push('SPECIAL_CATEGORY_DATA_DETECTED_NOT_IMPORTED');if(c.detected_not_imported.bank_data)c.warnings.push('BANK_DATA_DETECTED_NOT_IMPORTED');c.confidence=Math.max(0,100-new Set(c.warnings).size*30);}
  // Eine grosse Liste wird in Seiten zerlegt statt abgewiesen. Nach aussen bleibt es EIN Import:
  // eine batch_id, eine Pruefsumme ueber die vollstaendige Liste. Die Seiten haengen intern an der
  // ersten; applyParticipantImport arbeitet sie der Reihe nach ab, und weil es dabei ohnehin
  // completed=false meldet, treibt die vorhandene Fortsetzung sie ganz von selbst zu Ende.
  const clean=canonical(candidates),digest=await sha256Text(JSON.stringify(clean)),batchId=id('pib_'),ts=nowIso(),expires=new Date(Date.now()+2*3600_000).toISOString();
  const storedKind=['contract_text','pdf_text','pasted_text','api'].includes(kind)?kind:'structured';
  const seiten:ReturnType<typeof canonical>[]=[];for(let k=0;k<clean.length;k+=MAX_IMPORT_ROWS)seiten.push(clean.slice(k,k+MAX_IMPORT_ROWS));
  if(!seiten.length)seiten.push([]);
  await env.DB.batch(seiten.map((seite,nr)=>env.DB.prepare("INSERT INTO participant_import_batches(id,tenant_id,source_name,source_kind,course_id,preview_digest,preview_json,status,created_by,created_at,expires_at,parent_batch_id,page_no,total_pages,row_offset,row_count) VALUES(?,?,?,?,?,?,?,'preview',?,?,?,?,?,?,?,?)")
    .bind(nr?`${batchId}_s${nr+1}`:batchId,tenantId,sourceName,storedKind,fallbackCourseId,digest,JSON.stringify(seite),auth.userId,ts,expires,nr?batchId:null,nr+1,seiten.length,nr*MAX_IMPORT_ROWS,seite.length)));
  await audit(env.DB,auth.userId,'participants.import.previewed',tenantId,fallbackCourseId??undefined,'participant_import_batch',batchId,{sourceName,rows:clean.length,pages:seiten.length,fallbackOrgUnitId});
  return{batch_id:batchId,digest,expires_at:expires,candidates,total_rows:clean.length,pages:seiten.length};
}
// Wie viele Personen ein einzelner Aufruf anlegt. Gemessen, nicht geschaetzt: eine Person kostet
// rund 16 Unteranfragen (Konto suchen, Konto anlegen, Mandantenzuordnung, Mitgliedschaft,
// Einladung samt Mailversand, Nachweiszeile) - die Plattform laesst 1000 je Aufruf zu.
//
// Ohne diese Grenze brach eine Liste mit hundert Teilnehmenden mitten im Anlegen ab: ein Teil war
// angelegt und eingeladen, der Rest nicht, und der Kunde sah nur einen Abbruch, ohne zu wissen wer
// schon drin ist. Jetzt bleibt der Rest ausdruecklich uebrig und wird fortgesetzt - von der
// Oberflaeche sofort, im automatischen Betrieb vom naechsten Lauf.
const PARTICIPANT_APPLY_MAX=50;

export async function applyParticipantImport(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  canImport(auth);
  const batchId=safeString(input.batch_id,100),digest=safeString(input.digest,128);
  // Eine grosse Liste liegt in Seiten. Nach aussen ist es EIN Import - der Aufrufer nennt immer die
  // erste batch_id. Hier wird die Kette geladen und die erste noch offene Seite bearbeitet; ist sie
  // fertig, meldet completed=false weiterhin Arbeit, und die vorhandene Fortsetzung holt die
  // naechste. Der Aufrufer merkt von der Zerlegung nichts.
  const kette=((await env.DB.prepare("SELECT id,preview_digest,preview_json,status,expires_at,page_no,row_offset,row_count,applied_upto FROM participant_import_batches WHERE tenant_id=? AND (id=? OR parent_batch_id=?) ORDER BY page_no").bind(tenantId,batchId,batchId).all<{id:string;preview_digest:string;preview_json:string;status:string;expires_at:string;page_no:number;row_offset:number;row_count:number;applied_upto:number}>()).results)??[];
  if(!kette.length)throw new Error('PARTICIPANT_IMPORT_NOT_FOUND');
  // Vor der Wand abbiegen: eine Masseneinspielung, die mittendrin an der 10-GB-Grenze von D1
  // scheitert, hinterlaesst halb uebernommene Teilnehmerdaten. Eine klare Absage vorher ist billiger
  // als ein halber Import, den niemand mehr sauber zurueckdrehen kann.
  await assertSpeicherFuerMassenimport(env,kette.reduce((n,x)=>n+(Number(x.row_count)||0),0));
  const kopf=kette[0];
  if(kopf.expires_at<=nowIso())throw new Error('PARTICIPANT_IMPORT_EXPIRED');
  if(kopf.preview_digest!==digest)throw new Error('PARTICIPANT_IMPORT_PREVIEW_CHANGED');
  const offeneSeiten=kette.filter(x=>x.status==='preview');
  if(!offeneSeiten.length)throw new Error('PARTICIPANT_IMPORT_NOT_PENDING');
  const seite=offeneSeiten[0];
  const rows=JSON.parse(seite.preview_json) as ParticipantCandidate[];
  // Die Auswahl des Kunden zaehlt ueber die ganze Liste; diese Seite kennt ihren Versatz.
  const versatz=Number(seite.row_offset)||0;
  const selected=new Set((Array.isArray(input.selected_indexes)?(input.selected_indexes as unknown[]).map(x=>Number(x)-versatz):rows.map((_,i)=>i)).map(Number));
  // Zeilen der spaeteren Seiten sind noch nicht angefasst - sie gehoeren in "offen", sonst meldete
  // der erste Durchgang faelschlich "fertig".
  const spaeter=offeneSeiten.slice(1).reduce((n,x)=>n+(Number(x.row_count)||0),0);
  const results:any[]=[];
  // Eine Obergrenze aus der Anfrage darf die gemessene Grenze nur unterschreiten, nie anheben.
  const grenze=Math.max(1,Math.min(PARTICIPANT_APPLY_MAX,Math.floor(Number(input.max_apply))||PARTICIPANT_APPLY_MAX));
  const blocking=new Set(['EMAIL_NOT_DETECTED','MULTIPLE_EMAILS','COURSE_AMBIGUOUS','COURSE_NOT_FOUND','COURSE_NOT_RESOLVED','COURSE_INACTIVE','COURSE_FORBIDDEN','ORG_CONTEXT_MISMATCH','ORG_CONTEXT_AMBIGUOUS','ORG_CONTEXT_UNRESOLVED','ORG_FALLBACK_INVALID','DUPLICATE_IN_IMPORT']);
  // Was ein frueherer Aufruf schon erledigt hat, steht in den Ergebniszeilen. Daran erkennt ein
  // Folgeaufruf, wo er weitermachen muss - auch dann, wenn dazwischen etwas abgestuerzt ist.
  // Der Schluessel ist E-Mail UND Kurs zusammen: dieselbe Person kann in mehreren Kursen dieses
  // Batches stehen, und ein bereits erledigter Kurs darf einen anderen Kurs derselben Person
  // nicht als "schon erledigt" verdecken.
  const kursSchluessel=(email:string,courseId:string|null)=>`${email.toLowerCase()}|${courseId||''}`;
  // Diese Menge sagt, wer schon durch ist, damit eine Fortsetzung niemanden zweimal anlegt. Sie
  // hing frueher am ganzen Import: bei 12.000 Personen ueber 240 Fortsetzungen wurden dabei rund
  // 1,4 Millionen Zeilen gelesen, und der letzte Aufruf war der teuerste - genau verkehrt herum.
  // Jetzt haengt sie an der laufenden Seite und bleibt damit beschraenkt. Ueber Seiten hinweg
  // schuetzt weiterhin die Duplikatpruefung der Vorschau, und createTenantUser findet ein
  // bestehendes Konto ohnehin wieder.
  // Der Zeiger sagt in konstanter Zeit, wo diese Seite steht. Vorher las jede Fortsetzung alle
  // bisher verarbeiteten Ergebniszeilen - der Aufwand wuchs mit jedem Schritt, und der letzte
  // Schritt eines grossen Imports war der teuerste, obwohl dort das CPU-Zeitlimit der Plattform am
  // naechsten ist. Jetzt kostet jede Fortsetzung dasselbe.
  //
  // Die Ergebnismenge bleibt als Sicherung fuer den Fall, dass ein Aufruf nach dem Anlegen, aber
  // vor dem Fortschreiben des Zeigers abbricht - sie deckt dann genau das eine Fenster ab, das der
  // Zeiger noch nicht kennt, statt der ganzen Seite.
  const zeiger=Math.max(0,Number(seite.applied_upto)||0);
  const erledigt=new Set((((await env.DB.prepare('SELECT email,course_id FROM participant_import_results WHERE batch_id=? AND tenant_id=? ORDER BY created_at DESC LIMIT ?').bind(seite.id,tenantId,PARTICIPANT_APPLY_MAX*2).all<{email:string;course_id:string|null}>()).results)??[]).map(x=>kursSchluessel(String(x.email||''),x.course_id)));
  // bisI ist der Index der ersten Zeile, die NOCH NICHT durch ist. Erledigt heisst hier auch
  // "uebersprungen" oder "beanstandet" - die kommen nie mehr dran. Nur die erste zurueckgestellte
  // Zeile haelt den Zeiger an; ab ihr beginnt der naechste Aufruf.
  let bearbeitet=0,offen=0,bisI=zeiger,angehalten=false;
  for(let i=zeiger;i<rows.length;i++){
    const r=rows[i];
    if(!selected.has(i)){if(!angehalten)bisI=i+1;continue;}
    if(!r.display_name||!r.email||!r.course_id||r.warnings.some(w=>blocking.has(w))){results.push({index:i,action:'skipped',reason:'REVIEW_REQUIRED'});if(!angehalten)bisI=i+1;continue;}
    if(erledigt.has(kursSchluessel(r.email,r.course_id))){results.push({index:i,action:'already_applied'});if(!angehalten)bisI=i+1;continue;}
    if(bearbeitet>=grenze){offen++;if(!angehalten){bisI=i;angehalten=true;}continue;}
    bearbeitet++;
    const ts=nowIso();
    try{
      const created=await createTenantUser(env,auth,tenantId,{display_name:r.display_name,email:r.email,role:'participant',course_id:r.course_id,no_portal_access:istErsatzAdresse(r.email)});
      if(r.external_id)await env.DB.prepare("UPDATE tenant_users SET external_id=COALESCE(external_id,?),source=CASE WHEN source='manual' THEN 'import' ELSE source END,updated_at=? WHERE tenant_id=? AND user_id=? AND (external_id IS NULL OR external_id=?)").bind(r.external_id,ts,tenantId,created.user_id,r.external_id).run();
      const action=created.invitation_sent?'created_invited':'existing_added';
      await env.DB.prepare('INSERT INTO participant_import_results(id,batch_id,tenant_id,course_id,user_id,email,display_name,external_id,action,detail_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').bind(id('pir_'),seite.id,tenantId,r.course_id,created.user_id,r.email,r.display_name,r.external_id,action,JSON.stringify({enrollment_start:r.enrollment_start,enrollment_end:r.enrollment_end,org_path:r.org_path}),ts).run();
      erledigt.add(kursSchluessel(r.email,r.course_id));
      results.push({index:i,action,user_id:created.user_id,invitation_sent:created.invitation_sent});
    }catch(e){
      // Auch das Scheitern wird festgehalten. Sonst versuchte es jeder Folgeaufruf erneut, kaeme
      // nie ans Ende der Liste - und niemand koennte spaeter nachlesen, wer nicht angelegt wurde.
      const grund=String((e as Error).message||e).slice(0,200);
      await env.DB.prepare('INSERT INTO participant_import_results(id,batch_id,tenant_id,course_id,user_id,email,display_name,external_id,action,detail_json,created_at) VALUES(?,?,?,?,NULL,?,?,?,?,?,?)').bind(id('pir_'),seite.id,tenantId,r.course_id,r.email,r.display_name,r.external_id,'skipped',JSON.stringify({reason:grund}),ts).run();
      erledigt.add(kursSchluessel(r.email,r.course_id));
      results.push({index:i,action:'skipped',reason:grund});
    }
    // Angelegt oder mit festgehaltenem Grund gescheitert - beides heisst: diese Zeile kommt nicht
    // wieder. Der Zeiger darf weiter.
    if(!angehalten)bisI=i+1;
  }
  // Diese Seite ist durch, sobald auf ihr nichts mehr offen ist. Der ganze Import ist erst durch,
  // wenn danach keine Seite mehr wartet.
  // Bis hierhin ist die Seite sicher durch. Bricht der naechste Aufruf ab, beginnt er genau hier.
  const neuerZeiger=angehalten?bisI:rows.length;
  if(neuerZeiger>zeiger)await env.DB.prepare('UPDATE participant_import_batches SET applied_upto=? WHERE id=? AND tenant_id=?').bind(neuerZeiger,seite.id,tenantId).run();
  const seiteFertig=!offen;
  if(seiteFertig)await env.DB.prepare("UPDATE participant_import_batches SET status='applied',applied_at=? WHERE id=? AND tenant_id=? AND status='preview'").bind(nowIso(),seite.id,tenantId).run();
  const nochOffen=offen+spaeter,fertig=seiteFertig&&!spaeter;
  await audit(env.DB,auth.userId,'participants.import.applied',tenantId,undefined,'participant_import_batch',batchId,{page:seite.page_no,selected:selected.size,created:results.filter(x=>x.action==='created_invited').length,skipped:results.filter(x=>x.action==='skipped').length,remaining:nochOffen,completed:fertig});
  return{batch_id:batchId,results,completed:fertig,remaining:nochOffen};
}

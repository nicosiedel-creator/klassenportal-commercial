import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Anerkennung von Vorleistungen (P7).
//
// Wer eine abgeschlossene Ausbildung, Berufsjahre oder ein Zertifikat mitbringt, sitzt die Inhalte
// heute trotzdem ab - das System kennt Vorleistungen gar nicht. Fuer einen Traeger mit oeffentlicher
// Foerderung ist das nicht nur unbequem, sondern teuer: gefoerderte Stunden fuer Inhalte, die die
// Person nachweislich beherrscht.
//
// Die Anerkennung ist ein VERWALTUNGSAKT. Sie braucht deshalb, was jeder Verwaltungsakt braucht:
//  - einen Antrag, den die betroffene Person selbst stellen kann,
//  - eine Pruefung durch jemanden, der nicht die antragstellende Person ist,
//  - eine BEGRUENDETE Entscheidung - auch und gerade bei Ablehnung,
//  - einen Hinweis auf den Rechtsbehelf.
//
// Und im Zeugnis muss erkennbar bleiben, was geprueft und was anerkannt wurde. Beides gleich
// auszuweisen waere eine Faelschung des Nachweises - der naechste Arbeitgeber liest es als
// "hat die Pruefung abgelegt".

export const ARTEN=['schulabschluss','berufsausbildung','berufserfahrung','zertifikat','hochschule','sonstiges'] as const;
export const ENTSCHEIDUNGEN=['anerkannt','teilweise','abgelehnt'] as const;
const clean=(v:unknown,n=5000)=>safeString(v,n);

export async function beantrageAnerkennung(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const fuer=clean(input.user_id,120)||auth.userId;
  // Fuer sich selbst darf jeder. Fuer andere nur die Verwaltung - sonst koennte jemand Vorleistungen
  // in fremdem Namen behaupten.
  if(fuer!==auth.userId)requireRole(auth,'class_admin');
  const art=clean(input.art,40),beschreibung=clean(input.beschreibung,5000);
  if(!(ARTEN as readonly string[]).includes(art))throw new Error('VORLEISTUNG_ART_UNGUELTIG');
  if(beschreibung.length<20)throw new Error('VORLEISTUNG_BESCHREIBUNG_ERFORDERLICH');
  const mitglied=await env.DB.prepare("SELECT 1 AS ok FROM tenant_users WHERE tenant_id=? AND user_id=? AND status='active'").bind(tenantId,fuer).first();
  if(!mitglied)throw new Error('VORLEISTUNG_PERSON_NICHT_GEFUNDEN');
  const ts=nowIso(),claimId=id('vor_');
  await env.DB.prepare("INSERT INTO prior_learning_claims(id,tenant_id,user_id,course_id,art,beschreibung,nachweis_file_id,externe_stelle,zeitraum_von,zeitraum_bis,status,beantragt_am,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,'offen',?,?)")
    .bind(claimId,tenantId,fuer,clean(input.course_id,120)||null,art,beschreibung,clean(input.nachweis_file_id,120)||null,
      clean(input.externe_stelle,200)||null,clean(input.zeitraum_von,40)||null,clean(input.zeitraum_bis,40)||null,ts,ts).run();
  await audit(env.DB,auth.userId,'prior_learning.filed',tenantId,undefined,'prior_learning_claim',claimId,{art});
  return{id:claimId,status:'offen'};
}

export async function meineAnerkennungen(env:Env,auth:CoreAuthContext,tenantId:string){
  return ((await env.DB.prepare('SELECT id,art,beschreibung,status,entscheidung_begruendung,entschieden_am,beantragt_am FROM prior_learning_claims WHERE tenant_id=? AND user_id=? ORDER BY beantragt_am DESC LIMIT 100')
    .bind(tenantId,auth.userId).all()).results)??[];
}

export async function ziehAnerkennungZurueck(env:Env,auth:CoreAuthContext,tenantId:string,claimId:string){
  const antrag=await env.DB.prepare('SELECT user_id,status FROM prior_learning_claims WHERE id=? AND tenant_id=?').bind(claimId,tenantId).first<{user_id:string;status:string}>();
  if(!antrag)throw new Error('VORLEISTUNG_NICHT_GEFUNDEN');
  if(antrag.user_id!==auth.userId)throw new Error('VORLEISTUNG_KEIN_EIGENER_ANTRAG');
  if(!['offen','in_pruefung'].includes(antrag.status))throw new Error('VORLEISTUNG_BEREITS_ENTSCHIEDEN');
  await env.DB.prepare("UPDATE prior_learning_claims SET status='zurueckgezogen',updated_at=? WHERE id=? AND tenant_id=?").bind(nowIso(),claimId,tenantId).run();
  return{zurueckgezogen:true};
}

export async function listeAnerkennungen(env:Env,auth:CoreAuthContext,tenantId:string,nurOffen=true){
  requireRole(auth,'class_admin');
  const sql=nurOffen
    ? "SELECT c.id,c.user_id,u.display_name,c.art,c.beschreibung,c.status,c.beantragt_am FROM prior_learning_claims c JOIN users u ON u.id=c.user_id WHERE c.tenant_id=? AND c.status IN ('offen','in_pruefung') ORDER BY c.beantragt_am"
    : "SELECT c.id,c.user_id,u.display_name,c.art,c.status,c.entschieden_am,c.beantragt_am FROM prior_learning_claims c JOIN users u ON u.id=c.user_id WHERE c.tenant_id=? ORDER BY c.beantragt_am DESC LIMIT 200";
  return ((await env.DB.prepare(sql).bind(tenantId).all()).results)??[];
}

export async function anerkennungLesen(env:Env,auth:CoreAuthContext,tenantId:string,claimId:string){
  const antrag=await env.DB.prepare('SELECT * FROM prior_learning_claims WHERE id=? AND tenant_id=?').bind(claimId,tenantId).first<Record<string,unknown>>();
  if(!antrag)throw new Error('VORLEISTUNG_NICHT_GEFUNDEN');
  if(String(antrag.user_id)!==auth.userId)requireRole(auth,'class_admin');
  const anrechnungen=((await env.DB.prepare('SELECT art,bezug_id,umfang_prozent,bemerkung FROM prior_learning_credits WHERE claim_id=? AND tenant_id=? ORDER BY art,bezug_id')
    .bind(claimId,tenantId).all()).results)??[];
  return{antrag,anrechnungen};
}

/**
 * Entscheiden.
 *
 * Die Begruendung ist Pflicht - bei Ablehnung genauso wie bei Anerkennung. Wer eine Vorleistung
 * ablehnt, muss sagen warum; sonst kann die Person dagegen nichts vorbringen, und genau daran
 * scheitert der Bescheid im Widerspruch.
 */
export async function entscheideAnerkennung(env:Env,auth:CoreAuthContext,tenantId:string,claimId:string,input:Record<string,unknown>){
  requireRole(auth,'class_admin');
  const antrag=await env.DB.prepare('SELECT id,user_id,status FROM prior_learning_claims WHERE id=? AND tenant_id=?').bind(claimId,tenantId).first<{id:string;user_id:string;status:string}>();
  if(!antrag)throw new Error('VORLEISTUNG_NICHT_GEFUNDEN');
  if(!['offen','in_pruefung'].includes(antrag.status))throw new Error('VORLEISTUNG_BEREITS_ENTSCHIEDEN');
  // Niemand entscheidet ueber den eigenen Antrag. Das ist keine Formalie: es ist der Unterschied
  // zwischen einer Pruefung und einer Selbstbedienung.
  if(antrag.user_id===auth.userId&&!auth.isPlatformAdmin)throw new Error('VORLEISTUNG_EIGENER_ANTRAG');
  const entscheidung=clean(input.entscheidung,30),begruendung=clean(input.begruendung,5000);
  if(!(ENTSCHEIDUNGEN as readonly string[]).includes(entscheidung))throw new Error('VORLEISTUNG_ENTSCHEIDUNG_UNGUELTIG');
  if(begruendung.length<20)throw new Error('VORLEISTUNG_BEGRUENDUNG_ERFORDERLICH');
  const roh=Array.isArray(input.anrechnungen)?input.anrechnungen as Record<string,unknown>[]:[];
  if(entscheidung==='abgelehnt'&&roh.length)throw new Error('VORLEISTUNG_ABLEHNUNG_OHNE_ANRECHNUNG');
  if(entscheidung!=='abgelehnt'&&!roh.length)throw new Error('VORLEISTUNG_ANRECHNUNG_ERFORDERLICH');
  const ts=nowIso(),anweisungen=[env.DB.prepare('UPDATE prior_learning_claims SET status=?,entscheidung_begruendung=?,geprueft_von=?,entschieden_am=?,updated_at=? WHERE id=? AND tenant_id=?')
    .bind(entscheidung,begruendung,auth.userId,ts,ts,claimId,tenantId)];
  for(const a of roh.slice(0,200)){
    const art=clean(a.art,20),bezug=clean(a.bezug_id,120);
    if(!['lernfeld','kompetenz'].includes(art)||!bezug)throw new Error('VORLEISTUNG_ANRECHNUNG_UNGUELTIG');
    const prozent=Math.trunc(Number(a.umfang_prozent??100));
    if(!Number.isFinite(prozent)||prozent<1||prozent>100)throw new Error('VORLEISTUNG_UMFANG_UNGUELTIG');
    anweisungen.push(env.DB.prepare('INSERT INTO prior_learning_credits(id,tenant_id,claim_id,art,bezug_id,umfang_prozent,framework_version_id,bemerkung,erfasst_am) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(claim_id,art,bezug_id) DO UPDATE SET umfang_prozent=excluded.umfang_prozent,bemerkung=excluded.bemerkung')
      .bind(id('vok_'),tenantId,claimId,art,bezug,prozent,clean(a.framework_version_id,120)||null,clean(a.bemerkung,500)||null,ts));
  }
  anweisungen.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'prior_learning_decided',?,?,?)")
    .bind(id('ntf_'),tenantId,antrag.user_id,'Entscheidung über Ihre Vorleistung',
      `Über Ihren Antrag wurde entschieden. Die Begründung steht in Ihrem Vorgang; gegen die Entscheidung können Sie Widerspruch einlegen.`,ts));
  for(let i=0;i<anweisungen.length;i+=90)await env.DB.batch(anweisungen.slice(i,i+90));
  await audit(env.DB,auth.userId,'prior_learning.decided',tenantId,undefined,'prior_learning_claim',claimId,{entscheidung,anrechnungen:roh.length});
  return{entscheidung,anrechnungen:roh.length,rechtsbehelf:'Gegen diese Entscheidung kann Widerspruch eingelegt werden.'};
}

/**
 * Was ist bei dieser Person anerkannt - und was ist geprueft?
 *
 * Fuer das Zeugnis. Die Unterscheidung ist der Kern: eine anerkannte Vorleistung ist kein
 * abgelegter Leistungsnachweis, und wer beides gleich ausweist, faelscht den Nachweis.
 */
export async function anerkannteLeistungen(env:Env,tenantId:string,userId:string):Promise<{art:string;bezug_id:string;umfang_prozent:number;quelle:string}[]>{
  const zeilen=((await env.DB.prepare("SELECT k.art,k.bezug_id,k.umfang_prozent,c.art AS quelle FROM prior_learning_credits k JOIN prior_learning_claims c ON c.id=k.claim_id WHERE k.tenant_id=? AND c.user_id=? AND c.status IN ('anerkannt','teilweise') ORDER BY k.art,k.bezug_id")
    .bind(tenantId,userId).all<{art:string;bezug_id:string;umfang_prozent:number;quelle:string}>()).results)??[];
  return zeilen;
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';
import { ausgeschlosseneKontakte, sorgeberechtigteFuerTeilnehmer } from './access-restrictions.js';

// Krisenkommunikation.
//
// Eine Meldung anzuzeigen ist keine Krisenkommunikation. Drei Dinge machen den Unterschied, und
// alle drei zeigen sich erst im Ernstfall:
//
//  1. WER hat sie gelesen? "Wurde versendet" ist im Schadensfall keine Aussage. Deshalb eine
//     namentliche Empfaengerliste mit Bestaetigung - nicht nur ein Zaehler.
//  2. Was, wenn der Weg ausfaellt? Genau dann braucht die Leitung die Telefonliste derer, die NICHT
//     bestaetigt haben - sofort, nicht nach einer Stunde Suchen in Ordnern. Das ist der
//     Ausfallkanal: keine zweite Technik, sondern die Liste, die man abtelefoniert.
//  3. Wer beendet die Lage? Eine Krise ohne ausdrueckliche Entwarnung bleibt in den Koepfen - und
//     die naechste echte Meldung wird dann nicht mehr ernst genommen.
//
// Sorgeberechtigte werden mitbenachrichtigt, aber ueber dieselbe Pruefung wie sonst auch: wer unter
// Kontaktverbot steht, bekommt auch eine Krisenmeldung nicht.

export const STUFEN=['info','warnung','gefahr'] as const;
// Nach dieser Zeit ohne Bestaetigung wird erinnert. Bei 'gefahr' frueher - dort zaehlen Minuten.
export const ERINNERUNG_MINUTEN:Record<string,number>={gefahr:15,warnung:60,info:240};
const clean=(v:unknown,n=5000)=>safeString(v,n);

export async function setzeNotfallkontakt(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  const person=clean(input.user_id,120)||auth.userId;
  // Fuer sich selbst darf jeder; fuer andere nur die Leitung.
  if(person!==auth.userId)requireRole(auth,'tenant_admin');
  const telefon=clean(input.telefon,60);
  if(telefon.length<5)throw new Error('NOTFALLKONTAKT_TELEFON_ERFORDERLICH');
  const ts=nowIso();
  await env.DB.prepare('INSERT INTO emergency_contacts(tenant_id,user_id,telefon,hinweis,erfasst_von,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(tenant_id,user_id) DO UPDATE SET telefon=excluded.telefon,hinweis=excluded.hinweis,erfasst_von=excluded.erfasst_von,updated_at=excluded.updated_at')
    .bind(tenantId,person,telefon,clean(input.hinweis,200)||null,auth.userId,ts).run();
  return{gespeichert:true};
}

/**
 * Krise ausloesen.
 *
 * Die Empfaengerliste wird als Momentaufnahme festgeschrieben - wer spaeter dazukommt, gehoerte
 * nicht zur Lage, und wer ausscheidet, war trotzdem betroffen. Ohne diese Momentaufnahme liesse
 * sich hinterher nicht sagen, wen man erreicht hat.
 */
export async function loeseKriseAus(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const titel=clean(input.titel,200),text=clean(input.text,5000),stufe=clean(input.stufe,20)||'warnung';
  const ausfallkanal=clean(input.ausfallkanal,500);
  if(titel.length<3||text.length<10)throw new Error('KRISE_TEXT_ERFORDERLICH');
  if(!STUFEN.includes(stufe as never))throw new Error('KRISE_STUFE_UNGUELTIG');
  // Der Ausfallkanal steht VORHER fest. Im Ernstfall denkt ihn niemand mehr aus.
  if(ausfallkanal.length<10)throw new Error('KRISE_AUSFALLKANAL_ERFORDERLICH');
  const mitglieder=((await env.DB.prepare("SELECT DISTINCT tu.user_id FROM tenant_users tu JOIN users u ON u.id=tu.user_id WHERE tu.tenant_id=? AND tu.status='active' AND u.status='active'")
    .bind(tenantId).all<{user_id:string}>()).results)??[];
  const teilnehmer=((await env.DB.prepare("SELECT DISTINCT user_id FROM memberships WHERE tenant_id=? AND role='participant'").bind(tenantId).all<{user_id:string}>()).results)??[];
  const sorgeberechtigte=await sorgeberechtigteFuerTeilnehmer(env,tenantId,teilnehmer.map(t=>t.user_id));
  // Ein Kontaktverbot gilt auch hier: eine Krisenmeldung sagt regelmaessig, wo Menschen gerade
  // sind. Ausgeschlossen wird nur, wer ausschliesslich ueber die Sorgeverknuepfung im Mandanten ist.
  const gesperrt=await ausgeschlosseneKontakte(env,tenantId);
  const eigene=new Set(mitglieder.filter(m=>!gesperrt.has(m.user_id)).map(m=>m.user_id));
  const ts=nowIso(),alertId=id('kri_');
  const empfaenger=[...mitglieder.filter(m=>!gesperrt.has(m.user_id)).map(m=>({user_id:m.user_id,grund:'mitglied'})),
    ...sorgeberechtigte.filter(s=>!eigene.has(s)).map(s=>({user_id:s,grund:'sorgeberechtigt'}))];
  if(!empfaenger.length)throw new Error('KRISE_KEINE_EMPFAENGER');
  const anweisungen=[env.DB.prepare('INSERT INTO crisis_alerts(id,tenant_id,titel,text,stufe,ausfallkanal,bestaetigung_pflicht,ausgeloest_von,ausgeloest_am,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .bind(alertId,tenantId,titel,text,stufe,ausfallkanal,input.bestaetigung_pflicht===false?0:1,auth.userId,ts,ts)];
  for(const e of empfaenger){
    anweisungen.push(env.DB.prepare('INSERT INTO crisis_alert_recipients(alert_id,tenant_id,user_id,grund,zugestellt_am) VALUES(?,?,?,?,?)').bind(alertId,tenantId,e.user_id,e.grund,ts));
    anweisungen.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'crisis_alert',?,?,?)")
      .bind(id('ntf_'),tenantId,e.user_id,`${stufe==='gefahr'?'GEFAHR: ':''}${titel}`,text,ts));
  }
  // In Stapeln, damit auch ein Traeger mit tausend Menschen nicht an der Unteranfragen-Grenze
  // scheitert - und zwar ausgerechnet im Ernstfall.
  for(let i=0;i<anweisungen.length;i+=80)await env.DB.batch(anweisungen.slice(i,i+80));
  await audit(env.DB,auth.userId,'crisis.raised',tenantId,undefined,'crisis_alert',alertId,{stufe,empfaenger:empfaenger.length});
  return{id:alertId,empfaenger:empfaenger.length,stufe};
}

export async function bestaetigeKrise(env:Env,auth:CoreAuthContext,tenantId:string,alertId:string){
  const r=await env.DB.prepare('UPDATE crisis_alert_recipients SET bestaetigt_am=COALESCE(bestaetigt_am,?) WHERE alert_id=? AND tenant_id=? AND user_id=?')
    .bind(nowIso(),alertId,tenantId,auth.userId).run();
  if(!r.meta?.changes)throw new Error('KRISE_NICHT_ADRESSIERT');
  return{bestaetigt:true};
}

export async function meineKrisen(env:Env,auth:CoreAuthContext,tenantId:string){
  return ((await env.DB.prepare('SELECT a.id,a.titel,a.text,a.stufe,a.ausfallkanal,a.ausgeloest_am,a.beendet_am,a.entwarnung,r.bestaetigt_am FROM crisis_alert_recipients r JOIN crisis_alerts a ON a.id=r.alert_id WHERE r.tenant_id=? AND r.user_id=? ORDER BY a.ausgeloest_am DESC LIMIT 50')
    .bind(tenantId,auth.userId).all()).results)??[];
}

/**
 * Der Lagestand - und der Ausfallkanal.
 *
 * Die Telefonliste enthaelt NUR die, die nicht bestaetigt haben. Wer bestaetigt hat, ist erreicht;
 * seine Nummer hat in dieser Liste nichts zu suchen.
 */
export async function krisenstand(env:Env,auth:CoreAuthContext,tenantId:string,alertId:string){
  requireRole(auth,'tenant_admin');
  const lage=await env.DB.prepare('SELECT * FROM crisis_alerts WHERE id=? AND tenant_id=?').bind(alertId,tenantId).first<Record<string,unknown>>();
  if(!lage)throw new Error('KRISE_NICHT_GEFUNDEN');
  const zahlen=await env.DB.prepare('SELECT COUNT(*) gesamt,SUM(CASE WHEN bestaetigt_am IS NOT NULL THEN 1 ELSE 0 END) bestaetigt FROM crisis_alert_recipients WHERE alert_id=?')
    .bind(alertId).first<{gesamt:number;bestaetigt:number}>();
  const offen=((await env.DB.prepare('SELECT r.user_id,u.display_name,r.grund,r.erinnerungen,e.telefon FROM crisis_alert_recipients r JOIN users u ON u.id=r.user_id LEFT JOIN emergency_contacts e ON e.tenant_id=r.tenant_id AND e.user_id=r.user_id WHERE r.alert_id=? AND r.bestaetigt_am IS NULL ORDER BY e.telefon IS NULL,u.display_name LIMIT 500')
    .bind(alertId).all()).results)??[];
  return{lage,gesamt:Number(zahlen?.gesamt??0),bestaetigt:Number(zahlen?.bestaetigt??0),
    offen,ohne_telefon:offen.filter(o=>!(o as Record<string,unknown>).telefon).length};
}

export async function listeKrisen(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return ((await env.DB.prepare('SELECT a.id,a.titel,a.stufe,a.ausgeloest_am,a.beendet_am,(SELECT COUNT(*) FROM crisis_alert_recipients r WHERE r.alert_id=a.id) gesamt,(SELECT COUNT(*) FROM crisis_alert_recipients r WHERE r.alert_id=a.id AND r.bestaetigt_am IS NOT NULL) bestaetigt FROM crisis_alerts a WHERE a.tenant_id=? ORDER BY a.ausgeloest_am DESC LIMIT 50')
    .bind(tenantId).all()).results)??[];
}

/** Entwarnung. Ausdruecklich, mit Text, und an denselben Kreis wie die Meldung. */
export async function gibEntwarnung(env:Env,auth:CoreAuthContext,tenantId:string,alertId:string,text:unknown){
  requireRole(auth,'tenant_admin');
  const entwarnung=clean(text,2000);
  if(entwarnung.length<10)throw new Error('KRISE_ENTWARNUNG_ERFORDERLICH');
  const ts=nowIso();
  const lage=await env.DB.prepare('SELECT titel,beendet_am FROM crisis_alerts WHERE id=? AND tenant_id=?').bind(alertId,tenantId).first<{titel:string;beendet_am:string|null}>();
  if(!lage)throw new Error('KRISE_NICHT_GEFUNDEN');
  if(lage.beendet_am)throw new Error('KRISE_BEREITS_BEENDET');
  const empfaenger=((await env.DB.prepare('SELECT user_id FROM crisis_alert_recipients WHERE alert_id=?').bind(alertId).all<{user_id:string}>()).results)??[];
  const anweisungen=[env.DB.prepare('UPDATE crisis_alerts SET beendet_am=?,entwarnung=?,beendet_von=?,updated_at=? WHERE id=? AND tenant_id=?').bind(ts,entwarnung,auth.userId,ts,alertId,tenantId)];
  for(const e of empfaenger)anweisungen.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'crisis_all_clear',?,?,?)")
    .bind(id('ntf_'),tenantId,e.user_id,`Entwarnung: ${lage.titel}`,entwarnung,ts));
  for(let i=0;i<anweisungen.length;i+=80)await env.DB.batch(anweisungen.slice(i,i+80));
  await audit(env.DB,auth.userId,'crisis.cleared',tenantId,undefined,'crisis_alert',alertId);
  return{beendet:true,benachrichtigt:empfaenger.length};
}

/**
 * Erinnern, solange die Lage laeuft und nicht bestaetigt ist.
 *
 * Gedeckelt: hoechstens zehn laufende Lagen und je Lage 200 Personen pro Durchgang. Eine Krise
 * darf das System nicht an die Unteranfragen-Grenze fahren - dann faellt genau im Ernstfall alles
 * andere aus.
 */
export async function erinnereAnKrisen(env:Env,grenze=10,jetzt=nowIso()):Promise<{erinnert:number;lagen:number}>{
  const lagen=((await env.DB.prepare('SELECT id,tenant_id,titel,stufe FROM crisis_alerts WHERE beendet_am IS NULL AND bestaetigung_pflicht=1 ORDER BY ausgeloest_am LIMIT ?')
    .bind(Math.max(1,Math.min(50,grenze))).all<{id:string;tenant_id:string;titel:string;stufe:string}>()).results)??[];
  let erinnert=0;
  for(const lage of lagen){
    const grenzwert=new Date(Date.parse(jetzt)-(ERINNERUNG_MINUTEN[lage.stufe]??60)*60000).toISOString();
    const offen=((await env.DB.prepare('SELECT user_id FROM crisis_alert_recipients WHERE alert_id=? AND bestaetigt_am IS NULL AND COALESCE(letzte_erinnerung_am,zugestellt_am)<=? LIMIT 200')
      .bind(lage.id,grenzwert).all<{user_id:string}>()).results)??[];
    if(!offen.length)continue;
    const anweisungen=[];
    for(const o of offen){
      anweisungen.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'crisis_reminder',?,?,?)")
        .bind(id('ntf_'),lage.tenant_id,o.user_id,`Bitte bestätigen: ${lage.titel}`,'Bitte bestätigen Sie, dass Sie diese Meldung gelesen haben.',jetzt));
      anweisungen.push(env.DB.prepare('UPDATE crisis_alert_recipients SET erinnerungen=erinnerungen+1,letzte_erinnerung_am=? WHERE alert_id=? AND user_id=?').bind(jetzt,lage.id,o.user_id));
      erinnert++;
    }
    for(let i=0;i<anweisungen.length;i+=80)await env.DB.batch(anweisungen.slice(i,i+80));
  }
  return{erinnert,lagen:lagen.length};
}

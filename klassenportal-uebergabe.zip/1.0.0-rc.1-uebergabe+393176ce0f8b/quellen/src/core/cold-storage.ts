// Heisse und kalte Daten trennen.
//
// D1 ist bei 10 GB zu Ende (siehe storage-growth.ts). Der groesste Teil dieser 10 GB ist Betrieb,
// der laengst vorbei ist: Anwesenheit aus abgeschlossenen Schuljahren, Protokolle, Ereignisse.
// Diese Zeilen muessen aufbewahrt werden - sie muessen aber nicht in der Datenbank liegen, die
// jeden Tag beschrieben wird.
//
// Deshalb: kalte Daten wandern als JSONL in den Objektspeicher und werden in D1 geloescht. Der
// Objektspeicher hat keine 10-GB-Grenze. Zwei Dinge sind daran unverhandelbar:
//
// 1. Geprueft vor geloescht. Erst schreiben, dann das Geschriebene ZURUECKLESEN, Zeilenzahl und
//    SHA-256 vergleichen - und nur wenn beides stimmt, in D1 loeschen. Ein Auslagern, das Daten
//    verliert, waere schlimmer als eine volle Datenbank.
// 2. Sichtbar bleiben. Jede Auslagerung steht in cold_archives, die Auskunft nach Artikel 15 liest
//    die Archive mit, und beim Vertragsende werden die Objekte mitgeloescht. Ausgelagert heisst
//    nicht verschwunden.
//
// Bewusst NICHT automatisch: es gibt keinen Hintergrundlauf, der von sich aus Betriebsdaten aus der
// Datenbank nimmt. Die Auslagerung startet die Plattformadministration fuer einen Mandanten und
// einen abgeschlossenen Zeitraum. Was ein Traeger noch braucht, weiss der Traeger, nicht der Cron.
import type { Env, CoreAuthContext } from './types.js';
import { requirePlatform } from './permissions.js';
import { id, nowIso } from './utils.js';

// Nur Zeitraeume, die lange vorbei sind. Ein laufendes oder gerade abgeschlossenes Schuljahr wird
// noch fuer Zeugnisse, Berichtshefte und Nachpruefungen gebraucht.
export const MINDESTALTER_JAHRE = 2;

// Je Tabelle muss ausdruecklich stehen, wie die alten Zeilen gefunden und wieder entfernt werden.
// Was hier nicht steht, wird nicht ausgelagert - fail closed. Eine Tabelle "einfach mitzunehmen",
// deren Loeschregel niemand geprueft hat, ist genau der Weg, auf dem Daten verschwinden.
type Kalttabelle = {
  // Liest die auszulagernden Zeilen. Immer mandantengebunden, immer mit Stichtag.
  lesen: (limit: number) => { sql: string; args: unknown[] };
  // Baut das Loeschen fuer die tatsaechlich gesicherten Zeilen - nie pauschal ueber den Stichtag,
  // sondern ueber genau die Schluessel, die im Objekt stehen.
  loeschen: (zeilen: Array<Record<string, unknown>>) => Array<{ sql: string; args: unknown[] }>;
};

function bloecke<T>(xs: T[], groesse: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < xs.length; i += groesse) out.push(xs.slice(i, i + groesse));
  return out;
}
const platzhalter = (n: number) => new Array(n).fill('?').join(',');

export const KALTTABELLEN: Record<string, (tenantId: string, stichtag: string) => Kalttabelle> = {
  // Die mit Abstand groesste Tabelle: eine Zeile je Person und Unterrichtseinheit. Ihr Datum
  // steht nicht in ihr selbst, sondern an der Einheit - deshalb der Verbund.
  attendance_records: (tenantId, stichtag) => ({
    lesen: (limit) => ({
      sql: 'SELECT r.* FROM attendance_records r JOIN attendance_sessions s ON s.id=r.session_id ' +
           'WHERE r.tenant_id=? AND s.session_date<? ORDER BY r.session_id,r.user_id LIMIT ?',
      args: [tenantId, stichtag, limit],
    }),
    loeschen: (zeilen) => {
      const sitzungen = [...new Set(zeilen.map(z => String(z.session_id)))];
      return bloecke(sitzungen, 200).map(blk => ({
        sql: `DELETE FROM attendance_records WHERE tenant_id=? AND session_id IN (${platzhalter(blk.length)})`,
        args: [tenantId, ...blk],
      }));
    },
  }),
  attendance_events: (tenantId, stichtag) => ({
    lesen: (limit) => ({
      sql: 'SELECT * FROM attendance_events WHERE tenant_id=? AND created_at<? ORDER BY created_at LIMIT ?',
      args: [tenantId, `${stichtag}T00:00:00.000Z`, limit],
    }),
    loeschen: (zeilen) => bloecke(zeilen.map(z => String(z.id)), 200).map(blk => ({
      sql: `DELETE FROM attendance_events WHERE tenant_id=? AND id IN (${platzhalter(blk.length)})`,
      args: [tenantId, ...blk],
    })),
  }),
  audit_log: (tenantId, stichtag) => ({
    lesen: (limit) => ({
      sql: 'SELECT * FROM audit_log WHERE tenant_id=? AND created_at<? ORDER BY created_at LIMIT ?',
      args: [tenantId, `${stichtag}T00:00:00.000Z`, limit],
    }),
    loeschen: (zeilen) => bloecke(zeilen.map(z => String(z.id)), 200).map(blk => ({
      sql: `DELETE FROM audit_log WHERE tenant_id=? AND id IN (${platzhalter(blk.length)})`,
      args: [tenantId, ...blk],
    })),
  }),
};

// Wie viele Zeilen ein Aufruf hoechstens mitnimmt. Die Plattform zaehlt Unteranfragen (1000 je
// Aufruf); ein Stapel zaehlt als eine. Bei 200 Sitzungen je Loeschanweisung bleibt reichlich Luft.
export const ZEILEN_JE_LAUF = 20000;

export function stichtagFuer(jahr: number): string { return `${jahr + 1}-01-01`; }

function objektschluessel(tenantId: string, tabelle: string, jahr: number): string {
  return `cold/${tenantId}/${tabelle}/${jahr}.jsonl`;
}

async function sha256(text: string): Promise<string> {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function archivierbareJahre(env: Env, auth: CoreAuthContext) {
  requirePlatform(auth);
  const grenze = new Date().getUTCFullYear() - MINDESTALTER_JAHRE;
  return { bis_einschliesslich_jahr: grenze - 1, mindestalter_jahre: MINDESTALTER_JAHRE, tabellen: Object.keys(KALTTABELLEN) };
}

// Lagert einen Zeitraum aus. Laeuft absichtlich in Haeppchen: der Aufruf meldet
// completed=false, solange noch Zeilen offen sind, und wird erneut aufgerufen.
export async function archiviereKaltdaten(env: Env, auth: CoreAuthContext, tenantId: string, tabelle: string, jahr: number) {
  requirePlatform(auth);
  const bauer = KALTTABELLEN[tabelle];
  if (!bauer) throw new Error('COLD_TABLE_NOT_ARCHIVABLE');
  const jetzt = new Date().getUTCFullYear();
  if (!Number.isInteger(jahr) || jahr > jetzt - MINDESTALTER_JAHRE) throw new Error('COLD_PERIOD_TOO_RECENT');

  const tabelleObj = bauer(tenantId, stichtagFuer(jahr));
  const abfrage = tabelleObj.lesen(ZEILEN_JE_LAUF);
  const zeilen = ((await env.DB.prepare(abfrage.sql).bind(...abfrage.args).all<Record<string, unknown>>()).results) ?? [];
  if (!zeilen.length) return { tabelle, jahr, archiviert: 0, completed: true, remaining: 0 };

  // Angehaengt wird nicht: ein zweiter Lauf schreibt ein eigenes Objekt mit laufender Nummer.
  // Ein Objekt zu ueberschreiben, waehrend die Quelle schon halb geloescht ist, waere der eine
  // Fehler, der nicht mehr zu reparieren ist.
  const vorhandene = Number((await env.DB.prepare('SELECT COUNT(*) n FROM cold_archives WHERE tenant_id=? AND table_name=? AND period=?').bind(tenantId, tabelle, String(jahr)).first<{ n: number }>())?.n || 0);
  const basis = objektschluessel(tenantId, tabelle, jahr);
  const schluessel = vorhandene ? basis.replace(/\.jsonl$/, `.${vorhandene + 1}.jsonl`) : basis;

  const jsonl = zeilen.map(z => JSON.stringify(z)).join('\n');
  const pruefsumme = await sha256(jsonl);
  await env.FILES.put(schluessel, jsonl, { httpMetadata: { contentType: 'application/x-ndjson' }, customMetadata: { tenantId, tabelle, jahr: String(jahr), zeilen: String(zeilen.length) } });

  // Geprueft vor geloescht: das Objekt wird zurueckgelesen und verglichen. Erst danach faellt in
  // D1 eine einzige Zeile.
  const zurueck = await env.FILES.get(schluessel);
  if (!zurueck) throw new Error('COLD_ARCHIVE_VERIFY_FAILED');
  const gelesen = await new Response(zurueck.body).text();
  if (await sha256(gelesen) !== pruefsumme) throw new Error('COLD_ARCHIVE_VERIFY_FAILED');
  if (gelesen.split('\n').length !== zeilen.length) throw new Error('COLD_ARCHIVE_VERIFY_FAILED');

  const ts = nowIso();
  await env.DB.prepare('INSERT INTO cold_archives (id,tenant_id,table_name,period,object_key,row_count,sha256,bytes,archived_by,archived_at) VALUES (?,?,?,?,?,?,?,?,?,?)')
    .bind(id('cold_'), tenantId, tabelle, String(jahr), schluessel, zeilen.length, pruefsumme, jsonl.length, auth.userId, ts).run();

  const loeschungen = tabelleObj.loeschen(zeilen);
  for (const blk of bloecke(loeschungen, 50)) await env.DB.batch(blk.map(x => env.DB.prepare(x.sql).bind(...x.args)));

  const rest = tabelleObj.lesen(1);
  const offen = ((await env.DB.prepare(rest.sql).bind(...rest.args).all()).results) ?? [];
  return { tabelle, jahr, archiviert: zeilen.length, object_key: schluessel, completed: offen.length === 0, remaining: offen.length ? 1 : 0 };
}

export async function kaltarchive(env: Env, auth: CoreAuthContext, tenantId: string) {
  requirePlatform(auth);
  return ((await env.DB.prepare('SELECT id,table_name,period,object_key,row_count,bytes,archived_at,restored_at FROM cold_archives WHERE tenant_id=? ORDER BY period DESC,table_name').bind(tenantId).all<Record<string, unknown>>()).results) ?? [];
}

const SPALTENNAME = /^[a-z][a-z0-9_]*$/;

// Zurueckholen. Notwendig, weil "ausgelagert" sonst "weg" hiesse: eine Nachpruefung, ein
// Rechtsstreit, eine Nachforderung der Aufsicht kann Jahre spaeter genau diese Zeilen brauchen.
export async function stelleKaltdatenWiederHer(env: Env, auth: CoreAuthContext, archivId: string) {
  requirePlatform(auth);
  const a = await env.DB.prepare('SELECT id,tenant_id,table_name,object_key,row_count,sha256 FROM cold_archives WHERE id=?').bind(archivId).first<{ id: string; tenant_id: string; table_name: string; object_key: string; row_count: number; sha256: string }>();
  if (!a) throw new Error('COLD_ARCHIVE_NOT_FOUND');
  if (!KALTTABELLEN[a.table_name]) throw new Error('COLD_TABLE_NOT_ARCHIVABLE');
  const obj = await env.FILES.get(a.object_key);
  if (!obj) throw new Error('COLD_ARCHIVE_OBJECT_MISSING');
  const text = await new Response(obj.body).text();
  if (await sha256(text) !== a.sha256) throw new Error('COLD_ARCHIVE_VERIFY_FAILED');
  const zeilen = text.split('\n').filter(Boolean).map(z => JSON.parse(z) as Record<string, unknown>);

  let eingefuegt = 0;
  for (const blk of bloecke(zeilen, 100)) {
    const anweisungen = blk.map(z => {
      const spalten = Object.keys(z);
      if (!spalten.every(s => SPALTENNAME.test(s))) throw new Error('COLD_ARCHIVE_COLUMN_INVALID');
      return env.DB.prepare(`INSERT OR IGNORE INTO ${a.table_name} (${spalten.join(',')}) VALUES (${platzhalter(spalten.length)})`).bind(...spalten.map(s => z[s] as unknown));
    });
    await env.DB.batch(anweisungen);
    eingefuegt += blk.length;
  }
  await env.DB.prepare('UPDATE cold_archives SET restored_at=? WHERE id=?').bind(nowIso(), archivId).run();
  return { archiv_id: archivId, tabelle: a.table_name, zurueckgeholt: eingefuegt };
}

// Artikel 15: Die Auskunft muss vollstaendig sein. Ausgelagerte Zeilen gehoeren dazu - sonst haette
// die Auslagerung die Auskunftspflicht ausgehebelt, ohne dass es jemand merkt.
export async function kalteDatenFuerPerson(env: Env, tenantId: string, userId: string): Promise<Record<string, Array<Record<string, unknown>>>> {
  const archive = ((await env.DB.prepare('SELECT table_name,object_key FROM cold_archives WHERE tenant_id=? AND restored_at IS NULL').bind(tenantId).all<{ table_name: string; object_key: string }>()).results) ?? [];
  const out: Record<string, Array<Record<string, unknown>>> = {};
  for (const a of archive) {
    const obj = await env.FILES.get(a.object_key).catch(() => null);
    if (!obj) continue;
    const text = await new Response(obj.body).text();
    for (const zeile of text.split('\n')) {
      if (!zeile) continue;
      let z: Record<string, unknown>;
      try { z = JSON.parse(zeile) as Record<string, unknown>; } catch { continue; }
      if (z.user_id !== userId && z.actor_user_id !== userId) continue;
      (out[a.table_name] ||= []).push(z);
    }
  }
  return out;
}

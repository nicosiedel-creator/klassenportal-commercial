import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { sorgeberechtigteFuerTeilnehmer } from './access-restrictions.js';
import { canManageOrgUnit } from './enterprise-access.js';
import { requireCourseAccess, requireRole } from './permissions.js';
import { mailConfigured } from './mail.js';
import { communicationEmailStats, deliverCommunicationEmails, retryFailedCommunicationEmails } from './communication-email.js';
import { bloeckeAusText, bloeckeLesen, darstellungen, parseBloecke, textDarstellung } from './communication-content.js';
import { entscheidungsAnweisung, kanalUrteil, nutzerMitPushGeraet, praeferenzenFuerNutzer, pruefeRangstufe, pruefeThema, pushAnweisung, themenAbwahlFuerNutzer, zeitzoneDesTraegers } from './notification-center.js';
import { id, nowIso, safeString } from './utils.js';

type Target={type:'tenant'|'org_unit'|'course'|'user';id:string|null;include_descendants:boolean};
type MessageRow={id:string;tenant_id:string;title:string;body:string;bloecke_json:string|null;rangstufe:string;thema:string;priority:string;status:string;starts_at:string|null;ends_at:string|null;require_read:number;require_ack:number;ack_due_at:string|null;send_email:number;an_sorgeberechtigte:number;recipient_count:number;published_at:string|null;created_by:string;created_at:string;updated_at:string};

function parseIso(v:unknown):string|null{const s=safeString(v,50);if(!s)return null;const d=new Date(s);if(Number.isNaN(d.getTime()))throw new Error('COMMUNICATION_DATE_INVALID');return d.toISOString();}
function priority(v:unknown){const x=String(v||'normal');if(!['info','normal','important','urgent'].includes(x))throw new Error('COMMUNICATION_PRIORITY_INVALID');return x;}
function targets(input:unknown):Target[]{if(!Array.isArray(input)||!input.length)throw new Error('COMMUNICATION_TARGET_REQUIRED');if(input.length>250)throw new Error('COMMUNICATION_TOO_MANY_TARGETS');const out:Target[]=[],seen=new Set<string>();for(const raw of input as any[]){const type=String(raw?.type||'') as Target['type'];if(!['tenant','org_unit','course','user'].includes(type))throw new Error('COMMUNICATION_TARGET_INVALID');const targetId=type==='tenant'?null:safeString(raw?.id,120)||null;if(type!=='tenant'&&!targetId)throw new Error('COMMUNICATION_TARGET_INVALID');const descendants=raw?.include_descendants!==false,key=`${type}:${targetId||''}:${descendants?1:0}`;if(seen.has(key))continue;seen.add(key);out.push({type,id:targetId,include_descendants:descendants});}return out;}
async function validateTarget(env:Env,auth:CoreAuthContext,tenantId:string,t:Target){
  if(t.type==='tenant'){if(!auth.isPlatformAdmin&&auth.role!=='tenant_admin')throw new Error('FORBIDDEN_COMMUNICATION_SCOPE');return;}
  if(t.type==='course'){const c=await env.DB.prepare('SELECT id FROM courses WHERE tenant_id=? AND id=? AND is_active=1').bind(tenantId,t.id).first();if(!c)throw new Error('COURSE_NOT_FOUND');requireCourseAccess(auth,String(t.id));return;}
  if(t.type==='org_unit'){const o=await env.DB.prepare("SELECT id FROM org_units WHERE tenant_id=? AND id=? AND status='active'").bind(tenantId,t.id).first();if(!o)throw new Error('ORG_UNIT_NOT_FOUND');if(!await canManageOrgUnit(env,auth,tenantId,String(t.id),'content.manage'))throw new Error('FORBIDDEN_COMMUNICATION_SCOPE');return;}
  const u=await env.DB.prepare("SELECT DISTINCT m.user_id FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.tenant_id=? AND m.user_id=? AND m.role='participant' AND u.status='active' LIMIT 1").bind(tenantId,t.id).first<{user_id:string}>();if(!u)throw new Error('PARTICIPANT_NOT_FOUND');if(!auth.isPlatformAdmin&&auth.role!=='tenant_admin'){const allowed=auth.courseIds??[];if(!allowed.length)throw new Error('FORBIDDEN_COMMUNICATION_SCOPE');const marks=allowed.map(()=>'?').join(',');const ok=await env.DB.prepare(`SELECT 1 AS ok FROM memberships WHERE tenant_id=? AND user_id=? AND role='participant' AND m.course_id IN (${marks})`.replace('AND m.course_id','AND course_id')).bind(tenantId,t.id,...allowed).first<{ok:number}>();if(!ok)throw new Error('FORBIDDEN_COMMUNICATION_SCOPE');}}
async function validateTargets(env:Env,auth:CoreAuthContext,tenantId:string,list:Target[]){for(const t of list)await validateTarget(env,auth,tenantId,t);}
async function activeParticipantQuery(env:Env,sql:string,args:unknown[]){const r=await env.DB.prepare(sql).bind(...args).all<{user_id:string}>();return (r.results??[]).map(x=>x.user_id);}
async function resolveTargetRecipients(env:Env,tenantId:string,t:Target):Promise<string[]>{
  const active="m.role='participant' AND u.status='active' AND tu.status='active'";
  if(t.type==='tenant')return activeParticipantQuery(env,`SELECT DISTINCT m.user_id FROM memberships m JOIN users u ON u.id=m.user_id JOIN tenant_users tu ON tu.tenant_id=m.tenant_id AND tu.user_id=m.user_id WHERE m.tenant_id=? AND ${active}`,[tenantId]);
  if(t.type==='course')return activeParticipantQuery(env,`SELECT DISTINCT m.user_id FROM memberships m JOIN users u ON u.id=m.user_id JOIN tenant_users tu ON tu.tenant_id=m.tenant_id AND tu.user_id=m.user_id WHERE m.tenant_id=? AND m.course_id=? AND ${active}`,[tenantId,t.id]);
  if(t.type==='user')return activeParticipantQuery(env,`SELECT DISTINCT m.user_id FROM memberships m JOIN users u ON u.id=m.user_id JOIN tenant_users tu ON tu.tenant_id=m.tenant_id AND tu.user_id=m.user_id WHERE m.tenant_id=? AND m.user_id=? AND ${active}`,[tenantId,t.id]);
  const unitIds:string[]=[];if(t.include_descendants){const r=await env.DB.prepare(`WITH RECURSIVE tree(id) AS (SELECT id FROM org_units WHERE tenant_id=? AND id=? AND status='active' UNION ALL SELECT o.id FROM org_units o JOIN tree t ON o.parent_id=t.id WHERE o.tenant_id=? AND o.status='active') SELECT id FROM tree`).bind(tenantId,t.id,tenantId).all<{id:string}>();unitIds.push(...(r.results??[]).map(x=>x.id));}else unitIds.push(String(t.id));if(!unitIds.length)return[];const marks=unitIds.map(()=>'?').join(',');return activeParticipantQuery(env,`SELECT DISTINCT m.user_id FROM course_org_units co JOIN memberships m ON m.tenant_id=co.tenant_id AND m.course_id=co.course_id JOIN users u ON u.id=m.user_id JOIN tenant_users tu ON tu.tenant_id=m.tenant_id AND tu.user_id=m.user_id WHERE co.tenant_id=? AND co.org_unit_id IN (${marks}) AND ${active}`,[tenantId,...unitIds]);
}
async function messageTargets(env:Env,messageId:string):Promise<Target[]>{const r=await env.DB.prepare('SELECT target_type,target_id,include_descendants FROM communication_targets WHERE message_id=? ORDER BY created_at,id').bind(messageId).all<Record<string,unknown>>();return (r.results??[]).map(x=>({type:String(x.target_type) as Target['type'],id:x.target_id?String(x.target_id):null,include_descendants:Number(x.include_descendants)!==0}));}
// Veroeffentlichen heisst: den Empfaengerkreis festschreiben UND je Person entscheiden, welcher Weg
// bedient, verzoegert oder unterdrueckt wird. Die Rangfolge aus K3 wird genau hier durchgesetzt -
// nicht in der Anzeige. Was hier nicht hinausgeht, steht als Entscheidung mit Grund in
// communication_channel_decisions; sonst waere eine unterdrueckte Benachrichtigung von einer
// zugestellten nicht mehr zu unterscheiden.
//
// Kosten: die Einstellungen aller Empfaenger werden in Bloecken zu 200 gelesen (drei Abfragen bei
// 500 Empfaengern statt fuenfhundert), und alle Schreibungen gehen in EINEM Stapel hinaus.
async function snapshotRecipients(env:Env,message:MessageRow){if(message.send_email&&!mailConfigured(env))throw new Error('COMMUNICATION_MAIL_NOT_CONFIGURED');const ts=nowIso(),users=new Set<string>();for(const target of await messageTargets(env,message.id))for(const userId of await resolveTargetRecipients(env,message.tenant_id,target))users.add(userId);if(Number(message.an_sorgeberechtigte||0)===1)for(const g of await sorgeberechtigteFuerTeilnehmer(env,message.tenant_id,[...users]))users.add(g);if(!users.size)throw new Error('COMMUNICATION_NO_RECIPIENTS');
  const liste=[...users],rangstufe=pruefeRangstufe(message.rangstufe),thema=pruefeThema(message.thema);
  const zeitzone=await zeitzoneDesTraegers(env,message.tenant_id),praeferenzen=await praeferenzenFuerNutzer(env,message.tenant_id,liste),abbestellt=await themenAbwahlFuerNutzer(env,message.tenant_id,thema,liste),mitGeraet=await nutzerMitPushGeraet(env,message.tenant_id,liste);
  const stmts=[env.DB.prepare('DELETE FROM communication_recipients WHERE message_id=?').bind(message.id),env.DB.prepare('DELETE FROM communication_channel_decisions WHERE message_id=?').bind(message.id)];
  const mailEmpfaenger:string[]=[],mailVerzoegert=new Map<string,string>();let unterdrueckt=0,verzoegert=0;
  for(const userId of liste){
    const lage={abbestellt:abbestellt.has(userId),praeferenz:praeferenzen.get(userId)??null,jetzt:ts,zeitzone};
    stmts.push(env.DB.prepare('INSERT INTO communication_recipients(message_id,tenant_id,user_id,delivered_at) VALUES(?,?,?,?)').bind(message.id,message.tenant_id,userId,ts));
    // Der Hinweis in der Glocke. Er traegt bewusst NICHT den Inhalt: eine Meldung, die auf einem
    // fremd einsehbaren Bildschirm auftaucht, waere eine Offenlegung ohne Empfaenger.
    const portal=kanalUrteil('portal',rangstufe,lage);let notificationId='';
    if(portal.zustellen){notificationId=id('ntf_');stmts.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at,quelle_typ,quelle_id) VALUES(?,?,NULL,?,'targeted_message',?,?,?,'communication',?)").bind(notificationId,message.tenant_id,userId,rangstufe==='verbindlich'?`Verbindliche Mitteilung: ${message.title}`:message.priority==='urgent'?`Dringende persönliche Meldung: ${message.title}`:`Neue persönliche Meldung: ${message.title}`,'Im Klassenportal liegt eine neue, für Dich bestimmte Meldung vor.',ts,message.id));}
    else{unterdrueckt++;stmts.push(entscheidungsAnweisung(env,{messageId:message.id,tenantId:message.tenant_id,userId,kanal:'portal',urteil:portal,rangstufe},ts));}
    if(mitGeraet.has(userId)){
      const push=portal.zustellen?kanalUrteil('push',rangstufe,lage):portal;
      // Ohne Glockeneintrag gibt es nichts zu senden - die Kurzmeldung haengt am Eintrag.
      if(!portal.zustellen)stmts.push(entscheidungsAnweisung(env,{messageId:message.id,tenantId:message.tenant_id,userId,kanal:'push',urteil:push,rangstufe},ts));
      else if(push.zustellen)stmts.push(pushAnweisung(env,{tenantId:message.tenant_id,userId,notificationId,status:'pending',faellig_ab:null},ts));
      else{
        // 'cancelled' statt „gar keine Zeile": der zeitgesteuerte Lauf wuerde eine fehlende Zeile
        // als „noch nicht vorgemerkt" lesen und die unterdrueckte Kurzmeldung nachtraeglich doch
        // senden. Die Zeile ist zugleich der Nachweis, dass bewusst nicht gesendet wurde.
        if(push.entscheidung==='verzoegert')verzoegert++;else unterdrueckt++;
        stmts.push(pushAnweisung(env,{tenantId:message.tenant_id,userId,notificationId,status:push.entscheidung==='verzoegert'?'pending':'cancelled',faellig_ab:push.faellig_ab},ts));
        stmts.push(entscheidungsAnweisung(env,{messageId:message.id,tenantId:message.tenant_id,userId,kanal:'push',urteil:push,rangstufe},ts));
      }
    }
    if(message.send_email){
      const mail=kanalUrteil('mail',rangstufe,lage);
      if(mail.zustellen)mailEmpfaenger.push(userId);
      else{
        stmts.push(entscheidungsAnweisung(env,{messageId:message.id,tenantId:message.tenant_id,userId,kanal:'mail',urteil:mail,rangstufe},ts));
        // Verzoegert heisst vorgemerkt, nicht gestrichen: die Mail geht in dieselbe
        // Wiederholungsschlange, die auch den Massenversand abarbeitet, und zwar ab Ruhezeitende.
        if(mail.entscheidung==='verzoegert'){verzoegert++;mailEmpfaenger.push(userId);mailVerzoegert.set(userId,String(mail.faellig_ab));}
        else unterdrueckt++;
      }
    }
  }
  stmts.push(env.DB.prepare("UPDATE communication_messages SET status='published',recipient_count=?,published_at=?,updated_at=? WHERE id=?").bind(users.size,ts,ts,message.id));
  stmts.push(env.DB.prepare("INSERT INTO communication_events(id,tenant_id,message_id,event_type,user_id,detail_json,created_at) VALUES(?,?,?,'published',NULL,?,?)").bind(id('cev_'),message.tenant_id,message.id,JSON.stringify({recipientCount:users.size,sendEmail:!!message.send_email,rangstufe,thema,unterdrueckt,verzoegert}),ts));
  await env.DB.batch(stmts);
  const email=message.send_email?await deliverCommunicationEmails(env,message,mailEmpfaenger,mailVerzoegert):{sent:0,failed:0,pending:0};
  return{count:users.size,email,unterdrueckt,verzoegert};}

async function canAdminSeeMessage(env:Env,auth:CoreAuthContext,tenantId:string,row:MessageRow):Promise<boolean>{if(auth.isPlatformAdmin||auth.role==='tenant_admin'||row.created_by===auth.userId)return true;const courses=[...new Set(auth.courseIds??[])];if(!courses.length)return false;const marks=courses.map(()=>'?').join(',');const direct=await env.DB.prepare(`SELECT 1 AS ok FROM communication_targets t WHERE t.message_id=? AND t.tenant_id=? AND ((t.target_type='course' AND t.target_id IN (${marks})) OR (t.target_type='user' AND EXISTS(SELECT 1 FROM memberships m WHERE m.tenant_id=? AND m.user_id=t.target_id AND m.role='participant' AND m.course_id IN (${marks})))) LIMIT 1`).bind(row.id,tenantId,...courses,tenantId,...courses).first<{ok:number}>();if(direct)return true;const delivered=await env.DB.prepare(`SELECT 1 AS ok FROM communication_recipients r JOIN memberships m ON m.tenant_id=r.tenant_id AND m.user_id=r.user_id WHERE r.message_id=? AND r.tenant_id=? AND m.role='participant' AND m.course_id IN (${marks}) LIMIT 1`).bind(row.id,tenantId,...courses).first<{ok:number}>();return !!delivered;}
async function assertAdminCanSee(env:Env,auth:CoreAuthContext,tenantId:string,row:MessageRow){if(!await canAdminSeeMessage(env,auth,tenantId,row))throw new Error('FORBIDDEN_COMMUNICATION_SCOPE');}
function statsQuery(env:Env,messageId:string){return env.DB.prepare('SELECT COUNT(*) total,SUM(CASE WHEN read_at IS NOT NULL THEN 1 ELSE 0 END) read_count,SUM(CASE WHEN acknowledged_at IS NOT NULL THEN 1 ELSE 0 END) ack_count FROM communication_recipients WHERE message_id=?').bind(messageId).first<Record<string,unknown>>();}

export async function createCommunication(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){requireRole(auth,'class_admin');const title=safeString(input.title,250),rohBody=safeString(input.body,10000);if(!title||(input.bloecke==null&&!rohBody))throw new Error('COMMUNICATION_FIELDS_REQUIRED');
  // EINE Quelle: entweder kommen Bloecke herein, oder der alte Fliesstext wird zu Bloecken. Der
  // Rumpf wird daraus GERECHNET und nicht getrennt entgegengenommen - sonst stuenden ab der ersten
  // Korrektur zwei Texte im System und niemand koennte sagen, welcher gilt.
  const bloecke=input.bloecke!=null?parseBloecke(input.bloecke):bloeckeAusText(rohBody),body=textDarstellung(bloecke).slice(0,20000);
  const thema=pruefeThema(input.thema);const targetList=targets(input.targets);await validateTargets(env,auth,tenantId,targetList);const startsAt=parseIso(input.starts_at),endsAt=parseIso(input.ends_at),ackDueAt=parseIso(input.ack_due_at),now=nowIso();if(startsAt&&endsAt&&startsAt>=endsAt)throw new Error('COMMUNICATION_WINDOW_INVALID');if(ackDueAt&&startsAt&&ackDueAt<startsAt)throw new Error('COMMUNICATION_ACK_DUE_INVALID');if(ackDueAt&&endsAt&&ackDueAt>endsAt)throw new Error('COMMUNICATION_ACK_DUE_INVALID');const sendEmail=input.send_email===true?1:0;const anSorgeberechtigte=input.an_sorgeberechtigte===true?1:0;if(sendEmail&&!mailConfigured(env))throw new Error('COMMUNICATION_MAIL_NOT_CONFIGURED');const requireAck=input.require_ack===true?1:0,requireRead=requireAck||input.require_read===true?1:0,msgId=id('msg_'),ts=nowIso(),wantsPublish=input.publish===true,status=wantsPublish&&startsAt&&startsAt>now?'scheduled':'draft';
  // Eine Pflichtbestaetigung, die sich abbestellen oder stummschalten laesst, ist keine. Wer eine
  // Quittung verlangt, verlangt sie von allen - deshalb ist die Rangstufe hier nicht frei waehlbar.
  const rangstufe=pruefeRangstufe(input.rangstufe,requireAck?'verbindlich':'normal');if(requireAck&&rangstufe!=='verbindlich')throw new Error('KOMMUNIKATION_QUITTUNG_ERFORDERT_VERBINDLICH');
  await env.DB.batch([env.DB.prepare('INSERT INTO communication_messages(id,tenant_id,title,body,bloecke_json,rangstufe,thema,priority,status,starts_at,ends_at,require_read,require_ack,ack_due_at,send_email,an_sorgeberechtigte,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(msgId,tenantId,title,body,JSON.stringify(bloecke),rangstufe,thema,priority(input.priority),status,startsAt,endsAt,requireRead,requireAck,ackDueAt,sendEmail,anSorgeberechtigte,auth.userId,ts,ts),...targetList.map(t=>env.DB.prepare('INSERT INTO communication_targets(id,message_id,tenant_id,target_type,target_id,include_descendants,created_at) VALUES(?,?,?,?,?,?,?)').bind(id('ctg_'),msgId,tenantId,t.type,t.id,t.include_descendants?1:0,ts)),env.DB.prepare("INSERT INTO communication_events(id,tenant_id,message_id,event_type,user_id,detail_json,created_at) VALUES(?,?,?,'created',NULL,?,?)").bind(id('cev_'),tenantId,msgId,JSON.stringify({targets:targetList.length,status,sendEmail:!!sendEmail}),ts)]);if(wantsPublish&&status!=='scheduled')await publishCommunication(env,auth,tenantId,msgId);await audit(env.DB,auth.userId,'communication.created',tenantId,undefined,'communication_message',msgId,{targets:targetList.length,wantsPublish,status,sendEmail:!!sendEmail,rangstufe,thema});return getCommunication(env,auth,tenantId,msgId);}
export async function getCommunication(env:Env,auth:CoreAuthContext,tenantId:string,messageId:string){requireRole(auth,'class_admin');const row=await env.DB.prepare('SELECT * FROM communication_messages WHERE tenant_id=? AND id=?').bind(tenantId,messageId).first<MessageRow>();if(!row)throw new Error('COMMUNICATION_NOT_FOUND');await assertAdminCanSee(env,auth,tenantId,row);const t=await messageTargets(env,messageId),stats=await statsQuery(env,messageId),email=await communicationEmailStats(env,messageId);const bloecke=bloeckeLesen(row.bloecke_json,row.body);return{...row,bloecke,darstellungen:darstellungen(bloecke,row.title,{betreff:row.priority==='urgent'?`Dringend: ${row.title}`:`Klassenportal: ${row.title}`}),targets:t,stats:{total:Number(stats?.total||0),read:Number(stats?.read_count||0),acknowledged:Number(stats?.ack_count||0),email}};}
export async function listCommunications(env:Env,auth:CoreAuthContext,tenantId:string){requireRole(auth,'class_admin');const rows=(await env.DB.prepare('SELECT * FROM communication_messages WHERE tenant_id=? ORDER BY created_at DESC LIMIT 500').bind(tenantId).all<MessageRow>()).results??[],out=[];for(const row of rows){if(!await canAdminSeeMessage(env,auth,tenantId,row))continue;const stats=await statsQuery(env,row.id),email=await communicationEmailStats(env,row.id);out.push({...row,stats:{total:Number(stats?.total||0),read:Number(stats?.read_count||0),acknowledged:Number(stats?.ack_count||0),email}});if(out.length>=300)break;}return out;}
export async function publishCommunication(env:Env,auth:CoreAuthContext,tenantId:string,messageId:string){requireRole(auth,'class_admin');const row=await env.DB.prepare('SELECT * FROM communication_messages WHERE tenant_id=? AND id=?').bind(tenantId,messageId).first<MessageRow>();if(!row)throw new Error('COMMUNICATION_NOT_FOUND');await assertAdminCanSee(env,auth,tenantId,row);if(!['draft','scheduled'].includes(row.status))throw new Error('COMMUNICATION_NOT_PUBLISHABLE');const t=await messageTargets(env,messageId);await validateTargets(env,auth,tenantId,t);if(row.starts_at&&row.starts_at>nowIso()){await env.DB.prepare("UPDATE communication_messages SET status='scheduled',updated_at=? WHERE id=?").bind(nowIso(),messageId).run();return getCommunication(env,auth,tenantId,messageId);}const delivery=await snapshotRecipients(env,row);await audit(env.DB,auth.userId,'communication.published',tenantId,undefined,'communication_message',messageId,{recipientCount:delivery.count,email:delivery.email});return getCommunication(env,auth,tenantId,messageId);}
export async function closeCommunication(env:Env,auth:CoreAuthContext,tenantId:string,messageId:string){requireRole(auth,'class_admin');const row=await env.DB.prepare('SELECT * FROM communication_messages WHERE tenant_id=? AND id=?').bind(tenantId,messageId).first<MessageRow>();if(!row)throw new Error('COMMUNICATION_NOT_FOUND');await assertAdminCanSee(env,auth,tenantId,row);const status=['draft','scheduled'].includes(row.status)?'cancelled':'closed',eventType=status==='cancelled'?'cancelled':'closed',ts=nowIso();await env.DB.batch([env.DB.prepare('UPDATE communication_messages SET status=?,updated_at=? WHERE tenant_id=? AND id=?').bind(status,ts,tenantId,messageId),env.DB.prepare('INSERT INTO communication_events(id,tenant_id,message_id,event_type,user_id,detail_json,created_at) VALUES(?,?,?,?,NULL,NULL,?)').bind(id('cev_'),tenantId,messageId,eventType,ts)]);await audit(env.DB,auth.userId,`communication.${status}`,tenantId,undefined,'communication_message',messageId);}

export async function myCommunications(env:Env,auth:CoreAuthContext,tenantId:string,courseId?:string){requireRole(auth,'participant');const now=nowIso();let sql=`SELECT m.id,m.title,m.body,m.bloecke_json,m.rangstufe,m.thema,m.priority,m.starts_at,m.ends_at,m.require_read,m.require_ack,m.ack_due_at,m.published_at,r.read_at,r.acknowledged_at FROM communication_recipients r JOIN communication_messages m ON m.id=r.message_id WHERE r.tenant_id=? AND r.user_id=? AND m.status='published' AND (m.starts_at IS NULL OR m.starts_at<=?) AND (m.ends_at IS NULL OR m.ends_at>?)`,args:unknown[]=[tenantId,auth.userId,now,now];if(courseId){requireCourseAccess(auth,courseId);sql+=` AND (m.id IN (SELECT message_id FROM communication_targets WHERE target_type='course' AND target_id=?) OR m.id IN (SELECT message_id FROM communication_targets WHERE target_type<>'course'))`;args.push(courseId);}sql+=' ORDER BY CASE m.rangstufe WHEN \'verbindlich\' THEN 1 WHEN \'wichtig\' THEN 2 ELSE 3 END,CASE m.priority WHEN \'urgent\' THEN 1 WHEN \'important\' THEN 2 ELSE 3 END,m.published_at DESC';const r=await env.DB.prepare(sql).bind(...args).all<Record<string,unknown>>();return (r.results??[]).map(x=>({...x,bloecke:bloeckeLesen(x.bloecke_json,x.body)}));}
export async function markCommunicationRead(env:Env,auth:CoreAuthContext,tenantId:string,messageId:string){requireRole(auth,'participant');const now=nowIso(),r=await env.DB.prepare('UPDATE communication_recipients SET read_at=COALESCE(read_at,?) WHERE tenant_id=? AND message_id=? AND user_id=?').bind(now,tenantId,messageId,auth.userId).run();if(!Number(r.meta?.changes||0))throw new Error('COMMUNICATION_NOT_FOUND');await env.DB.prepare("INSERT INTO communication_events(id,tenant_id,message_id,event_type,user_id,detail_json,created_at) VALUES(?,?,?,'read',?,NULL,?)").bind(id('cev_'),tenantId,messageId,auth.userId,now).run();return{read_at:now};}
export async function acknowledgeCommunication(env:Env,auth:CoreAuthContext,tenantId:string,messageId:string){requireRole(auth,'participant');const msg=await env.DB.prepare('SELECT require_ack,status,starts_at,ends_at FROM communication_messages WHERE tenant_id=? AND id=?').bind(tenantId,messageId).first<{require_ack:number;status:string;starts_at:string|null;ends_at:string|null}>();if(!msg||msg.status!=='published'||!msg.require_ack)throw new Error('COMMUNICATION_ACK_NOT_AVAILABLE');const now=nowIso();if(msg.starts_at&&msg.starts_at>now||msg.ends_at&&msg.ends_at<=now)throw new Error('COMMUNICATION_ACK_NOT_AVAILABLE');const r=await env.DB.prepare('UPDATE communication_recipients SET read_at=COALESCE(read_at,?),acknowledged_at=COALESCE(acknowledged_at,?) WHERE tenant_id=? AND message_id=? AND user_id=?').bind(now,now,tenantId,messageId,auth.userId).run();if(!Number(r.meta?.changes||0))throw new Error('COMMUNICATION_NOT_FOUND');await env.DB.prepare("INSERT INTO communication_events(id,tenant_id,message_id,event_type,user_id,detail_json,created_at) VALUES(?,?,?,'acknowledged',?,NULL,?)").bind(id('cev_'),tenantId,messageId,auth.userId,now).run();return{acknowledged_at:now};}

async function systemPublish(env:Env,row:MessageRow){try{await snapshotRecipients(env,row);}catch(e){await env.DB.prepare("UPDATE communication_messages SET status='draft',updated_at=? WHERE id=?").bind(nowIso(),row.id).run();const ts=nowIso();await env.DB.prepare("INSERT INTO automation_tasks(id,tenant_id,task_type,severity,title,detail_json,source_type,source_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'communication',?,'open',?,?)").bind(id('tsk_'),row.tenant_id,'communication_publish_failed','important',`Geplante Meldung konnte nicht veröffentlicht werden: ${row.title}`,JSON.stringify({error:String((e as Error).message||e)}),row.id,ts,ts).run();}}
export async function runCommunicationAutomation(env:Env){const now=nowIso(),scheduled=(await env.DB.prepare("SELECT * FROM communication_messages WHERE status='scheduled' AND starts_at IS NOT NULL AND starts_at<=? LIMIT 100").bind(now).all<MessageRow>()).results??[];for(const row of scheduled)await systemPublish(env,row);await retryFailedCommunicationEmails(env);const due=(await env.DB.prepare("SELECT m.id,m.tenant_id,m.title,m.priority,COUNT(*) missing FROM communication_messages m JOIN communication_recipients r ON r.message_id=m.id WHERE m.status='published' AND m.require_ack=1 AND m.ack_due_at IS NOT NULL AND m.ack_due_at<=? AND r.acknowledged_at IS NULL GROUP BY m.id,m.tenant_id,m.title,m.priority LIMIT 100").bind(now).all<{id:string;tenant_id:string;title:string;priority:string;missing:number}>()).results??[];for(const m of due){const existing=await env.DB.prepare("SELECT id FROM automation_tasks WHERE tenant_id=? AND source_type='communication' AND source_id=? AND status IN ('open','in_progress') LIMIT 1").bind(m.tenant_id,m.id).first();if(!existing){const ts=nowIso();await env.DB.prepare("INSERT INTO automation_tasks(id,tenant_id,task_type,severity,title,detail_json,source_type,source_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?,'communication',?,'open',?,?)").bind(id('tsk_'),m.tenant_id,'communication_ack_overdue',m.priority==='urgent'?'urgent':'important',`${Number(m.missing)} Pflichtbestätigung(en) fehlen: ${m.title}`,JSON.stringify({missing:Number(m.missing)}),m.id,ts,ts).run();}const recipients=(await env.DB.prepare('SELECT user_id FROM communication_recipients WHERE message_id=? AND acknowledged_at IS NULL AND (last_reminded_at IS NULL OR last_reminded_at<=?) LIMIT 500').bind(m.id,new Date(Date.now()-24*3600000).toISOString()).all<{user_id:string}>()).results??[],stmts=[] as any[];for(const r of recipients){stmts.push(env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at) VALUES(?,?,NULL,?,'targeted_message_reminder',?,?,?)").bind(id('ntf_'),m.tenant_id,r.user_id,'Bestätigung ausstehend','Bitte öffne die für Dich bestimmte Pflichtmeldung im Klassenportal und bestätige sie.',now));stmts.push(env.DB.prepare('UPDATE communication_recipients SET reminder_count=reminder_count+1,last_reminded_at=? WHERE message_id=? AND user_id=?').bind(now,m.id,r.user_id));}if(stmts.length){stmts.push(env.DB.prepare("INSERT INTO communication_events(id,tenant_id,message_id,event_type,user_id,detail_json,created_at) VALUES(?,?,?,'reminder',NULL,?,?)").bind(id('cev_'),m.tenant_id,m.id,JSON.stringify({erinnert:recipients.length,ausloeser:'frist'}),now));await env.DB.batch(stmts);}}}


// ---------------------------------------------------------------------------------------------
// Kommunikationsnachweis (K6) und Quittierung (K7)
//
// Die Frage des Traegers lautet nie "wurde versendet", sondern: „Die Einladung zum Elterngespraech
// ging am 3. Mai ueber Portal und Mail an 24 Personen, 19 haben sie gelesen." Dafuer werden hier
// die vorhandenen Quellen zusammengefuehrt, nicht verdoppelt:
//   communication_recipients          - Portalzustellung, Lesen, Quittung, Erinnerungen
//   communication_email_deliveries    - Mailversand samt endgueltigem Fehlschlag
//   push_outbox ueber notifications   - Kurzmeldung
//   communication_channel_decisions   - was NICHT hinausging und warum
// Eine fehlgeschlagene oder unterdrueckte Zustellung, die nirgends steht, ist eine nicht erfolgte
// Benachrichtigung - und genau danach wird gefragt, wenn jemand sagt, er habe nichts erhalten.
// ---------------------------------------------------------------------------------------------

export async function kommunikationsNachweis(env:Env,auth:CoreAuthContext,tenantId:string,messageId:string){
  requireRole(auth,'class_admin');
  const row=await env.DB.prepare('SELECT * FROM communication_messages WHERE tenant_id=? AND id=?').bind(tenantId,messageId).first<MessageRow>();
  if(!row)throw new Error('COMMUNICATION_NOT_FOUND');
  await assertAdminCanSee(env,auth,tenantId,row);
  const summe=await env.DB.prepare('SELECT COUNT(*) gesamt,SUM(CASE WHEN read_at IS NOT NULL THEN 1 ELSE 0 END) gelesen,SUM(CASE WHEN acknowledged_at IS NOT NULL THEN 1 ELSE 0 END) quittiert,SUM(reminder_count) erinnerungen FROM communication_recipients WHERE message_id=?').bind(messageId).first<Record<string,unknown>>();
  const mail=await communicationEmailStats(env,messageId);
  const push=(await env.DB.prepare("SELECT o.status,COUNT(*) anzahl FROM push_outbox o JOIN notifications n ON n.id=o.notification_id WHERE n.quelle_typ='communication' AND n.quelle_id=? GROUP BY o.status").bind(messageId).all<Record<string,unknown>>()).results??[];
  const entscheidungen=(await env.DB.prepare('SELECT kanal,entscheidung,grund,COUNT(*) anzahl FROM communication_channel_decisions WHERE message_id=? GROUP BY kanal,entscheidung,grund ORDER BY kanal,entscheidung,grund').bind(messageId).all<Record<string,unknown>>()).results??[];
  // Eine Abfrage fuer alle Personen - nicht eine je Person. Bei 500 Empfaengern ist das der
  // Unterschied zwischen einer Unteranfrage und fuenfhundert.
  const personen=(await env.DB.prepare("SELECT r.user_id,u.display_name,r.delivered_at,r.read_at,r.acknowledged_at,r.reminder_count,r.last_reminded_at,(SELECT e.status FROM communication_email_deliveries e WHERE e.message_id=r.message_id AND e.user_id=r.user_id) AS mail_status,(SELECT e.error_code FROM communication_email_deliveries e WHERE e.message_id=r.message_id AND e.user_id=r.user_id) AS mail_fehler,(SELECT o.status FROM push_outbox o JOIN notifications n ON n.id=o.notification_id WHERE n.quelle_typ='communication' AND n.quelle_id=r.message_id AND o.user_id=r.user_id ORDER BY o.created_at DESC LIMIT 1) AS push_status,(SELECT group_concat(cd.kanal||':'||cd.entscheidung||':'||cd.grund) FROM communication_channel_decisions cd WHERE cd.message_id=r.message_id AND cd.user_id=r.user_id) AS entscheidungen FROM communication_recipients r JOIN users u ON u.id=r.user_id WHERE r.message_id=? AND r.tenant_id=? ORDER BY u.display_name LIMIT 500").bind(messageId,tenantId).all<Record<string,unknown>>()).results??[];
  const gesamt=Number(summe?.gesamt||0),gelesen=Number(summe?.gelesen||0),quittiert=Number(summe?.quittiert||0);
  await audit(env.DB,auth.userId,'communication.nachweis_gelesen',tenantId,undefined,'communication_message',messageId,{empfaenger:gesamt});
  return{
    meldung:{id:row.id,titel:row.title,rangstufe:row.rangstufe,thema:row.thema,priority:row.priority,status:row.status,veroeffentlicht_am:row.published_at,quittung_noetig:Number(row.require_ack||0)===1,quittung_faellig_am:row.ack_due_at},
    kanaele:{
      portal:{zugestellt:gesamt,gelesen,quittiert},
      mail:Number(row.send_email||0)?mail:{total:0,sent:0,failed:0,pending:0},
      push:Object.fromEntries(push.map(p=>[String(p.status),Number(p.anzahl||0)])),
    },
    quittung:{noetig:Number(row.require_ack||0)===1,quittiert,ausstehend:Math.max(0,gesamt-quittiert),erinnerungen:Number(summe?.erinnerungen||0)},
    nicht_zugestellt:entscheidungen.map(e=>({kanal:String(e.kanal),entscheidung:String(e.entscheidung),grund:String(e.grund),anzahl:Number(e.anzahl||0)})),
    personen:personen.map(p=>({
      user_id:String(p.user_id),name:String(p.display_name||''),zugestellt_am:p.delivered_at??null,gelesen_am:p.read_at??null,quittiert_am:p.acknowledged_at??null,
      erinnerungen:Number(p.reminder_count||0),zuletzt_erinnert_am:p.last_reminded_at??null,
      mail_status:p.mail_status??(Number(row.send_email||0)?'offen':'nicht_gewaehlt'),mail_fehler:p.mail_fehler??null,push_status:p.push_status??'nicht_erzeugt',
      entscheidungen:String(p.entscheidungen??'').split(',').filter(Boolean).map(x=>{const [kanal,entscheidung,grund]=x.split(':');return{kanal,entscheidung,grund};}),
    })),
    hinweis_unvollstaendig:personen.length>=500?'Die Personenliste ist auf 500 Zeilen begrenzt; die Summen oben gelten für alle Empfänger.':null,
  };
}

/** Die Nachweisliste des Traegers: eine Zeile je veroeffentlichter Meldung, mit Zustellstand. */
export async function nachweisUebersicht(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'class_admin');
  const rows=(await env.DB.prepare("SELECT m.id,m.title,m.created_by,m.rangstufe,m.thema,m.priority,m.status,m.published_at,m.send_email,m.require_ack,m.recipient_count,(SELECT COUNT(*) FROM communication_recipients r WHERE r.message_id=m.id) AS empfaenger,(SELECT COUNT(*) FROM communication_recipients r WHERE r.message_id=m.id AND r.read_at IS NOT NULL) AS gelesen,(SELECT COUNT(*) FROM communication_recipients r WHERE r.message_id=m.id AND r.acknowledged_at IS NOT NULL) AS quittiert,(SELECT COUNT(*) FROM communication_email_deliveries e WHERE e.message_id=m.id AND e.status='sent') AS mail_gesendet,(SELECT COUNT(*) FROM communication_email_deliveries e WHERE e.message_id=m.id AND e.status='failed' AND e.attempts>=3) AS mail_fehlgeschlagen,(SELECT COUNT(*) FROM communication_channel_decisions cd WHERE cd.message_id=m.id AND cd.entscheidung='unterdrueckt') AS unterdrueckt,(SELECT COUNT(*) FROM communication_channel_decisions cd WHERE cd.message_id=m.id AND cd.entscheidung='verzoegert') AS verzoegert FROM communication_messages m WHERE m.tenant_id=? AND m.status IN ('published','closed') ORDER BY m.published_at DESC LIMIT 200").bind(tenantId).all<Record<string,unknown>>()).results??[];
  const out=[];
  for(const row of rows){if(!await canAdminSeeMessage(env,auth,tenantId,row as unknown as MessageRow))continue;out.push(row);if(out.length>=150)break;}
  return out;
}

/**
 * Quittung anmahnen - von Hand, nicht erst wenn die Frist gerissen ist.
 *
 * Gedrosselt auf einmal je 24 Stunden und Person: eine Erinnerung, die dreimal am Tag kommt, wird
 * weggeklickt wie Werbung, und danach hilft auch die vierte nicht mehr.
 */
export async function erinnereAnQuittung(env:Env,auth:CoreAuthContext,tenantId:string,messageId:string){
  requireRole(auth,'class_admin');
  const row=await env.DB.prepare('SELECT * FROM communication_messages WHERE tenant_id=? AND id=?').bind(tenantId,messageId).first<MessageRow>();
  if(!row)throw new Error('COMMUNICATION_NOT_FOUND');
  await assertAdminCanSee(env,auth,tenantId,row);
  if(!Number(row.require_ack||0)||row.status!=='published')throw new Error('KOMMUNIKATION_QUITTUNG_NICHT_VERLANGT');
  const jetzt=nowIso(),grenze=new Date(Date.now()-24*3600000).toISOString();
  const offen=(await env.DB.prepare('SELECT user_id FROM communication_recipients WHERE message_id=? AND acknowledged_at IS NULL AND (last_reminded_at IS NULL OR last_reminded_at<=?) LIMIT 500').bind(messageId,grenze).all<{user_id:string}>()).results??[];
  if(!offen.length)throw new Error('KOMMUNIKATION_ERINNERUNG_ZU_FRUEH');
  const stmts=offen.flatMap(r=>[
    env.DB.prepare("INSERT INTO notifications(id,tenant_id,course_id,user_id,type,title,body,created_at,quelle_typ,quelle_id) VALUES(?,?,NULL,?,'targeted_message_reminder',?,?,?,'communication',?)").bind(id('ntf_'),tenantId,r.user_id,'Bestätigung ausstehend','Bitte öffne die für Dich bestimmte Pflichtmeldung im Klassenportal und bestätige sie.',jetzt,messageId),
    env.DB.prepare('UPDATE communication_recipients SET reminder_count=reminder_count+1,last_reminded_at=? WHERE message_id=? AND user_id=?').bind(jetzt,messageId,r.user_id),
  ]);
  stmts.push(env.DB.prepare("INSERT INTO communication_events(id,tenant_id,message_id,event_type,user_id,detail_json,created_at) VALUES(?,?,?,'reminder',?,?,?)").bind(id('cev_'),tenantId,messageId,auth.userId,JSON.stringify({erinnert:offen.length,ausloeser:'hand'}),jetzt));
  await env.DB.batch(stmts);
  await audit(env.DB,auth.userId,'communication.erinnert',tenantId,undefined,'communication_message',messageId,{erinnert:offen.length});
  return{erinnert:offen.length};
}

// Betriebsbeobachtung: messen statt behaupten (Master-Spec V2, MUSS-V1 "Observability",
// "RTO/RPO").
//
// Vorhanden war eine Zeile in der Weiche: /api/health antwortet {"ok":true,"service":...}. Diese
// Antwort ist immer wahr, solange der Worker ueberhaupt startet - sie war auch dann wahr, wenn die
// Datenbank nicht erreichbar, der Objektspeicher leer und der Automatiklauf seit Tagen tot ist.
// Eine Ueberwachung, die genau in dem Moment gruen bleibt, in dem es brennt, ist schlimmer als
// keine: sie erzeugt Vertrauen, das nichts traegt.
//
// Drei Dinge tut dieses Modul, und nur diese drei:
//   pruefeGesundheit  misst jeden Bereich einzeln und schreibt die Messung fort.
//   sloStand          rechnet aus den Messungen den Erfuellungsgrad je Ziel - mit RTO und RPO.
//   alarmBedarf       nennt, was JETZT kritisch ist und seit wann.
//
// Die wichtigste Eigenschaft steht in pruefeGesundheit: der Aufruf liefert IMMER eine Antwort.
// Ein Health Check, der selbst abstuerzt, wenn ein Bereich ausfaellt, meldet keinen Ausfall - er
// meldet gar nichts, und die Ueberwachung sieht einen Verbindungsfehler statt einer Diagnose.
// Deshalb faengt jede Sonde fuer sich, und deshalb hat jede eine Zeitgrenze: ein Bereich, der
// haengt, darf die Antwort ueber die anderen nicht mitreissen.
import type { Env } from './types.js';
import { id, nowIso } from './utils.js';

export type Bereich = 'datenbank' | 'speicher' | 'mail' | 'automatik';
export type Messbereich = Bereich | 'gesamt';
export type Status = 'ok' | 'warnung' | 'kritisch';

export interface Befund { bereich: Messbereich; status: Status; dauer_ms: number; detail: string }
export interface Gesundheit {
  status: Status;
  geprueft_am: string;
  dauer_ms: number;
  bereiche: Befund[];
  /** Ob die Messung fortgeschrieben werden konnte. Faellt die Datenbank aus, eben nicht. */
  aufgezeichnet: boolean;
}

/**
 * Der Schluessel, an dem der Objektspeicher gefragt wird. Er MUSS nicht existieren: dass der
 * Speicher ueberhaupt antwortet, ist die Aussage der Sonde. Liegt er, ist die Aussage staerker.
 */
export const SPEICHER_SONDE = 'health/probe.txt';

// Eine Sonde, die nicht zurueckkommt, ist ein Ausfall - nur einer, den man ohne Grenze nie sieht.
// Fuenf Sekunden sind grosszuegig fuer eine Zaehlabfrage und eine Kopfabfrage; wer laenger
// braucht, ist auch fuer den Nutzer kaputt.
export const ZEITGRENZE_MS = 5000;

// Der Automatiklauf startet alle fuenf Minuten (wrangler.jsonc, Cron). Drei ausgelassene Runden
// sind ein Aussetzer, zwoelf sind ein Stillstand: ab da laufen weder Mahnlauf noch Buchhaltung
// noch Benachrichtigungen.
export const AUTOMATIK_WARNUNG_MINUTEN = 15;
export const AUTOMATIK_KRITISCH_MINUTEN = 60;

// Liegengebliebener Mailversand. Einzelne vorgemerkte Nachrichten sind der Normalfall - der
// Wiederholungslauf holt sie. Hunderte heissen, dass der Wiederholungslauf selbst steht.
export const MAIL_WARNUNG_OFFEN = 25;
export const MAIL_KRITISCH_OFFEN = 250;
// Ab wann eine vorgemerkte Nachricht als liegengeblieben gilt.
export const MAIL_LIEGT_MINUTEN = 60;

const RANG: Record<Status, number> = { ok: 0, warnung: 1, kritisch: 2 };

/** Der schlechteste Einzelbefund bestimmt den Gesamtstatus. Nichts wird weggemittelt. */
export function gesamtstatus(befunde: Befund[]): Status {
  return befunde.reduce<Status>((schlimmster, b) => (RANG[b.status] > RANG[schlimmster] ? b.status : schlimmster), 'ok');
}

// Fehlertexte aus der Tiefe (D1-Meldungen, Netzwerkfehler) sind Diagnose, nicht Oberflaeche -
// deshalb gekuerzt, damit ein langer Stacktrace die Messreihe nicht vollschreibt.
function kurz(fehler: unknown): string {
  return String((fehler as Error)?.message ?? fehler ?? 'unbekannter Fehler').slice(0, 300);
}

function minutenSeit(zeitpunkt: string | null | undefined, jetzt = Date.now()): number | null {
  const t = Date.parse(String(zeitpunkt ?? ''));
  return Number.isFinite(t) ? Math.max(0, Math.round((jetzt - t) / 60000)) : null;
}

// Rennt die Sonde gegen die Uhr. Der Zeitgeber wird in jedem Fall abgeraeumt - ohne das haelt ein
// offener Timer die Laufzeit am Leben, und ein Testlauf endete nie. Die Sonde selbst bekommt einen
// leeren Fangblock: gewinnt die Uhr und die Sonde scheitert erst danach, waere ihre Ablehnung
// sonst unbehandelt und riss den Prozess mit.
async function mitZeitgrenze<T>(arbeit: Promise<T>, grenze: number, bereich: Messbereich): Promise<T> {
  arbeit.catch(() => undefined);
  let zeitgeber: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      arbeit,
      new Promise<never>((_, ab) => { zeitgeber = setTimeout(() => ab(new Error(`Zeitgrenze ${grenze} ms ueberschritten (${bereich})`)), grenze); }),
    ]);
  } finally {
    if (zeitgeber !== undefined) clearTimeout(zeitgeber);
  }
}

// Der Kern der Ausfallsicherheit: hier darf nichts nach oben durchschlagen. Was die Sonde wirft,
// wird zum Befund 'kritisch' mit Begruendung - genau der Zustand, den die Ueberwachung sehen soll.
async function messen(bereich: Bereich, sonde: () => Promise<{ status: Status; detail: string }>, grenze: number): Promise<Befund> {
  const start = Date.now();
  try {
    const r = await mitZeitgrenze(sonde(), grenze, bereich);
    return { bereich, status: r.status, detail: r.detail, dauer_ms: Date.now() - start };
  } catch (e) {
    return { bereich, status: 'kritisch', detail: kurz(e), dauer_ms: Date.now() - start };
  }
}

// Billig und trotzdem aussagekraeftig: eine Zeile aus einer winzigen Tabelle. 'SELECT 1' haette
// nur bewiesen, dass die Bindung existiert - nicht, dass diese Datenbank das Schema dieses
// Standes hat.
async function sondeDatenbank(env: Env): Promise<{ status: Status; detail: string }> {
  const row = await env.DB.prepare('SELECT COUNT(*) AS anzahl FROM service_level_objectives').first<{ anzahl: number }>();
  const anzahl = Number(row?.anzahl ?? 0);
  if (!anzahl) return { status: 'warnung', detail: 'Datenbank antwortet, aber es ist kein Betriebsziel hinterlegt.' };
  return { status: 'ok', detail: `Abfrage beantwortet, ${anzahl} Betriebsziele hinterlegt.` };
}

// Kopfdaten statt Inhalt: der Speicher soll antworten, nicht ausliefern. Fehlt head() (ein Ersatz
// hinter derselben Schnittstelle muss sie nicht haben), tut get() dasselbe - der Sondenschluessel
// ist klein, deshalb kostet der Umweg nichts.
async function sondeSpeicher(env: Env): Promise<{ status: Status; detail: string }> {
  const objekt = env.FILES.head ? await env.FILES.head(SPEICHER_SONDE) : await env.FILES.get(SPEICHER_SONDE);
  if (!objekt) {
    // KEIN Fehler: der Speicher hat geantwortet, und das ist die Frage. Dass die Aussage schwaecher
    // ist, wird gesagt statt verschwiegen - ein dauerhaft gelbes Portal, nur weil der Betreiber
    // kein Sondenobjekt hinterlegt hat, waere der kuerzeste Weg zu ignorierten Warnungen.
    return { status: 'ok', detail: `Speicher antwortet. Sonde ${SPEICHER_SONDE} ist nicht hinterlegt, der Inhalt ist damit ungeprueft.` };
  }
  return { status: 'ok', detail: `Sonde ${SPEICHER_SONDE} abrufbar.` };
}

// Der Mailversand laesst sich nicht pruefen, indem man Mail verschickt - eine Pruefmail alle fuenf
// Minuten waere selbst der Schaden. Gemessen wird deshalb, was der Versand hinterlaesst: eine
// Warteschlange, die nicht leer laeuft, und Zustellungen, die scheitern.
async function sondeMail(env: Env): Promise<{ status: Status; detail: string }> {
  const jetzt = Date.now();
  const liegtSeit = new Date(jetzt - MAIL_LIEGT_MINUTEN * 60000).toISOString();
  const tagesgrenze = new Date(jetzt - 24 * 3600000).toISOString();
  const row = await env.DB.prepare(
    "SELECT SUM(CASE WHEN status='queued' AND created_at<? THEN 1 ELSE 0 END) AS liegengeblieben," +
    " SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS gescheitert" +
    ' FROM communication_email_deliveries WHERE created_at>=?')
    .bind(liegtSeit, tagesgrenze).first<{ liegengeblieben: number | null; gescheitert: number | null }>();
  const offen = Number(row?.liegengeblieben ?? 0), gescheitert = Number(row?.gescheitert ?? 0);
  const teile = [`${offen} Nachrichten laenger als ${MAIL_LIEGT_MINUTEN} min vorgemerkt`, `${gescheitert} gescheitert (24 h)`];
  // Ohne gebundenen Versand geht gar nichts hinaus. Das ist in Vorschau- und Entwicklungsumgebungen
  // normal, in der Produktion ein Befund - deshalb Warnung und nicht kritisch.
  if (!env.EMAIL) return { status: 'warnung', detail: `Kein Mailversand gebunden. ${teile.join(', ')}.` };
  if (offen >= MAIL_KRITISCH_OFFEN || gescheitert >= MAIL_KRITISCH_OFFEN) return { status: 'kritisch', detail: teile.join(', ') + '.' };
  if (offen >= MAIL_WARNUNG_OFFEN || gescheitert >= MAIL_WARNUNG_OFFEN) return { status: 'warnung', detail: teile.join(', ') + '.' };
  return { status: 'ok', detail: teile.join(', ') + '.' };
}

// Achtung, Falle im Bestand: automation_cycle_state.last_ran haelt NICHT den Zeitpunkt, sondern
// die Liste der zuletzt gelaufenen Jobs (siehe automation-cycle.ts). Der Zeitpunkt steht in
// updated_at. Wer hier last_ran liest, bekommt einen Text wie 'push,mahnlauf' und misst nichts.
async function sondeAutomatik(env: Env): Promise<{ status: Status; detail: string }> {
  const row = await env.DB.prepare("SELECT updated_at,last_ran FROM automation_cycle_state WHERE id='singleton'").first<{ updated_at: string; last_ran: string | null }>();
  if (!row) return { status: 'warnung', detail: 'Der Automatiklauf hat noch nie geschrieben - entweder ist er neu, oder er ist nie gelaufen.' };
  const alter = minutenSeit(row.updated_at);
  if (alter === null) return { status: 'warnung', detail: `Unlesbarer Zeitpunkt des letzten Laufs: ${String(row.updated_at).slice(0, 60)}` };
  const detail = `Letzter Lauf vor ${alter} min (${row.last_ran ?? 'keine Jobangabe'}).`;
  if (alter >= AUTOMATIK_KRITISCH_MINUTEN) return { status: 'kritisch', detail };
  if (alter >= AUTOMATIK_WARNUNG_MINUTEN) return { status: 'warnung', detail };
  return { status: 'ok', detail };
}

/**
 * Prueft alle Bereiche und schreibt die Messung fort.
 *
 * Liefert unter allen Umstaenden ein Ergebnis: jede Sonde laeuft in ihrem eigenen Fangblock und
 * gegen ihre eigene Uhr, und auch das Fortschreiben darf den Aufruf nicht zum Absturz bringen -
 * ist die Datenbank der kaputte Bereich, laesst sich die Messung eben nicht speichern. Dass sie
 * nicht gespeichert wurde, steht dann in der Antwort (aufgezeichnet=false) statt nirgends.
 */
export async function pruefeGesundheit(env: Env, zeitgrenze = ZEITGRENZE_MS): Promise<Gesundheit> {
  const start = Date.now();
  const bereiche = await Promise.all([
    messen('datenbank', () => sondeDatenbank(env), zeitgrenze),
    messen('speicher', () => sondeSpeicher(env), zeitgrenze),
    messen('mail', () => sondeMail(env), zeitgrenze),
    messen('automatik', () => sondeAutomatik(env), zeitgrenze),
  ]);
  const gesamt: Befund = {
    bereich: 'gesamt',
    status: gesamtstatus(bereiche),
    dauer_ms: Date.now() - start,
    detail: bereiche.filter(b => b.status !== 'ok').map(b => `${b.bereich}: ${b.status}`).join(', ') || 'alle Bereiche ok',
  };
  const alle = [...bereiche, gesamt];
  const ts = nowIso();

  let aufgezeichnet = true;
  try {
    await env.DB.batch(alle.map(b => env.DB
      .prepare('INSERT INTO service_health_checks (id,bereich,status,dauer_ms,detail,geprueft_am) VALUES (?,?,?,?,?,?)')
      .bind(id('shc_'), b.bereich, b.status, b.dauer_ms, b.detail, ts)));
  } catch {
    aufgezeichnet = false;
  }
  return { status: gesamt.status, geprueft_am: ts, dauer_ms: gesamt.dauer_ms, bereiche: alle, aufgezeichnet };
}

export interface SloBefund {
  id: string; name: string; bereich: Messbereich; ziel_prozent: number; messfenster_tage: number;
  rto_minuten: number; rpo_minuten: number; beschreibung: string | null;
  messungen: number; ok_messungen: number;
  /** null, solange nichts gemessen wurde - 100 % aus null Messungen waere eine Zahl ohne Deckung. */
  erfuellung_prozent: number | null;
  erfuellt: boolean;
  letzte_pruefung: string | null;
}

/**
 * Erfuellungsgrad je Ziel im jeweiligen Messfenster, dazu die Wiederanlaufwerte.
 *
 * Nur 'ok' zaehlt als erfuellt. Eine Warnung als halbe Erfuellung zu verbuchen waere die Art von
 * Rechnung, nach der jedes Ziel immer erreicht wird.
 *
 * Das Messfenster kommt je Zeile aus der Tabelle, deshalb wird der Stichtag in SQL aus der Zeile
 * gebildet - und zwar im selben Format, in dem geprueft_am geschrieben wird (ISO mit T und Z).
 * datetime('now') liefert ein Leerzeichen statt des T; ein Vergleich dagegen waere still falsch.
 */
export async function sloStand(env: Env): Promise<SloBefund[]> {
  const zeilen = (await env.DB.prepare(
    'SELECT s.id,s.name,s.bereich,s.ziel_prozent,s.messfenster_tage,s.rto_minuten,s.rpo_minuten,s.beschreibung,' +
    " (SELECT COUNT(*) FROM service_health_checks h WHERE h.bereich=s.bereich AND h.geprueft_am>=strftime('%Y-%m-%dT%H:%M:%fZ','now','-'||s.messfenster_tage||' days')) AS messungen," +
    " (SELECT COUNT(*) FROM service_health_checks h WHERE h.bereich=s.bereich AND h.status='ok' AND h.geprueft_am>=strftime('%Y-%m-%dT%H:%M:%fZ','now','-'||s.messfenster_tage||' days')) AS ok_messungen," +
    ' (SELECT MAX(h.geprueft_am) FROM service_health_checks h WHERE h.bereich=s.bereich) AS letzte_pruefung' +
    ' FROM service_level_objectives s ORDER BY s.name'
  ).all<Record<string, unknown>>()).results ?? [];

  return zeilen.map(z => {
    const messungen = Number(z.messungen ?? 0), okMessungen = Number(z.ok_messungen ?? 0);
    const ziel = Number(z.ziel_prozent ?? 0);
    const grad = messungen ? Math.round((okMessungen / messungen) * 10000) / 100 : null;
    return {
      id: String(z.id), name: String(z.name), bereich: z.bereich as Messbereich,
      ziel_prozent: ziel, messfenster_tage: Number(z.messfenster_tage ?? 0),
      rto_minuten: Number(z.rto_minuten ?? 0), rpo_minuten: Number(z.rpo_minuten ?? 0),
      beschreibung: z.beschreibung === null || z.beschreibung === undefined ? null : String(z.beschreibung),
      messungen, ok_messungen: okMessungen,
      erfuellung_prozent: grad,
      // Ungemessen ist nicht erfuellt. Sonst meldete ein Ziel, dessen Messung ausgefallen ist,
      // dauerhaft Erfolg - und genau der Ausfall der Messung bliebe unsichtbar.
      erfuellt: grad !== null && grad >= ziel,
      letzte_pruefung: z.letzte_pruefung === null || z.letzte_pruefung === undefined ? null : String(z.letzte_pruefung),
    };
  });
}

export interface Alarm {
  bereich: Messbereich; seit: string; seit_minuten: number; messungen: number;
  detail: string | null; rto_minuten: number | null; rto_ueberschritten: boolean;
}

/**
 * Welche Bereiche JETZT kritisch sind - und seit wann.
 *
 * Eine Abfrage fuer alle Bereiche, nicht eine je Bereich: der Alarmweg laeuft im selben Aufruf wie
 * die Pruefung, und Cloudflare zaehlt 1000 Unteranfragen fuer alles zusammen. Eine Schleife ueber
 * die Bereiche waere heute billig und in dem Moment teuer, in dem sie gebraucht wird.
 *
 * Der Trick der Abfrage: gezaehlt werden nur kritische Messungen, die NACH der letzten nicht
 * kritischen dieses Bereichs liegen. Damit faellt ein Bereich, der sich erholt hat, von selbst
 * heraus - und 'seit' ist der Beginn der laufenden Stoerung, nicht der ersten des Monats.
 */
export async function alarmBedarf(env: Env): Promise<Alarm[]> {
  const zeilen = (await env.DB.prepare(
    'SELECT h.bereich, MIN(h.geprueft_am) AS seit, COUNT(*) AS messungen,' +
    ' (SELECT g.detail FROM service_health_checks g WHERE g.bereich=h.bereich ORDER BY g.geprueft_am DESC LIMIT 1) AS detail,' +
    ' (SELECT s.rto_minuten FROM service_level_objectives s WHERE s.bereich=h.bereich) AS rto_minuten' +
    " FROM service_health_checks h WHERE h.status='kritisch'" +
    " AND h.geprueft_am>COALESCE((SELECT MAX(g.geprueft_am) FROM service_health_checks g WHERE g.bereich=h.bereich AND g.status<>'kritisch'),'')" +
    ' GROUP BY h.bereich ORDER BY seit'
  ).all<Record<string, unknown>>()).results ?? [];

  const jetzt = Date.now();
  return zeilen.map(z => {
    const seit = String(z.seit);
    const dauer = minutenSeit(seit, jetzt) ?? 0;
    const rto = z.rto_minuten === null || z.rto_minuten === undefined ? null : Number(z.rto_minuten);
    return {
      bereich: z.bereich as Messbereich, seit, seit_minuten: dauer, messungen: Number(z.messungen ?? 0),
      detail: z.detail === null || z.detail === undefined ? null : String(z.detail),
      rto_minuten: rto,
      // Erst hier bekommt die RTO aus der Zieltabelle einen Zweck: laeuft die Stoerung laenger als
      // die zugesagte Wiederanlaufzeit, ist die Zusage gebrochen - und das muss auffallen,
      // waehrend es passiert, nicht im Quartalsbericht.
      rto_ueberschritten: rto !== null && dauer >= rto,
    };
  });
}

// Die Messreihe waechst mit jedem Lauf: fuenf Zeilen alle fuenf Minuten sind rund eine halbe
// Million im Jahr. Das laengste Messfenster sind 30 Tage - was aelter ist, beantwortet keine Frage
// mehr, kostet aber Platz in einer Datenbank mit harter Obergrenze (siehe storage-growth.ts).
// Ruft der Betrieb das hier nicht regelmaessig auf, ist die Ueberwachung auf Dauer selbst das
// Problem, das sie melden soll.
export const MESSUNGEN_AUFBEWAHREN_TAGE = 90;
export async function raeumeMessungenAuf(env: Env, tage = MESSUNGEN_AUFBEWAHREN_TAGE): Promise<{ geloescht: number }> {
  const grenze = new Date(Date.now() - Math.max(1, tage) * 86400000).toISOString();
  const r = await env.DB.prepare('DELETE FROM service_health_checks WHERE geprueft_am<?').bind(grenze).run();
  return { geloescht: Number(r?.meta?.changes ?? 0) };
}

import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireCourseAccess, requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';

// Foerderplanung mit Beratungsdokumentation.
//
// Beim Eintritt wird mit dem Teilnehmer ein Foerderplan vereinbart: Ziele, dazu Massnahmen mit
// Zustaendigem und Termin. Waehrend der Massnahme dokumentieren mehrere Beteiligte Beobachtungen
// am jeweiligen Ziel; zum Review-Termin wird der Plan fortgeschrieben. Daneben laeuft die
// Beratungsdokumentation: nach jedem Einzelgespraech ein datierter Eintrag mit Anlass,
// Vereinbarung und naechstem Termin.
//
// Warum das nicht auf learner_coach_plans (0083) aufsetzt: jene Tabelle haelt einen aus dem
// Lernzwilling ERRECHNETEN Vorschlag - zwei JSON-Felder, ohne Zustaendigen, ohne Termin, ohne
// Mitschrift. Sie ist das Ergebnis einer Auswertung, nicht die mit dem Menschen getroffene
// Vereinbarung. Bei einer Pruefung durch den Kostentraeger zaehlt genau der Unterschied: die
// lueckenlose Gespraechshistorie ist der Nachweis fuer die erbrachte Betreuungsleistung, ein
// Rechenergebnis ist es nicht.
//
// Dieses Modul erhebt bewusst KEINE Gesundheitsdaten. Es gibt kein Feld fuer Diagnose, Attest
// oder Foerderbedarf im Sinne von Artikel 9 DSGVO - aus demselben Grund, aus dem eine Krankmeldung
// im Klassenbuch keinen Freitext aufnimmt (siehe attendance-classbook.ts).

type Row=Record<string,unknown>;
type Sichtbarkeit='counseling_team'|'teaching_team';

const FUNKTIONEN=new Set(['social_pedagogue','education_guide','counselor']);
const ZIEL_STATUS=new Set(['open','achieved','partly_achieved','dropped']);
const MASSNAHME_STATUS=new Set(['open','in_progress','done','cancelled']);
const SICHTBARKEIT=new Set<Sichtbarkeit>(['counseling_team','teaching_team']);
// Ziele, die beim Fortschreiben in die naechste Fassung mitgehen. Ein erreichtes oder verworfenes
// Ziel gehoert in die alte Fassung und nicht in die neue - sonst waechst der Plan bei jedem
// Review um Erledigtes und niemand sieht mehr, woran gerade gearbeitet wird.
const ZIEL_OFFEN=new Set(['open','partly_achieved']);

function pflicht(v:unknown,fehler:string,max=200){const s=safeString(v,max);if(!s)throw new Error(fehler);return s;}
function optional(v:unknown,max=2000){return safeString(v,max)||null;}
function tag(v:unknown,fehler:string){
  const s=safeString(v,10);
  if(!s||!/^\d{4}-\d\d-\d\d$/.test(s)||Number.isNaN(Date.parse(`${s}T00:00:00.000Z`)))throw new Error(fehler);
  return s;
}
function tagOptional(v:unknown,fehler:string){
  const s=safeString(v,10);
  return s?tag(s,fehler):null;
}

// --- Wer darf was ----------------------------------------------------------------------------

/**
 * Beratungsrecht. Es laesst sich aus keiner vorhandenen Rolle ableiten: ein Dozent kann in seinem
 * Kurs 'class_admin' sein und gehoert trotzdem nicht ins Beratungsteam, ein Sozialpaedagoge ist im
 * Kurs oft nur Gast. Deshalb wird es ausdruecklich vergeben und hier ausdruecklich nachgesehen -
 * ohne Abkuerzung ueber auth.role. Auch die Leitung des Traegers hat es nicht automatisch: wer
 * Gespraechsnotizen lesen will, muss im Beratungsteam stehen. Genau das ist der Sinn der Stufe.
 */
export async function hasCounselingAccess(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string):Promise<boolean>{
  const r=await env.DB.prepare(
    `SELECT 1 ok FROM support_counseling_access
      WHERE tenant_id=? AND user_id=? AND status='active' AND (course_id IS NULL OR course_id=?) LIMIT 1`
  ).bind(tenantId,auth.userId,courseId).first();
  return !!r;
}

// Lehrende dieses Kurses. Die Rolle IN DIESEM Kurs entscheidet, nicht auth.role - das ist die
// hoechste ueber alle Kurse, und wer in Klasse A Verantwortung traegt, hat sie in Klasse B nicht.
function lehrendImKurs(auth:CoreAuthContext,courseId:string){
  try{requireRole(auth,'class_admin');requireCourseAccess(auth,courseId,'class_admin');return true;}catch{return false;}
}

/** Den Plan lesen darf, wer den Kurs unterrichtet oder das Beratungsrecht hat. */
async function assertSehen(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  if(lehrendImKurs(auth,courseId))return;
  if(await hasCounselingAccess(env,auth,tenantId,courseId))return;
  throw new Error('FORBIDDEN_SUPPORT_VIEW');
}
/** Dokumentieren darf derselbe Kreis. Der Teilnehmer selbst schreibt hier nichts. */
async function assertDokumentieren(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  if(lehrendImKurs(auth,courseId))return;
  if(await hasCounselingAccess(env,auth,tenantId,courseId))return;
  throw new Error('FORBIDDEN_SUPPORT_MANAGE');
}

// Jede vom Client gelieferte Kennung wird gegen den Mandanten geprueft, nie geglaubt. Ohne diese
// Pruefung reichte eine anderswo erfahrene Kurskennung, um in einem fremden Mandanten zu lesen.
async function ladeKurs(env:Env,tenantId:string,courseId:string){
  const k=await env.DB.prepare('SELECT id,name FROM courses WHERE tenant_id=? AND id=?').bind(tenantId,courseId).first<{id:string;name:string}>();
  if(!k)throw new Error('COURSE_NOT_FOUND');
  return k;
}
async function teilnehmerImKurs(env:Env,tenantId:string,courseId:string,userId:string){
  const r=await env.DB.prepare(
    `SELECT 1 ok FROM memberships WHERE tenant_id=? AND course_id=? AND user_id=? AND role='participant' LIMIT 1`
  ).bind(tenantId,courseId,userId).first();
  if(!r)throw new Error('SUPPORT_PARTICIPANT_NOT_IN_COURSE');
}
async function ladePlan(env:Env,tenantId:string,planId:string){
  const p=await env.DB.prepare('SELECT * FROM support_plans WHERE tenant_id=? AND id=?').bind(tenantId,planId).first<Row>();
  if(!p)throw new Error('SUPPORT_PLAN_NOT_FOUND');
  return p;
}

// --- Beratungsteam ---------------------------------------------------------------------------

/** Beratungsrecht erteilen. Nur die Kundenadministration - es ist ein Recht auf heikle Inhalte. */
export async function grantCounselingAccess(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  requireRole(auth,'tenant_admin');
  const userId=pflicht(input.user_id,'SUPPORT_ACCESS_USER_REQUIRED',120);
  const funktion=String(input.function_kind||'');
  if(!FUNKTIONEN.has(funktion))throw new Error('SUPPORT_COUNSELING_FUNCTION_INVALID');
  // Die Person muss zu DIESEM Mandanten gehoeren, sonst liesse sich ueber eine geratene Kennung
  // ein fremdes Konto ins eigene Beratungsteam heben.
  const gehoert=await env.DB.prepare('SELECT 1 ok FROM tenant_users WHERE tenant_id=? AND user_id=? LIMIT 1').bind(tenantId,userId).first();
  if(!gehoert)throw new Error('SUPPORT_ACCESS_USER_NOT_IN_TENANT');
  const courseId=optional(input.course_id,120);
  if(courseId)await ladeKurs(env,tenantId,courseId);
  const ts=nowIso();
  // Ein erneutes Erteilen ist kein Fehler: es hebt einen frueheren Entzug wieder auf. Kein
  // ON CONFLICT, weil die Eindeutigkeit an zwei TEILschluesseln haengt (mit und ohne Kurs) - ein
  // Konfliktziel koennte immer nur einen davon nennen. Zwei ausgeschriebene Abfragen, weil
  // course_id IS NULL sich nicht als Parameter binden laesst.
  const vorhanden=courseId
    ?await env.DB.prepare('SELECT id FROM support_counseling_access WHERE tenant_id=? AND user_id=? AND course_id=?').bind(tenantId,userId,courseId).first<{id:string}>()
    :await env.DB.prepare('SELECT id FROM support_counseling_access WHERE tenant_id=? AND user_id=? AND course_id IS NULL').bind(tenantId,userId).first<{id:string}>();
  const accessId=vorhanden?.id??id('sca_');
  if(vorhanden)await env.DB.prepare("UPDATE support_counseling_access SET function_kind=?,status='active',granted_by=?,updated_at=? WHERE tenant_id=? AND id=?")
    .bind(funktion,auth.userId,ts,tenantId,accessId).run();
  else await env.DB.prepare(
    `INSERT INTO support_counseling_access(id,tenant_id,course_id,user_id,function_kind,status,granted_by,created_at,updated_at)
     VALUES(?,?,?,?,?,'active',?,?,?)`
  ).bind(accessId,tenantId,courseId,userId,funktion,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'support.counseling.granted',tenantId,courseId??undefined,'support_counseling_access',accessId,{user_id:userId,function_kind:funktion});
  return{id:accessId,user_id:userId,course_id:courseId,function_kind:funktion,status:'active'};
}

/** Beratungsrecht entziehen. Die Zeile bleibt stehen - wer es wann hatte, ist selbst ein Nachweis. */
export async function revokeCounselingAccess(env:Env,auth:CoreAuthContext,tenantId:string,accessId:string){
  requireRole(auth,'tenant_admin');
  const r=await env.DB.prepare("UPDATE support_counseling_access SET status='revoked',updated_at=? WHERE tenant_id=? AND id=? AND status='active'")
    .bind(nowIso(),tenantId,accessId).run();
  if(!Number(r.meta?.changes||0))throw new Error('SUPPORT_COUNSELING_ACCESS_NOT_FOUND');
  await audit(env.DB,auth.userId,'support.counseling.revoked',tenantId,undefined,'support_counseling_access',accessId);
  return{id:accessId,status:'revoked'};
}

/** Wer im Beratungsteam steht. Das darf jeder Lehrende sehen: wen er ansprechen kann, ist kein Geheimnis. */
export async function listCounselingTeam(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string){
  await ladeKurs(env,tenantId,courseId);
  await assertSehen(env,auth,tenantId,courseId);
  const r=await env.DB.prepare(
    `SELECT a.id,a.course_id,a.user_id,a.function_kind,a.status,a.created_at,u.display_name,u.email
       FROM support_counseling_access a JOIN users u ON u.id=a.user_id
      WHERE a.tenant_id=? AND a.status='active' AND (a.course_id IS NULL OR a.course_id=?)
      ORDER BY u.display_name`
  ).bind(tenantId,courseId).all<Row>();
  return r.results??[];
}

// --- Der Foerderplan -------------------------------------------------------------------------

/** Den Plan beim Eintritt vereinbaren. */
export async function createSupportPlan(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  const courseId=pflicht(input.course_id,'SUPPORT_COURSE_REQUIRED',120);
  await ladeKurs(env,tenantId,courseId);
  await assertDokumentieren(env,auth,tenantId,courseId);
  const userId=pflicht(input.user_id,'SUPPORT_PARTICIPANT_REQUIRED',120);
  await teilnehmerImKurs(env,tenantId,courseId,userId);
  const agreedOn=tag(input.agreed_on,'SUPPORT_DATE_INVALID');
  const reviewOn=tagOptional(input.review_due_on,'SUPPORT_DATE_INVALID');
  if(reviewOn&&reviewOn<agreedOn)throw new Error('SUPPORT_REVIEW_DATE_INVALID');
  const offen=await env.DB.prepare("SELECT id FROM support_plans WHERE tenant_id=? AND course_id=? AND user_id=? AND status='active'")
    .bind(tenantId,courseId,userId).first<{id:string}>();
  // Zwei gleichzeitig gueltige Plaene sind zwei widersprechende Vereinbarungen. Fortschreiben
  // statt danebenlegen - dafuer gibt es reviewSupportPlan.
  if(offen)throw new Error('SUPPORT_PLAN_EXISTS');
  const planId=id('spl_'),ts=nowIso();
  await env.DB.prepare(
    `INSERT INTO support_plans(id,tenant_id,course_id,user_id,version,previous_plan_id,agreed_on,review_due_on,status,created_by,created_at,updated_at)
     VALUES(?,?,?,?,1,NULL,?,?,'active',?,?,?)`
  ).bind(planId,tenantId,courseId,userId,agreedOn,reviewOn,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'support.plan.created',tenantId,courseId,'support_plan',planId,{user_id:userId,agreed_on:agreedOn});
  return{id:planId,course_id:courseId,user_id:userId,version:1,agreed_on:agreedOn,review_due_on:reviewOn,status:'active'};
}

/** Ein Ziel im Plan. */
export async function addSupportGoal(env:Env,auth:CoreAuthContext,tenantId:string,planId:string,input:Row){
  const plan=await ladePlan(env,tenantId,planId);
  await assertDokumentieren(env,auth,tenantId,String(plan.course_id));
  if(plan.status!=='active')throw new Error('SUPPORT_PLAN_NOT_ACTIVE');
  const title=pflicht(input.title,'SUPPORT_GOAL_TITLE_REQUIRED',300);
  const goalId=id('sgo_'),ts=nowIso();
  await env.DB.prepare(
    `INSERT INTO support_plan_goals(id,tenant_id,plan_id,title,description,target_on,status,sort_index,created_by,created_at,updated_at)
     VALUES(?,?,?,?,?,?,'open',?,?,?,?)`
  ).bind(goalId,tenantId,planId,title,optional(input.description,4000),tagOptional(input.target_on,'SUPPORT_DATE_INVALID'),
    Math.max(0,Math.min(999,Math.round(Number(input.sort_index||0)))),auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'support.goal.added',tenantId,String(plan.course_id),'support_plan_goal',goalId,{plan_id:planId});
  return{id:goalId,plan_id:planId,title,status:'open'};
}

/** Eine Massnahme zu einem Ziel - mit Zustaendigem und Termin, sonst ist es keine. */
export async function addSupportMeasure(env:Env,auth:CoreAuthContext,tenantId:string,goalId:string,input:Row){
  const ziel=await env.DB.prepare(
    `SELECT g.id,g.plan_id,p.course_id,p.status plan_status FROM support_plan_goals g
       JOIN support_plans p ON p.id=g.plan_id AND p.tenant_id=g.tenant_id
      WHERE g.tenant_id=? AND g.id=?`
  ).bind(tenantId,goalId).first<Row>();
  if(!ziel)throw new Error('SUPPORT_GOAL_NOT_FOUND');
  await assertDokumentieren(env,auth,tenantId,String(ziel.course_id));
  if(ziel.plan_status!=='active')throw new Error('SUPPORT_PLAN_NOT_ACTIVE');
  const title=pflicht(input.title,'SUPPORT_MEASURE_TITLE_REQUIRED',300);
  const zustaendig=pflicht(input.responsible_user_id,'SUPPORT_MEASURE_RESPONSIBLE_REQUIRED',120);
  // Der Zustaendige muss zum Mandanten gehoeren. Sonst stuende in der Akte ein Name, den bei der
  // Pruefung niemand zuordnen kann - und die Massnahme haette faktisch keinen Verantwortlichen.
  const gehoert=await env.DB.prepare('SELECT 1 ok FROM tenant_users WHERE tenant_id=? AND user_id=? LIMIT 1').bind(tenantId,zustaendig).first();
  if(!gehoert)throw new Error('SUPPORT_MEASURE_RESPONSIBLE_NOT_IN_TENANT');
  const dueOn=tag(input.due_on,'SUPPORT_DATE_INVALID');
  const measureId=id('sms_'),ts=nowIso();
  await env.DB.prepare(
    `INSERT INTO support_plan_measures(id,tenant_id,goal_id,title,responsible_user_id,due_on,status,created_by,created_at,updated_at)
     VALUES(?,?,?,?,?,?,'open',?,?,?)`
  ).bind(measureId,tenantId,goalId,title,zustaendig,dueOn,auth.userId,ts,ts).run();
  await audit(env.DB,auth.userId,'support.measure.added',tenantId,String(ziel.course_id),'support_plan_measure',measureId,{goal_id:goalId,due_on:dueOn});
  return{id:measureId,goal_id:goalId,title,responsible_user_id:zustaendig,due_on:dueOn,status:'open'};
}

/** Den Stand eines Ziels fortschreiben. */
export async function setSupportGoalStatus(env:Env,auth:CoreAuthContext,tenantId:string,goalId:string,status:string){
  if(!ZIEL_STATUS.has(status))throw new Error('SUPPORT_STATUS_INVALID');
  const ziel=await env.DB.prepare(
    `SELECT g.id,p.course_id FROM support_plan_goals g JOIN support_plans p ON p.id=g.plan_id AND p.tenant_id=g.tenant_id
      WHERE g.tenant_id=? AND g.id=?`
  ).bind(tenantId,goalId).first<Row>();
  if(!ziel)throw new Error('SUPPORT_GOAL_NOT_FOUND');
  await assertDokumentieren(env,auth,tenantId,String(ziel.course_id));
  await env.DB.prepare('UPDATE support_plan_goals SET status=?,updated_at=? WHERE tenant_id=? AND id=?').bind(status,nowIso(),tenantId,goalId).run();
  return{id:goalId,status};
}

/** Den Stand einer Massnahme fortschreiben. */
export async function setSupportMeasureStatus(env:Env,auth:CoreAuthContext,tenantId:string,measureId:string,status:string){
  if(!MASSNAHME_STATUS.has(status))throw new Error('SUPPORT_STATUS_INVALID');
  const m=await env.DB.prepare(
    `SELECT m.id,p.course_id FROM support_plan_measures m
       JOIN support_plan_goals g ON g.id=m.goal_id AND g.tenant_id=m.tenant_id
       JOIN support_plans p ON p.id=g.plan_id AND p.tenant_id=g.tenant_id
      WHERE m.tenant_id=? AND m.id=?`
  ).bind(tenantId,measureId).first<Row>();
  if(!m)throw new Error('SUPPORT_MEASURE_NOT_FOUND');
  await assertDokumentieren(env,auth,tenantId,String(m.course_id));
  await env.DB.prepare('UPDATE support_plan_measures SET status=?,updated_at=? WHERE tenant_id=? AND id=?').bind(status,nowIso(),tenantId,measureId).run();
  return{id:measureId,status};
}

// --- Beobachtungen und Beratungsgespraeche ----------------------------------------------------

/**
 * Ein datierter Eintrag: entweder eine Beobachtung am Ziel oder ein Beratungsgespraech mit Anlass,
 * Vereinbarung und naechstem Termin.
 *
 * Die Sichtbarkeitsstufe steht am EINTRAG, nicht an der Rolle des Schreibenden. Derselbe
 * Sozialpaedagoge schreibt am selben Tag eine Beobachtung, die jeder Dozent kennen muss, und eine
 * Gespraechsnotiz, die nur das Beratungsteam etwas angeht. Waere die Stufe an der Rolle
 * festgemacht, muesste er sich zwischen "alles offen" und "nichts geteilt" entscheiden - und
 * wuerde in der Praxis gar nichts mehr dokumentieren.
 */
export async function addSupportJournalEntry(env:Env,auth:CoreAuthContext,tenantId:string,input:Row){
  const courseId=pflicht(input.course_id,'SUPPORT_COURSE_REQUIRED',120);
  await ladeKurs(env,tenantId,courseId);
  await assertDokumentieren(env,auth,tenantId,courseId);
  const userId=pflicht(input.user_id,'SUPPORT_PARTICIPANT_REQUIRED',120);
  await teilnehmerImKurs(env,tenantId,courseId,userId);
  const art=String(input.entry_kind||'');
  if(art!=='observation'&&art!=='counseling')throw new Error('SUPPORT_ENTRY_KIND_INVALID');
  const sichtbarkeit=String(input.visibility||'') as Sichtbarkeit;
  if(!SICHTBARKEIT.has(sichtbarkeit))throw new Error('SUPPORT_VISIBILITY_INVALID');
  const occurredOn=tag(input.occurred_on,'SUPPORT_DATE_INVALID');
  const subject=pflicht(input.subject,'SUPPORT_ENTRY_SUBJECT_REQUIRED',300);
  const body=pflicht(input.body,'SUPPORT_ENTRY_BODY_REQUIRED',8000);
  const nextOn=tagOptional(input.next_meeting_on,'SUPPORT_DATE_INVALID');
  if(nextOn&&nextOn<occurredOn)throw new Error('SUPPORT_NEXT_MEETING_INVALID');

  // Das Ziel bestimmt den Plan. Eine Beobachtung ohne Ziel waere eine Notiz ins Blaue: sie soll
  // zeigen, wie weit das VEREINBARTE Ziel getragen hat.
  let goalId:string|null=optional(input.goal_id,120);
  let planId:string|null=optional(input.plan_id,120);
  if(art==='observation'&&!goalId)throw new Error('SUPPORT_ENTRY_GOAL_REQUIRED');
  if(goalId){
    const ziel=await env.DB.prepare(
      `SELECT g.id,g.plan_id,p.course_id,p.user_id FROM support_plan_goals g
         JOIN support_plans p ON p.id=g.plan_id AND p.tenant_id=g.tenant_id
        WHERE g.tenant_id=? AND g.id=?`
    ).bind(tenantId,goalId).first<Row>();
    if(!ziel)throw new Error('SUPPORT_GOAL_NOT_FOUND');
    // Kurs und Person des Ziels muessen zum Eintrag passen. Ohne diese Pruefung liesse sich eine
    // Beobachtung ueber Person A an das Ziel von Person B haengen.
    if(String(ziel.course_id)!==courseId||String(ziel.user_id)!==userId)throw new Error('SUPPORT_GOAL_NOT_FOUND');
    planId=String(ziel.plan_id);
  }else if(planId){
    const plan=await ladePlan(env,tenantId,planId);
    if(String(plan.course_id)!==courseId||String(plan.user_id)!==userId)throw new Error('SUPPORT_PLAN_NOT_FOUND');
  }

  const entryId=id('sje_'),ts=nowIso();
  await env.DB.prepare(
    `INSERT INTO support_journal_entries(id,tenant_id,course_id,user_id,plan_id,goal_id,entry_kind,occurred_on,subject,body,next_meeting_on,visibility,created_by,created_at,updated_at)
     VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  ).bind(entryId,tenantId,courseId,userId,planId,goalId,art,occurredOn,subject,body,nextOn,sichtbarkeit,auth.userId,ts,ts).run();
  // Der Inhalt gehoert NICHT ins Revisionsprotokoll: das audit_log ueberlebt die Loeschung des
  // Mandanten (siehe tenant-erasure-registry.ts). Festgehalten wird, DASS dokumentiert wurde.
  await audit(env.DB,auth.userId,'support.journal.added',tenantId,courseId,'support_journal_entry',entryId,{entry_kind:art,visibility:sichtbarkeit,occurred_on:occurredOn});
  return{id:entryId,entry_kind:art,visibility:sichtbarkeit,occurred_on:occurredOn,next_meeting_on:nextOn};
}

// Die Sichtbarkeitsregel steht genau einmal, als Bedingung IN DER ABFRAGE. Ein geschuetzter
// Eintrag verlaesst damit die Datenbank gar nicht erst - anders als bei einem Filter im Quelltext,
// wo eine spaeter eingefuegte Zeile die Rohdaten wieder ausgeben koennte, bevor gefiltert wird.
const SICHTBAR=`(e.visibility='teaching_team' OR ?=1 OR e.created_by=?)`;

async function journal(env:Env,tenantId:string,courseId:string,userId:string,beratung:boolean,leser:string,goalId?:string){
  // Zwei ausgeschriebene Anweisungen statt einer zusammengesetzten: nur so laesst sich jede von
  // ihnen gegen das echte Schema vorbereiten (tests/sql-schema-contract.mjs).
  const rows=goalId
    ?((await env.DB.prepare(
      `SELECT e.id,e.entry_kind,e.occurred_on,e.subject,e.body,e.next_meeting_on,e.visibility,e.goal_id,e.plan_id,e.created_by,e.created_at,u.display_name author_name
         FROM support_journal_entries e JOIN users u ON u.id=e.created_by
        WHERE e.tenant_id=? AND e.course_id=? AND e.user_id=? AND e.goal_id=? AND ${SICHTBAR}
        ORDER BY e.occurred_on DESC,e.created_at DESC LIMIT 500`
    ).bind(tenantId,courseId,userId,goalId,beratung?1:0,leser).all<Row>()).results)??[]
    :((await env.DB.prepare(
      `SELECT e.id,e.entry_kind,e.occurred_on,e.subject,e.body,e.next_meeting_on,e.visibility,e.goal_id,e.plan_id,e.created_by,e.created_at,u.display_name author_name
         FROM support_journal_entries e JOIN users u ON u.id=e.created_by
        WHERE e.tenant_id=? AND e.course_id=? AND e.user_id=? AND ${SICHTBAR}
        ORDER BY e.occurred_on DESC,e.created_at DESC LIMIT 500`
    ).bind(tenantId,courseId,userId,beratung?1:0,leser).all<Row>()).results)??[];
  return rows;
}

// Was jemand NICHT sehen darf, wird gezaehlt statt verschwiegen. Sonst haelt die Leitung eine
// luecklige Liste fuer vollstaendig und meldet dem Kostentraeger zu wenige Gespraeche - und beim
// Betroffenen entstuende der Eindruck, es sei nie mit ihm gesprochen worden.
async function verborgen(env:Env,tenantId:string,courseId:string,userId:string,leser:string){
  const r=await env.DB.prepare(
    `SELECT COUNT(*) n FROM support_journal_entries
      WHERE tenant_id=? AND course_id=? AND user_id=? AND visibility='counseling_team' AND created_by<>?`
  ).bind(tenantId,courseId,userId,leser).first<{n:number}>();
  return Number(r?.n||0);
}

/** Der Plan mit Zielen, Massnahmen und den Beobachtungen am jeweiligen Ziel. */
export async function getSupportPlan(env:Env,auth:CoreAuthContext,tenantId:string,planId:string){
  const plan=await ladePlan(env,tenantId,planId);
  const courseId=String(plan.course_id),userId=String(plan.user_id);
  await assertSehen(env,auth,tenantId,courseId);
  const beratung=await hasCounselingAccess(env,auth,tenantId,courseId);
  const ziele=((await env.DB.prepare(
    'SELECT id,title,description,target_on,status,sort_index,created_at FROM support_plan_goals WHERE tenant_id=? AND plan_id=? ORDER BY sort_index,created_at'
  ).bind(tenantId,planId).all<Row>()).results)??[];
  const massnahmen=((await env.DB.prepare(
    `SELECT m.id,m.goal_id,m.title,m.responsible_user_id,m.due_on,m.status,u.display_name responsible_name
       FROM support_plan_measures m JOIN support_plan_goals g ON g.id=m.goal_id AND g.tenant_id=m.tenant_id
       LEFT JOIN users u ON u.id=m.responsible_user_id
      WHERE m.tenant_id=? AND g.plan_id=? ORDER BY m.due_on,m.created_at`
  ).bind(tenantId,planId).all<Row>()).results)??[];
  const eintraege=await journal(env,tenantId,courseId,userId,beratung,auth.userId);
  return{
    plan,
    can_read_counseling:beratung,
    goals:ziele.map(z=>({
      ...z,
      measures:massnahmen.filter(m=>String(m.goal_id)===String(z.id)),
      observations:eintraege.filter(e=>e.entry_kind==='observation'&&String(e.goal_id??'')===String(z.id)),
    })),
    protected_entries_hidden:beratung?0:await verborgen(env,tenantId,courseId,userId,auth.userId),
  };
}

/**
 * Die Beratungsdokumentation einer Person: jedes Gespraech, datiert, mit Anlass, Vereinbarung und
 * naechstem Termin. Das ist der Nachweis der Betreuungsleistung gegenueber dem Kostentraeger.
 */
export async function listCounselingHistory(env:Env,auth:CoreAuthContext,tenantId:string,courseId:string,userId:string){
  await ladeKurs(env,tenantId,courseId);
  await assertSehen(env,auth,tenantId,courseId);
  await teilnehmerImKurs(env,tenantId,courseId,userId);
  const beratung=await hasCounselingAccess(env,auth,tenantId,courseId);
  const alle=await journal(env,tenantId,courseId,userId,beratung,auth.userId);
  const entries=alle.filter(e=>e.entry_kind==='counseling');
  const naechster=entries.map(e=>String(e.next_meeting_on||'')).filter(Boolean).sort().pop()??null;
  return{
    course_id:courseId,user_id:userId,
    can_read_counseling:beratung,
    entries,
    next_meeting_on:naechster,
    protected_entries_hidden:beratung?0:await verborgen(env,tenantId,courseId,userId,auth.userId),
  };
}

/** Beobachtungen zu einem Ziel - dieselbe Regel, nur enger gefragt. */
export async function listGoalObservations(env:Env,auth:CoreAuthContext,tenantId:string,goalId:string){
  const ziel=await env.DB.prepare(
    `SELECT g.id,p.course_id,p.user_id FROM support_plan_goals g JOIN support_plans p ON p.id=g.plan_id AND p.tenant_id=g.tenant_id
      WHERE g.tenant_id=? AND g.id=?`
  ).bind(tenantId,goalId).first<Row>();
  if(!ziel)throw new Error('SUPPORT_GOAL_NOT_FOUND');
  const courseId=String(ziel.course_id);
  await assertSehen(env,auth,tenantId,courseId);
  const beratung=await hasCounselingAccess(env,auth,tenantId,courseId);
  return await journal(env,tenantId,courseId,String(ziel.user_id),beratung,auth.userId,goalId);
}

// --- Fortschreibung zum Review-Termin ---------------------------------------------------------

/**
 * Zum Review-Termin wird der Plan fortgeschrieben: die alte Fassung bleibt unveraendert stehen und
 * wird als abgeloest gekennzeichnet, die noch offenen Ziele wandern samt ihrer offenen Massnahmen
 * in die naechste Fassung. Ein ueberschriebener Plan waere kein Nachweis mehr - bei der Pruefung
 * liesse sich nicht mehr zeigen, was zum Eintritt vereinbart war und was sich seither geaendert hat.
 */
export async function reviewSupportPlan(env:Env,auth:CoreAuthContext,tenantId:string,planId:string,input:Row){
  const plan=await ladePlan(env,tenantId,planId);
  const courseId=String(plan.course_id),userId=String(plan.user_id);
  await assertDokumentieren(env,auth,tenantId,courseId);
  if(plan.status!=='active')throw new Error('SUPPORT_PLAN_NOT_ACTIVE');
  const agreedOn=tag(input.agreed_on,'SUPPORT_DATE_INVALID');
  const reviewOn=tagOptional(input.review_due_on,'SUPPORT_DATE_INVALID');
  if(reviewOn&&reviewOn<agreedOn)throw new Error('SUPPORT_REVIEW_DATE_INVALID');

  const ziele=((await env.DB.prepare(
    'SELECT id,title,description,target_on,status,sort_index FROM support_plan_goals WHERE tenant_id=? AND plan_id=? ORDER BY sort_index,created_at'
  ).bind(tenantId,planId).all<Row>()).results)??[];
  const massnahmen=((await env.DB.prepare(
    `SELECT m.id,m.goal_id,m.title,m.responsible_user_id,m.due_on,m.status FROM support_plan_measures m
       JOIN support_plan_goals g ON g.id=m.goal_id AND g.tenant_id=m.tenant_id
      WHERE m.tenant_id=? AND g.plan_id=?`
  ).bind(tenantId,planId).all<Row>()).results)??[];

  const neuId=id('spl_'),ts=nowIso(),version=Number(plan.version||1)+1;
  const anweisungen:unknown[]=[
    // Die alte Fassung MUSS vor dem Einfuegen abgeloest werden: der Teilschluessel aus der
    // Migration laesst nur einen aktiven Plan je Person und Kurs zu. Umgekehrte Reihenfolge und
    // die Fortschreibung scheitert an der eigenen Regel.
    env.DB.prepare("UPDATE support_plans SET status='superseded',updated_at=? WHERE tenant_id=? AND id=? AND status='active'").bind(ts,tenantId,planId),
    env.DB.prepare(
      `INSERT INTO support_plans(id,tenant_id,course_id,user_id,version,previous_plan_id,agreed_on,review_due_on,status,created_by,created_at,updated_at)
       VALUES(?,?,?,?,?,?,?,?,'active',?,?,?)`
    ).bind(neuId,tenantId,courseId,userId,version,planId,agreedOn,reviewOn,auth.userId,ts,ts),
  ];
  let uebernommeneZiele=0,uebernommeneMassnahmen=0;
  for(const z of ziele){
    if(!ZIEL_OFFEN.has(String(z.status)))continue;
    const neuesZiel=id('sgo_');uebernommeneZiele++;
    anweisungen.push(env.DB.prepare(
      `INSERT INTO support_plan_goals(id,tenant_id,plan_id,title,description,target_on,status,sort_index,created_by,created_at,updated_at)
       VALUES(?,?,?,?,?,?,'open',?,?,?,?)`
    ).bind(neuesZiel,tenantId,neuId,String(z.title),z.description??null,z.target_on??null,Number(z.sort_index||0),auth.userId,ts,ts));
    for(const m of massnahmen){
      if(String(m.goal_id)!==String(z.id))continue;
      // Erledigtes und Abgebrochenes bleibt in der alten Fassung. Es doppelt mitzunehmen wuerde
      // die naechste Pruefung glauben machen, die Massnahme sei zweimal erbracht worden.
      if(String(m.status)!=='open'&&String(m.status)!=='in_progress')continue;
      uebernommeneMassnahmen++;
      anweisungen.push(env.DB.prepare(
        `INSERT INTO support_plan_measures(id,tenant_id,goal_id,title,responsible_user_id,due_on,status,created_by,created_at,updated_at)
         VALUES(?,?,?,?,?,?,?,?,?,?)`
      ).bind(id('sms_'),tenantId,neuesZiel,String(m.title),String(m.responsible_user_id),String(m.due_on),String(m.status),auth.userId,ts,ts));
    }
  }
  await env.DB.batch(anweisungen as never[]);
  await audit(env.DB,auth.userId,'support.plan.reviewed',tenantId,courseId,'support_plan',neuId,{previous_plan_id:planId,version,goals:uebernommeneZiele,measures:uebernommeneMassnahmen});
  return{id:neuId,previous_plan_id:planId,version,goals_carried_over:uebernommeneZiele,measures_carried_over:uebernommeneMassnahmen};
}

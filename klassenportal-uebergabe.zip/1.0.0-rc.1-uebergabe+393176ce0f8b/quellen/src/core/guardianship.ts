import type { CoreAuthContext, Env } from './types.js';
import { audit } from './audit.js';
import { requireRole } from './permissions.js';
import { id, nowIso, safeString } from './utils.js';
import { gesperrteBereiche, pruefeZugriff } from './access-restrictions.js';

// Die Elternrolle (Master-Spec V2 §7).
//
// Ein Sorgeberechtigter ist keine Stufe auf der Rangleiter zwischen Teilnehmer und Leitung - er
// sieht die Daten einer ANDEREN Person. Deshalb gibt es hier keine neue Rolle, sondern eine
// ausdrueckliche Verknuepfung und eigene Zugaenge, die jedes Mal genau diese Verknuepfung pruefen.
// Ohne Verknuepfung sieht ein Elternteil weiterhin nichts - an keiner bestehenden Stelle aendert
// sich etwas.
//
// Die beiden Regeln, an denen es rechtlich haengt:
//  - Das Sorgerecht endet mit der Volljaehrigkeit. Danach entscheidet die junge Person selbst, ob
//    die Eltern weiter Einblick haben - und nur sie kann diese Einwilligung geben und widerrufen.
//  - Ein Elternteil sieht ausschliesslich das eigene Kind. Die Kennung des Kindes kommt nie aus der
//    Anfrage, sondern immer aus der geprueften Verknuepfung.

export const VERHAELTNISSE=['mutter','vater','vormund','betreuer','sonstige'] as const;
// Vormund und rechtlicher Betreuer enden durch Gerichtsbeschluss, nicht an einem Geburtstag.
export const OHNE_ENDE_ERLAUBT=['vormund','betreuer'];
const clean=(v:unknown,n=500)=>safeString(v,n);

export type Muendel={guardianship_id:string;participant_user_id:string;display_name:string;verhaeltnis:string;gueltig_bis:string|null;einwilligung_der_person_am:string|null};

/**
 * Die Kinder, fuer die dieser Zugang HEUTE gilt.
 *
 * Nach dem eingetragenen Ende gilt die Verknuepfung nur weiter, wenn die betroffene Person selbst
 * eingewilligt hat. Das ist der ganze Unterschied zwischen Sorgerecht und Datenschutz.
 */
export async function meineMuendel(env:Env,auth:CoreAuthContext,tenantId:string,stichtag=nowIso()):Promise<Muendel[]>{
  const tag=stichtag.slice(0,10);
  return (await env.DB.prepare("SELECT g.id AS guardianship_id,g.participant_user_id,u.display_name,g.verhaeltnis,g.gueltig_bis,g.einwilligung_der_person_am FROM guardianships g JOIN users u ON u.id=g.participant_user_id WHERE g.tenant_id=? AND g.guardian_user_id=? AND g.status='aktiv' AND u.status='active' AND (g.gueltig_bis IS NULL OR substr(g.gueltig_bis,1,10)>=? OR g.einwilligung_der_person_am IS NOT NULL) ORDER BY u.display_name")
    .bind(tenantId,auth.userId,tag).all<Muendel>()).results??[];
}

/** Wirft, wenn dieser Zugang fuer dieses Kind heute nicht gilt. Jede Elternsicht faengt damit an. */
export async function assertMuendel(env:Env,auth:CoreAuthContext,tenantId:string,kindId:string,stichtag=nowIso()):Promise<Muendel>{
  const tag=stichtag.slice(0,10);
  const g=await env.DB.prepare("SELECT g.id AS guardianship_id,g.participant_user_id,u.display_name,g.verhaeltnis,g.gueltig_bis,g.einwilligung_der_person_am FROM guardianships g JOIN users u ON u.id=g.participant_user_id WHERE g.tenant_id=? AND g.guardian_user_id=? AND g.participant_user_id=? AND g.status='aktiv' AND u.status='active' AND (g.gueltig_bis IS NULL OR substr(g.gueltig_bis,1,10)>=? OR g.einwilligung_der_person_am IS NOT NULL)")
    .bind(tenantId,auth.userId,kindId,tag).first<Muendel>();
  if(!g)throw new Error('GUARDIANSHIP_NOT_ACTIVE');
  // Sorgerecht ist nicht dasselbe wie unbeschraenkter Einblick. Liegt eine gerichtliche
  // Beschraenkung oder ein Kontaktverbot gegen genau diesen Zugang vor, endet er hier - und zwar
  // serverseitig, nicht erst in der Anzeige.
  await pruefeZugriff(env,tenantId,kindId,auth.userId,undefined,stichtag);
  return g;
}

export async function createGuardianship(env:Env,auth:CoreAuthContext,tenantId:string,input:Record<string,unknown>){
  requireRole(auth,'tenant_admin');
  const guardian=clean(input.guardian_user_id,120),kind=clean(input.participant_user_id,120),verhaeltnis=clean(input.verhaeltnis,40);
  if(!guardian||!kind)throw new Error('GUARDIANSHIP_USERS_REQUIRED');
  if(guardian===kind)throw new Error('GUARDIANSHIP_SAME_PERSON');
  if(!VERHAELTNISSE.includes(verhaeltnis as never))throw new Error('GUARDIANSHIP_RELATION_INVALID');
  const bis=clean(input.gueltig_bis,40)||null;
  // Ein Elternteil ohne Enddatum haette Einblick, bis irgendwann jemand daran denkt. Der Traeger
  // kennt den Geburtstag aus seinen Unterlagen; dieses System speichert ihn bewusst nicht.
  if(!bis&&!OHNE_ENDE_ERLAUBT.includes(verhaeltnis))throw new Error('GUARDIANSHIP_END_REQUIRED');
  const beide=(await env.DB.prepare('SELECT id FROM users WHERE id IN (?,?) AND status=\'active\'').bind(guardian,kind).all<{id:string}>()).results??[];
  if(beide.length!==2)throw new Error('GUARDIANSHIP_USER_NOT_FOUND');
  const imMandanten=await env.DB.prepare('SELECT COUNT(DISTINCT user_id) n FROM memberships WHERE tenant_id=? AND user_id IN (?,?)').bind(tenantId,guardian,kind).first<{n:number}>();
  if(Number(imMandanten?.n||0)!==2)throw new Error('GUARDIANSHIP_USER_NOT_IN_TENANT');
  const gid=id('sorg_'),ts=nowIso();
  try{
    await env.DB.prepare('INSERT INTO guardianships(id,tenant_id,guardian_user_id,participant_user_id,verhaeltnis,gueltig_bis,status,angelegt_von,angelegt_am,updated_at) VALUES(?,?,?,?,?,?,\'aktiv\',?,?,?)')
      .bind(gid,tenantId,guardian,kind,verhaeltnis,bis,auth.userId,ts,ts).run();
  }catch(e){
    if(/UNIQUE/i.test(String((e as Error).message)))throw new Error('GUARDIANSHIP_ALREADY_EXISTS');
    throw e;
  }
  await audit(env.DB,auth.userId,'guardianship.created',tenantId,undefined,'guardianship',gid,{verhaeltnis,gueltig_bis:bis});
  return env.DB.prepare('SELECT * FROM guardianships WHERE id=?').bind(gid).first();
}

export async function endGuardianship(env:Env,auth:CoreAuthContext,tenantId:string,guardianshipId:string){
  requireRole(auth,'tenant_admin');
  const ts=nowIso();
  // Beendet, nicht geloescht: wer wann Einblick hatte, muss nachvollziehbar bleiben.
  const r=await env.DB.prepare("UPDATE guardianships SET status='beendet',beendet_von=?,beendet_am=?,updated_at=? WHERE id=? AND tenant_id=? AND status='aktiv'")
    .bind(auth.userId,ts,ts,guardianshipId,tenantId).run();
  if(!r.meta?.changes)throw new Error('GUARDIANSHIP_NOT_FOUND');
  await audit(env.DB,auth.userId,'guardianship.ended',tenantId,undefined,'guardianship',guardianshipId);
  return{ended:true};
}

export async function listGuardianships(env:Env,auth:CoreAuthContext,tenantId:string){
  requireRole(auth,'tenant_admin');
  return (await env.DB.prepare('SELECT g.*,e.display_name AS guardian_name,k.display_name AS participant_name FROM guardianships g JOIN users e ON e.id=g.guardian_user_id JOIN users k ON k.id=g.participant_user_id WHERE g.tenant_id=? ORDER BY g.status,k.display_name,e.display_name')
    .bind(tenantId).all()).results??[];
}

/**
 * Die Einwilligung nach dem Ende des Sorgerechts. Nur die betroffene Person selbst.
 *
 * Bewusst getrennt von createGuardianship: wuerde der Traeger sie setzen koennen, waere sie keine
 * Einwilligung, sondern eine Verwaltungsentscheidung ueber fremde Daten.
 */
export async function setOwnGuardianConsent(env:Env,auth:CoreAuthContext,tenantId:string,guardianshipId:string,einwilligen:boolean){
  const ts=nowIso();
  const r=await env.DB.prepare('UPDATE guardianships SET einwilligung_der_person_am=?,updated_at=? WHERE id=? AND tenant_id=? AND participant_user_id=?')
    .bind(einwilligen?ts:null,ts,guardianshipId,tenantId,auth.userId).run();
  if(!r.meta?.changes)throw new Error('GUARDIANSHIP_NOT_FOUND');
  await audit(env.DB,auth.userId,einwilligen?'guardianship.consent_given':'guardianship.consent_withdrawn',tenantId,undefined,'guardianship',guardianshipId);
  return{consent:einwilligen};
}

/** Die eigene Sicht der teilnehmenden Person: wer sieht mich, und kann ich das beenden. */
export async function myGuardians(env:Env,auth:CoreAuthContext,tenantId:string){
  return (await env.DB.prepare("SELECT g.id,g.verhaeltnis,g.gueltig_bis,g.einwilligung_der_person_am,g.status,e.display_name AS guardian_name FROM guardianships g JOIN users e ON e.id=g.guardian_user_id WHERE g.tenant_id=? AND g.participant_user_id=? ORDER BY g.status,e.display_name")
    .bind(tenantId,auth.userId).all()).results??[];
}

/**
 * Was ein Elternteil ueber sein Kind sehen darf: Anwesenheit, veroeffentlichte Noten, gemeldete
 * Abwesenheiten. Bewusst NICHT: Abgabetexte, Forenbeitraege, Nachrichten, Notizen - das sind die
 * eigenen Aeusserungen des Kindes und nicht Gegenstand der Auskunft an die Eltern.
 */
export async function wardOverview(env:Env,auth:CoreAuthContext,tenantId:string,kindId:string,stichtag=nowIso()){
  const g=await assertMuendel(env,auth,tenantId,kindId,stichtag);
  const kurse=(await env.DB.prepare("SELECT c.id,c.name FROM memberships m JOIN courses c ON c.id=m.course_id WHERE m.tenant_id=? AND m.user_id=? AND m.role='participant' AND c.is_active=1 ORDER BY c.name")
    .bind(tenantId,kindId).all<{id:string;name:string}>()).results??[];
  const anwesenheit=(await env.DB.prepare("SELECT course_id,status,COUNT(*) n FROM attendance_records WHERE tenant_id=? AND user_id=? GROUP BY course_id,status")
    .bind(tenantId,kindId).all()).results??[];
  const noten=(await env.DB.prepare("SELECT gi.title,gi.max_points,gs.points,gs.grade_value,gs.published_at FROM gradebook_scores gs JOIN gradebook_items gi ON gi.id=gs.item_id WHERE gs.tenant_id=? AND gs.user_id=? AND gs.status='published' AND gi.visible_to_participants=1 ORDER BY gs.published_at DESC LIMIT 100")
    .bind(tenantId,kindId).all()).results??[];
  const abwesenheiten=(await env.DB.prepare('SELECT id,course_id,starts_on,ends_on,status,kind,submitted_at,eingereicht_von FROM absence_notices WHERE tenant_id=? AND user_id=? ORDER BY starts_on DESC LIMIT 100')
    .bind(tenantId,kindId).all()).results??[];
  // Eine teilweise Beschraenkung schliesst nicht den ganzen Zugang, sondern genau die benannten
  // Bereiche. Was gesperrt ist, kommt leer zurueck UND wird als gesperrt benannt - ein stilles
  // "keine Eintraege" waere eine Falschauskunft.
  const gesperrt=await gesperrteBereiche(env,tenantId,kindId,auth.userId,stichtag);
  return{kind:{id:kindId,display_name:g.display_name,verhaeltnis:g.verhaeltnis},
    kurse:gesperrt.has('stundenplan')?[]:kurse,
    anwesenheit:gesperrt.has('anwesenheit')?[]:anwesenheit,
    noten:gesperrt.has('noten')?[]:noten,
    abwesenheiten:gesperrt.has('abwesenheiten')?[]:abwesenheiten,
    gesperrte_bereiche:[...gesperrt]};
}

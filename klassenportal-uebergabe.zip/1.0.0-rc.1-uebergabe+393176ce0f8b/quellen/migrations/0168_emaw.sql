PRAGMA foreign_keys = ON;

-- Elektronische Massnahmeabwicklung (eM@w) der Bundesagentur fuer Arbeit.
--
-- Der Punkt, an dem eine selbstgebaute Anbindung regelmaessig scheitert, steht im technischen
-- Infopaket der BA in einem Nebensatz:
--
--   "Die Kommunikationseroeffnung bezueglich eines Kunden [...] muss also immer von Seiten der
--    BA / des Jobcenters in Form eines Anmelde-Ereignisses erfolgen."
--
-- Die Schluesseldaten - drei UUIDs fuer Traeger, Massnahme und Teilnehmer, dazu Kundennummer und
-- Verfahrenszweig - werden vom Traeger NICHT vergeben. Er erfaehrt sie aus einem Anmeldeereignis
-- der BA und muss sie unveraendert zuruecksenden. Wer sie erfindet oder abtippt, bekommt
-- "unbekannte Schluesselkombination" - und zwar erst in der Quittung, Stunden spaeter.
--
-- Deshalb ist emaw_schluessel eine EMPFANGENE Tabelle: sie wird ausschliesslich aus eingegangenen
-- Anmeldeereignissen befuellt, und ohne einen Eintrag darin laesst sich kein Ereignis erzeugen.

CREATE TABLE IF NOT EXISTS emaw_provider (
  tenant_id TEXT PRIMARY KEY,
  providername TEXT NOT NULL,
  -- Der Providername besteht ausschliesslich aus Kleinbuchstaben (Infopaket, Kap. Kommunikations-
  -- konzept) und ist Bestandteil jedes Dateinamens. Ein Grossbuchstabe hier macht jedes Archiv
  -- unbrauchbar.
  aktiv INTEGER NOT NULL DEFAULT 1 CHECK(aktiv IN (0,1)),
  eigener_provider INTEGER NOT NULL DEFAULT 1 CHECK(eigener_provider IN (0,1)),
  bemerkung TEXT,
  angelegt_von TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(angelegt_von) REFERENCES users(id),
  CHECK(providername GLOB '[a-z]*' AND providername NOT GLOB '*[^a-z0-9]*')
);

CREATE TABLE IF NOT EXISTS emaw_schluessel (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  kundennummer TEXT NOT NULL,
  verfahrenszweig TEXT NOT NULL,
  traeger_cosach_id TEXT NOT NULL,
  traeger_quelle TEXT NOT NULL,
  traeger_aanr TEXT NOT NULL,
  traeger_lfdnr TEXT NOT NULL,
  traeger_bezeichnung TEXT NOT NULL,
  massnahme_cosach_id TEXT NOT NULL,
  massnahme_quelle TEXT NOT NULL,
  massnahme_aanr TEXT NOT NULL,
  massnahme_lfdnr TEXT NOT NULL,
  massnahme_jahr TEXT NOT NULL,
  massnahme_bezeichnung TEXT NOT NULL,
  kunde_cosach_id TEXT NOT NULL,
  kunde_name TEXT NOT NULL,
  kunde_vorname TEXT NOT NULL,
  kunde_arbeitsamtsnummer TEXT NOT NULL,
  -- Die Zuordnung zur eigenen Welt. Beides darf offen bleiben, solange niemand zugeordnet hat -
  -- dann steht die Anmeldung als unerledigter Posten in der Mappe, statt still zu verschwinden.
  user_id TEXT,
  course_id TEXT,
  quelle_ereignis TEXT NOT NULL,
  empfangen_am TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE SET NULL,
  UNIQUE(tenant_id,kundennummer,massnahme_cosach_id,verfahrenszweig)
);
CREATE INDEX IF NOT EXISTS idx_emaw_schluessel_zuordnung ON emaw_schluessel(tenant_id,user_id,course_id);

CREATE TABLE IF NOT EXISTS emaw_ereignisse (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  schluessel_id TEXT NOT NULL,
  richtung TEXT NOT NULL CHECK(richtung IN ('an_ba','an_traeger')),
  art TEXT NOT NULL,
  ereignis_id TEXT NOT NULL,
  ereignis_datum TEXT NOT NULL,
  dateiname TEXT NOT NULL,
  xml TEXT NOT NULL,
  archiv_id TEXT,
  -- 'erzeugt' -> im Archiv -> 'uebergeben' -> Quittung -> 'angenommen' | 'abgewiesen'.
  -- 'abgewiesen' ist endgueltig: ein mit NOK quittiertes Ereignis nimmt eM@w nicht noch einmal
  -- entgegen (Infopaket: "koennen von EMAW nicht noch einmal in die Importverarbeitung genommen
  -- werden"). Der Nachfolger ist ein NEUES Ereignis mit neuer Ereignis-ID.
  status TEXT NOT NULL DEFAULT 'erzeugt' CHECK(status IN ('erzeugt','uebergeben','angenommen','abgewiesen','empfangen')),
  fehlertext TEXT,
  ersetzt_durch TEXT,
  erzeugt_von TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(schluessel_id) REFERENCES emaw_schluessel(id) ON DELETE CASCADE,
  FOREIGN KEY(ersetzt_durch) REFERENCES emaw_ereignisse(id),
  FOREIGN KEY(erzeugt_von) REFERENCES users(id),
  UNIQUE(tenant_id,ereignis_id)
);
CREATE INDEX IF NOT EXISTS idx_emaw_ereignisse_offen ON emaw_ereignisse(tenant_id,status,art,created_at);

CREATE TABLE IF NOT EXISTS emaw_archive (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  dateiname TEXT NOT NULL,
  anzahl INTEGER NOT NULL CHECK(anzahl>0),
  bytes INTEGER NOT NULL CHECK(bytes>0),
  pruefsumme TEXT NOT NULL,
  ablage_schluessel TEXT,
  status TEXT NOT NULL DEFAULT 'gebaut' CHECK(status IN ('gebaut','uebergeben','quittiert','abgewiesen')),
  quittung_dateiname TEXT,
  quittung_text TEXT,
  gebaut_von TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(gebaut_von) REFERENCES users(id),
  UNIQUE(tenant_id,dateiname)
);
CREATE INDEX IF NOT EXISTS idx_emaw_archive_tenant ON emaw_archive(tenant_id,status,created_at);

PRAGMA foreign_keys = ON;

-- Leistung durch Bauart, nicht durch Hoffnung (Zusatzforderung "Performance-by-Design fuer KI").
--
-- Drei Befunde standen am Anfang:
--
-- 1. KEINE EINSTUFUNG. Jede KI-Funktion lief sofort und im Vordergrund. Die Entwurfsfabrik rief
--    bis zu fuenf Modelle NACHEINANDER auf, waehrend ein Mensch vor dem Ladebalken sass - bei
--    zwanzig Sekunden Zeitlimit je Aufruf sind das bis zu eineinhalb Minuten Warten auf eine
--    Antwort, die auch in der Mappe haette landen koennen.
-- 2. KEINE WIEDERVERWENDUNG. Der Eingabehash wurde protokolliert, aber nie nachgeschlagen.
--    Dieselbe Zusammenfassung desselben Lernfelds wurde beim zehnten Mal zum zehnten Mal
--    bezahlt - und lieferte ein anderes Ergebnis als beim ersten.
-- 3. DIE DATENKLASSE KAM VOM AUFRUFER. Wer 'oeffentlich' hineinschrieb, bekam ein Modell in den
--    USA, auch wenn im Auftrag Namen standen. Die Entscheidung, wie heikel eine Eingabe ist,
--    gehoert nicht an die Stelle, die sie absendet.
--
-- Diese beiden Tabellen sind die Antwort auf 1 und 2; die Antwort auf 3 ist das Zweckregister im
-- Quelltext, das fail closed ist und die Klasse vorgibt.

-- Ergebnisse, die wiederverwendet werden duerfen.
--
-- Der Schluessel ist (Mandant, Zweck, Eingabehash): dieselbe Frage zur selben Grundlage. Die
-- Fassung zaehlt hoch, statt zu ueberschreiben - ein spaeteres Modell antwortet anders, und wer
-- einen Zeugnistext von vor einem Jahr nachweisen muss, braucht den von damals und nicht den von
-- heute. Wiederverwendet wird immer die neueste GUELTIGE Fassung.
CREATE TABLE IF NOT EXISTS ai_results (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  zweck TEXT NOT NULL,
  eingabe_hash TEXT NOT NULL,
  fassung INTEGER NOT NULL DEFAULT 1,
  text TEXT NOT NULL,
  anbieter TEXT NOT NULL,
  modell TEXT NOT NULL,
  invocation_id TEXT,
  kosten_cent INTEGER NOT NULL DEFAULT 0,
  -- Wie oft dieses Ergebnis einen bezahlten Aufruf erspart hat. Die Zahl ist der Nachweis, dass
  -- die Wiederverwendung wirkt - und die Grundlage, sie fuer einen Zweck wieder abzuschalten.
  treffer INTEGER NOT NULL DEFAULT 0,
  letzter_treffer TEXT,
  erzeugt_am TEXT NOT NULL,
  -- NULL heisst: altert nicht. Das ist die Ausnahme und steht im Register mit Begruendung.
  gueltig_bis TEXT,
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(invocation_id) REFERENCES ai_invocations(id) ON DELETE SET NULL,
  UNIQUE(tenant_id, zweck, eingabe_hash, fassung)
);

-- Der Nachschlag beim Aufruf: eine Abfrage, ein Index, keine Sortierung ueber die ganze Tabelle.
CREATE INDEX IF NOT EXISTS idx_ai_results_suche ON ai_results(tenant_id,zweck,eingabe_hash,fassung DESC);

-- Langlaufende Erzeugung: Auftrag statt Wartezimmer.
--
-- Der Auftrag traegt seinen Fortschritt, seine Versuche und seinen Fehler bei sich. Das ist der
-- Unterschied zwischen "der Balken haengt" und "Versuch 2 von 3, zuletzt Zeitueberschreitung beim
-- Anbieter": das Erste ist fuer niemanden zu gebrauchen, das Zweite beantwortet die Frage, ob man
-- warten oder abbrechen soll.
CREATE TABLE IF NOT EXISTS ai_jobs (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  zweck TEXT NOT NULL,
  eingabe TEXT NOT NULL,
  eingabe_hash TEXT NOT NULL,
  -- Woran das Ergebnis haengt, damit der Auftrag es selbst ablegen kann.
  ziel_typ TEXT,
  ziel_id TEXT,
  status TEXT NOT NULL DEFAULT 'offen' CHECK (status IN ('offen','laeuft','fertig','fehler','abgebrochen')),
  fortschritt INTEGER NOT NULL DEFAULT 0 CHECK (fortschritt BETWEEN 0 AND 100),
  schritt TEXT,
  teile INTEGER NOT NULL DEFAULT 1 CHECK (teile BETWEEN 1 AND 20),
  fertige_teile INTEGER NOT NULL DEFAULT 0,
  versuche INTEGER NOT NULL DEFAULT 0,
  max_versuche INTEGER NOT NULL DEFAULT 3 CHECK (max_versuche BETWEEN 1 AND 10),
  letzter_fehler TEXT,
  ergebnis_json TEXT,
  wiederverwendet INTEGER NOT NULL DEFAULT 0,
  angefordert_von TEXT NOT NULL,
  -- Wann der Auftrag zuletzt ein Lebenszeichen gegeben hat. Ein Auftrag, der in 'laeuft' haengen
  -- bleibt, weil der Aufruf mitten im Lauf abgebrochen ist, wird daran wiedererkannt und neu
  -- aufgenommen - sonst waere ein abgestuerzter Lauf ein Auftrag, der nie wieder anlaeuft.
  puls_am TEXT,
  benachrichtigt_am TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  gestartet_am TEXT,
  fertig_am TEXT,
  CHECK(status <> 'fertig' OR ergebnis_json IS NOT NULL),
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(angefordert_von) REFERENCES users(id)
);

-- Die Warteschlange des Laufs: aelteste offene zuerst, ohne die fertigen zu lesen.
CREATE INDEX IF NOT EXISTS idx_ai_jobs_warteschlange ON ai_jobs(status,created_at);
CREATE INDEX IF NOT EXISTS idx_ai_jobs_mandant ON ai_jobs(tenant_id,created_at DESC);

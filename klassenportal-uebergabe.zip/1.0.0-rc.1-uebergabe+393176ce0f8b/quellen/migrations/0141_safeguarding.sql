-- Kinderschutz: Meldeweg, enge Sichtbarkeit, Eskalation mit Frist (Master-Spec V2, Block Recht).
--
-- Der Fall, den kein anderes Modul traegt: eine Lehrkraft bemerkt blaue Flecken, ein Teilnehmer
-- erzaehlt von Gewalt zu Hause, jemand aeussert Selbstgefaehrdung. Heute bleibt dafuer nur die
-- gewoehnliche Notiz oder eine Mail - und beides ist falsch:
--
--  - Die Notiz sieht jeder, der Verwaltungsrechte hat. Bei einer Meldung, die sich gegen eine
--    Person aus genau dieser Verwaltung richtet, ist das der Grund, warum niemand meldet.
--  - Die Mail hat keine Frist. Ein Verdacht, der vier Wochen in einem Postfach liegt, ist im
--    Ergebnis dasselbe wie kein Verdacht.
--
-- Deshalb hier: benannte Kinderschutzfachkraefte statt Rollenrecht, Einsicht nur fuer sie,
-- Ausschluss bei Befangenheit, und eine Frist, die laeuft, ob jemand hinsieht oder nicht.

-- Wer ueberhaupt hineinsehen darf. Bewusst NICHT an die Rolle tenant_admin gebunden: Einsicht ist
-- eine Benennung, kein Nebenprodukt von Verwaltungsrechten.
CREATE TABLE IF NOT EXISTS safeguarding_officers (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rolle TEXT NOT NULL DEFAULT 'fachkraft' CHECK (rolle IN ('fachkraft','stellvertretung','externe_stelle')),
  benannt_von TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  benannt_am TEXT NOT NULL,
  aktiv INTEGER NOT NULL DEFAULT 1 CHECK (aktiv IN (0,1)),
  beendet_am TEXT,
  updated_at TEXT NOT NULL,
  UNIQUE(tenant_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_safeguarding_officers_aktiv ON safeguarding_officers(tenant_id, aktiv);

CREATE TABLE IF NOT EXISTS safeguarding_reports (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  -- Um wen es geht. Darf fehlen: eine Beobachtung ohne sichere Zuordnung ist trotzdem zu melden.
  betroffene_person TEXT REFERENCES users(id) ON DELETE SET NULL,
  gemeldet_von TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kategorie TEXT NOT NULL CHECK (kategorie IN ('vernachlaessigung','koerperliche_gewalt','sexualisierte_gewalt','selbstgefaehrdung','mobbing','sonstiges')),
  -- 'akut' heisst: heute. Die Frist unten richtet sich danach.
  dringlichkeit TEXT NOT NULL DEFAULT 'normal' CHECK (dringlichkeit IN ('akut','hoch','normal')),
  sachverhalt TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'offen' CHECK (status IN ('offen','in_bearbeitung','eskaliert','abgeschlossen')),
  zugewiesen_an TEXT REFERENCES users(id) ON DELETE SET NULL,
  frist_am TEXT NOT NULL,
  eskaliert_an TEXT,
  eskaliert_am TEXT,
  eskalationsgrund TEXT,
  abgeschlossen_am TEXT,
  ergebnis TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_safeguarding_reports_offen ON safeguarding_reports(tenant_id, status, frist_am);
CREATE INDEX IF NOT EXISTS idx_safeguarding_reports_person ON safeguarding_reports(tenant_id, betroffene_person);

-- Der Verlauf. Nur anhaengen: eine Kinderschutzakte, aus der sich Eintraege entfernen lassen, ist
-- im Ernstfall wertlos - und der Ernstfall ist hier eine Anhoerung oder ein Gericht.
CREATE TABLE IF NOT EXISTS safeguarding_notes (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  report_id TEXT NOT NULL REFERENCES safeguarding_reports(id) ON DELETE CASCADE,
  verfasst_von TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  art TEXT NOT NULL DEFAULT 'notiz' CHECK (art IN ('notiz','gespraech','massnahme','statuswechsel','eskalation')),
  text TEXT NOT NULL,
  erfasst_am TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_safeguarding_notes_fall ON safeguarding_notes(report_id, erfasst_am);

CREATE TRIGGER IF NOT EXISTS trg_safeguarding_notes_kein_update
BEFORE UPDATE ON safeguarding_notes
BEGIN SELECT RAISE(ABORT,'SAFEGUARDING_VERLAUF_UNVERAENDERLICH'); END;
CREATE TRIGGER IF NOT EXISTS trg_safeguarding_notes_kein_delete
BEFORE DELETE ON safeguarding_notes
WHEN (SELECT COUNT(*) FROM safeguarding_reports WHERE id = OLD.report_id) > 0
BEGIN SELECT RAISE(ABORT,'SAFEGUARDING_VERLAUF_UNVERAENDERLICH'); END;

-- Medienbibliothek mit Rechteverwaltung (K8), Video/Audio in Aufgaben und Pruefungen (K9),
-- Untertitel, Transkript und Audiodeskription (K10).
--
-- Bisher lagen Bilder und Videos dort, wo sie jemand hochgeladen hat - im Aufgabenanhang, im
-- Kursmaterial, im Anschreiben. Drei Dinge folgten daraus, und jedes ist teuer:
--
--  - Niemand wusste, unter welcher Lizenz ein Bild stand. Bei einer Abmahnung ist "das hat
--    jemand mal hochgeladen" keine Auskunft. Und eine befristete Lizenz lief ab, ohne dass
--    irgendwo stand, WO das Bild ueberall verwendet wird.
--  - Video und Audio waren in Aufgaben gar nicht vorgesehen.
--  - Untertitel fehlten. Ein Lernvideo ohne Untertitel ist fuer gehoerlose Teilnehmende kein
--    Lernvideo, und fuer einen oeffentlich gefoerderten Traeger ist es ein Verstoss gegen die
--    Barrierefreiheit, den die naechste Pruefung findet.
--
-- Der INHALT liegt in R2, nicht in D1. D1 hat eine harte Grenze von 10 GB; ein einziges
-- Schulungsvideo waere ein Prozent davon.

CREATE TABLE IF NOT EXISTS media_assets (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  -- Der Schluessel in R2. In D1 steht nur, WO die Datei liegt - nie die Datei.
  r2_key TEXT NOT NULL,
  dateiname TEXT NOT NULL,
  content_type TEXT NOT NULL,
  groesse_bytes INTEGER NOT NULL CHECK (groesse_bytes > 0),
  sha256 TEXT NOT NULL,
  art TEXT NOT NULL CHECK (art IN ('bild','video','audio','dokument')),
  dauer_sekunden INTEGER,
  titel TEXT NOT NULL,
  beschreibung TEXT,
  -- Die Lizenz ist Pflicht. 'unklar' ist erlaubt, aber ein Medium mit unklarer Lizenz darf nicht
  -- verwendet werden - es liegt in der Bibliothek, bis jemand die Herkunft geklaert hat.
  lizenz TEXT NOT NULL CHECK (lizenz IN ('eigenes_werk','cc0','cc_by','cc_by_sa','cc_by_nc','gemeinfrei','lizenziert','unklar')),
  urheber TEXT,
  lizenz_quelle TEXT,
  -- Befristete Lizenzen sind der Regelfall bei eingekauftem Material. Ohne dieses Datum faellt
  -- der Ablauf erst auf, wenn die Rechnung des Anwalts kommt.
  lizenz_bis TEXT,
  -- Wofuer das Medium verwendet werden darf, als Liste: 'unterricht', 'oeffentlich', 'druck'.
  -- Ein Bild, das nur im Unterricht erlaubt ist, gehoert nicht auf die Anmeldeseite.
  verwendung_json TEXT NOT NULL DEFAULT '["unterricht"]',
  status TEXT NOT NULL DEFAULT 'aktiv' CHECK (status IN ('aktiv','gesperrt','abgelaufen')),
  hochgeladen_von TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(hochgeladen_von) REFERENCES users(id),
  UNIQUE(tenant_id, sha256)
);
CREATE INDEX IF NOT EXISTS idx_media_assets_art ON media_assets(tenant_id, art, status);
CREATE INDEX IF NOT EXISTS idx_media_assets_lizenz ON media_assets(tenant_id, lizenz_bis);

-- Wo ein Medium verwendet wird. Ohne diese Tabelle ist eine ablaufende Lizenz eine Warnung ohne
-- Handlungsanweisung: man weiss, dass etwas ersetzt werden muss, aber nicht wo.
CREATE TABLE IF NOT EXISTS media_usages (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  asset_id TEXT NOT NULL,
  objekt_typ TEXT NOT NULL CHECK (objekt_typ IN ('aufgabe','quiz_frage','kursmaterial','nachricht','seite','zeugnisvorlage')),
  objekt_id TEXT NOT NULL,
  feld TEXT,
  -- Wofuer es hier verwendet wird - muss in der Lizenz gedeckt sein.
  zweck TEXT NOT NULL DEFAULT 'unterricht' CHECK (zweck IN ('unterricht','oeffentlich','druck')),
  eingebunden_von TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(asset_id) REFERENCES media_assets(id) ON DELETE RESTRICT,
  UNIQUE(asset_id, objekt_typ, objekt_id, feld)
);
CREATE INDEX IF NOT EXISTS idx_media_usages_objekt ON media_usages(tenant_id, objekt_typ, objekt_id);

-- Untertitel, Transkript, Audiodeskription. Getrennt vom Medium, weil es mehrere Sprachen gibt
-- und weil eine KI-erzeugte Spur etwas anderes ist als eine gepruefte.
CREATE TABLE IF NOT EXISTS media_tracks (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  asset_id TEXT NOT NULL,
  art TEXT NOT NULL CHECK (art IN ('untertitel','transkript','audiodeskription','uebersetzung')),
  sprache TEXT NOT NULL,
  -- Kurze Spuren stehen hier, lange liegen in R2. Ein Transkript von 90 Minuten hat nichts in
  -- D1 zu suchen.
  inhalt TEXT,
  r2_key TEXT,
  quelle TEXT NOT NULL DEFAULT 'manuell' CHECK (quelle IN ('manuell','ki','import')),
  -- Eine KI-erzeugte Spur zaehlt erst als barrierefrei, wenn ein Mensch sie geprueft hat. Eine
  -- automatische Untertitelung mit Fehlern ist fuer die betroffene Person schlimmer als keine:
  -- sie sieht aus wie ein Angebot und ist keines.
  geprueft_von TEXT,
  geprueft_am TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK (inhalt IS NOT NULL OR r2_key IS NOT NULL),
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(asset_id) REFERENCES media_assets(id) ON DELETE CASCADE,
  UNIQUE(asset_id, art, sprache)
);
CREATE INDEX IF NOT EXISTS idx_media_tracks_asset ON media_tracks(tenant_id, asset_id, art);

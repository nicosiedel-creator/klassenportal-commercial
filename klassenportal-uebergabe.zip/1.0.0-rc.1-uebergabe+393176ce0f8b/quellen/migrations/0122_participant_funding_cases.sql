-- Foerderfaelle der Teilnehmenden.
--
-- Ein Bildungstraeger lebt davon, dass jemand anderes die Massnahme bezahlt: Agentur fuer Arbeit,
-- Jobcenter, Rentenversicherung, Berufsgenossenschaft, ein Betrieb oder die Person selbst. Jeder
-- dieser Kostentraeger will wissen, wer wann eingetreten ist, wer noch da ist, wer gefehlt hat und
-- wer vorzeitig gegangen ist - und zwar monatlich.
--
-- Das Portal wusste davon bisher nichts. Es kannte Mitgliedschaften in Kursen, aber keinen
-- Foerderfall: kein Kostentraeger, keine Zuweisungs- oder Gutscheinnummer, kein Eintritts- und
-- kein Austrittsdatum, keinen Austrittsgrund. Damit war jede Meldung an einen Kostentraeger
-- Handarbeit in einer Tabellenkalkulation - genau die Arbeit, die dieses Portal abnehmen soll.
--
-- Bewusst getrennt von memberships: eine Person kann denselben Kurs in zwei Foerderfaellen
-- durchlaufen (Abbruch und Wiedereinstieg), und ein Foerderfall ueberlebt das Ende der
-- Mitgliedschaft, weil er belegt werden muss.
CREATE TABLE IF NOT EXISTS participant_funding_cases (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  course_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  -- Wer zahlt. 'selbstzahler' ist ausdruecklich dabei: auch dann gibt es Eintritt und Austritt,
  -- und die Rechnung haengt daran.
  cost_bearer TEXT NOT NULL CHECK(cost_bearer IN ('agentur_fuer_arbeit','jobcenter','rentenversicherung','berufsgenossenschaft','betrieb','land','selbstzahler','sonstige')),
  cost_bearer_name TEXT,
  -- Die Nummern, unter denen der Kostentraeger den Fall fuehrt. Ohne sie ist keine Meldung
  -- zuordenbar; sie sind aber nicht bei jedem Traeger vorhanden, deshalb optional.
  case_number TEXT,
  voucher_number TEXT,
  measure_number TEXT,
  entered_on TEXT NOT NULL,
  planned_exit_on TEXT,
  exited_on TEXT,
  exit_reason TEXT CHECK(exit_reason IS NULL OR exit_reason IN ('regulaer','abbruch_teilnehmer','abbruch_traeger','arbeitsaufnahme','krankheit','umzug','sonstige')),
  exit_note TEXT,
  status TEXT NOT NULL DEFAULT 'aktiv' CHECK(status IN ('aktiv','beendet','abgebrochen')),
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(created_by) REFERENCES users(id),
  CHECK(planned_exit_on IS NULL OR planned_exit_on>=entered_on),
  CHECK(exited_on IS NULL OR exited_on>=entered_on),
  -- Ein beendeter Fall ohne Austrittsdatum waere eine Meldung ohne Aussage.
  CHECK(status='aktiv' OR exited_on IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS idx_funding_cases_course ON participant_funding_cases(tenant_id,course_id,status);
CREATE INDEX IF NOT EXISTS idx_funding_cases_user ON participant_funding_cases(tenant_id,user_id);
CREATE INDEX IF NOT EXISTS idx_funding_cases_bearer ON participant_funding_cases(tenant_id,cost_bearer,status);
-- Zwei gleichzeitig offene Faelle derselben Person im selben Kurs waeren doppelte Abrechnung.
CREATE UNIQUE INDEX IF NOT EXISTS idx_funding_cases_offen ON participant_funding_cases(tenant_id,course_id,user_id) WHERE status='aktiv';

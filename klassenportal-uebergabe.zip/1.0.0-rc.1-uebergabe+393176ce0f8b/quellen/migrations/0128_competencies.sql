-- Kompetenzen (Master-Spec V2 §2.6, §7 Beziehungskette).
--
-- Bis hierher fuehrte curriculum_items Lernziele als Text. Ein Text laesst sich nicht auswerten:
-- die Frage "kann diese Person das" war im System nicht beantwortbar, nur "war sie anwesend" und
-- "wie viele Punkte hat sie". Fuer einen Traeger, der Umschulungen abschliesst, ist genau das die
-- Frage, die Kostentraeger und Kammer stellen.
--
-- Die Kompetenz ist deshalb eine eigene Sache, die sich durch die Kette zieht: Lehrplanposition ->
-- Aufgabe/Frage -> Bewertung. Der Stand wird NICHT gespeichert, sondern aus den Nachweisen
-- abgeleitet - eine gespeicherte Kennzahl waere am Tag nach der ersten Nachkorrektur falsch.
CREATE TABLE IF NOT EXISTS competencies (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  -- Eine Kompetenz kann zu einem Rahmenlehrplan gehoeren oder traegerweit gelten.
  framework_id TEXT,
  parent_id TEXT,
  code TEXT NOT NULL,
  title TEXT NOT NULL,
  beschreibung TEXT,
  -- Deutscher Qualifikationsrahmen, Stufe 1-8. Das ist die Sprache, in der Kammer und
  -- Kostentraeger ueber Abschluesse reden; ohne sie ist eine Kompetenzliste hausgemacht.
  dqr_niveau INTEGER CHECK(dqr_niveau IS NULL OR dqr_niveau BETWEEN 1 AND 8),
  art TEXT NOT NULL DEFAULT 'fachkompetenz' CHECK(art IN ('fachkompetenz','methodenkompetenz','sozialkompetenz','selbstkompetenz')),
  status TEXT NOT NULL DEFAULT 'aktiv' CHECK(status IN ('aktiv','archiviert')),
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(tenant_id,code),
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(framework_id) REFERENCES curriculum_frameworks(id) ON DELETE SET NULL,
  FOREIGN KEY(parent_id) REFERENCES competencies(id) ON DELETE SET NULL,
  FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_competencies_mandant ON competencies(tenant_id,status,sort_order);

-- Die Kette selbst: woran haengt diese Kompetenz. Eine Zeile je Verbindung, damit dieselbe
-- Kompetenz an mehreren Stellen nachgewiesen werden kann - genau das macht sie belastbar.
CREATE TABLE IF NOT EXISTS competency_links (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  competency_id TEXT NOT NULL,
  gegenstand TEXT NOT NULL CHECK(gegenstand IN ('curriculum_item','gradebook_item','quiz','rubric_criterion')),
  bezug_id TEXT NOT NULL,
  -- Wie stark dieser Nachweis zaehlt. Eine Abschlusspruefung wiegt mehr als eine Uebung.
  gewicht REAL NOT NULL DEFAULT 1 CHECK(gewicht > 0),
  verknuepft_von TEXT NOT NULL,
  verknuepft_am TEXT NOT NULL,
  UNIQUE(tenant_id,competency_id,gegenstand,bezug_id),
  FOREIGN KEY(tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY(competency_id) REFERENCES competencies(id) ON DELETE CASCADE,
  FOREIGN KEY(verknuepft_von) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_competency_links_bezug ON competency_links(tenant_id,gegenstand,bezug_id);

-- Ab wann eine Kompetenz als erreicht gilt. Gehoert in die Pruefungsordnung des Traegers, nicht in
-- den Quelltext; 60 Prozent als Vorgabe, weil die meisten Ordnungen dort die Bestehensgrenze haben.
ALTER TABLE tenant_settings ADD COLUMN kompetenz_schwelle_prozent INTEGER NOT NULL DEFAULT 60 CHECK(kompetenz_schwelle_prozent BETWEEN 1 AND 100);

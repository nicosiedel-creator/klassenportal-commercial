// Elektronische Maßnahmeabwicklung (eM@w).
//
// Die Oberfläche macht drei Dinge sichtbar, die sonst erst in der Quittung auffallen:
// welche Anmeldung der BA noch keiner Person zugeordnet ist, welches Ereignis noch nicht
// versendet wurde, und welches abgewiesen wurde — samt Grund.
const EW=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const EW_STATUS={erzeugt:'noch nicht im Archiv',uebergeben:'im Archiv, Quittung offen',
  angenommen:'angenommen',abgewiesen:'abgewiesen',empfangen:'von der BA'};
async function ewApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const ewText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;

function ewModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="ew-titel" style="width:min(1080px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="ew-titel" style="margin:0">${EW(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="ew-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#ew-body'),zu};
}

async function ewMappe(tenantId){
  const {body}=ewModal('Elektronische Maßnahmeabwicklung (eM@w)');
  const melde=t=>{const p=body.querySelector('#ew-err');if(p)p.textContent=t;};
  async function render(){
    let d,personen=[],kurse=[];
    try{d=await ewApi(`/api/emaw?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${EW(ewText(e.message))}</div>`;return;}
    try{personen=(await ewApi(`/api/tenant/users?tenant_id=${encodeURIComponent(tenantId)}`)).users||[];}catch{}
    try{kurse=(await ewApi(`/api/courses?tenant_id=${encodeURIComponent(tenantId)}`)).courses||[];}catch{}

    const zuordnung=(d.schluessel||[]).map(s=>{
      const offen=!s.user_id||!s.course_id;
      return `<tr><th scope="row">${EW(s.kundennummer)}</th><td>${EW(s.kunde_vorname)} ${EW(s.kunde_name)}</td>`
        +`<td>${EW(s.massnahme_bezeichnung)}</td><td>${EW(s.kurs||'')}</td>`
        +`<td>${offen?'<span class="tag bad">nicht zugeordnet</span>':'<span class="tag good">zugeordnet</span>'}</td>`
        +`<td class="toolbar" style="gap:.25rem;flex-wrap:wrap">`
        +`<button class="btn secondary" type="button" data-zuordnen="${EW(s.id)}">Zuordnen</button>`
        +(offen?'':`<button class="btn secondary" type="button" data-eintritt="${EW(s.id)}">Eintritt</button>`
          +`<button class="btn secondary" type="button" data-anwesenheit="${EW(s.id)}">Anwesenheit</button>`
          +`<button class="btn secondary" type="button" data-austritt="${EW(s.id)}">Austritt</button>`)
        +`</td></tr>`;
    }).join('')||'<tr><td colspan="6">Noch keine Anmeldung der BA eingelesen.</td></tr>';

    const ereignisse=(d.ereignisse||[]).slice(0,60).map(e=>`<tr><th scope="row">${EW(e.art)}</th>`
      +`<td>${EW(String(e.created_at||'').slice(0,10))}</td><td>${EW(EW_STATUS[e.status]||e.status)}</td>`
      +`<td>${EW(e.fehlertext||'')}</td></tr>`).join('')||'<tr><td colspan="4">Noch nichts erzeugt.</td></tr>';

    const archive=(d.archive||[]).map(x=>`<tr><th scope="row">${EW(x.dateiname)}</th><td>${EW(x.anzahl)}</td>`
      +`<td>${EW(x.status)}</td><td>${EW(String(x.created_at||'').slice(0,10))}</td></tr>`).join('')
      ||'<tr><td colspan="4">Noch kein Archiv gebaut.</td></tr>';

    const hinweis=d.ohne_zuordnung
      ? `<div class="notice bad"><strong>${EW(d.ohne_zuordnung)} Anmeldung(en) ohne Zuordnung.</strong> Für sie lässt sich nichts melden — und das fällt sonst erst auf, wenn die Meldung fehlt.</div>`
      : '<div class="notice good">Jede Anmeldung der BA ist einer Person und einem Kurs zugeordnet.</div>';

    body.innerHTML=hinweis
      +`<div class="notice">Provider: <strong>${EW(d.provider?.providername||'— nicht gesetzt —')}</strong>. `
      +`Der Name wird von der BA mit dem Zugriffszertifikat vergeben und steht in jedem Dateinamen.</div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Anmeldungen der BA</caption><thead><tr>`
      +`<th scope="col">Kundennummer</th><th scope="col">Teilnehmer</th><th scope="col">Maßnahme</th>`
      +`<th scope="col">Kurs</th><th scope="col">Stand</th><th scope="col">Nächster Schritt</th></tr></thead>`
      +`<tbody>${zuordnung}</tbody></table></div>`
      +`<div class="toolbar"><button class="btn" type="button" id="ew-archiv">Archiv bauen und herunterladen</button>`
      +`<button class="btn secondary" type="button" id="ew-eingang">Datei der BA einlesen</button>`
      +`<button class="btn secondary" type="button" id="ew-quittung">Quittung einlesen</button></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Ereignisse an die BA</caption><thead><tr>`
      +`<th scope="col">Ereignis</th><th scope="col">Erzeugt</th><th scope="col">Stand</th><th scope="col">Meldung der BA</th>`
      +`</tr></thead><tbody>${ereignisse}</tbody></table></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Archive</caption><thead><tr><th scope="col">Datei</th>`
      +`<th scope="col">Ereignisse</th><th scope="col">Stand</th><th scope="col">Gebaut</th></tr></thead><tbody>${archive}</tbody></table></div>`
      +`<form id="ew-provider"><h4>Provider setzen</h4>`
      +`<label class="field">Providername (Kleinbuchstaben, von der BA vergeben)<input name="providername" required></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Speichern</button></div></form>`
      +`<p class="error" id="ew-err" role="alert"></p>`;

    const post=async(pfad,daten)=>{await ewApi(`/api/${pfad}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(daten)});await render();};
    const fehler=e=>melde(ewText(e.message));

    body.querySelector('#ew-provider').onsubmit=async e=>{e.preventDefault();
      const f=new FormData(e.target);
      try{await post('emaw/provider',{providername:f.get('providername')});}catch(err){fehler(err);}};

    const dateiLesen=async()=>new Promise(r=>{
      const i=document.createElement('input');i.type='file';i.accept='.xml,text/xml';
      i.onchange=async()=>{const f=i.files?.[0];r(f?await f.text():null);};i.click();});

    body.querySelector('#ew-eingang').onclick=async()=>{
      const xml=await dateiLesen();if(!xml)return;
      try{const r=await ewApi(`/api/emaw/inbox?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({xml})});
        melde(r.anmeldung?`Anmeldung „${r.art}" übernommen.`:`Ereignis „${r.art}" festgehalten.`);await render();}
      catch(err){fehler(err);}};
    body.querySelector('#ew-quittung').onclick=async()=>{
      const xml=await dateiLesen();if(!xml)return;
      try{const r=await ewApi(`/api/emaw/receipt?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({xml})});
        melde(`Quittung verarbeitet: ${r.angenommen} angenommen, ${r.abgewiesen} abgewiesen.`);await render();}
      catch(err){fehler(err);}};
    body.querySelector('#ew-archiv').onclick=async()=>{
      try{
        const antwort=await fetch(`/api/emaw/archive?tenant_id=${encodeURIComponent(tenantId)}`,
          {method:'POST',credentials:'same-origin'});
        if(!antwort.ok){let d={};try{d=await antwort.json();}catch{}throw new Error(d.error||`HTTP_${antwort.status}`);}
        const name=(antwort.headers.get('content-disposition')||'').match(/filename="([^"]+)"/)?.[1]||'emaw.zip';
        const blob=await antwort.blob(),url=URL.createObjectURL(blob);
        const a=document.createElement('a');a.href=url;a.download=name;a.click();URL.revokeObjectURL(url);
        melde(`${name} heruntergeladen — hochladen nach https://emaw.arbeitsagentur.de/in/`);
        await render();
      }catch(err){fehler(err);}};

    body.querySelectorAll('[data-zuordnen]').forEach(b=>b.onclick=()=>ewZuordnen(tenantId,b.dataset.zuordnen,personen,kurse,render));
    body.querySelectorAll('[data-eintritt]').forEach(b=>b.onclick=async()=>{
      const beginn=prompt('Tatsächlicher Eintritt (JJJJ-MM-TT)');if(!beginn)return;
      try{await post('emaw/events/entry',{schluessel_id:b.dataset.eintritt,beginn});}catch(err){fehler(err);}});
    body.querySelectorAll('[data-anwesenheit]').forEach(b=>b.onclick=async()=>{
      const m=prompt('Welcher Monat? (JJJJ-MM)');if(!m)return;
      const [jahr,monat]=m.split('-');
      try{await post('emaw/events/attendance',{schluessel_id:b.dataset.anwesenheit,jahr:Number(jahr),monat:Number(monat)});}
      catch(err){fehler(err);}});
    body.querySelectorAll('[data-austritt]').forEach(b=>b.onclick=()=>ewAustritt(tenantId,b.dataset.austritt,render));
  }
  await render();
}

function ewZuordnen(tenantId,schluesselId,personen,kurse,danach){
  const {body,zu}=ewModal('Anmeldung zuordnen');
  body.innerHTML=`<p>Die Schlüsseldaten kommen von der BA. Hier wird nur festgelegt, welche Person und welcher Kurs im Portal dazu gehören.</p>`
    +`<form id="ew-zu">`
    +`<label class="field">Person<select name="user_id" required>${personen.map(p=>`<option value="${EW(p.user_id||p.id)}">${EW(p.display_name||p.email)}</option>`).join('')}</select></label>`
    +`<label class="field">Kurs<select name="course_id" required>${kurse.map(k=>`<option value="${EW(k.id)}">${EW(k.name)}</option>`).join('')}</select></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Zuordnen</button></div></form><p class="error" id="ew-zerr" role="alert"></p>`;
  body.querySelector('#ew-zu').onsubmit=async e=>{
    e.preventDefault();const f=new FormData(e.target);
    try{await ewApi(`/api/emaw/assign?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
      body:JSON.stringify({schluessel_id:schluesselId,user_id:f.get('user_id'),course_id:f.get('course_id')})});
      zu();await danach();}
    catch(err){body.querySelector('#ew-zerr').textContent=ewText(err.message);}};
}

async function ewAustritt(tenantId,schluesselId,danach){
  const {body,zu}=ewModal('Austritt melden');
  let arten=[],verbleibe=[];
  try{const d=await ewApi(`/api/emaw?tenant_id=${encodeURIComponent(tenantId)}`);arten=d.sendbare_arten||[];}catch{}
  // Die Wertelisten stammen aus dem Schema der BA und stehen im Modul; hier werden die
  // gebräuchlichsten angeboten, der Rest ist frei einzutragen.
  const beendigung=['regulaer','vorzeitig - Arbeit','vorzeitig - Ausbildung betrieblich',
    'vorzeitig - gesundheitl. Beeintraechtigungen','vorzeitig - vertragswidriges Verhalten',
    'vorzeitig - fehlende Motivation/ Mitwirkung','vorzeitig - persoenliche Gruende (z.B. Umzug, Mutterschutz)'];
  verbleibe=['Arbeit - versicherungspflichtig - unbefristet','Arbeit - versicherungspflichtig - befristet',
    'Arbeitslosigkeit','Selbstaendigkeit','Studium','Arbeitsunfaehigkeit','unbekannter Verbleib'];
  body.innerHTML=`<form id="ew-aus">`
    +`<label class="field">Letzter Tag<input name="letztertag" type="date" required></label>`
    +`<label><input type="checkbox" name="zielerreicht"> Maßnahmeziel erreicht</label>`
    +`<label class="field">Beendigung<select name="beendigung">${beendigung.map(x=>`<option value="${EW(x)}">${EW(x)}</option>`).join('')}</select></label>`
    +`<label class="field">Verbleib<select name="verbleib">${verbleibe.map(x=>`<option value="${EW(x)}">${EW(x)}</option>`).join('')}</select></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Austritt erzeugen</button></div></form><p class="error" id="ew-aerr" role="alert"></p>`;
  body.querySelector('#ew-aus').onsubmit=async e=>{
    e.preventDefault();const f=new FormData(e.target);
    try{await ewApi(`/api/emaw/events/exit?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
      body:JSON.stringify({schluessel_id:schluesselId,letztertag:f.get('letztertag'),
        zielerreicht:f.get('zielerreicht')==='on',beendigung:f.get('beendigung'),verbleib:f.get('verbleib')})});
      zu();await danach();}
    catch(err){body.querySelector('#ew-aerr').textContent=ewText(err.message);}};
}

(async()=>{
  let me=null;try{me=(await ewApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const verwaltung=me.isPlatformAdmin||roles.some(x=>x.role==='tenant_admin'||x.role==='class_admin');
  if(!verwaltung)return;
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');if(!seite||document.querySelector('#ew-launch'))return;
    const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');if(!anker)return;
    const b=document.createElement('button');b.id='ew-launch';b.type='button';b.className='nav';
    b.textContent='eM@w (Agentur für Arbeit)';b.onclick=()=>ewMappe(tenantId).catch(e=>alert(ewText(e.message)));
    anker.after(b);
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

// Helpdesk und Wissensbasis — mit kontextbezogener Hilfe.
//
// Der Hilfeknopf kennt den Bereich, in dem er steht: wer auf der Stundenplanseite Hilfe ruft,
// bekommt die Stundenplanartikel und nicht das Inhaltsverzeichnis.
const HK=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const HK_KAT=[['technik','Technik'],['daten','Daten'],['abrechnung','Abrechnung'],['unterricht','Unterricht'],['pruefung','Prüfung'],['zugang','Zugang'],['sonstiges','Sonstiges']];
const HK_DRI=[['kritisch','Kritisch (4 Std.)'],['hoch','Hoch (24 Std.)'],['normal','Normal (3 Tage)'],['niedrig','Niedrig (1 Woche)']];
async function hkApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const hkText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
const hkZeit=v=>{const d=new Date(String(v));return Number.isNaN(d.getTime())?String(v??''):d.toLocaleString('de-DE',{dateStyle:'short',timeStyle:'short'});};
function hkModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="hk-titel" style="width:min(1000px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="hk-titel" style="margin:0">${HK(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="hk-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#hk-body'),zu};
}
// Welcher Bereich gerade offen ist — daran hängt die kontextbezogene Hilfe.
const hkBereich=()=>document.querySelector('.side .nav.active')?.dataset?.v||document.body.dataset.bereich||'allgemein';

async function hkHilfe(tenantId){
  const bereich=hkBereich();
  const {body}=hkModal('Hilfe zu diesem Bereich');
  let d={artikel:[]};try{d=await hkApi(`/api/knowledge/context?tenant_id=${encodeURIComponent(tenantId)}&bereich=${encodeURIComponent(bereich)}`);}catch{}
  const liste=(d.artikel||[]).map(a=>`<li><button class="btn secondary hk-art" type="button" data-slug="${HK(a.slug)}">${HK(a.titel)}</button></li>`).join('')
    ||'<li>Für diesen Bereich ist noch kein Artikel hinterlegt.</li>';
  body.innerHTML=`<p class="muted">Bereich: <strong>${HK(bereich)}</strong></p><ul style="list-style:none;padding:0;display:flex;flex-direction:column;gap:.5rem">${liste}</ul>`
    +`<form id="hk-suche"><label class="field">In der gesamten Wissensbasis suchen<input name="q" required></label><div class="toolbar"><button class="btn" type="submit">Suchen</button></div></form>`
    +`<p class="error" id="hk-err" role="alert"></p><div id="hk-out"></div>`;
  const oeffne=async slug=>{
    try{const a=await hkApi(`/api/knowledge/articles/${encodeURIComponent(slug)}?tenant_id=${encodeURIComponent(tenantId)}`);
      body.querySelector('#hk-out').innerHTML=`<article><h4>${HK(a.artikel.titel)}</h4><p style="white-space:pre-wrap">${HK(a.artikel.inhalt)}</p><p class="muted">Fassung ${HK(String(a.artikel.fassung))}</p></article>`;}
    catch(e){body.querySelector('#hk-err').textContent=hkText(e.message);}
  };
  const binde=()=>body.querySelectorAll('.hk-art').forEach(b=>b.onclick=()=>oeffne(b.dataset.slug));
  binde();
  body.querySelector('#hk-suche').onsubmit=async ev=>{
    ev.preventDefault();body.querySelector('#hk-err').textContent='';
    try{const r=await hkApi(`/api/knowledge/search?tenant_id=${encodeURIComponent(tenantId)}&q=${encodeURIComponent(String(new FormData(ev.target).get('q')))}`);
      body.querySelector('#hk-out').innerHTML=`<ul style="list-style:none;padding:0;display:flex;flex-direction:column;gap:.5rem">`
        +((r.treffer||[]).map(t=>`<li><button class="btn secondary hk-art" type="button" data-slug="${HK(t.slug)}">${HK(t.titel)}</button></li>`).join('')||'<li>Keine Treffer. Wer zwei Begriffe eingibt, bekommt nur Artikel mit beiden.</li>')+`</ul>`;
      binde();}
    catch(e){body.querySelector('#hk-err').textContent=hkText(e.message);}
  };
}

async function hkMeldung(tenantId){
  const {body}=hkModal('Problem melden');
  async function render(){
    let d={tickets:[]};try{d=await hkApi(`/api/personal/helpdesk/tickets?tenant_id=${encodeURIComponent(tenantId)}`);}catch{}
    const zeilen=(d.tickets||[]).map(t=>`<tr><th scope="row">#${HK(String(t.nummer))}</th><td>${HK(t.betreff)}</td><td>${HK(t.status)}</td><td>${HK(hkZeit(t.frist_am))}</td>`
      +`<td><button class="btn secondary hk-auf" type="button" data-id="${HK(t.id)}">Verlauf</button>${t.status==='geloest'?` <button class="btn secondary hk-neu" type="button" data-id="${HK(t.id)}">Wieder öffnen</button>`:''}</td></tr>`).join('')
      ||'<tr><td colspan="5">Sie haben noch nichts gemeldet.</td></tr>';
    body.innerHTML=`<form id="hk-neu-t"><label class="field">Kategorie<select name="kategorie">${HK_KAT.map(([k,t])=>`<option value="${HK(k)}">${HK(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Dringlichkeit<select name="dringlichkeit">${HK_DRI.map(([k,t])=>`<option value="${HK(k)}"${k==='normal'?' selected':''}>${HK(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Betreff<input name="betreff" required></label>`
      +`<label class="field">Was ist passiert?<textarea name="beschreibung" rows="4" required></textarea></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Melden</button></div></form><p class="error" id="hk-terr" role="alert"></p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Meine Meldungen</caption><thead><tr><th scope="col">Nr.</th><th scope="col">Betreff</th><th scope="col">Stand</th><th scope="col">Frist</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div><div id="hk-tout"></div>`;
    body.querySelector('#hk-neu-t').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{const r=await hkApi(`/api/helpdesk/tickets?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        kategorie:String(f.get('kategorie')),dringlichkeit:String(f.get('dringlichkeit')),betreff:String(f.get('betreff')),
        beschreibung:String(f.get('beschreibung')),bereich:hkBereich()})});
        await render();body.querySelector('#hk-tout').innerHTML=`<div class="notice good">Meldung #${HK(String(r.nummer))} angelegt. Antwort bis ${HK(hkZeit(r.frist_am))}.</div>`;}
      catch(e){body.querySelector('#hk-terr').textContent=hkText(e.message);}
    };
    body.querySelectorAll('.hk-auf').forEach(b=>b.onclick=async()=>{
      try{const r=await hkApi(`/api/helpdesk/tickets/${encodeURIComponent(b.dataset.id)}?tenant_id=${encodeURIComponent(tenantId)}`);
        body.querySelector('#hk-tout').innerHTML=`<h4>Verlauf zu #${HK(String(r.ticket.nummer))}</h4><ul>`
          +(r.verlauf||[]).map(v=>`<li>${HK(hkZeit(v.created_at))} — ${HK(v.akteur||'System')}: ${HK(v.text)}</li>`).join('')+`</ul>`
          +`<form id="hk-antw"><label class="field">Antworten<textarea name="text" rows="3" required></textarea></label><div class="toolbar"><button class="btn" type="submit">Senden</button></div></form>`;
        body.querySelector('#hk-antw').onsubmit=async ev=>{
          ev.preventDefault();
          try{await hkApi(`/api/helpdesk/tickets/${encodeURIComponent(b.dataset.id)}/reply?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({text:String(new FormData(ev.target).get('text'))})});b.click();}
          catch(e){body.querySelector('#hk-terr').textContent=hkText(e.message);}
        };}
      catch(e){body.querySelector('#hk-terr').textContent=hkText(e.message);}
    });
    body.querySelectorAll('.hk-neu').forEach(b=>b.onclick=async()=>{
      const grund=prompt('Warum passt die Lösung nicht?');if(!grund)return;
      try{await hkApi(`/api/helpdesk/tickets/${encodeURIComponent(b.dataset.id)}/reopen?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({grund})});await render();}
      catch(e){body.querySelector('#hk-terr').textContent=hkText(e.message);}
    });
  }
  await render();
}

async function hkVerwaltung(tenantId){
  const {body}=hkModal('Helpdesk und Wissensbasis');
  async function render(){
    let d;try{d=await hkApi(`/api/helpdesk/tickets?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${HK(hkText(e.message))}</div>`;return;}
    const k=d.kennzahlen||{};
    const zeilen=(d.offen||[]).map(t=>`<tr><th scope="row">#${HK(String(t.nummer))}</th><td>${HK(t.betreff)}</td><td>${HK(t.kategorie)}</td><td>${HK(t.dringlichkeit)}</td>`
      +`<td>${HK(hkZeit(t.frist_am))}${Number(t.ueberfaellig)?' <strong>überfällig</strong>':''}${Number(t.eskalationsstufe)?` (Stufe ${HK(String(t.eskalationsstufe))})`:''}</td>`
      +`<td>${HK(t.zustaendig||'—')}</td>`
      +`<td><button class="btn secondary hk-zu" type="button" data-id="${HK(t.id)}">Übernehmen</button> <button class="btn hk-loe" type="button" data-id="${HK(t.id)}">Lösen</button></td></tr>`).join('')
      ||'<tr><td colspan="7">Nichts offen.</td></tr>';
    body.innerHTML=`<div class="notice${Number(k.ueberfaellig)?' bad':' good'}">${HK(String(k.offen||0))} offen, ${HK(String(k.ueberfaellig||0))} überfällig, ${HK(String(k.in_frist_geloest||0))} von ${HK(String(k.geloest||0))} in der Frist gelöst.</div>`
      +(Number(k.ohne_artikel)?`<div class="notice">${HK(String(k.ohne_artikel))} gelöste Meldungen ohne Hilfeartikel — dort fehlt ein Artikel in der Wissensbasis.</div>`:'')
      +`<div style="overflow-x:auto"><table class="table"><caption>Offene Meldungen</caption><thead><tr><th scope="col">Nr.</th><th scope="col">Betreff</th><th scope="col">Kategorie</th><th scope="col">Dringlichkeit</th><th scope="col">Frist</th><th scope="col">Zuständig</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<div class="toolbar"><button class="btn secondary" type="button" id="hk-esk">Fristen prüfen und eskalieren</button> <button class="btn secondary" type="button" id="hk-wissen">Wissensbasis</button></div>`
      +`<p class="error" id="hk-verr" role="alert"></p><div id="hk-vout"></div>`;
    const fehler=e=>{body.querySelector('#hk-verr').textContent=hkText(e.message);};
    body.querySelector('#hk-esk').onclick=async()=>{
      try{const r=await hkApi(`/api/helpdesk/escalate?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
        body.querySelector('#hk-vout').textContent=`${r.geprueft} überfällige geprüft, ${r.eskaliert} eskaliert.`;await render();}
      catch(e){fehler(e);}
    };
    body.querySelector('#hk-wissen').onclick=()=>hkWissen(tenantId);
    body.querySelectorAll('.hk-zu').forEach(b=>b.onclick=async()=>{
      const person=prompt('Kennung der zuständigen Person:');if(!person)return;
      try{await hkApi(`/api/helpdesk/tickets/${encodeURIComponent(b.dataset.id)}/assign?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({user_id:person})});await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.hk-loe').forEach(b=>b.onclick=async()=>{
      const loesung=prompt('Wie wurde es gelöst?');if(!loesung)return;
      const artikel=prompt('Kennung des Hilfeartikels, der das beantwortet (leer lassen, wenn keiner passt):')||'';
      try{await hkApi(`/api/helpdesk/tickets/${encodeURIComponent(b.dataset.id)}/resolve?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
        body:JSON.stringify(artikel?{loesung,artikel_id:artikel}:{loesung})});await render();}
      catch(e){fehler(e);}
    });
  }
  await render();
}

async function hkWissen(tenantId){
  const {body}=hkModal('Wissensbasis');
  async function render(){
    let d;try{d=await hkApi(`/api/knowledge/articles?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${HK(hkText(e.message))}</div>`;return;}
    const zeilen=(d.artikel||[]).map(a=>`<tr><th scope="row">${HK(a.titel)}</th><td>${HK(a.slug)}</td><td>${HK(a.status)}</td><td>${HK(String(a.fassung))}</td>`
      +`<td>${HK((JSON.parse(a.bereiche_json||'[]')||[]).join(', '))}</td>`
      +`<td>${a.status!=='veroeffentlicht'?`<button class="btn hk-pub" type="button" data-id="${HK(a.id)}">Veröffentlichen</button>`:`<button class="btn secondary hk-weg" type="button" data-id="${HK(a.id)}">Zurückziehen</button>`} <button class="btn secondary hk-fas" type="button" data-id="${HK(a.id)}">Fassungen</button></td></tr>`).join('')
      ||'<tr><td colspan="6">Noch kein Artikel.</td></tr>';
    body.innerHTML=`<p class="muted">Veröffentlicht wird, was gelten soll — nur das ist auffindbar. Jede Fassung bleibt lesbar.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Artikel</caption><thead><tr><th scope="col">Titel</th><th scope="col">Kennung</th><th scope="col">Stand</th><th scope="col">Fassung</th><th scope="col">Bereiche</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<form id="hk-anew"><h4>Artikel anlegen</h4><label class="field">Kurzkennung<input name="slug" required></label><label class="field">Titel<input name="titel" required></label>`
      +`<label class="field">Bereiche (durch Komma getrennt)<input name="bereiche" placeholder="stundenplan, import"></label>`
      +`<label class="field">Inhalt<textarea name="inhalt" rows="5" required></textarea></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Anlegen</button></div></form><p class="error" id="hk-werr" role="alert"></p><div id="hk-wout"></div>`;
    const fehler=e=>{body.querySelector('#hk-werr').textContent=hkText(e.message);};
    body.querySelector('#hk-anew').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await hkApi(`/api/knowledge/articles?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        slug:String(f.get('slug')),titel:String(f.get('titel')),inhalt:String(f.get('inhalt')),bereiche:String(f.get('bereiche')||'')})});await render();}
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.hk-pub').forEach(b=>b.onclick=async()=>{
      try{await hkApi(`/api/knowledge/articles/${encodeURIComponent(b.dataset.id)}/publish?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.hk-weg').forEach(b=>b.onclick=async()=>{
      try{await hkApi(`/api/knowledge/articles/${encodeURIComponent(b.dataset.id)}/withdraw?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.hk-fas').forEach(b=>b.onclick=async()=>{
      try{const r=await hkApi(`/api/knowledge/articles/${encodeURIComponent(b.dataset.id)}/versions?tenant_id=${encodeURIComponent(tenantId)}`);
        body.querySelector('#hk-wout').innerHTML=`<ul>`+((r.fassungen||[]).map(f=>`<li>Fassung ${HK(String(f.fassung))} — ${HK(f.titel)} (${HK(hkZeit(f.veroeffentlicht_am))})</li>`).join('')||'<li>Noch keine veröffentlichte Fassung.</li>')+`</ul>`;}
      catch(e){fehler(e);}
    });
    // Bearbeiten über PATCH: ein veröffentlichter Artikel geht dabei zurück auf Entwurf.
    body.querySelectorAll('tbody th').forEach(th=>{th.style.cursor='pointer';th.onclick=async()=>{
      const zeile=th.parentElement,id=zeile.querySelector('[data-id]')?.dataset?.id;if(!id)return;
      const inhalt=prompt('Neuer Inhalt (leer lassen zum Abbrechen):');if(!inhalt)return;
      try{await hkApi(`/api/knowledge/articles/${encodeURIComponent(id)}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'PATCH',body:JSON.stringify({inhalt})});await render();}
      catch(e){fehler(e);}
    };});
  }
  await render();
}

(async()=>{
  let me=null;try{me=(await hkApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const verwaltung=me.isPlatformAdmin||roles.some(x=>['tenant_admin','class_admin'].includes(x.role));
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(seite){
      const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
      knopf('hk-hilfe-launch','Hilfe zu dieser Seite',()=>hkHilfe(tenantId),anker,'nav');
      knopf('hk-melden-launch','Problem melden',()=>hkMeldung(tenantId),anker,'nav');
      if(verwaltung)knopf('hk-helpdesk-launch','Helpdesk',()=>hkVerwaltung(tenantId),anker,'nav');
    }
    const portal=document.querySelector('.portal-main');
    if(portal&&!document.querySelector('#hk-portal-btn')){
      const b=document.createElement('button');b.id='hk-portal-btn';b.type='button';b.className='portal-btn secondary';b.textContent='Hilfe und Meldungen';
      b.onclick=()=>hkMeldung(tenantId).catch(e=>alert(hkText(e.message)));
      (document.querySelector('#gs-portal-buttons')||portal).append(b);
      const h=document.createElement('button');h.id='hk-portal-hilfe';h.type='button';h.className='portal-btn secondary';h.textContent='Hilfe';
      h.onclick=()=>hkHilfe(tenantId).catch(e=>alert(hkText(e.message)));
      (document.querySelector('#gs-portal-buttons')||portal).append(h);
    }
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

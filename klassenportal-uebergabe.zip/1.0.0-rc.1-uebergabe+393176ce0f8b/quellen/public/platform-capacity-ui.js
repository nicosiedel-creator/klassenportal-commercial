// Speicher, Kaltdaten und Rechtsnachfolge in der Plattformverwaltung.
//
// Diese drei Funktionen waren gebaut, geprüft und über die API erreichbar - aber es gab keinen
// Knopf dafür. Eine Funktion ohne Bedienung ist für den Betrieb dasselbe wie keine Funktion: die
// 10-GB-Grenze von D1 wäre trotz Messreihe unbemerkt näher gerückt, weil niemand die Zahl je zu
// Gesicht bekommt.
const CAPACITY_UI=location.pathname.replace(/\/$/,'')==='/plattform-admin';
if(CAPACITY_UI){
  const E=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const text=x=>{const code=String(x?.message||x||'');return (window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(x):code)||code;};
  async function api(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
  function modal(title,html){const w=document.createElement('div');w.className='modal-back';w.innerHTML=`<div class="modal" style="width:min(980px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 style="margin:0">${E(title)}</h3><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div data-body>${html}</div></div>`;document.body.append(w);w.querySelector('[data-close]').onclick=()=>w.remove();w.addEventListener('click',e=>{if(e.target===w)w.remove();});return w;}

  const GB=1024*1024*1024;
  const gb=b=>`${(Number(b||0)/GB).toFixed(2)} GB`;
  const STUFENTEXT={ok:'unauffällig',beobachten:'beobachten',warnung:'Warnung',kritisch:'kritisch'};
  const STUFENFARBE={ok:'#0f7b3f',beobachten:'#8a6d00',warnung:'#a35200',kritisch:'#b3261e'};

  function speicherBlock(s){
    const anteil=Math.min(100,Math.round(Number(s.anteil||0)*1000)/10);
    const rest=s.tage_bis_grenze===null||s.tage_bis_grenze===undefined
      ? (s.messreihe_tage>=2?'Kein messbarer Zuwachs.':`Noch zu wenig Messwerte (${E(s.messreihe_tage||0)} von 2 Tagen).`)
      : `Bei gleichbleibendem Zuwachs noch <strong>${E(s.tage_bis_grenze)} Tage</strong> (${gb(s.taeglicher_zuwachs_bytes)} je Tag).`;
    return `<section class="card" style="margin-top:14px">
      <div class="top"><h3 style="margin:0">Speicher der Datenbank</h3>
        <span style="font-weight:600;color:${STUFENFARBE[s.stufe]||'#333'}">${E(STUFENTEXT[s.stufe]||s.stufe)}</span></div>
      <p style="margin:.4rem 0"><strong>${gb(s.bytes)}</strong> von ${gb(s.grenze_bytes)} belegt (${E(anteil)} %, ${s.quelle==='gemessen'?'gemessen':'geschätzt'}).</p>
      <div style="height:12px;border-radius:6px;background:#eef2f7;overflow:hidden" role="img" aria-label="${E(anteil)} Prozent belegt">
        <div style="height:100%;width:${E(Math.max(1,anteil))}%;background:${STUFENFARBE[s.stufe]||'#2563eb'}"></div></div>
      <p class="muted" style="margin:.5rem 0">${rest}</p>
      <p class="muted">Diese Grenze setzt Cloudflare bei 10 GB je Datenbank. Sie lässt sich nicht anheben – wer sie erreicht, kann nicht mehr schreiben: keine Anwesenheit, keine Note, kein Zeugnis. Ab „kritisch“ werden große Einspielungen abgelehnt, damit kein halb übernommener Import entsteht.</p>
      ${(s.tabellen||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Tabelle</th><th scope="col">Zeilen</th><th scope="col">geschätzt</th></tr>
        ${s.tabellen.map(t=>`<tr><td>${E(t.tabelle)}</td><td style="text-align:right">${E(Number(t.zeilen).toLocaleString('de-DE'))}</td><td style="text-align:right">${gb(t.bytes)}</td></tr>`).join('')}</table></div>`:'<p class="muted">Noch keine nennenswerten Betriebsdaten.</p>'}
    </section>`;
  }

  function kaltBlock(rahmen,archive){
    return `<section class="card" style="margin-top:14px">
      <div class="top"><h3 style="margin:0">Kalte Daten auslagern</h3></div>
      <p class="muted">Abgeschlossene Jahrgänge wandern als Datei in den Objektspeicher und werden in der Datenbank gelöscht – geprüft vor gelöscht: erst wird das Geschriebene zurückgelesen und verglichen. Ausgelagert heißt nicht verschwunden: die Auskunft nach Artikel 15 liest die Archive mit, und beim Vertragsende gehen sie mit.</p>
      <form data-archive class="row" style="align-items:end;gap:10px">
        <label class="field">Träger<input name="tenant_id" required placeholder="Mandantenkennung"></label>
        <label class="field">Daten<select name="table">${(rahmen.tabellen||[]).map(t=>`<option value="${E(t)}">${E(t)}</option>`).join('')}</select></label>
        <label class="field">Jahr<input name="year" type="number" required max="${E(rahmen.bis_einschliesslich_jahr)}" placeholder="${E(rahmen.bis_einschliesslich_jahr)}"></label>
        <button class="btn">Auslagern</button>
      </form>
      <p class="muted">Möglich bis einschließlich ${E(rahmen.bis_einschliesslich_jahr)} – jüngere Zeiträume werden noch für Zeugnisse, Berichtshefte und Nachprüfungen gebraucht.</p>
      <div data-archive-status class="muted"></div>
      <div data-archive-list>${archivListe(archive)}</div>
    </section>`;
  }
  function archivListe(archive){
    if(!archive?.length)return '<p class="muted">Noch nichts ausgelagert.</p>';
    return `<div class="table-wrap"><table><tr><th scope="col">Zeitraum</th><th scope="col">Daten</th><th scope="col">Zeilen</th><th scope="col">Größe</th><th scope="col">Ausgelagert</th><th scope="col"></th></tr>
      ${archive.map(a=>`<tr><td>${E(a.period)}</td><td>${E(a.table_name)}</td><td style="text-align:right">${E(Number(a.row_count).toLocaleString('de-DE'))}</td><td style="text-align:right">${gb(a.bytes)}</td><td>${E(String(a.archived_at||'').slice(0,10))}${a.restored_at?' · zurückgeholt':''}</td>
        <td>${a.restored_at?'':`<button class="btn secondary" data-restore="${E(a.id)}">Zurückholen</button>`}</td></tr>`).join('')}</table></div>`;
  }

  function nachfolgeBlock(successions){
    return `<section class="card" style="margin-top:14px">
      <div class="top"><h3 style="margin:0">Rechtsnachfolge</h3></div>
      <p class="muted">Ein Träger verschwindet selten sauber – er wird übernommen, verschmilzt oder wird aufgelöst, und ein anderer führt die laufenden Kurse zu Ende. Beim Übergang ziehen die ausgewählten Kurse mit allem um, was an ihnen hängt; Protokoll und offene Forderungen bleiben beim Vorgänger. Der Nachweis überlebt den gelöschten Vorgänger, damit ein Zeugnis nicht bei einem Namen endet, den niemand mehr findet.</p>
      <form data-succession>
        <div class="row">
          <label class="field">Vorgänger<input name="predecessor_tenant_id" required placeholder="Mandantenkennung"></label>
          <label class="field">Art<select name="kind">
            <option value="uebergang">Übergang – Kurse ziehen zu einem Träger im Portal</option>
            <option value="inhaberwechsel">Inhaberwechsel – nur die Verantwortung wechselt</option>
            <option value="aufloesung">Auflösung – Nachfolger außerhalb des Portals</option>
          </select></label>
          <label class="field">Stichtag<input name="effective_on" type="date" required></label>
        </div>
        <div class="row">
          <label class="field">Nachfolger im Portal<input name="successor_tenant_id" placeholder="Mandantenkennung (beim Übergang erforderlich)"></label>
          <label class="field">Name des Nachfolgers<input name="successor_name" placeholder="wird sonst aus dem Träger übernommen"></label>
          <label class="field">Rechtsgrund<input name="legal_basis" placeholder="z. B. Verschmelzung nach UmwG"></label>
        </div>
        <label class="field">Kurse (leer = alle)<input name="course_ids" placeholder="Kurskennungen, durch Komma getrennt"></label>
        <button class="btn">Nachfolge anlegen</button> <span class="muted" data-succession-status></span>
      </form>
      <div data-succession-list style="margin-top:12px">${nachfolgeListe(successions)}</div>
    </section>`;
  }
  function nachfolgeListe(xs){
    if(!xs?.length)return '<p class="muted">Keine Nachfolge erfasst.</p>';
    return `<div class="table-wrap"><table><tr><th scope="col">Stichtag</th><th scope="col">Art</th><th scope="col">Vorgänger</th><th scope="col">Nachfolger</th><th scope="col">Kurse</th><th scope="col">Stand</th><th scope="col"></th></tr>
      ${xs.map(x=>`<tr><td>${E(x.effective_on)}</td><td>${E(x.kind)}</td><td>${E(x.predecessor_name)}</td><td>${E(x.successor_name)}</td>
        <td style="text-align:right">${E(x.courses_done)} / ${E(x.courses_total)}</td><td>${E(x.status)}</td>
        <td>${x.status==='vorbereitet'||x.status==='laufend'?`<button class="btn secondary" data-continue="${E(x.id)}">Fortsetzen</button> ${Number(x.courses_done)===0?`<button class="btn secondary" data-cancel="${E(x.id)}">Abbrechen</button>`:''}`:''}</td></tr>`).join('')}</table></div>`;
  }

  async function open(){
    const w=modal('Speicher & Nachfolge','<p class="muted">Wird geladen …</p>');
    const body=w.querySelector('[data-body]');
    let mandant='';
    async function laden(){
      try{
        const s=await api('/api/platform/storage');
        const kalt=await api(`/api/platform/cold-storage?tenant_id=${encodeURIComponent(mandant)}`);
        const nf=await api(`/api/platform/succession?tenant_id=${encodeURIComponent(mandant)}`);
        body.innerHTML=speicherBlock(s.storage)+kaltBlock(kalt.rahmen,kalt.archive)+nachfolgeBlock(nf.successions);
        verdrahten();
      }catch(e){body.innerHTML=`<div class="notice error">${E(text(e))}</div>`;}
    }
    function verdrahten(){
      const archivForm=body.querySelector('[data-archive]'),archivStatus=body.querySelector('[data-archive-status]');
      if(archivForm)archivForm.onsubmit=async e=>{
        e.preventDefault();
        const d=Object.fromEntries(new FormData(archivForm));
        mandant=String(d.tenant_id||'');
        archivStatus.textContent='Lagert aus …';
        try{
          let r,gesamt=0;
          // Die Auslagerung läuft in Häppchen; hier wird so lange fortgesetzt, bis nichts mehr offen ist.
          do{ r=await api('/api/platform/cold-storage/archive',{method:'POST',body:JSON.stringify({tenant_id:d.tenant_id,table:d.table,year:Number(d.year)})}); gesamt+=Number(r.archiviert||0); }while(r.completed===false);
          archivStatus.textContent=`${gesamt.toLocaleString('de-DE')} Zeilen ausgelagert.`;
          await laden();
        }catch(x){archivStatus.textContent=text(x);}
      };
      body.querySelectorAll('[data-restore]').forEach(b=>b.onclick=async()=>{
        if(!confirm('Dieses Archiv wirklich zurück in die Datenbank holen?'))return;
        try{await api('/api/platform/cold-storage/restore',{method:'POST',body:JSON.stringify({archive_id:b.dataset.restore})});await laden();}
        catch(x){alert(text(x));}
      });
      const nfForm=body.querySelector('[data-succession]'),nfStatus=body.querySelector('[data-succession-status]');
      if(nfForm)nfForm.onsubmit=async e=>{
        e.preventDefault();
        const d=Object.fromEntries(new FormData(nfForm));
        mandant=String(d.predecessor_tenant_id||'');
        const payload={...d};
        payload.course_ids=String(d.course_ids||'').split(',').map(x=>x.trim()).filter(Boolean);
        if(!payload.course_ids.length)delete payload.course_ids;
        for(const k of ['successor_tenant_id','successor_name','legal_basis'])if(!payload[k])delete payload[k];
        nfStatus.textContent='Wird angelegt …';
        try{await api('/api/platform/succession',{method:'POST',body:JSON.stringify(payload)});nfStatus.textContent='Angelegt.';await laden();}
        catch(x){nfStatus.textContent=text(x);}
      };
      body.querySelectorAll('[data-continue]').forEach(b=>b.onclick=async()=>{
        b.disabled=true;
        try{ let r; do{ r=await api('/api/platform/succession/continue',{method:'POST',body:JSON.stringify({succession_id:b.dataset.continue})}); }while(r.completed===false); await laden(); }
        catch(x){alert(text(x));b.disabled=false;}
      });
      body.querySelectorAll('[data-cancel]').forEach(b=>b.onclick=async()=>{
        if(!confirm('Diese Nachfolge wirklich abbrechen?'))return;
        try{await api('/api/platform/succession/cancel',{method:'POST',body:JSON.stringify({succession_id:b.dataset.cancel})});await laden();}
        catch(x){alert(text(x));}
      });
    }
    await laden();
  }

  function enhance(){
    const side=document.querySelector('.side');
    if(!side||side.querySelector('#platform-capacity-nav'))return;
    const b=document.createElement('button');
    b.id='platform-capacity-nav';b.className='nav';b.type='button';
    b.dataset.platformI18nKey='storage_succession';
    b.textContent=window.KP_PLATFORM_I18N?.t?.('storage_succession')||'Speicher & Nachfolge';
    const spacer=side.querySelector('.spacer');
    side.insertBefore(b,spacer||null);
    b.onclick=open;
    window.KP_PLATFORM_I18N?.apply?.();
  }
  window.addEventListener('kp:app-rendered',enhance);
  window.addEventListener('kp:platform-ui-applied',enhance);
  window.addEventListener('kp:localechange',enhance);
  enhance();
}

// Dokumentakte: Fassungen und Volltextsuche.
//
// Vorher wurde die alte Fassung beim Ersetzen überschrieben — für ein Zeugnis oder einen
// Förderbescheid der Unterschied zwischen einer Akte und einem Zettel. Und gesucht wurde nur über
// Felder, nie im Text der Dokumente.
const DA=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function daApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const daText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function daModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="da-titel" style="width:min(900px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="da-titel" style="margin:0">${DA(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="da-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#da-body'),zu};
}

async function daSuche(tenantId){
  const {body}=daModal('Dokumente durchsuchen');
  body.innerHTML=`<p class="muted">Gesucht wird auch im Text der Dokumente, soweit er erkannt wurde. Mehrere Begriffe werden UND-verknüpft — wer zwei eingibt, meint beide.</p>`
    +`<form id="da-suche"><label class="field">Suchbegriffe<input name="q" required minlength="3" placeholder="Förderbescheid Aktenzeichen"></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Suchen</button></div><p class="error" id="da-err" role="alert"></p></form><div id="da-treffer"></div>`;
  body.querySelector('#da-suche').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target);
    try{
      const d=await daApi(`/api/documents/search?tenant_id=${encodeURIComponent(tenantId)}&q=${encodeURIComponent(String(f.get('q')||''))}`);
      const zeilen=(d.treffer||[]).map(t=>`<tr><th scope="row">${DA(t.titel)}</th><td>${DA(t.kategorie)}</td><td>${DA(String(t.treffer))}</td><td>${DA(String(Math.round(Number(t.punkte))))}</td><td><button class="btn secondary da-fass" type="button" data-id="${DA(t.document_id)}">Fassungen</button></td></tr>`).join('')
        ||'<tr><td colspan="5">Kein Treffer. Alle Begriffe müssen vorkommen.</td></tr>';
      body.querySelector('#da-treffer').innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Suchtreffer</caption><thead><tr><th scope="col">Dokument</th><th scope="col">Art</th><th scope="col">Begriffe</th><th scope="col">Rang</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div><div id="da-detail"></div>`;
      body.querySelectorAll('.da-fass').forEach(b=>b.onclick=()=>daFassungen(tenantId,b.dataset.id,body.querySelector('#da-detail')));
    }catch(e){body.querySelector('#da-err').textContent=daText(e.message);}
  };
}

async function daFassungen(tenantId,documentId,ziel){
  const halter=ziel||daModal('Fassungen eines Dokuments').body;
  let d;try{d=await daApi(`/api/documents/${encodeURIComponent(documentId)}/versions?tenant_id=${encodeURIComponent(tenantId)}`);}
  catch(e){halter.innerHTML=`<div class="notice bad">${DA(daText(e.message))}</div>`;return;}
  const zeilen=(d.fassungen||[]).map(f=>`<tr><th scope="row">${DA(String(f.version))}</th><td>${DA(f.titel)}</td><td>${DA(f.kommentar||'')}</td><td>${DA(f.geaendert_name||f.geaendert_von)}</td><td>${DA(f.geaendert_am)}</td>`
    +`<td><button class="btn secondary da-zurueck" type="button" data-v="${DA(String(f.version))}">Zurückholen</button></td></tr>`).join('')
    ||'<tr><td colspan="6">Noch keine Fassung erfasst.</td></tr>';
  halter.innerHTML=`<h4>Fassungen</h4><p class="muted">Eine zurückgeholte Fassung wird als <strong>neue</strong> Fassung angelegt. Zurücksetzen würde den Beleg dafür löschen, dass es die spätere Fassung gab.</p>`
    +`<div style="overflow-x:auto"><table class="table"><caption>Fassungen dieses Dokuments</caption><thead><tr><th scope="col">Fassung</th><th scope="col">Titel</th><th scope="col">Änderung</th><th scope="col">Von</th><th scope="col">Am</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
    +`<h4>Neue Fassung</h4><form id="da-neu"><div class="row"><label class="field">Titel<input name="titel"></label>`
    +`<label class="field">Dateikennung<input name="file_id"></label></div>`
    +`<label class="field">Was hat sich geändert?<input name="kommentar" required minlength="5"></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Fassung speichern</button></div><p class="error" id="da-ferr" role="alert"></p></form>`;
  halter.querySelector('#da-neu').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target);
    try{await daApi(`/api/documents/${encodeURIComponent(documentId)}/versions?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
      body:JSON.stringify({titel:f.get('titel'),file_id:f.get('file_id'),kommentar:f.get('kommentar')})});
      await daFassungen(tenantId,documentId,halter);}
    catch(e){halter.querySelector('#da-ferr').textContent=daText(e.message);}
  };
  halter.querySelectorAll('.da-zurueck').forEach(b=>b.onclick=async()=>{
    const grund=prompt('Warum soll diese ältere Fassung wieder gelten? (mindestens 10 Zeichen)');
    if(grund===null)return;
    try{await daApi(`/api/documents/${encodeURIComponent(documentId)}/versions/${encodeURIComponent(b.dataset.v)}/restore?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({grund})});
      await daFassungen(tenantId,documentId,halter);}
    catch(e){alert(daText(e.message));}
  });
}

(async()=>{
  let me=null;try{me=(await daApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  if(!me.isPlatformAdmin&&!roles.some(x=>['tenant_admin','class_admin'].includes(x.role)))return;
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');if(!seite)return;
    const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
    knopf('da-suche-launch','Dokumente durchsuchen',()=>daSuche(tenantId),anker,'nav');
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

// Aufgabenfabrik und Befehlszeile.
//
// Zwei Dinge stehen hier ausdrücklich in der Oberfläche, weil sie sonst niemand glaubt:
// Entwürfe sind Entwürfe (freigeben darf jemand anderes), und die Befehlszeile schlägt vor —
// sie führt nichts aus.
const AF=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const AF_ART=[['quizfrage','Prüfungsfrage'],['aufgabe','Übungsaufgabe'],['lernmaterial','Lernmaterial'],['zusammenfassung','Zusammenfassung']];
const AF_QUELLE=[['curriculum_item','Lernfeld'],['competency','Kompetenz'],['media_asset','Medium'],['freitext','Freier Text']];
const AF_KLASSE=[['oeffentlich','Öffentlich'],['intern','Intern'],['personenbezogen','Personenbezogen'],['besonders','Besondere Kategorien']];
async function afApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const afText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function afModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="af-titel" style="width:min(980px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="af-titel" style="margin:0">${AF(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="af-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#af-body'),zu};
}

async function afFabrik(tenantId){
  const {body}=afModal('Aufgabenfabrik');
  async function render(){
    let d,auftraege={auftraege:[]};
    try{[d,auftraege]=await Promise.all([
      afApi(`/api/ai/drafts?tenant_id=${encodeURIComponent(tenantId)}`),
      afApi(`/api/ai/jobs?tenant_id=${encodeURIComponent(tenantId)}&grenze=10`).catch(()=>({auftraege:[]}))]);}
    catch(e){body.innerHTML=`<div class="notice bad">${AF(afText(e.message))}</div>`;return;}
    const zeilen=(d.entwuerfe||[]).map(x=>`<tr><th scope="row">${AF(x.titel)}</th><td>${AF(x.art)}</td><td>${AF(x.status)}</td>`
      +`<td>${AF(x.erzeuger)}</td><td>${x.herkunft?`${AF(x.herkunft.anbieter)}/${AF(x.herkunft.modell)}`:'—'}</td>`
      +`<td>${x.status==='entwurf'?`<button class="btn af-frei" type="button" data-id="${AF(x.id)}">Freigeben</button> <button class="btn secondary af-weg" type="button" data-id="${AF(x.id)}">Verwerfen</button>`:''}`
      +`${x.status==='freigegeben'?` <button class="btn af-ueb" type="button" data-id="${AF(x.id)}">Übernehmen</button>`:''}</td></tr>`).join('')
      ||'<tr><td colspan="6">Noch kein Entwurf.</td></tr>';
    // Laufende Aufträge. Sie sind der Grund, warum niemand mehr vor dem Ladebalken sitzt: die
    // Erzeugung läuft im Hintergrund, meldet ihren Stand und nimmt sich nach einem Abbruch selbst
    // wieder auf.
    const laufend=(auftraege.auftraege||[]).filter(j=>j.status==='offen'||j.status==='laeuft');
    const AF_STAND={offen:'wartet',laeuft:'läuft',fertig:'fertig',fehler:'gescheitert',abgebrochen:'abgebrochen'};
    const auftragsliste=(auftraege.auftraege||[]).length
      ?`<div style="overflow-x:auto"><table class="table"><caption>Aufträge</caption><thead><tr><th scope="col">Angelegt</th><th scope="col">Zweck</th><th scope="col">Stand</th><th scope="col">Fortschritt</th><th scope="col">Hinweis</th></tr></thead><tbody>`
        +auftraege.auftraege.map(j=>`<tr><th scope="row">${AF(String(j.created_at||'').slice(0,16).replace('T',' '))}</th><td>${AF(j.zweck)}</td>`
          +`<td>${AF(AF_STAND[j.status]||j.status)}${Number(j.wiederverwendet)?' <span class="muted">(wiederverwendet)</span>':''}</td>`
          +`<td><progress max="100" value="${AF(j.fortschritt)}"></progress> ${AF(j.fortschritt)} %</td>`
          +`<td class="muted">${AF(j.letzter_fehler?afText(j.letzter_fehler):(j.schritt||''))}</td></tr>`).join('')
        +`</tbody></table></div>`
      :'';
    body.innerHTML=`<div class="notice">Was hier entsteht, sind <strong>Entwürfe</strong>. Freigeben darf jemand anderes als die Person, die sie erzeugt hat — sonst hat niemand geprüft, was die Maschine geschrieben hat.</div>`
      +auftragsliste
      +`<div style="overflow-x:auto"><table class="table"><caption>Entwürfe</caption><thead><tr><th scope="col">Titel</th><th scope="col">Art</th><th scope="col">Stand</th><th scope="col">Erzeugt von</th><th scope="col">Modell</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<form id="af-neu"><h4>Entwürfe erzeugen</h4>`
      +`<label class="field">Art<select name="art">${AF_ART.map(([k,t])=>`<option value="${AF(k)}">${AF(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Quelle<select name="quelle_typ">${AF_QUELLE.map(([k,t])=>`<option value="${AF(k)}">${AF(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Kennung der Quelle<input name="quelle_id"></label>`
      +`<label class="field">Quelltext (nur bei freiem Text)<textarea name="quelltext" rows="3"></textarea></label>`
      +`<label class="field">Auftrag<textarea name="auftrag" rows="2" required placeholder="Erzeuge eine Prüfungsfrage zum Lernfeld."></textarea></label>`
      +`<label class="field">Anzahl<input name="menge" type="number" min="1" max="5" value="2"></label>`
      +`<label class="field">Kurs (optional)<input name="course_id"></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Erzeugen</button></div></form><p class="error" id="af-err" role="alert"></p>`;
    const fehler=e=>{body.querySelector('#af-err').textContent=afText(e.message);};
    body.querySelector('#af-neu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target),daten={menge:Number(f.get('menge')||1)};
      for(const [k,v] of f.entries())if(k!=='menge'&&String(v).trim())daten[k]=String(v).trim();
      try{
        const r=await afApi(`/api/ai/drafts?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(daten)});
        await render();
  // Nachsehen, solange etwas läuft. Kein Dauerlauf: ist nichts offen oder das Fenster zu, hört es
  // von selbst auf - ein Fenster, das im Hintergrund alle 15 Sekunden den Worker fragt, ist genau
  // die Sorte Last, die niemand bemerkt und alle bezahlen.
  const uhr=setInterval(async()=>{
    if(!document.body.contains(body))return clearInterval(uhr);
    try{
      const j=await afApi(`/api/ai/jobs?tenant_id=${encodeURIComponent(tenantId)}&grenze=10`);
      if(!(j.auftraege||[]).some(x=>x.status==='offen'||x.status==='laeuft'))return clearInterval(uhr);
      await render();
    }catch{clearInterval(uhr);}
  },15000);
        const offen=(r.entwuerfe||[]).filter(x=>x.status!=='fertig').length;
        body.querySelector('#af-err').textContent=offen
          ?`${offen} Entwurf/Entwürfe werden im Hintergrund erzeugt. Sie können dieses Fenster schließen – der Stand steht oben.`
          :'Die Entwürfe lagen schon vor und wurden wiederverwendet.';
      }
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.af-frei').forEach(b=>b.onclick=async()=>{
      const anmerkung=prompt('Anmerkung zur Prüfung (optional):')||'';
      try{await afApi(`/api/ai/drafts/${encodeURIComponent(b.dataset.id)}/release?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({anmerkung})});await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.af-weg').forEach(b=>b.onclick=async()=>{
      const grund=prompt('Warum wird der Entwurf verworfen?');if(!grund)return;
      try{await afApi(`/api/ai/drafts/${encodeURIComponent(b.dataset.id)}/discard?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({grund})});await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.af-ueb').forEach(b=>b.onclick=async()=>{
      const quiz=prompt('Kennung des Tests (leer lassen, wenn es keine Prüfungsfrage ist):')||'';
      try{await afApi(`/api/ai/drafts/${encodeURIComponent(b.dataset.id)}/adopt?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
        body:JSON.stringify(quiz?{quiz_id:quiz}:{ziel_id:'manuell'})});await render();}
      catch(e){fehler(e);}
    });
  }
  await render();
}

async function afBefehl(tenantId){
  const {body}=afModal('Befehlszeile');
  let befehle=[];
  try{befehle=(await afApi(`/api/command/available?tenant_id=${encodeURIComponent(tenantId)}`)).befehle||[];}catch{}
  body.innerHTML=`<div class="notice">Diese Zeile <strong>schlägt vor</strong>. Sie führt nichts aus — ausgeführt wird erst, was Sie danach bestätigen und öffnen.</div>`
    +`<form id="af-b"><label class="field">Was möchten Sie tun?<input name="eingabe" required placeholder="Zeig mir die überfälligen Meldungen"></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Vorschlagen</button></div></form>`
    +`<p class="error" id="af-berr" role="alert"></p><div id="af-bout"></div>`
    +`<details><summary>Was ich verstehe (${AF(String(befehle.length))})</summary><ul>`
    +befehle.map(b=>`<li>${AF(b.beschreibung)}${b.veraendert?' <span class="pill">verändert etwas</span>':''}</li>`).join('')+`</ul></details>`
    +`<div id="af-verlauf"></div>`;
  const fehler=e=>{body.querySelector('#af-berr').textContent=afText(e.message);};
  async function verlauf(){
    try{const r=await afApi(`/api/command/history?tenant_id=${encodeURIComponent(tenantId)}`);
      body.querySelector('#af-verlauf').innerHTML=`<details><summary>Frühere Anfragen</summary><ul>`
        +((r.verlauf||[]).map(v=>`<li>„${AF(v.eingabe)}“ → ${AF(v.absicht||v.hinweis||v.status)}</li>`).join('')||'<li>Noch nichts.</li>')+`</ul></details>`;}
    catch{}
  }
  body.querySelector('#af-b').onsubmit=async ev=>{
    ev.preventDefault();body.querySelector('#af-berr').textContent='';
    const eingabe=String(new FormData(ev.target).get('eingabe'));
    try{
      const r=await afApi(`/api/command/suggest?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({eingabe})});
      if(r.status==='abgelehnt'){body.querySelector('#af-bout').innerHTML=`<div class="notice bad">${AF(afText('BEFEHL_NICHT_VERSTANDEN'))}</div>`;await verlauf();return;}
      body.querySelector('#af-bout').innerHTML=(r.status==='unklar'?`<div class="notice">${AF(afText('BEFEHL_MEHRDEUTIG'))}</div>`:'')
        +`<ul style="list-style:none;padding:0;display:flex;flex-direction:column;gap:.5rem">`
        +r.vorschlaege.map(v=>`<li><button class="btn secondary af-ok" type="button" data-id="${AF(r.id)}" data-k="${AF(v.schluessel)}">`
          +`${AF(v.beschreibung)} (${AF(String(v.sicherheit))} %)${v.veraendert?' — verändert etwas':''}</button></li>`).join('')
        +`</ul>`;
      body.querySelectorAll('.af-ok').forEach(b=>b.onclick=async()=>{
        try{const c=await afApi(`/api/command/confirm?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
          body:JSON.stringify({id:b.dataset.id,schluessel:b.dataset.k})});
          body.querySelector('#af-bout').innerHTML=`<div class="notice good">Gemeint war: <code>${AF(c.methode)} ${AF(c.route)}</code>.`
            +` ${c.veraendert?'Dieser Aufruf verändert etwas — er wird erst durch Ihr Öffnen ausgeführt.':'Nichts wurde ausgeführt.'}</div>`;
          await verlauf();}
        catch(e){fehler(e);}
      });
      await verlauf();
    }catch(e){fehler(e);}
  };
  await verlauf();
}

(async()=>{
  let me=null;try{me=(await afApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const verwaltung=me.isPlatformAdmin||roles.some(x=>['tenant_admin','class_admin'].includes(x.role));
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(seite){
      const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
      if(verwaltung)knopf('af-fabrik-launch','Aufgabenfabrik',()=>afFabrik(tenantId),anker,'nav');
      knopf('af-befehl-launch','Befehlszeile',()=>afBefehl(tenantId),anker,'nav');
    }
    const portal=document.querySelector('.portal-main');
    if(portal&&!document.querySelector('#af-portal-btn')){
      const b=document.createElement('button');b.id='af-portal-btn';b.type='button';b.className='portal-btn secondary';b.textContent='Befehlszeile';
      b.onclick=()=>afBefehl(tenantId).catch(e=>alert(afText(e.message)));
      (document.querySelector('#gs-portal-buttons')||portal).append(b);
    }
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

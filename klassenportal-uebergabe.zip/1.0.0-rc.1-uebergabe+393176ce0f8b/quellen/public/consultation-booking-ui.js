// Sprechtag im Klassenportal: die Familie sucht sich ihr Zeitfenster selbst aus.
//
// Bewusst zwei getrennte Ansichten in einer Datei, weil es dieselben Daten sind:
//   - Familie:            freie Fenster je Dozent, buchen, absagen, eigener Ablaufplan
//   - Klassenverantwortung: Sprechtag anlegen und oeffnen, Raster erzeugen, Laufzettel je Dozent
//
// Der Ablaufplan umfasst den ganzen Abend, nicht nur einen Sprechtag: wer zwei Kinder in zwei
// Klassen hat, hat an diesem Abend zwei parallel laufende Sprechtage.
const KP_CONSULTATION_PORTAL=/^\/portal\/[^/]+\/[^/]+\/?$/.test(location.pathname);
if(KP_CONSULTATION_PORTAL){
  const E=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fehler=e=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(e):'Die Aktion konnte nicht ausgeführt werden.';
  const uhr=v=>String(v||'').slice(11,16);
  const tagText=v=>{const d=new Date(`${String(v||'').slice(0,10)}T12:00:00Z`);return Number.isNaN(d.getTime())?String(v||''):d.toLocaleDateString('de-DE',{weekday:'long',day:'2-digit',month:'2-digit',year:'numeric',timeZone:'UTC'});};
  let ctx=null,laeuft=false;

  async function api(url,opt={}){
    const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});
    let d={};try{d=await r.json();}catch{}
    if(!r.ok)throw Object.assign(new Error(d.error||`HTTP_${r.status}`),{status:r.status});
    return d;
  }
  const q=(pfad,extra={})=>{const p=new URLSearchParams({tenant_id:ctx.tenantId,course_id:ctx.courseId});for(const [k,v] of Object.entries(extra))if(v)p.set(k,String(v));return `${pfad}?${p}`;};

  function kontext(data){
    const rolle=String(data?.viewer?.role||'');
    if(!['participant','class_admin','tenant_admin'].includes(rolle))return null;
    if(!data?.viewer?.tenantId||!data?.course?.id)return null;
    return{tenantId:String(data.viewer.tenantId),courseId:String(data.course.id),rolle,verwaltet:rolle!=='participant'};
  }

  function bereich(){
    let host=document.querySelector('#portal-consultation');
    if(!host){host=document.createElement('section');host.id='portal-consultation';host.className='portal-section wide';document.querySelector('.portal-main')?.append(host);}
    return host;
  }
  function melden(host,text,art='ok'){
    const box=host.querySelector('[data-consultation-status]');
    if(box)box.innerHTML=text?`<div class="notice${art==='ok'?' ok':''}" style="margin:10px 0">${E(text)}</div>`:'';
  }

  async function laden(erzwingen=false){
    if(!ctx||laeuft)return;laeuft=true;
    const host=bereich();
    try{
      const antwort=await api(q('/api/education/planning/consultation-days'));
      const tage=(antwort.days||[]).filter(t=>String(t.status)!=='draft'||ctx.verwaltet);
      zeichnen(host,tage);
    }catch(x){
      // Eine leere Liste und eine gescheiterte Abfrage sehen sonst gleich aus - und die Familie
      // haelt "keine Sprechtage" fuer eine Aussage, obwohl gar nichts geladen wurde.
      host.innerHTML=`<div class="portal-section-head"><h2>Sprechtag</h2></div><div class="notice">${E(fehler(x))}</div>`;
    }finally{laeuft=false;void erzwingen;}
  }

  function zeichnen(host,tage){
    host.innerHTML=`<div class="portal-section-head"><h2>Sprechtag &amp; Beratungsgespräche</h2>${ctx.verwaltet?'<button class="portal-btn secondary" type="button" data-neu>Sprechtag anlegen</button>':''}</div>`
      +`<div data-consultation-status aria-live="polite"></div>`
      +(tage.length?`<div class="portal-list" data-consultation-list>${tage.map(karte).join('')}</div>`
        :`<p class="meta">Zurzeit ist kein Sprechtag zur Buchung geöffnet. Sobald die Schule einen Termin freigibt, erscheint er hier.</p>`);
    if(ctx.verwaltet)host.querySelector('[data-neu]').onclick=()=>anlegen(host);
    for(const knopf of host.querySelectorAll('[data-oeffnen]'))knopf.onclick=()=>fenster(host,knopf.dataset.oeffnen);
    for(const knopf of host.querySelectorAll('[data-plan]'))knopf.onclick=()=>ablaufplan(host,knopf.dataset.plan);
    for(const knopf of host.querySelectorAll('[data-raster]'))knopf.onclick=()=>raster(host,knopf.dataset.raster);
    for(const knopf of host.querySelectorAll('[data-laufzettel]'))knopf.onclick=()=>laufzettel(host,knopf.dataset.laufzettel);
  }

  const ZUSTAND={draft:'In Vorbereitung – für Familien noch nicht sichtbar',open:'Zur Buchung geöffnet',closed:'Buchung abgeschlossen'};
  function karte(t){
    const frei=Math.max(0,Number(t.slot_count||0)-Number(t.booked_count||0));
    return `<div class="portal-item"><strong>${E(t.title)}</strong>`
      +`<div class="meta">${E(tagText(t.event_date))}, ${E(String(t.starts_time))}–${E(String(t.ends_time))} Uhr`
      +(t.location?` · ${E(t.location)}`:'')+(t.course_name?` · ${E(t.course_name)}`:'')
      +` · Gespräch ${E(String(t.slot_minutes))} Minuten</div>`
      +`<div class="meta">${E(ZUSTAND[String(t.status)]||String(t.status))} · ${E(String(frei))} von ${E(String(t.slot_count||0))} Zeitfenstern frei</div>`
      +`<div class="toolbar" style="margin-top:8px">`
      +`<button class="portal-btn" type="button" data-oeffnen="${E(t.id)}">Zeitfenster ansehen</button>`
      +`<button class="portal-btn secondary" type="button" data-plan="${E(t.id)}">Mein Ablaufplan</button>`
      +(ctx.verwaltet?`<button class="portal-btn secondary" type="button" data-raster="${E(t.id)}">Zeitraster erzeugen</button>`
        +`<button class="portal-btn secondary" type="button" data-laufzettel="${E(t.id)}">Laufzettel je Dozent</button>`:'')
      +`</div></div>`;
  }

  function dialog(titel,inhalt){
    const w=document.createElement('div');w.className='modal-back';
    w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-label="${E(titel)}" style="width:min(760px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 style="margin:0">${E(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div data-inhalt>${inhalt}</div></div>`;
    document.body.append(w);
    const zu=()=>w.remove();
    w.querySelector('[data-close]').onclick=zu;
    w.addEventListener('click',e=>{if(e.target===w)zu();});
    return w;
  }

  // --- Familie ------------------------------------------------------------------------------
  async function fenster(host,dayId){
    const w=dialog('Zeitfenster wählen','<p class="muted">Wird geladen …</p>');
    try{
      const d=await api(q(`/api/education/planning/consultation-days/${encodeURIComponent(dayId)}/slots`));
      const nachDozent=new Map();
      for(const s of d.slots||[]){const k=String(s.teacher_name||'');const l=nachDozent.get(k)||[];l.push(s);nachDozent.set(k,l);}
      const inhalt=[...nachDozent.entries()].map(([name,liste])=>
        `<div class="portal-item"><strong>${E(name)}</strong><div class="toolbar" style="flex-wrap:wrap;gap:6px;margin-top:6px">`
        +liste.map(s=>{
          if(s.mine)return `<button class="portal-btn" type="button" data-absagen="${E(s.booking_id)}" title="Diese Buchung absagen">${E(uhr(s.starts_at))} · gebucht ✕</button>`;
          if(Number(s.taken))return `<button class="portal-btn secondary" type="button" disabled>${E(uhr(s.starts_at))} · vergeben</button>`;
          if(String(s.status)!=='open')return `<button class="portal-btn secondary" type="button" disabled>${E(uhr(s.starts_at))} · gesperrt</button>`;
          return `<button class="portal-btn secondary" type="button" data-buchen="${E(s.id)}">${E(uhr(s.starts_at))}</button>`;
        }).join('')+`</div></div>`).join('');
      w.querySelector('[data-inhalt]').innerHTML=
        `<p class="meta">Wer belegt ist, steht als „vergeben“ – wer gebucht hat, sehen nur die Schule und die betreffende Familie selbst.</p>`
        +`<div data-consultation-status aria-live="polite"></div>`
        +(inhalt||'<p class="meta">Für diesen Sprechtag ist noch kein Zeitraster erzeugt worden.</p>');
      for(const b of w.querySelectorAll('[data-buchen]'))b.onclick=()=>buchen(w,host,dayId,b.dataset.buchen);
      for(const b of w.querySelectorAll('[data-absagen]'))b.onclick=()=>absagen(w,host,dayId,b.dataset.absagen);
    }catch(x){w.querySelector('[data-inhalt]').innerHTML=`<div class="notice">${E(fehler(x))}</div>`;}
  }

  async function buchen(w,host,dayId,slotId){
    const feld=w.querySelector('[data-name]');
    melden(w,'Wird gebucht …');
    try{
      await api(q('/api/education/planning/consultation-bookings'),{method:'POST',body:JSON.stringify({slot_id:slotId,participant_name:feld?feld.value:''})});
      w.remove();await laden(true);
      const zurueck=bereich();melden(zurueck,'Das Gespräch ist gebucht. Der Ablaufplan zeigt alle Termine dieses Abends.');
    }catch(x){melden(w,fehler(x),'warn');}
  }
  async function absagen(w,host,dayId,bookingId){
    melden(w,'Wird abgesagt …');
    try{
      await api(q(`/api/education/planning/consultation-bookings/${encodeURIComponent(bookingId)}`),{method:'DELETE'});
      w.remove();await laden(true);await fenster(bereich(),dayId);
    }catch(x){melden(w,fehler(x),'warn');}
  }

  async function ablaufplan(host,dayId){
    const w=dialog('Mein Ablaufplan','<p class="muted">Wird geladen …</p>');
    try{
      const d=await api(q(`/api/education/planning/consultation-days/${encodeURIComponent(dayId)}/schedule`));
      const zeilen=d.rows||[];
      w.querySelector('[data-inhalt]').innerHTML=zeilen.length
        ?`<p class="meta">${E(tagText(d.day?.event_date))} · ${E(uhr(d.first_starts_at))} bis ${E(uhr(d.last_ends_at))} Uhr</p>`
          +`<div class="portal-list">${zeilen.map(z=>
            `<div class="portal-item"><strong>${E(uhr(z.starts_at))}–${E(uhr(z.ends_at))} Uhr · ${E(z.teacher_name)}</strong>`
            +`<div class="meta">${[z.course_name,z.location,z.participant_name].filter(Boolean).map(E).join(' · ')||'&nbsp;'}</div>`
            +(Number(z.wait_minutes)>0?`<div class="meta">${E(String(z.wait_minutes))} Minuten Wartezeit bis zu diesem Gespräch.</div>`:'')
            +`</div>`).join('')}</div>`
        :'<p class="meta">Für diesen Abend ist noch kein Gespräch gebucht.</p>';
    }catch(x){w.querySelector('[data-inhalt]').innerHTML=`<div class="notice">${E(fehler(x))}</div>`;}
  }

  // --- Klassenverantwortung -----------------------------------------------------------------
  function anlegen(host){
    const heute=new Date().toISOString().slice(0,10);
    const w=dialog('Sprechtag anlegen',`<form data-form>
      <label class="field">Bezeichnung<input name="title" required maxlength="200" value="Sprechtag"></label>
      <label class="field">Datum<input name="event_date" type="date" value="${E(heute)}" required></label>
      <div class="row"><label class="field">Beginn<input name="starts_time" type="time" value="16:00" required></label>
      <label class="field">Ende<input name="ends_time" type="time" value="19:00" required></label></div>
      <div class="row"><label class="field">Dauer je Gespräch (Minuten)<input name="slot_minutes" type="number" min="5" max="120" value="10" required></label>
      <label class="field">Wechselzeit (Minuten)<input name="break_minutes" type="number" min="0" max="60" value="0"></label></div>
      <label class="field">Ort<input name="location" maxlength="200" placeholder="z. B. Hauptgebäude, Erdgeschoss"></label>
      <label class="field">Höchstzahl Gespräche je Familie (0 = beliebig)<input name="max_bookings_per_user" type="number" min="0" value="0"></label>
      <label class="field">Zustand<select name="status"><option value="draft">In Vorbereitung – noch nicht sichtbar</option><option value="open" selected>Zur Buchung geöffnet</option><option value="closed">Buchung abgeschlossen</option></select></label>
      <p class="meta">Das Zeitraster entsteht anschließend aus den hinterlegten Arbeitszeiten, Abwesenheiten und Schließzeiten – es muss nichts doppelt gepflegt werden.</p>
      <div class="toolbar" style="margin-top:12px"><button class="btn" type="submit">Sprechtag speichern</button></div>
      <div data-consultation-status aria-live="polite"></div></form>`);
    const f=w.querySelector('[data-form]');
    f.onsubmit=async e=>{
      e.preventDefault();
      melden(w,'Wird gespeichert …');
      try{
        await api(q('/api/education/planning/consultation-days'),{method:'POST',body:JSON.stringify({...Object.fromEntries(new FormData(f)),course_id:ctx.courseId})});
        w.remove();await laden(true);
      }catch(x){melden(w,fehler(x),'warn');}
    };
  }

  async function raster(host,dayId){
    melden(host,'Das Zeitraster wird erzeugt …');
    try{
      const d=await api(q(`/api/education/planning/consultation-days/${encodeURIComponent(dayId)}/slots`),{method:'POST',body:JSON.stringify({})});
      const uebergangen=(d.skipped||[]).map(s=>`${s.teacher_name}: ${s.grund}`).join('; ');
      await laden(true);
      melden(bereich(),`${d.created} Zeitfenster neu angelegt, ${d.already_present} waren bereits vorhanden.`
        +(uebergangen?` Übergangen: ${uebergangen}.`:''));
    }catch(x){melden(host,fehler(x),'warn');}
  }

  async function laufzettel(host,dayId){
    const w=dialog('Laufzettel je Dozent','<p class="muted">Wird geladen …</p>');
    try{
      const d=await api(q(`/api/education/planning/consultation-days/${encodeURIComponent(dayId)}/slots`));
      const dozenten=[...new Map((d.slots||[]).map(s=>[String(s.teacher_id),String(s.teacher_name||'')])).entries()];
      if(!dozenten.length){w.querySelector('[data-inhalt]').innerHTML='<p class="meta">Für diesen Sprechtag ist noch kein Zeitraster erzeugt worden.</p>';return;}
      const bloecke=await Promise.all(dozenten.map(([tid])=>api(q(`/api/education/planning/consultation-days/${encodeURIComponent(dayId)}/run-sheet`,{teacher_id:tid}))));
      w.querySelector('[data-inhalt]').innerHTML=bloecke.map(b=>
        `<div class="portal-item"><strong>${E(b.teacher_name)}</strong>`
        +`<div class="meta">${E(String(b.booked))} Gespräche gebucht, ${E(String(b.free))} Zeitfenster frei.</div>`
        +`<div class="portal-list" style="margin-top:6px">${(b.rows||[]).map(z=>
          `<div class="portal-item"><strong>${E(uhr(z.starts_at))}–${E(uhr(z.ends_at))} Uhr</strong>`
          +`<div class="meta">${z.state==='gebucht'?E([z.family_name,z.participant_name,z.course_name].filter(Boolean).join(' · ')):z.state==='gesperrt'?'gesperrt':'frei'}</div>`
          +(z.note?`<div class="meta">${E(z.note)}</div>`:'')+`</div>`).join('')}</div></div>`).join('');
    }catch(x){w.querySelector('[data-inhalt]').innerHTML=`<div class="notice">${E(fehler(x))}</div>`;}
  }

  function portalDaten(data){
    ctx=kontext(data);
    if(ctx)void laden(true);
    else document.querySelector('#portal-consultation')?.remove();
  }
  window.addEventListener('kp:portal-data',event=>portalDaten(event.detail?.data));
  if(window.__KP_PORTAL_DATA)portalDaten(window.__KP_PORTAL_DATA);
}

// Angebote und Verträge für Kurse.
//
// Der Maßnahmeplan wird aus dem Stundenplan abgeleitet, nicht getippt. Genau ihn prüft der
// Kostenträger später gegen den Anwesenheitsnachweis — Abweichungen werden zurückgefordert.
// Deshalb hängt an jedem versendeten Angebot eine Prüfsumme über den Plan, und die Liste sagt
// von selbst, wenn sich der Unterricht seither geändert hat.
const CA=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CA_TRAEGER=[['agentur_fuer_arbeit','Agentur für Arbeit'],['jobcenter','Jobcenter'],['rentenversicherung','Rentenversicherung'],
  ['berufsgenossenschaft','Berufsgenossenschaft'],['betrieb','Betrieb'],['land','Land / Kommune'],['selbstzahler','Selbstzahler'],['sonstige','Sonstige']];
const CA_ANLAGE=[['massnahmeplan','Maßnahmeplan'],['kostenaufstellung','Kostenaufstellung'],['zulassung','Zulassung (AZAV)'],
  ['lehrplan','Lehrplan'],['raumkonzept','Raumkonzept'],['dozentenprofil','Dozentenprofil'],['sonstiges','Sonstiges']];
const CA_STATUS={entwurf:'Entwurf',versendet:'Versendet',angenommen:'Angenommen',abgelehnt:'Abgelehnt',abgelaufen:'Abgelaufen'};
const caName=(liste,k)=>(liste.find(x=>x[0]===k)||[k,k])[1];
const caEuro=c=>(Number(c||0)/100).toLocaleString('de-DE',{style:'currency',currency:'EUR'});
async function caApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const caText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;

function caModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="ca-titel" style="width:min(1040px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="ca-titel" style="margin:0">${CA(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="ca-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#ca-body'),zu};
}

async function caAngebote(tenantId){
  const {body}=caModal('Angebote und Verträge');
  const melde=t=>{const p=body.querySelector('#ca-err');if(p)p.textContent=t;};
  async function render(){
    let d,kurse=[];
    try{d=await caApi(`/api/course-offers?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${CA(caText(e.message))}</div>`;return;}
    try{kurse=(await caApi(`/api/courses?tenant_id=${encodeURIComponent(tenantId)}`)).courses||[];}catch{}

    const zeilen=(d.angebote||[]).map(a=>{
      const fehlt=(a.fehlende_anlagen||[]);
      const hinweis=fehlt.length
        ? `<span class="tag bad">fehlt: ${CA(fehlt.map(f=>caName(CA_ANLAGE,f)).join(', '))}</span>`
        : '<span class="tag good">vollständig</span>';
      const knoepfe=[`<button class="btn secondary" type="button" data-plan="${CA(a.id)}">Maßnahmeplan</button>`,
        `<button class="btn secondary" type="button" data-anlage="${CA(a.id)}">Anlage</button>`];
      if(a.status==='entwurf')knoepfe.push(`<button class="btn" type="button" data-send="${CA(a.id)}">Versenden</button>`);
      if(a.status==='versendet')knoepfe.push(`<button class="btn secondary" type="button" data-check="${CA(a.id)}">Aktualität prüfen</button>`,
        `<button class="btn" type="button" data-accept="${CA(a.id)}">Angenommen</button>`,
        `<button class="btn secondary" type="button" data-reject="${CA(a.id)}">Abgelehnt</button>`);
      return `<tr><th scope="row">${CA(a.nummer)}</th><td>${CA(a.kurs)}</td>`
        +`<td>${CA(caName(CA_TRAEGER,a.kostentraeger_art))}<br><small>${CA(a.kostentraeger_name)}</small></td>`
        +`<td>${CA(a.plaetze)} × ${CA(caEuro(a.preis_je_teilnehmer_cent))}<br><strong>${CA(caEuro(a.summe_cent))}</strong></td>`
        +`<td>${CA(a.gueltig_bis||'')}</td><td>${CA(CA_STATUS[a.status]||a.status)}</td><td>${hinweis}</td>`
        +`<td class="toolbar" style="gap:.25rem;flex-wrap:wrap">${knoepfe.join('')}</td></tr>`;
    }).join('')||'<tr><td colspan="8">Noch kein Angebot.</td></tr>';

    const vertraege=(d.vertraege||[]).map(v=>`<tr><th scope="row">${CA(v.vertragsnummer)}</th><td>${CA(v.kurs)}</td>`
      +`<td>${CA(v.kostentraeger_name)}</td><td>${CA(v.plaetze)} × ${CA(caEuro(v.preis_je_teilnehmer_cent))}</td>`
      +`<td>${CA(v.status)}</td></tr>`).join('')||'<tr><td colspan="5">Noch kein Vertrag.</td></tr>';

    body.innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Angebote</caption><thead><tr>`
      +`<th scope="col">Nr.</th><th scope="col">Kurs</th><th scope="col">Kostenträger</th><th scope="col">Preis</th>`
      +`<th scope="col">Gültig bis</th><th scope="col">Stand</th><th scope="col">Unterlagen</th><th scope="col">Nächster Schritt</th>`
      +`</tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<div class="toolbar"><button class="btn secondary" type="button" id="ca-expire">Abgelaufene schließen</button></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Verträge</caption><thead><tr><th scope="col">Nummer</th>`
      +`<th scope="col">Kurs</th><th scope="col">Kostenträger</th><th scope="col">Umfang</th><th scope="col">Stand</th></tr></thead>`
      +`<tbody>${vertraege}</tbody></table></div>`
      +`<form id="ca-neu"><h4>Neues Angebot</h4>`
      +`<label class="field">Kurs<select name="course_id" required>${kurse.map(k=>`<option value="${CA(k.id)}">${CA(k.name)}</option>`).join('')}</select></label>`
      +`<label class="field">Kostenträger<select name="kostentraeger_art">${CA_TRAEGER.map(([k,t])=>`<option value="${CA(k)}">${CA(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Name des Kostenträgers<input name="kostentraeger_name" required></label>`
      +`<label class="field">Ansprechpartner<input name="ansprechpartner"></label>`
      +`<label class="field">Maßnahmenummer<input name="massnahmenummer"></label>`
      +`<label class="field">Aktenzeichen<input name="aktenzeichen"></label>`
      +`<label class="field">Preis je Teilnehmer (Euro)<input name="preis_euro" type="number" min="0" step="0.01" required></label>`
      +`<label class="field">Plätze<input name="plaetze" type="number" min="1" step="1" required></label>`
      +`<label class="field">Gültig bis<input name="gueltig_bis" type="date" required></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Angebot anlegen</button></div></form>`
      +`<p class="error" id="ca-err" role="alert"></p>`;

    body.querySelector('#ca-neu').onsubmit=async e=>{
      e.preventDefault();const f=new FormData(e.target);
      // Der Preis wird in Euro getippt und in Cent gespeichert - gerechnet, nicht gerundet geraten.
      const cent=Math.round(Number(String(f.get('preis_euro')).replace(',','.'))*100);
      try{
        await caApi(`/api/course-offers?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
          course_id:f.get('course_id'),kostentraeger_art:f.get('kostentraeger_art'),kostentraeger_name:f.get('kostentraeger_name'),
          ansprechpartner:f.get('ansprechpartner')||undefined,massnahmenummer:f.get('massnahmenummer')||undefined,
          aktenzeichen:f.get('aktenzeichen')||undefined,preis_je_teilnehmer_cent:cent,
          plaetze:Number(f.get('plaetze')),gueltig_bis:f.get('gueltig_bis')})});
        await render();
      }catch(err){melde(caText(err.message));}
    };
    body.querySelector('#ca-expire').onclick=async()=>{
      try{const r=await caApi(`/api/course-offers/expire?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
        melde(`${r.abgelaufen||0} Angebot(e) abgelaufen.`);await render();}
      catch(err){melde(caText(err.message));}
    };
    body.querySelectorAll('[data-plan]').forEach(b=>b.onclick=async()=>{
      const a=(d.angebote||[]).find(x=>x.id===b.dataset.plan);if(!a)return;
      const kurs=(kurse.find(k=>k.name===a.kurs)||{}).id;
      try{
        const r=await caApi(`/api/course-offers/plan?tenant_id=${encodeURIComponent(tenantId)}&course_id=${encodeURIComponent(kurs||'')}`);
        const p=r.plan||{};
        melde(`${p.unterrichtseinheiten} Unterrichtseinheiten (${p.stunden} Zeitstunden) über ${p.wochen} Wochen, `
          +`${(p.lernfelder||[]).length} Lernfelder — abgeleitet aus dem Stundenplan.`);
      }catch(err){melde(caText(err.message));}
    });
    body.querySelectorAll('[data-check]').forEach(b=>b.onclick=async()=>{
      try{const r=await caApi(`/api/course-offers/check?tenant_id=${encodeURIComponent(tenantId)}&offer_id=${encodeURIComponent(b.dataset.check)}`);
        melde(r.unveraendert
          ? 'Der Stundenplan entspricht noch dem versendeten Maßnahmeplan.'
          : `Der Stundenplan hat sich geändert: versendet ${r.plan_damals?.unterrichtseinheiten} Unterrichtseinheiten, heute ${r.plan_heute?.unterrichtseinheiten}. Bitte neu versenden.`);
      }catch(err){melde(caText(err.message));}
    });
    body.querySelectorAll('[data-send]').forEach(b=>b.onclick=async()=>{
      try{await caApi(`/api/course-offers/send?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({offer_id:b.dataset.send})});await render();}
      catch(err){melde(caText(err.message));}
    });
    body.querySelectorAll('[data-accept]').forEach(b=>b.onclick=async()=>{
      try{const r=await caApi(`/api/course-offers/accept?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({offer_id:b.dataset.accept})});
        melde(`Vertrag ${r.vertragsnummer} angelegt, ${r.foerderfaelle} Förderfall/Förderfälle eröffnet.`);await render();}
      catch(err){melde(caText(err.message));}
    });
    body.querySelectorAll('[data-reject]').forEach(b=>b.onclick=async()=>{
      const grund=prompt('Warum wurde abgelehnt?');if(!grund)return;
      try{await caApi(`/api/course-offers/reject?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({offer_id:b.dataset.reject,grund})});await render();}
      catch(err){melde(caText(err.message));}
    });
    body.querySelectorAll('[data-anlage]').forEach(b=>b.onclick=()=>caAnlage(tenantId,b.dataset.anlage,render));
  }
  await render();
}

function caAnlage(tenantId,offerId,danach){
  const {body,zu}=caModal('Anlage beilegen');
  body.innerHTML=`<form id="ca-anl">`
    +`<label class="field">Art<select name="art">${CA_ANLAGE.map(([k,t])=>`<option value="${CA(k)}">${CA(t)}</option>`).join('')}</select></label>`
    +`<label class="field">Titel<input name="titel" required></label>`
    +`<label class="field">Inhalt / Angaben<textarea name="inhalt" rows="4" required></textarea></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Beilegen</button></div></form><p class="error" id="ca-anl-err" role="alert"></p>`;
  body.querySelector('#ca-anl').onsubmit=async e=>{
    e.preventDefault();const f=new FormData(e.target);
    try{
      await caApi(`/api/course-offers/attachments?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        offer_id:offerId,art:f.get('art'),titel:f.get('titel'),inhalt:{text:String(f.get('inhalt'))}})});
      zu();await danach();
    }catch(err){body.querySelector('#ca-anl-err').textContent=caText(err.message);}
  };
}

(async()=>{
  let me=null;try{me=(await caApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const traegerleitung=me.isPlatformAdmin||roles.some(x=>x.role==='tenant_admin');
  if(!traegerleitung)return;
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');if(!seite||document.querySelector('#ca-launch'))return;
    const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');if(!anker)return;
    const b=document.createElement('button');b.id='ca-launch';b.type='button';b.className='nav';
    b.textContent='Angebote & Verträge';b.onclick=()=>caAngebote(tenantId).catch(e=>alert(caText(e.message)));
    anker.after(b);
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

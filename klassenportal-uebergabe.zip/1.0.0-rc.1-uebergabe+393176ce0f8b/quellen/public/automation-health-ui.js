// Der Zustand der Automatik: Fehlerwarteschlange, Vorgänge, Probeläufe.
//
// Vorher stand ein gescheiterter Automatiklauf in `console.error` — also nirgends. Eine Regel, die
// seit drei Wochen bei jedem Lauf scheitert, sah von außen aus wie eine, die nichts zu tun hat.
const AH=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function ahApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const ahText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function ahModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="ah-titel" style="width:min(940px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="ah-titel" style="margin:0">${AH(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="ah-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#ah-body'),zu};
}

async function ahZustand(tenantId){
  const {body}=ahModal('Automatik: Zustand');
  async function render(){
    let f,v;
    try{[f,v]=await Promise.all([
      ahApi(`/api/automation/failures?tenant_id=${encodeURIComponent(tenantId)}`),
      ahApi(`/api/automation/operations?tenant_id=${encodeURIComponent(tenantId)}`)]);}
    catch(e){body.innerHTML=`<div class="notice bad">${AH(ahText(e.message))}</div>`;return;}
    const fehler=(f.fehler||[]).map(x=>`<tr><th scope="row">${AH(x.quelle)}${x.quelle_id?` · ${AH(x.quelle_id)}`:''}</th><td>${AH(x.fehler_code)}</td><td>${AH(String(x.versuche))}</td><td>${AH(x.status)}</td><td>${AH(x.letzter_fehler_am)}</td>`
      +`<td><button class="btn secondary ah-wieder" type="button" data-id="${AH(x.id)}">Wiederaufnehmen</button> <button class="btn secondary ah-auf" type="button" data-id="${AH(x.id)}">Aufgeben</button></td></tr>`).join('')
      ||'<tr><td colspan="6">Kein offener Fehler. Die Automatik arbeitet.</td></tr>';
    const vorgaenge=(v.vorgaenge||[]).map(x=>`<tr><th scope="row">${AH(x.vorgang)}</th><td>${AH(x.status)}</td><td>${AH(String(x.erledigt))} von ${AH(String(x.schritte))}</td><td>${AH(x.fehler_code||'')}</td><td>${AH(x.gestartet_am)}</td></tr>`).join('')
      ||'<tr><td colspan="5">Kein hängender Vorgang.</td></tr>';
    body.innerHTML=`<p class="muted">Ein Fehler wird einmal geführt und zählt hoch, statt die Liste zu fluten. Nach fünf Versuchen bleibt er liegen — sichtbar, mit Knopf. Endlose Wiederholung ist kein Betrieb.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Fehlerwarteschlange der Automatik</caption><thead><tr><th scope="col">Quelle</th><th scope="col">Fehler</th><th scope="col">Versuche</th><th scope="col">Stand</th><th scope="col">Zuletzt</th><th scope="col">Aktion</th></tr></thead><tbody>${fehler}</tbody></table></div>`
      +`<h4>Hängende Vorgänge</h4><p class="muted">Ein mehrschrittiger Vorgang zeigt, welcher Schritt hält und woran es gescheitert ist. Ein Wiederanlauf überspringt, was schon erledigt ist.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Laufende und gescheiterte Vorgänge</caption><thead><tr><th scope="col">Vorgang</th><th scope="col">Stand</th><th scope="col">Schritte</th><th scope="col">Fehler</th><th scope="col">Begonnen</th></tr></thead><tbody>${vorgaenge}</tbody></table></div>`
      +`<p class="error" id="ah-err" role="alert"></p>`;
    body.querySelectorAll('.ah-wieder').forEach(b=>b.onclick=async()=>{
      try{await ahApi(`/api/automation/failures/${encodeURIComponent(b.dataset.id)}/resume?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await render();}
      catch(e){body.querySelector('#ah-err').textContent=ahText(e.message);}
    });
    body.querySelectorAll('.ah-auf').forEach(b=>b.onclick=async()=>{
      const grund=prompt('Warum wird dieser Fehler nicht weiterverfolgt? (mindestens 10 Zeichen)');
      if(grund===null)return;
      try{await ahApi(`/api/automation/failures/${encodeURIComponent(b.dataset.id)}/abandon?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({grund})});await render();}
      catch(e){body.querySelector('#ah-err').textContent=ahText(e.message);}
    });
  }
  await render();
}

// Probelauf und Aktivierung einer Regel.
async function ahRegel(tenantId,ruleId){
  const {body}=ahModal('Automatikregel: Probelauf');
  async function render(){
    let d;try{d=await ahApi(`/api/workflow-rules/${encodeURIComponent(ruleId)}/simulation?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${AH(ahText(e.message))}</div>`;return;}
    const zeilen=(d.faelle||[]).map(x=>`<tr><th scope="row">${AH(x.erfasst_am)}</th><td>${AH(x.wuerde)}</td></tr>`).join('')
      ||'<tr><td colspan="2">Noch kein Probelauf. Die Regel hat im Simulationsmodus noch keinen Auslöser gefunden.</td></tr>';
    body.innerHTML=`<p><strong>${AH(d.regel.name)}</strong> — Modus ${AH(String(d.regel.modus||'aktiv'))}${d.regel.aktiviert_am?`, scharf seit ${AH(d.regel.aktiviert_am)}`:''}</p>`
      +`<p class="muted">Im Probelauf wertet die Regel ihre Auslöser aus und schreibt auf, was sie tun <em>würde</em> — sie tut es nicht.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Was die Regel getan hätte (${AH(String(d.anzahl))} Fälle)</caption><thead><tr><th scope="col">Zeitpunkt</th><th scope="col">Hätte getan</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<div class="toolbar"><button class="btn secondary" type="button" id="ah-sim">In Probelauf setzen</button><button class="btn" type="button" id="ah-akt">Scharf schalten</button><button class="btn secondary" type="button" id="ah-aus">Abschalten</button></div>`
      +`<p class="error" id="ah-rerr" role="alert"></p>`;
    const modus=async m=>{
      try{await ahApi(`/api/workflow-rules/${encodeURIComponent(ruleId)}/mode?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({modus:m})});await render();}
      catch(e){body.querySelector('#ah-rerr').textContent=ahText(e.message);}
    };
    body.querySelector('#ah-sim').onclick=()=>modus('simulation');
    body.querySelector('#ah-aus').onclick=()=>modus('aus');
    body.querySelector('#ah-akt').onclick=async()=>{
      try{const r=await ahApi(`/api/workflow-rules/${encodeURIComponent(ruleId)}/activate?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
        body.querySelector('#ah-rerr').textContent=`Scharf geschaltet (${r.probelaeufe} Probelauf-Fälle gesehen).`;await render();}
      catch(e){
        if(String(e.message)==='WORKFLOW_PROBELAUF_ERFORDERLICH'){
          const grund=prompt('Diese Regel hatte noch keinen Probelauf. Warum soll sie trotzdem sofort scharf werden? (mindestens 20 Zeichen)');
          if(grund===null)return;
          try{await ahApi(`/api/workflow-rules/${encodeURIComponent(ruleId)}/activate?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({begruendung:grund})});await render();}
          catch(e2){body.querySelector('#ah-rerr').textContent=ahText(e2.message);}
        }else body.querySelector('#ah-rerr').textContent=ahText(e.message);
      }
    };
  }
  await render();
}

(async()=>{
  let me=null;try{me=(await ahApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  if(!me.isPlatformAdmin&&!roles.some(x=>x.role==='tenant_admin'))return;
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(!seite)return;
    const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
    knopf('ah-zustand-launch','Automatik: Zustand',()=>ahZustand(tenantId),anker,'nav');
    knopf('ah-regel-launch','Automatik: Probelauf',()=>{
      const rid=prompt('Kennung der Regel:');if(rid)ahRegel(tenantId,rid).catch(e=>alert(ahText(e.message)));
    },anker,'nav');
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

// Planung: Fassungen bewerten, vergleichen, zurückholen, teilweise neu planen, Rhythmen.
//
// Vorher gab es Fassungen, aber keinen Weg zurück und keinen Vergleich — und geplant wurde ganz
// oder gar nicht. Die Spec verlangt wörtlich „keine unnötige Zerstörung bestehender Pläne".
const PV=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const PV_RHYTHMEN=[['einzelstunde','Einzelstunde'],['doppelstunde','Doppelstunde'],['block','Blockunterricht'],['schicht','Schicht-/Randzeit'],['praxisphase','Praxisphase']];
async function pvApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const pvText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function pvModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="pv-titel" style="width:min(980px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="pv-titel" style="margin:0">${PV(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="pv-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#pv-body'),zu};
}
const pvZahl=v=>PV(String(Math.round(Number(v)||0)));

// 1. Bewerten, vergleichen, zurückholen.
async function pvFassungen(tenantId){
  const {body}=pvModal('Planfassungen: bewerten, vergleichen, zurückholen');
  body.innerHTML=`<p class="muted">Die Bewertung rechnet offene Konflikte, Belastungsverstöße, Raumauslastung und Lücken zusammen. Sie sagt nicht, welche Fassung „besser" ist — sie sagt, worin sie sich unterscheiden.</p>`
    +`<form id="pv-bew"><div class="row"><label class="field">Planfassung<input name="plan_id" required></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Bewerten</button></div></div></form>`
    +`<form id="pv-vgl"><div class="row"><label class="field">Fassung A<input name="a" required></label>`
    +`<label class="field">Fassung B<input name="b" required></label>`
    +`<div class="toolbar"><button class="btn secondary" type="submit">Vergleichen</button></div></div></form>`
    +`<form id="pv-zur"><div class="row"><label class="field">Zielfassung (wird ersetzt)<input name="ziel" required></label>`
    +`<label class="field">Quellfassung (kommt zurück)<input name="quelle" required></label>`
    +`<div class="toolbar"><button class="btn secondary" type="submit">Rückkehr vorschauen</button></div></div></form>`
    +`<p class="error" id="pv-err" role="alert"></p><div id="pv-out"></div>`;
  const out=body.querySelector('#pv-out'),err=body.querySelector('#pv-err');
  body.querySelector('#pv-bew').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target);err.textContent='';
    try{const d=await pvApi(`/api/timetable-plans/${encodeURIComponent(String(f.get('plan_id')))}/score?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
      const k=d.bewertung||d;
      out.innerHTML=`<h4>Bewertung</h4><div style="overflow-x:auto"><table class="table"><caption>Kennzahlen dieser Fassung</caption><tbody>`
        +`<tr><th scope="row">Kennzahl</th><td>${pvZahl(k.kennzahl)}</td></tr>`
        +`<tr><th scope="row">Einträge</th><td>${pvZahl(k.eintraege)}</td></tr>`
        +`<tr><th scope="row">Konflikte (Fehler / Hinweise)</th><td>${pvZahl(k.konflikte_fehler)} / ${pvZahl(k.konflikte_hinweise)}</td></tr>`
        +`<tr><th scope="row">Belastungsverstöße</th><td>${pvZahl(k.belastungsverstoesse)}</td></tr>`
        +`<tr><th scope="row">Raumauslastung</th><td>${pvZahl(k.raumauslastung_prozent)} %</td></tr>`
        +`<tr><th scope="row">Lücken (Teilnehmende / Lehrkräfte)</th><td>${pvZahl(k.luecken_minuten_teilnehmende)} / ${pvZahl(k.luecken_minuten_lehrkraefte)} min</td></tr>`
        +`</tbody></table></div>`;
    }catch(e){err.textContent=pvText(e.message);}
  };
  body.querySelector('#pv-vgl').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target);err.textContent='';
    try{const d=await pvApi(`/api/timetable-plans/compare?tenant_id=${encodeURIComponent(tenantId)}&a=${encodeURIComponent(String(f.get('a')))}&b=${encodeURIComponent(String(f.get('b')))}`);
      const zeilen=(d.unterschiede||[]).map(u=>`<tr><th scope="row">${PV(u.feld||u.art||'')}</th><td>${PV(String(u.a??''))}</td><td>${PV(String(u.b??''))}</td></tr>`).join('')
        ||'<tr><td colspan="3">Keine Unterschiede in den Kennzahlen.</td></tr>';
      out.innerHTML=`<h4>Vergleich</h4><div style="overflow-x:auto"><table class="table"><caption>Was sich zwischen den Fassungen ändert</caption><thead><tr><th scope="col">Merkmal</th><th scope="col">Fassung A</th><th scope="col">Fassung B</th></tr></thead><tbody>${zeilen}</tbody></table></div>`;
    }catch(e){err.textContent=pvText(e.message);}
  };
  body.querySelector('#pv-zur').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target);err.textContent='';
    const ziel=String(f.get('ziel')),quelle=String(f.get('quelle'));
    try{const d=await pvApi(`/api/timetable-plans/${encodeURIComponent(ziel)}/restore-preview?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({quelle_plan_id:quelle})});
      const v=d.vorschau||{};
      out.innerHTML=`<h4>Rückkehr — Vorschau</h4><p>Ersetzt werden ${pvZahl(v.entfernt??v.ersetzt)} Einträge; zurück kommen ${pvZahl(v.hinzugefuegt??v.uebernommen)}.</p>`
        +`<div class="toolbar"><button class="btn danger" type="button" id="pv-go">Jetzt zurückholen</button></div>`;
      out.querySelector('#pv-go').onclick=async()=>{
        try{const r=await pvApi(`/api/timetable-plans/${encodeURIComponent(ziel)}/restore?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({quelle_plan_id:quelle,pruefsumme:v.pruefsumme})});
          out.innerHTML=`<div class="notice">Zurückgeholt. Nachkontrolle: ${PV(String(r.nachkontrolle||r.status||'siehe Läufe'))}.</div>`;}
        catch(e2){err.textContent=pvText(e2.message);}
      };
    }catch(e){err.textContent=pvText(e.message);}
  };
}

// 2. Nur den betroffenen Bereich neu planen.
async function pvTeilplanung(tenantId){
  const {body}=pvModal('Nur den betroffenen Bereich neu planen');
  body.innerHTML=`<p class="muted">Angefasst wird ausschließlich, was Sie hier eingrenzen. Alles andere bleibt unverändert — die Vorschau zählt beides aus, bevor etwas passiert.</p>`
    +`<form id="pv-teil"><div class="row"><label class="field">Planfassung<input name="plan_id" required></label>`
    +`<label class="field">Kurs (optional)<input name="course_id"></label>`
    +`<label class="field">Raum (optional)<input name="room_id"></label></div>`
    +`<div class="row"><label class="field">Von<input name="von" type="date"></label>`
    +`<label class="field">Bis<input name="bis" type="date"></label></div>`
    +`<div class="toolbar"><button class="btn" type="submit">Vorschau</button></div><p class="error" id="pv-terr" role="alert"></p></form><div id="pv-tout"></div>`;
  body.querySelector('#pv-teil').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target),plan=String(f.get('plan_id'));
    const nutzlast={course_id:f.get('course_id')||null,room_id:f.get('room_id')||null,von:f.get('von')||null,bis:f.get('bis')||null};
    try{const d=await pvApi(`/api/timetable-plans/${encodeURIComponent(plan)}/partial-replan/preview?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(nutzlast)});
      const v=d.vorschau||{};
      body.querySelector('#pv-tout').innerHTML=`<div class="notice">Im Bereich: <strong>${pvZahl(v.betroffen)}</strong> Einträge. Unberührt: <strong>${pvZahl(v.unberuehrt)}</strong>.</div>`
        +`<div class="toolbar"><button class="btn danger" type="button" id="pv-tgo">Diesen Bereich neu planen</button></div><div id="pv-tres"></div>`;
      body.querySelector('#pv-tgo').onclick=async()=>{
        try{const r=await pvApi(`/api/timetable-plans/${encodeURIComponent(plan)}/partial-replan?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(nutzlast)});
          body.querySelector('#pv-tres').innerHTML=`<div class="notice">Neu geplant: ${pvZahl(r.neu_geplant??r.betroffen)} · unverändert geblieben: ${pvZahl(r.unberuehrt)}.</div>`;}
        catch(e2){body.querySelector('#pv-terr').textContent=pvText(e2.message);}
      };
    }catch(e){body.querySelector('#pv-terr').textContent=pvText(e.message);}
  };
}

// 3. Konfliktvorschläge — der mit der geringsten Eingriffstiefe zuerst.
async function pvVorschlaege(tenantId){
  const {body}=pvModal('Konflikte: Lösungsvorschläge');
  body.innerHTML=`<form id="pv-vor"><label class="field">Planfassung<input name="plan_id" required></label><div class="toolbar"><button class="btn" type="submit">Vorschläge holen</button></div><p class="error" id="pv-verr" role="alert"></p></form><div id="pv-vout"></div>`;
  body.querySelector('#pv-vor').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target);
    try{const d=await pvApi(`/api/timetable-plans/${encodeURIComponent(String(f.get('plan_id')))}/suggestions?tenant_id=${encodeURIComponent(tenantId)}`);
      const zeilen=(d.vorschlaege||[]).map(v=>`<tr><th scope="row">${PV(v.konflikt||v.art||'')}</th><td>${PV(v.vorschlag||v.beschreibung||'')}</td><td>${pvZahl(v.verschiebt??v.eingriffstiefe)}</td><td>${PV(v.begruendung||'')}</td></tr>`).join('')
        ||'<tr><td colspan="4">Keine offenen Konflikte.</td></tr>';
      body.querySelector('#pv-vout').innerHTML=`<p class="muted">Sortiert nach Eingriffstiefe: je weniger bestehende Einträge ein Vorschlag verschiebt, desto weiter oben steht er.</p>`
        +`<div style="overflow-x:auto"><table class="table"><caption>Vorschläge zu offenen Konflikten</caption><thead><tr><th scope="col">Konflikt</th><th scope="col">Vorschlag</th><th scope="col">Verschiebt</th><th scope="col">Warum</th></tr></thead><tbody>${zeilen}</tbody></table></div>`;
    }catch(e){body.querySelector('#pv-verr').textContent=pvText(e.message);}
  };
}

// 4. Rhythmen: Block, Doppelstunde, Schicht, Praxisphase.
async function pvRhythmen(tenantId){
  const {body}=pvModal('Unterrichtsrhythmen');
  async function render(){
    let d;try{d=await pvApi(`/api/teaching-rhythms?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${PV(pvText(e.message))}</div>`;return;}
    const zeilen=(d.regeln||[]).map(r=>`<tr><th scope="row">${PV(r.name)}</th><td>${PV((PV_RHYTHMEN.find(x=>x[0]===r.rhythmus)||[,r.rhythmus])[1])}</td><td>${pvZahl(r.einheit_minuten)} min × ${pvZahl(r.einheiten_je_block)}</td><td>${PV(r.frueheste_zeit||'')}–${PV(r.spaeteste_zeit||'')}</td><td>${Number(r.zaehlt_als_unterricht)===1?'Unterricht':'keine Unterrichtszeit'}</td>`
      +`<td><button class="btn secondary pv-del" type="button" data-id="${PV(r.id)}">Löschen</button></td></tr>`).join('')
      ||'<tr><td colspan="6">Kein Rhythmus angelegt. Ohne Rhythmus plant das System nur Einzelstunden.</td></tr>';
    body.innerHTML=`<p class="muted">Ein Block ist nicht dasselbe wie zwei Einzelstunden hintereinander, und eine Praxisphase ist eine Abwesenheit vom Unterricht — keine Lücke.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Angelegte Rhythmen</caption><thead><tr><th scope="col">Name</th><th scope="col">Art</th><th scope="col">Einheiten</th><th scope="col">Zeitfenster</th><th scope="col">Zählung</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<h4>Neuer Rhythmus</h4><form id="pv-rneu"><div class="row"><label class="field">Name<input name="name" required></label>`
      +`<label class="field">Art<select name="rhythmus">${PV_RHYTHMEN.map(x=>`<option value="${x[0]}">${x[1]}</option>`).join('')}</select></label>`
      +`<label class="field">Kurs (optional)<input name="course_id"></label></div><div class="row">`
      +`<label class="field">Minuten je Einheit<input name="einheit_minuten" type="number" min="5" max="480" value="45"></label>`
      +`<label class="field">Einheiten je Block<input name="einheiten_je_block" type="number" min="1" max="12" value="2"></label>`
      +`<label class="field">Pause im Block (min)<input name="pause_im_block_minuten" type="number" min="0" max="120" value="0"></label></div><div class="row">`
      +`<label class="field">Frühester Beginn<input name="frueheste_zeit" type="time" value="08:00"></label>`
      +`<label class="field">Spätestes Ende<input name="spaeteste_zeit" type="time" value="17:00"></label></div>`
      +`<div class="toolbar"><button class="btn" type="submit">Rhythmus speichern</button></div><p class="error" id="pv-rerr" role="alert"></p></form>`
      +`<h4>Auf eine Planfassung anwenden</h4><form id="pv-ranw"><div class="row"><label class="field">Planfassung<input name="plan_id" required></label>`
      +`<label class="field">Rhythmus (Kennung)<input name="rule_id" required></label></div><div class="row">`
      +`<label class="field">Von<input name="von" type="date" required></label><label class="field">Bis<input name="bis" type="date" required></label></div>`
      +`<div class="toolbar"><button class="btn secondary" type="submit">Anwenden</button></div><p class="error" id="pv-aerr" role="alert"></p></form>`;
    body.querySelector('#pv-rneu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await pvApi(`/api/teaching-rhythms?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(Object.fromEntries(f.entries()))});await render();}
      catch(e){body.querySelector('#pv-rerr').textContent=pvText(e.message);}
    };
    body.querySelector('#pv-ranw').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{const r=await pvApi(`/api/timetable-plans/${encodeURIComponent(String(f.get('plan_id')))}/apply-rhythm?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
        body:JSON.stringify({rule_id:f.get('rule_id'),von:f.get('von'),bis:f.get('bis')})});
        body.querySelector('#pv-aerr').textContent=`Angewendet: ${Math.round(Number(r.erzeugt??r.eintraege??0))} Einheiten.`;}
      catch(e){body.querySelector('#pv-aerr').textContent=pvText(e.message);}
    };
    body.querySelectorAll('.pv-del').forEach(b=>b.onclick=async()=>{
      try{await pvApi(`/api/teaching-rhythms/${encodeURIComponent(b.dataset.id)}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'DELETE'});await render();}
      catch(e){alert(pvText(e.message));}
    });
  }
  await render();
}

(async()=>{
  let me=null;try{me=(await pvApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  if(!me.isPlatformAdmin&&!roles.some(x=>['tenant_admin','class_admin'].includes(x.role)))return;
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');if(!seite)return;
    const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
    knopf('pv-fassungen-launch','Planfassungen',()=>pvFassungen(tenantId),anker,'nav');
    knopf('pv-teil-launch','Teilbereich neu planen',()=>pvTeilplanung(tenantId),anker,'nav');
    knopf('pv-vorschlaege-launch','Konfliktvorschläge',()=>pvVorschlaege(tenantId),anker,'nav');
    knopf('pv-rhythmen-launch','Unterrichtsrhythmen',()=>pvRhythmen(tenantId),anker,'nav');
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

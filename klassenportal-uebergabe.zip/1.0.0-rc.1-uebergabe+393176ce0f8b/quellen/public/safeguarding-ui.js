// Kinderschutz in der Oberfläche.
//
// Zwei getrennte Sichten, weil es zwei getrennte Rechtsstellungen sind:
//  - Melden darf jeder, der zum Träger gehört. Ohne Rolle, ohne Rückfrage, ohne Schwelle.
//  - Lesen dürfen nur die benannten Fachkräfte. Verwaltungsrechte reichen ausdrücklich nicht.
const SG=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const SG_KATEGORIEN=[['vernachlaessigung','Vernachlässigung'],['koerperliche_gewalt','Körperliche Gewalt'],['sexualisierte_gewalt','Sexualisierte Gewalt'],['selbstgefaehrdung','Selbstgefährdung'],['mobbing','Mobbing'],['sonstiges','Sonstiges']];
const SG_DRINGLICHKEIT=[['akut','Akut – heute'],['hoch','Hoch – 24 Stunden'],['normal','Normal – 3 Tage']];
async function sgApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const sgText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function sgModal(titel,breite='min(880px,96vw)'){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="sg-titel" style="width:${breite};max-height:92vh;overflow:auto"><div class="top"><h3 id="sg-titel" style="margin:0">${SG(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="sg-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{w,body:w.querySelector('#sg-body'),zu};
}

// 1. Melden - für alle.
async function sgMelden(tenantId){
  const {body}=sgModal('Kinderschutz: etwas melden');
  body.innerHTML=`<p class="muted">Eine Meldung ist kein Vorwurf und keine Diagnose. Sie beschreibt, was Sie beobachtet haben. Die benannten Fachkräfte sehen sie sofort; sonst niemand.</p>`
    +`<form id="sg-neu"><div class="row">`
    +`<label class="field">Kategorie<select name="kategorie" required>${SG_KATEGORIEN.map(k=>`<option value="${k[0]}">${k[1]}</option>`).join('')}</select></label>`
    +`<label class="field">Dringlichkeit<select name="dringlichkeit">${SG_DRINGLICHKEIT.map(d=>`<option value="${d[0]}"${d[0]==='normal'?' selected':''}>${d[1]}</option>`).join('')}</select></label>`
    +`<label class="field">Betroffene Person (Kennung, falls bekannt)<input name="betroffene_person"></label></div>`
    +`<label class="field">Was haben Sie beobachtet?<textarea name="sachverhalt" rows="6" required minlength="20" placeholder="Konkret: wann, was, wer war dabei."></textarea></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Meldung absenden</button></div><p class="error" id="sg-err" role="alert"></p></form>`
    +`<div id="sg-eigene"></div>`;
  async function eigene(){
    try{const d=await sgApi(`/api/safeguarding/my-reports?tenant_id=${encodeURIComponent(tenantId)}`);
      const zeilen=(d.meldungen||[]).map(m=>`<tr><th scope="row">${SG(m.created_at)}</th><td>${SG((SG_KATEGORIEN.find(k=>k[0]===m.kategorie)||[,m.kategorie])[1])}</td><td>${SG(m.status)}</td></tr>`).join('');
      document.querySelector('#sg-eigene').innerHTML=zeilen?`<h4>Ihre bisherigen Meldungen</h4><div style="overflow-x:auto"><table class="table"><caption>Eigene Meldungen und ihr Bearbeitungsstand</caption><thead><tr><th scope="col">Eingegangen</th><th scope="col">Kategorie</th><th scope="col">Stand</th></tr></thead><tbody>${zeilen}</tbody></table></div>`:'';
    }catch{/* eigene Liste ist Beiwerk; die Meldung selbst zählt */}
  }
  await eigene();
  body.querySelector('#sg-neu').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target);
    try{
      const r=await sgApi(`/api/safeguarding/reports?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        kategorie:f.get('kategorie'),dringlichkeit:f.get('dringlichkeit'),betroffene_person:f.get('betroffene_person')||null,sachverhalt:f.get('sachverhalt')})});
      ev.target.reset();
      body.querySelector('#sg-err').textContent=r.ohne_fachkraft
        ? 'Aufgenommen – aber es ist noch keine Kinderschutzfachkraft benannt. Bitte die Leitung darauf hinweisen.'
        : `Aufgenommen. ${r.benachrichtigt} Fachkraft/Fachkräfte wurden benachrichtigt, Frist: ${r.frist_am}.`;
      await eigene();
    }catch(e){body.querySelector('#sg-err').textContent=sgText(e.message);}
  };
}

// 2. Bearbeiten - nur für benannte Fachkräfte.
async function sgFaelle(tenantId){
  const {body}=sgModal('Kinderschutz: Fälle');
  async function liste(){
    let d;
    try{d=await sgApi(`/api/safeguarding/reports?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${SG(sgText(e.message))}</div>`;return;}
    const zeilen=(d.faelle||[]).map(f=>`<tr><th scope="row">${SG(f.created_at)}</th><td>${SG((SG_KATEGORIEN.find(k=>k[0]===f.kategorie)||[,f.kategorie])[1])}</td><td>${SG(f.dringlichkeit)}</td><td>${SG(f.frist_am)}</td><td>${SG(f.status)}</td><td><button class="btn secondary sg-open" type="button" data-id="${SG(f.id)}">Öffnen</button></td></tr>`).join('')
      ||'<tr><td colspan="6">Keine offenen Fälle.</td></tr>';
    body.innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Offene Kinderschutzfälle</caption><thead><tr><th scope="col">Eingegangen</th><th scope="col">Kategorie</th><th scope="col">Dringlichkeit</th><th scope="col">Frist</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div><div id="sg-detail"></div>`;
    body.querySelectorAll('.sg-open').forEach(b=>b.onclick=()=>detail(b.dataset.id));
  }
  async function detail(fallId){
    const ziel=body.querySelector('#sg-detail');
    let d;
    try{d=await sgApi(`/api/safeguarding/reports/${encodeURIComponent(fallId)}?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){ziel.innerHTML=`<div class="notice bad">${SG(sgText(e.message))}</div>`;return;}
    const verlauf=(d.verlauf||[]).map(n=>`<li><strong>${SG(n.erfasst_am)}</strong> · ${SG(n.art)}: ${SG(n.text)}</li>`).join('')||'<li>Noch kein Eintrag.</li>';
    ziel.innerHTML=`<h4>Fall vom ${SG(d.fall.created_at)}</h4><p><strong>Sachverhalt:</strong> ${SG(d.fall.sachverhalt)}</p>`
      +`<p class="muted">Frist ${SG(d.fall.frist_am)} · Stand ${SG(d.fall.status)}${d.fall.eskaliert_an?` · eskaliert an ${SG(d.fall.eskaliert_an)}`:''}</p>`
      +`<h5>Verlauf</h5><ul>${verlauf}</ul>`
      +`<form id="sg-notiz"><label class="field">Eintrag hinzufügen<textarea name="text" rows="3" required></textarea></label>`
      +`<label class="field">Art<select name="art"><option value="notiz">Notiz</option><option value="gespraech">Gespräch</option><option value="massnahme">Maßnahme</option></select></label>`
      +`<div class="toolbar"><button class="btn secondary" type="submit">Eintragen</button></div></form>`
      +`<form id="sg-status"><div class="row"><label class="field">Bearbeitungsstand<select name="status"><option value="in_bearbeitung">In Bearbeitung</option><option value="eskaliert">Eskaliert</option><option value="abgeschlossen">Abgeschlossen</option></select></label>`
      +`<label class="field">Stelle (bei Eskalation)<input name="eskaliert_an" placeholder="Jugendamt, Beratungsstelle, Polizei"></label></div>`
      +`<label class="field">Begründung<input name="grund"></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Stand setzen</button></div><p class="error" id="sg-derr" role="alert"></p></form>`;
    ziel.querySelector('#sg-notiz').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await sgApi(`/api/safeguarding/reports/${encodeURIComponent(fallId)}/notes?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({text:f.get('text'),art:f.get('art')})});await detail(fallId);}
      catch(e){ziel.querySelector('#sg-derr').textContent=sgText(e.message);}
    };
    ziel.querySelector('#sg-status').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await sgApi(`/api/safeguarding/reports/${encodeURIComponent(fallId)}/status?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({status:f.get('status'),grund:f.get('grund'),eskaliert_an:f.get('eskaliert_an')})});await liste();}
      catch(e){ziel.querySelector('#sg-derr').textContent=sgText(e.message);}
    };
  }
  await liste();
}

// 3. Benennen - Leitungsaufgabe. Einsicht folgt der Benennung, nicht dem Verwaltungsrecht.
async function sgFachkraefte(tenantId){
  const {body}=sgModal('Kinderschutz: Fachkräfte benennen');
  async function render(){
    let d,u;
    try{[d,u]=await Promise.all([sgApi(`/api/safeguarding/officers?tenant_id=${encodeURIComponent(tenantId)}`),sgApi(`/api/tenant/users?tenant_id=${encodeURIComponent(tenantId)}`)]);}
    catch(e){body.innerHTML=`<div class="notice bad">${SG(sgText(e.message))}</div>`;return;}
    const namen=new Map((u.users||[]).map(x=>[x.id,x.display_name]));
    const zeilen=(d.fachkraefte||[]).map(f=>`<tr><th scope="row">${SG(namen.get(f.user_id)||f.user_id)}</th><td>${SG(f.rolle)}</td><td><button class="btn secondary sg-del" type="button" data-id="${SG(f.user_id)}">Benennung beenden</button></td></tr>`).join('')
      ||'<tr><td colspan="3">Noch niemand benannt. Bis dahin erreicht eine Meldung niemanden.</td></tr>';
    body.innerHTML=`<p class="muted">Einsicht in Kinderschutzfälle hat nur, wer hier steht – Verwaltungsrechte genügen ausdrücklich nicht. Wer selbst betroffen ist, sieht den eigenen Fall auch dann nicht.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Benannte Kinderschutzfachkräfte</caption><thead><tr><th scope="col">Person</th><th scope="col">Rolle</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<form id="sg-ben"><div class="row"><label class="field">Person<select name="user_id" required><option value="">– wählen –</option>${(u.users||[]).map(x=>`<option value="${SG(x.id)}">${SG(x.display_name)}</option>`).join('')}</select></label>`
      +`<label class="field">Rolle<select name="rolle"><option value="fachkraft">Fachkraft</option><option value="stellvertretung">Stellvertretung</option><option value="externe_stelle">Externe Stelle</option></select></label></div>`
      +`<div class="toolbar"><button class="btn" type="submit">Benennen</button></div><p class="error" id="sg-berr" role="alert"></p></form>`;
    body.querySelector('#sg-ben').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await sgApi(`/api/safeguarding/officers?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({user_id:f.get('user_id'),rolle:f.get('rolle')})});await render();}
      catch(e){body.querySelector('#sg-berr').textContent=sgText(e.message);}
    };
    body.querySelectorAll('.sg-del').forEach(b=>b.onclick=async()=>{
      try{await sgApi(`/api/safeguarding/officers/${encodeURIComponent(b.dataset.id)}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'DELETE'});await render();}
      catch(e){alert(sgText(e.message));}
    });
  }
  await render();
}

(async()=>{
  let me=null;try{me=(await sgApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(seite){
      const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
      knopf('sg-melden-launch','Kinderschutz melden',()=>sgMelden(tenantId),anker,'nav');
      knopf('sg-faelle-launch','Kinderschutz: Fälle',()=>sgFaelle(tenantId),anker,'nav');
      if(me.isPlatformAdmin||roles.some(x=>x.role==='tenant_admin'))knopf('sg-fachkraefte-launch','Kinderschutz: Fachkräfte',()=>sgFachkraefte(tenantId),anker,'nav');
    }
    const portal=document.querySelector('.portal-main');
    if(portal&&!document.querySelector('#sg-portal-btn')){
      const b=document.createElement('button');b.id='sg-portal-btn';b.type='button';b.className='portal-btn secondary';b.textContent='Etwas melden (Kinderschutz)';
      b.onclick=()=>sgMelden(tenantId).catch(e=>alert(sgText(e.message)));
      (document.querySelector('#gs-portal-buttons')||portal).append(b);
    }
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

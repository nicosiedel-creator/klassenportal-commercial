const LS=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function lsApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json()}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const qp=(p,t,c)=>`${p}${p.includes('?')?'&':'?'}tenant_id=${encodeURIComponent(t)}${c?`&course_id=${encodeURIComponent(c)}`:''}`;
async function scope(){const me=(await lsApi('/api/auth/me')).user;if(!me)return null;let tenantId=document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||'',courseId=new URLSearchParams(location.search).get('course_id')||'';const roles=me.tenantRoles||[];if(!tenantId){const ids=[...new Set(roles.filter(x=>['tenant_admin','class_admin'].includes(x.role)).map(x=>x.tenantId))];if(ids.length===1)tenantId=ids[0];}if(!courseId){const exact=roles.find(x=>x.tenantId===tenantId&&x.role==='class_admin'&&x.courseId);if(exact)courseId=exact.courseId;}if(!tenantId)return null;const courses=(await lsApi(`/api/courses?tenant_id=${encodeURIComponent(tenantId)}`)).courses||[];if(!courseId&&courses.length===1)courseId=courses[0].id;return{me,tenantId,courseId,courses};}
function modal(){const w=document.createElement('div');w.className='modal-back';w.innerHTML=`<div class="modal" style="width:min(1220px,97vw);max-height:95vh;overflow:auto"><div class="top"><div><h3 style="margin:0">Lernen, Quiz, Vorlagen & Berichte</h3><div class="muted">Offizielle Bewertungen, Online-Tests, wiederverwendbare Kursvorlagen, sichere Berichte und Kursforum.</div></div><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div id="ls-work" style="margin-top:14px"></div></div>`;document.body.append(w);w.querySelector('[data-close]').onclick=()=>w.remove();w.addEventListener('click',e=>{if(e.target===w)w.remove()});return w;}
async function openWorkspace(){const s=await scope();if(!s)return alert('Kein eindeutiger Kundenbereich verfügbar.');const w=modal(),host=w.querySelector('#ls-work');let activeCourse=s.courseId||s.courses[0]?.id||'';if(!activeCourse)return host.innerHTML='<div class="notice warn">Bitte zuerst eine Klasse oder einen Kurs anlegen.</div>';
  async function render(tab='gradebook'){const course=s.courses.find(x=>String(x.id)===String(activeCourse));host.innerHTML=`<div class="card"><div class="row" style="align-items:end"><label class="field">Klasse / Kurs<select id="ls-course">${s.courses.map(c=>`<option value="${LS(c.id)}" ${String(c.id)===String(activeCourse)?'selected':''}>${LS(c.name)}</option>`).join('')}</select></label><div class="toolbar"><button class="btn secondary ls-tab" data-tab="gradebook">Bewertungsbuch</button><button class="btn secondary ls-tab" data-tab="quiz">Quiz & Tests</button><button class="btn secondary ls-tab" data-tab="nta">Nachteilsausgleich</button><button class="btn secondary ls-tab" data-tab="raster">Bewertungsraster</button><button class="btn secondary ls-tab" data-tab="kompetenz">Kompetenzen</button><button class="btn secondary ls-tab" data-tab="einspruch">Einsprüche</button><button class="btn secondary ls-tab" data-tab="templates">Vorlagen</button><button class="btn secondary ls-tab" data-tab="reports">Berichte</button><button class="btn secondary ls-tab" data-tab="forum">Forum</button></div></div><div class="muted">${LS(course?.name||'')}</div></div><div id="ls-pane" style="margin-top:14px"></div>`;host.querySelector('#ls-course').onchange=e=>{activeCourse=e.target.value;render(tab)};host.querySelectorAll('.ls-tab').forEach(b=>b.onclick=()=>pane(b.dataset.tab));await pane(tab);}
  async function pane(tab){const p=host.querySelector('#ls-pane');p.innerHTML='<div class="card">Lädt …</div>';try{if(tab==='gradebook')await gradebook(p);if(tab==='quiz')await quiz(p);if(tab==='nta')await nachteilsausgleich(p);if(tab==='raster')await raster(p);if(tab==='kompetenz')await kompetenzen(p);if(tab==='einspruch')await einsprueche(p);if(tab==='templates')await templates(p);if(tab==='reports')await reports(p);if(tab==='forum')await forum(p);}catch(e){p.innerHTML=`<div class="notice bad">${LS(e.message)}</div>`;}}
  async function gradebook(p){const d=await lsApi(qp('/api/learning-suite/gradebook',s.tenantId,activeCourse)),r=await lsApi(qp('/api/learning-suite/gradebook/report',s.tenantId,activeCourse));p.innerHTML=`<div class="grid"><div class="card"><h3>Kategorien & Gewichtung</h3>${(d.categories||[]).map(c=>`<div class="item"><strong>${LS(c.name)}</strong><div class="muted">${Number(c.weight_basis_points||0)/100}% · niedrigste ${LS(c.drop_lowest||0)} streichen</div></div>`).join('')||'<p class="muted">Noch keine Kategorien.</p>'}<form id="ls-cat"><label class="field">Kategorie<input name="name" required placeholder="z. B. Klausuren"></label><div class="row"><label class="field">Gewicht %<input name="weight" type="number" min="0" max="100" step="0.01" value="0"></label><label class="field">Niedrigste Ergebnisse streichen<input name="drop" type="number" min="0" max="20" value="0"></label></div><button class="btn">Kategorie speichern</button></form></div><div class="card"><h3>Notenschlüssel</h3><p class="muted">Kein Notenschlüssel wird geraten. Erst nach ausdrücklichem Speichern wird Prozent → Note abgeleitet.</p><form id="ls-scale"><label class="field">Bezeichnung<input name="name" value="Notenschlüssel" required></label><label class="field">Bereiche – je Zeile: Note;Minimum;Maximum<textarea name="items" rows="7" placeholder="1;92;100&#10;2;81;91.99&#10;3;67;80.99"></textarea></label><button class="btn">Notenschlüssel speichern</button></form></div></div><div class="card" style="margin-top:14px"><div class="top"><h3 style="margin:0">Gesamtübersicht</h3><a class="btn secondary" href="${LS(qp('/api/learning-suite/gradebook/export.csv',s.tenantId,activeCourse))}">CSV exportieren</a></div><div class="table-wrap"><table><tr><th scope="col">Teilnehmer</th><th scope="col">E-Mail</th><th scope="col">Gesamt %</th><th scope="col">Note</th><th scope="col">Gewichtung vollständig</th></tr>${(r.rows||[]).map(x=>`<tr><td>${LS(x.name)}</td><td>${LS(x.email)}</td><td>${x.percent===''?'—':LS(x.percent)}</td><td>${LS(x.grade||'—')}</td><td>${Number(x.weight_complete_basis_points||0)/100}%</td></tr>`).join('')}</table></div></div>`;
    p.querySelector('#ls-cat').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget);await lsApi(qp('/api/learning-suite/gradebook/categories',s.tenantId,activeCourse),{method:'PUT',body:JSON.stringify({name:f.get('name'),weight_basis_points:Math.round(Number(f.get('weight'))*100),drop_lowest:Number(f.get('drop'))})});await gradebook(p);};p.querySelector('#ls-scale').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget),items=String(f.get('items')||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean).map(line=>{const [label,min,max]=line.split(';');return{label,min_percent:Number(min),max_percent:Number(max)}});await lsApi(qp('/api/learning-suite/gradebook/scales',s.tenantId,activeCourse),{method:'PUT',body:JSON.stringify({name:f.get('name'),is_default:true,items})});await gradebook(p);};}
  async function quiz(p){const [banksD,quizzesD]=await Promise.all([lsApi(qp('/api/learning-suite/question-banks',s.tenantId,activeCourse)),lsApi(qp('/api/learning-suite/quizzes',s.tenantId,activeCourse))]),banks=banksD.banks||[],quizzes=quizzesD.quizzes||[];let selected=banks[0]?.id||'',questions=selected?(await lsApi(qp(`/api/learning-suite/question-banks/${encodeURIComponent(selected)}/questions`,s.tenantId,activeCourse))).questions||[]:[];p.innerHTML=`<div class="grid"><div class="card"><h3>Fragenkatalog</h3><div class="row"><form id="ls-bank"><label class="field">Neuer Katalog<input name="title" required></label><button class="btn">Anlegen</button></form>${banks.length?`<label class="field">Katalog<select id="ls-bank-pick">${banks.map(b=>`<option value="${LS(b.id)}">${LS(b.title)} (${LS(b.question_count)})</option>`).join('')}</select></label>`:''}</div>${selected?`<form id="ls-question"><label class="field">Fragetyp<select name="type"><option value="single_choice">Eine richtige Antwort</option><option value="multiple_choice">Mehrere richtige Antworten</option><option value="true_false">Richtig / Falsch</option><option value="numeric">Zahl</option><option value="short_text">Kurztext – manuell</option><option value="long_text">Freitext – manuell</option></select></label><label class="field">Frage<textarea name="prompt" required></textarea></label><label class="field">Antworten – je Zeile; richtige Antwort mit * markieren<textarea name="options" placeholder="*Berlin&#10;Bonn&#10;Hamburg"></textarea></label><label class="field">Numerische Lösung (nur Zahl-Frage)<input name="numeric_answer" type="number" step="any"></label><label class="field">Punkte<input name="max_points" type="number" min="0.1" step="0.1" value="1"></label><button class="btn">Frage hinzufügen</button></form>`:'<p class="muted">Lege zuerst einen Fragenkatalog an.</p>'}</div><div class="card"><h3>Tests</h3>${quizzes.map(q=>`<div class="item"><strong>${LS(q.title)}</strong> <span class="pill">${LS(q.status)}</span>${q.status==='draft'?` <button class="btn secondary ls-pub" data-id="${LS(q.id)}">Veröffentlichen</button>`:''} <button class="btn secondary ls-var" data-id="${LS(q.id)}" data-title="${LS(q.title)}">Prüfungsvarianten</button> <button class="btn secondary ls-seb" data-id="${LS(q.id)}" data-req="${Number(q.seb_required)?'1':''}" data-bek="${LS(q.seb_browser_exam_keys||'')}" data-ck="${LS(q.seb_config_keys||'')}">Prüfungssperre</button><div class="muted">${Number(q.seb_required)?'Safe Exam Browser vorgeschrieben':'Ohne Prüfungssperre – im gewöhnlichen Browser schreibbar'}</div></div>`).join('')||'<p class="muted">Noch kein Online-Test.</p>'}${questions.length?`<form id="ls-quiz"><label class="field">Titel<input name="title" required></label><label class="field">Zeitlimit Minuten<input name="limit" type="number" min="1" max="1440"></label><label class="field">Versuche<input name="attempts" type="number" min="1" max="20" value="1"></label><fieldset><legend>Fragen</legend>${questions.map(q=>`<label style="display:block"><input type="checkbox" name="qid" value="${LS(q.id)}"> ${LS(q.prompt)} (${LS(q.max_points)} P.)</label>`).join('')}</fieldset><button class="btn">Quiz anlegen</button></form>`:'<p class="muted">Für ein Quiz werden Fragen benötigt.</p>'}</div></div>`;
    p.querySelector('#ls-bank').onsubmit=async e=>{e.preventDefault();await lsApi(qp('/api/learning-suite/question-banks',s.tenantId,activeCourse),{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.currentTarget)))});await quiz(p);};const pick=p.querySelector('#ls-bank-pick');if(pick)pick.onchange=async()=>{const next=pick.value,qs=(await lsApi(qp(`/api/learning-suite/question-banks/${encodeURIComponent(next)}/questions`,s.tenantId,activeCourse))).questions||[];selected=next;questions=qs;await quiz(p);};const qform=p.querySelector('#ls-question');if(qform)qform.onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget),type=String(f.get('type')),lines=String(f.get('options')||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean),options=lines.map(x=>({label:x.replace(/^\*/,''),correct:x.startsWith('*')}));if(type==='true_false'&&!options.length)options.push({label:'Richtig',correct:true},{label:'Falsch',correct:false});await lsApi(qp(`/api/learning-suite/question-banks/${encodeURIComponent(selected)}/questions`,s.tenantId,activeCourse),{method:'POST',body:JSON.stringify({type,prompt:f.get('prompt'),max_points:Number(f.get('max_points')),numeric_answer:f.get('numeric_answer'),options})});await quiz(p);};const quizForm=p.querySelector('#ls-quiz');if(quizForm)quizForm.onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget),ids=f.getAll('qid');if(!ids.length)return alert('Bitte mindestens eine Frage auswählen.');await lsApi(qp('/api/learning-suite/quizzes',s.tenantId,activeCourse),{method:'POST',body:JSON.stringify({title:f.get('title'),question_ids:ids,time_limit_minutes:f.get('limit')?Number(f.get('limit')):null,max_attempts:Number(f.get('attempts')),randomize_questions:true,randomize_options:true,show_results_mode:'after_close'})});await quiz(p);};p.querySelectorAll('.ls-var').forEach(b=>b.onclick=()=>variantenModal(b.dataset.id,b.dataset.title,()=>quiz(p)).catch(e=>alert(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(e.message):e.message)));p.querySelectorAll('.ls-seb').forEach(b=>b.onclick=()=>sebModal(b.dataset.id,b.dataset.req==='1',b.dataset.bek,b.dataset.ck,()=>quiz(p)));p.querySelectorAll('.ls-pub').forEach(b=>b.onclick=async()=>{if(!confirm('Quiz für Teilnehmer veröffentlichen?'))return;await lsApi(qp(`/api/learning-suite/quizzes/${encodeURIComponent(b.dataset.id)}/publish`,s.tenantId,activeCourse),{method:'POST',body:'{}'});await quiz(p);});}
  // Nachteilsausgleich: Pflicht fuer jeden Traeger, der Pruefungen abnimmt (Art. 3 Abs. 3 GG,
  // §§ 2, 16 BGG, § 65 BBiG). Bewusst OHNE Feld fuer die Diagnose - Gesundheitsdaten sind
  // Art. 9 DSGVO und gehoeren nicht in die Pruefungsverwaltung. Erfasst wird die Auswirkung.
  // Prüfungsvarianten. Ohne sie schreiben alle dieselbe Arbeit: Nebensitzende sehen denselben
  // Bogen, und ein Nachschreibtermin ist entweder dieselbe Arbeit oder eine unverbundene neue.
  // Gleichwertig heißt gleiche Aufgabenzahl und gleiche Punktsumme - nicht gleiche Verteilung.
  async function variantenModal(quizId,titel,danach){
    const w2=document.createElement('div');w2.className='modal-back';
    w2.innerHTML=`<div class="modal" style="width:min(900px,96vw);max-height:92vh;overflow:auto"><div class="top"><div><h3 style="margin:0">Prüfungsvarianten</h3><div class="muted">${LS(titel||'')}</div></div><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div id="var-body">Lädt …</div></div>`;
    document.body.append(w2);
    const zu=()=>{w2.remove();danach&&danach();};w2.querySelector('[data-close]').onclick=zu;w2.onclick=e=>{if(e.target===w2)zu();};
    const body=w2.querySelector('#var-body');
    async function zeichne(){
      let d;try{d=await lsApi(qp(`/api/learning-suite/quizzes/${encodeURIComponent(quizId)}/variants`,s.tenantId,activeCourse));}
      catch(err){body.innerHTML=`<div class="notice bad">${LS(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message)}</div>`;return;}
      const varianten=d.varianten||[],zuweisungen=d.zuweisungen||[],personen=d.teilnehmer||[],fragen=d.fragen||[];
      const aktiv=varianten.filter(v=>v.status==='aktiv');
      body.innerHTML=`<p class="muted">Eine Variante gilt erst nach der Freigabe. Freigegeben wird nur, was dieselbe Aufgabenzahl und dieselbe Punktsumme hat wie die übrigen Varianten und die Grundfassung – sonst würden Teilnehmende nach verschiedenen Maßstäben bewertet.</p>`
        +(varianten.length?varianten.map(v=>`<div class="item"><strong>${LS(v.label)}</strong> <span class="pill">${LS(v.status)}</span>${Number(v.nur_auf_zuweisung)?' <span class="pill">nur auf Zuweisung</span>':''}`
          +`<div class="muted">${LS(v.fragen)} Aufgaben · ${LS(v.punkte)} Punkte</div>`
          +(v.status==='entwurf'?` <button class="btn secondary var-akt" data-id="${LS(v.id)}">Freigeben</button>`:'')
          +(v.status==='aktiv'?` <button class="btn secondary var-arch" data-id="${LS(v.id)}">Archivieren</button>`:'')
          +`</div>`).join(''):'<p class="muted">Noch keine Variante angelegt – alle schreiben dieselbe Arbeit.</p>')
        +(fragen.length?`<h4>Neue Variante</h4><form id="var-neu"><div class="row"><label class="field">Bezeichnung<input name="label" required maxlength="60" placeholder="B"></label>`
          +`<label style="align-self:end"><input type="checkbox" name="nur_auf_zuweisung"> nur auf Zuweisung (Nachschreibtermin)</label></div>`
          +`<fieldset><legend>Aufgaben</legend>${fragen.map(f=>`<label style="display:block"><input type="checkbox" name="qid" value="${LS(f.id)}"> ${LS(f.prompt)} (${LS(f.max_points)} P.)</label>`).join('')}</fieldset>`
          +`<button class="btn">Variante anlegen</button></form><div id="var-err"></div>`:'<p class="muted">Für Varianten werden Aufgaben in den Fragenkatalogen dieses Kurses benötigt.</p>')
        +(aktiv.length&&personen.length?`<h4>Gezielte Zuweisung</h4><p class="muted">Ohne Zuweisung verteilt der Server die Bögen gleichmäßig und nachrechenbar. Eine Zuweisung braucht es für den Nachschreibtermin.</p>`
          +`<form id="var-zu"><div class="row"><label class="field">Person<select name="user_id">${personen.map(u=>`<option value="${LS(u.id)}">${LS(u.display_name)}</option>`).join('')}</select></label>`
          +`<label class="field">Variante<select name="variant_id"><option value="">– Zuweisung aufheben –</option>${aktiv.map(v=>`<option value="${LS(v.id)}">${LS(v.label)}</option>`).join('')}</select></label></div>`
          +`<label class="field">Grund<input name="grund" maxlength="500" placeholder="z. B. Nachschreibtermin"></label><button class="btn secondary">Zuweisen</button></form>`:'')
        +(zuweisungen.length?`<h4>Zugewiesen</h4>`+zuweisungen.map(z=>`<div class="item"><strong>${LS(z.display_name)}</strong> → ${LS(z.label)}`+(z.grund?`<div class="muted">${LS(z.grund)}</div>`:'')+`</div>`).join(''):'');
      const tun=async fn=>{
        try{await fn();await zeichne();}
        catch(err){
          const text=window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message;
          const kasten=body.querySelector('#var-err');
          if(kasten)kasten.innerHTML=`<div class="notice bad">${LS(text)}</div>`;else alert(text);
        }
      };
      const neu=body.querySelector('#var-neu');
      if(neu)neu.onsubmit=e=>{e.preventDefault();const f=new FormData(e.currentTarget),ids=f.getAll('qid');
        if(!ids.length)return alert('Bitte mindestens eine Aufgabe auswählen.');
        tun(()=>lsApi(qp(`/api/learning-suite/quizzes/${encodeURIComponent(quizId)}/variants`,s.tenantId,activeCourse),{method:'POST',body:JSON.stringify({label:f.get('label'),question_ids:ids,nur_auf_zuweisung:e.currentTarget.nur_auf_zuweisung.checked})}));};
      const zuF=body.querySelector('#var-zu');
      if(zuF)zuF.onsubmit=e=>{e.preventDefault();const f=new FormData(e.currentTarget);
        tun(()=>lsApi(qp(`/api/learning-suite/quizzes/${encodeURIComponent(quizId)}/variant-assignments`,s.tenantId,activeCourse),{method:'PUT',body:JSON.stringify({user_id:f.get('user_id'),variant_id:f.get('variant_id')||null,grund:f.get('grund')})}));};
      body.querySelectorAll('.var-akt').forEach(b=>b.onclick=()=>tun(()=>lsApi(qp(`/api/learning-suite/quizzes/${encodeURIComponent(quizId)}/variants/${encodeURIComponent(b.dataset.id)}`,s.tenantId,activeCourse),{method:'PUT',body:JSON.stringify({status:'aktiv'})})));
      body.querySelectorAll('.var-arch').forEach(b=>b.onclick=()=>tun(()=>lsApi(qp(`/api/learning-suite/quizzes/${encodeURIComponent(quizId)}/variants/${encodeURIComponent(b.dataset.id)}`,s.tenantId,activeCourse),{method:'PUT',body:JSON.stringify({status:'archiviert'})})));
    }
    await zeichne();
  }
  // Die Pruefungssperre war gebaut und nicht einschaltbar: die Spalten gab es, einen Weg sie zu
  // setzen nicht. Der Schluessel selbst geht nie ueber die Leitung - SEB schickt nur Hashes.
  async function sebModal(quizId,aktiv,bek,ck,danach){
    const w2=document.createElement('div');w2.className='modal-back';
    w2.innerHTML=`<div class="modal" style="width:min(680px,96vw)"><div class="top"><h3>Prüfungssperre (Safe Exam Browser)</h3><button class="btn secondary" data-close aria-label="Schließen">×</button></div>`
      +`<p class="muted">Der Safe Exam Browser sperrt das Gerät in einen Kiosk-Modus. Der Server weist nach, dass die Prüfung wirklich darin lief. Das belegt die <strong>Umgebung</strong>, nicht die Person: wer neben dem gesperrten Rechner ein Telefon liegen hat, wird davon nicht erfasst.</p>`
      +`<form id="seb-form"><label style="display:block;margin:.4rem 0"><input type="checkbox" name="seb_required" ${aktiv?'checked':''}> Diese Prüfung darf nur im Safe Exam Browser geschrieben werden</label>`
      +`<label class="field">Browser Exam Keys – einer je Zeile<textarea name="seb_browser_exam_keys" rows="3">${LS(String(bek||'').split(/\s+/).filter(Boolean).join('\n'))}</textarea></label>`
      +`<label class="field">Config Keys – einer je Zeile<textarea name="seb_config_keys" rows="3">${LS(String(ck||'').split(/\s+/).filter(Boolean).join('\n'))}</textarea></label>`
      +`<p class="muted">Ohne mindestens einen Schlüssel lässt sich die Sperre nicht aktivieren – sie wäre eine Zusage ohne Deckung. Teilnehmende mit Nachteilsausgleich können von der Sperre befreit werden.</p>`
      +`<button class="btn">Speichern</button></form><div id="seb-err"></div></div>`;
    document.body.append(w2);
    const zu=()=>w2.remove();w2.querySelector('[data-close]').onclick=zu;w2.onclick=e=>{if(e.target===w2)zu();};
    w2.querySelector('#seb-form').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget);
      try{await lsApi(qp(`/api/learning-suite/quizzes/${encodeURIComponent(quizId)}/lockdown`,s.tenantId,activeCourse),{method:'PUT',body:JSON.stringify({seb_required:e.currentTarget.seb_required.checked,seb_browser_exam_keys:String(f.get('seb_browser_exam_keys')||'').trim(),seb_config_keys:String(f.get('seb_config_keys')||'').trim()})});zu();await danach();}
      catch(err){w2.querySelector('#seb-err').innerHTML=`<div class="notice bad">${LS(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message)}</div>`;}};
  }
  const NTA_FORMATE=[['','– kein besonderes Format –'],['grossdruck','Großdruck'],['screenreader','Screenreader'],['braille','Braillezeile'],['muendlich_statt_schriftlich','Mündlich statt schriftlich'],['schriftlich_statt_muendlich','Schriftlich statt mündlich'],['leichte_sprache','Leichte Sprache'],['einzelraum','Einzelraum'],['pausen','Zusätzliche Pausen']];
  async function nachteilsausgleich(p){
    const d=await lsApi(qp('/api/learning-suite/accommodations',s.tenantId,activeCourse)),rows=d.accommodations||[],personen=d.teilnehmer||[],pruefungen=d.pruefungen||[];
    const formatText=v=>(NTA_FORMATE.find(x=>x[0]===String(v||''))||['',''])[1];
    p.innerHTML=`<div class="grid"><div class="card"><h3>Nachteilsausgleich gewähren</h3>`
      +`<p class="muted">Der Ausgleich gleicht die Bedingungen an, nicht den Maßstab: mehr Zeit, anderes Format, Hilfsmittel. Die Leistungsanforderung bleibt unverändert. Tragen Sie hier <strong>keine Diagnose</strong> ein – nur das Aktenzeichen des Bescheids.</p>`
      +(personen.length?`<form id="nta-form"><label class="field">Person<select name="user_id" required>${personen.map(u=>`<option value="${LS(u.id)}">${LS(u.display_name)}</option>`).join('')}</select></label>`
      +`<label class="field">Gilt für<select name="quiz_id"><option value="">Alle Prüfungen dieses Kurses</option>${pruefungen.map(q=>`<option value="${LS(q.id)}">${LS(q.title)}</option>`).join('')}</select></label>`
      +`<label class="field">Zeitzuschlag in Prozent<input name="zeitzuschlag_prozent" type="number" min="0" max="200" step="5" value="0"></label>`
      +`<label class="field">Zusätzliche Versuche<input name="zusatzversuche" type="number" min="0" max="10" value="0"></label>`
      +`<label class="field">Prüfungsformat<select name="format">${NTA_FORMATE.map(f=>`<option value="${LS(f[0])}">${LS(f[1])}</option>`).join('')}</select></label>`
      +`<label class="field">Zugelassene Hilfsmittel<input name="hilfsmittel" maxlength="500" placeholder="z. B. Bildschirmlupe, Vorlesesoftware"></label>`
      +`<label style="display:block;margin:.4rem 0"><input type="checkbox" name="seb_befreit"> Vom Safe Exam Browser befreien <span class="muted">(nötig, wenn Screenreader oder Braillezeile im Kiosk-Modus nicht laufen)</span></label>`
      +`<label class="field">Aktenzeichen des Bescheids<input name="bescheid_referenz" maxlength="120"></label>`
      +`<div class="row"><label class="field">Gültig ab<input name="gueltig_ab" type="date"></label><label class="field">Gültig bis<input name="gueltig_bis" type="date"></label></div>`
      +`<label class="field">Interner Hinweis<textarea name="hinweis" maxlength="2000"></textarea></label>`
      +`<button class="btn">Nachteilsausgleich eintragen</button></form>`:'<p class="muted">Dieser Kurs hat noch keine Teilnehmenden.</p>')
      +`</div><div class="card"><h3>Eingetragene Ausgleiche</h3>`
      +(rows.length?rows.map(a=>`<div class="item"><strong>${LS(a.display_name)}</strong> <span class="pill">${a.status==='aktiv'?'aktiv':'widerrufen'}</span>`
        +`<div class="muted">${LS(a.quiz_title||'Alle Prüfungen')}${Number(a.zeitzuschlag_prozent)?` · +${LS(a.zeitzuschlag_prozent)} % Zeit`:''}${Number(a.zusatzversuche)?` · +${LS(a.zusatzversuche)} Versuche`:''}${Number(a.seb_befreit)?' · ohne Safe Exam Browser':''}${a.format?` · ${LS(formatText(a.format))}`:''}${a.hilfsmittel?` · ${LS(a.hilfsmittel)}`:''}</div>`
        +`<div class="muted">${a.gueltig_ab||a.gueltig_bis?`Gültig ${LS(a.gueltig_ab||'')} – ${LS(a.gueltig_bis||'offen')}`:'Unbefristet'}${a.bescheid_referenz?` · Bescheid ${LS(a.bescheid_referenz)}`:''}</div>`
        +(a.status==='aktiv'?`<button class="btn secondary nta-rev" data-id="${LS(a.id)}">Widerrufen</button>`:'')+`</div>`).join(''):'<p class="muted">Noch kein Nachteilsausgleich eingetragen.</p>')
      +`<p class="muted">Widerrufene Ausgleiche bleiben sichtbar: bei einem Einspruch muss belegbar sein, was zum Prüfungszeitpunkt galt.</p></div></div>`;
    const f=p.querySelector('#nta-form');
    if(f)f.onsubmit=async e=>{e.preventDefault();const d2=Object.fromEntries(new FormData(e.currentTarget));
      await lsApi(qp('/api/learning-suite/accommodations',s.tenantId,activeCourse),{method:'POST',body:JSON.stringify({...d2,zeitzuschlag_prozent:Number(d2.zeitzuschlag_prozent||0),zusatzversuche:Number(d2.zusatzversuche||0),seb_befreit:e.currentTarget.seb_befreit.checked})});
      await nachteilsausgleich(p);};
    p.querySelectorAll('.nta-rev').forEach(b=>b.onclick=async()=>{if(!confirm('Diesen Nachteilsausgleich widerrufen? Er gilt dann für künftige Prüfungen nicht mehr.'))return;await lsApi(qp(`/api/learning-suite/accommodations/${encodeURIComponent(b.dataset.id)}`,s.tenantId,activeCourse),{method:'DELETE'});await nachteilsausgleich(p);});
  }
  // Kompetenzen. Die Frage, die Kostenträger und Kammer stellen, ist nicht "war die Person
  // anwesend", sondern "kann sie das". Der Stand wird abgeleitet, nicht gepflegt - deshalb gibt es
  // hier nichts einzutragen außer der Kette: woran hängt diese Kompetenz.
  const KMP_ART={fachkompetenz:'Fachkompetenz',methodenkompetenz:'Methodenkompetenz',sozialkompetenz:'Sozialkompetenz',selbstkompetenz:'Selbstkompetenz'};
  const KMP_STAND={erreicht:'erreicht',teilweise:'teilweise',offen:'offen',ohne_nachweis:'ohne Nachweis'};
  async function kompetenzen(p){
    const [d,u,gb,rb]=await Promise.all([
      lsApi(qp('/api/learning-suite/competencies',s.tenantId,'')),
      lsApi(qp('/api/learning-suite/competency-overview',s.tenantId,activeCourse)),
      lsApi(qp('/api/learning-suite/gradebook',s.tenantId,activeCourse)).catch(()=>({})),
      lsApi(qp('/api/learning-suite/rubrics',s.tenantId,activeCourse)).catch(()=>({})),
    ]);
    const liste=d.competencies||[],zeilen=u.zeilen||[],positionen=gb.items||[],raster=(rb.rubrics||[]).filter(r=>r.status==='aktiv');
    p.innerHTML=`<div class="grid"><div class="card"><h3>Kompetenzen des Trägers</h3>`
      +`<p class="muted">Die Stufe des Deutschen Qualifikationsrahmens ist die Sprache, in der Kammer und Kostenträger über Abschlüsse reden. Der Stand einer Person wird aus den vorhandenen Nachweisen abgeleitet – es gibt hier nichts nachzupflegen.</p>`
      +`<form id="kmp-new"><div class="row"><label class="field">Kennung<input name="code" required maxlength="60" placeholder="BF-1"></label><label class="field">Titel<input name="title" required></label></div>`
      +`<div class="row"><label class="field">Art<select name="art">${Object.entries(KMP_ART).map(([k,v])=>`<option value="${LS(k)}">${LS(v)}</option>`).join('')}</select></label>`
      +`<label class="field">DQR-Niveau<select name="dqr_niveau"><option value="">– ohne –</option>${[1,2,3,4,5,6,7,8].map(n=>`<option value="${n}">Stufe ${n}</option>`).join('')}</select></label></div>`
      +`<label class="field">Beschreibung<textarea name="beschreibung" rows="2"></textarea></label><button class="btn">Kompetenz anlegen</button></form><div id="kmp-err"></div>`
      +(liste.length?liste.map(k=>`<div class="item"><strong>${LS(k.code)}</strong> ${LS(k.title)}${k.dqr_niveau?` <span class="pill">DQR ${LS(k.dqr_niveau)}</span>`:''}`
        +`<div class="muted">${LS(KMP_ART[k.art]||k.art)} · ${LS((k.verbindungen||[]).length)} Verknüpfung(en)</div>`
        +((k.verbindungen||[]).length?`<div class="muted">${(k.verbindungen||[]).map(v=>`${LS(v.gegenstand)} (Gewicht ${LS(v.gewicht)})`).join(' · ')}</div>`:'')
        +((positionen.length||raster.length)?`<form class="kmp-link" data-id="${LS(k.id)}"><div class="row"><label class="field">Nachweis verknüpfen<select name="ziel">`
          +positionen.map(i=>`<option value="gradebook_item:${LS(i.id)}">Aufgabe: ${LS(i.title)}</option>`).join('')
          +raster.map(r=>`<option value="rubric:${LS(r.id)}">Raster: ${LS(r.title)} – Kriterium wählen</option>`).join('')
          +`</select></label><label class="field">Gewicht<input name="gewicht" type="number" min="0.5" max="100" step="0.5" value="1"></label></div><button class="btn secondary">Verknüpfen</button></form>`:'')
        +`</div>`).join(''):'<p class="muted">Noch keine Kompetenz angelegt.</p>')
      +`</div><div class="card"><h3>Kompetenzstand der Klasse</h3>`
      +(zeilen.length&&liste.length
        ?`<p class="muted">Erreicht ab ${LS(u.schwelle_prozent)} %${u.abgeschnitten?` · ${LS(u.gezeigt)} von ${LS(u.gesamt)} Personen gezeigt`:''}</p>`
          +`<div class="table-wrap"><table><thead><tr><th scope="col">Person</th>${(zeilen[0].kompetenzen||[]).map(k=>`<th scope="col">${LS(k.code)}</th>`).join('')}</tr></thead><tbody>`
          +zeilen.map(z=>`<tr><td>${LS(z.display_name)}</td>${(z.kompetenzen||[]).map(k=>`<td>${k.prozent===null?'<span class="muted">–</span>':`${LS(k.prozent)} %`}<div class="muted">${LS(KMP_STAND[k.stand]||k.stand)}</div></td>`).join('')}</tr>`).join('')
          +`</tbody></table></div><p class="muted">„–" heißt: diese Kompetenz wurde bei dieser Person noch nie geprüft. Das ist etwas anderes als „nicht erreicht".</p>`
        :'<p class="muted">Sobald Kompetenzen angelegt und mit Aufgaben oder Rasterkriterien verknüpft sind, steht hier der Stand der Klasse.</p>')
      +`</div></div>`;
    p.querySelector('#kmp-new').onsubmit=async e=>{e.preventDefault();const f=Object.fromEntries(new FormData(e.currentTarget));
      try{await lsApi(qp('/api/learning-suite/competencies',s.tenantId,''),{method:'POST',body:JSON.stringify(f)});await kompetenzen(p);}
      catch(err){p.querySelector('#kmp-err').innerHTML=`<div class="notice bad">${LS(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message)}</div>`;}};
    p.querySelectorAll('.kmp-link').forEach(f=>f.onsubmit=async e=>{e.preventDefault();const fd=new FormData(f),ziel=String(fd.get('ziel')||''),[art,id]=ziel.split(':');
      try{
        let gegenstand=art,bezugId=id;
        if(art==='rubric'){
          // Ein Raster besteht aus Kriterien - und genau ein Kriterium sagt über genau eine
          // Kompetenz etwas aus. Deshalb wird hier nachgefragt statt pauschal das ganze Raster zu nehmen.
          const r=await lsApi(qp(`/api/learning-suite/rubrics/${encodeURIComponent(id)}`,s.tenantId,activeCourse));
          const namen=(r.kriterien||[]).map((k,i)=>`${i+1}. ${k.title}`).join('\n');
          const wahl=prompt(`Welches Kriterium weist diese Kompetenz nach?\n\n${namen}\n\nNummer eingeben:`,'1');
          const idx=Number(wahl)-1;
          if(!Number.isInteger(idx)||idx<0||idx>=(r.kriterien||[]).length)return;
          gegenstand='rubric_criterion';bezugId=r.kriterien[idx].id;
        }
        await lsApi(qp('/api/learning-suite/competency-links',s.tenantId,activeCourse),{method:'POST',body:JSON.stringify({competency_id:f.dataset.id,gegenstand,bezug_id:bezugId,gewicht:Number(fd.get('gewicht'))||1})});
        await kompetenzen(p);
      }catch(err){alert(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message);}});
  }
  // Die Maske, in der das Raster ausgefüllt wird. Dieselbe für Erst- und Zweitkorrektur: genau
  // deshalb sind die beiden Bewertungen hinterher Kriterium für Kriterium vergleichbar.
  async function rasterMaske(rubricId,gegenstand,bezugId,rolle,titel,danach){
    const r=await lsApi(qp(`/api/learning-suite/rubrics/${encodeURIComponent(rubricId)}`,s.tenantId,activeCourse));
    const w2=document.createElement('div');w2.className='modal-back';
    w2.innerHTML=`<div class="modal" style="width:min(820px,96vw);max-height:92vh;overflow:auto"><div class="top"><div><h3 style="margin:0">${LS(titel)}</h3><div class="muted">${LS(r.rubrik.title)} · ${rolle==='zweitkorrektur'?'Zweitkorrektur':'Erstkorrektur'} · ${LS(r.summe_max)} Punkte</div></div><button class="btn secondary" data-close aria-label="Schließen">×</button></div>`
      +(rolle==='zweitkorrektur'?'<p class="muted">Die Erstkorrektur wird Ihnen erst nach Ihrer eigenen Abgabe gezeigt.</p>':'')
      +`<form id="rb-mask">${(r.kriterien||[]).map((k,i)=>`<fieldset><legend>${LS(k.title)} (max. ${LS(k.max_points)} P.)</legend>${k.erwartungshorizont?`<p class="muted">${LS(k.erwartungshorizont)}</p>`:''}`
        +((k.stufen||[]).length
          ?`<label class="field">Niveaustufe<select name="lvl_${i}" required><option value="">– wählen –</option>${(k.stufen||[]).map(x=>`<option value="${LS(x.id)}">${LS(x.label)} – ${LS(x.points)} P.${x.beschreibung?`: ${LS(x.beschreibung)}`:''}</option>`).join('')}</select></label>`
          :`<label class="field">Punkte<input name="pts_${i}" type="number" min="0" max="${LS(k.max_points)}" step="0.5" required></label>`)
        +`<label class="field">Kommentar<textarea name="cmt_${i}" rows="2"></textarea></label></fieldset>`).join('')}`
      +`<button class="btn">Bewertung abgeben</button></form><div id="rb-mask-err"></div></div>`;
    document.body.append(w2);
    const zu=()=>w2.remove();w2.querySelector('[data-close]').onclick=zu;w2.onclick=e=>{if(e.target===w2)zu();};
    w2.querySelector('#rb-mask').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget);
      const bewertungen=(r.kriterien||[]).map((k,i)=>{
        const stufe=f.get(`lvl_${i}`),punkte=f.get(`pts_${i}`);
        return{criterion_id:k.id,level_id:stufe||null,points:stufe?null:Number(punkte),kommentar:f.get(`cmt_${i}`)||null};
      });
      try{await lsApi(qp('/api/learning-suite/rubric-assessments',s.tenantId,activeCourse),{method:'POST',body:JSON.stringify({rubric_id:rubricId,gegenstand,bezug_id:bezugId,rolle,bewertungen})});zu();await danach();}
      catch(err){w2.querySelector('#rb-mask-err').innerHTML=`<div class="notice bad">${LS(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message)}</div>`;}};
  }

  // Korrekturliste zu einer Aufgabe mit Raster.
  async function rasterListe(itemId,danach){
    const {w,body}=(()=>{const w=document.createElement('div');w.className='modal-back';w.innerHTML='<div class="modal" style="width:min(760px,96vw);max-height:90vh;overflow:auto"><div class="top"><h3 style="margin:0">Nach Raster bewerten</h3><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div id="rb-queue">Lädt …</div></div>';document.body.append(w);w.querySelector('[data-close]').onclick=()=>w.remove();w.onclick=e=>{if(e.target===w)w.remove();};return{w,body:w.querySelector('#rb-queue')};})();
    async function zeichne(){
      let d;try{d=await lsApi(qp(`/api/learning-suite/gradebook/items/${encodeURIComponent(itemId)}/rubric-queue`,s.tenantId,activeCourse));}
      catch(err){body.innerHTML=`<div class="notice bad">${LS(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message)}</div>`;return;}
      if(!d.item.rubric_id){body.innerHTML='<p class="muted">An dieser Aufgabe hängt kein Bewertungsraster.</p>';return;}
      body.innerHTML=`<p class="muted">${LS(d.item.title)} · max. ${LS(d.item.max_points)} Punkte</p>`
        +((d.zeilen||[]).length?(d.zeilen||[]).map(z=>`<div class="item"><strong>${LS(z.display_name)}</strong> <span class="pill">${z.mein_raster===null||z.mein_raster===undefined?'offen':`${LS(z.mein_raster)} P.`}</span> <button class="btn secondary rb-do" data-score="${LS(z.score_id)}" data-name="${LS(z.display_name)}">${z.mein_raster===null||z.mein_raster===undefined?'Bewerten':'Nachbessern'}</button></div>`).join('')
          :'<p class="muted">Für diese Aufgabe ist noch keine Bewertungszeile angelegt.</p>');
      body.querySelectorAll('.rb-do').forEach(b=>b.onclick=()=>rasterMaske(String(d.item.rubric_id),'gradebook_score',b.dataset.score,'erstkorrektur',b.dataset.name,async()=>{await zeichne();await danach();}).catch(err=>alert(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message)));
    }
    await zeichne();
  }
  // Bewertungsraster und Erwartungshorizont. Erst damit wird aus "38 von 50" eine begründete
  // Entscheidung - und erst damit sieht man bei einer Zweitkorrektur, WO man auseinandergeht.
  async function raster(p){
    const [d,gb]=await Promise.all([
      lsApi(qp('/api/learning-suite/rubrics',s.tenantId,activeCourse)),
      lsApi(qp('/api/learning-suite/gradebook',s.tenantId,activeCourse)).catch(()=>({})),
    ]);
    const rows=d.rubrics||[],positionen=gb.items||[];
    p.innerHTML=`<div class="grid"><div class="card"><h3>Neues Bewertungsraster</h3>`
      +`<p class="muted">Ein Kriterium je Zeile: <code>Titel | Punkte | Erwartungshorizont</code>. Niveaustufen darunter mit führendem Minus: <code>- Bezeichnung | Punkte</code>. Die Punktsumme des Rasters muss der Punktzahl der Aufgabe entsprechen.</p>`
      +`<form id="rb-new"><label class="field">Titel<input name="title" required></label>`
      +`<label class="field">Kriterien<textarea name="kriterien" rows="10" required placeholder="Rechenweg | 20 | Der Weg ist vollständig dargestellt.&#10;- vollständig | 20&#10;- weitgehend | 14&#10;- nicht erfüllt | 0&#10;Ergebnis | 15 | Das Ergebnis ist richtig und mit Einheit angegeben.&#10;- richtig | 15&#10;- falsch | 0"></textarea></label>`
      +`<button class="btn">Raster anlegen</button></form><div id="rb-err"></div></div>`
      +`<div class="card"><h3>Raster dieses Kurses</h3>`
      +(rows.length?rows.map(r=>`<div class="item"><strong>${LS(r.title)}</strong> <span class="pill">${LS(r.status)}</span> <span class="muted">Fassung ${LS(r.fassung)}</span>`
        +`<div class="muted">${LS(r.kriterien)} Kriterien · ${LS(r.bewertungen)} Bewertungen${r.vorgaenger_id?' · Nachfolger einer früheren Fassung':''}</div>`
        +(r.status==='entwurf'?`<button class="btn secondary rb-status" data-id="${LS(r.id)}" data-s="aktiv">Freigeben</button>`:'')
        +(r.status==='aktiv'?`<button class="btn secondary rb-status" data-id="${LS(r.id)}" data-s="archiviert">Archivieren</button> <button class="btn secondary rb-rev" data-id="${LS(r.id)}">Neue Fassung</button>`:'')
        +` <button class="btn secondary rb-show" data-id="${LS(r.id)}">Ansehen</button>`
        +(r.status==='aktiv'&&positionen.filter(i=>String(i.rubric_id||'')===String(r.id)).length?`<div class="row">${positionen.filter(i=>String(i.rubric_id||'')===String(r.id)).map(i=>`<button class="btn rb-grade" data-item="${LS(i.id)}">Nach Raster bewerten: ${LS(i.title)}</button>`).join('')}</div>`:'')
        +(r.status==='aktiv'&&positionen.length?`<form class="rb-attach" data-id="${LS(r.id)}"><label class="field">An Aufgabe hängen<select name="item_id">${positionen.map(i=>`<option value="${LS(i.id)}">${LS(i.title)}${i.max_points!==null&&i.max_points!==undefined?` (${LS(i.max_points)} P.)`:''}</option>`).join('')}</select></label><button class="btn secondary">Zuordnen</button></form>`:'')
        +`</div>`).join(''):'<p class="muted">Noch kein Bewertungsraster angelegt.</p>')
      +`<p class="muted">Ein Raster, mit dem bereits bewertet wurde, lässt sich nicht mehr ändern – sonst änderte sich rückwirkend die Begründung einer erteilten Note. Dafür gibt es die neue Fassung.</p></div></div>`;
    p.querySelector('#rb-new').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget);
      try{
        const kriterien=[];
        for(const zeile of String(f.get('kriterien')||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean)){
          if(zeile.startsWith('-')){
            if(!kriterien.length)throw new Error('RUBRIC_CRITERIA_INVALID');
            const [label,punkte]=zeile.slice(1).split('|').map(x=>x.trim());
            kriterien[kriterien.length-1].stufen.push({label,points:Number(punkte)});
          }else{
            const [title,punkte,erwartung]=zeile.split('|').map(x=>x.trim());
            kriterien.push({title,max_points:Number(punkte),erwartungshorizont:erwartung||null,stufen:[]});
          }
        }
        await lsApi(qp('/api/learning-suite/rubrics',s.tenantId,activeCourse),{method:'POST',body:JSON.stringify({title:f.get('title'),kriterien})});
        await raster(p);
      }catch(err){p.querySelector('#rb-err').innerHTML=`<div class="notice bad">${LS(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message)}</div>`;}};
    const tun=async fn=>{try{await fn();await raster(p);}catch(err){alert(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message);}};
    p.querySelectorAll('.rb-status').forEach(b=>b.onclick=()=>tun(()=>lsApi(qp(`/api/learning-suite/rubrics/${encodeURIComponent(b.dataset.id)}`,s.tenantId,activeCourse),{method:'PUT',body:JSON.stringify({status:b.dataset.s})})));
    p.querySelectorAll('.rb-rev').forEach(b=>b.onclick=()=>tun(()=>lsApi(qp(`/api/learning-suite/rubrics/${encodeURIComponent(b.dataset.id)}/revision`,s.tenantId,activeCourse),{method:'POST',body:'{}'})));
    p.querySelectorAll('.rb-grade').forEach(b=>b.onclick=()=>rasterListe(b.dataset.item,()=>raster(p)).catch(err=>alert(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message)));
    p.querySelectorAll('.rb-attach').forEach(f=>f.onsubmit=e=>{e.preventDefault();const item=new FormData(f).get('item_id');
      tun(()=>lsApi(qp(`/api/learning-suite/gradebook/items/${encodeURIComponent(item)}/rubric`,s.tenantId,activeCourse),{method:'PUT',body:JSON.stringify({rubric_id:f.dataset.id})}));});
    p.querySelectorAll('.rb-show').forEach(b=>b.onclick=async()=>{
      try{
        const r=await lsApi(qp(`/api/learning-suite/rubrics/${encodeURIComponent(b.dataset.id)}`,s.tenantId,activeCourse));
        const w2=document.createElement('div');w2.className='modal-back';
        w2.innerHTML=`<div class="modal" style="width:min(760px,96vw);max-height:90vh;overflow:auto"><div class="top"><h3>${LS(r.rubrik.title)}</h3><button class="btn secondary" data-close aria-label="Schließen">×</button></div>`
          +`<p class="muted">${LS(r.summe_max)} Punkte gesamt</p>`
          +(r.kriterien||[]).map(k=>`<div class="item"><strong>${LS(k.title)}</strong> <span class="pill">${LS(k.max_points)} P.</span>${k.erwartungshorizont?`<div>${LS(k.erwartungshorizont)}</div>`:''}${(k.stufen||[]).length?`<div class="muted">${(k.stufen||[]).map(x=>`${LS(x.label)}: ${LS(x.points)}`).join(' · ')}</div>`:''}</div>`).join('')
          +`</div>`;
        document.body.append(w2);const zu=()=>w2.remove();w2.querySelector('[data-close]').onclick=zu;w2.onclick=e=>{if(e.target===w2)zu();};
      }catch(err){alert(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message);}});
  }
  // Einspruch und Zweitkorrektur. Die Beweislast fuer ein ordnungsgemaesses Verfahren liegt beim
  // Traeger - deshalb zeigt diese Maske nicht nur den Stand, sondern die Begruendungen und Daten,
  // aus denen sich der Ablauf spaeter rekonstruieren laesst.
  const NTA_STATUS={eingelegt:'eingelegt',zweitkorrektur:'in Zweitkorrektur',abgeholfen:'abgeholfen',zurueckgewiesen:'zurückgewiesen',zurueckgenommen:'zurückgenommen'};
  async function einsprueche(p){
    const [d,eigene]=await Promise.all([
      lsApi(qp('/api/learning-suite/appeals',s.tenantId,activeCourse)),
      lsApi(qp('/api/learning-suite/my-second-markings',s.tenantId,activeCourse)).catch(()=>({})),
    ]);
    const rows=d.appeals||[],korr=d.korrigierende||[],meine=(eigene.markings||[]).filter(x=>!x.abgeschlossen_am);
    const pkt=v=>v===null||v===undefined?'–':String(v);
    p.innerHTML=`<div class="grid"><div class="card"><h3>Eingelegte Einsprüche</h3>`
      +(rows.length?rows.map(a=>`<div class="item"><strong>${LS(a.display_name)}</strong> <span class="pill">${LS(NTA_STATUS[a.status]||a.status)}</span>`
        +`<div class="muted">Bekanntgabe ${LS(String(a.bekanntgabe_am).slice(0,10))} · Frist bis ${LS(String(a.frist_bis).slice(0,10))} · eingelegt ${LS(String(a.eingelegt_am).slice(0,10))}</div>`
        +`<div>${LS(a.begruendung)}</div>`
        +`<div class="muted">Bewertet mit ${LS(pkt(a.urspruengliche_punkte))}${a.zweitkorrektur_name?` · Zweitkorrektur: ${LS(a.zweitkorrektur_name)}${a.zweitkorrektur_am?` (${LS(pkt(a.zweitkorrektur_punkte))})`:' – noch offen'}`:''}${a.neue_punkte!==null&&a.neue_punkte!==undefined?` · neu ${LS(a.neue_punkte)}`:''}</div>`
        +(a.entscheidung?`<div class="muted">Bescheid vom ${LS(String(a.entschieden_am).slice(0,10))}: ${LS(a.entscheidung)}</div>`:'')
        +(a.gegenstand==='gradebook_score'||a.gegenstand==='quiz_attempt'?` <button class="btn secondary ea-cmp" data-g="${LS(a.gegenstand)}" data-b="${LS(a.bezug_id)}">Rastervergleich</button>`:'')
        +(a.status==='eingelegt'&&korr.length?`<form class="ea-order" data-id="${LS(a.id)}"><label class="field">Zweitkorrektur beauftragen<select name="zweitkorrektur_von" required><option value="">– Person wählen –</option>${korr.map(k=>`<option value="${LS(k.id)}">${LS(k.display_name)}</option>`).join('')}</select></label><button class="btn secondary">Beauftragen</button></form>`:'')
        +(['eingelegt','zweitkorrektur'].includes(a.status)?`<form class="ea-dec" data-id="${LS(a.id)}"><label class="field">Entscheidung<select name="status"><option value="zurueckgewiesen">Zurückweisen</option><option value="abgeholfen">Abhelfen</option></select></label><label class="field">Neue Punktzahl bei Abhilfe<input name="neue_punkte" type="number" min="0" step="0.5" placeholder="leer = Ergebnis der Zweitkorrektur"></label><label class="field">Begründung<textarea name="entscheidung" required minlength="20"></textarea></label><button class="btn">Bescheiden</button></form>`:'')
        +`</div>`).join(''):'<p class="muted">Es liegt kein Einspruch vor.</p>')
      +`</div><div class="card"><h3>Meine Zweitkorrekturen</h3>`
      +`<p class="muted">Die erste Bewertung wird erst nach Ihrer eigenen Abgabe angezeigt. Eine Zweitkorrektur, die die erste Note kennt, ist keine.</p>`
      +(meine.length?meine.map(m=>`<div class="item"><strong>${LS(m.display_name)}</strong><div>${LS(m.begruendung)}</div>`
        +(m.rubric_id?`<button class="btn secondary ea-rubric" data-rub="${LS(m.rubric_id)}" data-g="${LS(m.gegenstand)}" data-b="${LS(m.bezug_id)}" data-name="${LS(m.display_name)}">Nach Raster bewerten</button>`:'')
        +`<form class="ea-mark" data-id="${LS(m.appeal_id)}"><label class="field">Ihre Punktzahl<input name="punkte" type="number" min="0" step="0.5" required></label><label class="field">Kommentar<textarea name="kommentar"></textarea></label><button class="btn">Zweitkorrektur abgeben</button></form></div>`).join(''):'<p class="muted">Kein offener Auftrag.</p>')
      +`</div></div>`;
    const senden=async(el,pfad,methode,daten)=>{try{await lsApi(qp(pfad,s.tenantId,activeCourse),{method:methode,body:JSON.stringify(daten)});await einsprueche(p);}catch(err){alert(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message);}};
    p.querySelectorAll('.ea-rubric').forEach(b=>b.onclick=()=>rasterMaske(b.dataset.rub,b.dataset.g,b.dataset.b,'zweitkorrektur',b.dataset.name,()=>einsprueche(p)).catch(err=>alert(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message)));
    p.querySelectorAll('.ea-cmp').forEach(b=>b.onclick=async()=>{
      try{
        const v=await lsApi(qp(`/api/learning-suite/rubric-comparison?gegenstand=${encodeURIComponent(b.dataset.g)}&bezug_id=${encodeURIComponent(b.dataset.b)}`,s.tenantId,activeCourse));
        const w2=document.createElement('div');w2.className='modal-back';
        // Der Gewinn gegenüber zwei bloßen Noten: die Abweichung steht an dem Kriterium, an dem sie ist.
        w2.innerHTML=`<div class="modal" style="width:min(860px,96vw);max-height:90vh;overflow:auto"><div class="top"><h3>Erst- und Zweitkorrektur im Vergleich</h3><button class="btn secondary" data-close aria-label="Schließen">×</button></div>`
          +(v.kriterien&&v.kriterien.length
            ?`<div class="table-wrap"><table><thead><tr><th scope="col">Kriterium</th><th scope="col">Erstkorrektur</th><th scope="col">Zweitkorrektur</th><th scope="col">Abweichung</th></tr></thead><tbody>`
              +v.kriterien.map(k=>`<tr><td>${LS(k.title)} <span class="muted">(max. ${LS(k.max_points)})</span>${k.erst_kommentar||k.zweit_kommentar?`<div class="muted">${LS([k.erst_kommentar,k.zweit_kommentar].filter(Boolean).join(' · '))}</div>`:''}</td><td>${k.erstkorrektur===null?'–':`${LS(k.erstkorrektur)}${k.erst_stufe?` (${LS(k.erst_stufe)})`:''}`}</td><td>${k.zweitkorrektur===null?'–':`${LS(k.zweitkorrektur)}${k.zweit_stufe?` (${LS(k.zweit_stufe)})`:''}`}</td><td>${k.abweichung===null?'–':LS(k.abweichung>0?`+${k.abweichung}`:k.abweichung)}</td></tr>`).join('')
              +`</tbody></table></div><p class="muted">Gesamtabweichung: ${v.abweichung===null?'die Zweitkorrektur steht noch aus':LS(v.abweichung>0?`+${v.abweichung}`:v.abweichung)}</p>`
            :'<p class="muted">Für diese Bewertung wurde kein Raster verwendet. Ohne Raster lässt sich nur vergleichen, DASS man sich uneinig ist – nicht worüber.</p>')
          +`</div>`;
        document.body.append(w2);const zu=()=>w2.remove();w2.querySelector('[data-close]').onclick=zu;w2.onclick=e=>{if(e.target===w2)zu();};
      }catch(err){alert(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(err.message):err.message);}});
    p.querySelectorAll('.ea-order').forEach(f=>f.onsubmit=e=>{e.preventDefault();senden(f,`/api/learning-suite/appeals/${encodeURIComponent(f.dataset.id)}/second-marking`,'POST',{zweitkorrektur_von:new FormData(f).get('zweitkorrektur_von')});});
    p.querySelectorAll('.ea-mark').forEach(f=>f.onsubmit=e=>{e.preventDefault();const fd=new FormData(f);senden(f,`/api/learning-suite/appeals/${encodeURIComponent(f.dataset.id)}/second-marking`,'PUT',{punkte:Number(fd.get('punkte')),kommentar:fd.get('kommentar')});});
    p.querySelectorAll('.ea-dec').forEach(f=>f.onsubmit=e=>{e.preventDefault();const fd=new FormData(f);senden(f,`/api/learning-suite/appeals/${encodeURIComponent(f.dataset.id)}/decision`,'POST',{status:fd.get('status'),entscheidung:fd.get('entscheidung'),neue_punkte:fd.get('neue_punkte')||null});});
  }
  async function templates(p){const d=await lsApi(qp('/api/learning-suite/templates',s.tenantId,'')),rows=d.templates||[];p.innerHTML=`<div class="grid"><div class="card"><h3>Aktuellen Kurs als Vorlage sichern</h3><p class="muted">Personen, Abgaben, Noten, Anwesenheiten und Nachrichten werden niemals in eine Vorlage kopiert.</p><form id="ls-template"><label class="field">Vorlagenname<input name="name" required></label><label class="field">Beschreibung<textarea name="description"></textarea></label><button class="btn">Vorlage erzeugen</button></form></div><div class="card"><h3>Vorlagen</h3>${rows.map(t=>`<div class="item"><strong>${LS(t.name)}</strong><div class="muted">Version ${LS(t.version)}</div><button class="btn secondary ls-clone" data-id="${LS(t.id)}">Neuen Jahrgang erzeugen</button></div>`).join('')||'<p class="muted">Noch keine Vorlage.</p>'}</div></div>`;p.querySelector('#ls-template').onsubmit=async e=>{e.preventDefault();await lsApi(qp('/api/learning-suite/templates',s.tenantId,activeCourse),{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.currentTarget)))});await templates(p);};p.querySelectorAll('.ls-clone').forEach(b=>b.onclick=async()=>{const name=prompt('Name der neuen Klasse / des neuen Kurses:');if(!name)return;const code=prompt('Eindeutiger Code / Kürzel:');if(!code)return;const start=prompt('Startdatum (YYYY-MM-DD), optional:','');try{await lsApi(qp(`/api/learning-suite/templates/${encodeURIComponent(b.dataset.id)}/clone`,s.tenantId,''),{method:'POST',body:JSON.stringify({name,code,start_date:start||null})});alert('Neuer Jahrgang wurde ohne personenbezogene Altdaten erzeugt.');}catch(e){alert(e.message);}});}
  async function reports(p){const defs={participants:['course_id','user_id','name','email','role','created_at'],attendance:['course_id','user_id','name','status','minutes','starts_at','subject'],assignments:['course_id','user_id','name','assignment','status','submitted_at'],grades:['course_id','user_id','name','item','points','grade','status','graded_at'],courses:['course_id','name','code','start_date','end_date','is_active'],communications:['title','priority','status','recipient_count','published_at','created_at'],certificates:['course_id','user_id','name','certificate_number','status','issued_at']};p.innerHTML=`<div class="card"><h3>Report Builder</h3><p class="muted">Nur freigegebene Datensätze und Felder können ausgewählt werden. Eigene SQL-Abfragen sind aus Sicherheitsgründen nicht möglich.</p><form id="ls-report"><div class="row"><label class="field">Datensatz<select name="dataset">${Object.keys(defs).map(x=>`<option>${LS(x)}</option>`).join('')}</select></label><label class="field">Spalten (mit Komma)<input name="columns" value="course_id,name"></label></div><button class="btn">Vorschau</button><button class="btn secondary" type="button" id="ls-report-csv">CSV exportieren</button></form><div id="ls-report-result" style="margin-top:12px"></div></div>`;const form=p.querySelector('#ls-report'),result=p.querySelector('#ls-report-result');form.dataset.changed='';form.dataset.cols='';form.dataset.dataset='participants';form.dataset.valid='';form.querySelector('[name=dataset]').onchange=e=>{form.querySelector('[name=columns]').value=defs[e.target.value].slice(0,6).join(',');};const payload=()=>({dataset:form.datasetEl?form.datasetEl.value:form.querySelector('[name=dataset]').value,columns:String(form.querySelector('[name=columns]').value).split(',').map(x=>x.trim()).filter(Boolean),filters:{course_id:activeCourse}});form.onsubmit=async e=>{e.preventDefault();const d=await lsApi(qp('/api/reports/run',s.tenantId,''),{method:'POST',body:JSON.stringify(payload())}),cols=d.columns||[],rows=d.rows||[];result.innerHTML=`<div class="table-wrap"><table><tr>${cols.map(c=>`<th scope="col">${LS(c)}</th>`).join('')}</tr>${rows.slice(0,200).map(r=>`<tr>${cols.map(c=>`<td>${LS(r[c])}</td>`).join('')}</tr>`).join('')}</table></div>${d.truncated?'<div class="notice warn">Ergebnis wurde auf 10.000 Zeilen begrenzt.</div>':''}`;};p.querySelector('#ls-report-csv').onclick=async()=>{const r=await fetch(qp('/api/reports/export.csv',s.tenantId,''),{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json'},body:JSON.stringify(payload())});if(!r.ok)return alert((await r.json().catch(()=>({}))).error||'Export fehlgeschlagen');const blob=await r.blob(),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='bericht.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};}
  async function forum(p){const d=await lsApi(qp('/api/collaboration/threads',s.tenantId,activeCourse)),threads=d.threads||[];p.innerHTML=`<div class="grid"><div class="card"><h3>Kursforum</h3><form id="ls-thread"><label class="field">Thema<input name="title" required></label><button class="btn">Thema eröffnen</button></form><p class="muted">Direktnachrichten bleiben standardmäßig deaktiviert. Das Kursforum ist moderierbar und kursgebunden.</p></div><div class="card"><h3>Themen</h3>${threads.filter(x=>x.type==='course_forum').map(t=>`<div class="item"><button class="btn secondary ls-thread-open" data-id="${LS(t.id)}">${LS(t.title)}</button></div>`).join('')||'<p class="muted">Noch kein Thema.</p>'}</div></div>`;p.querySelector('#ls-thread').onsubmit=async e=>{e.preventDefault();await lsApi(qp('/api/collaboration/threads',s.tenantId,activeCourse),{method:'POST',body:JSON.stringify({type:'course_forum',title:new FormData(e.currentTarget).get('title')})});await forum(p);};p.querySelectorAll('.ls-thread-open').forEach(b=>b.onclick=()=>threadModal(b.dataset.id));}
  async function threadModal(id){const d=await lsApi(qp(`/api/collaboration/threads/${encodeURIComponent(id)}/messages`,s.tenantId,activeCourse)),w2=document.createElement('div');w2.className='modal-back';w2.innerHTML=`<div class="modal" style="width:min(760px,96vw)"><div class="top"><h3>Forum</h3><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div class="portal-list" style="max-height:55vh;overflow:auto">${(d.messages||[]).map(m=>`<div class="item"><strong>${LS(m.display_name)}</strong><div>${LS(m.body)}</div><div class="muted">${LS(new Date(m.created_at).toLocaleString('de-DE'))}</div></div>`).join('')}</div><form id="ls-post"><label class="field">Antwort<textarea name="body" required maxlength="10000"></textarea></label><button class="btn">Senden</button></form></div>`;document.body.append(w2);w2.querySelector('[data-close]').onclick=()=>w2.remove();w2.querySelector('#ls-post').onsubmit=async e=>{e.preventDefault();await lsApi(qp(`/api/collaboration/threads/${encodeURIComponent(id)}/messages`,s.tenantId,activeCourse),{method:'POST',body:JSON.stringify({body:new FormData(e.currentTarget).get('body')})});w2.remove();await threadModal(id);};}
  await render();}
function mount(){if(document.querySelector('#ls-admin-launch'))return;const customer=document.querySelector('.side');if(customer){const b=document.createElement('button');b.className='nav';b.id='ls-admin-launch';b.textContent='Lernen & Berichte';b.onclick=()=>openWorkspace().catch(e=>alert(e.message));const a=customer.querySelector('[data-v="exams"]')||customer.querySelector('[data-v="content"]');a?.after(b);return;}if(location.pathname.replace(/\/$/,'')==='/klassen-admin'&&document.querySelector('#class-admin-portal')?.children.length){const b=document.createElement('button');b.id='ls-admin-launch';b.className='portal-btn';b.textContent='Lernen & Berichte';b.style.cssText='position:fixed;right:18px;bottom:18px;z-index:35';b.onclick=()=>openWorkspace().catch(e=>alert(e.message));document.body.append(b);}}
new MutationObserver(mount).observe(document.documentElement,{subtree:true,childList:true});mount();

// Richtlinienbestätigung in der Oberfläche (Master-Spec V2, R9).
//
// Nutzungsordnung, IT-Ordnung, Hausordnung, Datenschutzhinweise. Wenn es darauf ankommt, lautet
// die Frage nie „gab es eine Ordnung", sondern: WER hat WELCHE FASSUNG WANN bestätigt.
//
// Eine Einwilligung ist freiwillig und jederzeit widerrufbar. Eine Richtlinie ist es nicht: sie
// gilt, sie wird bestätigt, und sie kennt keinen Widerruf – nur eine neue Fassung. Deshalb steht
// hier kein „Ablehnen"-Knopf. Wer eine Pflichtrichtlinie nicht bestätigt, bekommt den betroffenen
// Bereich nicht; das sagt diese Oberfläche offen, statt es hinter einer stummen Fehlermeldung zu
// verstecken.
const PA=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function paApi(url,opt={}){
  const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});
  let d={};try{d=await r.clone().json();}catch(fehler){d={};}
  if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);
  return d;
}
const paText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):String(m||'');
const PA_BEREICH={portal:'ganzes Portal',anwesenheit:'Anwesenheit & Klassenbuch',pruefung:'Prüfungen',kommunikation:'Nachrichten',material:'Lernmaterial & Netzzugang'};
const paDatum=v=>v?String(v).slice(0,10).split('-').reverse().join('.'):'—';

function paModal(titel,inhalt){
  const w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" style="width:min(880px,97vw);max-height:93vh;overflow:auto"><div class="top"><h3 style="margin:0">${PA(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div data-inhalt>${inhalt}</div></div>`;
  document.body.append(w);
  w.querySelector('[data-close]').addEventListener('click',()=>w.remove());
  w.addEventListener('click',e=>{if(e.target===w)w.remove();});
  return w;
}

// ---------------------------------------------------------------------------
// Die eigene Seite: bestätigen
// ---------------------------------------------------------------------------
async function paEigene(tenantId){
  const w=paModal('Richtlinien des Bildungsträgers','<p>Wird geladen …</p>');
  const feld=w.querySelector('[data-inhalt]');
  async function zeichne(){
    let d;
    try{d=await paApi(`/api/personal/policies?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(fehler){feld.innerHTML=`<div class="notice bad">Die Richtlinien konnten nicht geladen werden: ${PA(paText(fehler.message))}</div>`;return;}
    const zeilen=d.policies||[];
    feld.innerHTML=`<p class="muted">Eine bestätigte Richtlinie lässt sich nicht widerrufen – sie ist ein Nachweis. Ändert der Träger den Text, entsteht eine neue Fassung, und die Bestätigung wird erneut erbeten: die alte gilt für den neuen Text ausdrücklich <strong>nicht</strong>.</p>`
      +(zeilen.length?zeilen.map(z=>`<section class="item" style="margin-bottom:12px"><h4 style="margin:0 0 4px">${PA(z.titel)}${Number(z.pflicht)?' <span class="pill">Pflicht</span>':''}</h4>`
        +`<div class="muted">Fassung ${PA(z.aktuelle_fassung)} · Bereich: ${PA(PA_BEREICH[z.bereich]||z.bereich)}</div>`
        +`<p style="white-space:pre-wrap;margin:8px 0">${PA(z.text)}</p>`
        +(z.bestaetigt?`<div class="notice ok">Bestätigt am ${PA(paDatum(z.bestaetigt_am))} (Fassung ${PA(z.bestaetigte_fassung)}).</div>`
          :`<form data-bestaetigen="${PA(z.definition_id)}"><label><input type="checkbox" name="gelesen" required> Ich habe „${PA(z.titel)}" in der Fassung ${PA(z.aktuelle_fassung)} gelesen und erkenne sie an.</label>`
            +(z.fassung_veraltet?`<div class="notice">Du hattest Fassung ${PA(z.bestaetigte_fassung)} bestätigt. Der Text wurde seither geändert; die alte Bestätigung trägt ihn nicht.</div>`:'')
            +`<div class="toolbar" style="margin-top:8px"><button class="btn" type="submit">Bestätigen</button><span class="muted" data-status></span></div></form>`)
        +`</section>`).join(''):'<p class="muted">Für diesen Kundenbereich ist keine Richtlinie hinterlegt.</p>');
    feld.querySelectorAll('[data-bestaetigen]').forEach(f=>f.addEventListener('submit',async e=>{
      e.preventDefault();
      const st=f.querySelector('[data-status]');
      if(!f.querySelector('[name=gelesen]').checked){st.textContent='Bitte bestätige zuerst, dass du die Richtlinie gelesen hast.';return;}
      st.textContent='Wird gespeichert …';
      try{
        await paApi(`/api/personal/policies?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({definition_id:f.dataset.bestaetigen,bestaetigt:true})});
        await zeichne();await paHinweisPruefen(tenantId);
      }catch(fehler){st.textContent=paText(fehler.message);}
    }));
  }
  await zeichne();
}

/** Der Hinweis im Portal: was offen ist, und was dadurch gesperrt bleibt. */
async function paHinweisPruefen(tenantId){
  let d;
  try{d=await paApi(`/api/personal/policies?tenant_id=${encodeURIComponent(tenantId)}`);}
  catch(fehler){return;}
  const offen=(d.policies||[]).filter(z=>z.offen&&Number(z.pflicht));
  const alt=document.querySelector('#pa-hinweis');
  if(!offen.length){if(alt)alt.remove();return;}
  const box=alt||document.createElement('div');
  box.id='pa-hinweis';
  box.setAttribute('role','status');
  box.setAttribute('aria-live','polite');
  box.style.cssText='position:fixed;right:18px;bottom:18px;z-index:2400;max-width:420px;padding:12px 14px;border:1px solid #b45309;border-radius:10px;background:#fff7ed;color:#1f2937;font:14px/1.4 system-ui,sans-serif;box-shadow:0 8px 24px #0003';
  box.innerHTML=`<p style="margin:0 0 6px"><strong>${offen.length} Richtlinie${offen.length===1?'':'n'} noch nicht bestätigt.</strong></p>`
    +`<p style="margin:0 0 8px">Gesperrt bleibt bis dahin: ${PA([...new Set(offen.map(z=>PA_BEREICH[z.bereich]||z.bereich))].join(', '))}.</p>`
    +`<button class="btn" type="button" data-pa-oeffnen style="padding:6px 12px">Jetzt lesen und bestätigen</button>`;
  if(!alt)document.body.append(box);
  box.querySelector('[data-pa-oeffnen]').addEventListener('click',()=>{paEigene(tenantId).catch(fehler=>alert(paText(fehler.message)));});
}

// ---------------------------------------------------------------------------
// Die Seite des Trägers: erlassen und nachhalten
// ---------------------------------------------------------------------------
async function paVerwaltung(tenantId){
  const w=paModal('Richtlinien & Bestätigungen',
    '<div class="row"><button class="btn secondary" type="button" data-t="richtlinien">Richtlinien</button><button class="btn secondary" type="button" data-t="stand">Wer hat bestätigt</button><button class="btn secondary" type="button" data-t="eigene">Meine Bestätigungen</button></div><div data-body><p>Wird geladen …</p></div>');
  const feld=w.querySelector('[data-body]');

  async function richtlinien(){
    let d;
    try{d=await paApi(`/api/compliance/policies?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(fehler){feld.innerHTML=`<div class="notice bad">Die Richtlinien konnten nicht geladen werden: ${PA(paText(fehler.message))}</div>`;return;}
    const zeilen=d.policies||[];
    feld.innerHTML=`<p class="muted">Jede Textänderung erzeugt eine neue Fassung. Eine vorher erteilte Bestätigung gilt für den neuen Text <strong>nicht</strong> – die betroffenen Personen werden erneut gefragt. Titel, Bereich und Pflichtigkeit lassen sich dagegen nachziehen, ohne die Bestätigungen zu entwerten.</p>`
      +(zeilen.length?`<div class="table-wrap"><table><thead><tr><th scope="col">Richtlinie</th><th scope="col">Fassung</th><th scope="col">Bereich</th><th scope="col">Art</th></tr></thead><tbody>`
        +zeilen.map(z=>`<tr><td><strong>${PA(z.titel)}</strong><div class="muted">${PA(z.schluessel)}</div></td><td>${PA(z.fassung)}</td><td>${PA(PA_BEREICH[z.bereich]||z.bereich)}</td><td>${Number(z.pflicht)?'Pflicht':'freiwillig'}</td></tr>`).join('')
        +`</tbody></table></div>`
        :`<p class="muted">Noch keine Richtlinie hinterlegt.</p><button class="btn" type="button" id="pa-seed">Nutzungsordnung, IT-Ordnung, Hausordnung und Datenschutzhinweise anlegen</button>`)
      +`<h4 style="margin:18px 0 6px">Richtlinie anlegen oder neu fassen</h4>`
      +`<form id="pa-neu"><div class="row"><label class="field">Schlüssel<input name="schluessel" required placeholder="hausordnung"></label>`
      +`<label class="field">Titel<input name="titel" required placeholder="Hausordnung"></label></div>`
      +`<div class="row"><label class="field">Gesperrter Bereich<select name="bereich">${Object.entries(PA_BEREICH).map(([k,v])=>`<option value="${PA(k)}">${PA(v)}</option>`).join('')}</select></label>`
      +`<label class="field" style="align-self:end"><span>Art der Richtlinie</span><select name="pflicht"><option value="1">Pflicht – sperrt den Bereich bis zur Bestätigung</option><option value="0">freiwillig – wird nur nachgehalten</option></select></label></div>`
      +`<label class="field">Wortlaut<textarea name="text" rows="5" required></textarea></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Speichern</button><span class="muted" data-status></span></div></form>`;
    const seed=feld.querySelector('#pa-seed');
    if(seed)seed.addEventListener('click',async()=>{
      try{await paApi(`/api/compliance/policies/seed?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await richtlinien();}
      catch(fehler){alert(paText(fehler.message));}
    });
    const form=feld.querySelector('#pa-neu');
    form.addEventListener('submit',async e=>{
      e.preventDefault();
      const f=new FormData(form),st=form.querySelector('[data-status]');
      st.textContent='Wird gespeichert …';
      try{
        const r=await paApi(`/api/compliance/policies?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
          schluessel:f.get('schluessel'),titel:f.get('titel'),bereich:f.get('bereich'),
          pflicht:String(f.get('pflicht'))==='1',text:f.get('text')})});
        st.textContent=`Gespeichert als Fassung ${r.policy?r.policy.fassung:'?'}.`;
        await richtlinien();
      }catch(fehler){st.textContent=paText(fehler.message);}
    });
  }

  async function stand(){
    let d;
    try{d=await paApi(`/api/compliance/policies/overview?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(fehler){feld.innerHTML=`<div class="notice bad">Der Bestätigungsstand konnte nicht geladen werden: ${PA(paText(fehler.message))}</div>`;return;}
    const zeilen=d.stand||[],offen=d.ausstehend||[];
    feld.innerHTML=`<p class="muted">Gezählt wird gegen die <strong>aktuelle</strong> Fassung. Wer die Vorgängerfassung bestätigt hat, steht deshalb wieder unter „steht noch aus" – und genau das ist richtig.</p>`
      +(zeilen.length?`<div class="table-wrap"><table><thead><tr><th scope="col">Richtlinie</th><th scope="col">Fassung</th><th scope="col">Personen</th><th scope="col">bestätigt</th><th scope="col">offen</th></tr></thead><tbody>`
        +zeilen.map(z=>`<tr><td>${PA(z.titel)}${Number(z.pflicht)?' <span class="pill">Pflicht</span>':''}</td><td>${PA(z.aktuelle_fassung)}</td><td>${PA(z.betroffen)}</td><td>${PA(z.bestaetigt)}</td><td>${PA(z.offen)}</td></tr>`).join('')
        +`</tbody></table></div>`:'<p class="muted">Noch keine Richtlinie hinterlegt.</p>')
      +`<h4 style="margin:18px 0 6px">Steht noch aus</h4>`
      +(offen.length?`<div class="table-wrap"><table><thead><tr><th scope="col">Person</th><th scope="col">Richtlinie</th></tr></thead><tbody>`
        +offen.map(z=>`<tr><td>${PA(z.display_name)}</td><td>${PA(z.titel)}</td></tr>`).join('')
        +`</tbody></table></div>${d.ausstehend_gekuerzt?'<p class="muted">Die Liste ist gekürzt – es sind mehr Einträge offen als hier angezeigt werden.</p>':''}`
        :'<p class="muted">Niemand steht mehr aus.</p>');
  }

  w.querySelectorAll('[data-t]').forEach(b=>b.addEventListener('click',()=>{void zeichne(b.dataset.t);}));
  async function zeichne(t){
    feld.innerHTML='<p>Wird geladen …</p>';
    if(t==='stand')return stand();
    if(t==='eigene'){feld.innerHTML='<p class="muted">Die eigenen Bestätigungen stehen in einem eigenen Fenster.</p>';return paEigene(tenantId);}
    return richtlinien();
  }
  await zeichne('richtlinien');
}

(async()=>{
  let me=null;
  try{me=(await paApi('/api/auth/me')).user||null;}catch(fehler){me=null;}
  if(!me)return;
  const rollen=me.tenantRoles||[];
  const mandant=()=>document.querySelector('#tenantPick')?.value
    ||new URLSearchParams(location.search).get('tenant_id')
    ||(rollen[0]?rollen[0].tenant_id:'');
  const tenantId=mandant();
  if(tenantId)await paHinweisPruefen(tenantId).catch(()=>undefined);
  if(!me.isPlatformAdmin&&!rollen.some(x=>x.role==='tenant_admin'))return;
  function mount(){
    const seite=document.querySelector('.side');
    if(!seite||document.querySelector('#pa-launch'))return;
    const anker=seite.querySelector('[data-v="data"]')||seite.querySelector('[data-v="overview"]');
    if(!anker)return;
    const b=document.createElement('button');
    b.id='pa-launch';b.className='nav';b.type='button';b.textContent='Richtlinien & Bestätigungen';
    b.addEventListener('click',()=>{paVerwaltung(mandant()).catch(fehler=>alert(paText(fehler.message)));});
    anker.after(b);
  }
  new MutationObserver(()=>{try{mount();}catch(fehler){/* die Oberflaeche baut sich noch auf */}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

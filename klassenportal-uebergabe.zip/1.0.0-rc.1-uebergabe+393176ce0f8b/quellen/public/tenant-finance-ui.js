// Träger-Finanzen: Klassenkasse, Debitoren, Honorare und Förderfälle.
//
// Vier Funktionen waren gebaut, geprüft und über die API erreichbar - und hatten keinen Knopf.
// Für den Betrieb ist das dasselbe wie nicht vorhanden: die Verwaltung hätte weiter in einer
// Tabellenkalkulation gerechnet, während das Portal die Zahlen längst führt.
const FIN_PATH=['/kunden-admin','/klassen-admin'].includes(location.pathname.replace(/\/$/,''));
if(FIN_PATH){
  const E=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money=(c,cur='EUR')=>new Intl.NumberFormat('de-DE',{style:'currency',currency:cur||'EUR'}).format(Number(c||0)/100);
  const text=x=>(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(x):String(x?.message||x))||String(x?.message||x||'');
  let navBusy=false;
  async function api(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{'content-type':'application/json',...(opt.headers||{})}});let d={};try{d=await r.json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
  function tid(){return document.querySelector('#tenantPick')?.value||'';}
  const q=(pfad,extra={})=>{const u=new URLSearchParams({tenant_id:tid(),...extra});return `${pfad}?${u}`;};
  function modal(title,body,width='1050px'){const w=document.createElement('div');w.className='modal-back';w.innerHTML=`<div class="modal" style="width:min(${width},96vw);max-height:92vh;overflow:auto"><div class="top"><h3 style="margin:0">${E(title)}</h3><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div data-body>${body}</div></div>`;document.body.append(w);w.querySelector('[data-close]').onclick=()=>w.remove();w.addEventListener('click',e=>{if(e.target===w)w.remove();});return w;}
  async function courses(){const t=tid();return t?(await api(q('/api/courses'))).courses||[]:[];}
  const opts=(xs,sel='')=>xs.map(c=>`<option value="${E(c.id)}"${String(c.id)===String(sel)?' selected':''}>${E(c.name)}</option>`).join('');

  const KOSTENTRAEGER={agentur_fuer_arbeit:'Agentur für Arbeit',jobcenter:'Jobcenter',rentenversicherung:'Rentenversicherung',berufsgenossenschaft:'Berufsgenossenschaft',betrieb:'Betrieb',land:'Land',selbstzahler:'Selbstzahler',sonstige:'Sonstige'};
  const AUSTRITT={regulaer:'regulär beendet',abbruch_teilnehmer:'Abbruch durch Teilnehmende',abbruch_traeger:'Abbruch durch Träger',arbeitsaufnahme:'Arbeitsaufnahme',krankheit:'Krankheit',umzug:'Umzug',sonstige:'Sonstige'};

  const TABS=[
    {key:'kasse',label:'Klassenkasse',render:kasse},
    {key:'debitoren',label:'Forderungen & Mahnungen',render:debitoren},
    {key:'honorar',label:'Honorare',render:honorar},
    {key:'foerderung',label:'Förderfälle & Meldung',render:foerderung},
  ];

  // --- Klassenkasse: Kleinbeträge für Klassenfahrt, Material, Kopiergeld.
  async function kasse(host){
    const cs=await courses(),d=await api(q('/api/course-fees'));
    host.innerHTML=`<section class="card"><h3 style="margin-top:0">Neue Sammlung</h3>
      <form data-new class="row" style="align-items:end;gap:10px">
        <label class="field">Klasse/Kurs<select name="course_id" required>${opts(cs)}</select></label>
        <label class="field">Zweck<input name="title" required maxlength="200" placeholder="Klassenfahrt"></label>
        <label class="field">Verwendungszweck<input name="purpose" maxlength="200" placeholder="Fahrtkosten und Übernachtung"></label>
        <label class="field">Betrag je Person (€)<input name="amount" type="number" min="0.01" step="0.01" required></label>
        <label class="field">Fällig am<input name="due_date" type="date"></label>
        <button class="btn">Anlegen</button>
      </form><span class="muted" data-status></span></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Sammlungen</h3>${
        (d.collections||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Zweck</th><th scope="col">Klasse</th><th scope="col">je Person</th><th scope="col">eingesammelt</th><th scope="col">Stand</th></tr>
        ${d.collections.map(x=>`<tr><td>${E(x.title)}</td><td>${E(cs.find(c=>c.id===x.course_id)?.name||x.course_id)}</td><td style="text-align:right">${money(x.amount_cents,x.currency)}</td><td style="text-align:right">${money(x.paid_cents||0,x.currency)} von ${money(x.expected_cents||0,x.currency)}</td><td>${E(x.status)}</td></tr>`).join('')}</table></div>`
        :'<p class="muted">Noch keine Sammlung angelegt.</p>'}</section>`;
    const f=host.querySelector('[data-new]'),st=host.querySelector('[data-status]');
    f.onsubmit=async e=>{e.preventDefault();const v=Object.fromEntries(new FormData(f));st.textContent='Wird angelegt …';
      try{await api(q('/api/course-fees'),{method:'POST',body:JSON.stringify({course_id:v.course_id,title:v.title,purpose:v.purpose||v.title,amount_cents:Math.round(Number(v.amount)*100),due_date:v.due_date||null})});await kasse(host);}
      catch(x){st.textContent=text(x);}};
  }

  // --- Debitoren: Forderungen, SEPA-Mandate, Mahnstufen, Buchungsexport.
  async function debitoren(host){
    const cs=await courses();
    const [posten,mandate,plaene,einstellungen]=await Promise.all([api(q('/api/receivables/items')),api(q('/api/receivables/mandates')),api(q('/api/receivables/plans')),api(q('/api/receivables/settings'))]);
    const einst=einstellungen.settings||{};
    const heute=new Date().toISOString().slice(0,10);
    host.innerHTML=`<section class="card"><h3 style="margin-top:0">Offene Forderungen</h3>
      <div class="row" style="align-items:end;gap:10px">
        <label class="field">Klasse/Kurs<select data-filter-course><option value="">alle</option>${opts(cs)}</select></label>
        <label><input type="checkbox" data-overdue> nur überfällige</label>
        <button class="btn secondary" data-reload>Aktualisieren</button>
        <button class="btn secondary" data-run>Fällige Forderungen erzeugen</button>
        <button class="btn secondary" data-dunning>Mahnlauf starten</button>
      </div>
      <div data-items style="margin-top:12px">${postenListe(posten)}</div>
      <p class="muted" data-status></p></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Buchungsexport</h3>
        <form data-export class="row" style="align-items:end;gap:10px">
          <label class="field">von<input name="from" type="date" required value="${E(heute.slice(0,8))}01"></label>
          <label class="field">bis<input name="to" type="date" required value="${E(heute)}"></label>
          <button class="btn">CSV herunterladen</button>
        </form>
        <p class="muted">Die Datei trägt ein BOM, damit Excel die Umlaute richtig liest.</p></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Kontierung und Mahnregeln</h3>
        <p class="muted">Ohne diese Angaben läuft weder ein Forderungslauf noch der Buchungsexport – die Konten stehen in jeder erzeugten Buchung.</p>
        <form data-settings>
          <div class="row">
            <label class="field">Forderungskonto<input name="receivable_account" required value="${E(einst.receivable_account||'')}"></label>
            <label class="field">Erlöskonto Lehrgangsgebühr<input name="revenue_account_tuition" required value="${E(einst.revenue_account_tuition||'')}"></label>
            <label class="field">Erlöskonto Kursgebühr<input name="revenue_account_course_fee" required value="${E(einst.revenue_account_course_fee||'')}"></label>
            <label class="field">Erlöskonto Mahngebühr<input name="revenue_account_dunning_fee" required value="${E(einst.revenue_account_dunning_fee||'')}"></label>
          </div>
          <div class="row">
            <label class="field">Gläubiger-Identifikationsnummer<input name="creditor_identifier" value="${E(einst.creditor_identifier||'')}"></label>
            <label class="field">Zahlungsfrist Mahnung (Tage)<input name="dunning_deadline_days" type="number" min="1" value="${E(einst.dunning_deadline_days??14)}"></label>
          </div>
          <div class="row">
            <label class="field">1. Mahnung nach Tagen<input name="dunning_level1_after_days" type="number" min="1" value="${E(einst.dunning_level1_after_days??7)}"></label>
            <label class="field">2. Mahnung nach Tagen<input name="dunning_level2_after_days" type="number" min="1" value="${E(einst.dunning_level2_after_days??21)}"></label>
            <label class="field">3. Mahnung nach Tagen<input name="dunning_level3_after_days" type="number" min="1" value="${E(einst.dunning_level3_after_days??35)}"></label>
          </div>
          <div class="row">
            <label class="field">Gebühr 1. Mahnung (€)<input name="fee1" type="number" min="0" step="0.01" value="${E(((einst.dunning_level1_fee_cents??0)/100).toFixed(2))}"></label>
            <label class="field">Gebühr 2. Mahnung (€)<input name="fee2" type="number" min="0" step="0.01" value="${E(((einst.dunning_level2_fee_cents??500)/100).toFixed(2))}"></label>
            <label class="field">Gebühr 3. Mahnung (€)<input name="fee3" type="number" min="0" step="0.01" value="${E(((einst.dunning_level3_fee_cents??1000)/100).toFixed(2))}"></label>
          </div>
          <button class="btn">Speichern</button> <span class="muted" data-settings-status></span>
        </form></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Zahlungspläne</h3>${
        (plaene.plans||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Person</th><th scope="col">Zweck</th><th scope="col">Betrag</th><th scope="col">Takt</th><th scope="col">ab</th><th scope="col">Stand</th></tr>
        ${plaene.plans.map(x=>`<tr><td>${E(x.display_name||x.user_id)}</td><td>${E(x.title)}</td><td style="text-align:right">${money(x.amount_cents,x.currency)}</td><td>${E(x.interval)}</td><td>${E(x.starts_on||'')}</td><td>${E(x.status)}</td></tr>`).join('')}</table></div>`
        :'<p class="muted">Kein Zahlungsplan hinterlegt.</p>'}</section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">SEPA-Mandate</h3>${
        (mandate.mandates||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Person</th><th scope="col">Mandat</th><th scope="col">unterschrieben</th><th scope="col">Stand</th><th scope="col"></th></tr>
        ${mandate.mandates.map(m=>`<tr><td>${E(m.display_name||m.user_id)}</td><td>${E(m.mandate_reference||'')}</td><td>${E(m.signed_on||'')}</td><td>${E(m.status)}</td><td>${m.status==='active'?`<button class="btn secondary" data-revoke="${E(m.id)}">Widerrufen</button>`:''}</td></tr>`).join('')}</table></div>`
        :'<p class="muted">Kein Mandat hinterlegt.</p>'}</section>`;
    const st=host.querySelector('[data-status]');
    const neuLaden=async()=>{
      const kurs=host.querySelector('[data-filter-course]').value,ueber=host.querySelector('[data-overdue]').checked;
      const d=await api(q('/api/receivables/items',{...(kurs?{course_id:kurs}:{}),...(ueber?{overdue_only:'1'}:{})}));
      host.querySelector('[data-items]').innerHTML=postenListe(d);verdrahtenPosten();
    };
    function verdrahtenPosten(){
      host.querySelectorAll('[data-pay]').forEach(b=>b.onclick=async()=>{
        const betrag=prompt('Eingegangener Betrag in Euro:');if(betrag===null)return;
        try{await api(q('/api/receivables/payments'),{method:'POST',body:JSON.stringify({receivable_id:b.dataset.pay,amount_cents:Math.round(Number(betrag.replace(',','.'))*100),received_on:new Date().toISOString().slice(0,10)})});await neuLaden();}
        catch(x){st.textContent=text(x);}});
    }
    verdrahtenPosten();
    host.querySelector('[data-reload]').onclick=()=>void neuLaden().catch(x=>st.textContent=text(x));
    host.querySelector('[data-run]').onclick=async()=>{st.textContent='Erzeugt …';try{const r=await api(q('/api/receivables/run'),{method:'POST',body:'{}'});st.textContent=`${r.created||0} Forderungen erzeugt.`;await neuLaden();}catch(x){st.textContent=text(x);}};
    host.querySelector('[data-dunning]').onclick=async()=>{st.textContent='Mahnlauf läuft …';try{const r=await api(q('/api/receivables/dunning/run'),{method:'POST',body:'{}'});st.textContent=`${r.dunned||r.prepared||0} Mahnungen vorbereitet.`;await neuLaden();}catch(x){st.textContent=text(x);}};
    host.querySelector('[data-export]').onsubmit=e=>{e.preventDefault();const v=Object.fromEntries(new FormData(e.currentTarget));location.href=q('/api/receivables/export.csv',{from:v.from,to:v.to});};
    const sf=host.querySelector('[data-settings]'),sfSt=host.querySelector('[data-settings-status]');
    sf.onsubmit=async e=>{e.preventDefault();const v=Object.fromEntries(new FormData(sf));
      const payload={...v,dunning_level1_fee_cents:Math.round(Number(v.fee1||0)*100),dunning_level2_fee_cents:Math.round(Number(v.fee2||0)*100),dunning_level3_fee_cents:Math.round(Number(v.fee3||0)*100)};
      delete payload.fee1;delete payload.fee2;delete payload.fee3;
      sfSt.textContent='Wird gespeichert …';
      try{await api(q('/api/receivables/settings'),{method:'POST',body:JSON.stringify(payload)});sfSt.textContent='Gespeichert.';}
      catch(x){sfSt.textContent=text(x);}};
    host.querySelectorAll('[data-revoke]').forEach(b=>b.onclick=async()=>{
      if(!confirm('Dieses Mandat wirklich widerrufen?'))return;
      try{await api(`/api/receivables/mandates/${encodeURIComponent(b.dataset.revoke)}/revoke?tenant_id=${encodeURIComponent(tid())}`,{method:'POST',body:JSON.stringify({revoked_on:new Date().toISOString().slice(0,10)})});await debitoren(host);}
      catch(x){st.textContent=text(x);}});
  }
  function postenListe(d){
    // Der Worker liefert die Posten unter rows, nicht unter items - hier stand einmal items, und
    // die Liste blieb immer leer, ohne dass irgendwo ein Fehler zu sehen war.
    const xs=d.rows||[];
    if(!xs.length)return '<p class="muted">Keine offenen Forderungen.</p>';
    const kopf=`<p class="muted">${Number(d.count||xs.length).toLocaleString('de-DE')} Posten, offen ${E(d.open_display||'')} (Stand ${E(d.as_of||'')}).</p>`;
    return `<div class="table-wrap"><table><tr><th scope="col">Beleg</th><th scope="col">Person</th><th scope="col">fällig</th><th scope="col">offen</th><th scope="col">Mahnstufe</th><th scope="col"></th></tr>
      ${xs.map(x=>`<tr><td>${E(x.document_no)}</td><td>${E(x.display_name||x.user_id)}</td><td>${E(x.due_on)}</td><td style="text-align:right">${money(Number(x.amount_cents||0)+Number(x.fee_cents||0)-Number(x.paid_cents||0),x.currency)}</td><td>${E(x.dunning_level||0)}</td>
        <td><button class="btn secondary" data-pay="${E(x.id)}">Zahlung erfassen</button></td></tr>`).join('')}</table></div>`+kopf;
  }

  // --- Honorare: Sätze, Abrechnungszeiträume, Auszahlungsliste.
  async function honorar(host){
    const [saetze,perioden,auszahlung]=await Promise.all([api(q('/api/teacher-fees/rates')),api(q('/api/teacher-fees/periods')),api(q('/api/teacher-fees/payout'))]);
    const monat=new Date().toISOString().slice(0,7);
    host.innerHTML=`<section class="card"><h3 style="margin-top:0">Abrechnung vorschlagen</h3>
      <form data-propose class="row" style="align-items:end;gap:10px">
        <label class="field">von<input name="from" type="date" required value="${E(monat)}-01"></label>
        <label class="field">bis<input name="to" type="date" required value="${E(new Date(Date.UTC(Number(monat.slice(0,4)),Number(monat.slice(5,7)),0)).toISOString().slice(0,10))}"></label>
        <button class="btn">Vorschlag erzeugen</button>
      </form>
      <p class="muted">Der Vorschlag entsteht aus den tatsächlich gehaltenen Einheiten. Bestätigen, freigeben und als bezahlt melden bleiben getrennte Schritte.</p>
      <span class="muted" data-status></span></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Zeiträume</h3>${
        (perioden.periods||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Zeitraum</th><th scope="col">Honorarkraft</th><th scope="col">Minuten</th><th scope="col">Betrag</th><th scope="col">Stand</th><th scope="col"></th></tr>
        ${perioden.periods.map(p=>`<tr><td>${E(p.period_start)} – ${E(p.period_end)}</td><td>${E(p.display_name||p.teacher_user_id||'')}</td><td style="text-align:right">${E(p.total_minutes||0)}</td><td style="text-align:right">${money(p.amount_cents,p.currency)}</td><td>${E(p.status)}</td>
          <td>${p.status==='proposed'?`<button class="btn secondary" data-confirm="${E(p.id)}">Bestätigen</button>`:''}${p.status==='confirmed'?`<button class="btn secondary" data-approve="${E(p.id)}">Freigeben</button>`:''}${p.status==='approved'?`<button class="btn secondary" data-paid="${E(p.id)}">Als bezahlt melden</button>`:''}</td></tr>`).join('')}</table></div>`
        :'<p class="muted">Noch kein Zeitraum abgerechnet.</p>'}</section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Auszahlungsliste</h3>
        <p class="muted">Was freigegeben, aber noch nicht bezahlt ist – die Liste, mit der die Buchhaltung überweist.</p>${
        (auszahlung.rows||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Honorarkraft</th><th scope="col">Zeitraum</th><th scope="col">Minuten</th><th scope="col">Betrag</th></tr>
        ${auszahlung.rows.map(x=>`<tr><td>${E(x.display_name||x.teacher_id||'')}</td><td>${E(x.period_from)} – ${E(x.period_to)}</td><td style="text-align:right">${E(x.minutes_total||0)}</td><td style="text-align:right">${E(x.display||money(x.total_cents,x.currency))}</td></tr>`).join('')}
        <tr><td colspan="2"><strong>Summe</strong></td><td style="text-align:right"><strong>${E(auszahlung.total_minutes||0)}</strong></td><td style="text-align:right"><strong>${E(auszahlung.total_display||money(auszahlung.total_cents))}</strong></td></tr></table></div>`
        :'<p class="muted">Nichts zur Auszahlung offen.</p>'}</section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Honorarsätze</h3>${
        (saetze.rates||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Honorarkraft</th><th scope="col">je Stunde</th><th scope="col">gültig ab</th><th scope="col">gültig bis</th></tr>
        ${saetze.rates.map(r=>`<tr><td>${E(r.display_name||r.teacher_user_id||'')}</td><td style="text-align:right">${money(r.cents_per_hour,r.currency)}</td><td>${E(r.valid_from||'')}</td><td>${E(r.valid_until||'—')}</td></tr>`).join('')}</table></div>`
        :'<p class="muted">Noch kein Satz hinterlegt.</p>'}</section>`;
    const st=host.querySelector('[data-status]');
    host.querySelector('[data-propose]').onsubmit=async e=>{e.preventDefault();
      const v=Object.fromEntries(new FormData(e.currentTarget));st.textContent='Wird berechnet …';
      try{const r=await api(q('/api/teacher-fees/periods/propose'),{method:'POST',body:JSON.stringify({from:v.from,to:v.to})});st.textContent=`${r.proposed??r.count??0} Abrechnungen vorgeschlagen.`;await honorar(host);}
      catch(x){st.textContent=text(x);}};
    const schritt=async(id,weg)=>{try{await api(`/api/teacher-fees/periods/${encodeURIComponent(id)}/${weg}?tenant_id=${encodeURIComponent(tid())}`,{method:'POST',body:'{}'});await honorar(host);}catch(x){st.textContent=text(x);}};
    host.querySelectorAll('[data-confirm]').forEach(b=>b.onclick=()=>schritt(b.dataset.confirm,'confirm'));
    host.querySelectorAll('[data-approve]').forEach(b=>b.onclick=()=>schritt(b.dataset.approve,'approve'));
    host.querySelectorAll('[data-paid]').forEach(b=>b.onclick=()=>schritt(b.dataset.paid,'paid'));
  }

  // --- Förderfälle und die Monatsmeldung an den Kostenträger.
  async function foerderung(host){
    const cs=await courses(),kurs=host.dataset.kurs||cs[0]?.id||'';
    host.dataset.kurs=kurs;
    const monat=host.dataset.monat||new Date().toISOString().slice(0,7);
    const faelle=kurs?await api(q('/api/funding/cases',{course_id:kurs})):{cases:[]};
    host.innerHTML=`<section class="card"><h3 style="margin-top:0">Förderfall erfassen</h3>
      <form data-case>
        <div class="row">
          <label class="field">Klasse/Kurs<select name="course_id" required>${opts(cs,kurs)}</select></label>
          <label class="field">Person (Kennung)<input name="user_id" required placeholder="Teilnehmerkennung"></label>
          <label class="field">Kostenträger<select name="cost_bearer">${Object.entries(KOSTENTRAEGER).map(([k,v])=>`<option value="${E(k)}">${E(v)}</option>`).join('')}</select></label>
        </div>
        <div class="row">
          <label class="field">Kundennummer<input name="case_number" maxlength="60"></label>
          <label class="field">Gutschein/Zuweisung<input name="voucher_number" maxlength="60"></label>
          <label class="field">Maßnahmenummer<input name="measure_number" maxlength="60"></label>
        </div>
        <div class="row">
          <label class="field">Eintritt<input name="entered_on" type="date" required></label>
          <label class="field">geplantes Ende<input name="planned_exit_on" type="date"></label>
          <label class="field">Austritt<input name="exited_on" type="date"></label>
          <label class="field">Austrittsgrund<select name="exit_reason"><option value="">—</option>${Object.entries(AUSTRITT).map(([k,v])=>`<option value="${E(k)}">${E(v)}</option>`).join('')}</select></label>
        </div>
        <button class="btn">Speichern</button> <span class="muted" data-status></span>
      </form>
      <p class="muted">Ein Austritt zählt nur mit Datum und Grund – der Kostenträger entscheidet danach über die Abrechnung des angefangenen Monats.</p></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Förderfälle des Kurses</h3>${
        (faelle.cases||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Person</th><th scope="col">Kostenträger</th><th scope="col">Nummern</th><th scope="col">Eintritt</th><th scope="col">Austritt</th><th scope="col">Stand</th></tr>
        ${faelle.cases.map(x=>`<tr><td>${E(x.display_name||x.user_id)}</td><td>${E(KOSTENTRAEGER[x.cost_bearer]||x.cost_bearer)}</td><td class="muted">${E([x.case_number,x.voucher_number,x.measure_number].filter(Boolean).join(' · ')||'—')}</td><td>${E(x.entered_on)}</td><td>${x.exited_on?`${E(x.exited_on)} (${E(AUSTRITT[x.exit_reason]||x.exit_reason||'')})`:'—'}</td><td>${E(x.status)}</td></tr>`).join('')}</table></div>`
        :'<p class="muted">Für diesen Kurs ist kein Förderfall erfasst.</p>'}</section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Monatsmeldung</h3>
        <form data-report class="row" style="align-items:end;gap:10px">
          <label class="field">Monat<input name="month" type="month" required value="${E(monat)}"></label>
          <label class="field">Kostenträger<select name="cost_bearer"><option value="">alle</option>${Object.entries(KOSTENTRAEGER).map(([k,v])=>`<option value="${E(k)}">${E(v)}</option>`).join('')}</select></label>
          <button class="btn">Meldung erzeugen</button>
        </form>
        <div data-report-out style="margin-top:12px"></div></section>`;
    const st=host.querySelector('[data-status]');
    host.querySelector('[name="course_id"]').onchange=e=>{host.dataset.kurs=e.target.value;void foerderung(host);};
    host.querySelector('[data-case]').onsubmit=async e=>{e.preventDefault();
      const v=Object.fromEntries(new FormData(e.currentTarget));
      const payload={};for(const [k,val] of Object.entries(v))if(val&&k!=='course_id')payload[k]=val;
      st.textContent='Wird gespeichert …';
      try{await api(q('/api/funding/cases',{course_id:v.course_id}),{method:'POST',body:JSON.stringify(payload)});host.dataset.kurs=v.course_id;await foerderung(host);}
      catch(x){st.textContent=text(x);}};
    host.querySelector('[data-report]').onsubmit=async e=>{e.preventDefault();
      const v=Object.fromEntries(new FormData(e.currentTarget)),out=host.querySelector('[data-report-out]');
      host.dataset.monat=v.month;out.innerHTML='<p class="muted">Wird erzeugt …</p>';
      try{
        const d=(await api(q('/api/funding/report',{month:v.month,...(v.cost_bearer?{cost_bearer:v.cost_bearer}:{})}))).report;
        out.innerHTML=d.anzahl?`<div class="table-wrap"><table><tr><th scope="col">Person</th><th scope="col">Kurs</th><th scope="col">Kostenträger</th><th scope="col">anwesend</th><th scope="col">entschuldigt</th><th scope="col">unentschuldigt</th><th scope="col">Verspätung</th><th scope="col">Ein-/Austritt</th></tr>
          ${d.faelle.map(f=>`<tr><td>${E(f.display_name)}</td><td>${E(f.course_name)}</td><td>${E(KOSTENTRAEGER[f.cost_bearer]||f.cost_bearer)}</td><td style="text-align:right">${E(f.anwesend)}</td><td style="text-align:right">${E(f.entschuldigt)}</td><td style="text-align:right">${E(f.unentschuldigt)}</td><td style="text-align:right">${E(f.verspaetung_minuten)} min</td>
            <td>${f.eintritt_im_monat?'Eintritt ':''}${f.austritt_im_monat?'Austritt':''}${!f.eintritt_im_monat&&!f.austritt_im_monat?'—':''}</td></tr>`).join('')}
          <tr><td colspan="3"><strong>Summe</strong></td><td style="text-align:right"><strong>${E(d.summe.anwesend)}</strong></td><td style="text-align:right"><strong>${E(d.summe.entschuldigt)}</strong></td><td style="text-align:right"><strong>${E(d.summe.unentschuldigt)}</strong></td><td colspan="2"></td></tr></table></div>
          <p class="muted">${E(d.hinweis)}</p>`:'<p class="muted">In diesem Monat lief kein Förderfall.</p>';
      }catch(x){out.innerHTML=`<div class="notice error">${E(text(x))}</div>`;}};
  }

  async function open(){
    const w=modal('Träger-Finanzen',`<div class="row" data-tabs style="gap:8px;margin-bottom:12px">${TABS.map((t,i)=>`<button class="btn ${i?'secondary':''}" data-tab="${E(t.key)}">${E(t.label)}</button>`).join('')}</div><div data-host><p class="muted">Wird geladen …</p></div>`);
    const host=w.querySelector('[data-host]');
    async function zeige(key){
      w.querySelectorAll('[data-tab]').forEach(b=>b.className=`btn ${b.dataset.tab===key?'':'secondary'}`);
      host.dataset.kurs='';host.innerHTML='<p class="muted">Wird geladen …</p>';
      try{await TABS.find(t=>t.key===key).render(host);}
      catch(x){host.innerHTML=`<div class="notice error">${E(text(x))}</div>`;}
    }
    w.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>void zeige(b.dataset.tab));
    await zeige('kasse');
  }

  async function ensureNav(){
    if(navBusy)return;navBusy=true;
    try{
      const side=document.querySelector('.side');
      if(!side||!tid()||side.querySelector('#kp-finance-nav'))return;
      const b=document.createElement('button');
      b.type='button';b.className='nav';b.id='kp-finance-nav';b.textContent='Träger-Finanzen';
      b.onclick=open;
      const anchor=side.querySelector('[data-v="modules"]')||side.querySelector('[data-v="exams"]');
      anchor?.after(b)||side.append(b);
    }catch{}finally{navBusy=false;}
  }
  document.addEventListener('change',e=>{if(e.target?.id==='tenantPick')setTimeout(ensureNav,50);});
  new MutationObserver(()=>queueMicrotask(ensureNav)).observe(document.querySelector('#app')||document.body,{subtree:true,childList:true});
  void ensureNav();
}

// Netzunterbrechung im Klassenraum (Master-Spec V2, B17).
//
// Der Fall ist nicht theoretisch: die Lehrkraft hakt die Anwesenheit ab, das WLAN bricht weg, sie
// klickt weiter. Bisher endete das auf zwei Arten, und beide sind falsch - die Eingabe war weg,
// oder die Oberfläche stand still und niemand wusste, ob gespeichert wurde.
//
// Drei Regeln tragen diese Datei:
//
//  1. NICHTS VORTÄUSCHEN. Eine eingereihte Eingabe ist NICHT gespeichert, und genau das steht
//     dann da. Ein grüner Haken für etwas, das der Server nie gesehen hat, ist schlimmer als
//     eine Fehlermeldung: die Lehrkraft schließt das Fenster und die Stunde ist verloren.
//  2. NICHTS VERSCHLUCKEN. Jeder Eintrag endet sichtbar - übertragen, im Konflikt oder
//     gescheitert. Es gibt keinen stillen Abbruch und keine endlose Wiederholung: nach einer
//     begrenzten Zahl von Versuchen bleibt der Eintrag mit einem Knopf stehen.
//  3. NICHTS VERLIEREN. Die Warteschlange liegt im Browserspeicher und übersteht das Neuladen
//     der Seite - auch den geschlossenen Laptop.
//
// Lesende Aufrufe bleiben lesend: sie werden nie eingereiht und bekommen nie einen
// Idempotenz-Schlüssel. Ein wiederholter Lesevorgang schadet nicht; ein wiederholter
// Schreibvorgang schon, und genau dafür gibt es den Schlüssel.
(function(){
  'use strict';
  const SPEICHER='kp-offline-warteschlange';
  const SCHREIBWEGE=['POST','PUT','PATCH','DELETE'];
  const MAX_VERSUCHE=5;
  const MAX_EINTRAEGE=200;

  const OQ=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const text=fehler=>{
    const roh=fehler&&typeof fehler.message==='string'?fehler.message:String(fehler==null?'':fehler);
    return window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(roh):roh;
  };

  let liste=[],speicherdefekt=false,laeuft=false;

  function laden(){
    try{
      const roh=window.localStorage?window.localStorage.getItem(SPEICHER):null;
      liste=roh?JSON.parse(roh):[];
      if(!Array.isArray(liste))liste=[];
    }catch(fehler){
      // Ein defekter oder gesperrter Browserspeicher wird gemeldet, nicht überspielt: die
      // Lehrkraft muss wissen, dass ihre Eingaben hier NICHT zwischengelagert werden können.
      liste=[];speicherdefekt=true;
    }
    return liste;
  }
  function sichern(){
    try{if(window.localStorage)window.localStorage.setItem(SPEICHER,JSON.stringify(liste));}
    catch(fehler){speicherdefekt=true;}
  }

  function neuerSchluessel(){
    const c=window.crypto;
    if(c&&typeof c.randomUUID==='function')return 'kp-'+c.randomUUID();
    return 'kp-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,12);
  }

  const online=()=>!(window.navigator&&window.navigator.onLine===false);

  async function uebertragen(eintrag){
    const antwort=await window.fetch(eintrag.url,{
      method:eintrag.methode,credentials:'same-origin',cache:'no-store',
      headers:{'content-type':'application/json','Idempotenz-Schluessel':eintrag.schluessel},
      body:eintrag.koerper,
    });
    let daten={};
    try{daten=await antwort.json();}catch(fehler){daten={};}
    if(!antwort.ok){
      const fehler=new Error(daten&&daten.error?daten.error:'HTTP_'+antwort.status);
      fehler.status=antwort.status;
      throw fehler;
    }
    return daten;
  }

  function einreihen(eintrag){
    if(liste.length>=MAX_EINTRAEGE)throw new Error('OFFLINE_WARTESCHLANGE_VOLL');
    liste.push(eintrag);sichern();zeichnen();
    return{zustand:'eingereiht',eintrag:eintrag};
  }

  /**
   * Einen schreibenden Aufruf absetzen.
   *
   * Ergebnis 'gesendet'   - der Server hat geantwortet, die Daten stehen.
   * Ergebnis 'eingereiht' - es gab keine Verbindung. NICHT gespeichert; wird nachgeholt.
   * Ein fachlicher Fehler des Servers (400, 403, 409 …) wird geworfen, nicht eingereiht: ihn
   * zu wiederholen würde ihn nur wiederholen.
   */
  async function sende(url,optionen){
    const opt=optionen||{};
    const methode=String(opt.method||'GET').toUpperCase();
    // Lesende Aufrufe bleiben lesend - ohne Schlüssel, ohne Warteschlange.
    if(SCHREIBWEGE.indexOf(methode)<0){
      const antwort=await window.fetch(url,{credentials:'same-origin',cache:'no-store',...opt});
      let daten={};try{daten=await antwort.json();}catch(fehler){daten={};}
      if(!antwort.ok)throw new Error(daten&&daten.error?daten.error:'HTTP_'+antwort.status);
      return{zustand:'gesendet',daten:daten};
    }
    const eintrag={
      id:neuerSchluessel(),schluessel:neuerSchluessel(),url:String(url),methode:methode,
      koerper:typeof opt.body==='string'?opt.body:JSON.stringify(opt.body||{}),
      bezeichnung:String(opt.bezeichnung||'Eingabe'),
      versuche:0,zustand:'wartet',meldung:'',angelegt_am:new Date().toISOString(),
    };
    if(!online())return einreihen(eintrag);
    try{
      const daten=await uebertragen(eintrag);
      return{zustand:'gesendet',daten:daten};
    }catch(fehler){
      // Nur der Verbindungsabbruch wird eingereiht. Ein beantworteter Fehler ist eine Antwort -
      // ihn in die Warteschlange zu legen hieße, ihn endlos zu wiederholen.
      if(fehler&&fehler.status)throw fehler;
      return einreihen(eintrag);
    }
  }

  /** Die Warteschlange der Reihe nach nachspielen. Reihenfolge zählt: sie ist die des Unterrichts. */
  async function jetztSenden(){
    if(laeuft)return{gesendet:0,offen:liste.length};
    laeuft=true;
    let gesendet=0;
    try{
      for(let i=0;i<liste.length;i++){
        const e=liste[i];
        if(e.zustand!=='wartet')continue;
        if(e.versuche>=MAX_VERSUCHE){
          e.zustand='gescheitert';
          e.meldung='Nach '+MAX_VERSUCHE+' Versuchen nicht übertragen. Bitte erneut versuchen oder den Eintrag verwerfen.';
          continue;
        }
        e.versuche++;e.zustand='laeuft';
        try{
          await uebertragen(e);
          liste.splice(i,1);i--;gesendet++;
        }catch(fehler){
          if(!fehler||!fehler.status){
            // Weiterhin ohne Verbindung: der Eintrag bleibt stehen, der Lauf endet hier. Die
            // Reihenfolge bleibt dadurch erhalten.
            e.zustand='wartet';
            e.meldung='Keine Verbindung. Wird automatisch nachgeholt.';
            break;
          }
          const code=fehler.message||'';
          e.zustand=code==='IDEMPOTENZ_KONFLIKT'?'konflikt':'gescheitert';
          e.meldung=text(fehler);
        }
      }
    }finally{
      laeuft=false;sichern();zeichnen();
    }
    return{gesendet:gesendet,offen:liste.length};
  }

  function wiederholen(id){
    const e=liste.filter(x=>x.id===id)[0];
    if(!e)return;
    // Ein Konflikt bekommt einen NEUEN Schlüssel: der alte gehört zu einer anderen Anfrage, und
    // genau daran hat der Server ihn abgewiesen. Mit demselben Schlüssel bliebe es dabei.
    if(e.zustand==='konflikt')e.schluessel=neuerSchluessel();
    e.zustand='wartet';e.versuche=0;e.meldung='';
    sichern();zeichnen();
    return jetztSenden();
  }
  function verwerfen(id){
    liste=liste.filter(x=>x.id!==id);
    sichern();zeichnen();
  }
  function warteschlange(){return liste.map(x=>({...x}));}

  // -------------------------------------------------------------------------
  // Anzeige. Sie sagt, was ist - nicht, was man gern hätte.
  // -------------------------------------------------------------------------
  const ZUSTAND={wartet:'wartet auf Verbindung',laeuft:'wird übertragen',konflikt:'Konflikt',gescheitert:'nicht übertragen'};
  let kasten=null;

  function kastenHolen(){
    if(kasten)return kasten;
    if(!window.document||!window.document.body)return null;
    kasten=window.document.createElement('div');
    kasten.id='kp-offline-anzeige';
    kasten.setAttribute('role','status');
    kasten.setAttribute('aria-live','polite');
    kasten.setAttribute('aria-label','Verbindung und wartende Eingaben');
    kasten.style.cssText='position:fixed;left:18px;bottom:18px;z-index:2400;max-width:420px;padding:12px 14px;border:1px solid #b45309;border-radius:10px;background:#fff7ed;color:#1f2937;box-shadow:0 8px 24px #0003;font:14px/1.4 system-ui,sans-serif';
    window.document.body.append(kasten);
    return kasten;
  }

  function zeichnen(){
    const offen=liste.length;
    if(!offen&&online()&&!speicherdefekt){
      if(kasten&&kasten.remove)kasten.remove();
      kasten=null;
      return;
    }
    const k=kastenHolen();
    if(!k)return;
    const kopf=!online()
      ?'Keine Verbindung zum Portal.'
      :(offen?'Verbindung steht – die wartenden Eingaben werden nachgeholt.':'Verbindung steht.');
    k.innerHTML='<p style="margin:0 0 6px"><strong>'+OQ(kopf)+'</strong></p>'
      +(speicherdefekt?'<p style="margin:0 0 6px">Dieser Browser lässt kein Zwischenspeichern zu. Bitte erst speichern, wenn die Verbindung wieder steht.</p>':'')
      +(offen?'<p style="margin:0 0 6px">'+offen+' Eingabe'+(offen===1?'':'n')+' ist noch <strong>nicht gespeichert</strong>.</p>':'')
      +(offen?'<ul style="margin:0 0 8px;padding-left:18px">'+liste.map(e=>
        '<li style="margin-bottom:6px">'+OQ(e.bezeichnung)+' · '+OQ(ZUSTAND[e.zustand]||e.zustand)
        +(e.meldung?'<br>'+OQ(e.meldung):'')
        +(e.zustand==='konflikt'||e.zustand==='gescheitert'
          ?'<br><button type="button" data-offline-wiederholen="'+OQ(e.id)+'" style="margin-top:4px;padding:6px 12px;border:1px solid #1d4ed8;border-radius:6px;background:#fff;color:#1d4ed8;cursor:pointer">Erneut versuchen</button>'
           +' <button type="button" data-offline-verwerfen="'+OQ(e.id)+'" style="margin-top:4px;padding:6px 12px;border:1px solid #9ca3af;border-radius:6px;background:#fff;color:#374151;cursor:pointer">Eintrag verwerfen</button>'
          :'')
        +'</li>').join('')+'</ul>':'')
      +(offen?'<button type="button" data-offline-alle style="padding:6px 12px;border:1px solid #1d4ed8;border-radius:6px;background:#1d4ed8;color:#fff;cursor:pointer">Jetzt erneut senden</button>':'');
    const alle=k.querySelector?k.querySelector('[data-offline-alle]'):null;
    if(alle&&alle.addEventListener)alle.addEventListener('click',()=>{liste.forEach(e=>{if(e.zustand==='gescheitert'){e.zustand='wartet';e.versuche=0;e.meldung='';}});sichern();void jetztSenden();});
    const knoepfe=k.querySelectorAll?k.querySelectorAll('[data-offline-wiederholen]'):[];
    Array.prototype.forEach.call(knoepfe,b=>b.addEventListener('click',()=>{void wiederholen(b.getAttribute('data-offline-wiederholen'));}));
    const weg=k.querySelectorAll?k.querySelectorAll('[data-offline-verwerfen]'):[];
    Array.prototype.forEach.call(weg,b=>b.addEventListener('click',()=>{verwerfen(b.getAttribute('data-offline-verwerfen'));}));
  }

  laden();
  window.KP_OFFLINE={sende,jetztSenden,wiederholen,verwerfen,warteschlange,neuerSchluessel,zeichnen,MAX_VERSUCHE};
  if(window.addEventListener){
    window.addEventListener('online',()=>{zeichnen();void jetztSenden();});
    window.addEventListener('offline',()=>{zeichnen();});
  }
  if(window.document&&window.document.addEventListener){
    window.document.addEventListener('visibilitychange',()=>{if(online())void jetztSenden();});
  }
  zeichnen();
  if(liste.length&&online())void jetztSenden();
})();

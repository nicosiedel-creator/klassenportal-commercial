const PARTICIPANT_IMPORT_PATH=location.pathname.replace(/\/$/,'')==='/kunden-admin';
if(PARTICIPANT_IMPORT_PATH){
  const E=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const tenant=()=>document.querySelector('#tenantPick')?.value||'';
  async function api(path,opt={}){const r=await fetch(path,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body&&!((opt.body) instanceof FormData)?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
  const q=(path,t=tenant())=>`${path}${path.includes('?')?'&':'?'}tenant_id=${encodeURIComponent(t)}`;
  function modal(title,html){const w=document.createElement('div');w.className='modal-back';w.innerHTML=`<div class="modal" style="width:min(1180px,97vw);max-height:94vh;overflow:auto"><div class="top"><h3 style="margin:0">${E(title)}</h3><button class="btn secondary" data-close type="button" aria-label="Schließen">×</button></div><div data-body>${html}</div></div>`;document.body.append(w);w.querySelector('[data-close]').onclick=()=>w.remove();w.addEventListener('click',e=>{if(e.target===w)w.remove()});return w;}
  // Ein technischer Code darf nie auf dem Bildschirm erscheinen. Fehlt er in diesem eigenen
  // Woerterbuch, antwortet die gemeinsame Tabelle aus kp-error-text.js - eigener Text behaelt
  // Vorrang.
  const warningText=w=>({NAME_NOT_DETECTED:'Name nicht eindeutig erkannt',EMAIL_NOT_DETECTED:'E-Mail fehlt',MULTIPLE_EMAILS:'Mehrere E-Mail-Adressen erkannt',COURSE_NOT_DETECTED:'Kein Kurs oder Organisationskontext erkannt',COURSE_NOT_RESOLVED:'Kurs konnte nicht eindeutig zugeordnet werden',COURSE_AMBIGUOUS:'Mehrere passende Kurse gefunden',COURSE_NOT_FOUND:'Kurs existiert nicht',COURSE_INACTIVE:'Zielkurs ist archiviert/inaktiv',COURSE_FORBIDDEN:'Keine Berechtigung für den erkannten Zielkurs',COURSE_FALLBACK_USED:'Zielkurs wurde vom Admin vorgegeben',ORG_CONTEXT_MISMATCH:'Standort/Bereich/Maßnahme passt nicht zum erkannten Kurs',ORG_CONTEXT_AMBIGUOUS:'Organisationszuordnung ist nicht eindeutig',ORG_CONTEXT_UNRESOLVED:'Standort/Bereich/Maßnahme konnte nicht eindeutig zugeordnet werden',ORG_FALLBACK_INVALID:'Vorgegebene Organisationseinheit ist ungültig oder inaktiv',ORG_FALLBACK_USED:'Organisationsbereich wurde als sichere Vorgabe verwendet',DUPLICATE_IN_IMPORT:'Doppelter Eintrag in diesem Import',SPECIAL_CATEGORY_DATA_DETECTED_NOT_IMPORTED:'Besonders sensible Vertragsangaben erkannt – werden nicht übernommen',BANK_DATA_DETECTED_NOT_IMPORTED:'Bankdaten erkannt – werden nicht übernommen'})[w]||(typeof window!=='undefined'&&typeof window.KP_ERROR_TEXT==='function'?window.KP_ERROR_TEXT(w):w);
  const hardBlock=new Set(['NAME_NOT_DETECTED','EMAIL_NOT_DETECTED','MULTIPLE_EMAILS','COURSE_NOT_RESOLVED','COURSE_AMBIGUOUS','COURSE_NOT_FOUND','COURSE_INACTIVE','COURSE_FORBIDDEN','ORG_CONTEXT_MISMATCH','ORG_CONTEXT_AMBIGUOUS','ORG_CONTEXT_UNRESOLVED','ORG_FALLBACK_INVALID','DUPLICATE_IN_IMPORT']);
  const blocking=c=>(c.warnings||[]).some(w=>hardBlock.has(w));
  async function pdfText(file){
    const pdfjs=await import('/vendor/pdfjs/pdf.mjs');pdfjs.GlobalWorkerOptions.workerSrc='/vendor/pdfjs/pdf.worker.mjs';const bytes=await file.arrayBuffer(),doc=await pdfjs.getDocument({data:bytes,cMapUrl:'/vendor/pdfjs/cmaps/',cMapPacked:true,standardFontDataUrl:'/vendor/pdfjs/standard_fonts/',wasmUrl:'/vendor/pdfjs/wasm/'}).promise;let text='';for(let p=1;p<=doc.numPages;p++){const page=await doc.getPage(p),content=await page.getTextContent();text+=`\n--- Seite ${p} ---\n`+content.items.map(x=>('str'in x?x.str+((x).hasEOL?'\n':' '):'')).join('');}if(text.replace(/[-\s]/g,'').length<20)throw new Error('PDF_OCR_REQUIRED');return text.slice(0,300000);}
  async function open(){
    const t=tenant();if(!t)return alert('Kein Kunde ausgewählt.');let courses=[];try{courses=(await api(`/api/courses?tenant_id=${encodeURIComponent(t)}`)).courses||[];}catch{}
    const w=modal('Teilnehmer automatisch übernehmen & einladen',`<div class="notice ok"><strong>Listen oder Verträge einlesen</strong><div class="muted" style="margin-top:5px">Unterstützt werden CSV, XLSX, JSON, Text und textbasierte PDFs. Standort, Bereich, Maßnahme/Bildungsgang sowie Klasse/Kurs werden gemeinsam ausgewertet. PDF-Verträge werden im Browser ausgelesen; der vollständige Vertrag wird nicht als Teilnehmerprofil gespeichert. Vor jeder Einladung gibt es eine Vorschau.</div></div>
      <div class="card" style="margin-top:14px"><div class="row"><label class="field">Dateien auswählen<input type="file" data-files multiple accept=".csv,.xlsx,.json,.txt,.pdf,text/csv,application/pdf,application/json"></label><label class="field">Fallback-Kurs für Verträge/PDF <span class="muted">optional</span><select data-fallback><option value="">— nur automatisch zuordnen —</option>${courses.map(c=>`<option value="${E(c.id)}">${E(c.name)}${c.code?` · ${E(c.code)}`:''}</option>`).join('')}</select></label></div><label class="field">Oder Vertrags-/Listentext einfügen<textarea data-text rows="7" placeholder="Optional: Text aus einem Vertrag oder einer Teilnehmerliste hier einfügen"></textarea></label><div class="notice"><strong>Datenschutzregel:</strong> Automatisch importiert werden nur die für Portalzugang und Zuordnung erforderlichen Angaben. Erkannte Anschrift, Geburtsdatum, Bankdaten oder besondere Kategorien werden nicht automatisch gespeichert. Mehrdeutige Standort-/Kurszuordnungen werden nie geraten.</div><div class="toolbar" style="margin-top:12px"><button class="btn" type="button" data-preview>Vorschau erstellen</button><span class="muted" data-status></span></div></div><div data-preview-area></div>`);
    const status=w.querySelector('[data-status]'),area=w.querySelector('[data-preview-area]');
    w.querySelector('[data-preview]').onclick=async()=>{
      const files=[...w.querySelector('[data-files]').files],text=w.querySelector('[data-text]').value.trim(),fallbackId=w.querySelector('[data-fallback]').value||null;if(!files.length&&!text)return alert('Bitte Datei auswählen oder Text einfügen.');status.textContent='Lese Daten und prüfe Standort-/Kurszuordnungen …';area.innerHTML='';
      try{
        let preview;
        const pdfFiles=files.filter(f=>f.name.toLowerCase().endsWith('.pdf')||f.type==='application/pdf'),other=files.filter(f=>!pdfFiles.includes(f));
        if(other.length>1||other.length&&pdfFiles.length)throw new Error('ONE_STRUCTURED_SOURCE_OR_PDFS');
        if(pdfFiles.length){const documents=[];for(const f of pdfFiles)documents.push(await pdfText(f));preview=(await api(q('/api/enterprise/participants/import/preview',t),{method:'POST',body:JSON.stringify({source_name:pdfFiles.length===1?pdfFiles[0].name:`${pdfFiles.length} PDF-Verträge`,source_kind:'pdf_text',documents,default_course_id:fallbackId})})).preview;}
        else if(other.length){const fd=new FormData();fd.append('file',other[0]);preview=(await api(q('/api/enterprise/participants/import/file-preview',t),{method:'POST',body:fd})).preview;}
        else preview=(await api(q('/api/enterprise/participants/import/preview',t),{method:'POST',body:JSON.stringify({source_name:'Eingefügter Text',source_kind:'pasted_text',text,default_course_id:fallbackId})})).preview;
        status.textContent='Vorschau erstellt.';renderPreview(w,area,preview,courses,t);
      }catch(e){status.textContent='';alert(({PDF_OCR_REQUIRED:'Diese PDF enthält keinen zuverlässig auslesbaren Text. Sie ist vermutlich gescannt und benötigt OCR. Es wurde nichts importiert.',ONE_STRUCTURED_SOURCE_OR_PDFS:'Bitte entweder genau eine strukturierte Listen-Datei oder mehrere PDF-Verträge gleichzeitig auswählen.',UNSUPPORTED_PARTICIPANT_IMPORT_FILE:'Dieses Dateiformat wird nicht direkt unterstützt. Bitte als PDF, CSV, XLSX, JSON oder Text exportieren.',IMPORT_FILE_TOO_LARGE:'Die Datei ist zu groß.'})[e.message]||(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(e):e.message));}
    };
  }
  // Der Kunde sah bisher nirgends, welche seiner Spalten das Portal gelesen hat. Lag die Erkennung
  // daneben - eine Kopfzeile heisst 'Kurs-Code' statt 'Kurscode', 'class_id' statt 'course_code' -
  // stand auf jeder Zeile "Kein Kurs erkannt", und ihm blieb nur, die Datei umzubenennen und
  // erneut hochzuladen. Hier sieht er die Zuordnung und stellt sie selbst richtig.
  const ZUORDNUNG_FELDER=[['','— nicht übernehmen —'],['display_name','Name'],['first_name','Vorname'],['last_name','Nachname'],['email','E-Mail'],['external_id','Kennung der Person'],['course_code','Kurs-/Klassenkennung'],['course_name','Kurs-/Klassenname'],['course_id','Kurs-ID des Portals'],['site','Standort'],['area','Bereich'],['measure','Maßnahme/Bildungsgang'],['org_path','Organisationspfad'],['enrollment_start','Beginn'],['enrollment_end','Ende']];
  function renderZuordnung(p){
    const spalten=(p&&p.columns)||[];if(!spalten.length||!(p&&p.source_rows))return'';
    const offen=spalten.filter(c=>!c.mapped_to).length;
    return `<section class="card" style="margin-top:14px"><h3 style="margin-top:0">Spaltenzuordnung</h3>`
      +`<p class="muted">So hat das Portal Ihre Kopfzeile gelesen. Stimmt etwas nicht, stellen Sie es hier um – die Vorschau wird sofort neu erstellt, ohne die Datei erneut hochzuladen.</p>`
      +(offen?`<div class="notice"><strong>${E(offen)} Spalte(n) werden nicht übernommen.</strong><div class="muted" style="margin-top:4px">Das ist in Ordnung, wenn dort nichts steht, was ins Portal gehört – sonst hier zuordnen.</div></div>`:'')
      +`<div class="table-wrap"><table><tr><th scope="col">Spalte in Ihrer Datei</th><th scope="col">Beispielwert</th><th scope="col">Wird gelesen als</th></tr>`
      +spalten.map(c=>`<tr><td><strong>${E(c.header)}</strong></td><td class="muted">${E(c.sample||'—')}</td><td><select data-spalte="${E(c.key)}" aria-label="Zuordnung für ${E(c.header)}">${ZUORDNUNG_FELDER.map(([v,l])=>`<option value="${v}" ${v===(c.mapped_to||'')?'selected':''}>${E(l)}</option>`).join('')}${ZUORDNUNG_FELDER.some(([v])=>v===(c.mapped_to||''))?'':`<option value="${E(c.mapped_to)}" selected>${E(c.mapped_to)}</option>`}</select></td></tr>`).join('')
      +`</table></div><span class="muted" data-zuordnung-status></span></section>`;
  }
  const IMPORT_MAX_LAEUFE=40;
  // Bei einer Hochschulliste sind es zwoelftausend Zeilen. Die liest niemand durch - gesucht wird
  // nach Rot. Ab einer Groesse, bei der die vollstaendige Liste ohnehin niemand mehr prueft, steht
  // deshalb oben die Bilanz, darunter die beanstandeten Zeilen, und dazu eine kleine Stichprobe der
  // erkannten: sonst sieht der Kunde bei einer fehlerfreien Datei eine leere Liste und haelt das
  // fuer "nichts erkannt".
  const UEBERSICHT_AB=200, STICHPROBE=10;
  const bilanz=p=>{const c=p.candidates||[],paare=c.map((x,i)=>[x,i]);
    return{gesamt:c.length,schlecht:paare.filter(([x])=>blocking(x)),gut:paare.filter(([x])=>!blocking(x))};};
  function renderPreview(w,area,p,courses,t,overrides){
    const b=bilanz(p),kurz=b.gesamt>UEBERSICHT_AB;
    const liste=kurz?[...b.schlecht,...b.gut.slice(0,STICHPROBE)]:(p.candidates||[]).map((x,i)=>[x,i]);
    const uebersicht=kurz?`<section class="card" style="margin-top:14px"><h3 style="margin-top:0">${b.gesamt.toLocaleString('de-DE')} Zeilen gelesen</h3><p><strong>${b.gut.length.toLocaleString('de-DE')}</strong> eindeutig zugeordnet – sie werden übernommen. <strong>${b.schlecht.length.toLocaleString('de-DE')}</strong> zur Prüfung – sie stehen unten.</p><p class="muted">Bei dieser Menge zeigt die Liste die beanstandeten Zeilen und ${STICHPROBE} Beispiele der erkannten, statt aller ${b.gesamt.toLocaleString('de-DE')}.</p></section>`:'';
    const cs=new Map(courses.map(c=>[c.id,c]));overrides=overrides||{};area.innerHTML=`${renderZuordnung(p)}${uebersicht}<section class="card" style="margin-top:14px"><h3 style="margin-top:0">Importvorschau</h3><p class="muted">Nur markierte, vollständig und eindeutig zugeordnete Datensätze werden angelegt. Neue Teilnehmer erhalten automatisch ihre Aktivierungs-E-Mail; bestehende Konten werden nur der Klasse hinzugefügt.</p><div class="table-wrap"><table><tr><th scope="col">Übernehmen</th><th scope="col">Name / E-Mail</th><th scope="col">ID</th><th scope="col">Standort / Struktur / Kurs</th><th scope="col">Erkennung</th><th scope="col">Hinweise</th><th scope="col">Nicht übernommen</th></tr>${liste.map(([c,i])=>{const bad=blocking(c),sens=c.detected_not_imported||{},notImported=[sens.birth_date?'Geburtsdatum':'',sens.address?'Anschrift':'',sens.bank_data?'Bankdaten':'',sens.special_category_hint?'sensible Angaben':''].filter(Boolean),course=cs.get(c.course_id)?.name||c.course_name||c.course_code||'—';return`<tr><td><input type="checkbox" aria-label="Diesen Eintrag übernehmen" data-select="${i}" ${bad?'disabled':'checked'}></td><td><strong>${E(c.display_name||'—')}</strong><div class="muted">${E(c.email||'—')}</div></td><td>${E(c.external_id||'—')}</td><td>${c.org_path?`<div>${E(c.org_path)}</div>`:''}<strong>${E(course)}</strong></td><td>${E(c.confidence)} %</td><td>${(c.warnings||[]).map(x=>`<div class="${hardBlock.has(x)?'error':'muted'}">${E(warningText(x))}</div>`).join('')||'✅ Eindeutig'}</td><td>${notImported.length?E(notImported.join(', ')):'—'}</td></tr>`}).join('')}</table></div><div class="toolbar" style="margin-top:12px"><button class="btn" type="button" data-apply>Markierte Teilnehmer übernehmen & einladen</button><span data-apply-status class="muted"></span></div></section>`;
    // Eine geaenderte Zuordnung baut die Vorschau aus denselben Zeilen neu auf - dieselbe
    // Datei, nur anders gelesen.
    for(const sel of area.querySelectorAll('[data-spalte]'))sel.onchange=async()=>{
      const st=area.querySelector('[data-zuordnung-status]');if(st)st.textContent='Erkennung läuft erneut …';
      const next={...overrides};for(const x of area.querySelectorAll('[data-spalte]'))next[x.dataset.spalte]=x.value;
      try{
        const frisch=(await api(q('/api/enterprise/participants/import/preview',t),{method:'POST',body:JSON.stringify({source_name:'Korrigierte Zuordnung',source_kind:'structured',rows:p.source_rows,column_overrides:next})})).preview;
        renderPreview(w,area,frisch,courses,t,next);
      }catch(e){if(st)st.textContent=(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(e):e.message);}
    };
    area.querySelector('[data-apply]').onclick=async()=>{// In der Uebersicht sind nicht alle Zeilen gerendert. Die Auswahl aus dem Bildschirm zu lesen
      // liesse dann genau die stillschweigend liegen, die in Ordnung sind - also kommt sie aus der
      // Liste. Was der Kunde abwaehlt, bleibt abgewaehlt: das zaehlt nur fuer gerenderte Zeilen.
      const b2=bilanz(p),kurz2=b2.gesamt>UEBERSICHT_AB;
      const abgewaehlt=new Set([...area.querySelectorAll('[data-select]:not(:checked)')].map(x=>Number(x.dataset.select)));
      const selected=kurz2?b2.gut.map(([,i])=>i).filter(i=>!abgewaehlt.has(i))
        :[...area.querySelectorAll('[data-select]:checked')].map(x=>Number(x.dataset.select));if(!selected.length)return alert('Keine vollständig geprüften Datensätze ausgewählt.');if(!confirm(`${selected.length} Teilnehmer jetzt übernehmen und neue Konten automatisch per E-Mail einladen?`))return;const b=area.querySelector('[data-apply]'),st=area.querySelector('[data-apply-status]');b.disabled=true;st.textContent='Übernehme und versende Einladungen …';try{// Ein Aufruf legt hoechstens eine begrenzte Zahl von Personen an - die Plattform laesst
        // 1000 Unteranfragen je Aufruf zu, eine Person kostet rund 16. Frueher brach eine lange
        // Liste mitten im Anlegen ab: ein Teil eingeladen, der Rest nicht, und niemand wusste
        // wer. Jetzt uebernimmt die Oberflaeche den Rest selbst, bis die Liste steht.
        let created=0,existing=0,skipped=0,laeufe=0,r=null;
        do{
          r=(await api(q('/api/enterprise/participants/import/apply',t),{method:'POST',body:JSON.stringify({batch_id:p.batch_id,digest:p.digest,selected_indexes:selected})})).result;
          laeufe++;
          created+=(r.results||[]).filter(x=>x.action==='created_invited').length;
          existing+=(r.results||[]).filter(x=>x.action==='existing_added').length;
          // Zur Pruefung zurueckgelegte Zeilen meldet jeder Lauf erneut - sie werden erst am Ende
          // einmal gezaehlt. Gezaehlt wird hier nur, was dieser Lauf wirklich versucht hat.
          skipped+=(r.results||[]).filter(x=>x.action==='skipped'&&x.reason!=='REVIEW_REQUIRED').length;
          if(r.completed)break;
          st.textContent=`Übernehme … ${created+existing} von ${selected.length} erledigt, noch ${r.remaining} offen.`;
        }while(laeufe<IMPORT_MAX_LAEUFE);
        skipped+=(r.results||[]).filter(x=>x.action==='skipped'&&x.reason==='REVIEW_REQUIRED').length;
        st.textContent=`Fertig: ${created} neu eingeladen, ${existing} bestehende Konten zugeordnet, ${skipped} übersprungen.`
          +(r.completed?'':` Es sind noch ${r.remaining} offen – bitte erneut übernehmen.`);
        if(r.completed)b.remove();else b.disabled=false;}catch(e){st.textContent=(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(e):e.message);b.disabled=false;}};
  }
  function enhance(){const side=document.querySelector('.side');if(!side||side.querySelector('#participant-import-nav'))return;const b=document.createElement('button');b.id='participant-import-nav';b.className='nav';b.dataset.customerNavSourceLabel='Teilnehmer-Einzelimport';b.textContent='Nur Teilnehmer importieren';const users=[...side.querySelectorAll('button,a')].find(x=>/Benutzer|Rollen/.test(x.textContent||'')),spacer=side.querySelector('.spacer');if(users?.nextSibling)users.parentNode.insertBefore(b,users.nextSibling);else side.insertBefore(b,spacer||null);b.onclick=open;}
  new MutationObserver(()=>queueMicrotask(enhance)).observe(document.querySelector('#app')||document.body,{subtree:true,childList:true});enhance();
}

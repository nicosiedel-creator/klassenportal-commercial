// KI-Modelle, Kosten, Herkunft und Prüfläufe.
//
// Die wichtigste Spalte ist nicht die Qualität, sondern die Region: Personendaten dürfen die
// EU nicht verlassen, und ein Modell, das das nicht einhält, taucht in der Kette gar nicht auf.
const KI=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const KI_KLASSEN=[['oeffentlich','Öffentlich'],['intern','Intern'],['personenbezogen','Personenbezogen'],['besonders','Besondere Kategorien']];
const KI_REG=[['eu','EU'],['us','USA'],['sonstige','Sonstige']];
const KI_FAEH=[['text','Text'],['vision','Bild'],['einbettung','Einbettung']];
async function kiApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const kiText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
const kiZeit=v=>{const d=new Date(String(v));return Number.isNaN(d.getTime())?String(v??''):d.toLocaleString('de-DE',{dateStyle:'short',timeStyle:'short'});};
function kiModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="ki-titel" style="width:min(1000px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="ki-titel" style="margin:0">${KI(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="ki-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#ki-body'),zu};
}

async function kiVerwaltung(tenantId){
  const {body}=kiModal('KI: Modelle, Kosten und Prüfläufe');
  async function render(){
    let m,s;
    try{m=await kiApi(`/api/ai/models?tenant_id=${encodeURIComponent(tenantId)}`);s=await kiApi(`/api/ai/status?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${KI(kiText(e.message))}</div>`;return;}
    const zeilen=(m.modelle||[]).map(x=>`<tr><th scope="row">${KI(x.anbieter)}/${KI(x.modell)}</th>`
      +`<td>${KI((JSON.parse(x.faehigkeiten_json||'[]')||[]).join(', '))}</td><td>${KI(x.region)}</td><td>${KI(x.max_datenklasse)}</td>`
      +`<td>${KI(String(x.prioritaet))}</td><td>${Number(x.aktiv)?'aktiv':'aus'}</td>`
      +`<td>${x.tenant_id?`<button class="btn secondary ki-schalt" type="button" data-id="${KI(x.id)}" data-a="${Number(x.aktiv)?0:1}">${Number(x.aktiv)?'Abschalten':'Einschalten'}</button>`:'<span class="muted">plattformweit</span>'}</td></tr>`).join('')
      ||'<tr><td colspan="7">Noch kein Modell hinterlegt — KI-Funktionen sind damit aus.</td></tr>';
    body.innerHTML=`<div class="notice${Number(s.unbestaetigte_texte)?' bad':' good'}">`
        +`${KI(String(s.aufrufe||0))} Aufrufe seit ${KI(kiZeit(s.seit))}, davon ${KI(String(s.fehler||0))} gestört und ${KI(String(s.abgelehnt||0))} abgelehnt; `
        +`${KI(String(s.mit_ausweichen||0))} mussten auf ein anderes Modell ausweichen. `
        +`${Number(s.unbestaetigte_texte)?`<strong>${KI(String(s.unbestaetigte_texte))} KI-Texte sind noch nicht geprüft.</strong>`:'Keine ungeprüften KI-Texte.'}</div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Modelle in der Reihenfolge, in der sie versucht werden</caption><thead><tr><th scope="col">Modell</th><th scope="col">Kann</th><th scope="col">Region</th><th scope="col">Höchste Datenklasse</th><th scope="col">Rang</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<form id="ki-neu"><h4>Modell eintragen</h4><label class="field">Anbieter<input name="anbieter" required></label><label class="field">Modell<input name="modell" required></label>`
      +`<fieldset><legend>Fähigkeiten</legend>${KI_FAEH.map(([k,t])=>`<label><input type="checkbox" name="faehigkeiten" value="${KI(k)}"${k==='text'?' checked':''}> ${KI(t)}</label>`).join(' ')}</fieldset>`
      +`<label class="field">Region<select name="region">${KI_REG.map(([k,t])=>`<option value="${KI(k)}">${KI(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Höchste Datenklasse<select name="max_datenklasse">${KI_KLASSEN.map(([k,t])=>`<option value="${KI(k)}"${k==='intern'?' selected':''}>${KI(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Rang (kleiner wird zuerst versucht)<input name="prioritaet" type="number" value="100"></label>`
      +`<label class="field">Cent je 1000 Eingabe-Token<input name="kosten_je_1k_eingabe_cent" type="number" min="0" value="0"></label>`
      +`<label class="field">Cent je 1000 Ausgabe-Token<input name="kosten_je_1k_ausgabe_cent" type="number" min="0" value="0"></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Eintragen</button> <button class="btn secondary" type="button" id="ki-eval">Prüfläufe</button></div></form>`
      +`<p class="error" id="ki-err" role="alert"></p>`;
    const fehler=e=>{body.querySelector('#ki-err').textContent=kiText(e.message);};
    body.querySelector('#ki-neu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await kiApi(`/api/ai/models?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        anbieter:String(f.get('anbieter')),modell:String(f.get('modell')),faehigkeiten:f.getAll('faehigkeiten').map(String),
        region:String(f.get('region')),max_datenklasse:String(f.get('max_datenklasse')),
        prioritaet:Number(f.get('prioritaet')||100),
        kosten_je_1k_eingabe_cent:Number(f.get('kosten_je_1k_eingabe_cent')||0),
        kosten_je_1k_ausgabe_cent:Number(f.get('kosten_je_1k_ausgabe_cent')||0)})});await render();}
      catch(e){fehler(e);}
    };
    body.querySelector('#ki-eval').onclick=()=>kiEvaluation(tenantId);
    body.querySelectorAll('.ki-schalt').forEach(b=>b.onclick=async()=>{
      try{await kiApi(`/api/ai/models/${encodeURIComponent(b.dataset.id)}/toggle?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({aktiv:b.dataset.a==='1'})});await render();}
      catch(e){fehler(e);}
    });
  }
  await render();
}

async function kiEvaluation(tenantId){
  const {body}=kiModal('KI-Prüfläufe');
  body.innerHTML=`<p class="muted">Feste Fälle, wiederholbarer Lauf. Ohne sie ist ein Modellwechsel ein Blindflug: die Antworten sehen weiter gut aus, und dass sie schlechter geworden sind, merkt man an der ersten Beschwerde.</p>`
    +`<form id="ki-fall"><h4>Prüffall anlegen</h4><label class="field">Zweck<input name="zweck" required placeholder="vorschlag"></label>`
    +`<label class="field">Bezeichnung<input name="bezeichnung" required></label><label class="field">Eingabe<textarea name="eingabe" rows="3" required></textarea></label>`
    +`<label class="field">Muss vorkommen (durch Komma getrennt)<input name="erwartet"></label>`
    +`<label class="field">Darf nicht vorkommen (durch Komma getrennt)<input name="verboten"></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Fall anlegen</button></div></form>`
    +`<form id="ki-lauf"><h4>Lauf starten</h4><label class="field">Zweck<input name="zweck" required></label><label class="field">Modell (Kennung)<input name="modell_id" required></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Prüfen</button> <button class="btn secondary" type="button" id="ki-vgl">Vergleich anzeigen</button></div></form>`
    +`<p class="error" id="ki-eerr" role="alert"></p><div id="ki-eout"></div>`;
  const fehler=e=>{body.querySelector('#ki-eerr').textContent=kiText(e.message);};
  const liste=v=>String(v||'').split(',').map(x=>x.trim()).filter(Boolean);
  body.querySelector('#ki-fall').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target);
    try{await kiApi(`/api/ai/evaluation/cases?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
      zweck:String(f.get('zweck')),bezeichnung:String(f.get('bezeichnung')),eingabe:String(f.get('eingabe')),
      erwartet:liste(f.get('erwartet')),verboten:liste(f.get('verboten'))})});
      body.querySelector('#ki-eout').innerHTML='<div class="notice good">Prüffall angelegt.</div>';}
    catch(e){fehler(e);}
  };
  body.querySelector('#ki-lauf').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target);
    try{const r=await kiApi(`/api/ai/evaluation/runs?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
      body:JSON.stringify({zweck:String(f.get('zweck')),modell_id:String(f.get('modell_id'))})});
      body.querySelector('#ki-eout').innerHTML=`<div class="notice${r.quote_prozent>=80?' good':' bad'}">${KI(r.modell)}: ${KI(String(r.bestanden))} von ${KI(String(r.faelle))} bestanden (${KI(String(r.quote_prozent))} %).</div>`
        +`<div style="overflow-x:auto"><table class="table"><caption>Befunde</caption><thead><tr><th scope="col">Fall</th><th scope="col">Ergebnis</th><th scope="col">Grund</th></tr></thead><tbody>`
        +(r.befunde||[]).map(b=>`<tr><th scope="row">${KI(b.fall)}</th><td>${b.bestanden?'bestanden':'durchgefallen'}</td><td>${KI(b.grund||'')}</td></tr>`).join('')+`</tbody></table></div>`;}
    catch(e){fehler(e);}
  };
  body.querySelector('#ki-vgl').onclick=async()=>{
    const zweck=body.querySelector('#ki-lauf [name=zweck]').value;
    if(!zweck){fehler(new Error('KI_KEINE_FAELLE'));return;}
    try{const r=await kiApi(`/api/ai/evaluation/comparison?tenant_id=${encodeURIComponent(tenantId)}&zweck=${encodeURIComponent(zweck)}`);
      body.querySelector('#ki-eout').innerHTML=((r.verschlechterungen||[]).length
          ?`<div class="notice bad"><strong>Schlechter geworden:</strong> ${KI(r.verschlechterungen.map(v=>`${v.modell} (${v.veraenderung} Punkte)`).join(', '))}</div>`
          :'<div class="notice good">Kein Modell ist gegenüber dem vorigen Lauf schlechter geworden.</div>')
        +`<div style="overflow-x:auto"><table class="table"><caption>Modelle im Vergleich</caption><thead><tr><th scope="col">Modell</th><th scope="col">Quote</th><th scope="col">Vorher</th><th scope="col">Veränderung</th><th scope="col">Zuletzt</th></tr></thead><tbody>`
        +(r.modelle||[]).map(x=>`<tr><th scope="row">${KI(x.modell)}</th><td>${KI(String(x.quote_prozent))} %</td><td>${x.vorher_prozent===null?'—':KI(String(x.vorher_prozent))+' %'}</td><td>${x.veraenderung===null?'—':KI(String(x.veraenderung))}</td><td>${KI(kiZeit(x.gelaufen_am))}</td></tr>`).join('')
        +`</tbody></table></div>`;}
    catch(e){fehler(e);}
  };
}

// Herkunft eines Textes — und die Bestätigung, die daraus eine Aussage des Trägers macht.
async function kiHerkunftAnzeigen(tenantId){
  const {body}=kiModal('Herkunft von KI-Texten');
  body.innerHTML=`<p class="muted">Bestätigt heißt „geprüft und übernommen“ — nicht „war nie KI“. Die Herkunft bleibt stehen.</p>`
    +`<form id="ki-h"><label class="field">Objektart<input name="objekt_typ" required placeholder="zeugnis"></label><label class="field">Objektkennung<input name="objekt_id" required></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Anzeigen</button></div></form><p class="error" id="ki-herr" role="alert"></p><div id="ki-hout"></div>`;
  body.querySelector('#ki-h').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target),typ=String(f.get('objekt_typ')),oid=String(f.get('objekt_id'));
    try{const r=await kiApi(`/api/ai/provenance?tenant_id=${encodeURIComponent(tenantId)}&objekt_typ=${encodeURIComponent(typ)}&objekt_id=${encodeURIComponent(oid)}`);
      body.querySelector('#ki-hout').innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>KI-Herkunft</caption><thead><tr><th scope="col">Feld</th><th scope="col">Modell</th><th scope="col">Erzeugt</th><th scope="col">Geprüft</th><th scope="col">Aktion</th></tr></thead><tbody>`
        +((r.herkunft||[]).map(h=>`<tr><th scope="row">${KI(h.feld)}</th><td>${KI(h.anbieter)}/${KI(h.modell)}</td><td>${KI(kiZeit(h.erzeugt_am))}</td>`
          +`<td>${h.bestaetigt_am?KI(kiZeit(h.bestaetigt_am)):'<strong>offen</strong>'}</td>`
          +`<td>${h.bestaetigt_am?'':`<button class="btn ki-ok" type="button" data-f="${KI(h.feld)}">Bestätigen</button>`}</td></tr>`).join('')
          ||'<tr><td colspan="5">Zu diesem Objekt ist kein KI-Text vermerkt.</td></tr>')+`</tbody></table></div>`;
      body.querySelectorAll('.ki-ok').forEach(b=>b.onclick=async()=>{
        try{await kiApi(`/api/ai/provenance/confirm?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
          body:JSON.stringify({objekt_typ:typ,objekt_id:oid,feld:b.dataset.f})});ev.target.requestSubmit();}
        catch(e){body.querySelector('#ki-herr').textContent=kiText(e.message);}
      });}
    catch(e){body.querySelector('#ki-herr').textContent=kiText(e.message);}
  };
}

(async()=>{
  let me=null;try{me=(await kiApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const traegerleitung=me.isPlatformAdmin||roles.some(x=>x.role==='tenant_admin');
  const verwaltung=traegerleitung||roles.some(x=>x.role==='class_admin');
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(!seite)return;
    const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
    if(traegerleitung)knopf('ki-modelle-launch','KI-Modelle',()=>kiVerwaltung(tenantId),anker,'nav');
    if(verwaltung)knopf('ki-herkunft-launch','KI-Herkunft',()=>kiHerkunftAnzeigen(tenantId),anker,'nav');
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

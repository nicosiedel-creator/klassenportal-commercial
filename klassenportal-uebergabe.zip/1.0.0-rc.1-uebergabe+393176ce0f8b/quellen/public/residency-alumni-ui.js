// Datenresidenz und Alumni.
//
// Die Residenzprüfung leitet aus dem echten Bestand ab, was wo liegt — und schönt den
// Mailversand nicht: die Plattform behauptet dafür ausdrücklich keine reine EU-Verarbeitung.
const RA=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const RA_REGION=[['de','Nur Deutschland'],['eu','EU'],['us','USA'],['weltweit','Weltweit']];
const RA_TEIL=[['datenbank','Datenbank'],['dateien','Dateien'],['mailversand','Mailversand'],['ki','KI'],['sicherung','Sicherung']];
const RA_ART=[['bestanden','Bestanden'],['teilnahme','Teilnahme'],['abgebrochen','Abgebrochen']];
const RA_UMFANG=[['zeugnis','Zeugnis'],['nachweise','Nachweise'],['veranstaltungen','Veranstaltungen']];
async function raApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const raText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function raModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="ra-titel" style="width:min(960px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="ra-titel" style="margin:0">${RA(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="ra-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#ra-body'),zu};
}

async function raResidenz(tenantId){
  const {body}=raModal('Datenresidenz');
  async function render(){
    let d;try{d=await raApi(`/api/residency?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${RA(raText(e.message))}</div>`;return;}
    const zeilen=(d.bestandteile||[]).map(b=>`<tr><th scope="row">${RA(b.bestandteil)}</th><td>${RA(b.region)}</td>`
      +`<td>${b.zugesagt?'ja':'<strong>nein</strong>'}</td><td>${RA(b.ausnahme||'')}</td></tr>`).join('');
    body.innerHTML=(d.hinweis==='RESIDENZ_OHNE_ZUSAGE'
        ? '<div class="notice">Für diesen Mandanten ist keine Datenregion zugesagt. Ohne Zusage gibt es nichts zu brechen — aber auch nichts zu belegen.</div>'
        : d.eingehalten
          ? `<div class="notice good">Zugesagt: <strong>${RA(d.zugesagte_region)}</strong> — eingehalten.</div>`
          : `<div class="notice bad">Zugesagt: <strong>${RA(d.zugesagte_region)}</strong> — <strong>${RA(String((d.verstoesse||[]).length))} Abweichung(en)</strong>: ${RA((d.verstoesse||[]).map(v=>`${v.bestandteil} (${v.region})`).join(', '))}</div>`)
      +`<div style="overflow-x:auto"><table class="table"><caption>Wo die Daten liegen</caption><thead><tr><th scope="col">Bestandteil</th><th scope="col">Region</th><th scope="col">Zugesagt</th><th scope="col">Ausnahme</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<form id="ra-fest"><h4>Zusage festlegen</h4><label class="field">Region<select name="zugesagte_region">${RA_REGION.map(([k,t])=>`<option value="${RA(k)}"${k===d.zugesagte_region?' selected':''}>${RA(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Rechtsgrundlage / Fundstelle<input name="rechtsgrundlage"></label>`
      +`<label><input type="checkbox" name="ausnahmen_erlaubt"> Begründete Ausnahmen zulassen</label>`
      +`<div class="toolbar"><button class="btn" type="submit">Festlegen</button></div></form>`
      +`<form id="ra-aus"><h4>Ausnahme erteilen</h4><label class="field">Bestandteil<select name="bestandteil">${RA_TEIL.map(([k,t])=>`<option value="${RA(k)}">${RA(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Region<select name="region">${RA_REGION.map(([k,t])=>`<option value="${RA(k)}">${RA(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Begründung<textarea name="begruendung" rows="2" required></textarea></label>`
      +`<label class="field">Gültig bis<input name="gueltig_bis" type="date"></label>`
      +`<div class="toolbar"><button class="btn secondary" type="submit">Ausnahme erteilen</button></div></form><p class="error" id="ra-err" role="alert"></p>`;
    const fehler=e=>{body.querySelector('#ra-err').textContent=raText(e.message);};
    body.querySelector('#ra-fest').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await raApi(`/api/residency?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        zugesagte_region:String(f.get('zugesagte_region')),rechtsgrundlage:String(f.get('rechtsgrundlage')||''),
        ausnahmen_erlaubt:f.get('ausnahmen_erlaubt')==='on'})});await render();}
      catch(e){fehler(e);}
    };
    body.querySelector('#ra-aus').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target),daten={};
      for(const [k,v] of f.entries())if(String(v).trim())daten[k]=String(v).trim();
      try{await raApi(`/api/residency/exceptions?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(daten)});await render();}
      catch(e){fehler(e);}
    };
  }
  await render();
}

async function raAlumni(tenantId){
  const {body}=raModal('Alumni');
  async function render(){
    let d,k;
    try{d=await raApi(`/api/alumni?tenant_id=${encodeURIComponent(tenantId)}`);
      k=await raApi(`/api/alumni/contactable?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${RA(raText(e.message))}</div>`;return;}
    const zeilen=(k.alumni||[]).map(a=>`<tr><th scope="row">${RA(a.display_name)}</th><td>${RA(a.abschluss_am)}</td><td>${RA(a.abschlussart)}</td>`
      +`<td><button class="btn secondary ra-ende" type="button" data-id="${RA(a.user_id)}">Status beenden</button></td></tr>`).join('')
      ||'<tr><td colspan="4">Niemand hat in die Kontaktaufnahme eingewilligt.</td></tr>';
    body.innerHTML=`<div class="notice">${RA(String(d.gesamt||0))} Abschlüsse (${RA(String(d.bestanden||0))} bestanden, ${RA(String(d.abgebrochen||0))} abgebrochen), `
        +`Quote ${d.abschlussquote_prozent===null?'—':RA(String(d.abschlussquote_prozent))+' %'}. `
        +`Laufende Teilnehmende: ${RA(String(d.laufende_teilnehmer||0))} — Abgeschlossene zählen dort nicht mit.</div>`
      +`<p class="muted">Angesprochen werden dürfen nur Eingewilligte. Ohne diesen Filter wäre die Liste ein Adressbestand ohne Grundlage.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Ansprechbare Alumni (${RA(String(d.ansprechbar||0))})</caption><thead><tr><th scope="col">Person</th><th scope="col">Abschluss</th><th scope="col">Art</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<form id="ra-ab"><h4>Abschluss vollziehen</h4><label class="field">Person (Kennung)<input name="user_id" required></label>`
      +`<label class="field">Kurs (Kennung)<input name="course_id"></label>`
      +`<label class="field">Art<select name="abschlussart">${RA_ART.map(([x,t])=>`<option value="${RA(x)}">${RA(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Abschlussdatum<input name="abschluss_am" type="date"></label>`
      +`<fieldset><legend>Bleibt zugänglich</legend>${RA_UMFANG.map(([x,t])=>`<label><input type="checkbox" name="umfang" value="${RA(x)}"${x!=='veranstaltungen'?' checked':''}> ${RA(t)}</label>`).join(' ')}</fieldset>`
      +`<div class="toolbar"><button class="btn" type="submit">Abschließen</button></div></form><p class="error" id="ra-aerr" role="alert"></p>`;
    const fehler=e=>{body.querySelector('#ra-aerr').textContent=raText(e.message);};
    body.querySelector('#ra-ab').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target),daten={umfang:f.getAll('umfang').map(String)};
      for(const [x,v] of f.entries())if(x!=='umfang'&&String(v).trim())daten[x]=String(v).trim();
      try{await raApi(`/api/alumni?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(daten)});await render();}
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.ra-ende').forEach(b=>b.onclick=async()=>{
      if(!confirm('Alumni-Status beenden?'))return;
      try{await raApi(`/api/alumni/end?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({user_id:b.dataset.id})});await render();}
      catch(e){fehler(e);}
    });
  }
  await render();
}

// Für die Person selbst: der eigene Abschluss und die Einwilligung, die sie jederzeit widerruft.
async function raMeineAbschluesse(tenantId){
  const {body}=raModal('Mein Abschluss');
  async function render(){
    let d;try{d=await raApi(`/api/personal/alumni?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${RA(raText(e.message))}</div>`;return;}
    const zeilen=(d.abschluesse||[]).map(a=>`<tr><th scope="row">${RA(a.abschluss_am)}</th><td>${RA(a.abschlussart)}</td>`
      +`<td>${RA((JSON.parse(a.umfang_json||'[]')||[]).join(', '))}</td><td>${RA(a.status)}</td>`
      +`<td>${Number(a.kontakt_einwilligung)?'erteilt':'nicht erteilt'}</td></tr>`).join('')
      ||'<tr><td colspan="5">Für Sie ist kein Abschluss vermerkt.</td></tr>';
    const offen=(d.abschluesse||[]).some(a=>a.status==='aktiv');
    body.innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Meine Abschlüsse</caption><thead><tr><th scope="col">Datum</th><th scope="col">Art</th><th scope="col">Zugänglich bleibt</th><th scope="col">Stand</th><th scope="col">Kontakt</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +(offen?`<div class="toolbar"><button class="btn" type="button" id="ra-ja">Kontaktaufnahme erlauben</button> <button class="btn secondary" type="button" id="ra-nein">Widerrufen</button> <button class="btn secondary" type="button" id="ra-weg">Alumni-Status beenden</button></div>`:'')
      +`<p class="error" id="ra-merr" role="alert"></p>`;
    const fehler=e=>{body.querySelector('#ra-merr').textContent=raText(e.message);};
    const einwilligung=async erteilt=>{
      try{await raApi(`/api/personal/alumni/consent?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({erteilt})});await render();}
      catch(e){fehler(e);}
    };
    if(offen){
      body.querySelector('#ra-ja').onclick=()=>einwilligung(true);
      body.querySelector('#ra-nein').onclick=()=>einwilligung(false);
      body.querySelector('#ra-weg').onclick=async()=>{
        if(!confirm('Alumni-Status beenden? Danach ist auch das Zeugnis hier nicht mehr abrufbar.'))return;
        try{await raApi(`/api/alumni/end?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await render();}
        catch(e){fehler(e);}
      };
    }
  }
  await render();
}

(async()=>{
  let me=null;try{me=(await raApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const traegerleitung=me.isPlatformAdmin||roles.some(x=>x.role==='tenant_admin');
  const verwaltung=traegerleitung||roles.some(x=>x.role==='class_admin');
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(seite){
      const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
      if(traegerleitung)knopf('ra-residenz-launch','Datenresidenz',()=>raResidenz(tenantId),anker,'nav');
      if(verwaltung)knopf('ra-alumni-launch','Alumni',()=>raAlumni(tenantId),anker,'nav');
    }
    const portal=document.querySelector('.portal-main');
    if(portal&&!document.querySelector('#ra-portal-btn')){
      const b=document.createElement('button');b.id='ra-portal-btn';b.type='button';b.className='portal-btn secondary';b.textContent='Mein Abschluss';
      b.onclick=()=>raMeineAbschluesse(tenantId).catch(e=>alert(raText(e.message)));
      (document.querySelector('#gs-portal-buttons')||portal).append(b);
    }
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

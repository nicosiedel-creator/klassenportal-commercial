// Inventar, Beschaffung, Raumwartung und Bibliothek.
//
// Zwei Listen sind der eigentliche Zweck: was noch bei jemandem liegt, und was noch nicht
// freigegeben ist. Beides steht deshalb oben, nicht in einem Unterpunkt.
const IL=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const IL_KAT=[['it','IT'],['moebel','Möbel'],['werkzeug','Werkzeug'],['fahrzeug','Fahrzeug'],['lehrmittel','Lehrmittel'],['sonstiges','Sonstiges']];
const IL_ZUSTAND=[['neu','Neu'],['gut','Gut'],['gebraucht','Gebraucht'],['defekt','Defekt']];
const IL_STUFE=[['kosmetisch','Kosmetisch'],['betrieblich','Betrieblich'],['sicherheitsrelevant','Sicherheitsrelevant']];
const IL_ART=[['buch','Buch'],['zeitschrift','Zeitschrift'],['medium','Medium'],['geraet','Gerät']];
const ilName=(l,k)=>(l.find(x=>x[0]===k)||[k,k])[1];
const ilEuro=c=>(Number(c||0)/100).toLocaleString('de-DE',{style:'currency',currency:'EUR'});
async function ilApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const ilText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;

function ilModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="il-titel" style="width:min(1040px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="il-titel" style="margin:0">${IL(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="il-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#il-body'),zu};
}

async function ilInventar(tenantId){
  const {body}=ilModal('Inventar, Beschaffung und Wartung');
  const melde=t=>{const p=body.querySelector('#il-err');if(p)p.textContent=t;};
  async function render(){
    let d,personen=[],raeume=[];
    try{d=await ilApi(`/api/inventory?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${IL(ilText(e.message))}</div>`;return;}
    try{personen=(await ilApi(`/api/tenant/users?tenant_id=${encodeURIComponent(tenantId)}`)).users||[];}catch{}
    try{raeume=(await ilApi(`/api/education/planning/resources?tenant_id=${encodeURIComponent(tenantId)}`)).resources||[];}catch{}

    const offene=(d.offene_ausgaben||[]).map(a=>`<tr><th scope="row">${IL(a.inventarnummer)}</th><td>${IL(a.bezeichnung)}</td>`
      +`<td>${IL(a.display_name)}</td><td>${IL(a.kurs||'')}</td><td>${IL(a.faellig_am||'')}</td>`
      +`<td class="toolbar" style="gap:.25rem;flex-wrap:wrap"><button class="btn" type="button" data-ret="${IL(a.id)}">Zurücknehmen</button>`
      +`<button class="btn secondary" type="button" data-loss="${IL(a.id)}">Verlust</button></td></tr>`).join('')
      ||'<tr><td colspan="6">Nichts offen.</td></tr>';

    const bestand=(d.bestand||[]).map(b=>`<tr><th scope="row">${IL(b.status)}</th><td>${IL(ilName(IL_KAT,b.kategorie))}</td>`
      +`<td>${IL(b.anzahl)}</td><td>${IL(ilEuro(b.wert_cent))}</td></tr>`).join('')||'<tr><td colspan="4">Noch kein Bestand.</td></tr>';

    const beschaffung=(d.beschaffung||[]).map(b=>{
      const knoepfe=[];
      if(b.status==='bedarf')knoepfe.push(`<button class="btn" type="button" data-appr="${IL(b.id)}">Freigeben</button>`,
        `<button class="btn secondary" type="button" data-rej="${IL(b.id)}">Ablehnen</button>`);
      if(b.status==='freigegeben')knoepfe.push(`<button class="btn" type="button" data-ord="${IL(b.id)}">Bestellen</button>`);
      if(b.status==='bestellt'||b.status==='teilgeliefert')knoepfe.push(`<button class="btn" type="button" data-rcp="${IL(b.id)}">Wareneingang</button>`);
      const hinweis=b.braucht_zweitfreigabe&&!b.zweitfreigabe_von
        ?'<span class="tag">zweite Freigabe nötig</span>':'';
      return `<tr><th scope="row">${IL(b.nummer)}</th><td>${IL(b.titel)}</td><td>${IL(b.menge)} × ${IL(ilEuro(b.einzelpreis_cent))}<br><strong>${IL(ilEuro(b.summe_cent))}</strong></td>`
        +`<td>${IL(b.status)} ${hinweis}</td><td class="toolbar" style="gap:.25rem;flex-wrap:wrap">${knoepfe.join('')}</td></tr>`;
    }).join('')||'<tr><td colspan="5">Nichts offen.</td></tr>';

    const wartung=(d.wartung||[]).map(w=>`<tr><th scope="row">${IL(w.titel)}</th><td>${IL(w.raum||w.inventarnummer||'')}</td>`
      +`<td>${IL(ilName(IL_STUFE,w.einstufung))}${w.einstufung==='sicherheitsrelevant'?' <span class="tag bad">Raum gesperrt</span>':''}</td>`
      +`<td>${IL(String(w.gemeldet_am||'').slice(0,10))}</td>`
      +`<td><button class="btn" type="button" data-fix="${IL(w.id)}">Behoben</button></td></tr>`).join('')
      ||'<tr><td colspan="5">Kein offener Mangel.</td></tr>';

    const personOpt=personen.map(p=>`<option value="${IL(p.user_id||p.id)}">${IL(p.display_name||p.email)}</option>`).join('');
    const raumOpt=`<option value="">— kein Raum —</option>`+raeume.map(r=>`<option value="${IL(r.id)}">${IL(r.name)}</option>`).join('');

    body.innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Bei wem liegt was</caption><thead><tr>`
      +`<th scope="col">Inventarnr.</th><th scope="col">Gegenstand</th><th scope="col">Person</th><th scope="col">Kurs</th>`
      +`<th scope="col">Rückgabe bis</th><th scope="col">Nächster Schritt</th></tr></thead><tbody>${offene}</tbody></table></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Bestand</caption><thead><tr><th scope="col">Stand</th>`
      +`<th scope="col">Kategorie</th><th scope="col">Anzahl</th><th scope="col">Wert</th></tr></thead><tbody>${bestand}</tbody></table></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Beschaffung</caption><thead><tr><th scope="col">Nr.</th>`
      +`<th scope="col">Was</th><th scope="col">Umfang</th><th scope="col">Stand</th><th scope="col">Nächster Schritt</th>`
      +`</tr></thead><tbody>${beschaffung}</tbody></table></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Offene Mängel</caption><thead><tr><th scope="col">Mangel</th>`
      +`<th scope="col">Wo</th><th scope="col">Einstufung</th><th scope="col">Gemeldet</th><th scope="col">Nächster Schritt</th>`
      +`</tr></thead><tbody>${wartung}</tbody></table></div>`
      +`<form id="il-neu"><h4>Gegenstand erfassen</h4>`
      +`<label class="field">Inventarnummer<input name="inventarnummer" required></label>`
      +`<label class="field">Bezeichnung<input name="bezeichnung" required></label>`
      +`<label class="field">Kategorie<select name="kategorie">${IL_KAT.map(([k,t])=>`<option value="${IL(k)}">${IL(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Seriennummer<input name="seriennummer"></label>`
      +`<label class="field">Fest im Raum<select name="resource_id">${raumOpt}</select></label>`
      +`<label class="field">Anschaffungswert (Euro)<input name="wert_euro" type="number" min="0" step="0.01"></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Erfassen</button></div></form>`
      +`<form id="il-aus"><h4>Ausgeben</h4>`
      +`<label class="field">Inventarnummer<input name="inventarnummer" required></label>`
      +`<label class="field">An<select name="user_id" required>${personOpt}</select></label>`
      +`<label class="field">Rückgabe bis<input name="faellig_am" type="date"></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Ausgeben</button></div></form>`
      +`<form id="il-besch"><h4>Beschaffung anfordern</h4>`
      +`<label class="field">Was<input name="titel" required></label>`
      +`<label class="field">Kategorie<select name="kategorie">${IL_KAT.map(([k,t])=>`<option value="${IL(k)}">${IL(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Menge<input name="menge" type="number" min="1" step="1" required></label>`
      +`<label class="field">Einzelpreis (Euro)<input name="preis_euro" type="number" min="0" step="0.01" required></label>`
      +`<label class="field">Begründung<textarea name="begruendung" rows="2"></textarea></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Anfordern</button></div></form>`
      +`<form id="il-mangel"><h4>Mangel melden</h4>`
      +`<label class="field">Raum<select name="resource_id">${raumOpt}</select></label>`
      +`<label class="field">Was ist defekt<input name="titel" required></label>`
      +`<label class="field">Einstufung<select name="einstufung">${IL_STUFE.map(([k,t])=>`<option value="${IL(k)}">${IL(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Beschreibung<textarea name="beschreibung" rows="2"></textarea></label>`
      +`<div class="notice">Ein <strong>sicherheitsrelevanter</strong> Mangel sperrt den Raum für die Planung, bis er behoben ist.</div>`
      +`<div class="toolbar"><button class="btn" type="submit">Melden</button></div></form>`
      +`<p class="error" id="il-err" role="alert"></p>`;

    const post=async(pfad,daten)=>{await ilApi(`/api/${pfad}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(daten)});await render();};
    const fehler=e=>melde(ilText(e.message));

    body.querySelector('#il-neu').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);
      const euro=String(f.get('wert_euro')||'').replace(',','.');
      try{await post('inventory',{inventarnummer:f.get('inventarnummer'),bezeichnung:f.get('bezeichnung'),
        kategorie:f.get('kategorie'),seriennummer:f.get('seriennummer')||undefined,resource_id:f.get('resource_id')||undefined,
        anschaffung_cent:euro?Math.round(Number(euro)*100):undefined});}catch(err){fehler(err);}};

    body.querySelector('#il-aus').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);
      try{await post('inventory/issue',{inventarnummer:String(f.get('inventarnummer')).trim(),
        user_id:f.get('user_id'),faellig_am:f.get('faellig_am')||undefined});}catch(err){fehler(err);}};

    body.querySelector('#il-besch').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);
      const euro=String(f.get('preis_euro')).replace(',','.');
      try{await post('procurement',{titel:f.get('titel'),kategorie:f.get('kategorie'),menge:Number(f.get('menge')),
        einzelpreis_cent:Math.round(Number(euro)*100),begruendung:f.get('begruendung')||undefined});}catch(err){fehler(err);}};

    body.querySelector('#il-mangel').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);
      try{await post('maintenance',{resource_id:f.get('resource_id')||undefined,titel:f.get('titel'),
        einstufung:f.get('einstufung'),beschreibung:f.get('beschreibung')||undefined});}catch(err){fehler(err);}};

    body.querySelectorAll('[data-ret]').forEach(b=>b.onclick=async()=>{
      const zustand=prompt('In welchem Zustand kommt es zurück? neu / gut / gebraucht / defekt','gut');
      if(!zustand)return;
      try{await post('inventory/return',{ausgabe_id:b.dataset.ret,zustand:zustand.trim().toLowerCase()});}catch(err){fehler(err);}});
    body.querySelectorAll('[data-loss]').forEach(b=>b.onclick=async()=>{
      const grund=prompt('Was ist passiert?');if(!grund)return;
      try{await post('inventory/loss',{ausgabe_id:b.dataset.loss,grund});}catch(err){fehler(err);}});
    body.querySelectorAll('[data-appr]').forEach(b=>b.onclick=async()=>{
      try{await post('procurement/approve',{request_id:b.dataset.appr});}catch(err){fehler(err);}});
    body.querySelectorAll('[data-rej]').forEach(b=>b.onclick=async()=>{
      const grund=prompt('Warum wird abgelehnt?');if(!grund)return;
      try{await post('procurement/reject',{request_id:b.dataset.rej,grund});}catch(err){fehler(err);}});
    body.querySelectorAll('[data-ord]').forEach(b=>b.onclick=async()=>{
      try{await post('procurement/order',{request_id:b.dataset.ord});}catch(err){fehler(err);}});
    body.querySelectorAll('[data-rcp]').forEach(b=>b.onclick=async()=>{
      const menge=prompt('Wie viele sind geliefert worden?');if(!menge)return;
      try{await post('procurement/receipt',{request_id:b.dataset.rcp,menge:Number(menge)});}catch(err){fehler(err);}});
    body.querySelectorAll('[data-fix]').forEach(b=>b.onclick=async()=>{
      const text=prompt('Was wurde gemacht?');if(!text)return;
      try{await post('maintenance/fix',{ticket_id:b.dataset.fix,text});}catch(err){fehler(err);}});
  }
  await render();
}

async function ilAbgang(tenantId,courseId){
  const {body}=ilModal('Was beim Abgang noch offen ist');
  try{
    const d=await ilApi(`/api/inventory/open-issues?tenant_id=${encodeURIComponent(tenantId)}&course_id=${encodeURIComponent(courseId||'')}`);
    const zeilen=(d.offen||[]).map(a=>`<tr><th scope="row">${IL(a.inventarnummer)}</th><td>${IL(a.bezeichnung)}</td>`
      +`<td>${IL(a.display_name)}</td><td>${IL(a.faellig_am||'')}</td></tr>`).join('')
      ||'<tr><td colspan="4">Nichts offen – alle Geräte sind zurück.</td></tr>';
    body.innerHTML=`<div class="notice">Offener Wert: <strong>${IL(ilEuro(d.wert_cent))}</strong></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Noch nicht zurück</caption><thead><tr>`
      +`<th scope="col">Inventarnr.</th><th scope="col">Gegenstand</th><th scope="col">Person</th><th scope="col">Rückgabe bis</th>`
      +`</tr></thead><tbody>${zeilen}</tbody></table></div>`;
  }catch(e){body.innerHTML=`<div class="notice bad">${IL(ilText(e.message))}</div>`;}
}

async function ilBibliothek(tenantId){
  const {body}=ilModal('Bibliothek und Ausleihe');
  const melde=t=>{const p=body.querySelector('#il-berr');if(p)p.textContent=t;};
  async function render(){
    let d,personen=[];
    try{d=await ilApi(`/api/library?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${IL(ilText(e.message))}</div>`;return;}
    try{personen=(await ilApi(`/api/tenant/users?tenant_id=${encodeURIComponent(tenantId)}`)).users||[];}catch{}
    const personOpt=personen.map(p=>`<option value="${IL(p.user_id||p.id)}">${IL(p.display_name||p.email)}</option>`).join('');
    const titelOpt=(d.titel||[]).map(t=>`<option value="${IL(t.id)}">${IL(t.titel)} (${IL(t.frei||0)}/${IL(t.exemplare||0)} frei)</option>`).join('');

    const titel=(d.titel||[]).map(t=>`<tr><th scope="row">${IL(t.titel)}</th><td>${IL(t.urheber||'')}</td>`
      +`<td>${IL(ilName(IL_ART,t.art))}</td><td>${IL(t.frei||0)} von ${IL(t.exemplare||0)}</td>`
      +`<td><button class="btn secondary" type="button" data-copy="${IL(t.id)}">Exemplar</button></td></tr>`).join('')
      ||'<tr><td colspan="5">Noch kein Titel erfasst.</td></tr>';

    const ausleihen=(d.ausleihen||[]).map(a=>`<tr><th scope="row">${IL(a.titel)}</th><td>${IL(a.exemplarnummer)}</td>`
      +`<td>${IL(a.display_name||'')}</td><td>${IL(a.faellig_am)}</td><td>${a.mahnstufe>0?`Mahnstufe ${IL(a.mahnstufe)}`:''}</td>`
      +`<td class="toolbar" style="gap:.25rem;flex-wrap:wrap"><button class="btn" type="button" data-back="${IL(a.id)}">Zurück</button>`
      +`<button class="btn secondary" type="button" data-ext="${IL(a.id)}">Verlängern</button>`
      +`<button class="btn secondary" type="button" data-lost="${IL(a.id)}">Verlust</button></td></tr>`).join('')
      ||'<tr><td colspan="6">Nichts ausgeliehen.</td></tr>';

    const vor=(d.vormerkungen||[]).map(v=>`<tr><th scope="row">${IL(v.titel)}</th><td>${IL(v.display_name)}</td>`
      +`<td>${v.status==='bereit'?`liegt bereit bis ${IL(v.bereit_bis||'')}`:'wartet'}</td></tr>`).join('')
      ||'<tr><td colspan="3">Keine Vormerkung.</td></tr>';

    body.innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Bestand</caption><thead><tr><th scope="col">Titel</th>`
      +`<th scope="col">Urheber</th><th scope="col">Art</th><th scope="col">Frei</th><th scope="col">Nächster Schritt</th>`
      +`</tr></thead><tbody>${titel}</tbody></table></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Laufende Ausleihen</caption><thead><tr><th scope="col">Titel</th>`
      +`<th scope="col">Exemplar</th><th scope="col">Person</th><th scope="col">Fällig</th><th scope="col">Mahnung</th>`
      +`<th scope="col">Nächster Schritt</th></tr></thead><tbody>${ausleihen}</tbody></table></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Vormerkungen</caption><thead><tr><th scope="col">Titel</th>`
      +`<th scope="col">Person</th><th scope="col">Stand</th></tr></thead><tbody>${vor}</tbody></table></div>`
      +`<div class="toolbar"><button class="btn secondary" type="button" id="il-mahn">Überfällige mahnen</button>`
      +`<button class="btn secondary" type="button" id="il-frist">Abholfristen räumen</button></div>`
      +`<form id="il-titel"><h4>Titel erfassen</h4>`
      +`<label class="field">Titel<input name="titel" required></label>`
      +`<label class="field">Urheber<input name="urheber"></label>`
      +`<label class="field">Art<select name="art">${IL_ART.map(([k,t])=>`<option value="${IL(k)}">${IL(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Leihdauer (Tage)<input name="leihdauer_tage" type="number" min="1" max="365" value="28"></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Erfassen</button></div></form>`
      +`<form id="il-leihe"><h4>Ausleihen</h4>`
      +`<label class="field">Titel<select name="title_id" required>${titelOpt}</select></label>`
      +`<label class="field">An<select name="user_id" required>${personOpt}</select></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Ausleihen</button>`
      +`<button class="btn secondary" type="button" id="il-vor">Stattdessen vormerken</button></div></form>`
      +`<div class="notice">Nach der Rückgabe wird die Person aus der Ausleihe entfernt. Wer welches Buch gelesen hat, beantwortet das Portal danach nicht mehr — auch nicht auf Nachfrage.</div>`
      +`<p class="error" id="il-berr" role="alert"></p>`;

    const post=async(pfad,daten)=>{await ilApi(`/api/${pfad}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(daten)});await render();};
    const fehler=e=>melde(ilText(e.message));

    body.querySelector('#il-titel').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);
      try{await post('library/titles',{titel:f.get('titel'),urheber:f.get('urheber')||undefined,art:f.get('art'),
        leihdauer_tage:Number(f.get('leihdauer_tage'))||28});}catch(err){fehler(err);}};
    body.querySelector('#il-leihe').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);
      try{await post('library/loans',{title_id:f.get('title_id'),user_id:f.get('user_id')});}catch(err){fehler(err);}};
    body.querySelector('#il-vor').onclick=async()=>{const f=new FormData(body.querySelector('#il-leihe'));
      try{await post('library/reservations',{title_id:f.get('title_id'),user_id:f.get('user_id')});}catch(err){fehler(err);}};
    body.querySelector('#il-mahn').onclick=async()=>{
      try{const r=await ilApi(`/api/library/reminders?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
        melde(`${r.gemahnt||0} Mahnung(en) erfasst.`);await render();}catch(err){fehler(err);}};
    body.querySelector('#il-frist').onclick=async()=>{
      try{const r=await ilApi(`/api/library/pickup-expiry?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
        melde(`${r.abgelaufen||0} Bereitlegung(en) abgelaufen.`);await render();}catch(err){fehler(err);}};
    body.querySelectorAll('[data-copy]').forEach(b=>b.onclick=async()=>{
      const nr=prompt('Exemplarnummer');if(!nr)return;
      try{await post('library/copies',{title_id:b.dataset.copy,exemplarnummer:nr});}catch(err){fehler(err);}});
    body.querySelectorAll('[data-back]').forEach(b=>b.onclick=async()=>{
      try{await post('library/return',{loan_id:b.dataset.back});}catch(err){fehler(err);}});
    body.querySelectorAll('[data-ext]').forEach(b=>b.onclick=async()=>{
      try{await post('library/extend',{loan_id:b.dataset.ext});}catch(err){fehler(err);}});
    body.querySelectorAll('[data-lost]').forEach(b=>b.onclick=async()=>{
      const grund=prompt('Was ist passiert?');if(!grund)return;
      try{await post('library/loss',{loan_id:b.dataset.lost,grund});}catch(err){fehler(err);}});
  }
  await render();
}

(async()=>{
  let me=null;try{me=(await ilApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const verwaltung=me.isPlatformAdmin||roles.some(x=>x.role==='tenant_admin'||x.role==='class_admin');
  if(!verwaltung)return;
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,anker)=>{if(!anker||document.querySelector(`#${id}`))return;
    const b=document.createElement('button');b.id=id;b.type='button';b.className='nav';b.textContent=text;b.onclick=klick;anker.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');if(!seite)return;
    const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
    knopf('il-inv-launch','Inventar & Beschaffung',()=>ilInventar(tenantId).catch(e=>alert(ilText(e.message))),anker);
    knopf('il-bib-launch','Bibliothek',()=>ilBibliothek(tenantId).catch(e=>alert(ilText(e.message))),anker);
    knopf('il-abgang-launch','Rückgaben beim Abgang',()=>ilAbgang(tenantId,new URLSearchParams(location.search).get('course_id')||'').catch(e=>alert(ilText(e.message))),anker);
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

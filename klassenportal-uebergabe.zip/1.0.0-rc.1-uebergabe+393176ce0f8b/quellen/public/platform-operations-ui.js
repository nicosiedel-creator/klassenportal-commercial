// Betreiber-Cockpit: Betriebszustand, Zielwerte und Kosten.
//
// Bis hierher gab es einen Endpunkt /api/health, der "ok" sagte, solange der Worker antwortete.
// Für den Betrieb ohne Entwicklerwissen reicht das nicht: man muss sehen können, WO es klemmt, seit
// wann, und ob die zugesagte Wiederanlaufzeit schon überschritten ist. Und man muss sehen, was der
// Betrieb kostet, bevor die Rechnung kommt.
(()=>{
  if(location.pathname.replace(/\/$/,'')!=='/plattform-admin')return;
  const PO=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  // Die Aufrufoptionen MUESSEN weitergereicht werden: ohne sie ging der Notfallzugriff als GET
  // hinaus, waehrend der Worker POST erwartet - der Knopf konnte nie funktionieren.
  async function api(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
  const text=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
  const AMPEL={ok:'✓',warnung:'!',kritisch:'✕'};
  const BEREICH={datenbank:'Datenbank',speicher:'Objektspeicher',mail:'Mailversand',automatik:'Automatiklauf',gesamt:'Gesamtbetrieb'};
  const euro=c=>`${(Number(c||0)/100).toFixed(2)} €`;

  function modal(){
    const w=document.createElement('div');w.className='modal-back';
    w.innerHTML=`<div class="modal" style="width:min(960px,97vw);max-height:93vh;overflow:auto"><div class="top"><div><h3 style="margin:0">Betrieb & Kosten</h3><div class="muted">Betriebszustand, Zielwerte und Verbrauch – ohne Entwicklerwissen lesbar.</div></div><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div id="po-body">Lädt …</div></div>`;
    document.body.append(w);
    const zu=()=>w.remove();w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
    return w.querySelector('#po-body');
  }

  async function open(){
    const body=modal();
    let g,s,k,ketten;
    try{[g,s,k,ketten]=await Promise.all([api('/api/platform/health'),api('/api/platform/slo'),api('/api/platform/costs').catch(()=>({})),api('/api/platform/audit-chains').catch(()=>({}))]);}
    catch(e){body.innerHTML=`<div class="notice bad">${PO(text(e.message))}</div>`;return;}
    const slos=s.slos||[],alarme=s.alarme||[],dienste=k.dienste||[];
    body.innerHTML=`<h4>Betriebszustand</h4>`
      +`<div class="notice ${g.status==='ok'?'ok':'bad'}"><strong>${PO(AMPEL[g.status]||'')} ${PO(BEREICH.gesamt)}: ${PO(g.status)}</strong> <span class="muted">geprüft ${PO(new Date(g.geprueft_am).toLocaleString('de-DE'))}, ${PO(g.dauer_ms)} ms</span>`
      +(g.aufgezeichnet?'':'<div>Die Messung konnte nicht fortgeschrieben werden – die Datenbank antwortet nicht.</div>')+`</div>`
      +`<div class="table-wrap"><table><thead><tr><th scope="col">Bereich</th><th scope="col">Zustand</th><th scope="col">Dauer</th><th scope="col">Befund</th></tr></thead><tbody>`
      +(g.bereiche||[]).map(b=>`<tr><td>${PO(BEREICH[b.bereich]||b.bereich)}</td><td>${PO(AMPEL[b.status]||'')} ${PO(b.status)}</td><td>${PO(b.dauer_ms)} ms</td><td class="muted">${PO(b.detail||'')}</td></tr>`).join('')
      +`</tbody></table></div>`
      +(alarme.length?`<h4>Offene Alarme</h4>`+alarme.map(a=>`<div class="notice bad"><strong>${PO(BEREICH[a.bereich]||a.bereich)}</strong> seit ${PO(Math.round(a.seit_minuten))} Minuten kritisch`
        +(a.rto_ueberschritten?` — die zugesagte Wiederanlaufzeit von ${PO(a.rto_minuten)} Minuten ist überschritten`:` (Zusage: ${PO(a.rto_minuten)} Minuten)`)
        +(a.detail?`<div class="muted">${PO(a.detail)}</div>`:'')+`</div>`).join(''):'')
      +`<h4>Zielwerte</h4><p class="muted">RTO ist die Zeit bis zum Wiederanlauf, RPO der höchste vertretbare Datenverlust. Beide Zahlen sind Ausgangswerte – <strong>Sie</strong> legen sie fest, und wer sie zusagt, muss die Wiederherstellung geprobt haben.</p>`
      +`<div class="table-wrap"><table><thead><tr><th scope="col">Ziel</th><th scope="col">Soll</th><th scope="col">Ist</th><th scope="col">RTO</th><th scope="col">RPO</th></tr></thead><tbody>`
      +slos.map(x=>`<tr><td>${PO(x.name)}</td><td>${PO(x.ziel_prozent)} %</td><td>${x.erfuellung_prozent===null?'<span class="muted">noch nicht gemessen</span>':`${PO(x.erfuellung_prozent)} %${x.erfuellt?'':' <strong>unter Soll</strong>'}`}</td><td>${PO(x.rto_minuten)} min</td><td>${PO(x.rpo_minuten)} min</td></tr>`).join('')
      +`</tbody></table></div>`
      +`<h4>Verbrauch und Kosten</h4>`
      +(dienste.length?`<div class="table-wrap"><table><thead><tr><th scope="col">Dienst</th><th scope="col">Verbraucht</th><th scope="col">Grenze</th><th scope="col">Stand</th><th scope="col">Prognose Monat</th></tr></thead><tbody>`
        +dienste.map(d=>`<tr><td>${PO(d.dienst)}</td><td>${PO(euro(d.verbraucht_cent))}</td><td>${d.grenze_cent===null||d.grenze_cent===undefined?'<span class="muted">keine</span>':PO(euro(d.grenze_cent))}</td><td>${PO(d.stufe||'ok')}${Number(d.prozent)?` (${PO(Math.round(d.prozent))} %)`:''}</td><td>${d.prognose_cent===null||d.prognose_cent===undefined?'<span class="muted">–</span>':PO(euro(d.prognose_cent))}</td></tr>`).join('')
        +`</tbody></table></div><p class="muted">„Gebremst" heißt: nichtkritische Funktionen dieses Dienstes werden angehalten. Anmeldung, Zeugnisversand und andere als kritisch markierte Funktionen laufen weiter – eine Kostenbremse darf den Betrieb nicht abschalten.</p>`
        :'<p class="muted">Noch kein Verbrauch erfasst. Sobald Mail, Speicher oder KI genutzt werden, steht er hier.</p>')
      +`<h4>Revisionsprotokoll</h4><p class="muted">Jeder protokollierte Vorgang hängt an der Prüfsumme seines Vorgängers. Ändert oder entfernt jemand nachträglich einen Eintrag, passt die Kette nicht mehr – und genau das steht hier. Der tägliche Lauf prüft das Ende jeder bewegten Kette und siegelt sie nur, wenn sie heil ist.</p>`
      +((ketten&&ketten.ketten||[]).length
        ?`<div class="table-wrap"><table><caption>Protokollketten</caption><thead><tr><th scope="col">Kette</th><th scope="col">Einträge</th><th scope="col">Siegel</th><th scope="col">Zuletzt geprüft</th><th scope="col">Ergebnis</th></tr></thead><tbody>`
          +ketten.ketten.map(c=>`<tr><th scope="row">${PO(c.bereich==='plattform'?'Plattform':c.bereich)}</th><td>${PO(c.position)}</td><td>${PO(c.siegel)}${c.letztes_siegel?` <span class="muted">(${PO(String(c.letztes_siegel).slice(0,10))})</span>`:''}</td>`
            +`<td>${c.pruefung?PO(new Date(c.pruefung.geprueft_am).toLocaleString('de-DE')):'<span class="muted">noch nicht geprüft</span>'}</td>`
            +`<td>${c.pruefung?(c.pruefung.gueltig?'unverändert':`<strong>Bruch an Position ${PO(c.pruefung.bruch_position)}</strong>`):'<span class="muted">–</span>'}</td></tr>`).join('')
          +`</tbody></table></div>`
          +(ketten.ketten.filter(c=>c.pruefung&&!c.pruefung.gueltig).map(c=>`<div class="notice bad"><strong>${PO(c.bereich==='plattform'?'Plattform':c.bereich)}:</strong> ${PO(c.pruefung.hinweis||'')}</div>`).join(''))
        :'<p class="muted">Noch keine Kette angelegt. Sie entsteht mit dem ersten protokollierten Vorgang.</p>')
      +`<h4>Notfallzugriff</h4><p class="muted">Der Regelfall ist die Freigabe durch den Träger. Diese Ausnahme ist kurz befristet, nur lesend, wird der Leitung des Mandanten gemeldet und steht dauerhaft im Protokoll – für den Fall, dass ein Träger im Störfall nicht erreichbar ist.</p>`
      +`<form id="po-notfall"><div class="row"><label class="field">Mandantenkennung<input name="tenant_id" required></label>`
      +`<label class="field">Begründung (mindestens 20 Zeichen)<input name="begruendung" required minlength="20"></label></div>`
      +`<div class="toolbar"><button class="btn danger" type="submit">Notfallzugriff nehmen</button></div><p class="error" id="po-notfall-err" role="alert"></p></form>`;
    const formular=body.querySelector('#po-notfall');
    if(formular)formular.onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{const r=await api(`/api/platform/support-access/emergency?tenant_id=${encodeURIComponent(f.get('tenant_id'))}`,{method:'POST',body:JSON.stringify({begruendung:f.get('begruendung')})});
        body.querySelector('#po-notfall-err').textContent=`Notfallzugriff bis ${r.gueltig_bis}. Gemeldet an ${r.gemeldet_an} Person(en) der Leitung.`;}
      catch(e){body.querySelector('#po-notfall-err').textContent=text(e.message);}
    };
  }

  function enhance(){
    const side=document.querySelector('.side');
    if(!side||side.querySelector('#platform-operations-nav'))return;
    const b=document.createElement('button');
    b.id='platform-operations-nav';b.className='nav';b.type='button';
    b.dataset.platformI18nKey='operations_costs';
    b.textContent=window.KP_PLATFORM_I18N?.t?.('operations_costs')||'Betrieb & Kosten';
    const spacer=side.querySelector('.spacer');
    side.insertBefore(b,spacer||null);
    b.onclick=()=>open().catch(e=>alert(text(e.message)));
    window.KP_PLATFORM_I18N?.apply?.();
  }
  window.addEventListener('kp:app-rendered',enhance);
  window.addEventListener('kp:platform-ui-applied',enhance);
  enhance();
})();

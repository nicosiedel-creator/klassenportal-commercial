const ADV_ROOT=document.querySelector('#class-portal');
if(ADV_ROOT){
  const parts=location.pathname.split('/').filter(Boolean),tenantSlug=decodeURIComponent(parts[1]||''),courseCode=decodeURIComponent(parts[2]||''),codeKey=`kp_access_${tenantSlug}_${courseCode}`;
  const E=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot',"'":'&#39;'}[c]));
  let busy=false,lastSignature='',currentData=null;
  async function api(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
  function date(v){const d=new Date(String(v||''));return Number.isNaN(d.getTime())?'—':new Intl.DateTimeFormat('de-DE',{weekday:'short',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}).format(d);}
  function item(title,meta='',body=''){return `<div class="portal-item"><div class="portal-item-top"><strong>${E(title)}</strong></div>${meta?`<div class="meta">${E(meta)}</div>`:''}${body?`<div class="body">${E(body)}</div>`:''}</div>`;}
  function section(id,title,content,count,wide=false){return `<section class="portal-section${wide?' wide':''}" id="${id}"><div class="portal-section-head"><h2>${E(title)}</h2><span>${E(count)}</span></div>${content}</section>`;}
  function addNav(id,label){const nav=ADV_ROOT.querySelector('.portal-nav');if(!nav||nav.querySelector(`a[href="#${CSS.escape(id)}"]`))return;const a=document.createElement('a');a.href=`#${id}`;a.textContent=label;nav.append(a);}
  async function freshOverview(){const code=sessionStorage.getItem(codeKey)||'';return api(`/public/${encodeURIComponent(tenantSlug)}/${encodeURIComponent(courseCode)}/overview`,{headers:code?{'X-Klassenportal-Access-Code':code}:{}});}
  async function apply(d,force=false){
    const grid=ADV_ROOT.querySelector('.portal-grid');if(!grid||busy||!d?.course)return;busy=true;
    try{
      currentData=d;const m=d.modules||{},surveys=d.surveys||[],subs=d.substitutions||[],feed=d.microsoft365FeedUrl||null,viewer=d.viewer||{},course=d.course||{},signature=JSON.stringify([surveys.map(x=>[x.id,(x.options||[]).map(o=>[o.id,o.votes,o.selected])]),subs.map(x=>x.id),feed,m.surveys,m.substitution_updates,m.microsoft_365]);
      if(!force&&signature===lastSignature&&grid.querySelector('[data-advanced-portal]'))return;lastSignature=signature;grid.querySelectorAll('[data-advanced-portal]').forEach(x=>x.remove());
      if(m.substitution_updates!==false&&subs.length){addNav('vertretungen','Vertretungsänderungen');const rows=subs.map(x=>item(x.replacement_text,date(x.starts_at),[x.original_text?`Bisher: ${x.original_text}`:'',x.room?`Raum: ${x.room}`:'',x.note||''].filter(Boolean).join('\n'))).join('');grid.insertAdjacentHTML('beforeend',section('vertretungen','Vertretungsänderungen',`<div class="portal-list">${rows}</div>`,`${subs.length}`,true).replace('<section ','<section data-advanced-portal '));}
      if(m.surveys!==false&&['participant','guest'].includes(String(viewer.role||''))){addNav('umfragen','Umfragen');const content=surveys.length?surveys.map(s=>{const selected=(s.options||[]).find(o=>o.selected),total=(s.options||[]).reduce((n,o)=>n+Number(o.votes||0),0);return `<div class="portal-item" data-survey="${E(s.id)}"><div class="portal-item-top"><strong>${E(s.title)}</strong>${selected?'<span class="portal-pill">Abgestimmt</span>':''}</div><div class="body">${E(s.question)}</div><div style="display:grid;gap:7px;margin-top:10px">${(s.options||[]).map(o=>{const pct=total?Math.round(Number(o.votes||0)*100/total):0;return selected?`<div class="portal-item" style="padding:8px"><strong>${E(o.label)}</strong><div class="meta">${E(o.votes||0)} Stimme(n) · ${pct}%${o.selected?' · Deine Wahl':''}</div></div>`:`<button type="button" class="portal-btn secondary portal-survey-vote" data-survey="${E(s.id)}" data-option="${E(o.id)}">${E(o.label)}</button>`;}).join('')}</div>${s.closes_at?`<div class="meta" style="margin-top:8px">Offen bis ${E(date(s.closes_at))}</div>`:''}</div>`;}).join(''):'<div class="portal-empty">Aktuell gibt es keine offenen Umfragen.</div>';grid.insertAdjacentHTML('beforeend',section('umfragen','Umfragen',`<div class="portal-list">${content}</div>`,`${surveys.length} offen`).replace('<section ','<section data-advanced-portal '));}
      if(m.microsoft_365!==false&&feed){addNav('microsoft365','Outlook-Kalender');const html=`<div class="portal-item"><strong>Klassenkalender abonnieren</strong><div class="body">Unterricht, Termine, Prüfungen und Vertretungsänderungen können als automatisch aktualisierbarer Internetkalender in Outlook / Microsoft 365 abonniert werden.</div><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px"><button type="button" class="portal-btn secondary" id="portal-copy-m365" data-url="${E(feed)}">Kalenderadresse kopieren</button><a class="portal-btn secondary" href="${E(feed)}">ICS öffnen</a></div></div>`;grid.insertAdjacentHTML('beforeend',section('microsoft365','Microsoft 365 / Outlook',html,'Kalender',true).replace('<section ','<section data-advanced-portal '));}
      ADV_ROOT.querySelectorAll('.portal-survey-vote').forEach(b=>b.addEventListener('click',async()=>{if(!viewer.tenantId||!course.id)return;if(!confirm('Diese Antwort verbindlich abgeben? Die Stimme kann danach nicht geändert werden.'))return;b.disabled=true;try{await api(`/api/surveys/${encodeURIComponent(b.dataset.survey)}/vote?tenant_id=${encodeURIComponent(viewer.tenantId)}&course_id=${encodeURIComponent(course.id)}`,{method:'POST',body:JSON.stringify({option_id:b.dataset.option})});lastSignature='';await apply(await freshOverview(),true);}catch(e){b.textContent=(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(e):e.message)==='SURVEY_ALREADY_VOTED'?'Bereits abgestimmt':'Abstimmung nicht möglich';b.disabled=false;}}));
      // Die eigenen Noten. Der Endpunkt gab es seit langem, im Portal war er nirgends zu sehen -
      // die teilnehmende Person konnte ihre Bewertungen also nur erfahren, wenn jemand sie ihr
      // sagte. Bewusst nur lesend und nur die eigenen.
      if(viewer.tenantId&&course.id&&['participant','guest'].includes(String(viewer.role||''))){
        try{
          const g=await api(`/api/personal/grades?tenant_id=${encodeURIComponent(viewer.tenantId)}&course_id=${encodeURIComponent(course.id)}`);
          const noten=g.grades||[];
          addNav('meine-noten','Meine Noten');
          const inhalt=noten.length
            ? noten.map(x=>item(x.title||'Bewertung',[x.grade_value,x.points_value!==null&&x.points_value!==undefined?`${x.points_value} Punkte`:'',date(x.recorded_at)].filter(Boolean).join(' · '),x.note||'')).join('')
            : '<p class="muted">Für dich ist noch keine Note eingetragen.</p>';
          grid.insertAdjacentHTML('beforeend',section('meine-noten','Meine Noten',inhalt,noten.length));
        }catch{/* keine Noten sichtbar: dann bleibt der Abschnitt weg, statt einen Fehler zu zeigen */}
      }
      ADV_ROOT.querySelector('#portal-copy-m365')?.addEventListener('click',async e=>{const button=e.currentTarget,url=button.dataset.url;try{await navigator.clipboard.writeText(url);button.textContent='Kalenderadresse kopiert';setTimeout(()=>button.textContent='Kalenderadresse kopieren',1400);}catch{prompt('Kalenderadresse:',url);}});
    }finally{busy=false;}
  }
  window.addEventListener('kp:portal-data',event=>void apply(event.detail?.data));
  window.addEventListener('kp:advanced-refresh',()=>{if(currentData){lastSignature='';void apply(currentData,true);}});
  if(window.__KP_PORTAL_DATA)void apply(window.__KP_PORTAL_DATA);
}

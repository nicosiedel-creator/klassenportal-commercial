// Betreiber-Cockpit: Aktualisierung, Störungen und Ausfallprüfung.
//
// Die unbequemste Zahl steht unten: woran hängt der Betrieb an einer einzigen Person.
const OC=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const OC_SCHWERE=[['kritisch','Kritisch'],['hoch','Hoch'],['mittel','Mittel'],['niedrig','Niedrig']];
async function ocApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const ocText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
const ocZeit=v=>{const d=new Date(String(v));return Number.isNaN(d.getTime())?String(v??''):d.toLocaleString('de-DE',{dateStyle:'short',timeStyle:'short'});};
function ocModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="oc-titel" style="width:min(1000px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="oc-titel" style="margin:0">${OC(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="oc-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#oc-body'),zu};
}

async function ocReleases(){
  const {body}=ocModal('Aktualisierungen');
  async function render(){
    let d;try{d=await ocApi('/api/operations/releases');}
    catch(e){body.innerHTML=`<div class="notice bad">${OC(ocText(e.message))}</div>`;return;}
    const offen=(d.offen||[]).map(r=>`<tr><th scope="row">${OC(r.fassung)}</th><td>${OC(r.bezeichnung)}</td><td>${OC(r.status)}</td><td>${OC(r.probelauf_ergebnis||'—')}</td>`
      +`<td><button class="btn secondary oc-probe" type="button" data-id="${OC(r.id)}">Probelauf</button> <button class="btn oc-aus" type="button" data-id="${OC(r.id)}">Ausrollen</button></td></tr>`).join('')
      ||'<tr><td colspan="5">Nichts in Planung.</td></tr>';
    body.innerHTML=(d.laufend
        ? `<div class="notice${d.schema_passt?' good':' bad'}">Im Betrieb: <strong>${OC(d.laufend.fassung)}</strong> (${OC(d.laufend.bezeichnung)}), ausgerollt ${OC(ocZeit(d.laufend.ausgerollt_am))}.`
          +`<br>Schemastand: ${OC(d.ist_migration||'unbekannt')} — ${d.schema_passt?'passt zur laufenden Fassung.':'<strong>passt NICHT zur laufenden Fassung.</strong>'}`
          +`${d.laufend.build_ref?`<br>Stand: ${OC(d.laufend.build_ref)}`:''}</div>`
        : '<div class="notice">Es ist keine Fassung als ausgerollt vermerkt.</div>')
      +`<div style="overflow-x:auto"><table class="table"><caption>Geplante Aktualisierungen</caption><thead><tr><th scope="col">Fassung</th><th scope="col">Bezeichnung</th><th scope="col">Stand</th><th scope="col">Probelauf</th><th scope="col">Aktion</th></tr></thead><tbody>${offen}</tbody></table></div>`
      +(d.laufend?`<div class="toolbar"><button class="btn secondary" type="button" id="oc-zurueck">Laufende Fassung zurückrollen</button></div>`:'')
      +`<form id="oc-neu"><h4>Aktualisierung anmelden</h4><label class="field">Fassung<input name="fassung" required></label>`
      +`<label class="field">Bezeichnung<input name="bezeichnung" required></label><label class="field">Stand (Commit/Paket)<input name="build_ref"></label>`
      +`<label class="field">Erwartete Migration<input name="erwartete_migration" placeholder="0161_..."></label>`
      +`<label class="field">Was ändert sich<textarea name="aenderungen" rows="3" required></textarea></label>`
      +`<label class="field">Rückweg<textarea name="rueckweg" rows="3" required placeholder="Wie wird zurückgerollt? Ein Rollback, der erst im Ernstfall erdacht wird, ist keiner."></textarea></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Anmelden</button></div></form><p class="error" id="oc-err" role="alert"></p><p id="oc-info" class="muted" role="status"></p>`;
    const fehler=e=>{body.querySelector('#oc-err').textContent=ocText(e.message);};
    body.querySelector('#oc-neu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target),daten={};
      for(const [k,v] of f.entries())if(String(v).trim())daten[k]=String(v).trim();
      try{await ocApi('/api/operations/releases',{method:'POST',body:JSON.stringify(daten)});await render();}
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.oc-probe').forEach(b=>b.onclick=async()=>{
      try{const r=await ocApi(`/api/operations/releases/${encodeURIComponent(b.dataset.id)}/dry-run`,{method:'POST',body:'{}'});
        body.querySelector('#oc-info').textContent=r.bestanden?'Probelauf bestanden.':`Befunde: ${r.befunde.join('; ')}`;await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.oc-aus').forEach(b=>b.onclick=async()=>{
      try{await ocApi(`/api/operations/releases/${encodeURIComponent(b.dataset.id)}/rollout`,{method:'POST',body:'{}'});await render();}
      catch(e){fehler(e);}
    });
    const zurueck=body.querySelector('#oc-zurueck');
    if(zurueck)zurueck.onclick=async()=>{
      const grund=prompt('Warum wird zurückgerollt?');if(!grund)return;
      try{await ocApi(`/api/operations/releases/${encodeURIComponent(d.laufend.id)}/rollback`,{method:'POST',body:JSON.stringify({grund})});await render();}
      catch(e){fehler(e);}
    };
  }
  await render();
}

async function ocStoerungen(tenantId){
  const {body}=ocModal('Störungen');
  async function render(){
    let d;try{d=await ocApi('/api/operations/incidents');}
    catch(e){body.innerHTML=`<div class="notice bad">${OC(ocText(e.message))}</div>`;return;}
    const zeilen=(d.offen||[]).map(v=>`<tr><th scope="row">${OC(v.titel)}</th><td>${OC(v.schwere)}</td><td>${OC(ocZeit(v.entdeckt_am))}</td><td>${OC(v.auswirkung)}</td>`
      +`<td><button class="btn secondary oc-upd" type="button" data-id="${OC(v.id)}">Meldung</button> <button class="btn oc-beh" type="button" data-id="${OC(v.id)}">Behoben</button></td></tr>`).join('')
      ||'<tr><td colspan="5">Keine offene Störung.</td></tr>';
    const nach=(d.nachbetrachtung_offen||[]).map(v=>`<li>${OC(v.titel)} (${OC(v.schwere)}, behoben ${OC(ocZeit(v.behoben_am))}) <button class="btn secondary oc-nach" type="button" data-id="${OC(v.id)}">Nachbetrachtung</button></li>`).join('');
    body.innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Offene Störungen</caption><thead><tr><th scope="col">Titel</th><th scope="col">Schwere</th><th scope="col">Seit</th><th scope="col">Auswirkung</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +(nach?`<div class="notice bad"><strong>Nachbetrachtung offen</strong> — behoben ist nicht abgeschlossen.<ul>${nach}</ul></div>`:'<div class="notice good">Keine Nachbetrachtung offen.</div>')
      +`<form id="oc-sneu"><h4>Störung melden</h4><label class="field">Titel<input name="titel" required></label>`
      +`<label class="field">Schwere<select name="schwere">${OC_SCHWERE.map(([k,t])=>`<option value="${OC(k)}"${k==='mittel'?' selected':''}>${OC(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Was merken die Anwender?<textarea name="auswirkung" rows="3" required></textarea></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Melden</button></div></form><p class="error" id="oc-serr" role="alert"></p>`;
    const fehler=e=>{body.querySelector('#oc-serr').textContent=ocText(e.message);};
    body.querySelector('#oc-sneu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await ocApi('/api/operations/incidents',{method:'POST',body:JSON.stringify({
        titel:String(f.get('titel')),schwere:String(f.get('schwere')),auswirkung:String(f.get('auswirkung'))})});await render();}
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.oc-upd').forEach(b=>b.onclick=async()=>{
      const text=prompt('Meldung an die Anwender:');if(!text)return;
      try{await ocApi(`/api/operations/incidents/${encodeURIComponent(b.dataset.id)}/update`,{method:'POST',body:JSON.stringify({text})});await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.oc-beh').forEach(b=>b.onclick=async()=>{
      const ursache=prompt('Was war die Ursache?');if(!ursache)return;
      try{await ocApi(`/api/operations/incidents/${encodeURIComponent(b.dataset.id)}/resolve`,{method:'POST',body:JSON.stringify({ursache})});await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.oc-nach').forEach(b=>b.onclick=async()=>{
      const text=prompt('Nachbetrachtung: was ist passiert, warum, und was ändert sich daraufhin?');if(!text)return;
      try{await ocApi(`/api/operations/incidents/${encodeURIComponent(b.dataset.id)}/postmortem`,{method:'POST',body:JSON.stringify({nachbetrachtung:text})});await render();}
      catch(e){fehler(e);}
    });
  }
  await render();
}

async function ocAusfall(tenantId){
  const {body}=ocModal('Ausfallprüfung: hängt der Betrieb an einer Person?');
  async function render(){
    let d;try{d=await ocApi(`/api/operations/duties?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${OC(ocText(e.message))}</div>`;return;}
    const zeilen=(d.aufgaben||[]).map(a=>`<tr><th scope="row">${OC(a.bezeichnung)}</th><td>${OC(String(a.besetzt))} / ${OC(String(a.mindestbesetzung))}</td><td>${OC(String(a.geuebt))}</td>`
      +`<td>${(a.personen||[]).map(p=>`${OC(p.name)} (${OC(p.rolle)}${p.zuletzt_geuebt_am?`, geübt ${OC(p.zuletzt_geuebt_am)}`:', nie geübt'})`).join('<br>')||'—'}</td>`
      +`<td>${a.erfuellt?'ja':'<strong>nein</strong>'}</td>`
      +`<td><button class="btn secondary oc-bes" type="button" data-k="${OC(a.schluessel)}">Besetzen</button> <button class="btn secondary oc-ueb" type="button" data-k="${OC(a.schluessel)}">Übung vermerken</button> <button class="btn secondary oc-ent" type="button" data-k="${OC(a.schluessel)}">Entbinden</button></td></tr>`).join('')
      ||'<tr><td colspan="6">Noch keine Betriebsaufgabe festgelegt.</td></tr>';
    body.innerHTML=(d.hinweis==='AUFGABEN_NICHT_FESTGELEGT'
        ? '<div class="notice bad">Es ist keine kritische Betriebsaufgabe festgelegt. Wer nichts festgelegt hat, ist nicht abgesichert — er weiß es nur nicht.</div>'
        : d.erfuellt
          ? '<div class="notice good">Jede kritische Aufgabe ist doppelt besetzt und geübt.</div>'
          : `<div class="notice bad"><strong>Der Betrieb hängt an einzelnen Personen.</strong>`
            +`${(d.unbesetzt||[]).length?`<br>Unbesetzt: ${OC(d.unbesetzt.join(', '))}`:''}`
            +`${(d.einzelpersonen||[]).length?`<br>Nur eine Person: ${OC(d.einzelpersonen.join(', '))}`:''}`
            +`${(d.ungeuebt||[]).length?`<br>Besetzt, aber nicht geübt: ${OC(d.ungeuebt.join(', '))}`:''}</div>`)
      +`<div style="overflow-x:auto"><table class="table"><caption>Kritische Betriebsaufgaben</caption><thead><tr><th scope="col">Aufgabe</th><th scope="col">Besetzt</th><th scope="col">Davon geübt</th><th scope="col">Personen</th><th scope="col">Erfüllt</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<form id="oc-aneu"><h4>Betriebsaufgabe festlegen</h4><label class="field">Kennung<input name="schluessel" required placeholder="notfallzugriff"></label>`
      +`<label class="field">Bezeichnung<input name="bezeichnung" required></label>`
      +`<label class="field">Mindestbesetzung<input name="mindestbesetzung" type="number" min="1" max="10" value="2"></label>`
      +`<label class="field">Beschreibung<textarea name="beschreibung" rows="2"></textarea></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Festlegen</button></div></form><p class="error" id="oc-aerr" role="alert"></p>`;
    const fehler=e=>{body.querySelector('#oc-aerr').textContent=ocText(e.message);};
    body.querySelector('#oc-aneu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await ocApi(`/api/operations/duties?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        schluessel:String(f.get('schluessel')),bezeichnung:String(f.get('bezeichnung')),
        mindestbesetzung:Number(f.get('mindestbesetzung')||2),beschreibung:String(f.get('beschreibung')||'')})});await render();}
      catch(e){fehler(e);}
    };
    const mitPerson=async(pfad,k,extra={})=>{
      const person=prompt('Kennung der Person:');if(!person)return;
      try{await ocApi(`/api/operations/duties/${pfad}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
        body:JSON.stringify({schluessel:k,user_id:person,...extra})});await render();}
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.oc-bes').forEach(b=>b.onclick=()=>mitPerson('assign',b.dataset.k,{rolle:confirm('Als Vertretung? Abbrechen = als Träger.')?'vertretung':'traeger'}));
    body.querySelectorAll('.oc-ueb').forEach(b=>b.onclick=()=>mitPerson('drill',b.dataset.k));
    body.querySelectorAll('.oc-ent').forEach(b=>b.onclick=()=>mitPerson('release',b.dataset.k));
  }
  await render();
}

// Der Ereignisbus: was ist auf ein Ereignis hin geschehen, und was liegt im Totfach?
async function ocBus(tenantId){
  const {body}=ocModal('Ereignisbus');
  async function render(){
    let d,t;
    try{d=await ocApi(`/api/events/bus?tenant_id=${encodeURIComponent(tenantId)}`);
      t=await ocApi(`/api/events/dead-letter?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${OC(ocText(e.message))}</div>`;return;}
    const abos=(d.abonnements||[]).map(x=>`<tr><th scope="row">${OC(x.art)}</th><td>${OC(x.verarbeiter)}</td><td>${Number(x.aktiv)?'aktiv':'aus'}</td><td>${OC(x.beschreibung||'')}</td></tr>`).join('')
      ||'<tr><td colspan="4">Kein Abonnement.</td></tr>';
    const tot=(t.zustellungen||[]).map(z=>`<tr><th scope="row">${OC(z.art)}</th><td>${OC(z.objekt_typ)}/${OC(z.objekt_id)}</td><td>${OC(z.verarbeiter)}</td><td>${OC(String(z.versuche))}</td><td>${OC(z.letzter_fehler||'')}</td>`
      +`<td><button class="btn secondary oc-retry" type="button" data-id="${OC(z.id)}">Erneut zustellen</button></td></tr>`).join('')
      ||'<tr><td colspan="6">Das Totfach ist leer.</td></tr>';
    body.innerHTML=`<div class="notice${Number(d.totfach)||Number(d.uebersprungen)?' bad':' good'}">`
        +`${OC(String(d.erfolg||0))} zugestellt, ${OC(String(d.offen||0))} offen, ${OC(String(d.totfach||0))} im Totfach, ${OC(String(d.uebersprungen||0))} übersprungen.</div>`
      +`<div class="toolbar"><button class="btn" type="button" id="oc-lauf">Zustellung anstoßen</button></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Abonnements</caption><thead><tr><th scope="col">Ereignisart</th><th scope="col">Verarbeiter</th><th scope="col">Stand</th><th scope="col">Zweck</th></tr></thead><tbody>${abos}</tbody></table></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Totfach — was nicht durchkam</caption><thead><tr><th scope="col">Ereignis</th><th scope="col">Objekt</th><th scope="col">Verarbeiter</th><th scope="col">Versuche</th><th scope="col">Fehler</th><th scope="col">Aktion</th></tr></thead><tbody>${tot}</tbody></table></div>`
      +`<form id="oc-abo"><h4>Abonnieren</h4><label class="field">Ereignisart<input name="art" required placeholder="note.eingetragen"></label>`
      +`<label class="field">Verarbeiter<select name="verarbeiter">${(d.verarbeiter||[]).map(v=>`<option value="${OC(v)}">${OC(v)}</option>`).join('')||'<option value="">— keiner eingebaut —</option>'}</select></label>`
      +`<label class="field">Zweck<input name="beschreibung"></label><div class="toolbar"><button class="btn" type="submit">Abonnieren</button></div></form>`
      +`<form id="oc-spur"><h4>Spur zu einem Objekt</h4><label class="field">Objektart<input name="objekt_typ" required></label><label class="field">Objektkennung<input name="objekt_id" required></label>`
      +`<div class="toolbar"><button class="btn secondary" type="submit">Spur anzeigen</button></div></form>`
      +`<p class="error" id="oc-berr" role="alert"></p><div id="oc-bout"></div>`;
    const fehler=e=>{body.querySelector('#oc-berr').textContent=ocText(e.message);};
    body.querySelector('#oc-lauf').onclick=async()=>{
      try{const r=await ocApi('/api/events/deliver',{method:'POST',body:'{}'});
        body.querySelector('#oc-bout').textContent=`${r.geprueft} geprüft, ${r.erfolg} zugestellt, ${r.fehler} fehlgeschlagen, ${r.totfach} ins Totfach.`;await render();}
      catch(e){fehler(e);}
    };
    body.querySelector('#oc-abo').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await ocApi(`/api/events/subscriptions?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        art:String(f.get('art')),verarbeiter:String(f.get('verarbeiter')),beschreibung:String(f.get('beschreibung')||'')})});await render();}
      catch(e){fehler(e);}
    };
    body.querySelector('#oc-spur').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{const r=await ocApi(`/api/events/trace?tenant_id=${encodeURIComponent(tenantId)}&objekt_typ=${encodeURIComponent(String(f.get('objekt_typ')))}&objekt_id=${encodeURIComponent(String(f.get('objekt_id')))}`);
        body.querySelector('#oc-bout').innerHTML=`<ul>`+((r.ereignisse||[]).map(e=>`<li>${OC(String(e.folge))}. ${OC(e.art)} (${OC(ocZeit(e.created_at))}, ${OC(e.quelle)})`
          +`<ul>${(e.zustellungen||[]).map(z=>`<li>${OC(z.verarbeiter)}: ${OC(z.status)}${z.letzter_fehler?` — ${OC(z.letzter_fehler)}`:''}</li>`).join('')||'<li>kein Abonnent</li>'}</ul></li>`).join('')||'<li>Zu diesem Objekt ist kein Ereignis vermerkt.</li>')+`</ul>`;}
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.oc-retry').forEach(b=>b.onclick=async()=>{
      try{await ocApi(`/api/events/deliveries/${encodeURIComponent(b.dataset.id)}/retry?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await render();}
      catch(e){fehler(e);}
    });
  }
  await render();
}

(async()=>{
  let me=null;try{me=(await ocApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const traegerleitung=me.isPlatformAdmin||roles.some(x=>x.role==='tenant_admin');
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!traegerleitung)return;
    const seite=document.querySelector('.side');
    if(!seite)return;
    const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
    if(me.isPlatformAdmin){
      knopf('oc-releases-launch','Aktualisierungen',()=>ocReleases(),anker,'nav');
      knopf('oc-stoerungen-launch','Störungen',()=>ocStoerungen(tenantId),anker,'nav');
    }
    if(tenantId)knopf('oc-ausfall-launch','Ausfallprüfung',()=>ocAusfall(tenantId),anker,'nav');
    if(tenantId)knopf('oc-bus-launch','Ereignisbus',()=>ocBus(tenantId),anker,'nav');
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

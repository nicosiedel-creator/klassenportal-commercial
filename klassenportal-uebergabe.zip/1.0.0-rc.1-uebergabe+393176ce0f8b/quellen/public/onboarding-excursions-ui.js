// Geführte Einrichtung und Veranstaltungen als Vorgang.
//
// Die Einrichtung zeigt die Reihenfolge: ein Schritt, dessen Voraussetzung fehlt, ist gesperrt
// statt anklickbar-und-dann-kaputt. Und sie sagt, ob produktiv gearbeitet werden darf.
const OE=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function oeApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const oeText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
const oeZeit=v=>{const d=new Date(String(v));return Number.isNaN(d.getTime())?String(v??''):d.toLocaleString('de-DE',{dateStyle:'short',timeStyle:'short'});};
const oeEuro=c=>(Number(c||0)/100).toLocaleString('de-DE',{style:'currency',currency:'EUR'});
function oeModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="oe-titel" style="width:min(980px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="oe-titel" style="margin:0">${OE(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="oe-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#oe-body'),zu};
}

async function oeWizard(tenantId){
  const {body}=oeModal('Einrichtung');
  async function render(){
    let d;try{d=await oeApi(`/api/onboarding/wizard?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${OE(oeText(e.message))}</div>`;return;}
    const zeilen=(d.schritte||[]).map(s=>`<tr><th scope="row">${OE(s.titel)}${s.pflicht?' <span class="muted">(Pflicht)</span>':''}</th>`
      +`<td>${s.erledigt?'erledigt':s.uebersprungen?'übergangen':s.gesperrt?'gesperrt':'offen'}</td>`
      +`<td>${OE(s.hinweis)}${s.gesperrt?`<br><strong>Zuerst nötig: ${OE(s.fehlt.join(', '))}</strong>`:''}${s.uebersprungen?`<br><em>${OE(s.uebersprungen)}</em>`:''}</td>`
      +`<td>${!s.erledigt&&!s.gesperrt&&!s.uebersprungen?`<button class="btn secondary oe-hier" type="button" data-k="${OE(s.schluessel)}">Hier weiter</button>`:''}`
      +`${!s.erledigt&&!s.pflicht&&!s.uebersprungen?` <button class="btn secondary oe-skip" type="button" data-k="${OE(s.schluessel)}">Übergehen</button>`:''}</td></tr>`).join('');
    body.innerHTML=(d.betriebsbereit
        ?`<div class="notice good">Alle Pflichtschritte stehen — Sie können produktiv arbeiten.</div>`
        :`<div class="notice bad"><strong>Noch nicht betriebsbereit.</strong> Es fehlt: ${OE((d.fehlt_fuer_betrieb||[]).join(', '))}</div>`)
      +(d.zuletzt?`<p class="muted">Zuletzt waren Sie bei: <strong>${OE(d.zuletzt)}</strong>.</p>`:'')
      +`<div style="overflow-x:auto"><table class="table"><caption>Einrichtungsschritte (${OE(String(d.erledigt))} von ${OE(String(d.gesamt))})</caption><thead><tr><th scope="col">Schritt</th><th scope="col">Stand</th><th scope="col">Warum</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<div class="toolbar"><button class="btn" type="button" id="oe-fertig"${d.betriebsbereit?'':' disabled'}>Einrichtung abschließen</button></div>`
      +`<p class="error" id="oe-err" role="alert"></p><p id="oe-info" class="muted" role="status">${d.abgeschlossen_am?`Abgeschlossen am ${OE(oeZeit(d.abgeschlossen_am))}.`:''}</p>`;
    const fehler=e=>{body.querySelector('#oe-err').textContent=oeText(e.message);};
    body.querySelectorAll('.oe-hier').forEach(b=>b.onclick=async()=>{
      try{await oeApi(`/api/onboarding/wizard/position?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({schritt:b.dataset.k})});await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.oe-skip').forEach(b=>b.onclick=async()=>{
      const grund=prompt('Warum wird dieser Schritt übergangen?');if(!grund)return;
      try{await oeApi(`/api/onboarding/wizard/skip?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({schritt:b.dataset.k,grund})});await render();}
      catch(e){fehler(e);}
    });
    body.querySelector('#oe-fertig').onclick=async()=>{
      try{await oeApi(`/api/onboarding/wizard/finish?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await render();}
      catch(e){fehler(e);}
    };
  }
  await render();
}

async function oeFahrten(tenantId){
  const {body}=oeModal('Veranstaltungen und Exkursionen');
  async function render(){
    let d;try{d=await oeApi(`/api/excursions?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${OE(oeText(e.message))}</div>`;return;}
    const zeilen=(d.fahrten||[]).map(f=>`<tr><th scope="row">${OE(f.titel)}</th><td>${OE(f.kurs)}</td><td>${OE(oeZeit(f.beginnt_am))}</td>`
      +`<td>${OE(String(f.stand.zugesagt))}/${OE(String(f.stand.eingeladen))} zugesagt, ${OE(String(f.stand.einverstanden))} mit Einverständnis, ${OE(String(f.stand.begleitung))} Begleitung</td>`
      +`<td>${OE(f.status)}</td><td>${OE(oeEuro(f.kosten_cent))}</td>`
      +`<td><button class="btn secondary oe-pers" type="button" data-id="${OE(f.id)}">Personen</button>`
      +`${['entwurf','beantragt'].includes(f.status)?` <button class="btn oe-gen" type="button" data-id="${OE(f.id)}">Entscheiden</button>`:''}`
      +`${f.status==='genehmigt'?` <button class="btn secondary oe-not" type="button" data-id="${OE(f.id)}">Notfallliste</button> <button class="btn secondary oe-nach" type="button" data-id="${OE(f.id)}">Nachweis</button>`:''}</td></tr>`).join('')
      ||'<tr><td colspan="7">Noch keine Veranstaltung geplant.</td></tr>';
    body.innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Veranstaltungen</caption><thead><tr><th scope="col">Titel</th><th scope="col">Kurs</th><th scope="col">Beginn</th><th scope="col">Rückmeldungen</th><th scope="col">Stand</th><th scope="col">Kosten</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<form id="oe-neu"><h4>Veranstaltung planen</h4><label class="field">Kurs (Kennung)<input name="course_id" required></label>`
      +`<label class="field">Titel<input name="titel" required></label><label class="field">Ziel<input name="ziel" required></label>`
      +`<label class="field">Beginn<input name="beginnt_am" type="datetime-local" required></label><label class="field">Ende<input name="endet_am" type="datetime-local" required></label>`
      +`<label class="field">Rückmeldung bis<input name="rueckmeldung_bis" type="date" required></label>`
      +`<label class="field">Kosten in Cent<input name="kosten_cent" type="number" min="0" value="0"></label>`
      +`<label class="field">Teilnehmende je Begleitperson<input name="begleitung_je_teilnehmer" type="number" min="1" max="100" value="15"></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Planen</button></div></form><p class="error" id="oe-ferr" role="alert"></p><div id="oe-fout"></div>`;
    const fehler=e=>{body.querySelector('#oe-ferr').textContent=oeText(e.message);};
    body.querySelector('#oe-neu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await oeApi(`/api/excursions?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        course_id:String(f.get('course_id')),titel:String(f.get('titel')),ziel:String(f.get('ziel')),
        beginnt_am:new Date(String(f.get('beginnt_am'))).toISOString(),endet_am:new Date(String(f.get('endet_am'))).toISOString(),
        rueckmeldung_bis:String(f.get('rueckmeldung_bis')),kosten_cent:Number(f.get('kosten_cent')||0),
        begleitung_je_teilnehmer:Number(f.get('begleitung_je_teilnehmer')||15)})});await render();}
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.oe-pers').forEach(b=>b.onclick=async()=>{
      const roh=prompt('Kennungen der Teilnehmenden, durch Komma getrennt:');if(!roh)return;
      const begl=prompt('Kennungen der Begleitpersonen, durch Komma getrennt (leer lassen, wenn keine):')||'';
      const personen=[...roh.split(',').map(s=>({user_id:s.trim(),rolle:'teilnehmer'})),
        ...begl.split(',').map(s=>({user_id:s.trim(),rolle:'begleitung'}))].filter(p=>p.user_id);
      try{await oeApi(`/api/excursions/${encodeURIComponent(b.dataset.id)}/participants?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({personen})});await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.oe-gen').forEach(b=>b.onclick=async()=>{
      const grund=prompt('Begründung der Entscheidung:');if(!grund)return;
      const ja=confirm('Genehmigen? Abbrechen bedeutet ablehnen.');
      try{await oeApi(`/api/excursions/${encodeURIComponent(b.dataset.id)}/decision?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({genehmigt:ja,begruendung:grund})});await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.oe-not').forEach(b=>b.onclick=async()=>{
      try{const r=await oeApi(`/api/excursions/${encodeURIComponent(b.dataset.id)}/emergency-list?tenant_id=${encodeURIComponent(tenantId)}`);
        body.querySelector('#oe-fout').innerHTML=`<h4>Notfallliste — ${OE(r.fahrt.titel)}</h4>`
          +`<p class="muted">${OE(String(r.anzahl))} Teilnehmende, ${OE(String(r.begleitung))} Begleitpersonen.</p>`
          +`<div style="overflow-x:auto"><table class="table"><caption>Wer fährt mit</caption><thead><tr><th scope="col">Person</th><th scope="col">Rolle</th><th scope="col">Erreichbar</th><th scope="col">Zu beachten</th></tr></thead><tbody>`
          +(r.faehrt_mit||[]).map(z=>`<tr><th scope="row">${OE(z.display_name)}</th><td>${OE(z.rolle)}</td><td>${OE(z.notfall_kontakt||'—')}</td><td>${OE(z.notfall_hinweis||'—')}</td></tr>`).join('')
          +`</tbody></table></div>`
          +((r.ohne_einverstaendnis||[]).length?`<div class="notice bad"><strong>Fährt nicht mit — kein Einverständnis:</strong> ${OE(r.ohne_einverstaendnis.map(z=>z.display_name).join(', '))}</div>`:'');}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.oe-nach').forEach(b=>b.onclick=async()=>{
      const bericht=prompt('Was hat stattgefunden?');if(!bericht)return;
      const dabei=prompt('Kennungen der tatsächlich Teilnehmenden, durch Komma getrennt:')||'';
      try{await oeApi(`/api/excursions/${encodeURIComponent(b.dataset.id)}/report?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
        body:JSON.stringify({bericht,teilgenommen:dabei.split(',').map(s=>s.trim()).filter(Boolean)})});await render();}
      catch(e){fehler(e);}
    });
  }
  await render();
}

// Für Teilnehmende und Sorgeberechtigte: zusagen und — wer sorgeberechtigt ist — einverstanden sein.
async function oeMeineFahrten(tenantId,meineKennung){
  const {body}=oeModal('Meine Veranstaltungen');
  async function render(){
    let d;try{d=await oeApi(`/api/personal/excursions?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${OE(oeText(e.message))}</div>`;return;}
    const zeilen=(d.fahrten||[]).map(f=>`<tr><th scope="row">${OE(f.titel)}</th><td>${OE(f.display_name)}</td><td>${OE(oeZeit(f.beginnt_am))}</td>`
      +`<td>${OE(oeEuro(f.kosten_cent))}</td><td>Rückmeldung bis ${OE(f.rueckmeldung_bis)}</td>`
      +`<td>${OE(f.zusage)}${f.einverstaendnis_am?', Einverständnis liegt vor':''}</td>`
      +`<td>${f.user_id===meineKennung&&f.zusage==='offen'?`<button class="btn oe-ja" type="button" data-id="${OE(f.id)}">Zusagen</button> <button class="btn secondary oe-nein" type="button" data-id="${OE(f.id)}">Absagen</button>`:''}`
      +`${!f.einverstaendnis_am?` <button class="btn secondary oe-ein" type="button" data-id="${OE(f.id)}" data-p="${OE(f.user_id)}">Einverständnis</button>`:''}</td></tr>`).join('')
      ||'<tr><td colspan="7">Derzeit ist keine Veranstaltung offen.</td></tr>';
    body.innerHTML=`<p class="muted">Zusage und Einverständnis sind zwei Dinge. Ohne Einverständnis fährt niemand mit.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Meine Veranstaltungen</caption><thead><tr><th scope="col">Titel</th><th scope="col">Für</th><th scope="col">Beginn</th><th scope="col">Kosten</th><th scope="col">Frist</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div><p class="error" id="oe-merr" role="alert"></p>`;
    const fehler=e=>{body.querySelector('#oe-merr').textContent=oeText(e.message);};
    const zusagen=async(id,ja)=>{
      try{await oeApi(`/api/excursions/${encodeURIComponent(id)}/rsvp?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({zusage:ja})});await render();}
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.oe-ja').forEach(b=>b.onclick=()=>zusagen(b.dataset.id,true));
    body.querySelectorAll('.oe-nein').forEach(b=>b.onclick=()=>zusagen(b.dataset.id,false));
    body.querySelectorAll('.oe-ein').forEach(b=>b.onclick=async()=>{
      const kontakt=prompt('Unter welcher Nummer sind Sie am Tag der Fahrt erreichbar?')||'';
      const hinweis=prompt('Gibt es etwas, das die Begleitung wissen muss (Allergie, Medikament)? Leer lassen, wenn nicht.')||'';
      try{await oeApi(`/api/excursions/${encodeURIComponent(b.dataset.id)}/consent?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
        body:JSON.stringify({user_id:b.dataset.p,notfall:{kontakt,hinweis}})});await render();}
      catch(e){fehler(e);}
    });
  }
  await render();
}

(async()=>{
  let me=null;try{me=(await oeApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const traegerleitung=me.isPlatformAdmin||roles.some(x=>x.role==='tenant_admin');
  const verwaltung=traegerleitung||roles.some(x=>x.role==='class_admin');
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(seite){
      const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
      if(traegerleitung)knopf('oe-wizard-launch','Einrichtung',()=>oeWizard(tenantId),anker,'nav');
      if(verwaltung)knopf('oe-fahrten-launch','Veranstaltungen',()=>oeFahrten(tenantId),anker,'nav');
    }
    const portal=document.querySelector('.portal-main');
    if(portal&&!document.querySelector('#oe-portal-btn')){
      const b=document.createElement('button');b.id='oe-portal-btn';b.type='button';b.className='portal-btn secondary';b.textContent='Meine Veranstaltungen';
      b.onclick=()=>oeMeineFahrten(tenantId,me.id).catch(e=>alert(oeText(e.message)));
      (document.querySelector('#gs-portal-buttons')||portal).append(b);
    }
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

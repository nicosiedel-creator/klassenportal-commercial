// Dokumentvorlagen und Serienausgabe fuer die Kundenadministration.
//
// Der Sinn der Sache: eine neue Bescheinigungsart soll nicht mehr programmiert werden muessen.
// Die Verwaltung schreibt den Text selbst, setzt Platzhalter aus der angebotenen Liste ein und
// gibt ihn fuer eine ganze Klasse in einem Lauf aus.
const DOC_ADMIN=location.pathname.replace(/\/$/,'')==='/kunden-admin';
if(DOC_ADMIN){
  const E=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const hinweis=x=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(x):'Die Aktion konnte nicht ausgeführt werden.';
  async function api(url,opt={}){
    const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});
    let d={};try{d=await r.json();}catch{}
    if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);
    return d;
  }
  function modal(title,html){
    const w=document.createElement('div');w.className='modal-back';
    w.innerHTML=`<div class="modal" style="width:min(1100px,97vw);max-height:94vh;overflow:auto"><div class="top"><h3 style="margin:0">${E(title)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div data-body>${html}</div></div>`;
    document.body.append(w);
    w.querySelector('[data-close]').onclick=()=>w.remove();
    w.addEventListener('click',e=>{if(e.target===w)w.remove();});
    return w;
  }
  const tenant=()=>document.querySelector('#tenantPick')?.value||'';
  const q=(path,extra={})=>`${path}?${new URLSearchParams({tenant_id:tenant(),...extra})}`;
  const ART={teilnahmebescheinigung:'Teilnahmebescheinigung',praktikumsvertrag:'Praktikumsvertrag',kostentraegerbericht:'Kostenträgerbericht',absageschreiben:'Absageschreiben',sonstiges:'Sonstiges'};
  const ZIEL={teilnehmer:'je teilnehmender Person',kurs:'einmal für die Klasse'};

  async function open(){
    if(!tenant())return alert('Bitte zuerst einen Kunden auswählen.');
    let daten,kurse;
    try{
      daten=await api(q('/api/document-templates'));
      kurse=await api(q('/api/courses')).catch(()=>({courses:[]}));
    }catch(e){return alert(hinweis(e));}
    const vorlagen=daten.templates||[],platzhalter=daten.placeholders||[],cs=kurse.courses||[];
    const w=modal('Dokumentvorlagen & Serienausgabe',`
<div class="notice"><strong>Platzhalter werden eingesetzt, nicht ausgeführt.</strong><div class="muted" style="margin-top:5px">Nur die unten aufgeführten Platzhalter werden gefüllt. Alles andere bleibt im Dokument sichtbar stehen – eine Vorlage kann damit weder Berechnungen anstellen noch auf andere Daten zugreifen.</div></div>
<section class="card" style="margin-top:14px"><div class="top"><div><h3 style="margin:0">Vorlagen</h3><div class="muted">Teilnahmebescheinigung, Praktikumsvertrag, Kostenträgerbericht, Absageschreiben – selbst gepflegt</div></div><button class="btn" type="button" data-new>+ Vorlage</button></div>
<div class="table-wrap"><table><tr><th scope="col">Name</th><th scope="col">Art</th><th scope="col">Ausgabe</th><th scope="col">Version</th><th scope="col">Status</th><th scope="col"></th></tr>
${vorlagen.map(t=>`<tr><td>${E(t.name)}</td><td>${E(ART[t.document_kind]||t.document_kind)}</td><td>${E(ZIEL[t.subject_scope]||t.subject_scope)}</td><td>${E(t.version)}</td><td>${Number(t.is_active)?'aktiv':'stillgelegt'}${(t.unbekannte_platzhalter||[]).length?` · <span class="muted">${E((t.unbekannte_platzhalter||[]).length)} unbekannte Platzhalter</span>`:''}</td><td><button class="btn secondary" data-edit="${E(t.id)}">Bearbeiten</button> <button class="btn secondary" data-preview="${E(t.id)}">Vorschau</button>${Number(t.is_active)?` <button class="btn" data-run="${E(t.id)}">Serie ausgeben</button>`:''}</td></tr>`).join('')||'<tr><td colspan="6" class="muted">Noch keine Vorlage angelegt.</td></tr>'}
</table></div></section>
<section class="card" style="margin-top:14px"><h3 style="margin:0 0 8px">Verfügbare Platzhalter</h3><div class="table-wrap"><table><tr><th scope="col">Platzhalter</th><th scope="col">Bedeutung</th><th scope="col">Verfügbar bei</th></tr>
${platzhalter.map(p=>`<tr><td><code>{{${E(p.schluessel)}}}</code></td><td>${E(p.bedeutung)}</td><td>${E(p.zielgruppe==='beide'?'beiden Ausgabearten':ZIEL[p.zielgruppe]||p.zielgruppe)}</td></tr>`).join('')}
</table></div></section>`);
    w.querySelector('[data-new]').onclick=()=>form(w,null);
    w.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>form(w,vorlagen.find(t=>t.id===b.dataset.edit)));
    w.querySelectorAll('[data-preview]').forEach(b=>b.onclick=()=>preview(vorlagen.find(t=>t.id===b.dataset.preview),cs));
    w.querySelectorAll('[data-run]').forEach(b=>b.onclick=()=>serie(w,vorlagen.find(t=>t.id===b.dataset.run),cs));
  }

  function form(parent,t){
    const w=modal(t?'Vorlage bearbeiten':'Neue Vorlage',`<form data-form>
<label class="field">Name<input name="name" required value="${E(t?.name||'')}" placeholder="Teilnahmebescheinigung"></label>
<div class="row"><label class="field">Art<select name="document_kind">${Object.entries(ART).map(([k,v])=>`<option value="${E(k)}" ${t?.document_kind===k?'selected':''}>${E(v)}</option>`).join('')}</select></label>
<label class="field">Ausgabe<select name="subject_scope">${Object.entries(ZIEL).map(([k,v])=>`<option value="${E(k)}" ${t?.subject_scope===k?'selected':''}>${E(v)}</option>`).join('')}</select></label></div>
<label class="field">Überschrift<input name="title_template" required value="${E(t?.title_template||'Teilnahmebescheinigung')}"></label>
<label class="field">Text<textarea name="body_template" rows="9" required>${E(t?.body_template||'Hiermit bestätigt {{traeger.name}}, dass {{teilnehmer.name}} am Kurs {{kurs.bezeichnung}} ({{kurs.code}}) vom {{zeitraum.von}} bis {{zeitraum.bis}} teilgenommen hat.')}</textarea></label>
<label><input type="checkbox" name="is_active" ${!t||Number(t.is_active)?'checked':''}> aktiv</label>
<div style="margin-top:12px"><button class="btn" type="submit">Speichern</button> <span data-status class="muted" role="status"></span></div></form>`);
    const f=w.querySelector('[data-form]'),st=w.querySelector('[data-status]');
    f.onsubmit=async e=>{
      e.preventDefault();if(!f.reportValidity())return;
      const d=Object.fromEntries(new FormData(f));
      d.is_active=f.elements.is_active.checked;
      if(t)d.id=t.id;
      st.textContent='Wird gespeichert …';
      try{
        const antwort=await api(q('/api/document-templates'),{method:'POST',body:JSON.stringify(d)});
        const offen=antwort.template?.unbekannte_platzhalter||[];
        if(offen.length)alert(`Gespeichert. Diese Platzhalter kann das Portal nicht füllen und lässt sie im Dokument stehen: ${offen.join(', ')}`);
        w.remove();parent.remove();open();
      }catch(x){st.textContent=hinweis(x);}
    };
  }

  function kursFeld(cs){return `<label class="field">Klasse / Kurs<select name="course_id" required><option value="">— wählen —</option>${cs.map(c=>`<option value="${E(c.id)}">${E(c.name)}</option>`).join('')}</select></label>`;}

  function preview(t,cs){
    if(!t)return;
    const w=modal(`Vorschau: ${t.name}`,`<form data-form>${kursFeld(cs)}<button class="btn" type="submit">Vorschau erzeugen</button> <span data-status class="muted" role="status"></span></form><div data-out style="margin-top:14px"></div>`);
    const f=w.querySelector('[data-form]'),st=w.querySelector('[data-status]'),out=w.querySelector('[data-out]');
    f.onsubmit=async e=>{
      e.preventDefault();if(!f.reportValidity())return;
      st.textContent='Wird erzeugt …';out.innerHTML='';
      try{
        const d=await api(q('/api/document-templates/preview'),{method:'POST',body:JSON.stringify({template_id:t.id,course_id:f.elements.course_id.value})});
        const p=d.preview||{};st.textContent='';
        out.innerHTML=`<article style="padding:22px;border:1px solid #dbe3ec;border-radius:8px"><h2 style="margin-top:0">${E(p.title||'')}</h2><p style="white-space:pre-wrap;line-height:1.7">${E(p.body||'')}</p></article>`
          +((p.unbekannte_platzhalter||[]).length?`<div class="notice" style="margin-top:10px">Diese Platzhalter bleiben unverändert stehen, weil es sie nicht gibt: ${E((p.unbekannte_platzhalter||[]).join(', '))}</div>`:'');
      }catch(x){st.textContent=hinweis(x);}
    };
  }

  // Grosse Serien laufen in Abschnitten. Der Server meldet nach jedem Abschnitt, wie viel offen
  // ist; hier wird so lange fortgesetzt, bis nichts mehr aussteht - der Kunde sieht dabei den
  // Fortschritt, statt vor einer Oberflaeche zu warten, die nichts sagt.
  function serie(parent,t,cs){
    if(!t)return;
    const w=modal(`Serienausgabe: ${t.name}`,`<div class="notice">Es entsteht ${E(ZIEL[t.subject_scope]||'')} ein Dokument. Fertige Dokumente bleiben unverändert, auch wenn die Vorlage später bearbeitet wird.</div>
<form data-form style="margin-top:12px">${kursFeld(cs)}<div class="row"><label class="field">Zeitraum von <span class="muted">optional</span><input name="period_from" type="date"></label><label class="field">Zeitraum bis <span class="muted">optional</span><input name="period_to" type="date"></label></div>
<button class="btn" type="submit">Serie ausgeben</button> <span data-status class="muted" role="status"></span></form><div data-out style="margin-top:14px"></div>`);
    const f=w.querySelector('[data-form]'),st=w.querySelector('[data-status]'),out=w.querySelector('[data-out]');
    f.onsubmit=async e=>{
      e.preventDefault();if(!f.reportValidity())return;
      f.querySelector('button[type=submit]').disabled=true;out.innerHTML='';
      try{
        const start=await api(q('/api/document-runs'),{method:'POST',body:JSON.stringify({template_id:t.id,course_id:f.elements.course_id.value,period_from:f.elements.period_from.value||null,period_to:f.elements.period_to.value||null})});
        let lauf=start.run||{},fertig=lauf.total-lauf.remaining;
        st.textContent=`${fertig} von ${lauf.total} Dokumenten erzeugt …`;
        while(!lauf.completed){
          const weiter=await api(q(`/api/document-runs/${encodeURIComponent(lauf.run_id)}/continue`),{method:'POST',body:'{}'});
          lauf=weiter.run||{};
          fertig=lauf.total-lauf.remaining;
          st.textContent=`${fertig} von ${lauf.total} Dokumenten erzeugt …`;
        }
        st.textContent='';
        const d=await api(q(`/api/document-runs/${encodeURIComponent(lauf.run_id)}`));
        const docs=d.documents||[];
        out.innerHTML=`<div class="notice ok"><strong>${E(docs.length)} Dokument(e) erzeugt.</strong></div>`
          +docs.map(x=>`<article style="padding:20px;margin-top:12px;border:1px solid #dbe3ec;border-radius:8px;page-break-after:always"><div class="muted">${E(x.document_number)}</div><h2 style="margin:4px 0 10px">${E(x.title)}</h2><p style="white-space:pre-wrap;line-height:1.7">${E(x.body)}</p></article>`).join('')
          +'<div class="toolbar" style="margin-top:12px"><button class="btn secondary" type="button" data-print>Drucken / PDF speichern</button></div>';
        out.querySelector('[data-print]').onclick=()=>window.print();
      }catch(x){st.textContent=hinweis(x);}
      finally{f.querySelector('button[type=submit]').disabled=false;}
    };
  }

  function einhaengen(){
    const side=document.querySelector('.side');
    if(!side||side.querySelector('#doc-template-nav'))return;
    const b=document.createElement('button');
    b.id='doc-template-nav';b.className='nav';b.type='button';b.textContent='Dokumentvorlagen & Serienbriefe';
    side.insertBefore(b,side.querySelector('.spacer')||null);
    b.onclick=open;
  }
  new MutationObserver(()=>queueMicrotask(einhaengen)).observe(document.body,{subtree:true,childList:true});
  einhaengen();
}

// Benachrichtigungszentrum und Kommunikationsnachweis (Master-Spec V2, K5 bis K7).
//
// Zwei Fragen, zwei Seiten derselben Sache:
//
//  - Die Person fragt: Was habe ich bekommen, über welchen Weg, was steht noch offen - und wie
//    stelle ich ein, was ich wie bekommen will? Bisher gab es dafür keine Stelle. Ohne sie bleibt
//    als einziges Mittel gegen zu viele Meldungen das Wegsehen, und dann geht die verbindliche
//    Mitteilung mit unter.
//
//  - Der Träger fragt: Ging die Einladung raus, an wen, über welchen Weg, wer hat gelesen, wer hat
//    bestätigt - und was ist NICHT angekommen? Eine fehlgeschlagene oder unterdrückte Zustellung,
//    die nirgends steht, ist eine nicht erfolgte Benachrichtigung.
//
// Was diese Oberfläche ausdrücklich NICHT tut: filtern. Die Rangfolge aus K3 wird im Zustellweg
// durchgesetzt, nicht hier - was ein Browser ausblendet, blendet der nächste anders aus.
const NC_ADMIN=['/kunden-admin','/klassen-admin'].includes(location.pathname.replace(/\/$/,''));
const NC_PORTAL=/^\/portal\/[^/]+\/[^/]+\/?$/.test(location.pathname);
if(NC_ADMIN||NC_PORTAL){
  const E=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function ncApi(url,opt={}){
    const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});
    let d={};try{d=await r.clone().json();}catch(fehler){d={};}
    if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);
    return d;
  }
  const ncText=f=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(f):String(f&&f.message||f||'');
  const ncZeit=v=>v?new Date(v).toLocaleString('de-DE'):'—';
  const RANG={verbindlich:'Verbindlich',wichtig:'Wichtig',normal:'Normal'};
  const THEMA={allgemein:'Allgemein',organisation:'Organisation',unterricht:'Unterricht',pruefung:'Prüfungen',termine:'Termine',abrechnung:'Abrechnung'};
  const GRUND={themenabwahl:'Thema abbestellt',kanal_abgeschaltet:'Weg abgeschaltet',ruhezeit:'Ruhezeit'};
  const KANAL={portal:'Portal',mail:'E-Mail',push:'Kurzmeldung'};
  const MAILSTAND={sent:'gesendet',failed:'fehlgeschlagen',queued:'vorgemerkt',offen:'offen',nicht_gewaehlt:'nicht gewählt'};

  // Ein Inhaltsobjekt, eine Darstellung je Weg. Hier wird die Portalfassung gezeichnet - aus
  // denselben Bausteinen, aus denen der Versand seine Mail und seine Kurzmeldung rechnet.
  function ncBlock(b){
    if(!b||typeof b!=='object')return '';
    if(b.typ==='ueberschrift')return `<h4 style="margin:14px 0 4px">${E(b.text)}</h4>`;
    if(b.typ==='liste')return `<ul>${(b.punkte||[]).map(p=>`<li>${E(p)}</li>`).join('')}</ul>`;
    if(b.typ==='link')return `<p><a href="${E(b.ziel)}">${E(b.text)}</a></p>`;
    if(b.typ==='datei')return `<p><a href="${E(b.ziel)}">${E(b.text)}</a> <span class="muted">(Datei)</span></p>`;
    if(b.typ==='termin')return `<p><strong>${E(b.text)}</strong><br>${E(ncZeit(b.beginn))}${b.ende?` bis ${E(ncZeit(b.ende))}`:''}${b.ort?`<br>${E(b.ort)}`:''}</p>`;
    return `<p style="white-space:pre-wrap">${E(b.text)}</p>`;
  }
  const ncBloecke=liste=>Array.isArray(liste)&&liste.length?liste.map(ncBlock).join(''):'<p class="muted">Kein Inhalt hinterlegt.</p>';

  function ncModal(titel,inhalt,breite='min(1100px,97vw)'){
    const w=document.createElement('div');w.className='modal-back';
    w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" style="width:${breite};max-height:94vh;overflow:auto"><div class="top"><h3 style="margin:0">${E(titel)}</h3><button type="button" class="btn secondary" data-close aria-label="Schließen">×</button></div><div data-inhalt>${inhalt}</div></div>`;
    document.body.append(w);
    w.querySelector('[data-close]').addEventListener('click',()=>w.remove());
    w.addEventListener('click',e=>{if(e.target===w)w.remove();});
    return w;
  }

  // ---------------------------------------------------------------------------
  // Seite der Person: was kam an, was steht offen, was will ich wie bekommen
  // ---------------------------------------------------------------------------
  function ncKanalZeile(m){
    const teile=[`Portal: zugestellt`];
    if(m.kanaele&&m.kanaele.mail!=='nicht_gewaehlt')teile.push(`E-Mail: ${MAILSTAND[m.kanaele.mail]||m.kanaele.mail}`);
    if(m.kanaele&&m.kanaele.push&&m.kanaele.push!=='nicht_erzeugt')teile.push(`Kurzmeldung: ${m.kanaele.push==='sent'?'gesendet':m.kanaele.push==='cancelled'?'nicht gesendet':'vorgemerkt'}`);
    for(const e of m.entscheidungen||[])teile.push(`${KANAL[e.kanal]||e.kanal}: ${e.entscheidung==='verzoegert'?'verzögert':'unterdrückt'} (${GRUND[e.grund]||e.grund})`);
    return teile.join(' · ');
  }

  function ncPraeferenzFormular(p){
    return `<form data-praeferenzen class="card" style="margin-top:14px"><h4 style="margin:0 0 8px">Was Du wie bekommen möchtest</h4>`
      +`<p class="muted">${E(p.hinweis||'')}</p>`
      +`<label style="display:block;margin:8px 0"><input type="checkbox" name="mail_aktiv"${p.mail_aktiv?' checked':''}> Benachrichtigungen zusätzlich per E-Mail</label>`
      +`<label style="display:block;margin:8px 0"><input type="checkbox" name="push_aktiv"${p.push_aktiv?' checked':''}> Kurzmeldungen auf meine Geräte</label>`
      +`<div class="row"><label class="field">Ruhezeit ab <span class="muted">optional, z. B. 22:00</span><input type="time" name="ruhe_von" value="${E(p.ruhe_von||'')}"></label>`
      +`<label class="field">Ruhezeit bis <span class="muted">optional, z. B. 07:00</span><input type="time" name="ruhe_bis" value="${E(p.ruhe_bis||'')}"></label></div>`
      +`<fieldset style="margin-top:12px;border:1px solid #dbe3ec;border-radius:8px;padding:10px"><legend>Themen, über die ich nicht benachrichtigt werden möchte</legend>`
      +(p.themen||[]).map(t=>`<label style="display:block;margin:4px 0"><input type="checkbox" name="thema_${E(t.thema)}"${t.abbestellt?' checked':''}> ${E(THEMA[t.thema]||t.thema)}</label>`).join('')
      +`</fieldset><div class="toolbar" style="margin-top:12px"><button class="btn" type="submit">Einstellungen speichern</button><span class="muted" data-status role="status"></span></div></form>`;
  }

  function ncZeichnePortal(ctx,daten){
    let host=document.querySelector('#portal-notification-center');
    if(!host){
      host=document.createElement('section');host.id='portal-notification-center';host.className='portal-section wide';
      const main=document.querySelector('.portal-main')||document.querySelector('#class-portal');
      if(main)main.append(host);else document.body.append(host);
    }
    const meldungen=daten.meldungen||[],p=daten.praeferenzen||{};
    host.innerHTML=`<div class="portal-section-head"><h2>Benachrichtigungen</h2><span>${meldungen.length}${daten.offen?` · ${daten.offen} zu bestätigen`:''}</span></div>`
      +`<div class="table-wrap"><table><caption class="muted">Was an Dich ging, über welchen Weg, und was davon gelesen und bestätigt ist.</caption><tr><th scope="col">Mitteilung</th><th scope="col">Stufe</th><th scope="col">Wege</th><th scope="col">Gelesen</th><th scope="col">Bestätigt</th><th scope="col">Erinnerungen</th></tr>`
      +(meldungen.length?meldungen.map(m=>`<tr><td><strong>${E(m.titel)}</strong><div class="meta">${E(THEMA[m.thema]||m.thema)} · ${E(ncZeit(m.veroeffentlicht_am))}</div></td>`
        +`<td>${E(RANG[m.rangstufe]||m.rangstufe)}</td><td class="meta">${E(ncKanalZeile(m))}</td>`
        +`<td>${m.gelesen_am?E(ncZeit(m.gelesen_am)):'—'}</td>`
        +`<td>${m.quittiert_am?E(ncZeit(m.quittiert_am)):m.quittung_noetig?'<strong>offen</strong>':'—'}</td>`
        +`<td>${Number(m.erinnerungen||0)}</td></tr>`
        +`<tr><td colspan="6"><details><summary>Inhalt anzeigen: ${E(m.titel)}</summary><div style="margin-top:8px">${ncBloecke(m.bloecke)}</div>`
        +(m.quittung_noetig&&!m.quittiert_am?`<div class="toolbar" style="margin-top:10px"><button class="btn" type="button" data-ack="${E(m.id)}">Gelesen &amp; verbindlich bestätigen</button></div>`
          :!m.gelesen_am?`<div class="toolbar" style="margin-top:10px"><button class="btn secondary" type="button" data-read="${E(m.id)}">Als gelesen markieren</button></div>`:'')
        +`</details></td></tr>`).join('')
        :'<tr><td colspan="6" class="muted">Für Dich liegt derzeit keine Mitteilung vor.</td></tr>')
      +`</table></div>${ncPraeferenzFormular(p)}`;
    ncBindePortal(ctx,host);
  }

  function ncBindePortal(ctx,host){
    const q=`tenant_id=${encodeURIComponent(ctx.tenantId)}${ctx.courseId?`&course_id=${encodeURIComponent(ctx.courseId)}`:''}`;
    host.querySelectorAll('[data-read]').forEach(b=>b.addEventListener('click',async()=>{
      b.disabled=true;
      try{await ncApi(`/api/communications/${encodeURIComponent(b.dataset.read)}/read?${q}`,{method:'PATCH',body:'{}'});await ncLadePortal(ctx,true);}
      catch(fehler){b.disabled=false;b.insertAdjacentHTML('afterend',`<span class="notice bad">${E(ncText(fehler))}</span>`);}
    }));
    host.querySelectorAll('[data-ack]').forEach(b=>b.addEventListener('click',async()=>{
      if(!confirm('Bestätigst Du, dass Du diese Mitteilung gelesen und zur Kenntnis genommen hast?'))return;
      b.disabled=true;
      try{await ncApi(`/api/communications/${encodeURIComponent(b.dataset.ack)}/ack?${q}`,{method:'POST',body:'{}'});await ncLadePortal(ctx,true);}
      catch(fehler){b.disabled=false;b.insertAdjacentHTML('afterend',`<span class="notice bad">${E(ncText(fehler))}</span>`);}
    }));
    const form=host.querySelector('[data-praeferenzen]');
    if(form)form.addEventListener('submit',async e=>{
      e.preventDefault();
      const stand=form.querySelector('[data-status]');stand.textContent='Wird gespeichert …';
      const themen=[...form.querySelectorAll('input[name^="thema_"]')].map(x=>({thema:x.name.slice(6),abbestellt:x.checked}));
      const nutzlast={mail_aktiv:form.elements.mail_aktiv.checked,push_aktiv:form.elements.push_aktiv.checked,
        ruhe_von:form.elements.ruhe_von.value||null,ruhe_bis:form.elements.ruhe_bis.value||null,themen};
      try{await ncApi(`/api/communications/preferences?${q}`,{method:'PUT',body:JSON.stringify(nutzlast)});stand.textContent='Gespeichert.';await ncLadePortal(ctx,true);}
      catch(fehler){stand.textContent=ncText(fehler);}
    });
  }

  let ncKontext=null,ncLaeuft=false;
  async function ncLadePortal(ctx=ncKontext,erzwingen=false){
    if(!ctx||(ncLaeuft&&!erzwingen))return;
    ncLaeuft=true;
    try{
      const q=`tenant_id=${encodeURIComponent(ctx.tenantId)}${ctx.courseId?`&course_id=${encodeURIComponent(ctx.courseId)}`:''}`;
      ncZeichnePortal(ctx,await ncApi(`/api/communications/center?${q}`));
    }catch(fehler){
      // Eine leere Liste und eine nicht geladene Liste sind zweierlei. Der Grund gehört hin.
      let host=document.querySelector('#portal-notification-center');
      if(!host){host=document.createElement('section');host.id='portal-notification-center';host.className='portal-section wide';(document.querySelector('.portal-main')||document.body).append(host);}
      host.innerHTML=`<div class="portal-section-head"><h2>Benachrichtigungen</h2></div><div class="notice bad">Dein Benachrichtigungszentrum konnte nicht geladen werden: ${E(ncText(fehler))}</div>`;
    }finally{ncLaeuft=false;}
  }

  // ---------------------------------------------------------------------------
  // Seite des Trägers: der Nachweis
  // ---------------------------------------------------------------------------
  async function ncScope(){
    if(location.pathname.startsWith('/kunden-admin')){
      const tenantId=document.querySelector('#tenantPick')?.value||'';
      if(!tenantId)throw new Error('Bitte zuerst einen Kundenbereich auswählen.');
      return{tenantId,courseId:null};
    }
    const p=new URLSearchParams(location.search),me=(await ncApi('/api/auth/me')).user,rollen=me?.tenantRoles||[];
    const treffer=rollen.find(x=>x.role==='class_admin'&&x.courseId&&(!p.get('tenant_id')||x.tenantId===p.get('tenant_id')))||rollen.find(x=>x.role==='class_admin'&&x.courseId);
    if(!treffer&&me?.isPlatformAdmin&&p.get('tenant_id'))return{tenantId:p.get('tenant_id'),courseId:p.get('course_id')||null};
    if(!treffer)throw new Error('Kein Klassenbereich zugeordnet.');
    return{tenantId:treffer.tenantId,courseId:treffer.courseId};
  }
  const ncQ=(pfad,t,c)=>`${pfad}${pfad.includes('?')?'&':'?'}tenant_id=${encodeURIComponent(t)}${c?`&course_id=${encodeURIComponent(c)}`:''}`;

  async function ncNachweisListe(){
    let ctx;
    try{ctx=await ncScope();}catch(fehler){alert(ncText(fehler));return;}
    const w=ncModal('Kommunikationsnachweis','<p>Wird geladen …</p>');
    const feld=w.querySelector('[data-inhalt]');
    let daten;
    try{daten=await ncApi(ncQ('/api/communications/proof',ctx.tenantId,ctx.courseId));}
    catch(fehler){feld.innerHTML=`<div class="notice bad">Der Kommunikationsnachweis konnte nicht geladen werden: ${E(ncText(fehler))}</div>`;return;}
    const zeilen=daten.meldungen||[];
    feld.innerHTML=`<p class="muted">Wer hat was wann über welchen Weg bekommen – einschließlich dessen, was <strong>nicht</strong> zugestellt wurde. Eine fehlgeschlagene Zustellung, die nirgends steht, ist eine nicht erfolgte Benachrichtigung.</p>`
      +`<div class="table-wrap"><table><tr><th scope="col">Mitteilung</th><th scope="col">Stufe</th><th scope="col">Veröffentlicht</th><th scope="col">Empfänger</th><th scope="col">Gelesen</th><th scope="col">Bestätigt</th><th scope="col">E-Mail</th><th scope="col">Nicht zugestellt</th><th scope="col"><span class="muted">Aktion</span></th></tr>`
      +(zeilen.length?zeilen.map(m=>`<tr><td><strong>${E(m.title)}</strong><div class="muted">${E(THEMA[m.thema]||m.thema)}</div></td>`
        +`<td>${E(RANG[m.rangstufe]||m.rangstufe)}</td><td>${E(ncZeit(m.published_at))}</td><td>${Number(m.empfaenger||0)}</td>`
        +`<td>${Number(m.gelesen||0)}</td><td>${Number(m.require_ack)?Number(m.quittiert||0):'—'}</td>`
        +`<td>${Number(m.send_email)?`${Number(m.mail_gesendet||0)} gesendet${Number(m.mail_fehlgeschlagen||0)?` · <strong>${Number(m.mail_fehlgeschlagen)} fehlgeschlagen</strong>`:''}`:'<span class="muted">nur Portal</span>'}</td>`
        +`<td>${Number(m.unterdrueckt||0)+Number(m.verzoegert||0)||'—'}</td>`
        +`<td><button class="btn secondary" type="button" data-nachweis="${E(m.id)}">Nachweis</button></td></tr>`).join('')
        :'<tr><td colspan="9" class="muted">Es wurde noch keine Mitteilung veröffentlicht.</td></tr>')
      +'</table></div>';
    feld.querySelectorAll('[data-nachweis]').forEach(b=>b.addEventListener('click',()=>ncNachweisDetail(ctx,b.dataset.nachweis)));
  }

  async function ncNachweisDetail(ctx,messageId){
    const w=ncModal('Zustellnachweis','<p>Wird geladen …</p>');
    const feld=w.querySelector('[data-inhalt]');
    let daten;
    try{daten=(await ncApi(ncQ(`/api/communications/${encodeURIComponent(messageId)}/proof`,ctx.tenantId,ctx.courseId))).nachweis;}
    catch(fehler){feld.innerHTML=`<div class="notice bad">Der Zustellnachweis konnte nicht geladen werden: ${E(ncText(fehler))}</div>`;return;}
    const m=daten.meldung||{},k=daten.kanaele||{},q=daten.quittung||{};
    feld.innerHTML=`<div class="notice"><strong>${E(m.titel)}</strong> · ${E(RANG[m.rangstufe]||m.rangstufe)} · ${E(THEMA[m.thema]||m.thema)}<div class="muted">Veröffentlicht ${E(ncZeit(m.veroeffentlicht_am))}</div></div>`
      +`<div class="grid" style="margin-top:14px"><div class="card"><strong>${Number(k.portal&&k.portal.zugestellt||0)}</strong><div class="muted">Empfänger im Portal</div></div>`
      +`<div class="card"><strong>${Number(k.portal&&k.portal.gelesen||0)}</strong><div class="muted">gelesen</div></div>`
      +`<div class="card"><strong>${Number(k.mail&&k.mail.sent||0)}</strong><div class="muted">E-Mail gesendet</div></div>`
      +`<div class="card"><strong>${Number(k.mail&&k.mail.failed||0)}</strong><div class="muted">E-Mail endgültig fehlgeschlagen</div></div>`
      +`<div class="card"><strong>${Number(q.quittiert||0)}</strong><div class="muted">bestätigt</div></div>`
      +`<div class="card"><strong>${Number(q.ausstehend||0)}</strong><div class="muted">Bestätigung ausstehend</div></div></div>`
      +`<section class="card" style="margin-top:14px"><h4 style="margin-top:0">Nicht zugestellt</h4>`
      +((daten.nicht_zugestellt||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Weg</th><th scope="col">Entscheidung</th><th scope="col">Grund</th><th scope="col">Personen</th></tr>`
        +daten.nicht_zugestellt.map(x=>`<tr><td>${E(KANAL[x.kanal]||x.kanal)}</td><td>${x.entscheidung==='verzoegert'?'verzögert':'unterdrückt'}</td><td>${E(GRUND[x.grund]||x.grund)}</td><td>${Number(x.anzahl||0)}</td></tr>`).join('')
        +'</table></div>':'<p class="muted">Es wurde nichts unterdrückt oder verzögert.</p>')
      +`</section>`
      +`<section class="card" style="margin-top:14px"><h4 style="margin-top:0">Personen</h4><div class="table-wrap"><table><tr><th scope="col">Person</th><th scope="col">Zugestellt</th><th scope="col">Gelesen</th><th scope="col">Bestätigt</th><th scope="col">E-Mail</th><th scope="col">Kurzmeldung</th><th scope="col">Erinnerungen</th></tr>`
      +(daten.personen||[]).map(p=>`<tr><td>${E(p.name)}</td><td>${E(ncZeit(p.zugestellt_am))}</td><td>${p.gelesen_am?E(ncZeit(p.gelesen_am)):'—'}</td><td>${p.quittiert_am?E(ncZeit(p.quittiert_am)):(q.noetig?'<strong>offen</strong>':'—')}</td>`
        +`<td>${E(MAILSTAND[p.mail_status]||p.mail_status||'—')}${p.mail_fehler?` <span class="muted">(${E(p.mail_fehler)})</span>`:''}</td>`
        +`<td>${p.push_status==='sent'?'gesendet':p.push_status==='cancelled'?'nicht gesendet':p.push_status==='pending'?'vorgemerkt':'—'}</td>`
        +`<td>${Number(p.erinnerungen||0)}</td></tr>`).join('')
      +`</table></div>${daten.hinweis_unvollstaendig?`<p class="muted">${E(daten.hinweis_unvollstaendig)}</p>`:''}</section>`
      +(q.noetig&&Number(q.ausstehend||0)?`<div class="toolbar" style="margin-top:14px"><button class="btn" type="button" data-erinnern>${Number(q.ausstehend)} ausstehende Bestätigung(en) anmahnen</button><span class="muted" data-status role="status"></span></div>`:'');
    const knopf=feld.querySelector('[data-erinnern]');
    if(knopf)knopf.addEventListener('click',async()=>{
      const stand=feld.querySelector('[data-status]');stand.textContent='Erinnerung wird gesendet …';knopf.disabled=true;
      try{const r=await ncApi(ncQ(`/api/communications/${encodeURIComponent(messageId)}/remind`,ctx.tenantId,ctx.courseId),{method:'POST',body:'{}'});stand.textContent=`${r.erinnert} Person(en) erinnert.`;}
      catch(fehler){stand.textContent=ncText(fehler);knopf.disabled=false;}
    });
  }

  // ---------------------------------------------------------------------------
  // Einhängen
  // ---------------------------------------------------------------------------
  function ncKnopfKundenadmin(){
    const seite=document.querySelector('.side');
    if(!seite||seite.querySelector('#notification-center-nav'))return;
    const b=document.createElement('button');b.id='notification-center-nav';b.type='button';b.className='nav';b.textContent='Kommunikationsnachweis';
    seite.insertBefore(b,seite.querySelector('.spacer')||null);
    b.addEventListener('click',ncNachweisListe);
  }
  function ncKnopfKlassenadmin(){
    const wurzel=document.querySelector('#class-admin-portal');
    if(!wurzel||wurzel.querySelector('#notification-center-class-btn'))return;
    const leiste=wurzel.querySelector('.class-admin-actions');
    if(!leiste)return;
    const b=document.createElement('button');b.id='notification-center-class-btn';b.type='button';b.className='portal-btn secondary';b.textContent='Kommunikationsnachweis';
    leiste.append(b);b.addEventListener('click',ncNachweisListe);
  }
  if(NC_ADMIN){
    new MutationObserver(()=>queueMicrotask(()=>{if(location.pathname.startsWith('/kunden-admin'))ncKnopfKundenadmin();else ncKnopfKlassenadmin();})).observe(document.body,{subtree:true,childList:true});
    if(location.pathname.startsWith('/kunden-admin'))ncKnopfKundenadmin();else ncKnopfKlassenadmin();
  }
  if(NC_PORTAL){
    const ausPortal=daten=>{
      if(!daten||!daten.viewer||!daten.viewer.tenantId)return null;
      return{tenantId:String(daten.viewer.tenantId),courseId:daten.course&&daten.course.id?String(daten.course.id):null};
    };
    const start=daten=>{ncKontext=ausPortal(daten);if(ncKontext)void ncLadePortal(ncKontext,true);else document.querySelector('#portal-notification-center')?.remove();};
    window.addEventListener('kp:portal-data',e=>start(e.detail&&e.detail.data));
    if(window.__KP_PORTAL_DATA)start(window.__KP_PORTAL_DATA);
  }
}

// Laufbahn (Wechsel, Unterbrechung, Wiederaufnahme) und individuelle Lernplanung.
//
// Eine Unterbrechung ist kein Abbruch — das steht hier ausdrücklich, weil genau diese
// Unterscheidung darüber entscheidet, was der Träger dem Kostenträger meldet.
const LL=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LL_ARTEN=[['wechsel','Kurswechsel'],['unterbrechung','Unterbrechung'],['wiederaufnahme','Wiederaufnahme'],['abbruch','Abbruch']];
const LL_QUELLE={luecke:'Lücke',fehlzeit:'Versäumt',ungeprueft:'Noch kein Nachweis',manuell:'Eigener Schritt'};
async function llApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const llText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function llModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="ll-titel" style="width:min(960px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="ll-titel" style="margin:0">${LL(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="ll-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#ll-body'),zu};
}

async function llLaufbahn(tenantId){
  const {body}=llModal('Laufbahn: Wechsel, Unterbrechung, Wiederaufnahme');
  async function render(){
    let d;try{d=await llApi(`/api/enrollment-transitions?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${LL(llText(e.message))}</div>`;return;}
    const offen=(d.offen||[]).map(v=>`<tr><th scope="row">${LL(v.display_name)}</th><td>${LL(v.art)}</td><td>${LL(v.stichtag)}</td><td>${LL(v.anlass)}</td>`
      +`<td><button class="btn ll-ja" type="button" data-id="${LL(v.id)}">Genehmigen</button> <button class="btn secondary ll-nein" type="button" data-id="${LL(v.id)}">Ablehnen</button> <button class="btn secondary ll-voll" type="button" data-id="${LL(v.id)}">Vollziehen</button></td></tr>`).join('')
      ||'<tr><td colspan="5">Nichts offen.</td></tr>';
    const spaet=(d.ueberfaellig||[]).map(v=>`<tr><th scope="row">${LL(v.display_name)}</th><td>${LL(v.geplante_rueckkehr)}</td></tr>`).join('');
    body.innerHTML=`<p class="muted">Eine Unterbrechung ist kein Abbruch. Wer zurückerwartet wird und nicht kommt, steht unten — nicht in der Abbrecherquote.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Offene Vorgänge</caption><thead><tr><th scope="col">Person</th><th scope="col">Art</th><th scope="col">Stichtag</th><th scope="col">Anlass</th><th scope="col">Aktion</th></tr></thead><tbody>${offen}</tbody></table></div>`
      +(spaet?`<div class="notice bad"><strong>Rückkehr überfällig</strong><div style="overflow-x:auto"><table class="table"><caption>Zurückerwartet, aber nicht wieder angemeldet</caption><thead><tr><th scope="col">Person</th><th scope="col">Erwartet seit</th></tr></thead><tbody>${spaet}</tbody></table></div></div>`:'')
      +`<form id="ll-neu"><h4>Vorgang anlegen</h4><label class="field">Person (Kennung)<input name="user_id" required></label>`
      +`<label class="field">Art<select name="art">${LL_ARTEN.map(([k,t])=>`<option value="${LL(k)}">${LL(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Aus Kurs<input name="von_course_id"></label><label class="field">In Kurs (nur beim Wechsel)<input name="nach_course_id"></label>`
      +`<label class="field">Stichtag<input name="stichtag" type="date" required></label>`
      +`<label class="field">Geplante Rückkehr (bei Unterbrechung)<input name="geplante_rueckkehr" type="date"></label>`
      +`<label class="field">Leistungen<select name="leistungen"><option value="im_alten_kurs_belassen">Im alten Kurs belassen</option><option value="mitnehmen">In den neuen Kurs mitnehmen</option></select></label>`
      +`<label class="field">Anlass<textarea name="anlass" rows="3" required></textarea></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Beantragen</button></div></form><p class="error" id="ll-err" role="alert"></p><p id="ll-info" class="muted" role="status"></p>`;
    const fehler=e=>{body.querySelector('#ll-err').textContent=llText(e.message);};
    body.querySelector('#ll-neu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target),daten={};
      for(const [k,v] of f.entries())if(String(v).trim())daten[k]=String(v).trim();
      try{await llApi(`/api/enrollment-transitions?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(daten)});await render();}
      catch(e){fehler(e);}
    };
    const entscheide=async(id,ja)=>{
      const grund=prompt(ja?'Begründung der Genehmigung:':'Begründung der Ablehnung:');
      if(!grund)return;
      try{await llApi(`/api/enrollment-transitions/${encodeURIComponent(id)}/decision?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({genehmigt:ja,begruendung:grund})});await render();}
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.ll-ja').forEach(b=>b.onclick=()=>entscheide(b.dataset.id,true));
    body.querySelectorAll('.ll-nein').forEach(b=>b.onclick=()=>entscheide(b.dataset.id,false));
    body.querySelectorAll('.ll-voll').forEach(b=>b.onclick=async()=>{
      try{const r=await llApi(`/api/enrollment-transitions/${encodeURIComponent(b.dataset.id)}/execute?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
        body.querySelector('#ll-info').textContent=`Vollzogen (${r.art}). Die Leistungen im alten Kurs bleiben stehen.`;await render();}
      catch(e){fehler(e);}
    });
  }
  await render();
}

// Lernplan: rückwärts vom Prüfungstermin.
async function llLernplan(tenantId,alsVerwaltung){
  const {body}=llModal(alsVerwaltung?'Lernplanung':'Mein Lernplan');
  if(alsVerwaltung){
    body.innerHTML=`<p class="muted">Geplant wird rückwärts vom Prüfungstermin — aus belegten Lücken und versäumten Einheiten. Reicht die Zeit nicht, sagt der Plan es.</p>`
      +`<form id="ll-plan"><label class="field">Kurs (Kennung)<input name="course_id" required></label><label class="field">Person (Kennung)<input name="user_id" required></label>`
      +`<label class="field">Prüfungstermin<input name="pruefungstermin" type="date" required></label>`
      +`<label class="field">Zumutbare Wochenstunden<input name="wochenstunden" type="number" min="1" max="40" value="4" required></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Plan rechnen</button></div></form><p class="error" id="ll-perr" role="alert"></p><div id="ll-pout"></div>`;
    body.querySelector('#ll-plan').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{const r=await llApi(`/api/learning-plans?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        course_id:String(f.get('course_id')),user_id:String(f.get('user_id')),pruefungstermin:String(f.get('pruefungstermin')),wochenstunden:Number(f.get('wochenstunden'))})});
        await zeigePlan(r.id);}
      catch(e){body.querySelector('#ll-perr').textContent=llText(e.message);}
    };
  }else{
    let d;try{d=await llApi(`/api/personal/learning-plans?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${LL(llText(e.message))}</div>`;return;}
    // Die eigene Laufbahn gehört daneben: wer unterbrochen hat, soll schwarz auf weiß lesen,
    // dass er nicht als Abbrecher geführt wird — und bis wann er zurückerwartet wird.
    let lauf=null;try{lauf=await llApi(`/api/personal/enrollment-history?tenant_id=${encodeURIComponent(tenantId)}`);}catch{}
    const standText=lauf?({laufend:'Ihre Teilnahme läuft.',
      unterbrochen:`Ihre Teilnahme ist seit dem ${LL(lauf.unterbrochen_seit||'')} unterbrochen${lauf.rueckkehr_geplant?` — zurückerwartet zum ${LL(lauf.rueckkehr_geplant)}`:''}. Das ist kein Abbruch.`,
      abgebrochen:'Ihre Teilnahme ist beendet.'}[lauf.stand]||''):'';
    const liste=(d.plaene||[]).map(p=>`<li><button class="btn secondary ll-oeff" type="button" data-id="${LL(p.id)}">${LL(p.kurs)} — Prüfung ${LL(p.pruefungstermin)}, ${LL(String(p.offen))} offen</button></li>`).join('')
      ||'<li>Für Sie ist derzeit kein Lernplan hinterlegt.</li>';
    body.innerHTML=(standText?`<div class="notice ${lauf.stand==='laufend'?'good':''}">${LL(standText)}</div>`:'')
      +`<ul style="list-style:none;padding:0;display:flex;flex-direction:column;gap:.5rem">${liste}</ul><p class="error" id="ll-perr" role="alert"></p><div id="ll-pout"></div>`;
    body.querySelectorAll('.ll-oeff').forEach(b=>b.onclick=()=>zeigePlan(b.dataset.id));
  }
  async function zeigePlan(planId){
    try{
      const d=await llApi(`/api/learning-plans/${encodeURIComponent(planId)}?tenant_id=${encodeURIComponent(tenantId)}`);
      const zeilen=(d.schritte||[]).map(s=>`<tr><th scope="row">${LL(s.titel)}</th><td>${LL(LL_QUELLE[s.quelle]||s.quelle)}</td><td>${LL(s.faellig_am)}</td><td>${LL(String(s.aufwand_minuten))} min</td>`
        +`<td>${s.status==='erledigt'?`erledigt${s.erledigt_grund==='nachweis'?' (Nachweis)':''}`:'offen'}</td>`
        +`<td>${s.status==='offen'&&s.quelle!=='luecke'?`<button class="btn secondary ll-fertig" type="button" data-id="${LL(s.id)}">Erledigt</button>`:''}</td></tr>`).join('')
        ||'<tr><td colspan="6">Keine Schritte.</td></tr>';
      body.querySelector('#ll-pout').innerHTML=
        (d.plan.reicht_die_zeit?`<div class="notice good">Die Zeit bis zum ${LL(d.plan.pruefungstermin)} reicht für den Plan.</div>`
          :`<div class="notice bad">Die Zeit bis zum ${LL(d.plan.pruefungstermin)} reicht bei ${LL(String(d.plan.wochenstunden))} Wochenstunden nicht. Bitte Termin oder Umfang anpassen.</div>`)
        +(d.ueberfaellig?`<div class="notice bad">${LL(String(d.ueberfaellig))} Schritt(e) überfällig.</div>`:'')
        +`<div style="overflow-x:auto"><table class="table"><caption>Schritte bis zum Prüfungstermin</caption><thead><tr><th scope="col">Schritt</th><th scope="col">Quelle</th><th scope="col">Fällig</th><th scope="col">Aufwand</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
        +`<p class="muted">Eine Lücke schließt der erneute Nachweis — nicht das Abhaken.</p>`;
      body.querySelectorAll('.ll-fertig').forEach(b=>b.onclick=async()=>{
        const bem=prompt('Kurze Bemerkung, wie nachgeholt wurde:')||'';
        try{await llApi(`/api/learning-plan-steps/${encodeURIComponent(b.dataset.id)}/done?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({bemerkung:bem})});await zeigePlan(planId);}
        catch(e){body.querySelector('#ll-perr').textContent=llText(e.message);}
      });
    }catch(e){body.querySelector('#ll-perr').textContent=llText(e.message);}
  }
}

(async()=>{
  let me=null;try{me=(await llApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const verwaltung=me.isPlatformAdmin||roles.some(x=>['tenant_admin','class_admin'].includes(x.role));
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(seite&&verwaltung){
      const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
      knopf('ll-laufbahn-launch','Laufbahn',()=>llLaufbahn(tenantId),anker,'nav');
      knopf('ll-lernplan-launch','Lernplanung',()=>llLernplan(tenantId,true),anker,'nav');
    }
    const portal=document.querySelector('.portal-main');
    if(portal&&!document.querySelector('#ll-portal-btn')){
      const b=document.createElement('button');b.id='ll-portal-btn';b.type='button';b.className='portal-btn secondary';b.textContent='Mein Lernplan';
      b.onclick=()=>llLernplan(tenantId,false).catch(e=>alert(llText(e.message)));
      (document.querySelector('#gs-portal-buttons')||portal).append(b);
    }
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

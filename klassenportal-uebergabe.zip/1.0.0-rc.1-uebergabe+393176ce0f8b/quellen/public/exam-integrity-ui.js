// Prüfungsrecht in der Oberfläche: Beweiskette, Notfallbetrieb, Täuschungsfall.
//
// Drei Sichten, drei Rechtsstellungen:
//  - Die Lehrkraft führt den Bogen durch seine Stationen und die Aufsicht durch die Unterbrechung.
//  - Die Leitung entsiegelt (mit Begründung) und entscheidet Täuschungsfälle.
//  - Die betroffene Person sieht den Vorwurf mit den Beweisen und nimmt Stellung. Ohne diese Seite
//    wäre die Anhörung eine Behauptung.
const PR=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const PR_STATIONEN={entwurf:'Entwurf',freigegeben:'freigegeben',versiegelt:'versiegelt',archiviert:'archiviert'};
const PR_VERDACHT=[['taeuschung','Täuschung'],['unerlaubtes_hilfsmittel','Unerlaubtes Hilfsmittel'],['identitaet','Identität'],['stoerung','Störung'],['plagiat','Plagiat']];
const PR_QUELLEN=[['sicherheitsereignis','Sicherheitsereignis des Browsers'],['aufsicht','Aufsicht'],['plagiatspruefung','Plagiatsprüfung'],['hinweis','Hinweis'],['nachkontrolle','Nachkontrolle']];
const PR_ENTSCHEIDUNGEN=[['kein_verstoss','Kein Verstoß – Vorgang einstellen'],['ermahnung','Ermahnung'],['teilbewertung','Teilbewertung'],['nicht_bestanden','Nicht bestanden'],['ausschluss','Ausschluss']];
const PR_ARTEN=[['netz','Netzausfall'],['strom','Stromausfall'],['technik','Technischer Defekt'],['raeumung','Räumung'],['gesundheit','Gesundheitlicher Zwischenfall'],['sonstiges','Sonstiges']];
async function prApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const prText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function prModal(titel,breite='min(940px,96vw)'){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="pr-titel" style="width:${breite};max-height:92vh;overflow:auto"><div class="top"><h3 id="pr-titel" style="margin:0">${PR(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="pr-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#pr-body'),zu};
}

// 1. Der Aufgabenbogen und seine Stationen.
async function prBoegen(tenantId,courseId){
  const {body}=prModal('Prüfungen: Freigabe, Siegel, Beweiskette');
  async function liste(){
    let d;
    try{d=await prApi(`/api/learning-suite/quizzes?tenant_id=${encodeURIComponent(tenantId)}&course_id=${encodeURIComponent(courseId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${PR(prText(e.message))}</div>`;return;}
    const zeilen=(d.quizzes||[]).map(q=>{
      const st=String(q.freigabe_status||'entwurf');
      const knoepfe=[st==='entwurf'?`<button class="btn secondary pr-frei" type="button" data-id="${PR(q.id)}">Freigeben</button>`:'',
        st==='freigegeben'?`<button class="btn pr-siegel" type="button" data-id="${PR(q.id)}">Versiegeln</button>`:'',
        st==='versiegelt'?`<button class="btn secondary pr-entsiegel" type="button" data-id="${PR(q.id)}">Entsiegeln</button>`:'',
        st==='versiegelt'?`<button class="btn secondary pr-arch" type="button" data-id="${PR(q.id)}">Archivieren</button>`:'',
        `<button class="btn secondary pr-kette" type="button" data-id="${PR(q.id)}">Beweiskette</button>`].filter(Boolean).join(' ');
      return `<tr><th scope="row">${PR(q.title)}</th><td>${PR(PR_STATIONEN[st]||st)}</td><td>${PR(q.versiegelt_am||'')}</td><td>${knoepfe}</td></tr>`;}).join('')
      ||'<tr><td colspan="4">Keine Prüfungen in diesem Kurs.</td></tr>';
    body.innerHTML=`<p class="muted">Ein versiegelter Bogen lässt sich nicht mehr ändern. Wer ändern muss, entsiegelt mit Begründung – und die bleibt dauerhaft in der Kette. Versiegeln muss eine <strong>zweite</strong> Person.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Aufgabenbögen und ihre Stationen</caption><thead><tr><th scope="col">Prüfung</th><th scope="col">Station</th><th scope="col">Versiegelt</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div><p class="error" id="pr-err" role="alert"></p><div id="pr-kette"></div>`;
    const ruf=async(pfad,id,daten)=>{
      try{await prApi(`/api/exams/${encodeURIComponent(id)}/${pfad}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(daten||{})});await liste();}
      catch(e){const k=body.querySelector('#pr-err');if(k)k.textContent=prText(e.message);}
    };
    body.querySelectorAll('.pr-frei').forEach(b=>b.onclick=()=>ruf('release',b.dataset.id,{}));
    body.querySelectorAll('.pr-siegel').forEach(b=>b.onclick=()=>ruf('seal',b.dataset.id,{}));
    body.querySelectorAll('.pr-arch').forEach(b=>b.onclick=()=>ruf('archive',b.dataset.id,{}));
    body.querySelectorAll('.pr-entsiegel').forEach(b=>b.onclick=()=>{
      const grund=prompt('Warum muss der versiegelte Bogen geöffnet werden? (mindestens 20 Zeichen; bleibt dauerhaft in der Beweiskette)');
      if(grund===null)return;ruf('unseal',b.dataset.id,{begruendung:grund});
    });
    body.querySelectorAll('.pr-kette').forEach(b=>b.onclick=()=>kette(b.dataset.id));
  }
  async function kette(quizId){
    const ziel=body.querySelector('#pr-kette');
    let d;try{d=await prApi(`/api/exams/${encodeURIComponent(quizId)}/custody?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){ziel.innerHTML=`<div class="notice bad">${PR(prText(e.message))}</div>`;return;}
    const zeilen=(d.ereignisse||[]).map(e=>`<tr><th scope="row">${PR(e.erfasst_am)}</th><td>${PR(e.ereignis)}</td><td>${PR(e.akteur_name)}</td><td>${PR(e.begruendung||'')}</td></tr>`).join('')
      ||'<tr><td colspan="4">Noch kein Eintrag.</td></tr>';
    ziel.innerHTML=`<h4>Beweiskette</h4>`
      +(d.bogen.papier_hash?`<div class="notice ${d.siegel.unveraendert?'':'bad'}">${d.siegel.unveraendert?'Der Bogen ist seit der Versiegelung unverändert.':'<strong>Der Bogen weicht vom versiegelten Stand ab.</strong> Eine Ausgabe wird abgelehnt.'}</div>`:'')
      +`<div style="overflow-x:auto"><table class="table"><caption>Stationen des Aufgabenbogens</caption><thead><tr><th scope="col">Zeitpunkt</th><th scope="col">Ereignis</th><th scope="col">Person</th><th scope="col">Begründung</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<form id="pr-einsicht"><label class="field">Einsicht protokollieren (Grund)<input name="begruendung" placeholder="Einsichtnahme der teilnehmenden Person"></label><div class="toolbar"><button class="btn secondary" type="submit">Einsicht festhalten</button></div></form>`;
    ziel.querySelector('#pr-einsicht').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await prApi(`/api/exams/${encodeURIComponent(quizId)}/inspection?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({begruendung:f.get('begruendung')})});await kette(quizId);}
      catch(e){ziel.innerHTML+=`<p class="error">${PR(prText(e.message))}</p>`;}
    };
  }
  await liste();
}

// 2. Notfallbetrieb während der Prüfung.
async function prNotfall(tenantId,courseId){
  const {body}=prModal('Prüfung: Unterbrechung und Wiederaufnahme');
  async function liste(){
    let d;
    try{d=await prApi(`/api/exam-interruptions/open?tenant_id=${encodeURIComponent(tenantId)}&course_id=${encodeURIComponent(courseId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${PR(prText(e.message))}</div>`;return;}
    const zeilen=(d.offen||[]).map(o=>`<tr><th scope="row">${PR(o.display_name)}</th><td>${PR(o.art)}</td><td>${PR(String(Math.round(Number(o.restsekunden)/60)))} min</td><td>${PR(o.unterbrochen_am)}</td><td><button class="btn pr-fort" type="button" data-id="${PR(o.attempt_id)}">Fortsetzen</button></td></tr>`).join('')
      ||'<tr><td colspan="5">Kein Versuch ist angehalten.</td></tr>';
    body.innerHTML=`<p class="muted">Beim Unterbrechen wird die Restzeit eingefroren. Beim Fortsetzen läuft genau diese Restzeit wieder – nicht die ursprüngliche Uhr.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Angehaltene Versuche</caption><thead><tr><th scope="col">Person</th><th scope="col">Grund</th><th scope="col">Restzeit</th><th scope="col">Seit</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<h4>Versuch anhalten</h4><form id="pr-unt"><div class="row"><label class="field">Versuchskennung<input name="attempt_id" required></label>`
      +`<label class="field">Grund<select name="art">${PR_ARTEN.map(a=>`<option value="${a[0]}">${a[1]}</option>`).join('')}</select></label></div>`
      +`<label class="field">Was ist passiert?<input name="begruendung" required minlength="10"></label>`
      +`<div class="toolbar"><button class="btn danger" type="submit">Anhalten</button></div><p class="error" id="pr-nerr" role="alert"></p></form>`;
    body.querySelector('#pr-unt').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await prApi(`/api/exam-attempts/${encodeURIComponent(f.get('attempt_id'))}/interrupt?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({art:f.get('art'),begruendung:f.get('begruendung')})});await liste();}
      catch(e){body.querySelector('#pr-nerr').textContent=prText(e.message);}
    };
    body.querySelectorAll('.pr-fort').forEach(b=>b.onclick=async()=>{
      try{const r=await prApi(`/api/exam-attempts/${encodeURIComponent(b.dataset.id)}/resume?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
        body.querySelector('#pr-nerr').textContent=`Fortgesetzt. Neue Frist: ${r.deadline_at}.`;await liste();}
      catch(e){body.querySelector('#pr-nerr').textContent=prText(e.message);}
    });
  }
  await liste();
}

// 3. Täuschungsfälle.
async function prIntegritaet(tenantId){
  const {body}=prModal('Prüfung: Täuschungsverfahren');
  async function liste(){
    let d;try{d=await prApi(`/api/exam-integrity?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${PR(prText(e.message))}</div>`;return;}
    const zeilen=(d.faelle||[]).map(f=>`<tr><th scope="row">${PR(f.created_at)}</th><td>${PR((PR_VERDACHT.find(v=>v[0]===f.verdacht)||[,f.verdacht])[1])}</td><td>${PR(f.status)}</td><td>${PR(f.anhoerung_frist_am||'')}</td><td><button class="btn secondary pr-fall" type="button" data-id="${PR(f.id)}">Öffnen</button></td></tr>`).join('')
      ||'<tr><td colspan="5">Kein offener Vorgang.</td></tr>';
    body.innerHTML=`<p class="muted">Ohne Anhörung keine Entscheidung. Eine Entscheidung ohne Stellungnahmegelegenheit fällt im Widerspruch – auch dann, wenn die Täuschung vorlag.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Offene Täuschungsverfahren</caption><thead><tr><th scope="col">Eröffnet</th><th scope="col">Verdacht</th><th scope="col">Stand</th><th scope="col">Frist</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<h4>Vorgang eröffnen</h4><form id="pr-int"><div class="row"><label class="field">Prüfung (Kennung)<input name="quiz_id" required></label>`
      +`<label class="field">Betroffene Person (Kennung)<input name="betroffene_person" required></label>`
      +`<label class="field">Versuch (Kennung, optional)<input name="attempt_id"></label></div><div class="row">`
      +`<label class="field">Verdacht<select name="verdacht">${PR_VERDACHT.map(v=>`<option value="${v[0]}">${v[1]}</option>`).join('')}</select></label>`
      +`<label class="field">Herkunft<select name="quelle">${PR_QUELLEN.map(q=>`<option value="${q[0]}">${q[1]}</option>`).join('')}</select></label></div>`
      +`<label class="field">Sachverhalt<textarea name="sachverhalt" rows="3" required minlength="20"></textarea></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Vorgang eröffnen</button></div><p class="error" id="pr-ierr" role="alert"></p></form><div id="pr-idetail"></div>`;
    body.querySelector('#pr-int').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await prApi(`/api/exam-integrity?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        quiz_id:f.get('quiz_id'),betroffene_person:f.get('betroffene_person'),attempt_id:f.get('attempt_id')||null,
        verdacht:f.get('verdacht'),quelle:f.get('quelle'),sachverhalt:f.get('sachverhalt')})});await liste();}
      catch(e){body.querySelector('#pr-ierr').textContent=prText(e.message);}
    };
    body.querySelectorAll('.pr-fall').forEach(b=>b.onclick=()=>detail(b.dataset.id));
  }
  async function detail(fid){
    const ziel=body.querySelector('#pr-idetail');
    let d;try{d=await prApi(`/api/exam-integrity/${encodeURIComponent(fid)}?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){ziel.innerHTML=`<div class="notice bad">${PR(prText(e.message))}</div>`;return;}
    const f=d.fall;
    let beweise=[];try{beweise=(JSON.parse(String(f.beweise_json||'{}')).sicherheitsereignisse)||[];}catch{beweise=[];}
    ziel.innerHTML=`<h4>Vorgang vom ${PR(f.created_at)}</h4><p>${PR(f.sachverhalt)}</p>`
      +`<p class="muted">Festgehaltene Beweise: ${PR(String(beweise.length))} Sicherheitsereignis(se)${f.anhoerung_frist_am?` · Frist zur Stellungnahme ${PR(f.anhoerung_frist_am)}`:''}</p>`
      +(f.stellungnahme?`<div class="notice"><strong>Stellungnahme der betroffenen Person:</strong> ${PR(f.stellungnahme)}</div>`:'')
      +(f.status==='offen'?`<div class="toolbar"><button class="btn" type="button" id="pr-anh">Zur Stellungnahme auffordern</button></div>`:'')
      +(f.status==='anhoerung'?`<form id="pr-ent"><div class="row"><label class="field">Entscheidung<select name="entscheidung">${PR_ENTSCHEIDUNGEN.map(e=>`<option value="${e[0]}">${e[1]}</option>`).join('')}</select></label></div>`
        +`<label class="field">Begründung<textarea name="begruendung" rows="3" required minlength="20"></textarea></label>`
        +`<div class="toolbar"><button class="btn" type="submit">Entscheiden</button></div></form>`:'')
      +(f.entscheidung?`<div class="notice"><strong>Entschieden:</strong> ${PR(f.entscheidung)} – ${PR(f.entscheidung_begruendung||'')}<br>Anhörung: ${PR(f.anhoerung_ergebnis||'')}</div>`:'')
      +`<p class="error" id="pr-derr" role="alert"></p>`;
    const anh=ziel.querySelector('#pr-anh');
    if(anh)anh.onclick=async()=>{
      try{await prApi(`/api/exam-integrity/${encodeURIComponent(fid)}/hearing?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({tage:7})});await liste();await detail(fid);}
      catch(e){ziel.querySelector('#pr-derr').textContent=prText(e.message);}
    };
    const ent=ziel.querySelector('#pr-ent');
    if(ent)ent.onsubmit=async ev=>{
      ev.preventDefault();const fd=new FormData(ev.target);
      try{await prApi(`/api/exam-integrity/${encodeURIComponent(fid)}/decision?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({entscheidung:fd.get('entscheidung'),begruendung:fd.get('begruendung')})});await liste();await detail(fid);}
      catch(e){ziel.querySelector('#pr-derr').textContent=prText(e.message);}
    };
  }
  await liste();
}

// 4. Die betroffene Person: Vorwurf lesen, Stellung nehmen.
async function prMeinFall(tenantId,fallId){
  const {body}=prModal('Prüfung: Stellungnahme');
  let d;
  try{d=await prApi(`/api/personal/exam-integrity/${encodeURIComponent(fallId)}?tenant_id=${encodeURIComponent(tenantId)}`);}
  catch(e){body.innerHTML=`<div class="notice bad">${PR(prText(e.message))}</div>`;return;}
  const f=d.fall;
  let beweise=[];try{beweise=(JSON.parse(String(f.beweise||'{}')).sicherheitsereignisse)||[];}catch{beweise=[];}
  body.innerHTML=`<p><strong>Vorwurf:</strong> ${PR((PR_VERDACHT.find(v=>v[0]===f.verdacht)||[,f.verdacht])[1])}</p><p>${PR(f.sachverhalt)}</p>`
    +`<h4>Worauf sich der Verdacht stützt</h4>`
    +(beweise.length?`<ul>${beweise.map(b=>`<li>${PR(b.created_at)} · ${PR(b.event_type)}${b.request_path?` (${PR(b.request_path)})`:''}</li>`).join('')}</ul>`:'<p class="muted">Keine technischen Ereignisse festgehalten.</p>')
    +(f.stellungnahme?`<div class="notice"><strong>Ihre Stellungnahme:</strong> ${PR(f.stellungnahme)}</div>`
      :f.status==='anhoerung'?`<form id="pr-st"><label class="field">Ihre Stellungnahme (bis ${PR(f.anhoerung_frist_am||'')})<textarea name="text" rows="5" required></textarea></label>`
        +`<div class="toolbar"><button class="btn" type="submit">Stellungnahme abgeben</button><button class="btn secondary" type="button" id="pr-verz">Auf Stellungnahme verzichten</button></div><p class="error" id="pr-serr" role="alert"></p></form>`
      :'<p class="muted">Zurzeit ist keine Stellungnahme möglich.</p>')
    +(f.entscheidung?`<div class="notice"><strong>Entscheidung:</strong> ${PR(f.entscheidung)} – ${PR(f.entscheidung_begruendung||'')}<br>Gegen diese Entscheidung können Sie Einspruch einlegen.</div>`:'');
  const form=body.querySelector('#pr-st');
  if(form){
    form.onsubmit=async ev=>{
      ev.preventDefault();const fd=new FormData(ev.target);
      try{await prApi(`/api/personal/exam-integrity/${encodeURIComponent(fallId)}/statement?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({text:fd.get('text')})});await prMeinFall(tenantId,fallId);}
      catch(e){body.querySelector('#pr-serr').textContent=prText(e.message);}
    };
    body.querySelector('#pr-verz').onclick=async()=>{
      try{await prApi(`/api/personal/exam-integrity/${encodeURIComponent(fallId)}/waive?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await prMeinFall(tenantId,fallId);}
      catch(e){body.querySelector('#pr-serr').textContent=prText(e.message);}
    };
  }
}

(async()=>{
  let me=null;try{me=(await prApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const lehrend=me.isPlatformAdmin||roles.some(x=>['tenant_admin','class_admin'].includes(x.role));
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const kursOf=()=>new URLSearchParams(location.search).get('course_id')||roles.find(x=>x.course_id)?.course_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(seite&&lehrend){
      const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
      knopf('pr-boegen-launch','Prüfungen: Siegel & Kette',()=>prBoegen(tenantId,kursOf()),anker,'nav');
      knopf('pr-notfall-launch','Prüfung: Notfallbetrieb',()=>prNotfall(tenantId,kursOf()),anker,'nav');
      knopf('pr-int-launch','Täuschungsverfahren',()=>prIntegritaet(tenantId),anker,'nav');
    }
    // Die betroffene Person kommt über die Benachrichtigung hierher; der Vorgang steht in der URL.
    const fall=new URLSearchParams(location.search).get('integrity_case');
    if(fall&&!document.querySelector('#pr-mein-marker')){
      const m=document.createElement('span');m.id='pr-mein-marker';m.hidden=true;document.body.append(m);
      prMeinFall(tenantId,fall).catch(e=>alert(prText(e.message)));
    }
    const portal=document.querySelector('.portal-main');
    if(portal&&!document.querySelector('#pr-portal-btn')){
      const b=document.createElement('button');b.id='pr-portal-btn';b.type='button';b.className='portal-btn secondary';b.textContent='Prüfungsvorgang: Stellungnahme';
      b.onclick=()=>{const k=prompt('Vorgangskennung aus der Benachrichtigung:');if(k)prMeinFall(tenantId,k).catch(e=>alert(prText(e.message)));};
      (document.querySelector('#gs-portal-buttons')||portal).append(b);
    }
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

// Der Rückweg einer Nachforderung.
//
// Vorher gab es ihn nicht: der Träger konnte fehlende Nachweise nur per privater E-Mail
// anfordern, und sie kamen dorthin zurück. Diese Seite ist das Gegenstück — sie lässt
// ausschließlich einreichen.
//
// Was sie bewusst NICHT kann: den Stand der Bewerbung zeigen. Ein Link, der das könnte, zeigte
// ihn jedem, an den er weitergeleitet wird. Angezeigt wird nur die Vorgangsnummer, damit der
// Einreichende sieht, dass er beim richtigen Vorgang ist.
const N=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const text=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
const app=document.querySelector('#nachreichen-app');
const token=(location.pathname.match(/^\/bewerbung\/nachreichen\/([A-Za-z0-9]+)/)||[])[1]||'';

function zeigeFehler(satz){
  app.innerHTML=`<div class="nr-karte"><h1>Unterlagen nachreichen</h1><p class="nr-fehler">${N(satz)}</p>`
    +`<p>Bitte prüfen Sie den Link. Wenn er aus einer E-Mail stammt, öffnen Sie ihn noch einmal vollständig. `
    +`Ist die Frist abgelaufen, wenden Sie sich bitte an die Stelle, die Ihnen geschrieben hat.</p></div>`;
}

async function laden(){
  if(!token)return zeigeFehler('Dieser Link ist unvollständig.');
  let vorgang;
  try{
    const r=await fetch(`/api/bewerbung/nachreichen/${encodeURIComponent(token)}`,{cache:'no-store'});
    const d=await r.json().catch(()=>({}));
    if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);
    vorgang=d;
  }catch(e){return zeigeFehler(text(e.message));}

  app.innerHTML=`<div class="nr-karte">
    <h1>Unterlagen nachreichen</h1>
    <p>Vorgangsnummer <span class="nr-nummer">${N(vorgang.reference)}</span></p>
    <p>Bitte laden Sie hier die angeforderten Unterlagen hoch. Über diesen Link können Sie ausschließlich einreichen — Ihre Bewerbung selbst ist darüber nicht einsehbar.</p>
    <form id="nr-form" novalidate>
      <label class="nr-feld"><span>Unterlagen</span>
        <input name="files" type="file" multiple required accept=".pdf,.png,.jpg,.jpeg,.webp,.docx,.odt,.txt">
        <small>Bis zu 8 Dateien, je höchstens 10 MB.</small>
      </label>
      <div class="setup-actions"><button class="btn" type="submit" id="nr-senden">Unterlagen senden</button></div>
      <p class="nr-fehler" id="nr-fehler" role="alert"></p>
    </form>
  </div>`;

  const formular=document.querySelector('#nr-form'),knopf=document.querySelector('#nr-senden');
  formular.onsubmit=async e=>{
    e.preventDefault();
    const melde=s=>{document.querySelector('#nr-fehler').textContent=s;};
    melde('');
    const dateien=formular.elements.files.files;
    if(!dateien||!dateien.length)return melde('Bitte wählen Sie mindestens eine Datei aus.');
    const fd=new FormData();
    for(const f of dateien)fd.append('files',f);
    knopf.disabled=true;knopf.textContent='Wird gesendet …';
    try{
      const r=await fetch(`/api/bewerbung/nachreichen/${encodeURIComponent(token)}`,{method:'POST',body:fd});
      const d=await r.json().catch(()=>({}));
      if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);
      app.innerHTML=`<div class="nr-fertig"><h1>Danke — angekommen.</h1>
        <p>${N(d.documents)} Datei(en) sind eingegangen.</p>
        <p>Vorgangsnummer <span class="nr-nummer">${N(d.reference)}</span></p>
        <p>Sie müssen nichts weiter tun. Dieser Link ist damit verbraucht.</p></div>`;
    }catch(err){
      knopf.disabled=false;knopf.textContent='Unterlagen senden';
      melde(text(err.message));
    }
  };
}
laden();

// Rahmenfassungen und Anerkennung von Vorleistungen.
//
// Eine veröffentlichte Fassung ist unveränderlich: ändert sich der Wortlaut eines Lernfelds, darf
// sich nicht rückwirkend ändern, wofür jemand vor zwei Jahren eine Note bekommen hat.
const FR=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const FR_ARTEN=[['schulabschluss','Schulabschluss'],['berufsausbildung','Berufsausbildung'],['berufserfahrung','Berufserfahrung'],['zertifikat','Zertifikat'],['hochschule','Hochschule'],['sonstiges','Sonstiges']];
async function frApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const frText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function frModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="fr-titel" style="width:min(940px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="fr-titel" style="margin:0">${FR(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="fr-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#fr-body'),zu};
}

async function frFassungen(tenantId){
  const {body}=frModal('Rahmenfassungen');
  body.innerHTML=`<p class="muted">Eine veröffentlichte Fassung wird eingefroren und gehasht. Ändern geht nur über eine neue Fassung — die alte bleibt, weil die Bewertungen von damals auf sie zeigen.</p>`
    +`<form id="fr-lade"><label class="field">Rahmenplan (Kennung)<input name="framework_id" required></label><div class="toolbar"><button class="btn" type="submit">Fassungen anzeigen</button></div><p class="error" id="fr-err" role="alert"></p></form><div id="fr-out"></div>`;
  body.querySelector('#fr-lade').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target),rahmen=String(f.get('framework_id'));
    await zeige(rahmen);
  };
  async function zeige(rahmen){
    try{
      const d=await frApi(`/api/frameworks/${encodeURIComponent(rahmen)}/versions?tenant_id=${encodeURIComponent(tenantId)}`);
      const zeilen=(d.fassungen||[]).map(v=>`<tr><th scope="row">${FR(String(v.fassung))}</th><td>${FR(v.bezeichnung)}</td><td>${FR(v.status)}</td><td>${FR(v.gueltig_ab||'')}</td><td>${FR(String(v.eintraege))}</td>`
        +`<td>${v.status==='entwurf'?`<button class="btn fr-pub" type="button" data-id="${FR(v.id)}">Veröffentlichen</button>`:`<button class="btn secondary fr-chk" type="button" data-id="${FR(v.id)}">Siegel prüfen</button>`}</td></tr>`).join('')
        ||'<tr><td colspan="6">Noch keine Fassung. Die erste hält den heutigen Stand fest.</td></tr>';
      body.querySelector('#fr-out').innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Fassungen dieses Rahmenplans</caption><thead><tr><th scope="col">Fassung</th><th scope="col">Bezeichnung</th><th scope="col">Stand</th><th scope="col">Gültig ab</th><th scope="col">Einträge</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
        +`<div class="toolbar"><button class="btn secondary" type="button" id="fr-neu">Neue Fassung aus heutigem Stand</button></div><p id="fr-info" class="muted"></p>`;
      body.querySelector('#fr-neu').onclick=async()=>{
        try{const r=await frApi(`/api/frameworks/${encodeURIComponent(rahmen)}/versions?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
          body.querySelector('#fr-info').textContent=`Entwurf ${r.fassung} angelegt, ${r.eintraege} Einträge festgehalten.`;await zeige(rahmen);}
        catch(e){body.querySelector('#fr-err').textContent=frText(e.message);}
      };
      body.querySelectorAll('.fr-pub').forEach(b=>b.onclick=async()=>{
        try{const r=await frApi(`/api/framework-versions/${encodeURIComponent(b.dataset.id)}/publish?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
          body.querySelector('#fr-info').textContent=`Fassung ${r.fassung} veröffentlicht und eingefroren.`;await zeige(rahmen);}
        catch(e){body.querySelector('#fr-err').textContent=frText(e.message);}
      });
      body.querySelectorAll('.fr-chk').forEach(b=>b.onclick=async()=>{
        try{const r=await frApi(`/api/framework-versions/${encodeURIComponent(b.dataset.id)}/verify?tenant_id=${encodeURIComponent(tenantId)}`);
          body.querySelector('#fr-info').textContent=r.unveraendert?'Die Fassung ist seit der Veröffentlichung unverändert.':'ACHTUNG: Die Fassung weicht vom eingefrorenen Stand ab.';}
        catch(e){body.querySelector('#fr-err').textContent=frText(e.message);}
      });
    }catch(e){body.querySelector('#fr-err').textContent=frText(e.message);}
  }
}

// Vorleistungen: beantragen (alle) und entscheiden (Verwaltung).
async function frVorleistungen(tenantId,alsVerwaltung){
  const {body}=frModal(alsVerwaltung?'Vorleistungen: Anträge entscheiden':'Vorleistung anerkennen lassen');
  async function render(){
    const pfad=alsVerwaltung?`/api/prior-learning?tenant_id=${encodeURIComponent(tenantId)}`:`/api/personal/prior-learning?tenant_id=${encodeURIComponent(tenantId)}`;
    let d;try{d=await frApi(pfad);}catch(e){body.innerHTML=`<div class="notice bad">${FR(frText(e.message))}</div>`;return;}
    const zeilen=(d.antraege||[]).map(x=>`<tr><th scope="row">${FR(x.beantragt_am)}</th><td>${FR((FR_ARTEN.find(a=>a[0]===x.art)||[,x.art])[1])}</td>`
      +(alsVerwaltung?`<td>${FR(x.display_name||x.user_id)}</td>`:'')
      +`<td>${FR(x.status)}</td><td>${FR(x.entscheidung_begruendung||'')}</td>`
      +(alsVerwaltung?`<td><button class="btn secondary fr-ent" type="button" data-id="${FR(x.id)}">Entscheiden</button></td>`:`<td>${['offen','in_pruefung'].includes(String(x.status))?`<button class="btn secondary fr-zur" type="button" data-id="${FR(x.id)}">Zurückziehen</button>`:''}</td>`)
      +`</tr>`).join('')||`<tr><td colspan="${alsVerwaltung?6:5}">Kein Antrag.</td></tr>`;
    body.innerHTML=`<p class="muted">Die Anerkennung ist ein Verwaltungsakt: sie braucht eine begründete Entscheidung — auch bei Ablehnung — und im Zeugnis bleibt erkennbar, was geprüft und was anerkannt wurde.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Anträge auf Anerkennung</caption><thead><tr><th scope="col">Eingereicht</th><th scope="col">Art</th>${alsVerwaltung?'<th scope="col">Person</th>':''}<th scope="col">Stand</th><th scope="col">Begründung</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +(alsVerwaltung?'<div id="fr-ent-form"></div>'
        :`<h4>Neuer Antrag</h4><form id="fr-neu-antrag"><div class="row"><label class="field">Art<select name="art">${FR_ARTEN.map(a=>`<option value="${a[0]}">${a[1]}</option>`).join('')}</select></label>`
         +`<label class="field">Ausstellende Stelle<input name="externe_stelle"></label></div>`
         +`<label class="field">Was haben Sie erworben?<textarea name="beschreibung" rows="4" required minlength="20"></textarea></label>`
         +`<div class="toolbar"><button class="btn" type="submit">Antrag stellen</button></div></form>`)
      +`<p class="error" id="fr-verr" role="alert"></p>`;
    const neu=body.querySelector('#fr-neu-antrag');
    if(neu)neu.onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await frApi(`/api/prior-learning?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(Object.fromEntries(f.entries()))});await render();}
      catch(e){body.querySelector('#fr-verr').textContent=frText(e.message);}
    };
    body.querySelectorAll('.fr-zur').forEach(b=>b.onclick=async()=>{
      try{await frApi(`/api/personal/prior-learning/${encodeURIComponent(b.dataset.id)}/withdraw?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await render();}
      catch(e){body.querySelector('#fr-verr').textContent=frText(e.message);}
    });
    body.querySelectorAll('.fr-ent').forEach(b=>b.onclick=async()=>{
      let d2;try{d2=await frApi(`/api/prior-learning/${encodeURIComponent(b.dataset.id)}?tenant_id=${encodeURIComponent(tenantId)}`);}
      catch(e){body.querySelector('#fr-verr').textContent=frText(e.message);return;}
      body.querySelector('#fr-ent-form').innerHTML=`<h4>Antrag vom ${FR(d2.antrag.beantragt_am)}</h4><p>${FR(d2.antrag.beschreibung)}</p>`
        +`<form id="fr-ent-f"><div class="row"><label class="field">Entscheidung<select name="entscheidung"><option value="anerkannt">Anerkannt</option><option value="teilweise">Teilweise anerkannt</option><option value="abgelehnt">Abgelehnt</option></select></label>`
        +`<label class="field">Anrechnungen (Art:Kennung:Prozent, mit Komma getrennt)<input name="anrechnungen" placeholder="lernfeld:lf1:100, kompetenz:k2:50"></label></div>`
        +`<label class="field">Begründung<textarea name="begruendung" rows="3" required minlength="20"></textarea></label>`
        +`<div class="toolbar"><button class="btn" type="submit">Entscheiden</button></div></form>`;
      body.querySelector('#fr-ent-f').onsubmit=async ev=>{
        ev.preventDefault();const f=new FormData(ev.target);
        const roh=String(f.get('anrechnungen')||'').split(',').map(x=>x.trim()).filter(Boolean);
        const anrechnungen=roh.map(x=>{const [art,bezug,prozent]=x.split(':');return{art,bezug_id:bezug,umfang_prozent:Number(prozent||100)};});
        try{await frApi(`/api/prior-learning/${encodeURIComponent(b.dataset.id)}/decision?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
          body:JSON.stringify({entscheidung:f.get('entscheidung'),begruendung:f.get('begruendung'),anrechnungen})});await render();}
        catch(e){body.querySelector('#fr-verr').textContent=frText(e.message);}
      };
    });
  }
  await render();
}

(async()=>{
  let me=null;try{me=(await frApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const verwaltung=me.isPlatformAdmin||roles.some(x=>['tenant_admin','class_admin'].includes(x.role));
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(seite&&verwaltung){
      const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
      knopf('fr-fassungen-launch','Rahmenfassungen',()=>frFassungen(tenantId),anker,'nav');
      knopf('fr-vorleistung-launch','Vorleistungen',()=>frVorleistungen(tenantId,true),anker,'nav');
    }
    const portal=document.querySelector('.portal-main');
    if(portal&&!document.querySelector('#fr-portal-btn')){
      const b=document.createElement('button');b.id='fr-portal-btn';b.type='button';b.className='portal-btn secondary';b.textContent='Vorleistung anerkennen lassen';
      b.onclick=()=>frVorleistungen(tenantId,false).catch(e=>alert(frText(e.message)));
      (document.querySelector('#gs-portal-buttons')||portal).append(b);
    }
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

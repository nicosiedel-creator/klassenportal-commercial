// Das öffentliche Bewerbungsformular.
//
// Diese Seite ist der einzige Weg, auf dem ein Mensch von außen eine Bewerbung abgeben kann.
// Vorher gab es nur die JSON-Schnittstelle: der Träger konnte ein Formular veröffentlichen,
// und niemand konnte es ausfüllen.
//
// Zwei Eigenschaften sind hier wichtiger als das Aussehen:
//   - Die Seite verrät nichts über den Träger. Sie zeigt genau das, was die Schnittstelle
//     ausgibt — Titel, Einleitung, ob Unterlagen verlangt sind. Kein Kurs, kein Mandant,
//     keine Zahl bisheriger Bewerbungen.
//   - Die Vorgangsnummer erscheint genau einmal, nach dem Absenden. Es gibt bewusst keinen
//     Weg, mit ihr später den Stand abzufragen: das wäre eine unauthentifizierte Abfrage
//     auf Bewerberdaten.
const B=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const text=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
const app=document.querySelector('#bewerbung-app');
const schluessel=decodeURIComponent((location.pathname.match(/^\/bewerbung\/([^/]+)/)||[])[1]||'');

function zeigeFehler(satz){
  app.innerHTML=`<div class="bew-karte"><h1>Bewerbung</h1><p class="bew-fehler">${B(satz)}</p>`
    +`<p>Bitte prüfen Sie den Link. Wenn er aus einer E-Mail stammt, öffnen Sie ihn noch einmal vollständig.</p></div>`;
}

async function laden(){
  if(!schluessel)return zeigeFehler('Dieser Link ist unvollständig.');
  let form;
  try{
    const r=await fetch(`/api/bewerbung/${encodeURIComponent(schluessel)}`,{cache:'no-store'});
    const d=await r.json().catch(()=>({}));
    if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);
    form=d;
  }catch(e){return zeigeFehler(text(e.message));}

  const arten=(form.accepted_file_types||[]).join(', ');
  app.innerHTML=`<div class="bew-karte">
    <h1>${B(form.title||'Bewerbung')}</h1>
    ${form.intro?`<p>${B(form.intro)}</p>`:''}
    <form id="bew-form" novalidate>
      <label class="bew-feld"><span class="bew-pflicht">Name</span><input name="name" autocomplete="name" required maxlength="200"></label>
      <label class="bew-feld"><span>E-Mail</span><input name="email" type="email" autocomplete="email" maxlength="200"></label>
      <label class="bew-feld"><span>Geburtsdatum</span><input name="birth_date" type="date"></label>
      <p class="bew-hinweis">Bitte geben Sie <strong>E-Mail oder Geburtsdatum</strong> an — mindestens eines von beiden, damit Ihre Bewerbung zugeordnet werden kann.</p>
      <label class="bew-feld"><span>Telefon</span><input name="phone" autocomplete="tel" maxlength="60"></label>
      <label class="bew-feld"><span>Nachricht</span><textarea name="note" rows="4" maxlength="2000"></textarea></label>
      ${form.documents_required||form.max_documents?`<label class="bew-feld">
        <span${form.documents_required?' class="bew-pflicht"':''}>Unterlagen</span>
        <input name="files" type="file" multiple accept="${B(arten)}">
        <small>Bis zu ${B(form.max_documents)} Dateien, je höchstens ${B(form.max_document_mb)} MB. Erlaubt: ${B(arten)}.</small>
      </label>`:''}
      <div class="setup-actions"><button class="btn" type="submit" id="bew-senden">Bewerbung absenden</button></div>
      <p class="bew-fehler" id="bew-fehler" role="alert"></p>
    </form>
  </div>`;

  const formular=document.querySelector('#bew-form'),knopf=document.querySelector('#bew-senden');
  formular.onsubmit=async e=>{
    e.preventDefault();
    const melde=s=>{document.querySelector('#bew-fehler').textContent=s;};
    melde('');
    const fd=new FormData(formular);
    // Der Browser schickt ein leeres Dateifeld als leere Datei mit. Das wäre für den Server
    // eine abgelehnte Anlage — deshalb wird es hier entfernt, wenn nichts gewählt wurde.
    const dateien=(formular.querySelector('input[type=file]')?.files)||[];
    fd.delete('files');
    for(const f of dateien)fd.append('files',f);
    if(!String(fd.get('name')||'').trim())return melde(text('ADMISSION_NAME_REQUIRED'));
    if(!String(fd.get('email')||'').trim()&&!String(fd.get('birth_date')||'').trim())
      return melde(text('ADMISSION_CONTACT_REQUIRED'));
    knopf.disabled=true;knopf.textContent='Wird gesendet …';
    try{
      const r=await fetch(`/api/bewerbung/${encodeURIComponent(schluessel)}`,{method:'POST',body:fd});
      const d=await r.json().catch(()=>({}));
      if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);
      app.innerHTML=`<div class="bew-fertig">
        <h1>Bewerbung eingegangen</h1>
        <p>Ihre Vorgangsnummer:</p>
        <p class="bew-nummer">${B(d.reference)}</p>
        <p>Bitte notieren Sie sie. Sie wird Ihnen hier nur einmal angezeigt.</p>
        <p>Die Einrichtung meldet sich bei Ihnen.</p>
      </div>`;
      window.scrollTo(0,0);
    }catch(err){
      melde(text(err.message));
      knopf.disabled=false;knopf.textContent='Bewerbung absenden';
    }
  };
}
laden();

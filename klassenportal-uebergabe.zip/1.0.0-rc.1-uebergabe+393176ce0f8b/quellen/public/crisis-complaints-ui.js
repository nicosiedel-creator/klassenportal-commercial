// Krise und Beschwerde in der Oberfläche.
//
// Zwei Dinge, die im Ernstfall zählen und sich deshalb nicht hinter Menüs verstecken dürfen:
// die Lage auslösen (Leitung) und die Meldung bestätigen (alle). Dazu der Ausfallkanal — die
// Telefonliste derer, die nicht bestätigt haben.
const KB=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const KB_STUFEN=[['info','Information'],['warnung','Warnung'],['gefahr','Gefahr']];
const KB_KATEGORIEN=[['unterricht','Unterricht'],['organisation','Organisation'],['verhalten','Verhalten'],['abrechnung','Abrechnung'],['barrierefreiheit','Barrierefreiheit'],['datenschutz','Datenschutz'],['sonstiges','Sonstiges']];
async function kbApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const kbText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function kbModal(titel,breite='min(900px,96vw)'){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="kb-titel" style="width:${breite};max-height:92vh;overflow:auto"><div class="top"><h3 id="kb-titel" style="margin:0">${KB(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="kb-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#kb-body'),zu};
}

// 1. Leitung: Lage auslösen, Stand verfolgen, Entwarnung geben.
async function kbKrisen(tenantId){
  const {body}=kbModal('Krisenkommunikation');
  async function liste(){
    let d;try{d=await kbApi(`/api/crisis/alerts?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${KB(kbText(e.message))}</div>`;return;}
    const zeilen=(d.lagen||[]).map(l=>`<tr><th scope="row">${KB(l.titel)}</th><td>${KB((KB_STUFEN.find(s=>s[0]===l.stufe)||[,l.stufe])[1])}</td><td>${KB(l.ausgeloest_am)}</td><td>${KB(String(l.bestaetigt))} / ${KB(String(l.gesamt))}</td><td>${l.beendet_am?'beendet':'läuft'}</td><td><button class="btn secondary kb-stand" type="button" data-id="${KB(l.id)}">Stand</button></td></tr>`).join('')
      ||'<tr><td colspan="6">Keine Lage ausgelöst.</td></tr>';
    body.innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Ausgelöste Lagen</caption><thead><tr><th scope="col">Titel</th><th scope="col">Stufe</th><th scope="col">Ausgelöst</th><th scope="col">Bestätigt</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<h4>Neue Lage auslösen</h4><form id="kb-neu"><div class="row">`
      +`<label class="field">Titel<input name="titel" required></label>`
      +`<label class="field">Stufe<select name="stufe">${KB_STUFEN.map(s=>`<option value="${s[0]}"${s[0]==='warnung'?' selected':''}>${s[1]}</option>`).join('')}</select></label></div>`
      +`<label class="field">Meldung<textarea name="text" rows="4" required minlength="10"></textarea></label>`
      +`<label class="field">Ausfallkanal – wo nachsehen, wenn das Portal nicht erreichbar ist?<input name="ausfallkanal" required minlength="10" placeholder="Telefon 0123 456789, Aushang am Haupteingang"></label>`
      +`<div class="toolbar"><button class="btn danger" type="submit">Lage auslösen</button></div><p class="error" id="kb-err" role="alert"></p></form><div id="kb-stand"></div>`;
    body.querySelector('#kb-neu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{const r=await kbApi(`/api/crisis/alerts?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({titel:f.get('titel'),text:f.get('text'),stufe:f.get('stufe'),ausfallkanal:f.get('ausfallkanal')})});
        body.querySelector('#kb-err').textContent=`Ausgelöst. ${r.empfaenger} Personen wurden benachrichtigt.`;await liste();}
      catch(e){body.querySelector('#kb-err').textContent=kbText(e.message);}
    };
    body.querySelectorAll('.kb-stand').forEach(b=>b.onclick=()=>stand(b.dataset.id));
  }
  async function stand(alertId){
    const ziel=body.querySelector('#kb-stand');
    let d;try{d=await kbApi(`/api/crisis/alerts/${encodeURIComponent(alertId)}?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){ziel.innerHTML=`<div class="notice bad">${KB(kbText(e.message))}</div>`;return;}
    const offen=(d.offen||[]).map(o=>`<tr><th scope="row">${KB(o.display_name)}</th><td>${KB(o.grund)}</td><td>${o.telefon?KB(o.telefon):'<span class="muted">keine Nummer hinterlegt</span>'}</td><td>${KB(String(o.erinnerungen))}</td></tr>`).join('')
      ||'<tr><td colspan="4">Alle haben bestätigt.</td></tr>';
    ziel.innerHTML=`<h4>Stand: ${KB(String(d.bestaetigt))} von ${KB(String(d.gesamt))} bestätigt</h4>`
      +`<p class="muted">Ausfallkanal dieser Lage: ${KB(d.lage.ausfallkanal)}${d.ohne_telefon?` · <strong>${KB(String(d.ohne_telefon))}</strong> ohne hinterlegte Nummer`:''}</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Noch nicht bestätigt – Liste zum Abtelefonieren</caption><thead><tr><th scope="col">Person</th><th scope="col">Grund</th><th scope="col">Telefon</th><th scope="col">Erinnerungen</th></tr></thead><tbody>${offen}</tbody></table></div>`
      +(d.lage.beendet_am?`<p class="notice">Entwarnung am ${KB(d.lage.beendet_am)}: ${KB(d.lage.entwarnung||'')}</p>`
        :`<form id="kb-ende"><label class="field">Entwarnung<textarea name="entwarnung" rows="3" required minlength="10"></textarea></label><div class="toolbar"><button class="btn" type="submit">Entwarnung geben</button></div><p class="error" id="kb-eerr" role="alert"></p></form>`);
    const form=ziel.querySelector('#kb-ende');
    if(form)form.onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await kbApi(`/api/crisis/alerts/${encodeURIComponent(alertId)}/all-clear?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({entwarnung:f.get('entwarnung')})});await liste();}
      catch(e){ziel.querySelector('#kb-eerr').textContent=kbText(e.message);}
    };
  }
  await liste();
}

// 2. Alle: eigene Meldungen bestätigen und die Notfallnummer pflegen.
async function kbMeineLagen(tenantId){
  const {body}=kbModal('Meldungen und Notfallnummer');
  async function render(){
    let d;try{d=await kbApi(`/api/crisis/my-alerts?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${KB(kbText(e.message))}</div>`;return;}
    const zeilen=(d.lagen||[]).map(l=>`<div class="notice ${l.stufe==='gefahr'?'bad':''}"><strong>${KB(l.titel)}</strong><div>${KB(l.text)}</div>`
      +`<div class="muted">Wenn das Portal nicht erreichbar ist: ${KB(l.ausfallkanal)}</div>`
      +(l.beendet_am?`<div><strong>Entwarnung:</strong> ${KB(l.entwarnung||'')}</div>`
        :l.bestaetigt_am?`<div class="muted">Bestätigt am ${KB(l.bestaetigt_am)}</div>`
        :`<div class="toolbar"><button class="btn kb-ok" type="button" data-id="${KB(l.id)}">Gelesen und verstanden</button></div>`)+`</div>`).join('')
      ||'<p class="muted">Keine Meldungen.</p>';
    body.innerHTML=zeilen
      +`<h4>Notfallnummer</h4><p class="muted">Wird nur benutzt, wenn eine Lage läuft und Sie nicht bestätigt haben. Sonst sieht sie niemand.</p>`
      +`<form id="kb-tel"><label class="field">Telefonnummer<input name="telefon" required minlength="5"></label><div class="toolbar"><button class="btn secondary" type="submit">Speichern</button></div><p class="error" id="kb-terr" role="alert"></p></form>`;
    body.querySelectorAll('.kb-ok').forEach(b=>b.onclick=async()=>{
      try{await kbApi(`/api/crisis/alerts/${encodeURIComponent(b.dataset.id)}/confirm?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await render();}
      catch(e){alert(kbText(e.message));}
    });
    body.querySelector('#kb-tel').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await kbApi(`/api/crisis/emergency-contact?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({telefon:f.get('telefon')})});
        body.querySelector('#kb-terr').textContent='Gespeichert.';}
      catch(e){body.querySelector('#kb-terr').textContent=kbText(e.message);}
    };
  }
  await render();
}

// 3. Beschwerde einreichen - mit Namen oder anonym.
async function kbBeschwerdeEinreichen(tenantId){
  const {body}=kbModal('Beschwerde einreichen');
  body.innerHTML=`<p class="muted">Eine Beschwerde wird innerhalb von 14 Tagen beantwortet. Anonym geht auch – dann bekommen Sie einen Vorgangsschlüssel, mit dem Sie den Stand abfragen können.</p>`
    +`<form id="kb-bsw"><div class="row"><label class="field">Kategorie<select name="kategorie" required>${KB_KATEGORIEN.map(k=>`<option value="${k[0]}">${k[1]}</option>`).join('')}</select></label>`
    +`<label class="field">Betreff<input name="betreff" required></label></div>`
    +`<label class="field">Was ist vorgefallen?<textarea name="text" rows="5" required minlength="20"></textarea></label>`
    +`<label class="field inline"><input type="checkbox" name="anonym"> Anonym einreichen</label>`
    +`<div class="toolbar"><button class="btn" type="submit">Einreichen</button></div><p class="error" id="kb-berr" role="alert"></p></form>`
    +`<h4>Vorgang abfragen</h4><form id="kb-key"><label class="field">Vorgangsschlüssel<input name="vorgangsschluessel" required></label><div class="toolbar"><button class="btn secondary" type="submit">Stand abfragen</button></div></form><div id="kb-keyout"></div>`
    +`<h4>Meine Beschwerden</h4><div id="kb-mine">Lädt …</div>`;
  async function eigene(){
    try{const d=await kbApi(`/api/complaints/mine?tenant_id=${encodeURIComponent(tenantId)}`);
      const zeilen=(d.beschwerden||[]).map(b=>`<tr><th scope="row">${KB(b.created_at)}</th><td>${KB(b.betreff)}</td><td>${KB(b.status)}</td><td>${KB(b.frist_am)}</td><td>${KB(b.antwort||'')}</td></tr>`).join('');
      document.querySelector('#kb-mine').innerHTML=zeilen?`<div style="overflow-x:auto"><table class="table"><caption>Eigene Beschwerden</caption><thead><tr><th scope="col">Eingereicht</th><th scope="col">Betreff</th><th scope="col">Stand</th><th scope="col">Frist</th><th scope="col">Antwort</th></tr></thead><tbody>${zeilen}</tbody></table></div>`:'<p class="muted">Keine.</p>';
    }catch(e){document.querySelector('#kb-mine').innerHTML=`<p class="muted">${KB(kbText(e.message))}</p>`;}
  }
  await eigene();
  body.querySelector('#kb-bsw').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target);
    try{const r=await kbApi(`/api/complaints?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({kategorie:f.get('kategorie'),betreff:f.get('betreff'),text:f.get('text'),anonym:f.get('anonym')==='on'})});
      ev.target.reset();
      body.querySelector('#kb-berr').textContent=r.vorgangsschluessel
        ? `Eingegangen. Ihr Vorgangsschlüssel: ${r.vorgangsschluessel} — bitte notieren, er lässt sich nicht wiederherstellen. Antwort bis ${r.frist_am}.`
        : `Eingegangen. Antwort bis ${r.frist_am}.`;
      await eigene();}
    catch(e){body.querySelector('#kb-berr').textContent=kbText(e.message);}
  };
  body.querySelector('#kb-key').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target);
    try{const r=await kbApi(`/api/complaints/by-key?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({vorgangsschluessel:f.get('vorgangsschluessel')})});
      document.querySelector('#kb-keyout').innerHTML=`<div class="notice"><strong>${KB(r.vorgang.betreff)}</strong> · Stand ${KB(r.vorgang.status)} · Frist ${KB(r.vorgang.frist_am)}${r.vorgang.antwort?`<div><strong>Antwort:</strong> ${KB(r.vorgang.antwort)}</div>`:''}</div>`;}
    catch(e){document.querySelector('#kb-keyout').innerHTML=`<div class="notice bad">${KB(kbText(e.message))}</div>`;}
  };
}

// 4. Leitung: Beschwerden bearbeiten.
async function kbBeschwerden(tenantId){
  const {body}=kbModal('Beschwerden');
  async function liste(){
    let d;try{d=await kbApi(`/api/complaints?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${KB(kbText(e.message))}</div>`;return;}
    const zeilen=(d.beschwerden||[]).map(b=>`<tr><th scope="row">${KB(b.created_at)}</th><td>${KB(b.betreff)}</td><td>${KB(b.kategorie)}</td><td>${b.eingereicht_von?'mit Namen':'anonym'}</td><td>${KB(b.frist_am)}</td><td>${KB(b.status)}</td><td><button class="btn secondary kb-open" type="button" data-id="${KB(b.id)}">Öffnen</button></td></tr>`).join('')
      ||'<tr><td colspan="7">Keine offenen Beschwerden.</td></tr>';
    body.innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Offene Beschwerden</caption><thead><tr><th scope="col">Eingegangen</th><th scope="col">Betreff</th><th scope="col">Kategorie</th><th scope="col">Herkunft</th><th scope="col">Frist</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div><div id="kb-bdetail"></div>`;
    body.querySelectorAll('.kb-open').forEach(b=>b.onclick=()=>detail(b.dataset.id));
  }
  async function detail(cid){
    const ziel=body.querySelector('#kb-bdetail');
    let d;try{d=await kbApi(`/api/complaints/${encodeURIComponent(cid)}?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){ziel.innerHTML=`<div class="notice bad">${KB(kbText(e.message))}</div>`;return;}
    const verlauf=(d.verlauf||[]).map(n=>`<li>${KB(n.erfasst_am)} · ${KB(n.art)}${Number(n.fuer_einreicher)===1?' (sichtbar für die einreichende Person)':''}: ${KB(n.text)}</li>`).join('')||'<li>Noch kein Eintrag.</li>';
    ziel.innerHTML=`<h4>${KB(d.vorgang.betreff)}</h4><p>${KB(d.vorgang.text)}</p><p class="muted">Frist ${KB(d.vorgang.frist_am)} · Stand ${KB(d.vorgang.status)}</p><ul>${verlauf}</ul>`
      +`<form id="kb-bstatus"><div class="row"><label class="field">Bearbeitungsstand<select name="status"><option value="in_bearbeitung">In Bearbeitung</option><option value="eskaliert">Eskaliert</option><option value="beantwortet">Beantwortet</option><option value="abgeschlossen">Abgeschlossen</option></select></label>`
      +`<label class="field">Stelle (bei Eskalation)<input name="eskaliert_an"></label></div>`
      +`<label class="field">Text (Antwort bzw. Begründung)<textarea name="text" rows="4"></textarea></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Speichern</button></div><p class="error" id="kb-bderr" role="alert"></p></form>`;
    ziel.querySelector('#kb-bstatus').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await kbApi(`/api/complaints/${encodeURIComponent(cid)}/status?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({status:f.get('status'),text:f.get('text'),eskaliert_an:f.get('eskaliert_an')})});await liste();}
      catch(e){ziel.querySelector('#kb-bderr').textContent=kbText(e.message);}
    };
  }
  await liste();
}

(async()=>{
  let me=null;try{me=(await kbApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const leitung=me.isPlatformAdmin||roles.some(x=>x.role==='tenant_admin');
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(seite){
      const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
      if(leitung){
        knopf('kb-krisen-launch','Krisenkommunikation',()=>kbKrisen(tenantId),anker,'nav');
        knopf('kb-bsw-launch','Beschwerden',()=>kbBeschwerden(tenantId),anker,'nav');
      }
      knopf('kb-meine-launch','Meldungen bestätigen',()=>kbMeineLagen(tenantId),anker,'nav');
      knopf('kb-bsw-neu-launch','Beschwerde einreichen',()=>kbBeschwerdeEinreichen(tenantId),anker,'nav');
    }
    const portal=document.querySelector('.portal-main');
    if(portal&&!document.querySelector('#kb-portal-krise')){
      const halter=document.querySelector('#gs-portal-buttons')||portal;
      const a=document.createElement('button');a.id='kb-portal-krise';a.type='button';a.className='portal-btn secondary';a.textContent='Meldungen bestätigen';
      a.onclick=()=>kbMeineLagen(tenantId).catch(e=>alert(kbText(e.message)));
      const b=document.createElement('button');b.id='kb-portal-bsw';b.type='button';b.className='portal-btn secondary';b.textContent='Beschwerde einreichen';
      b.onclick=()=>kbBeschwerdeEinreichen(tenantId).catch(e=>alert(kbText(e.message)));
      halter.append(a,b);
    }
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

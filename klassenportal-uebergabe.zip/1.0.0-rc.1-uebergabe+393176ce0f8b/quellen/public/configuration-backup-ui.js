// Konfigurationssicherung in der Oberfläche.
//
// Die Daten eines Mandanten waren exportierbar, seine Einstellungen nicht. Nach einem Wiederanlauf
// stünden Teilnehmer und Noten wieder da - aber Branding, Fristen, Vorlagen und Anbindungen wären
// weg. Diese Maske schließt das, und zwar mit Simulation vor dem Einspielen: ohne sie ist eine
// Wiederherstellung ein Sprung ins Dunkle.
const CB=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function cbApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const cbText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;

async function cbOeffnen(tenantId){
  const w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" style="width:min(820px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 style="margin:0">Konfiguration sichern und wiederherstellen</h3><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div id="cb-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>w.remove();w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  const body=w.querySelector('#cb-body');
  let geladen=null;

  async function zeichne(){
    let d;try{d=await cbApi(`/api/tenant/configuration/export?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(err){body.innerHTML=`<div class="notice bad">${CB(cbText(err.message))}</div>`;return;}
    const k=d.configuration,tabellen=Object.entries(k.tabellen||{});
    const zeilenGesamt=tabellen.reduce((a,[,z])=>a+z.length,0);
    body.innerHTML=`<p class="muted">Gesichert werden die Einstellungen dieses Kundenbereichs: Branding, Fristen, Vorlagen, Skalen, Planungsgrenzen und Anbindungen. <strong>Zugangsgeheimnisse gehen bewusst nicht mit</strong> – die Sicherung vermerkt nur, dass eines hinterlegt war, damit beim Wiederanlauf auffällt, was noch fehlt.</p>`
      +`<div class="row"><span class="pill">${CB(tabellen.length)} Bereiche</span> <span class="pill">${CB(zeilenGesamt)} Einträge</span> <span class="pill">Prüfsumme ${CB(String(k.pruefsumme).slice(0,12))}</span></div>`
      +`<div class="row"><button class="btn" id="cb-down">Sicherung herunterladen</button><label class="btn secondary" for="cb-file" style="cursor:pointer">Sicherung auswählen …</label><input id="cb-file" type="file" accept="application/json" style="display:none"></div>`
      +((k.ausgelassene_geheimnisse||[]).length?`<div class="notice"><strong>Nach dem Wiederanlauf neu zu hinterlegen:</strong><ul>${(k.ausgelassene_geheimnisse||[]).map(g=>`<li>${CB(g.tabelle)}.${CB(g.spalte)}</li>`).join('')}</ul></div>`:'')
      +`<h4>Inhalt</h4>`+tabellen.map(([n,z])=>`<div class="item"><strong>${CB(n)}</strong> <span class="muted">${CB(z.length)} Einträge</span></div>`).join('')
      +`<div id="cb-plan"></div>`;
    body.querySelector('#cb-down').onclick=()=>{
      // Der Browser lädt die Datei aus dem Speicher - sie war schon da, es geht nichts erneut über die Leitung.
      const blob=new Blob([JSON.stringify(k,null,2)],{type:'application/json'});
      const a=document.createElement('a');a.href=URL.createObjectURL(blob);
      a.download=`klassenportal-konfiguration-${tenantId}-${String(k.erzeugt_am).slice(0,10)}.json`;
      document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),2000);
    };
    body.querySelector('#cb-file').onchange=async e=>{
      const datei=e.currentTarget.files?.[0];if(!datei)return;
      try{geladen=JSON.parse(await datei.text());}catch{return alert('Die Datei ließ sich nicht lesen.');}
      await simulieren();
    };
  }

  async function simulieren(){
    const kasten=body.querySelector('#cb-plan');
    kasten.innerHTML='Prüft …';
    let d;try{d=await cbApi(`/api/tenant/configuration/plan?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({configuration:geladen})});}
    catch(err){kasten.innerHTML=`<div class="notice bad">${CB(cbText(err.message))}</div>`;return;}
    const ersetzt=(d.plan||[]).filter(p=>p.wird_ersetzt),nurAnsicht=(d.plan||[]).filter(p=>!p.wird_ersetzt);
    kasten.innerHTML=`<h4>Was passieren würde</h4>`
      +((d.fehler||[]).length?`<div class="notice bad"><ul>${(d.fehler||[]).map(f=>`<li>${CB(f)}</li>`).join('')}</ul></div>`:'')
      +(ersetzt.length?`<div class="table-wrap"><table><thead><tr><th scope="col">Bereich</th><th scope="col">heute</th><th scope="col">aus der Sicherung</th></tr></thead><tbody>`
        +ersetzt.map(p=>`<tr><td>${CB(p.tabelle)}${p.fehlende_spalten.length?`<div class="muted">nicht in der Sicherung: ${CB(p.fehlende_spalten.join(', '))}</div>`:''}</td><td>${CB(p.vorhanden)}</td><td>${CB(p.in_sicherung)}</td></tr>`).join('')
        +`</tbody></table></div>`:'<p class="muted">Nichts einzuspielen.</p>')
      +(nurAnsicht.length?`<p class="muted"><strong>Nicht zurückgeschrieben:</strong> ${CB(nurAnsicht.map(p=>p.tabelle).join(', '))} – diesen Umfang vergibt die Plattform, nicht der Kundenbereich. Er steht in der Sicherung, damit nachvollziehbar bleibt, was galt.</p>`:'')
      +((d.geheimnisse||[]).length?`<p class="muted"><strong>Danach neu zu hinterlegen:</strong> ${CB((d.geheimnisse||[]).join(', '))}</p>`:'')
      +((d.fehler||[]).length?'':`<button class="btn" id="cb-go">Konfiguration jetzt wiederherstellen</button>`);
    const knopf=kasten.querySelector('#cb-go');
    if(knopf)knopf.onclick=async()=>{
      if(!confirm(`Die aktuellen Einstellungen in ${ersetzt.length} Bereichen werden durch die Sicherung ersetzt. Fortfahren?`))return;
      try{const r=await cbApi(`/api/tenant/configuration/restore?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({configuration:geladen})});
        alert(`Wiederhergestellt: ${r.tabellen} Bereiche, ${r.zeilen} Einträge.${r.geheimnisse_fehlen?` ${r.geheimnisse_fehlen} Zugangsgeheimnis(se) müssen neu hinterlegt werden.`:''}`);
        geladen=null;await zeichne();
      }catch(err){alert(cbText(err.message));}
    };
  }
  await zeichne();
}

(async()=>{
  let me=null;try{me=(await cbApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  if(!me.isPlatformAdmin&&!roles.some(x=>x.role==='tenant_admin'))return;
  function mount(){
    const seite=document.querySelector('.side');if(!seite||document.querySelector('#cb-launch'))return;
    const tenantId=document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
    if(!tenantId)return;
    const anker=seite.querySelector('[data-v="branding"]')||seite.querySelector('[data-v="overview"]');if(!anker)return;
    const b=document.createElement('button');b.id='cb-launch';b.className='nav';b.textContent='Konfiguration sichern';
    b.onclick=()=>cbOeffnen(document.querySelector('#tenantPick')?.value||tenantId).catch(e=>alert(cbText(e.message)));
    anker.after(b);
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

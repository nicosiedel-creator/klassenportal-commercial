// Löschsperre, Aufbewahrungsfristen und Einwilligungen in der Oberfläche.
//
// Gelöscht werden konnte bisher; gesperrt nicht. Eine turnusmäßige Frist, die mitten in einem
// laufenden Verfahren zuschlägt, löscht genau die Unterlagen weg, um die gestritten wird.
const CP=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function cpApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const cpText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
const CP_UMFANG={mandant:'ganzer Kundenbereich',person:'eine Person',kurs:'ein Kurs',vorgang:'ein Vorgang'};
const CP_GRUND={rechtsstreit:'Rechtsstreit',behoerde:'Behördenanfrage',pruefungsanfechtung:'Prüfungsanfechtung',ermittlung:'Ermittlung',sonstiges:'Sonstiges'};
const CP_MASSNAHME={loeschen:'löschen',anonymisieren:'anonymisieren',archivieren:'archivieren'};

async function cpOeffnen(tenantId){
  const w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" style="width:min(900px,97vw);max-height:93vh;overflow:auto"><div class="top"><div><h3 style="margin:0">Aufbewahrung, Löschsperren & Einwilligungen</h3><div class="muted">Eine aktive Sperre schlägt jede Frist – ohne Ausnahme.</div></div><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div class="row"><button class="btn secondary cp-tab" data-t="sperren">Löschsperren</button><button class="btn secondary cp-tab" data-t="fristen">Aufbewahrungsfristen</button><button class="btn secondary cp-tab" data-t="einwilligungen">Einwilligungen</button><button class="btn secondary cp-tab" data-t="support">Supportzugriff</button><button class="btn secondary cp-tab" data-t="vorfaelle">Datenschutzvorfälle</button><button class="btn secondary cp-tab" data-t="protokoll">Revisionsprotokoll</button></div><div id="cp-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>w.remove();w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  const body=w.querySelector('#cp-body');
  w.querySelectorAll('.cp-tab').forEach(b=>b.onclick=()=>zeichne(b.dataset.t));
  const fehler=(err)=>{const k=body.querySelector('#cp-err');const t=cpText(err.message);if(k)k.innerHTML=`<div class="notice bad">${CP(t)}</div>`;else alert(t);};

  async function sperren(){
    const d=await cpApi(`/api/compliance/legal-holds?tenant_id=${encodeURIComponent(tenantId)}`);
    const rows=d.holds||[];
    body.innerHTML=`<p class="muted">Eine Löschsperre hält die turnusmäßige Löschung an, solange ein Verfahren läuft. Sie greift in das Löschrecht der betroffenen Person ein – deshalb braucht sie eine Begründung, und ihre Aufhebung ebenso.</p>`
      +`<form id="cp-neu"><div class="row"><label class="field">Umfang<select name="umfang">${Object.entries(CP_UMFANG).map(([k,v])=>`<option value="${CP(k)}">${CP(v)}</option>`).join('')}</select></label>`
      +`<label class="field">Kennung (bei Person, Kurs oder Vorgang)<input name="bezug_id"></label></div>`
      +`<div class="row"><label class="field">Grund<select name="grund">${Object.entries(CP_GRUND).map(([k,v])=>`<option value="${CP(k)}">${CP(v)}</option>`).join('')}</select></label>`
      +`<label class="field">Aktenzeichen<input name="aktenzeichen"></label></div>`
      +`<label class="field">Begründung<textarea name="beschreibung" rows="2" required minlength="20"></textarea></label>`
      +`<button class="btn">Sperre verhängen</button></form><div id="cp-err"></div>`
      +(rows.length?rows.map(h=>`<div class="item"><strong>${CP(CP_GRUND[h.grund]||h.grund)}</strong> <span class="pill">${h.status==='aktiv'?'aktiv':'aufgehoben'}</span>`
        +`<div class="muted">${CP(CP_UMFANG[h.umfang]||h.umfang)}${h.bezug_id?` · ${CP(h.bezug_id)}`:''}${h.aktenzeichen?` · ${CP(h.aktenzeichen)}`:''} · verhängt ${CP(String(h.verhaengt_am).slice(0,10))} von ${CP(h.verhaengt_name)}</div>`
        +`<div>${CP(h.beschreibung)}</div>`
        +(h.aufhebungsgrund?`<div class="muted">Aufgehoben ${CP(String(h.aufgehoben_am).slice(0,10))}: ${CP(h.aufhebungsgrund)}</div>`:'')
        +(h.status==='aktiv'?` <button class="btn secondary cp-auf" data-id="${CP(h.id)}">Aufheben</button>`:'')
        +`</div>`).join(''):'<p class="muted">Keine Löschsperre eingetragen.</p>');
    body.querySelector('#cp-neu').onsubmit=async e=>{e.preventDefault();const f=Object.fromEntries(new FormData(e.currentTarget));
      try{await cpApi(`/api/compliance/legal-holds?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(f)});await sperren();}catch(err){fehler(err);}};
    body.querySelectorAll('.cp-auf').forEach(b=>b.onclick=async()=>{
      const grund=prompt('Warum wird die Sperre aufgehoben? Danach darf wieder gelöscht werden.\n\n(mindestens ein vollständiger Satz)','');
      if(!grund)return;
      try{await cpApi(`/api/compliance/legal-holds/${encodeURIComponent(b.dataset.id)}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'DELETE',body:JSON.stringify({grund})});await sperren();}catch(err){alert(cpText(err.message));}});
  }

  async function fristen(){
    const d=await cpApi(`/api/compliance/retention?tenant_id=${encodeURIComponent(tenantId)}`);
    const rows=d.policies||[];
    body.innerHTML=`<p class="muted">Wie lange welche Daten aufbewahrt werden – und was danach geschieht. „Anonymisieren" ist oft richtiger als „löschen": die Statistik bleibt, der Personenbezug fällt weg. Die Vorgabewerte folgen den üblichen deutschen Fristen und ersetzen keine Prüfung für Ihren Fall.</p>`
      +(rows.length?`<div class="table-wrap"><table><thead><tr><th scope="col">Datenart</th><th scope="col">Monate</th><th scope="col">danach</th><th scope="col">Rechtsgrundlage</th></tr></thead><tbody>`
        +rows.map(r=>`<tr><td>${CP(r.datenart)}</td><td><input class="cp-monate" data-art="${CP(r.datenart)}" aria-label="Aufbewahrung in Monaten für ${CP(r.datenart)}" type="number" min="1" max="1200" value="${CP(r.aufbewahrung_monate)}" style="width:6rem"></td><td><select class="cp-massnahme" data-art="${CP(r.datenart)}" aria-label="Maßnahme nach Fristablauf für ${CP(r.datenart)}">${Object.entries(CP_MASSNAHME).map(([k,v])=>`<option value="${CP(k)}" ${r.massnahme===k?'selected':''}>${CP(v)}</option>`).join('')}</select></td><td class="muted">${CP(r.rechtsgrundlage||'')}</td></tr>`).join('')
        +`</tbody></table></div><button class="btn" id="cp-speichern">Fristen speichern</button>`
        :`<p class="muted">Noch keine Fristen hinterlegt.</p><button class="btn" id="cp-seed">Vorgabewerte anlegen</button>`)
      +`<div id="cp-err"></div>`;
    const seed=body.querySelector('#cp-seed');
    if(seed)seed.onclick=async()=>{try{await cpApi(`/api/compliance/retention/seed?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await fristen();}catch(err){fehler(err);}};
    const sp=body.querySelector('#cp-speichern');
    if(sp)sp.onclick=async()=>{
      try{
        for(const feld of body.querySelectorAll('.cp-monate')){
          const art=feld.dataset.art;
          const massnahme=body.querySelector(`.cp-massnahme[data-art="${CSS.escape(art)}"]`)?.value||'loeschen';
          const alt=rows.find(r=>r.datenart===art);
          if(alt&&Number(alt.aufbewahrung_monate)===Number(feld.value)&&alt.massnahme===massnahme)continue;
          await cpApi(`/api/compliance/retention?tenant_id=${encodeURIComponent(tenantId)}`,{method:'PUT',body:JSON.stringify({datenart:art,aufbewahrung_monate:Number(feld.value),massnahme,rechtsgrundlage:alt?.rechtsgrundlage||null})});
        }
        await fristen();
      }catch(err){fehler(err);}};
  }

  async function einwilligungen(){
    body.innerHTML=`<p class="muted">Eine Einwilligung ohne Fassung ist wertlos: ändert sich der Text, ist unklar, wozu die Person zugestimmt hat. Jede Textänderung erzeugt deshalb eine neue Fassung, und eine vorher erteilte Zustimmung gilt für den neuen Text <strong>nicht</strong>.</p>`
      +`<form id="cp-einw"><div class="row"><label class="field">Schlüssel<input name="schluessel" required placeholder="fotos"></label><label class="field">Titel<input name="titel" required placeholder="Fotos im Portal"></label></div>`
      +`<label class="field">Zweck<input name="zweck" required placeholder="Veröffentlichung von Kursfotos im internen Portal"></label>`
      +`<label class="field">Text der Einwilligung<textarea name="text" rows="3" required></textarea></label>`
      +`<div class="row"><label style="align-self:end"><input type="checkbox" name="pflicht"> Pflicht (ohne sie keine Teilnahme)</label>`
      +`<label style="align-self:end"><input type="checkbox" name="sorgeberechtigt_noetig"> muss von Sorgeberechtigten erklärt werden</label>`
      +`<label class="field">Gültig für Monate<input name="gueltig_monate" type="number" min="1" max="1200"></label></div>`
      +`<button class="btn">Einwilligung anlegen oder neu fassen</button></form><div id="cp-err"></div>`
      +`<p class="muted">Die erteilten Erklärungen sehen Sie in der Teilnehmerakte; die betroffene Person sieht sie in ihrem Portal.</p>`;
    body.querySelector('#cp-einw').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget);
      try{
        await cpApi(`/api/compliance/consents?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
          schluessel:f.get('schluessel'),titel:f.get('titel'),zweck:f.get('zweck'),text:f.get('text'),
          pflicht:e.currentTarget.pflicht.checked,sorgeberechtigt_noetig:e.currentTarget.sorgeberechtigt_noetig.checked,
          gueltig_monate:f.get('gueltig_monate')?Number(f.get('gueltig_monate')):null})});
        await einwilligungen();
        alert('Einwilligung gespeichert. Eine Textänderung erzeugt eine neue Fassung – vorher erteilte Zustimmungen tragen sie nicht.');
      }catch(err){fehler(err);}};
  }

  // Supportzugriff: befristet, zweckgebunden, widerrufbar - und ohne Freigabe geschlossen.
  //
  // Vorher war "Support sieht nur zu" ein Zustand der Oberflaeche. Hier erteilt ihn der Traeger
  // selbst, sieht jede Freigabe und jeden einzelnen Zugriff darunter.
  async function supportzugriff(){
    const d=await cpApi(`/api/tenant/support-access?tenant_id=${encodeURIComponent(tenantId)}`);
    const grants=(d.grants||[]).map(g=>`<tr><th scope="row">${CP(g.support_name||g.support_user_id)}</th><td>${CP(g.zweck)}</td><td>${CP(g.gueltig_bis)}</td><td>${g.notfall?'Notfall':'regulär'}</td><td>${CP(g.status)}</td><td>${g.status==='aktiv'?`<button class="btn secondary cp-rev" type="button" data-id="${CP(g.id)}">Widerrufen</button>`:''}</td></tr>`).join('')
      ||'<tr><td colspan="6">Keine Freigabe erteilt. Ohne Freigabe kommt der Support nicht an Ihre Daten.</td></tr>';
    const events=(d.events||[]).slice(0,50).map(e=>`<tr><th scope="row">${CP(e.erfasst_am)}</th><td>${CP(e.art)}</td><td>${CP(e.methode)}</td><td>${CP(e.pfad)}</td><td>${CP(e.grund||'')}</td></tr>`).join('')
      ||'<tr><td colspan="5">Noch kein Zugriff protokolliert.</td></tr>';
    body.innerHTML=`<div id="cp-err"></div>`
      +`<p class="muted">Eine Freigabe gilt höchstens 72 Stunden, erlaubt nur das Lesen und lässt sich jederzeit widerrufen. Jeder Zugriff und jeder abgewiesene Versuch steht unten.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Erteilte Freigaben</caption><thead><tr><th scope="col">Supportkonto</th><th scope="col">Zweck</th><th scope="col">Gültig bis</th><th scope="col">Art</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${grants}</tbody></table></div>`
      +`<h4>Neue Freigabe</h4><form id="cp-sag"><div class="row">`
      +`<label class="field">Supportkonto (Kennung)<input name="support_user_id" required></label>`
      +`<label class="field">Zweck<input name="zweck" required minlength="10" placeholder="Fehlersuche Ticket 4711"></label>`
      +`<label class="field">Dauer in Stunden<input name="stunden" type="number" min="1" max="72" value="24"></label>`
      +`</div><div class="toolbar"><button class="btn" type="submit">Freigabe erteilen</button></div></form>`
      +`<h4>Zugriffsprotokoll</h4><div style="overflow-x:auto"><table class="table"><caption>Zugriffe und abgewiesene Versuche</caption><thead><tr><th scope="col">Zeitpunkt</th><th scope="col">Art</th><th scope="col">Methode</th><th scope="col">Weg</th><th scope="col">Grund</th></tr></thead><tbody>${events}</tbody></table></div>`;
    body.querySelector('#cp-sag').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await cpApi(`/api/tenant/support-access?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({support_user_id:f.get('support_user_id'),zweck:f.get('zweck'),stunden:Number(f.get('stunden')||24)})});await zeichne('support');}
      catch(err){fehler(err);}
    };
    body.querySelectorAll('.cp-rev').forEach(b=>b.onclick=async()=>{
      try{await cpApi(`/api/tenant/support-access/${encodeURIComponent(b.dataset.id)}/revoke?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({grund:'Vom Träger widerrufen'})});await zeichne('support');}
      catch(err){fehler(err);}
    });
  }

  // Datenschutzvorfall: Erkennung, Bewertung, Meldung, Nachweis.
  //
  // Die 72 Stunden laufen ab dem Moment, in dem jemand im Haus davon weiß — nicht ab der Erfassung
  // hier. Deshalb fragt das Formular genau danach.
  const CP_VORFALLARTEN=[['fehlversand','Fehlversand (falscher Empfänger)'],['unbefugter_zugriff','Unbefugter Zugriff'],['verlust','Verlust von Gerät oder Unterlagen'],['offenlegung','Unbeabsichtigte Offenlegung'],['schadsoftware','Schadsoftware'],['ausfall','Ausfall / Nichtverfügbarkeit'],['sonstiges','Sonstiges']];
  async function vorfaelle(){
    const d=await cpApi(`/api/privacy-incidents?tenant_id=${encodeURIComponent(tenantId)}`);
    const zeilen=(d.vorfaelle||[]).map(v=>{
      const ueberfaellig=!v.gemeldet_behoerde_am&&v.status!=='abgeschlossen'&&Date.parse(v.frist_behoerde_am)<Date.now();
      return `<tr><th scope="row">${CP(v.entdeckt_am)}</th><td>${CP((CP_VORFALLARTEN.find(a=>a[0]===v.art)||[,v.art])[1])}</td><td>${CP(v.risiko)}</td>`
        +`<td>${v.gemeldet_behoerde_am?CP(v.gemeldet_behoerde_am):(Number(v.meldepflicht_behoerde)===1?`<strong>${ueberfaellig?'überfällig':'offen'}</strong>`:'nicht meldepflichtig')}</td>`
        +`<td>${CP(v.status)}</td><td><button class="btn secondary cp-vf" type="button" data-id="${CP(v.id)}">Öffnen</button></td></tr>`;}).join('')
      ||'<tr><td colspan="6">Kein Vorfall erfasst.</td></tr>';
    body.innerHTML=`<div id="cp-err"></div>`
      +`<p class="muted">Das Verzeichnis nach Artikel 33 Absatz 5 führt <strong>jeden</strong> Vorfall – auch die, die nicht gemeldet werden mussten. Genau das will die Aufsicht sehen.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Verzeichnis der Datenschutzvorfälle</caption><thead><tr><th scope="col">Bekannt seit</th><th scope="col">Art</th><th scope="col">Risiko</th><th scope="col">Behörde</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<h4>Vorfall melden</h4><form id="cp-vfneu"><div class="row">`
      +`<label class="field">Art<select name="art" required>${CP_VORFALLARTEN.map(a=>`<option value="${a[0]}">${a[1]}</option>`).join('')}</select></label>`
      +`<label class="field">Seit wann bekannt?<input name="entdeckt_am" type="datetime-local" required></label>`
      +`<label class="field">Betroffene (Anzahl, falls bekannt)<input name="betroffene_anzahl" type="number" min="0"></label></div>`
      +`<label class="field">Was ist passiert?<textarea name="beschreibung" rows="4" required minlength="20"></textarea></label>`
      +`<label class="field">Betroffene Datenkategorien<input name="betroffene_kategorien" placeholder="Namen, Anschriften, Noten"></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Vorfall erfassen</button></div></form><div id="cp-vfdetail"></div>`;
    body.querySelector('#cp-vfneu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      const roh=String(f.get('entdeckt_am')||'');
      try{const r=await cpApi(`/api/privacy-incidents?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        art:f.get('art'),beschreibung:f.get('beschreibung'),entdeckt_am:roh?new Date(roh).toISOString():undefined,
        betroffene_kategorien:f.get('betroffene_kategorien'),betroffene_anzahl:f.get('betroffene_anzahl')||null})});
        await zeichne('vorfaelle');
        body.querySelector('#cp-err').innerHTML=`<div class="notice">Erfasst. Meldefrist an die Aufsichtsbehörde: <strong>${CP(r.frist_behoerde_am)}</strong>.</div>`;}
      catch(err){fehler(err);}
    };
    body.querySelectorAll('.cp-vf').forEach(b=>b.onclick=()=>vorfallDetail(b.dataset.id));
  }
  async function vorfallDetail(vid){
    const ziel=body.querySelector('#cp-vfdetail');
    let d;try{d=await cpApi(`/api/privacy-incidents/${encodeURIComponent(vid)}?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(err){ziel.innerHTML=`<div class="notice bad">${CP(cpText(err.message))}</div>`;return;}
    const v=d.vorfall;
    const verlauf=(d.verlauf||[]).map(n=>`<li>${CP(n.erfasst_am)} · ${CP(n.art)}: ${CP(n.text)}</li>`).join('')||'<li>Noch kein Eintrag.</li>';
    ziel.innerHTML=`<h4>Vorfall vom ${CP(v.entdeckt_am)}</h4><p>${CP(v.beschreibung)}</p>`
      +`<p class="muted">Frist an die Behörde: ${CP(v.frist_behoerde_am)}${v.gemeldet_behoerde_am?` · gemeldet am ${CP(v.gemeldet_behoerde_am)}`:''}</p><ul>${verlauf}</ul>`
      +(v.risiko==='offen'
        ?`<form id="cp-vfbew"><h5>Bewerten</h5><div class="row"><label class="field">Risiko für die betroffenen Personen<select name="risiko"><option value="gering">gering – keine Meldepflicht</option><option value="hoch">hoch – Behörde und Betroffene</option></select></label></div>`
         +`<label class="field">Begründung<textarea name="begruendung" rows="3" required minlength="20"></textarea></label>`
         +`<div class="toolbar"><button class="btn" type="submit">Bewertung festhalten</button></div></form>`
        :`<p><strong>Risiko ${CP(v.risiko)}:</strong> ${CP(v.risikobegruendung||'')}</p>`)
      +(Number(v.meldepflicht_behoerde)===1&&!v.gemeldet_behoerde_am
        ?`<form id="cp-vfmeld"><h5>Meldung an die Aufsichtsbehörde</h5><div class="row"><label class="field">Behörde<input name="behoerde" required></label>`
         +`<label class="field">Aktenzeichen<input name="aktenzeichen"></label></div>`
         +`<label class="field">Begründung, falls nach 72 Stunden<textarea name="verzoegerungsgrund" rows="2"></textarea></label>`
         +`<div class="toolbar"><button class="btn" type="submit">Meldung festhalten</button></div></form>`:'')
      +(Number(v.meldepflicht_betroffene)===1&&!v.betroffene_informiert_am
        ?`<form id="cp-vfinfo"><h5>Betroffene informieren</h5><label class="field">Text der Information<textarea name="text" rows="3" required minlength="50"></textarea></label><div class="toolbar"><button class="btn secondary" type="submit">Information festhalten</button></div></form>`:'')
      +(v.status!=='abgeschlossen'
        ?`<form id="cp-vfzu"><h5>Abschließen</h5><label class="field">Maßnahmen – was wurde getan, was verhindert die Wiederholung?<textarea name="massnahmen" rows="3" required minlength="20"></textarea></label><div class="toolbar"><button class="btn secondary" type="submit">Vorfall abschließen</button></div></form>`
        :`<p class="notice">Abgeschlossen am ${CP(v.abgeschlossen_am)}: ${CP(v.massnahmen||'')}</p>`)
      +`<p class="error" id="cp-vferr" role="alert"></p>`;
    const sende=(sel,pfad,daten)=>{const f=ziel.querySelector(sel);if(f)f.onsubmit=async ev=>{
      ev.preventDefault();
      try{await cpApi(`/api/privacy-incidents/${encodeURIComponent(vid)}/${pfad}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(daten(new FormData(ev.target)))});await zeichne('vorfaelle');}
      catch(err){const k=ziel.querySelector('#cp-vferr');if(k)k.textContent=cpText(err.message);else fehler(err);}
    };};
    sende('#cp-vfbew','assessment',f=>({risiko:f.get('risiko'),begruendung:f.get('begruendung')}));
    sende('#cp-vfmeld','authority-report',f=>({behoerde:f.get('behoerde'),aktenzeichen:f.get('aktenzeichen'),verzoegerungsgrund:f.get('verzoegerungsgrund')}));
    sende('#cp-vfinfo','inform-subjects',f=>({text:f.get('text')}));
    sende('#cp-vfzu','close',f=>({massnahmen:f.get('massnahmen')}));
  }

  // Revisionsprotokoll: der Nachweis, dass nichts nachträglich geändert wurde.
  //
  // Die Kette selbst gab es schon; geprüft hat sie nie jemand. Eine Kette, der niemand nachläuft,
  // ist kein Nachweis – sie verhindert keine Fälschung, sie macht sie sichtbar, und sichtbar wird
  // sie erst beim Nachrechnen. Deshalb dieser Knopf und der tägliche Lauf dahinter.
  const CP_BRUCH={zeile_geaendert:'Eintrag verändert',zeile_geloescht:'Eintrag entfernt',zeile_eingefuegt:'Eintrag eingeschoben',kopf_weicht_ab:'Ende der Kette weicht ab',siegel_gebrochen:'Gesiegelter Stand nicht mehr auffindbar'};
  function cpPruefung(p){
    if(!p)return '<p class="muted">Diese Kette wurde noch nicht geprüft.</p>';
    const wann=CP(new Date(p.geprueft_am).toLocaleString('de-DE'));
    if(p.gueltig)return `<div class="notice ok">Geprüft am ${wann}: Die Einträge ${CP(p.ab)} bis ${CP(p.bis_position)} sind unverändert.</div>`;
    return `<div class="notice bad"><strong>${CP(CP_BRUCH[p.bruch_art]||'Bruch')} an Position ${CP(p.bruch_position)}</strong><div>${CP(p.hinweis||'')}</div><div class="muted">Geprüft am ${wann}.</div></div>`;
  }
  async function protokoll(){
    const d=await cpApi(`/api/compliance/audit-chain?tenant_id=${encodeURIComponent(tenantId)}`);
    const st=d.stand;
    body.innerHTML=`<div id="cp-err"></div>`
      +`<p class="muted">Jeder protokollierte Vorgang trägt die Prüfsumme seines Vorgängers. Wird ein Eintrag nachträglich geändert, entfernt oder eingeschoben, passt die Rechnung nicht mehr – und die Prüfung nennt die erste Stelle, an der eingegriffen wurde. <strong>Anhängen</strong> kann weiterhin, wer Schreibrecht hat; geschützt ist die Vergangenheit.</p>`
      +(st?`<div class="table-wrap"><table><caption>Stand der Kette</caption><thead><tr><th scope="col">Einträge</th><th scope="col">Letzter Eintrag</th><th scope="col">Siegel</th><th scope="col">Zuletzt gesiegelt</th></tr></thead><tbody>`
          +`<tr><td>${CP(st.position)}</td><td>${CP(new Date(st.aktualisiert_am).toLocaleString('de-DE'))}</td><td>${CP(st.siegel)}</td><td>${st.letztes_siegel?CP(new Date(st.letztes_siegel).toLocaleString('de-DE')):'<span class="muted">noch nie</span>'}</td></tr>`
          +`</tbody></table></div>`
        :'<p class="muted">Für diesen Kundenbereich ist noch kein Vorgang protokolliert.</p>')
      +cpPruefung(d.pruefung)
      +`<p class="muted">Das Siegel hält einen Kopfstand fest. Ohne es bliebe ein vollständiger Neuaufbau der Tabelle unentdeckt: er ergäbe eine in sich schlüssige, nur kürzere Kette. Der tägliche Lauf siegelt automatisch – aber nur, was er vorher als heil erkannt hat.</p>`
      +`<div class="toolbar"><button class="btn" type="button" id="cp-pruefen">Jetzt prüfen</button> <button class="btn secondary" type="button" id="cp-siegeln">Stand siegeln</button></div>`;
    const knopf=body.querySelector('#cp-pruefen');
    if(knopf)knopf.onclick=async()=>{
      knopf.disabled=true;knopf.textContent='Prüft …';
      try{await cpApi(`/api/compliance/audit-chain/verify?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({ab:1,limit:500})});await zeichne('protokoll');}
      catch(err){knopf.disabled=false;knopf.textContent='Jetzt prüfen';fehler(err);}
    };
    const siegel=body.querySelector('#cp-siegeln');
    if(siegel)siegel.onclick=async()=>{
      try{await cpApi(`/api/compliance/audit-chain/seal?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await zeichne('protokoll');}
      catch(err){await zeichne('protokoll');fehler(err);}
    };
  }

  async function zeichne(t){body.innerHTML='Lädt …';try{if(t==='fristen')await fristen();else if(t==='einwilligungen')await einwilligungen();else if(t==='support')await supportzugriff();else if(t==='vorfaelle')await vorfaelle();else if(t==='protokoll')await protokoll();else await sperren();}catch(err){body.innerHTML=`<div class="notice bad">${CP(cpText(err.message))}</div>`;}}
  await zeichne('sperren');
}

(async()=>{
  let me=null;try{me=(await cpApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  if(!me.isPlatformAdmin&&!roles.some(x=>x.role==='tenant_admin'))return;
  function mount(){
    const seite=document.querySelector('.side');if(!seite||document.querySelector('#cp-launch'))return;
    const tenantId=document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
    if(!tenantId)return;
    const anker=seite.querySelector('[data-v="data"]')||seite.querySelector('[data-v="overview"]');if(!anker)return;
    const b=document.createElement('button');b.id='cp-launch';b.className='nav';b.textContent='Aufbewahrung & Einwilligungen';
    b.onclick=()=>cpOeffnen(document.querySelector('#tenantPick')?.value||tenantId).catch(e=>alert(cpText(e.message)));
    anker.after(b);
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

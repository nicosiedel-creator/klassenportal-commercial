// Betrieb: KURSNET, Zulassung, Klassenbuchregeln und Berichte.
//
// Auch hier war alles gebaut, geprüft und über die API erreichbar - und ohne Knopf. Der
// KURSNET-Export etwa: ein Träger, der seine Kurse bei der Bundesagentur listen lassen will,
// hätte den Katalog nur mit einem eigenen Programm abrufen können.
const OPS_PATH=['/kunden-admin','/klassen-admin'].includes(location.pathname.replace(/\/$/,''));
if(OPS_PATH){
  const E=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const text=x=>(window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(x):String(x?.message||x))||String(x?.message||x||'');
  let navBusy=false;
  async function api(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{'content-type':'application/json',...(opt.headers||{})}});let d={};try{d=await r.json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
  function tid(){return document.querySelector('#tenantPick')?.value||'';}
  const q=(pfad,extra={})=>{const u=new URLSearchParams({tenant_id:tid(),...extra});return `${pfad}?${u}`;};
  function modal(title,body,width='1050px'){const w=document.createElement('div');w.className='modal-back';w.innerHTML=`<div class="modal" style="width:min(${width},96vw);max-height:92vh;overflow:auto"><div class="top"><h3 style="margin:0">${E(title)}</h3><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div data-body>${body}</div></div>`;document.body.append(w);w.querySelector('[data-close]').onclick=()=>w.remove();w.addEventListener('click',e=>{if(e.target===w)w.remove();});return w;}
  async function courses(){const t=tid();return t?(await api(q('/api/courses'))).courses||[]:[];}
  const opts=(xs,sel='')=>xs.map(c=>`<option value="${E(c.id)}"${String(c.id)===String(sel)?' selected':''}>${E(c.name)}</option>`).join('');

  // --- KURSNET: Katalogangaben, Kursangebote, Vorschau und die Datei für die Bundesagentur.
  async function kursnet(host){
    const cs=await courses();
    const [einst,angebote]=await Promise.all([api(q('/api/kursnet/settings')),api(q('/api/kursnet/offers'))]);
    const s=einst.settings||{};
    host.innerHTML=`<section class="card"><h3 style="margin-top:0">Katalogangaben</h3>
      <p class="muted">Ohne diese Angaben lässt sich der Katalog gar nicht erst bauen. Anbieternummer, Eingabeverfahren und Katalogkennung sind Pflicht; sie stehen in jeder ausgelieferten Datei.</p>
      <form data-settings>
        <div class="row">
          <label class="field">Katalogkennung<input name="catalog_id" required value="${E(s.catalog_id||'')}"></label>
          <label class="field">Katalogname<input name="catalog_name" required value="${E(s.catalog_name||'')}"></label>
          <label class="field">Bildungsanbieternummer<input name="institution_number" required maxlength="8" value="${E(s.institution_number||'')}"></label>
        </div>
        <div class="row">
          <label class="field">Eingabeverfahren (Schlüsselzahl)<input name="input_type" type="number" min="0" required value="${E(s.input_type??'')}"></label>
          <label class="field">Kontakt-E-Mail<input name="contact_email" type="email" value="${E(s.contact_email||'')}"></label>
        </div>
        <button class="btn">Speichern</button> <span class="muted" data-settings-status></span>
      </form></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Kursangebot melden</h3>
        <form data-offer>
          <div class="row">
            <label class="field">Klasse/Kurs<select name="course_id" required>${opts(cs)}</select></label>
            <label class="field">Maßnahmenummer<input name="measure_number" maxlength="60"></label>
            <label class="field">Unterrichtssprache (ISO 639-2)<input name="teaching_language" maxlength="3" placeholder="ger"></label>
          </div>
          <div class="row">
            <label class="field">Angebotsart (1–5)<input name="course_type" type="number" min="1" max="5" required></label>
            <label class="field">Anbieterschlüssel<input name="institution_key" type="number" min="0" required></label>
            <label class="field">Unterrichtsform<input name="instruction_form_key" type="number" min="0" required></label>
          </div>
          <div class="row">
            <label class="field">Bildungsart<input name="education_type_key" type="number" min="0" required></label>
            <label class="field">Zeitraumklasse<input name="duration_type" type="number" min="0" required></label>
          </div>
          <p class="muted">Diese fünf Schlüsselzahlen gibt die Bundesagentur vor. Fehlt eine davon, lässt die Prüfung das Angebot mit Grund aus dem Katalog – es taucht dann in der Liste „ausgelassen“ auf.</p>
          <label class="field">Kurzbeschreibung<textarea name="description" rows="3"></textarea></label>
          <div class="row">
            <label class="field">Zugangsvoraussetzungen<input name="requirements"></label>
            <label class="field">Zielgruppe<input name="target_group"></label>
          </div>
          <button class="btn">Angebot speichern</button> <span class="muted" data-offer-status></span>
        </form></section>
      <section class="card" style="margin-top:14px"><div class="top"><h3 style="margin:0">Gemeldete Angebote</h3>
        <span><button class="btn secondary" data-preview>Katalog prüfen</button> <a class="btn secondary" href="${E(q('/api/kursnet/catalog.xml'))}">Datei herunterladen</a></span></div>${
        (angebote.offers||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Kurs</th><th scope="col">Maßnahmenummer</th><th scope="col">Sprache</th><th scope="col">aktiv</th></tr>
        ${angebote.offers.map(o=>`<tr><td>${E(cs.find(c=>c.id===o.course_id)?.name||o.course_id)}</td><td>${E(o.measure_number||'—')}</td><td>${E(o.teaching_language||'—')}</td><td>${Number(o.is_active)?'ja':'nein'}</td></tr>`).join('')}</table></div>`
        :'<p class="muted">Noch kein Angebot gemeldet.</p>'}
        <div data-preview-out style="margin-top:12px"></div></section>`;
    const st=host.querySelector('[data-settings-status]'),ost=host.querySelector('[data-offer-status]');
    host.querySelector('[data-settings]').onsubmit=async e=>{e.preventDefault();
      st.textContent='Wird gespeichert …';
      try{await api(q('/api/kursnet/settings'),{method:'PUT',body:JSON.stringify(Object.fromEntries(new FormData(e.currentTarget)))});st.textContent='Gespeichert.';}
      catch(x){st.textContent=text(x);}};
    host.querySelector('[data-offer]').onsubmit=async e=>{e.preventDefault();
      const v=Object.fromEntries(new FormData(e.currentTarget)),payload={};
      for(const [k,val] of Object.entries(v))if(val)payload[k]=val;
      ost.textContent='Wird gespeichert …';
      try{await api(q('/api/kursnet/offers'),{method:'POST',body:JSON.stringify(payload)});await kursnet(host);}
      catch(x){ost.textContent=text(x);}};
    host.querySelector('[data-preview]').onclick=async()=>{
      const out=host.querySelector('[data-preview-out]');out.innerHTML='<p class="muted">Wird geprüft …</p>';
      try{const d=await api(q('/api/kursnet/catalog'));
        const befunde=d.befunde||[];
        out.innerHTML=`<div class="notice${d.gueltig?'':' error'}">${E((d.angebote||[]).length)} Angebote im Katalog${(d.ausgelassen||[]).length?`, ${E(d.ausgelassen.length)} ausgelassen`:''}. ${d.gueltig?'Der Katalog ist gültig.':'Der Katalog ist so noch nicht gültig.'} Dateiname: ${E(d.dateiname||'—')}</div>${
          befunde.length?`<ul>${befunde.map(i=>`<li>${E(typeof i==='string'?i:(i.text||i.message||i.code||JSON.stringify(i)))}</li>`).join('')}</ul>`:''}${
          (d.ausgelassen||[]).length?`<p class="muted">Ausgelassen: ${E(d.ausgelassen.map(x=>typeof x==='string'?x:(x.course_id||x.grund||JSON.stringify(x))).join(', '))}</p>`:''}`;}
      catch(x){out.innerHTML=`<div class="notice error">${E(text(x))}</div>`;}};
  }

  // --- Zulassung: öffentliche Bewerbungsformulare und die eingegangenen Bewerbungen.
  async function zulassung(host){
    const cs=await courses();
    const [formulare,bewerbungen]=await Promise.all([api(q('/api/enterprise/admissions/forms')),api(q('/api/enterprise/admissions'))]);
    host.innerHTML=`<section class="card"><h3 style="margin-top:0">Bewerbungsformular anlegen</h3>
      <form data-form>
        <div class="row">
          <label class="field">Klasse/Kurs<select name="course_id" required>${opts(cs)}</select></label>
          <label class="field">Titel<input name="title" required maxlength="200"></label>
          <label class="field">Höchstzahl Bewerbungen<input name="max_applications" type="number" min="1"></label>
        </div>
        <label class="field">Einleitungstext<textarea name="intro" rows="3"></textarea></label>
        <div class="row">
          <label><input type="checkbox" name="documents_required"> Unterlagen erforderlich</label>
          <label class="field">Aufbewahrung der Unterlagen (Tage)<input name="document_retention_days" type="number" min="1" value="180"></label>
        </div>
        <button class="btn">Formular anlegen</button> <span class="muted" data-form-status></span>
      </form></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Formulare</h3>${
        (formulare.forms||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Titel</th><th scope="col">Kurs</th><th scope="col">Stand</th><th scope="col">öffentlicher Link</th></tr>
        ${formulare.forms.map(f=>`<tr><td>${E(f.title)}</td><td>${E(cs.find(c=>c.id===f.course_id)?.name||f.course_id||'—')}</td><td>${E(f.status)}</td><td class="muted">${f.public_url?`<a href="${E(f.public_url)}" target="_blank" rel="noopener">${E(f.public_url)}</a>`:'— erst nach dem Veröffentlichen —'}</td></tr>`).join('')}</table></div>`
        :'<p class="muted">Noch kein Formular angelegt.</p>'}</section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Eingegangene Bewerbungen</h3>${
        (bewerbungen.admissions||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Eingang</th><th scope="col">Name</th><th scope="col">Kontakt</th><th scope="col">Kurs</th><th scope="col">Stand</th><th scope="col">Vorgang</th></tr>
        ${bewerbungen.admissions.map(a=>`<tr><td>${E(String(a.created_at||'').slice(0,10))}</td><td>${E(a.applicant_name)}${Number(a.possible_duplicate)?' <span class="muted">(möglicher Doppeleingang)</span>':''}</td><td class="muted">${E(a.applicant_email||a.applicant_phone||'—')}</td><td>${E(cs.find(c=>c.id===a.course_id)?.name||a.course_id||'—')}</td><td>${E(a.status)}</td><td><button class="btn secondary" type="button" data-bew="${E(a.id)}">Öffnen</button></td></tr>`).join('')}</table></div>`
        :'<p class="muted">Noch keine Bewerbung eingegangen.</p>'}</section>`;
    host.querySelectorAll('[data-bew]').forEach(b=>b.onclick=()=>bewerbung(b.dataset.bew).catch(x=>alert(text(x))));
    const st=host.querySelector('[data-form-status]');
    host.querySelector('[data-form]').onsubmit=async e=>{e.preventDefault();
      const f=e.currentTarget,v=Object.fromEntries(new FormData(f));
      v.documents_required=f.elements.documents_required.checked;
      st.textContent='Wird angelegt …';
      try{await api(q('/api/enterprise/admissions/forms'),{method:'POST',body:JSON.stringify(v)});await zulassung(host);}
      catch(x){st.textContent=text(x);}};
  }

  // --- Ein einzelner Bewerbungsvorgang: Verlauf, Nachricht, Nachforderung, Entscheidung.
  //
  // Bis hierher war die Bewerbung eine Zeile in einer Liste. Entschieden, nachgefordert und
  // geantwortet wurde per privater E-Mail - nicht nachweisbar, und die nachgereichten Zeugnisse
  // landeten im Postfach einer Person statt in der Akte.
  const ART_NAME={eingang:'Eingangsbestätigung',nachforderung:'Nachforderung',einladung:'Einladung',zusage:'Zusage',absage:'Absage',hinweis:'Hinweis'};
  const STAND_NAME={received:'eingegangen',in_review:'in Prüfung',offered:'Platz angeboten',waitlisted:'Warteliste',rejected:'abgelehnt',enrolled:'übernommen'};
  // Dieselben Übergänge wie im Worker: was dort verboten ist, wird hier gar nicht erst angeboten.
  const MOEGLICH={received:['in_review','offered','waitlisted','rejected'],in_review:['offered','waitlisted','rejected'],
    waitlisted:['in_review','offered','rejected'],offered:['waitlisted','rejected'],rejected:[],enrolled:[]};
  async function bewerbung(id){
    const w=modal('Bewerbung','<p>Lädt …</p>','820px');
    const body=w.querySelector('[data-body]');
    async function zeichne(){
      const [d,v]=await Promise.all([
        api(q(`/api/enterprise/admissions/${encodeURIComponent(id)}`)),
        api(q(`/api/enterprise/admissions/${encodeURIComponent(id)}/messages`)).catch(()=>({verlauf:[]})),
      ]);
      const a=d.admission||d;
      const verlauf=v.verlauf||[];
      const offen=verlauf.filter(m=>m.offen);
      body.innerHTML=`<p><strong>${E(a.applicant_name)}</strong> · Vorgangsnummer <code>${E(a.reference_code)}</code> · Stand ${E(a.status)}</p>
        <p class="muted">${E(a.applicant_email||'—')}${a.applicant_phone?` · ${E(a.applicant_phone)}`:''} · ${E(a.document_count||0)} Unterlage(n)</p>
        ${offen.length?`<div class="notice${offen.some(m=>m.ueberfaellig)?' bad':''}">Offene Nachforderung, Frist ${E(String(offen[0].frist_am||'').slice(0,10))}${offen.some(m=>m.ueberfaellig)?' – überschritten':''}.</div>`:''}
        <h4>Was an die bewerbende Person ging</h4>
        ${verlauf.length?`<div class="table-wrap"><table><caption>Schriftwechsel</caption><thead><tr><th scope="col">Datum</th><th scope="col">Art</th><th scope="col">Betreff</th><th scope="col">Weg</th></tr></thead><tbody>`
          +verlauf.map(m=>`<tr><th scope="row">${E(String(m.created_at||'').slice(0,10))}</th><td>${E(ART_NAME[m.art]||m.art)}</td><td>${E(m.betreff)}</td>`
            +`<td>${m.kanal==='mail'?(m.versand_fehler?'<strong>nicht zugestellt</strong>':'per E-Mail'):'kein Kanal – bitte auf Papier'}${m.erledigt_am?' · erledigt':''}</td></tr>`).join('')
          +`</tbody></table></div>`:'<p class="muted">Noch nichts geschrieben.</p>'}
        <h4>Unterlagen nachfordern</h4>
        <p class="muted">Die bewerbende Person bekommt einen Link, über den sie ausschließlich einreichen kann. Drei Tage vor Fristende erinnert das Portal von selbst; abgelehnt wird deshalb nichts – das bleibt Ihre Entscheidung.</p>
        <form data-nachf><label class="field">Was fehlt?<textarea name="text" rows="3" required minlength="20" placeholder="Uns fehlt noch Ihr letztes Zeugnis."></textarea></label>
          <div class="row"><label class="field">Frist in Tagen<input name="frist_tage" type="number" min="1" max="90" value="14"></label></div>
          <div class="toolbar"><button class="btn" type="submit">Nachforderung senden</button></div></form>
        <h4>Nachricht schreiben</h4>
        <p class="muted">Was hier steht, liest die bewerbende Person wörtlich. Ihre interne Entscheidungsnotiz bleibt in der Akte und geht nie mit hinaus.</p>
        <form data-nachricht><div class="row">
          <label class="field">Art<select name="art"><option value="einladung">Einladung</option><option value="zusage">Zusage</option><option value="absage">Absage</option><option value="hinweis">Hinweis</option></select></label>
          <label class="field">Betreff<input name="betreff" maxlength="160"></label></div>
          <label class="field">Text<textarea name="text" rows="4" required minlength="20"></textarea></label>
          <div class="toolbar"><button class="btn secondary" type="submit">Nachricht senden</button></div></form>
        <h4>Entscheidung</h4>
        <p class="muted">Von ${E(STAND_NAME[a.status]||a.status)} aus möglich: ${E((MOEGLICH[a.status]||[]).map(x=>STAND_NAME[x]||x).join(', ')||'nichts mehr – der Vorgang ist abgeschlossen')}.</p>
        ${(MOEGLICH[a.status]||[]).length?`<form data-entsch><div class="row">
          <label class="field">Stand<select name="status">${(MOEGLICH[a.status]||[]).map(x=>`<option value="${E(x)}">${E(STAND_NAME[x]||x)}</option>`).join('')}</select></label></div>
          <label class="field">Interne Begründung (bleibt im Haus und geht nie an die bewerbende Person)<textarea name="note" rows="2"></textarea></label>
          <div class="toolbar"><button class="btn secondary" type="submit">Stand festhalten</button></div></form>`:''}
        ${a.status==='offered'?`<form data-uebern><p class="muted">Die Übernahme legt die Person als Teilnehmende an – über denselben Weg wie eine Teilnehmerliste, damit nichts doppelt entsteht.</p>
          <div class="toolbar"><button class="btn" type="submit">In den Kurs übernehmen</button></div></form>`:''}
        <p class="error" data-err role="alert"></p>`;
      const melde=x=>{body.querySelector('[data-err]').textContent=text(x);};
      const senden=(sel,pfad,daten,danach)=>{const f=body.querySelector(sel);if(f)f.onsubmit=async e=>{
        e.preventDefault();melde('');
        try{const r=await api(q(pfad),{method:'POST',body:JSON.stringify(daten(new FormData(e.target)))});await zeichne();if(danach)danach(r);}
        catch(x){melde(x);}
      };};
      senden('[data-nachf]',`/api/enterprise/admissions/${encodeURIComponent(id)}/request-documents`,
        f=>({text:f.get('text'),frist_tage:Number(f.get('frist_tage')||14)}),
        r=>{const n=r.nachforderung;if(n&&n.kanal!=='mail')body.querySelector('[data-err]').textContent=`Kein Postfach hinterlegt. Bitte geben Sie diesen Link persönlich weiter: ${n.link}`;});
      senden('[data-nachricht]',`/api/enterprise/admissions/${encodeURIComponent(id)}/messages`,
        f=>({art:f.get('art'),betreff:f.get('betreff'),text:f.get('text')}));
      senden('[data-entsch]',`/api/enterprise/admissions/${encodeURIComponent(id)}/decision`,
        f=>({status:f.get('status'),note:f.get('note')}));
      senden('[data-uebern]',`/api/enterprise/admissions/${encodeURIComponent(id)}/enroll`,()=>({}));
    }
    await zeichne();
  }

  // --- Betrieb: Anwesenheitsregeln, Namensgleichungen des Stundenplans, Zusammenarbeit.
  async function betrieb(host){
    const cs=await courses();
    const aliase=await api(q('/api/timetable/target-aliases')).catch(()=>({aliases:[]}));
    host.innerHTML=`<section class="card"><h3 style="margin-top:0">Anwesenheitsregeln</h3>
      <p class="muted">Ab wann das Portal auf eine Klasse aufmerksam macht: zu geringe Anwesenheit, zu viele unentschuldigte Einheiten oder zu viele Verspätungen im Betrachtungszeitraum. Ohne Regel warnt niemand.</p>
      <form data-policy>
        <div class="row">
          <label class="field">Klasse/Kurs<select name="course_id"><option value="">für den ganzen Träger</option>${opts(cs)}</select></label>
          <label><input type="checkbox" name="enabled" checked> Regel aktiv</label>
          <label class="field">Betrachtungszeitraum (Tage)<input name="lookback_days" type="number" min="1" max="3650" value="90"></label>
        </div>
        <div class="row">
          <label class="field">Warnen ab Anwesenheit unter (%)<input name="attendance_percent_threshold" type="number" min="0" max="100" value="80"></label>
          <label class="field">Warnen ab unentschuldigten Einheiten<input name="unexcused_session_threshold" type="number" min="0" value="3"></label>
          <label class="field">Warnen ab Verspätungen<input name="late_session_threshold" type="number" min="0" value="5"></label>
        </div>
        <button class="btn">Regel speichern</button> <span class="muted" data-policy-status></span>
      </form></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Namensgleichungen im Stundenplan</h3>
        <p class="muted">Wenn die Stundenplandatei „FK Metall 3“ schreibt und der Kurs im Portal „Fachklasse Metall 3“ heißt, ordnet die Gleichung beides einander zu – sonst landet die Stunde nirgends.</p>
        <form data-alias class="row" style="align-items:end;gap:10px">
          <label class="field">Schreibweise in der Datei<input name="source_value" required maxlength="200"></label>
          <label class="field">Klasse/Kurs<select name="course_id" required>${opts(cs)}</select></label>
          <button class="btn">Gleichung anlegen</button>
        </form>
        <span class="muted" data-alias-status></span>
        ${(aliase.aliases||[]).length?`<div class="table-wrap" style="margin-top:10px"><table><tr><th scope="col">Schreibweise</th><th scope="col">Ziel</th></tr>
          ${aliase.aliases.map(a=>`<tr><td>${E(a.source_value||'')}</td><td>${E(cs.find(c=>c.id===a.course_id)?.name||a.course_id||a.target_id||'')}</td></tr>`).join('')}</table></div>`:'<p class="muted">Keine Gleichung hinterlegt.</p>'}</section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Zusammenarbeit</h3>
        <form data-collab>
          <label><input type="checkbox" name="course_forums_enabled"> Kursforen</label><br>
          <label><input type="checkbox" name="direct_messages_enabled"> Direktnachrichten</label><br>
          <label><input type="checkbox" name="participant_thread_creation"> Teilnehmende dürfen Themen eröffnen</label><br>
          <button class="btn" style="margin-top:10px">Speichern</button> <span class="muted" data-collab-status></span>
        </form></section>`;
    const pst=host.querySelector('[data-policy-status]'),ast=host.querySelector('[data-alias-status]'),cst=host.querySelector('[data-collab-status]');
    host.querySelector('[data-policy]').onsubmit=async e=>{e.preventDefault();
      const f=e.currentTarget,v=Object.fromEntries(new FormData(f));
      pst.textContent='Wird gespeichert …';
      try{await api(q('/api/attendance/policy',v.course_id?{course_id:v.course_id}:{}),{method:'PUT',body:JSON.stringify({
        enabled:f.elements.enabled.checked,
        lookback_days:Number(v.lookback_days),
        attendance_percent_threshold:Number(v.attendance_percent_threshold),
        unexcused_session_threshold:Number(v.unexcused_session_threshold),
        late_session_threshold:Number(v.late_session_threshold)})});pst.textContent='Gespeichert.';}
      catch(x){pst.textContent=text(x);}};
    host.querySelector('[data-alias]').onsubmit=async e=>{e.preventDefault();
      const v=Object.fromEntries(new FormData(e.currentTarget));
      ast.textContent='Wird angelegt …';
      try{await api(q('/api/timetable/target-aliases'),{method:'POST',body:JSON.stringify(v)});await betrieb(host);}
      catch(x){ast.textContent=text(x);}};
    host.querySelector('[data-collab]').onsubmit=async e=>{e.preventDefault();
      const f=e.currentTarget;cst.textContent='Wird gespeichert …';
      try{await api(q('/api/collaboration/settings'),{method:'PUT',body:JSON.stringify({course_forums_enabled:f.elements.course_forums_enabled.checked,direct_messages_enabled:f.elements.direct_messages_enabled.checked,participant_thread_creation:f.elements.participant_thread_creation.checked})});cst.textContent='Gespeichert.';}
      catch(x){cst.textContent=text(x);}};
  }

  // --- Berichte und Reife.
  async function berichte(host){
    const cs=await courses(),kurs=host.dataset.kurs||cs[0]?.id||'';
    host.dataset.kurs=kurs;
    const [definitionen,sprachen]=await Promise.all([api(q('/api/reports/definitions')),api(q('/api/moat/locales')).catch(()=>({locales:[]}))]);
    host.innerHTML=`<section class="card"><h3 style="margin-top:0">Auswertungen</h3>${
      (definitionen.reports||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Name</th><th scope="col">Datensatz</th><th scope="col">Spalten</th></tr>
      ${definitionen.reports.map(d=>`<tr><td>${E(d.name)}</td><td>${E(d.dataset)}</td><td class="muted">${E((()=>{try{return JSON.parse(d.columns_json||'[]').join(', ');}catch{return '';}})())}</td></tr>`).join('')}</table></div>`
      :'<p class="muted">Noch keine Auswertung angelegt.</p>'}</section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Reife und Auslastung</h3>
        <div class="row" style="align-items:end;gap:10px">
          <label class="field">Klasse/Kurs<select data-kurs>${opts(cs,kurs)}</select></label>
          <button class="btn secondary" data-trend>Reifeverlauf</button>
          <button class="btn secondary" data-snapshot>Reife festhalten</button>
          <button class="btn secondary" data-workload>Lehrauslastung</button>
          <button class="btn secondary" data-twin>Lernstand festhalten</button>
        </div>
        <div data-out style="margin-top:12px"></div></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Eigener Lernkompass</h3>
        <button class="btn secondary" data-compass>Meinen Kompass anzeigen</button>
        <div data-compass-out style="margin-top:12px"></div></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Qualitätsanforderungen</h3>
        <button class="btn secondary" data-req>Anforderungen anzeigen</button>
        <p class="muted">Gepflegte Sprachen: ${E((sprachen.locales||[]).join(', ')||'—')}</p>
        <div data-req-out style="margin-top:12px"></div></section>`;
    const out=host.querySelector('[data-out]');
    host.querySelector('[data-kurs]').onchange=e=>{host.dataset.kurs=e.target.value;};
    const k=()=>host.querySelector('[data-kurs]').value;
    const zeigen=async(ziel,fn)=>{ziel.innerHTML='<p class="muted">Wird geladen …</p>';try{ziel.innerHTML=await fn();}catch(x){ziel.innerHTML=`<div class="notice error">${E(text(x))}</div>`;}};
    host.querySelector('[data-trend]').onclick=()=>zeigen(out,async()=>{
      const d=await api(q('/api/education-os/readiness/trend',{course_id:k()}));
      const xs=d.trend||d.snapshots||[];
      return xs.length?`<div class="table-wrap"><table><tr><th scope="col">Zeitpunkt</th><th scope="col">Punktzahl</th><th scope="col">Stand</th></tr>${xs.map(t=>`<tr><td>${E(String(t.captured_at||'').slice(0,16).replace('T',' '))}</td><td style="text-align:right">${E(t.score)}</td><td>${E(t.readiness_status||'')}</td></tr>`).join('')}</table></div>`:'<p class="muted">Noch kein Verlauf festgehalten.</p>';});
    host.querySelector('[data-snapshot]').onclick=()=>zeigen(out,async()=>{
      await api(q('/api/education-os/readiness/snapshot'),{method:'POST',body:JSON.stringify({course_id:k()})});
      return '<div class="notice">Reife festgehalten. Der Verlauf zeigt sie ab jetzt.</div>';});
    host.querySelector('[data-workload]').onclick=()=>zeigen(out,async()=>{
      const d=await api(q('/api/education/planning/teacher-workload-balance'));
      const xs=d.balance?.teachers||d.balance||[];
      return Array.isArray(xs)&&xs.length?`<div class="table-wrap"><table><tr><th scope="col">Lehrkraft</th><th scope="col">Minuten</th><th scope="col">Abweichung</th></tr>${xs.map(t=>`<tr><td>${E(t.name||t.teacher_id)}</td><td style="text-align:right">${E(t.minutes??t.total_minutes??0)}</td><td style="text-align:right">${E(t.deviation??t.delta??'—')}</td></tr>`).join('')}</table></div>`:'<p class="muted">Keine Auslastungsdaten vorhanden.</p>';});
    host.querySelector('[data-twin]').onclick=()=>zeigen(out,async()=>{
      await api(q('/api/moat/learner-twin/snapshot',{course_id:k()}),{method:'POST',body:'{}'});
      return '<div class="notice">Lernstand festgehalten.</div>';});
    host.querySelector('[data-compass]').onclick=()=>zeigen(host.querySelector('[data-compass-out]'),async()=>{
      const d=await api(q('/api/education-os/my-compass',{course_id:k()}));
      const c=d.compass||d;
      return `<div class="table-wrap"><table><tr><th scope="col">Feld</th><th scope="col">Wert</th></tr>${Object.entries(c).filter(([,v])=>typeof v!=='object').map(([kk,v])=>`<tr><td>${E(kk)}</td><td>${E(v)}</td></tr>`).join('')}</table></div>`;});
    host.querySelector('[data-req]').onclick=()=>zeigen(host.querySelector('[data-req-out]'),async()=>{
      const d=await api(q('/api/moat/compliance/requirements'));
      const xs=d.requirements||[];
      return xs.length?`<div class="table-wrap"><table><tr><th scope="col">Anforderung</th><th scope="col">Regelwerk</th><th scope="col">Stand</th></tr>${xs.map(r=>`<tr><td>${E(r.title||r.requirement_key)}</td><td>${E(r.framework||'')}</td><td>${E(r.status||'')}</td></tr>`).join('')}</table></div>`:'<p class="muted">Keine Anforderung hinterlegt.</p>';});
  }


  // --- Noten: die ganze Klasse in einem Zug bewerten.
  async function noten(host){
    const cs=await courses(),kurs=host.dataset.kurs||cs[0]?.id||'';
    host.dataset.kurs=kurs;
    const buch=kurs?await api(q('/api/learning-suite/gradebook',{course_id:kurs})):{items:[],participants:[]};
    const posten=buch.items||buch.gradebook?.items||[],leute=buch.participants||buch.gradebook?.participants||[];
    host.innerHTML=`<section class="card"><h3 style="margin-top:0">Notenliste der Klasse</h3>
      <p class="muted">Alle Bewertungen einer Leistung in einem Zug – das ist der Weg, den die Lehrkraft am Ende einer Klausur wirklich geht.</p>
      <div class="row" style="align-items:end;gap:10px">
        <label class="field">Klasse/Kurs<select data-kurs>${opts(cs,kurs)}</select></label>
        <label class="field">Leistung<select data-item>${posten.map(i=>`<option value="${E(i.id)}">${E(i.title)}${i.max_points!==null&&i.max_points!==undefined?` (max ${E(i.max_points)})`:''}</option>`).join('')}</select></label>
        <label><input type="checkbox" data-publish> sofort veröffentlichen</label>
        <button class="btn" data-save>Notenliste speichern</button>
      </div>
      <span class="muted" data-status></span>
      ${leute.length&&posten.length?`<div class="table-wrap" style="margin-top:12px"><table><tr><th scope="col">Person</th><th scope="col">Punkte</th><th scope="col">Note</th><th scope="col">Rückmeldung</th></tr>
        ${leute.map(p=>`<tr><td>${E(p.display_name||p.user_id)}</td>
          <td><input type="number" step="0.5" min="0" data-points="${E(p.user_id)}" style="width:6rem" aria-label="Punkte für ${E(p.display_name||p.user_id)}"></td>
          <td><input maxlength="80" data-grade="${E(p.user_id)}" style="width:6rem" aria-label="Note für ${E(p.display_name||p.user_id)}"></td>
          <td><input maxlength="500" data-feedback="${E(p.user_id)}" style="width:100%" aria-label="Rückmeldung für ${E(p.display_name||p.user_id)}"></td></tr>`).join('')}</table></div>`
        :'<p class="muted">Für diese Klasse gibt es noch keine Leistung oder keine Teilnehmenden.</p>'}</section>`;
    const st=host.querySelector('[data-status]');
    host.querySelector('[data-kurs]').onchange=e=>{host.dataset.kurs=e.target.value;void noten(host);};
    const save=host.querySelector('[data-save]');
    if(save)save.onclick=async()=>{
      const item=host.querySelector('[data-item]')?.value;
      if(!item){st.textContent='Bitte zuerst eine Leistung auswählen.';return;}
      const publish=host.querySelector('[data-publish]').checked,rows=[];
      for(const feld of host.querySelectorAll('[data-points]')){
        const uid=feld.dataset.points,punkte=feld.value.trim(),note=host.querySelector(`[data-grade="${CSS.escape(uid)}"]`).value.trim(),rueck=host.querySelector(`[data-feedback="${CSS.escape(uid)}"]`).value.trim();
        if(!punkte&&!note&&!rueck)continue;
        rows.push({user_id:uid,points:punkte===''?null:Number(punkte),grade_value:note,feedback:rueck,publish});
      }
      if(!rows.length){st.textContent='Es ist nichts eingetragen.';return;}
      st.textContent='Wird gespeichert …';
      try{const r=await api(q('/api/learning-suite/gradebook/bulk',{course_id:host.dataset.kurs}),{method:'POST',body:JSON.stringify({item_id:item,rows})});
        st.textContent=`${r.saved??rows.length} Bewertungen gespeichert.`;}
      catch(x){st.textContent=text(x);}
    };
  }

  // --- Personalakte: Vertrag, Urlaub, Krankheit, Unterweisungen, Austritt.
  //
  // Sie fehlte vollständig. Am schwersten wog der Austritt: es gab keinen Weg, einer
  // ausscheidenden Lehrkraft den Zugang zu entziehen, weil nichts die Lehrkraft mit ihrem
  // Benutzerkonto verband. Wer ging, behielt Kurse, Klassenbücher und Teilnehmerdaten.
  const P_FUNKTION={lehrkraft:'Lehrkraft',verwaltung:'Verwaltung',leitung:'Leitung',sozialpaedagogik:'Sozialpädagogik',ausbildung:'Ausbildung',sonstiges:'Sonstiges'};
  const P_ART={festanstellung:'Festanstellung',teilzeit:'Teilzeit',honorar:'Honorar',minijob:'Minijob',praktikum:'Praktikum',ehrenamt:'Ehrenamt'};
  const P_ABW={urlaub:'Urlaub',krankheit:'Krankheit',fortbildung:'Fortbildung',unbezahlt:'unbezahlt',sonderurlaub:'Sonderurlaub',mutterschutz:'Mutterschutz',elternzeit:'Elternzeit'};
  const P_UNT={arbeitsschutz:'Arbeitsschutz (§ 12 ArbSchG, jährlich)',datenschutz:'Datenschutz',kinderschutz:'Kinderschutz',infektionsschutz:'Infektionsschutz (§ 43 IfSG)',brandschutz:'Brandschutz',ersthelfer:'Ersthelfer',fuehrungszeugnis:'Erweitertes Führungszeugnis (§ 72a SGB VIII)',sonstiges:'Sonstiges'};
  const P_GRUND={kuendigung_arbeitnehmer:'Kündigung durch die Person',kuendigung_arbeitgeber:'Kündigung durch den Träger',befristung_ende:'Ende der Befristung',aufhebung:'Aufhebungsvertrag',rente:'Rente',sonstiges:'Sonstiges'};

  async function personal(host){
    const [liste,faellig]=await Promise.all([
      api(q('/api/personnel')),
      api(q('/api/personnel/instructions/due',{vorlauf:'60'})).catch(()=>({faellig:[]}))]);
    const ueberfaellig=(faellig.faellig||[]).filter(f=>f.ueberfaellig);
    host.innerHTML=`${ueberfaellig.length?`<div class="notice error"><strong>${E(ueberfaellig.length)} Unterweisung(en) überfällig.</strong> Das ist der Teil, an dem eine Prüfung nach AZAV hängt.</div>`:''}
      ${(faellig.faellig||[]).length?`<section class="card"><h3 style="margin-top:0">Fällige Unterweisungen</h3>
        <div class="table-wrap"><table><tr><th scope="col">Person</th><th scope="col">Art</th><th scope="col">fällig</th></tr>
        ${faellig.faellig.map(f=>`<tr><td>${E(f.name)}</td><td>${E(P_UNT[f.art]||f.art)}</td><td>${f.ueberfaellig?`<strong>${E(f.faellig_am)}</strong>`:E(f.faellig_am)}</td></tr>`).join('')}</table></div></section>`:''}
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Beschäftigte</h3>${
        (liste.personen||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Name</th><th scope="col">Funktion</th><th scope="col">Eintritt</th><th scope="col">Stand</th><th scope="col">Verträge</th><th scope="col">Akte</th></tr>
        ${liste.personen.map(x=>`<tr><td>${E(x.name)}${x.personalnummer?` <span class="muted">${E(x.personalnummer)}</span>`:''}</td><td>${E(P_FUNKTION[x.funktion]||x.funktion)}</td>`
          +`<td>${E(x.eintritt)}</td><td>${E(x.status)}${x.austritt?` <span class="muted">(${E(x.austritt)})</span>`:''}</td><td>${E(x.vertraege)}</td>`
          +`<td><button class="btn secondary" type="button" data-akte="${E(x.id)}">Öffnen</button></td></tr>`).join('')}</table></div>`
        :'<p class="muted">Noch keine Personalakte angelegt.</p>'}</section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Akte anlegen</h3>
        <form data-neu><div class="row">
          <label class="field">Name<input name="name" required minlength="2"></label>
          <label class="field">Funktion<select name="funktion">${Object.entries(P_FUNKTION).map(([k,v])=>`<option value="${E(k)}">${E(v)}</option>`).join('')}</select></label>
          <label class="field">Eintritt<input name="eintritt" type="date" required></label>
          <label class="field">Personalnummer<input name="personalnummer"></label>
        </div>
        <p class="muted">Die Kennung des Portalkontos verbindet die Akte mit dem Zugang – nur darüber lässt er sich beim Austritt entziehen.</p>
        <div class="row"><label class="field">Kennung des Portalkontos (optional)<input name="user_id"></label>
        <label class="field">Kennung der Lehrkraft (optional)<input name="teacher_id"></label></div>
        <button class="btn">Akte anlegen</button> <span class="muted" data-neu-status></span></form></section>`;
    const st=host.querySelector('[data-neu-status]');
    host.querySelector('[data-neu]').onsubmit=async e=>{e.preventDefault();
      const v=Object.fromEntries([...new FormData(e.currentTarget)].filter(([,x])=>String(x).trim()));
      st.textContent='Wird angelegt …';
      try{await api(q('/api/personnel'),{method:'POST',body:JSON.stringify(v)});await personal(host);}
      catch(x){st.textContent=text(x);}};
    host.querySelectorAll('[data-akte]').forEach(b=>b.onclick=()=>akte(b.dataset.akte).catch(x=>alert(text(x))));
  }

  async function akte(personnelId){
    const w=modal('Personalakte','<p>Lädt …</p>','860px');
    const body=w.querySelector('[data-body]');
    const pfad=t=>`/api/personnel/${encodeURIComponent(personnelId)}${t}`;
    async function zeichne(){
      const [d,austritt]=await Promise.all([api(q(pfad(''))),api(q(pfad('/offboarding'))).catch(()=>null)]);
      const p=d.person;
      body.innerHTML=`<p><strong>${E(p.name)}</strong> · ${E(P_FUNKTION[p.funktion]||p.funktion||'')} · Eintritt ${E(p.eintritt)} · Stand ${E(p.status)}</p>
        <h4>Verträge</h4>${(d.vertraege||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Art</th><th scope="col">Beginn</th><th scope="col">Ende</th><th scope="col">Befristet</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr>
          ${d.vertraege.map(v=>`<tr><td>${E(P_ART[v.art]||v.art)}</td><td>${E(v.beginn)}</td><td>${E(v.ende||'unbefristet')}</td>`
            +`<td>${Number(v.befristet)?`ja${v.sachgrund?` <span class="muted">(${E(v.sachgrund)})</span>`:' <span class="muted">(sachgrundlos)</span>'}`:'nein'}</td><td>${E(v.status)}</td>`
            +`<td>${v.status==='aktiv'?`<button class="btn secondary" type="button" data-ende="${E(v.id)}">Beenden</button>`:''}</td></tr>`).join('')}</table></div>`
          :'<p class="muted">Kein Vertrag hinterlegt.</p>'}
        <form data-vertrag><div class="row">
          <label class="field">Art<select name="art">${Object.entries(P_ART).map(([k,v])=>`<option value="${E(k)}">${E(v)}</option>`).join('')}</select></label>
          <label class="field">Beginn<input name="beginn" type="date" required></label>
          <label class="field">Ende (leer = unbefristet)<input name="ende" type="date"></label>
        </div><div class="row">
          <label class="field">Wochenstunden<input name="wochenstunden" type="number" step="0.5" min="0"></label>
          <label class="field">Urlaubstage/Jahr<input name="urlaubstage_jahr" type="number" step="0.5" min="0"></label>
          <label class="field">Probezeit bis<input name="probezeit_bis" type="date"></label>
        </div>
        <label class="field">Sachgrund der Befristung<input name="sachgrund" placeholder="z. B. Vertretung während Elternzeit"></label>
        <p class="muted">Ohne Sachgrund ist eine Befristung nur bis zwei Jahre und nur ohne frühere Beschäftigung bei diesem Träger zulässig (§ 14 Abs. 2 TzBfG). Sonst gilt der Vertrag als unbefristet.</p>
        <div class="toolbar"><button class="btn" type="submit">Vertrag anlegen</button></div></form>
        <h4>Urlaub ${E(d.urlaub?.jahr||'')}</h4>
        <p>Anspruch ${E(d.urlaub?.anspruch_tage??0)} Tage${Number(d.urlaub?.uebertrag_tage)?` + ${E(d.urlaub.uebertrag_tage)} Übertrag${d.urlaub.uebertrag_verfallen?' <span class="muted">(verfallen)</span>':''}`:''} · genommen ${E(d.urlaub?.genommen_tage??0)} · <strong>Rest ${E(d.urlaub?.rest_tage??0)}</strong></p>
        <form data-urlaub><div class="row">
          <label class="field">Jahr<input name="jahr" type="number" min="2000" max="2100" value="${E(d.urlaub?.jahr||new Date().getUTCFullYear())}"></label>
          <label class="field">Anspruch (Tage)<input name="anspruch_tage" type="number" step="0.5" min="0" required></label>
          <label class="field">Übertrag aus Vorjahr<input name="uebertrag_tage" type="number" step="0.5" min="0" value="0"></label>
        </div><div class="toolbar"><button class="btn secondary" type="submit">Anspruch festhalten</button></div></form>
        <h4>Abwesenheit</h4>${(d.abwesenheiten||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Art</th><th scope="col">von</th><th scope="col">bis</th><th scope="col">Tage</th><th scope="col">Stand</th><th scope="col">Nachweis</th><th scope="col">Aktion</th></tr>
          ${d.abwesenheiten.map(x=>`<tr><td>${E(P_ABW[x.art]||x.art)}</td><td>${E(x.von)}</td><td>${E(x.bis)}</td><td>${E(x.tage)}</td><td>${E(x.status)}</td>`
            +`<td>${Number(x.nachweis_noetig)?(x.nachweis_am?E(x.nachweis_am):'<strong>fehlt</strong>'):'—'}</td>`
            +`<td>${x.status==='beantragt'?`<button class="btn secondary" type="button" data-gen="${E(x.id)}">Genehmigen</button> <button class="btn secondary" type="button" data-abl="${E(x.id)}">Ablehnen</button>`:''}`
            +`${Number(x.nachweis_noetig)&&!x.nachweis_am?` <button class="btn secondary" type="button" data-nw="${E(x.id)}">Nachweis da</button>`:''}</td></tr>`).join('')}</table></div>`
          :'<p class="muted">Keine Abwesenheit erfasst.</p>'}
        <form data-abw><div class="row">
          <label class="field">Art<select name="art">${Object.entries(P_ABW).map(([k,v])=>`<option value="${E(k)}">${E(v)}</option>`).join('')}</select></label>
          <label class="field">von<input name="von" type="date" required></label>
          <label class="field">bis<input name="bis" type="date" required></label>
        </div><div class="toolbar"><button class="btn secondary" type="submit">Erfassen</button></div></form>
        <p class="muted">Eine Arbeitsunfähigkeitsbescheinigung wird ab dem vierten Kalendertag verlangt (§ 5 EFZG). Sie bleibt offen, bis sie vorliegt.</p>
        <h4>Unterweisungen</h4>${(d.unterweisungen||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Art</th><th scope="col">durchgeführt</th><th scope="col">Intervall</th><th scope="col">fällig</th></tr>
          ${d.unterweisungen.map(x=>`<tr><td>${E(P_UNT[x.art]||x.art)}</td><td>${E(x.durchgefuehrt_am)}</td><td>${E(x.intervall_monate)} Monate</td><td>${E(x.faellig_am)}</td></tr>`).join('')}</table></div>`
          :'<p class="muted">Keine Unterweisung erfasst.</p>'}
        <form data-unt><div class="row">
          <label class="field">Art<select name="art">${Object.entries(P_UNT).map(([k,v])=>`<option value="${E(k)}">${E(v)}</option>`).join('')}</select></label>
          <label class="field">durchgeführt am<input name="durchgefuehrt_am" type="date" required></label>
          <label class="field">Intervall (Monate)<input name="intervall_monate" type="number" min="1" max="120"></label>
        </div><div class="toolbar"><button class="btn secondary" type="submit">Unterweisung festhalten</button></div></form>
        <h4>Austritt</h4>
        ${austritt?`<p>Zugang ${austritt.zugang_aktiv?'<strong>noch aktiv</strong>':'entzogen'} · ${E(austritt.gegenstaende.length)} Gegenstand/Gegenstände offen · ${E(austritt.kurse.length)} laufende(r) Kurs(e) · ${E(austritt.aktive_vertraege)} aktive(r) Vertrag/Verträge · ${E(austritt.offene_abwesenheiten)} offene(r) Antrag/Anträge</p>
          ${austritt.gegenstaende.length?`<ul>${austritt.gegenstaende.map(g=>`<li>${E(g.bezeichnung)} (ausgegeben ${E(String(g.ausgegeben_am).slice(0,10))})</li>`).join('')}</ul>`:''}`:''}
        ${p.status!=='ausgeschieden'?`<form data-austritt><div class="row">
          <label class="field">Letzter Arbeitstag<input name="letzter_arbeitstag" type="date" required></label>
          <label class="field">Grund<select name="grund">${Object.entries(P_GRUND).map(([k,v])=>`<option value="${E(k)}">${E(v)}</option>`).join('')}</select></label>
        </div><p class="muted">Der Austritt beendet die Verträge, storniert offene Anträge und <strong>entzieht den Portalzugang samt laufender Sitzungen</strong>.</p>
        <div class="toolbar"><button class="btn danger" type="submit">Austritt vollziehen</button></div></form>`
        :`${austritt&&austritt.bereit?`<form data-abschluss><div class="toolbar"><button class="btn secondary" type="submit">Austritt abschließen</button></div></form>`
          :'<p class="muted">Der Austritt ist vollzogen; abschließen lässt er sich, sobald nichts mehr offen ist.</p>'}`}
        <p class="error" data-err role="alert"></p>`;
      const melde=x=>{body.querySelector('[data-err]').textContent=text(x);};
      const sende=(sel,weg,daten,methode='POST')=>{const f=body.querySelector(sel);if(f)f.onsubmit=async e=>{
        e.preventDefault();melde('');
        try{await api(q(weg),{method:methode,body:JSON.stringify(daten(new FormData(e.target)))});await zeichne();}
        catch(x){melde(x);}};};
      const felder=f=>Object.fromEntries([...f.entries()].filter(([,v])=>String(v).trim()));
      sende('[data-vertrag]',pfad('/contracts'),felder);
      sende('[data-urlaub]',pfad('/leave'),f=>({jahr:Number(f.get('jahr')),anspruch_tage:Number(f.get('anspruch_tage')),uebertrag_tage:Number(f.get('uebertrag_tage')||0)}),'PUT');
      sende('[data-abw]',pfad('/absences'),felder);
      sende('[data-unt]',pfad('/instructions'),felder);
      sende('[data-austritt]',pfad('/offboarding'),felder);
      sende('[data-abschluss]',pfad('/offboarding'),()=>({}),'PUT');
      body.querySelectorAll('[data-ende]').forEach(b=>b.onclick=async()=>{
        const ende=prompt('Zu welchem Tag endet der Vertrag? (JJJJ-MM-TT)');if(!ende)return;
        try{await api(q(`/api/personnel/contracts/${encodeURIComponent(b.dataset.ende)}/end`),{method:'POST',body:JSON.stringify({ende})});await zeichne();}
        catch(x){melde(x);}});
      body.querySelectorAll('[data-gen]').forEach(b=>b.onclick=async()=>{
        try{await api(q(`/api/personnel/absences/${encodeURIComponent(b.dataset.gen)}`),{method:'PATCH',body:JSON.stringify({status:'genehmigt'})});await zeichne();}
        catch(x){melde(x);}});
      body.querySelectorAll('[data-abl]').forEach(b=>b.onclick=async()=>{
        const grund=prompt('Warum wird der Antrag abgelehnt? (mindestens ein Satz)');if(!grund)return;
        try{await api(q(`/api/personnel/absences/${encodeURIComponent(b.dataset.abl)}`),{method:'PATCH',body:JSON.stringify({status:'abgelehnt',ablehnungsgrund:grund})});await zeichne();}
        catch(x){melde(x);}});
      body.querySelectorAll('[data-nw]').forEach(b=>b.onclick=async()=>{
        const am=prompt('Wann lag die Bescheinigung vor? (JJJJ-MM-TT)');if(!am)return;
        try{await api(q(`/api/personnel/absences/${encodeURIComponent(b.dataset.nw)}/proof`),{method:'POST',body:JSON.stringify({am})});await zeichne();}
        catch(x){melde(x);}});
    }
    await zeichne();
  }

  // --- Qualitätsmanagement: Ziele, Prozesse, Audits, Managementbewertung, Zertifikate.
  //
  // Vorhanden war die Maßnahme — das Ende der Kette. Alles davor fehlte. Für einen AZAV-Träger
  // ist das kein Beiwerk: die fachkundige Stelle prüft genau das, und ohne Zulassung gibt es
  // keine Förderung.
  const Q_MESS={abbruchquote:'Abbruchquote',erfolgsquote:'Erfolgsquote',vermittlungsquote:'Vermittlungsquote',anwesenheitsquote:'Anwesenheitsquote',beschwerdequote:'Beschwerdequote',manuell:'von Hand gepflegt'};
  const Q_PART={fuehrung:'Führungsprozess',kern:'Kernprozess',unterstuetzung:'Unterstützungsprozess'};
  const Q_AART={intern:'internes Audit',extern:'externes Audit',zertifizierung:'Zertifizierungsaudit',ueberwachung:'Überwachungsaudit'};
  const Q_EIN={abweichung_schwer:'schwere Abweichung',abweichung:'Abweichung',beobachtung:'Beobachtung',chance:'Verbesserungschance',konform:'konform'};
  const Q_ZART={traegerzulassung:'Trägerzulassung (AZAV)',massnahmezulassung:'Maßnahmezulassung',iso9001:'ISO 9001',anerkennung:'Anerkennung',sonstiges:'Sonstiges'};
  const prozent=v=>v===null||v===undefined?'<span class="muted">keine Daten</span>':`${E(v)} %`;

  async function qualitaet(host){
    const jahr=new Date().getUTCFullYear();
    const [ziele,prozesse,audits,zerts]=await Promise.all([
      api(q('/api/quality/objectives',{jahr:String(jahr)})),
      api(q('/api/quality/processes')),
      api(q('/api/quality/audits')),
      api(q('/api/quality/certifications'))]);
    const k=ziele.kennzahlen||{};
    host.innerHTML=`<section class="card"><h3 style="margin-top:0">Kennzahlen ${E(jahr)}</h3>
      <p class="muted">Diese Zahlen werden aus den Förderfällen und der erfassten Anwesenheit <strong>gerechnet</strong>. Eine Kennzahl, die jemand einträgt, ist vor der fachkundigen Stelle wertlos — niemand kann sagen, woher sie kommt.</p>
      <div class="table-wrap"><table><tr><th scope="col">Kennzahl</th><th scope="col">Wert</th><th scope="col">Grundlage</th></tr>
        <tr><td>Abbruchquote</td><td>${prozent(k.abbruchquote)}</td><td class="muted">${E(k.abbrueche||0)} von ${E(k.austritte||0)} Austritten</td></tr>
        <tr><td>Erfolgsquote</td><td>${prozent(k.erfolgsquote)}</td><td class="muted">regulär beendet oder Arbeit aufgenommen</td></tr>
        <tr><td>Vermittlungsquote</td><td>${prozent(k.vermittlungsquote)}</td><td class="muted">${E(k.arbeitsaufnahme||0)} Arbeitsaufnahmen</td></tr>
        <tr><td>Anwesenheitsquote</td><td>${prozent(k.anwesenheitsquote)}</td><td class="muted">aus dem Klassenbuch</td></tr>
        <tr><td>Beschwerden</td><td>${E(k.beschwerden||0)}</td><td class="muted">${prozent(k.beschwerdequote)} bezogen auf ${E(k.eintritte||0)} Eintritte</td></tr>
      </table></div></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Qualitätsziele ${E(jahr)}</h3>${
        (ziele.ziele||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Ziel</th><th scope="col">Messgröße</th><th scope="col">Soll</th><th scope="col">Ist</th><th scope="col">Stand</th></tr>
        ${ziele.ziele.map(z=>`<tr><td>${E(z.bezeichnung)}</td><td>${E(Q_MESS[z.messgroesse]||z.messgroesse)}${z.gerechnet?'':' <span class="muted">(von Hand)</span>'}</td>`
          +`<td>${E(z.zielwert)}${z.messgroesse==='manuell'?'':' %'}</td><td>${z.istwert===null?'<span class="muted">keine Daten</span>':E(z.istwert)}</td>`
          +`<td>${z.erreicht===null?'—':(z.erreicht?'erreicht':'<strong>verfehlt</strong>')}</td></tr>`).join('')}</table></div>`
        :'<p class="muted">Noch kein Ziel festgelegt.</p>'}
        <form data-ziel><div class="row">
          <label class="field">Bezeichnung<input name="bezeichnung" required minlength="5"></label>
          <label class="field">Messgröße<select name="messgroesse">${Object.entries(Q_MESS).map(([kk,v])=>`<option value="${E(kk)}">${E(v)}</option>`).join('')}</select></label>
          <label class="field">Zielwert<input name="zielwert" type="number" step="0.1" required></label>
        </div><input type="hidden" name="jahr" value="${E(jahr)}">
        <div class="toolbar"><button class="btn" type="submit">Ziel festlegen</button></div></form></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Prozessregister</h3>${
        (prozesse.prozesse||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Schlüssel</th><th scope="col">Prozess</th><th scope="col">Art</th><th scope="col">zuletzt geprüft</th><th scope="col">nächste Prüfung</th><th scope="col">Aktion</th></tr>
        ${prozesse.prozesse.map(p=>`<tr><td><code>${E(p.schluessel)}</code></td><td>${E(p.bezeichnung)}</td><td>${E(Q_PART[p.art]||p.art)}</td>`
          +`<td>${E(p.letzte_pruefung_am||'—')}</td><td>${E(p.naechste_pruefung_am||'—')}</td>`
          +`<td><button class="btn secondary" type="button" data-qpr="${E(p.id)}">Prüfung bestätigen</button></td></tr>`).join('')}</table></div>`
        :'<p class="muted">Noch kein Prozess beschrieben. Die Prozesslandkarte ist das Erste, wonach die fachkundige Stelle fragt.</p>'}
        <form data-prozess><div class="row">
          <label class="field">Schlüssel<input name="schluessel" required placeholder="p-unterricht"></label>
          <label class="field">Bezeichnung<input name="bezeichnung" required minlength="5"></label>
          <label class="field">Art<select name="art">${Object.entries(Q_PART).map(([kk,v])=>`<option value="${E(kk)}">${E(v)}</option>`).join('')}</select></label>
          <label class="field">Prüfintervall (Monate)<input name="pruefintervall_monate" type="number" min="1" max="60" value="12"></label>
        </div><label class="field">Beschreibung<textarea name="beschreibung" rows="2"></textarea></label>
        <div class="toolbar"><button class="btn secondary" type="submit">Prozess aufnehmen</button></div></form></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Audits</h3>${
        (audits.audits||[]).length?`<div class="table-wrap"><table><tr><th scope="col">geplant</th><th scope="col">Art</th><th scope="col">Bezeichnung</th><th scope="col">Stand</th><th scope="col">Abweichungen</th><th scope="col">Aktion</th></tr>
        ${audits.audits.map(x=>`<tr><td>${E(x.geplant_am)}</td><td>${E(Q_AART[x.art]||x.art)}</td><td>${E(x.bezeichnung)}</td><td>${E(x.status)}</td>`
          +`<td>${Number(x.abweichungen)?`<strong>${E(x.abweichungen)}</strong>`:'0'}</td>`
          +`<td><button class="btn secondary" type="button" data-qau="${E(x.id)}">Öffnen</button></td></tr>`).join('')}</table></div>`
        :'<p class="muted">Kein Audit geplant.</p>'}
        <form data-audit><div class="row">
          <label class="field">Art<select name="art">${Object.entries(Q_AART).map(([kk,v])=>`<option value="${E(kk)}">${E(v)}</option>`).join('')}</select></label>
          <label class="field">Bezeichnung<input name="bezeichnung" required minlength="5"></label>
          <label class="field">geplant am<input name="geplant_am" type="date" required></label>
        </div><div class="toolbar"><button class="btn secondary" type="submit">Audit planen</button></div></form></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Zertifikate und Zulassungen</h3>${
        (zerts.zertifikate||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Art</th><th scope="col">Zertifizierer</th><th scope="col">gültig bis</th><th scope="col">nächste Überwachung</th><th scope="col">Stand</th></tr>
        ${zerts.zertifikate.map(z=>`<tr><td>${E(Q_ZART[z.art]||z.art)}</td><td>${E(z.zertifizierer)}</td><td>${E(z.gueltig_bis)}</td>`
          +`<td>${E(z.naechste_ueberwachung_am||'—')}</td><td>${z.status==='gueltig'?'gültig':`<strong>${E(z.status)}</strong>`}</td></tr>`).join('')}</table></div>`
        :'<p class="muted">Keine Zulassung hinterlegt. Eine abgelaufene Trägerzulassung heißt: keine Förderung mehr, ab dem Tag.</p>'}
        <form data-zert><div class="row">
          <label class="field">Art<select name="art">${Object.entries(Q_ZART).map(([kk,v])=>`<option value="${E(kk)}">${E(v)}</option>`).join('')}</select></label>
          <label class="field">Zertifizierer (fachkundige Stelle)<input name="zertifizierer" required minlength="3"></label>
        </div><div class="row">
          <label class="field">gültig von<input name="gueltig_von" type="date" required></label>
          <label class="field">gültig bis<input name="gueltig_bis" type="date" required></label>
          <label class="field">nächste Überwachung<input name="naechste_ueberwachung_am" type="date"></label>
        </div><div class="toolbar"><button class="btn secondary" type="submit">Zertifikat aufnehmen</button></div></form></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Managementbewertung ${E(jahr)}</h3>
        <p class="muted">Sie zieht ihre Eingaben zum Stichtag selbst aus dem Bestand und friert sie ein — eine Bewertung muss auch in zwei Jahren noch zeigen, worauf sie sich gestützt hat.</p>
        <div class="toolbar"><button class="btn secondary" type="button" data-qmb>Eingaben zusammenstellen</button></div>
        <div data-qmb-ziel></div></section>
      <p class="error" data-qerr role="alert"></p>`;
    const melde=x=>{host.querySelector('[data-qerr]').textContent=text(x);};
    const felder=f=>Object.fromEntries([...f.entries()].filter(([,v])=>String(v).trim()));
    const sende=(sel,weg,daten,methode='POST')=>{const f=host.querySelector(sel);if(f)f.onsubmit=async e=>{
      e.preventDefault();melde('');
      try{await api(q(weg),{method:methode,body:JSON.stringify(daten(new FormData(e.target)))});await qualitaet(host);}
      catch(x){melde(x);}};};
    sende('[data-ziel]','/api/quality/objectives',f=>({...felder(f),jahr:Number(f.get('jahr')),zielwert:Number(f.get('zielwert'))}));
    sende('[data-prozess]','/api/quality/processes',f=>({...felder(f),pruefintervall_monate:Number(f.get('pruefintervall_monate')||12)}));
    sende('[data-audit]','/api/quality/audits',felder);
    sende('[data-zert]','/api/quality/certifications',felder);
    host.querySelectorAll('[data-qpr]').forEach(b=>b.onclick=async()=>{
      const am=prompt('Wann wurde der Prozess geprüft? (JJJJ-MM-TT)',new Date().toISOString().slice(0,10));if(!am)return;
      try{await api(q(`/api/quality/processes/${encodeURIComponent(b.dataset.qpr)}/review`),{method:'POST',body:JSON.stringify({am})});await qualitaet(host);}
      catch(x){melde(x);}});
    host.querySelectorAll('[data-qau]').forEach(b=>b.onclick=()=>auditMappe(b.dataset.qau).catch(x=>melde(x)));
    const qmb=host.querySelector('[data-qmb]');
    if(qmb)qmb.onclick=async()=>{
      try{
        const d=await api(q('/api/quality/review'),{method:'POST',body:JSON.stringify({jahr})});
        const e2=d.eingaben;
        host.querySelector('[data-qmb-ziel]').innerHTML=`<div class="table-wrap"><table><caption>Eingaben zum Stichtag ${E(String(e2.stichtag).slice(0,10))}</caption>
          <tr><th scope="row">Ziele erreicht</th><td>${E((e2.ziele||[]).filter(z=>z.erreicht).length)} von ${E((e2.ziele||[]).length)}</td></tr>
          <tr><th scope="row">Audits</th><td>${E(e2.audits.abgeschlossen)} von ${E(e2.audits.gesamt)} abgeschlossen, ${E(e2.audits.abweichungen)} Abweichungen</td></tr>
          <tr><th scope="row">Maßnahmen</th><td>${E(e2.massnahmen.erledigt)} von ${E(e2.massnahmen.gesamt)} erledigt, ${E(e2.massnahmen.ueberfaellig)} überfällig</td></tr>
          <tr><th scope="row">Beschwerden</th><td>${E(e2.beschwerden.abgeschlossen)} von ${E(e2.beschwerden.gesamt)} abgeschlossen</td></tr>
          <tr><th scope="row">Prozesse</th><td>${E(e2.prozesse.gesamt)} geführt, ${E(e2.prozesse.ueberfaellig)} überfällig</td></tr>
        </table></div>
        <form data-qmb-text><label class="field">Bewertung (mindestens 50 Zeichen)<textarea name="bewertung" rows="4" required minlength="50"></textarea></label>
        <label class="field">Entscheidungen und Maßnahmen<textarea name="entscheidungen" rows="3" required minlength="20"></textarea></label>
        <div class="toolbar"><button class="btn" type="submit">Bewertung festhalten</button> <button class="btn secondary" type="button" data-qmb-ab>Abschließen</button></div></form>`;
        const f=host.querySelector('[data-qmb-text]');
        f.onsubmit=async ev=>{ev.preventDefault();
          try{await api(q('/api/quality/review'),{method:'POST',body:JSON.stringify({jahr,...felder(new FormData(ev.target))})});melde('');host.querySelector('[data-qerr]').textContent='Bewertung festgehalten.';}
          catch(x){melde(x);}};
        host.querySelector('[data-qmb-ab]').onclick=async()=>{
          try{await api(q('/api/quality/review'),{method:'PUT',body:JSON.stringify({jahr})});host.querySelector('[data-qerr]').textContent='Managementbewertung abgeschlossen.';}
          catch(x){melde(x);}};
      }catch(x){melde(x);}
    };
  }

  async function auditMappe(auditId){
    const w=modal('Audit','<p>Lädt …</p>','760px');
    const body=w.querySelector('[data-body]');
    async function zeichne(){
      const d=await api(q(`/api/quality/audits/${encodeURIComponent(auditId)}`));
      const a=d.audit;
      body.innerHTML=`<p><strong>${E(a.bezeichnung)}</strong> · ${E(Q_AART[a.art]||a.art)} · geplant ${E(a.geplant_am)} · Stand ${E(a.status)}</p>
        ${(d.feststellungen||[]).length?`<div class="table-wrap"><table><caption>Feststellungen</caption><thead><tr><th scope="col">Einstufung</th><th scope="col">Feststellung</th><th scope="col">Maßnahme</th></tr></thead><tbody>
          ${d.feststellungen.map(f=>`<tr><td>${E(Q_EIN[f.einstufung]||f.einstufung)}</td><td>${E(f.bezeichnung)}</td>`
            +`<td>${f.action_id?`${E(f.massnahme_status||'offen')}${f.massnahme_frist?` · bis ${E(String(f.massnahme_frist).slice(0,10))}`:''}`:'—'}</td></tr>`).join('')}
          </tbody></table></div>`:'<p class="muted">Noch keine Feststellung.</p>'}
        ${a.status!=='abgeschlossen'?`<form data-fest><div class="row">
          <label class="field">Einstufung<select name="einstufung">${Object.entries(Q_EIN).map(([kk,v])=>`<option value="${E(kk)}">${E(v)}</option>`).join('')}</select></label>
          <label class="field">Frist der Maßnahme<input name="frist_am" type="date"></label>
        </div><label class="field">Feststellung<textarea name="bezeichnung" rows="2" required minlength="10"></textarea></label>
        <label class="field">Maßnahme (bei Abweichungen)<textarea name="massnahme" rows="2"></textarea></label>
        <div class="toolbar"><button class="btn secondary" type="submit">Feststellung erfassen</button></div></form>
        <form data-abschluss><label class="field">Auditergebnis (mindestens 20 Zeichen)<textarea name="ergebnis" rows="3" required minlength="20"></textarea></label>
        <label class="field">durchgeführt am<input name="durchgefuehrt_am" type="date" required></label>
        <p class="muted">Abschließen geht erst, wenn zu jeder Abweichung eine erledigte Maßnahme vorliegt. Genau daran scheitern Träger im Überwachungsaudit.</p>
        <div class="toolbar"><button class="btn" type="submit">Audit abschließen</button></div></form>`:''}
        <p class="error" data-aerr role="alert"></p>`;
      const melde=x=>{body.querySelector('[data-aerr]').textContent=text(x);};
      const felder=f=>Object.fromEntries([...f.entries()].filter(([,v])=>String(v).trim()));
      const f1=body.querySelector('[data-fest]');
      if(f1)f1.onsubmit=async e=>{e.preventDefault();melde('');
        try{await api(q(`/api/quality/audits/${encodeURIComponent(auditId)}/findings`),{method:'POST',body:JSON.stringify(felder(new FormData(e.target)))});await zeichne();}
        catch(x){melde(x);}};
      const f2=body.querySelector('[data-abschluss]');
      if(f2)f2.onsubmit=async e=>{e.preventDefault();melde('');
        try{await api(q(`/api/quality/audits/${encodeURIComponent(auditId)}`),{method:'PUT',body:JSON.stringify(felder(new FormData(e.target)))});await zeichne();}
        catch(x){melde(x);}};
    }
    await zeichne();
  }

  // --- Vertrieb: vom Interessenten bis zum Vertrag.
  //
  // Alles vor dem Angebot lief in Outlook, in einer Tabelle und im Kopf einer Person — und mit
  // ihr ging es. "Gewonnen" lässt sich hier nicht behaupten: dafür muss ein Angebot angenommen
  // sein, sonst misst die Statistik die Zuversicht des Vertriebs.
  const V_STUFE={neu:'neu',qualifiziert:'qualifiziert',angebot:'Angebot',verhandlung:'Verhandlung',gewonnen:'gewonnen',verloren:'verloren'};
  const V_ART={betrieb:'Betrieb',kostentraeger:'Kostenträger',kammer:'Kammer',schule:'Schule',verband:'Verband',sonstige:'Sonstige'};
  const V_QUELLE={empfehlung:'Empfehlung',messe:'Messe',anfrage:'Anfrage',kaltakquise:'Kaltakquise',bestandskunde:'Bestandskunde',ausschreibung:'Ausschreibung',sonstige:'Sonstige'};
  const V_GRUND={preis:'Preis',termin:'Termin',anbieter:'anderer Anbieter',kein_bedarf:'kein Bedarf',kein_budget:'kein Budget',keine_rueckmeldung:'keine Rückmeldung',sonstiges:'Sonstiges'};
  const euro=c=>`${(Number(c||0)/100).toLocaleString('de-DE',{minimumFractionDigits:2,maximumFractionDigits:2})} €`;

  async function vertrieb(host){
    const jahr=new Date().getUTCFullYear();
    const [mappe,bericht]=await Promise.all([
      api(q('/api/sales/leads')),
      api(q('/api/sales/report',{von:`${jahr}-01-01`,bis:`${jahr}-12-31`}))]);
    const offen=(mappe.vorgaenge||[]).filter(v=>!['gewonnen','verloren'].includes(v.stufe));
    const ueberfaellig=offen.filter(v=>v.ueberfaellig);
    host.innerHTML=`${ueberfaellig.length?`<div class="notice error"><strong>${E(ueberfaellig.length)} Wiedervorlage(n) überfällig.</strong> Die Frage „was ist eigentlich aus der Anfrage geworden" hat noch nie jemand rechtzeitig gestellt.</div>`:''}
      <section class="card"><h3 style="margin-top:0">Trichter ${E(jahr)}</h3>
        <p class="muted">Gerechnet aus den Vorgängen selbst. „Gewonnen" heißt: es gibt ein angenommenes Angebot — nicht „sieht gut aus".</p>
        <div class="table-wrap"><table><tr><th scope="col">Vorgänge</th><th scope="col">mit Angebot</th><th scope="col">gewonnen</th><th scope="col">verloren</th><th scope="col">offen</th><th scope="col">Gewinnquote</th><th scope="col">gewonnener Wert</th></tr>
          <tr><td>${E(bericht.vorgaenge)}</td><td>${E(bericht.mit_angebot)}</td><td>${E(bericht.gewonnen)}</td><td>${E(bericht.verloren)}</td><td>${E(bericht.offen)}</td>
            <td>${bericht.gewinnquote===null?'<span class="muted">nichts entschieden</span>':`${E(bericht.gewinnquote)} %`}</td><td>${E(euro(bericht.gewonnen_cent))}</td></tr></table></div>
        ${(bericht.verlustgruende||[]).length?`<h4>Warum verloren</h4><ul>${bericht.verlustgruende.map(g=>`<li>${E(V_GRUND[g.grund]||g.grund)}: ${E(g.anzahl)}</li>`).join('')}</ul>`:''}
        ${(bericht.quellen||[]).length?`<h4>Woher die Vorgänge kommen</h4><div class="table-wrap"><table><tr><th scope="col">Quelle</th><th scope="col">Vorgänge</th><th scope="col">gewonnen</th></tr>
          ${bericht.quellen.map(x=>`<tr><td>${E(V_QUELLE[x.quelle]||x.quelle)}</td><td>${E(x.anzahl)}</td><td>${E(x.gewonnen)}</td></tr>`).join('')}</table></div>`:''}
      </section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Vorgänge</h3>${
        (mappe.vorgaenge||[]).length?`<div class="table-wrap"><table><tr><th scope="col">Organisation</th><th scope="col">Vorgang</th><th scope="col">Stufe</th><th scope="col">Wiedervorlage</th><th scope="col">nächster Schritt</th><th scope="col">Aktion</th></tr>
        ${mappe.vorgaenge.map(v=>`<tr><td>${E(v.organisation)}</td><td>${E(v.bezeichnung)}</td><td>${E(V_STUFE[v.stufe]||v.stufe)}</td>`
          +`<td>${v.wiedervorlage_am?(v.ueberfaellig?`<strong>${E(v.wiedervorlage_am)}</strong>`:E(v.wiedervorlage_am)):'—'}</td>`
          +`<td class="muted">${E(v.naechster_schritt||(v.verloren_grund?`verloren: ${V_GRUND[v.verloren_grund]||v.verloren_grund}`:''))}</td>`
          +`<td><button class="btn secondary" type="button" data-vlead="${E(v.id)}">Öffnen</button></td></tr>`).join('')}</table></div>`
        :'<p class="muted">Noch kein Vorgang erfasst.</p>'}</section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Organisation aufnehmen</h3>
        <form data-vorg><div class="row">
          <label class="field">Name<input name="name" required minlength="2"></label>
          <label class="field">Art<select name="art">${Object.entries(V_ART).map(([k,v])=>`<option value="${E(k)}">${E(v)}</option>`).join('')}</select></label>
          <label class="field">Ort<input name="ort"></label>
          <label class="field">Quelle<select name="quelle">${Object.entries(V_QUELLE).map(([k,v])=>`<option value="${E(k)}">${E(v)}</option>`).join('')}</select></label>
        </div><div class="toolbar"><button class="btn" type="submit">Organisation anlegen</button></div></form></section>
      <section class="card" style="margin-top:14px"><h3 style="margin-top:0">Vorgang anlegen</h3>
        <form data-vlead-neu><div class="row">
          <label class="field">Kennung der Organisation<input name="account_id" required></label>
          <label class="field">Bezeichnung<input name="bezeichnung" required minlength="5"></label>
          <label class="field">erwarteter Wert (€)<input name="wert_euro" type="number" min="0" step="0.01"></label>
        </div><div class="row">
          <label class="field">nächster Schritt<input name="naechster_schritt" required minlength="3" placeholder="Rückruf, Termin vereinbaren"></label>
          <label class="field">Wiedervorlage<input name="wiedervorlage_am" type="date" required></label>
        </div><p class="muted">Ein offener Vorgang ohne nächsten Schritt mit Datum ist ein vergessener Vorgang — deshalb sind beide Pflicht.</p>
        <div class="toolbar"><button class="btn" type="submit">Vorgang anlegen</button></div></form></section>
      <p class="error" data-verr role="alert"></p>`;
    const melde=x=>{host.querySelector('[data-verr]').textContent=text(x);};
    const felder=f=>Object.fromEntries([...f.entries()].filter(([,v])=>String(v).trim()));
    host.querySelector('[data-vorg]').onsubmit=async e=>{e.preventDefault();melde('');
      try{const r=await api(q('/api/sales/accounts'),{method:'POST',body:JSON.stringify(felder(new FormData(e.target)))});
        melde('');host.querySelector('[data-verr]').textContent=`Angelegt. Kennung: ${r.organisation.id}`;}
      catch(x){melde(x);}};
    host.querySelector('[data-vlead-neu]').onsubmit=async e=>{e.preventDefault();melde('');
      const f=new FormData(e.target),v=felder(f);
      if(v.wert_euro){v.erwarteter_wert_cent=Math.round(Number(v.wert_euro)*100);delete v.wert_euro;}
      try{await api(q('/api/sales/leads'),{method:'POST',body:JSON.stringify(v)});await vertrieb(host);}
      catch(x){melde(x);}};
    host.querySelectorAll('[data-vlead]').forEach(b=>b.onclick=()=>vorgang(b.dataset.vlead).catch(x=>melde(x)));
  }

  async function vorgang(leadId){
    const w=modal('Vertriebsvorgang','<p>Lädt …</p>','820px');
    const body=w.querySelector('[data-body]');
    async function zeichne(){
      const d=await api(q(`/api/sales/leads/${encodeURIComponent(leadId)}`));
      const v=d.vorgang,offen=!['gewonnen','verloren'].includes(v.stufe);
      let fassungen=[];
      if(v.offer_id)fassungen=(await api(q(`/api/course-offers/${encodeURIComponent(v.offer_id)}/versions`)).catch(()=>({fassungen:[]}))).fassungen||[];
      body.innerHTML=`<p><strong>${E(d.organisation?.name||'')}</strong> · ${E(v.bezeichnung)} · Stufe ${E(V_STUFE[v.stufe]||v.stufe)}
        ${v.wiedervorlage_am?` · Wiedervorlage ${E(v.wiedervorlage_am)}`:''}</p>
        ${v.naechster_schritt?`<p class="muted">Nächster Schritt: ${E(v.naechster_schritt)}</p>`:''}
        ${fassungen.length>1?`<h4>Angebotsfassungen</h4><div class="table-wrap"><table><caption>Was wann angeboten wurde</caption><thead><tr><th scope="col">Fassung</th><th scope="col">Summe</th><th scope="col">Stand</th><th scope="col">Grund der Verhandlung</th></tr></thead><tbody>
          ${fassungen.map(f=>`<tr><th scope="row">${E(f.fassung)}</th><td>${E(euro(f.summe_cent))}</td><td>${E(f.status)}</td><td class="muted">${E(f.verhandlungsgrund||'—')}</td></tr>`).join('')}
          </tbody></table></div><p class="muted">Eine Nachverhandlung überschreibt nichts. Was ursprünglich angeboten wurde, ist genau die Frage, die im Streit gestellt wird.</p>`:''}
        <h4>Verlauf</h4>${(d.aktivitaeten||[]).length?`<div class="table-wrap"><table><caption>Kontakthistorie</caption><thead><tr><th scope="col">Datum</th><th scope="col">Art</th><th scope="col">Notiz</th></tr></thead><tbody>
          ${d.aktivitaeten.map(x=>`<tr><th scope="row">${E(x.am)}</th><td>${E(x.art)}</td><td>${E(x.text)}</td></tr>`).join('')}</tbody></table></div>`
          :'<p class="muted">Noch kein Kontakt festgehalten.</p>'}
        ${offen?`<form data-vakt><div class="row">
          <label class="field">Art<select name="art"><option value="anruf">Anruf</option><option value="email">E-Mail</option><option value="termin">Termin</option><option value="notiz">Notiz</option></select></label>
          <label class="field">am<input name="am" type="date"></label>
          <label class="field">neue Wiedervorlage<input name="wiedervorlage_am" type="date"></label>
        </div><label class="field">Notiz<textarea name="text" rows="2" required minlength="3"></textarea></label>
        <label class="field">nächster Schritt<input name="naechster_schritt"></label>
        <div class="toolbar"><button class="btn secondary" type="submit">Kontakt festhalten</button></div></form>
        <h4>Stand ändern</h4>
        <form data-vstufe><div class="row">
          <label class="field">Stufe<select name="stufe"><option value="qualifiziert">qualifiziert</option><option value="angebot">Angebot</option><option value="verhandlung">Verhandlung</option><option value="verloren">verloren</option></select></label>
          <label class="field">Wiedervorlage<input name="wiedervorlage_am" type="date"></label>
          <label class="field">Verlustgrund<select name="verloren_grund"><option value="">—</option>${Object.entries(V_GRUND).map(([k,g])=>`<option value="${E(k)}">${E(g)}</option>`).join('')}</select></label>
        </div><label class="field">nächster Schritt / Notiz zum Verlust<input name="naechster_schritt"></label>
        <div class="toolbar"><button class="btn secondary" type="submit">Stand festhalten</button></div></form>
        <h4>Angebot</h4>
        <form data-vangebot><div class="row"><label class="field">Kennung des Angebots<input name="offer_id" required></label></div>
        <div class="toolbar"><button class="btn secondary" type="submit">Angebot zuordnen</button></div></form>
        ${v.offer_id?`<form data-vwin><p class="muted">Gewinnen geht erst, wenn das zugeordnete Angebot angenommen ist.</p>
          <div class="toolbar"><button class="btn" type="submit" data-vwin-btn>Als gewonnen festhalten</button></div></form>`:''}`:''}
        <p class="error" data-aerr role="alert"></p>`;
      const melde=x=>{body.querySelector('[data-aerr]').textContent=text(x);};
      const felder=f=>Object.fromEntries([...f.entries()].filter(([,v2])=>String(v2).trim()));
      const sende=(sel,weg,daten,methode='POST')=>{const f=body.querySelector(sel);if(f)f.onsubmit=async e=>{
        e.preventDefault();melde('');
        try{await api(q(weg),{method:methode,body:JSON.stringify(daten(new FormData(e.target)))});await zeichne();}
        catch(x){melde(x);}};};
      sende('[data-vakt]',`/api/sales/leads/${encodeURIComponent(leadId)}/activities`,felder);
      sende('[data-vstufe]',`/api/sales/leads/${encodeURIComponent(leadId)}`,felder,'PATCH');
      sende('[data-vangebot]',`/api/sales/leads/${encodeURIComponent(leadId)}/offer`,felder);
      const win=body.querySelector('[data-vwin-btn]');
      if(win)win.onclick=async e=>{e.preventDefault();melde('');
        try{await api(q(`/api/sales/leads/${encodeURIComponent(leadId)}/win`),{method:'POST',body:'{}'});await zeichne();}
        catch(x){melde(x);}};
    }
    await zeichne();
  }

  const TABS=[
    {key:'kursnet',label:'KURSNET',render:kursnet},
    {key:'zulassung',label:'Bewerbungen',render:zulassung},
    {key:'betrieb',label:'Regeln & Zuordnungen',render:betrieb},
    {key:'noten',label:'Notenliste',render:noten},
    {key:'personal',label:'Personal',render:personal},
    {key:'qualitaet',label:'Qualität',render:qualitaet},
    {key:'vertrieb',label:'Vertrieb',render:vertrieb},
    {key:'berichte',label:'Berichte & Reife',render:berichte},
  ];

  async function open(){
    const w=modal('Betrieb & Meldungen',`<div class="row" data-tabs style="gap:8px;margin-bottom:12px">${TABS.map((t,i)=>`<button class="btn ${i?'secondary':''}" data-tab="${E(t.key)}">${E(t.label)}</button>`).join('')}</div><div data-host><p class="muted">Wird geladen …</p></div>`);
    const host=w.querySelector('[data-host]');
    async function zeige(key){
      w.querySelectorAll('[data-tab]').forEach(b=>b.className=`btn ${b.dataset.tab===key?'':'secondary'}`);
      host.dataset.kurs='';host.innerHTML='<p class="muted">Wird geladen …</p>';
      try{await TABS.find(t=>t.key===key).render(host);}
      catch(x){host.innerHTML=`<div class="notice error">${E(text(x))}</div>`;}
    }
    w.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>void zeige(b.dataset.tab));
    await zeige('kursnet');
  }

  async function ensureNav(){
    if(navBusy)return;navBusy=true;
    try{
      const side=document.querySelector('.side');
      if(!side||!tid()||side.querySelector('#kp-operations-nav'))return;
      const b=document.createElement('button');
      b.type='button';b.className='nav';b.id='kp-operations-nav';b.textContent='Betrieb & Meldungen';
      b.onclick=open;
      const anchor=side.querySelector('#kp-finance-nav')||side.querySelector('[data-v="modules"]');
      anchor?.after(b)||side.append(b);
    }catch{}finally{navBusy=false;}
  }
  document.addEventListener('change',e=>{if(e.target?.id==='tenantPick')setTimeout(ensureNav,50);});
  new MutationObserver(()=>queueMicrotask(ensureNav)).observe(document.querySelector('#app')||document.body,{subtree:true,childList:true});
  void ensureNav();
}

// Medienbibliothek: Lizenzen, Fundstellen und Barrierefreiheit.
//
// Die wichtigste Spalte ist nicht die Dateigröße, sondern „verwendbar“: ein Video ohne
// geprüften Untertitel ist kein Angebot, und ein Bild mit abgelaufener Lizenz ist ein Risiko.
const ML=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ML_LIZ=[['eigenes_werk','Eigenes Werk'],['cc0','CC0'],['cc_by','CC BY'],['cc_by_sa','CC BY-SA'],['cc_by_nc','CC BY-NC (nur nicht-kommerziell)'],['gemeinfrei','Gemeinfrei'],['lizenziert','Eingekauft'],['unklar','Herkunft ungeklärt']];
const ML_ART=[['bild','Bild'],['video','Video'],['audio','Audio'],['dokument','Dokument']];
const ML_ZWECK=[['unterricht','Unterricht'],['oeffentlich','Öffentlich'],['druck','Druck']];
async function mlApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const mlText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
const mlGroesse=b=>{const n=Number(b||0);return n>1048576?`${(n/1048576).toFixed(1)} MB`:`${Math.round(n/1024)} kB`;};
function mlModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="ml-titel" style="width:min(1020px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="ml-titel" style="margin:0">${ML(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="ml-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#ml-body'),zu};
}

async function mlBibliothek(tenantId){
  const {body}=mlModal('Medienbibliothek');
  async function render(art=''){
    let d,l;
    try{d=await mlApi(`/api/media?tenant_id=${encodeURIComponent(tenantId)}${art?`&art=${encodeURIComponent(art)}`:''}`);
      l=await mlApi(`/api/media/licence-check?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${ML(mlText(e.message))}</div>`;return;}
    const warnung=(l.abgelaufen||[]).length||(l.laeuft_ab||[]).length
      ? `<div class="notice bad"><strong>Lizenzen:</strong> ${ML(String((l.abgelaufen||[]).length))} abgelaufen, ${ML(String((l.laeuft_ab||[]).length))} laufen bald ab.`
        +`<ul>${[...(l.abgelaufen||[]),...(l.laeuft_ab||[])].map(x=>`<li>${ML(x.titel)} (bis ${ML(x.lizenz_bis)}) — verwendet in: ${ML((x.fundstellen||[]).map(f=>`${f.objekt_typ}/${f.objekt_id}`).join(', ')||'nirgends')}</li>`).join('')}</ul></div>`
      : '<div class="notice good">Keine Lizenz läuft in den nächsten 30 Tagen ab.</div>';
    const zeilen=(d.medien||[]).map(m=>`<tr><th scope="row">${ML(m.titel)}</th><td>${ML(m.art)}</td><td>${ML(mlGroesse(m.groesse_bytes))}</td>`
      +`<td>${ML(m.lizenz)}${m.urheber?` — ${ML(m.urheber)}`:''}${m.lizenz_bis?`<br>bis ${ML(m.lizenz_bis)}`:''}</td>`
      +`<td>${ML((JSON.parse(m.verwendung_json||'[]')||[]).join(', '))}</td>`
      +`<td>${ML(String(m.verwendungen))}</td>`
      +`<td>${m.barrierefrei?'ja':'<strong>nein</strong>'}</td>`
      +`<td>${ML(m.status)}</td>`
      +`<td><button class="btn secondary ml-spur" type="button" data-id="${ML(m.id)}">Spuren</button> <button class="btn secondary ml-weg" type="button" data-id="${ML(m.id)}">Entfernen</button></td></tr>`).join('')
      ||'<tr><td colspan="9">Noch kein Medium in der Bibliothek.</td></tr>';
    body.innerHTML=warnung
      +`<div class="toolbar"><label class="field">Art<select id="ml-filter"><option value="">alle</option>${ML_ART.map(([k,t])=>`<option value="${ML(k)}"${k===art?' selected':''}>${ML(t)}</option>`).join('')}</select></label></div>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Medien</caption><thead><tr><th scope="col">Titel</th><th scope="col">Art</th><th scope="col">Größe</th><th scope="col">Lizenz</th><th scope="col">Erlaubt für</th><th scope="col">Verwendet</th><th scope="col">Barrierefrei</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<form id="ml-neu"><h4>Medium aufnehmen</h4><label class="field">Titel<input name="titel" required></label>`
      +`<label class="field">Art<select name="art">${ML_ART.map(([k,t])=>`<option value="${ML(k)}">${ML(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Ablageschlüssel (R2)<input name="r2_key" required></label><label class="field">Prüfsumme (SHA-256)<input name="sha256" required></label>`
      +`<label class="field">Dateiname<input name="dateiname"></label><label class="field">Inhaltstyp<input name="content_type" value="application/octet-stream"></label>`
      +`<label class="field">Größe in Byte<input name="groesse_bytes" type="number" min="1" required></label>`
      +`<label class="field">Lizenz<select name="lizenz">${ML_LIZ.map(([k,t])=>`<option value="${ML(k)}">${ML(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Urheber / Quelle<input name="urheber"></label><label class="field">Beleg (Rechnung, Link)<input name="lizenz_quelle"></label>`
      +`<label class="field">Lizenz läuft bis<input name="lizenz_bis" type="date"></label>`
      +`<fieldset><legend>Erlaubt für</legend>${ML_ZWECK.map(([k,t])=>`<label><input type="checkbox" name="verwendung" value="${ML(k)}"${k==='unterricht'?' checked':''}> ${ML(t)}</label>`).join(' ')}</fieldset>`
      +`<div class="toolbar"><button class="btn" type="submit">Aufnehmen</button></div></form><p class="error" id="ml-err" role="alert"></p><div id="ml-out"></div>`;
    const fehler=e=>{body.querySelector('#ml-err').textContent=mlText(e.message);};
    body.querySelector('#ml-filter').onchange=ev=>render(ev.target.value);
    body.querySelector('#ml-neu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target),daten={verwendung:f.getAll('verwendung').map(String)};
      for(const [k,v] of f.entries())if(k!=='verwendung'&&String(v).trim())daten[k]=k==='groesse_bytes'?Number(v):String(v).trim();
      try{await mlApi(`/api/media?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(daten)});await render(art);}
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.ml-spur').forEach(b=>b.onclick=()=>mlSpuren(tenantId,b.dataset.id,()=>render(art)));
    body.querySelectorAll('.ml-weg').forEach(b=>b.onclick=async()=>{
      if(!confirm('Medium entfernen?'))return;
      try{await mlApi(`/api/media/${encodeURIComponent(b.dataset.id)}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'DELETE'});await render(art);}
      catch(e){fehler(e);}
    });
  }
  await render();
}

async function mlSpuren(tenantId,assetId,zurueck){
  const {body}=mlModal('Untertitel, Transkript, Audiodeskription');
  body.innerHTML=`<p class="muted">Eine automatische Untertitelung mit Fehlern ist schlimmer als keine: sie sieht aus wie ein Angebot und ist keines. Erst die Prüfung macht sie zu einer.</p>`
    +`<form id="ml-sp"><label class="field">Art<select name="art"><option value="untertitel">Untertitel</option><option value="transkript">Transkript</option><option value="audiodeskription">Audiodeskription</option><option value="uebersetzung">Übersetzung</option></select></label>`
    +`<label class="field">Sprache<input name="sprache" value="de" required></label>`
    +`<label class="field">Herkunft<select name="quelle"><option value="manuell">Selbst erstellt</option><option value="ki">Automatisch erzeugt</option><option value="import">Importiert</option></select></label>`
    +`<label class="field">Inhalt<textarea name="inhalt" rows="5"></textarea></label>`
    +`<label class="field">Oder Ablageschlüssel (R2)<input name="r2_key"></label>`
    +`<div class="toolbar"><button class="btn" type="submit">Speichern</button> <button class="btn secondary" type="button" id="ml-frei">Vorhandene Spur prüfen und freigeben</button></div></form>`
    +`<p class="error" id="ml-serr" role="alert"></p><p id="ml-sinfo" class="muted" role="status"></p>`;
  const fehler=e=>{body.querySelector('#ml-serr').textContent=mlText(e.message);};
  body.querySelector('#ml-sp').onsubmit=async ev=>{
    ev.preventDefault();const f=new FormData(ev.target),daten={};
    for(const [k,v] of f.entries())if(String(v).trim())daten[k]=String(v).trim();
    try{const r=await mlApi(`/api/media/${encodeURIComponent(assetId)}/tracks?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(daten)});
      body.querySelector('#ml-sinfo').textContent=r.geprueft?'Gespeichert und gilt als geprüft.':'Gespeichert — gilt erst nach der Prüfung als barrierefrei.';
      zurueck?.();}
    catch(e){fehler(e);}
  };
  body.querySelector('#ml-frei').onclick=async()=>{
    const f=new FormData(body.querySelector('#ml-sp'));
    try{await mlApi(`/api/media/${encodeURIComponent(assetId)}/tracks/approve?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
      body:JSON.stringify({art:String(f.get('art')),sprache:String(f.get('sprache'))})});
      body.querySelector('#ml-sinfo').textContent='Spur geprüft und freigegeben.';zurueck?.();}
    catch(e){fehler(e);}
  };
}

(async()=>{
  let me=null;try{me=(await mlApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const verwaltung=me.isPlatformAdmin||roles.some(x=>['tenant_admin','class_admin'].includes(x.role));
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId||!verwaltung)return;
    const seite=document.querySelector('.side');
    if(!seite)return;
    const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
    knopf('ml-bibliothek-launch','Medienbibliothek',()=>mlBibliothek(tenantId),anker,'nav');
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

// Prüfungsplanung: Raum, Aufsicht, Zeit.
//
// Der Plan sagt ehrlich, was vor der Freigabe noch fehlt. Freigegeben wird nur, was am
// Prüfungstag auch durchführbar ist — Raum frei, Aufsicht eingeteilt, Zeit lang genug für den
// längsten bewilligten Zeitzuschlag.
const PS=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const PS_ROLLEN=[['aufsicht','Aufsicht'],['pruefungsleitung','Prüfungsleitung'],['ergaenzende_aufsicht','Ergänzende Aufsicht']];
async function psApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const psText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
const psZeit=v=>{const d=new Date(String(v));return Number.isNaN(d.getTime())?String(v??''):d.toLocaleString('de-DE',{dateStyle:'short',timeStyle:'short'});};
function psModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="ps-titel" style="width:min(1000px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="ps-titel" style="margin:0">${PS(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="ps-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#ps-body'),zu};
}

// Was "offen" meldet, ist keine Warnung nebenbei: genau daran scheitert die Freigabe.
const PS_OFFEN={
  PRUEFPLAN_KEINE_TEILNEHMER:'Noch niemand eingeteilt',
  PRUEFPLAN_AUFSICHT_FEHLT:'Keine Aufsicht eingeteilt',
  PRUEFPLAN_AUFSICHT_UNBESTAETIGT:'Aufsicht hat noch nicht bestätigt',
  PRUEFPLAN_ZEIT_ZU_KURZ:'Raum zu kurz gebucht (Zeitzuschlag)',
  PRUEFPLAN_KEINE_SITZUNG:'Für diese Prüfung ist noch kein Raum geplant'
};

async function psPlan(tenantId){
  const {body}=psModal('Prüfungsplanung: Raum, Aufsicht, Zeit');
  body.innerHTML=`<p class="muted">Freigegeben wird nur, was durchführbar ist. Was hier unter „Offen“ steht, verhindert die Freigabe.</p>`
    +`<form id="ps-lade"><label class="field">Prüfung (Kennung)<input name="exam_id" required></label><div class="toolbar"><button class="btn" type="submit">Plan anzeigen</button></div><p class="error" id="ps-err" role="alert"></p></form><div id="ps-out"></div>`;
  let aktuelleP='';
  body.querySelector('#ps-lade').onsubmit=async ev=>{ev.preventDefault();aktuelleP=String(new FormData(ev.target).get('exam_id'));await zeige();};
  async function zeige(){
    body.querySelector('#ps-err').textContent='';
    try{
      const d=await psApi(`/api/exams/${encodeURIComponent(aktuelleP)}/sittings?tenant_id=${encodeURIComponent(tenantId)}`);
      const offenListe=(d.offen||[]).map(o=>{const [code,sid]=String(o).split(':');return`<li>${PS(PS_OFFEN[code]||psText(code))}${sid?` <span class="muted">(${PS(sid)})</span>`:''}</li>`;}).join('');
      const zeilen=(d.sitzungen||[]).map(z=>`<tr><th scope="row">${PS(z.raum)}</th><td>${PS(psZeit(z.beginnt_am))} – ${PS(psZeit(z.endet_am))}</td><td>${PS(String((z.teilnehmer||[]).length))} / ${PS(String(z.plaetze))}</td>`
        +`<td>${(z.aufsicht||[]).map(a=>`${PS(a.display_name)}${a.bestaetigt_am?' ✓':' (offen)'}`).join(', ')||'—'}</td><td>${PS(z.status)}</td>`
        +`<td><button class="btn secondary ps-auf" type="button" data-id="${PS(z.id)}">Aufsicht</button> <button class="btn secondary ps-sitz" type="button" data-id="${PS(z.id)}">Plätze</button>`
        +`${z.status==='entwurf'?` <button class="btn ps-frei" type="button" data-id="${PS(z.id)}">Freigeben</button>`:''}</td></tr>`).join('')
        ||'<tr><td colspan="6">Für diese Prüfung ist noch kein Raum geplant.</td></tr>';
      body.querySelector('#ps-out').innerHTML=`<div style="overflow-x:auto"><table class="table"><caption>Sitzungen dieser Prüfung</caption><thead><tr><th scope="col">Raum</th><th scope="col">Zeit</th><th scope="col">Belegt</th><th scope="col">Aufsicht</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
        +(offenListe?`<div class="notice bad"><strong>Offen vor der Freigabe</strong><ul>${offenListe}</ul></div>`:'<div class="notice good">Nichts offen.</div>')
        +`<form id="ps-neu"><h4>Sitzung anlegen</h4><label class="field">Raum (Ressourcen-Kennung)<input name="resource_id" required></label>`
        +`<label class="field">Beginn<input name="beginnt_am" type="datetime-local" required></label><label class="field">Ende<input name="endet_am" type="datetime-local" required></label>`
        +`<label class="field">Plätze<input name="plaetze" type="number" min="1" max="400" value="20" required></label>`
        +`<label class="field">Art<select name="art"><option value="regulaer">Regulär</option><option value="einzelraum">Einzelraum (Nachteilsausgleich)</option><option value="nachholtermin">Nachholtermin</option></select></label>`
        +`<div class="toolbar"><button class="btn" type="submit">Anlegen</button></div></form><p id="ps-info" class="muted" role="status"></p>`;
      const melde=t=>{body.querySelector('#ps-info').textContent=t;};
      body.querySelector('#ps-neu').onsubmit=async ev=>{
        ev.preventDefault();const f=new FormData(ev.target);
        try{await psApi(`/api/exam-sittings?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({exam_id:aktuelleP,resource_id:String(f.get('resource_id')),
          beginnt_am:new Date(String(f.get('beginnt_am'))).toISOString(),endet_am:new Date(String(f.get('endet_am'))).toISOString(),
          plaetze:Number(f.get('plaetze')),art:String(f.get('art'))})});
          await zeige();melde('Sitzung angelegt.');}
        catch(e){body.querySelector('#ps-err').textContent=psText(e.message);}
      };
      body.querySelectorAll('.ps-frei').forEach(b=>b.onclick=async()=>{
        try{const r=await psApi(`/api/exam-sittings/${encodeURIComponent(b.dataset.id)}/release?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
          await zeige();melde(`Freigegeben für ${r.teilnehmer} Prüflinge.`);}
        catch(e){body.querySelector('#ps-err').textContent=psText(e.message);}
      });
      body.querySelectorAll('.ps-auf').forEach(b=>b.onclick=async()=>{
        const person=prompt('Kennung der Aufsicht:');if(!person)return;
        const rolle=prompt(`Rolle (${PS_ROLLEN.map(r=>r[0]).join(' / ')}):`,'aufsicht')||'aufsicht';
        try{await psApi(`/api/exam-sittings/${encodeURIComponent(b.dataset.id)}/supervisors?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({user_id:person,rolle})});
          await zeige();melde('Aufsicht eingeteilt.');}
        catch(e){body.querySelector('#ps-err').textContent=psText(e.message);}
      });
      body.querySelectorAll('.ps-sitz').forEach(b=>b.onclick=async()=>{
        const roh=prompt('Kennungen der Prüflinge, durch Komma getrennt:');if(!roh)return;
        try{const r=await psApi(`/api/exam-sittings/${encodeURIComponent(b.dataset.id)}/seats?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',
          body:JSON.stringify({user_ids:roh.split(',').map(s=>s.trim()).filter(Boolean)})});
          await zeige();melde(`${r.besetzt} von ${r.plaetze} Plätzen besetzt.`);}
        catch(e){body.querySelector('#ps-err').textContent=psText(e.message);}
      });
    }catch(e){body.querySelector('#ps-err').textContent=psText(e.message);}
  }
}

// Eigene Aufsichten: eingeteilt ist nicht zugesagt — bestätigt wird selbst.
async function psMeineAufsichten(tenantId){
  const {body}=psModal('Meine Prüfungsaufsichten');
  async function render(){
    let d;try{d=await psApi(`/api/personal/exam-supervisions?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${PS(psText(e.message))}</div>`;return;}
    const zeilen=(d.sitzungen||[]).map(z=>`<tr><th scope="row">${PS(z.title)}</th><td>${PS(z.raum)}</td><td>${PS(psZeit(z.beginnt_am))}</td><td>${PS(z.rolle)}</td>`
      +`<td>${z.bestaetigt_am?'bestätigt':'<span class="muted">offen</span>'}</td>`
      +`<td>${z.bestaetigt_am?'':`<button class="btn ps-ok" type="button" data-id="${PS(z.id)}">Bestätigen</button>`}</td></tr>`).join('')
      ||'<tr><td colspan="6">Sie sind derzeit für keine Prüfung als Aufsicht eingeteilt.</td></tr>';
    body.innerHTML=`<p class="muted">Eine eingeteilte, aber nicht bestätigte Aufsicht ist eine Planungsannahme — keine Zusage.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Meine Aufsichten</caption><thead><tr><th scope="col">Prüfung</th><th scope="col">Raum</th><th scope="col">Beginn</th><th scope="col">Rolle</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div><p id="ps-mi" class="muted" role="status"></p>`;
    body.querySelectorAll('.ps-ok').forEach(b=>b.onclick=async()=>{
      try{await psApi(`/api/exam-sittings/${encodeURIComponent(b.dataset.id)}/confirm?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await render();}
      catch(e){body.querySelector('#ps-mi').textContent=psText(e.message);}
    });
  }
  await render();
}

(async()=>{
  let me=null;try{me=(await psApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const verwaltung=me.isPlatformAdmin||roles.some(x=>['tenant_admin','class_admin'].includes(x.role));
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(seite&&verwaltung){
      const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
      knopf('ps-plan-launch','Prüfungsplanung',()=>psPlan(tenantId),anker,'nav');
    }
    const portal=document.querySelector('.portal-main');
    if(portal&&!document.querySelector('#ps-portal-btn')){
      const b=document.createElement('button');b.id='ps-portal-btn';b.type='button';b.className='portal-btn secondary';b.textContent='Meine Prüfungsaufsichten';
      b.onclick=()=>psMeineAufsichten(tenantId).catch(e=>alert(psText(e.message)));
      (document.querySelector('#gs-portal-buttons')||portal).append(b);
    }
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

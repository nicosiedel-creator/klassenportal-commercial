// Schuljahr/Periode und Termine in der Oberfläche.
//
// Bisher führte jeder Bereich seine eigene Zeit: ein verschobener Unterricht änderte den
// Stundenplan, das Klassenbuch blieb am alten Tag stehen. Hier entsteht der Termin einmal — und
// Anwesenheit, Kalender und Prüfungstermin hängen daran.
const SC=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function scApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const scText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
const SC_ART={unterricht:'Unterricht',pruefung:'Prüfung',veranstaltung:'Veranstaltung',beratung:'Beratung',termin:'Termin',abgabe:'Abgabe',sonstiges:'Sonstiges'};
const SC_PERIODENART={schuljahr:'Schuljahr',semester:'Semester',trimester:'Trimester',quartal:'Quartal',block:'Block',massnahme:'Maßnahme'};

async function scOeffnen(tenantId,courses){
  const w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" style="width:min(980px,97vw);max-height:93vh;overflow:auto"><div class="top"><div><h3 style="margin:0">Schuljahr & Termine</h3><div class="muted">Ein Termin, aus dem Klassenbuch, Anwesenheit und Kalender entstehen.</div></div><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div class="row" id="sc-tabs"><button class="btn secondary sc-tab" data-t="perioden">Schuljahre & Zeiträume</button><button class="btn secondary sc-tab" data-t="termine">Termine</button></div><div id="sc-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>w.remove();w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  const body=w.querySelector('#sc-body');
  let kurs=courses[0]?.id||'';
  w.querySelectorAll('.sc-tab').forEach(b=>b.onclick=()=>zeichne(b.dataset.t));

  async function perioden(){
    const d=await scApi(`/api/schedule/periods?tenant_id=${encodeURIComponent(tenantId)}`);
    const rows=d.periods||[],jetzt=d.current;
    body.innerHTML=`<p class="muted">Ohne Zeitraum hängt jede Auswertung in der Luft: „die Klassen dieses Schuljahres" ist sonst nicht zu beantworten. Genau <strong>ein</strong> Zeitraum ist der laufende.</p>`
      +`<form id="sc-neu"><div class="row"><label class="field">Name<input name="name" required placeholder="Schuljahr 2026/27"></label>`
      +`<label class="field">Art<select name="art">${Object.entries(SC_PERIODENART).map(([k,v])=>`<option value="${SC(k)}">${SC(v)}</option>`).join('')}</select></label></div>`
      +`<div class="row"><label class="field">Beginn<input name="starts_on" type="date" required></label><label class="field">Ende<input name="ends_on" type="date" required></label></div>`
      +`<button class="btn">Zeitraum anlegen</button></form><div id="sc-err"></div>`
      +(rows.length?rows.map(p=>`<div class="item"><strong>${SC(p.name)}</strong> <span class="pill">${SC(SC_PERIODENART[p.art]||p.art)}</span>${Number(p.ist_aktuell)?' <span class="pill">laufend</span>':''}`
        +`<div class="muted">${SC(p.starts_on)} bis ${SC(p.ends_on)} · ${SC(p.kurse)} Kurse · ${SC(p.termine)} Termine</div>`
        +(Number(p.ist_aktuell)?'':`<button class="btn secondary sc-akt" data-id="${SC(p.id)}">Als laufend setzen</button>`)
        +(courses.length?`<form class="sc-zuordnen" data-id="${SC(p.id)}"><label class="field">Kurs zuordnen<select name="course_id">${courses.map(c=>`<option value="${SC(c.id)}">${SC(c.name)}</option>`).join('')}</select></label><button class="btn secondary">Zuordnen</button></form>`:'')
        +`</div>`).join(''):'<p class="muted">Noch kein Zeitraum angelegt.</p>')
      +(jetzt?`<p class="muted">Laufend: <strong>${SC(jetzt.name)}</strong></p>`:'<p class="muted">Es ist kein Zeitraum als laufend gesetzt – dann gilt der, in den das heutige Datum fällt.</p>');
    const tun=async fn=>{try{await fn();await perioden();}catch(err){const k=body.querySelector('#sc-err');const t=scText(err.message);if(k)k.innerHTML=`<div class="notice bad">${SC(t)}</div>`;else alert(t);}};
    body.querySelector('#sc-neu').onsubmit=e=>{e.preventDefault();const f=Object.fromEntries(new FormData(e.currentTarget));
      tun(()=>scApi(`/api/schedule/periods?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(f)}));};
    body.querySelectorAll('.sc-akt').forEach(b=>b.onclick=()=>tun(()=>scApi(`/api/schedule/periods/${encodeURIComponent(b.dataset.id)}/current?tenant_id=${encodeURIComponent(tenantId)}`,{method:'PUT',body:'{}'})));
    body.querySelectorAll('.sc-zuordnen').forEach(f=>f.onsubmit=e=>{e.preventDefault();const c=new FormData(f).get('course_id');
      tun(()=>scApi(`/api/schedule/courses/${encodeURIComponent(c)}/period?tenant_id=${encodeURIComponent(tenantId)}`,{method:'PUT',body:JSON.stringify({period_id:f.dataset.id})}));});
  }

  async function termine(){
    const von=new Date().toISOString(),bis=new Date(Date.now()+7776000000).toISOString();
    const d=await scApi(`/api/schedule/events?tenant_id=${encodeURIComponent(tenantId)}${kurs?`&course_id=${encodeURIComponent(kurs)}`:''}&von=${encodeURIComponent(von)}&bis=${encodeURIComponent(bis)}`);
    const rows=d.events||[];
    body.innerHTML=(courses.length>1?`<label class="field">Kurs<select id="sc-kurs">${courses.map(c=>`<option value="${SC(c.id)}" ${c.id===kurs?'selected':''}>${SC(c.name)}</option>`).join('')}</select></label>`:'')
      +`<p class="muted">Ein Termin mit erwarteter Anwesenheit erzeugt die Klassenbucheinheit gleich mit. Wird er verschoben, zieht sie mit – das ist der Unterschied zu zwei getrennten Einträgen.</p>`
      +`<form id="sc-termin"><div class="row"><label class="field">Art<select name="art">${Object.entries(SC_ART).map(([k,v])=>`<option value="${SC(k)}">${SC(v)}</option>`).join('')}</select></label>`
      +`<label class="field">Titel<input name="titel" required></label></div>`
      +`<div class="row"><label class="field">Beginn<input name="starts_at" type="datetime-local" required></label><label class="field">Ende<input name="ends_at" type="datetime-local" required></label></div>`
      +`<div class="row"><label class="field">Raum<input name="raum"></label><label class="field">Wiederholungen<input name="wiederholungen" type="number" min="1" max="200" value="1"></label><label class="field">Abstand in Tagen<input name="abstand_tage" type="number" min="1" max="366" value="7"></label></div>`
      +`<label style="display:block;margin:.4rem 0"><input type="checkbox" name="anwesenheit_erwartet" checked> Anwesenheit führen (erzeugt die Klassenbucheinheit)</label>`
      +`<button class="btn">Termin anlegen</button></form><div id="sc-err"></div>`
      +`<h4>Nächste Termine</h4>`
      +(rows.length?rows.map(e=>`<div class="item"><strong>${SC(e.titel)}</strong> <span class="pill">${SC(SC_ART[e.art]||e.art)}</span>${e.status!=='geplant'?` <span class="pill">${SC(e.status)}</span>`:''}`
        +`<div class="muted">${SC(new Date(e.starts_at).toLocaleString('de-DE'))} – ${SC(new Date(e.ends_at).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}))}${e.raum?` · ${SC(e.raum)}`:''}${e.periode?` · ${SC(e.periode)}`:''}${Number(e.anwesenheit_erwartet)?' · Anwesenheit':''}</div>`
        +(e.status!=='abgesagt'?`<button class="btn secondary sc-verschieben" data-id="${SC(e.id)}" data-ab="${SC(e.starts_at)}" data-bis="${SC(e.ends_at)}">Verschieben</button> <button class="btn secondary sc-absagen" data-id="${SC(e.id)}">Absagen</button>`:'')
        +`</div>`).join(''):'<p class="muted">Keine Termine im nächsten Vierteljahr.</p>');
    const pick=body.querySelector('#sc-kurs');if(pick)pick.onchange=()=>{kurs=pick.value;termine();};
    const tun=async fn=>{try{await fn();await termine();}catch(err){const k=body.querySelector('#sc-err');const t=scText(err.message);if(k)k.innerHTML=`<div class="notice bad">${SC(t)}</div>`;else alert(t);}};
    body.querySelector('#sc-termin').onsubmit=e=>{e.preventDefault();const f=new FormData(e.currentTarget);
      const daten={art:f.get('art'),titel:f.get('titel'),starts_at:new Date(String(f.get('starts_at'))).toISOString(),
        ends_at:new Date(String(f.get('ends_at'))).toISOString(),raum:f.get('raum')||null,
        anwesenheit_erwartet:e.currentTarget.anwesenheit_erwartet.checked};
      const n=Number(f.get('wiederholungen'))||1;
      const pfad=n>1?'/api/schedule/events/recurring':'/api/schedule/events';
      tun(()=>scApi(`${pfad}?tenant_id=${encodeURIComponent(tenantId)}&course_id=${encodeURIComponent(kurs)}`,
        {method:'POST',body:JSON.stringify(n>1?{...daten,wiederholungen:n,abstand_tage:Number(f.get('abstand_tage'))||7}:daten)}));};
    body.querySelectorAll('.sc-verschieben').forEach(b=>b.onclick=()=>{
      const neu=prompt('Neuer Beginn (JJJJ-MM-TT SS:MM):',String(b.dataset.ab).slice(0,16).replace('T',' '));
      if(!neu)return;
      const ab=new Date(neu.replace(' ','T'));if(Number.isNaN(ab.getTime()))return alert('Bitte im Format JJJJ-MM-TT SS:MM angeben.');
      const dauer=Date.parse(b.dataset.bis)-Date.parse(b.dataset.ab);
      tun(()=>scApi(`/api/schedule/events/${encodeURIComponent(b.dataset.id)}?tenant_id=${encodeURIComponent(tenantId)}`,
        {method:'PUT',body:JSON.stringify({starts_at:ab.toISOString(),ends_at:new Date(ab.getTime()+dauer).toISOString()})}));});
    body.querySelectorAll('.sc-absagen').forEach(b=>b.onclick=()=>{
      const grund=prompt('Grund der Absage (erscheint am Termin):','');
      if(grund===null)return;
      tun(()=>scApi(`/api/schedule/events/${encodeURIComponent(b.dataset.id)}?tenant_id=${encodeURIComponent(tenantId)}${grund?`&grund=${encodeURIComponent(grund)}`:''}`,{method:'DELETE'}));});
  }

  async function zeichne(t){body.innerHTML='Lädt …';try{if(t==='termine')await termine();else await perioden();}catch(err){body.innerHTML=`<div class="notice bad">${SC(scText(err.message))}</div>`;}}
  await zeichne('perioden');
}

(async()=>{
  let me=null;try{me=(await scApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  if(!me.isPlatformAdmin&&!roles.some(x=>['tenant_admin','class_admin'].includes(x.role)))return;
  function mount(){
    const seite=document.querySelector('.side');if(!seite||document.querySelector('#sc-launch'))return;
    const tenantId=document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
    if(!tenantId)return;
    const anker=seite.querySelector('[data-v="content"]')||seite.querySelector('[data-v="overview"]');if(!anker)return;
    const b=document.createElement('button');b.id='sc-launch';b.className='nav';b.textContent='Schuljahr & Termine';
    b.onclick=async()=>{
      try{
        const tid=document.querySelector('#tenantPick')?.value||tenantId;
        const d=await scApi(`/api/courses?tenant_id=${encodeURIComponent(tid)}`).catch(()=>({}));
        await scOeffnen(tid,(d.courses||[]).filter(c=>c.is_active!==0));
      }catch(e){alert(scText(e.message));}
    };
    anker.after(b);
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

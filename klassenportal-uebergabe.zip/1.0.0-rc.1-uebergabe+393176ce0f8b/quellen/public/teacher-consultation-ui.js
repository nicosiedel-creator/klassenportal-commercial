// Der Laufzettel: was am Sprechtag auf dem Tisch der Dozentin oder des Dozenten liegt.
//
// Bewusst mit den freien Zeitfenstern dazwischen. Ein Zettel, der nur die gebuchten Gespraeche
// zeigt, laesst nicht erkennen, wann eine Pause ist - und verleitet dazu, die naechste Familie
// vorzuziehen, die aber erst zur genannten Uhrzeit da ist.
const teacherConsultationRoot=document.querySelector('#teacher-portal');

if(teacherConsultationRoot){
  const E=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fehler=e=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(e):'Die Aktion konnte nicht ausgeführt werden.';
  const uhr=v=>String(v||'').slice(11,16);
  const tagText=v=>{const d=new Date(`${String(v||'').slice(0,10)}T12:00:00Z`);return Number.isNaN(d.getTime())?String(v||''):d.toLocaleDateString('de-DE',{weekday:'long',day:'2-digit',month:'2-digit',year:'numeric',timeZone:'UTC'});};
  let aktuell=null,tage=[],gewaehlt='',zettel=null,ladefehler='';

  async function api(url,opt={}){
    const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});
    let d={};try{d=await r.json();}catch{}
    if(!r.ok)throw Object.assign(new Error(d.error||`HTTP_${r.status}`),{status:r.status});
    return d;
  }
  const q=(pfad,z,extra={})=>{const p=new URLSearchParams({tenant_id:z.tenant_id});for(const [k,v] of Object.entries(extra))if(v)p.set(k,String(v));return `${pfad}?${p}`;};

  async function laden(){
    if(!aktuell)return;
    tage=(await api(q('/api/education/planning/consultation-days',aktuell))).days||[];
    if(!tage.length){zettel=null;return;}
    if(!tage.some(t=>String(t.id)===gewaehlt))gewaehlt=String(tage[0].id);
    zettel=await api(q(`/api/education/planning/consultation-days/${encodeURIComponent(gewaehlt)}/run-sheet`,aktuell,{teacher_id:aktuell.teacher_id}));
  }

  function karte(){
    const main=teacherConsultationRoot.querySelector('.portal-main');if(!main||!aktuell)return null;
    let host=main.querySelector('#tp-consultation');
    if(!host){host=document.createElement('section');host.id='tp-consultation';main.append(host);}
    return host;
  }

  function zeichnen(){
    const host=karte();if(!host)return;
    if(ladefehler){host.innerHTML=`<div class="tp-workspace-card"><div class="tp-workspace-head"><strong>Mein Laufzettel zum Sprechtag</strong></div><div class="notice">${E(ladefehler)}</div></div>`;return;}
    if(!tage.length){
      host.innerHTML=`<div class="tp-workspace-card"><div class="tp-workspace-head"><strong>Mein Laufzettel zum Sprechtag</strong></div>`
        +`<div class="muted" style="margin-top:10px">Zurzeit ist kein Sprechtag angelegt. Sobald die Verwaltung einen Termin öffnet, steht der Laufzettel hier.</div></div>`;
      return;
    }
    const zeilen=(zettel?.rows||[]).map(z=>
      `<tr><td>${E(uhr(z.starts_at))} – ${E(uhr(z.ends_at))}</td>`
      +`<td>${z.state==='gebucht'?E(z.family_name||'gebucht'):z.state==='gesperrt'?'gesperrt':'frei'}</td>`
      +`<td>${E(z.participant_name||'')}</td><td>${E(z.course_name||'')}</td><td>${E(z.note||'')}</td></tr>`).join('');
    host.innerHTML=`<div class="tp-workspace-card"><div class="tp-workspace-head"><strong>Mein Laufzettel zum Sprechtag</strong>`
      +`<span>${E(String(zettel?.booked||0))} gebucht, ${E(String(zettel?.free||0))} frei</span></div>`
      +`<label class="field" style="margin-top:10px">Sprechtag<select data-tag>${tage.map(t=>
        `<option value="${E(t.id)}"${String(t.id)===gewaehlt?' selected':''}>${E(t.title)} · ${E(tagText(t.event_date))}</option>`).join('')}</select></label>`
      +(zettel?.day?.location?`<div class="muted">Ort: ${E(zettel.day.location)}</div>`:'')
      +(zeilen?`<div class="table-wrap" style="margin-top:10px"><table><tr><th scope="col">Zeit</th><th scope="col">Familie</th><th scope="col">Teilnehmer/in</th><th scope="col">Klasse</th><th scope="col">Hinweis</th></tr>${zeilen}</table></div>`
        :'<div class="muted" style="margin-top:10px">Für diesen Sprechtag ist noch kein Zeitraster erzeugt worden.</div>')
      +`<div class="muted" style="margin-top:8px">Freie Zeitfenster stehen bewusst mit im Zettel: die nächste Familie kommt erst zu ihrer Uhrzeit.</div></div>`;
    const w=host.querySelector('[data-tag]');
    if(w)w.onchange=async()=>{gewaehlt=w.value;try{zettel=await api(q(`/api/education/planning/consultation-days/${encodeURIComponent(gewaehlt)}/run-sheet`,aktuell,{teacher_id:aktuell.teacher_id}));ladefehler='';}catch(x){ladefehler=fehler(x);}zeichnen();};
  }

  // Das Portal baut seine Oberflaeche nach und nach auf. Wer nur einmal zeichnet, waehrend der
  // Anker noch fehlt, zeigt die Karte nie - deshalb wird beobachtet und nachgezogen.
  let laeuft=false;
  async function start(){
    if(laeuft)return;laeuft=true;
    try{
      if(!aktuell){
        const kurse=(await api('/api/attendance/teacher/courses')).courses||[];
        aktuell=kurse.find(c=>c.tenant_id&&c.teacher_id)||null;
        if(!aktuell)return;
      }
      if(!teacherConsultationRoot.querySelector('.portal-main'))return;
      if(teacherConsultationRoot.querySelector('#tp-consultation'))return;
      try{await laden();ladefehler='';}
      catch(x){ladefehler=fehler(x);}
      zeichnen();
    }catch{/* das Portal bleibt ohne diese Karte bedienbar */}
    finally{laeuft=false;}
  }
  const anstossen=()=>queueMicrotask(()=>void start());
  window.addEventListener('kp:teacher-modules-ready',anstossen);
  window.addEventListener('kp:teacher-state',anstossen);
  new MutationObserver(anstossen).observe(teacherConsultationRoot,{subtree:true,childList:true});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',anstossen);else anstossen();
}

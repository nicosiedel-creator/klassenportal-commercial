// Die Elternrolle in der Oberfläche.
//
// Drei getrennte Sichten, weil es drei getrennte Rechtsstellungen sind:
//  - Die Leitung trägt ein, wer sorgeberechtigt ist, und bis wann.
//  - Das Elternteil sieht sein Kind - und nur dieses.
//  - Die teilnehmende Person sieht, wer Einblick hat, und entscheidet nach der Volljährigkeit
//    selbst darüber. Diesen Schalter darf niemand sonst bedienen.
const GS=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const GS_VERHAELTNIS={mutter:'Mutter',vater:'Vater',vormund:'Vormund',betreuer:'rechtliche Betreuung',sonstige:'sonstige'};
async function gsApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const gsText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function gsModal(titel,breite='min(820px,96vw)'){const w=document.createElement('div');w.className='modal-back';w.innerHTML=`<div class="modal" style="width:${breite};max-height:92vh;overflow:auto"><div class="top"><h3 style="margin:0">${GS(titel)}</h3><button class="btn secondary" data-close aria-label="Schließen">×</button></div><div id="gs-body">Lädt …</div></div>`;document.body.append(w);const zu=()=>w.remove();w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};return{w,body:w.querySelector('#gs-body'),zu};}

// 1. Leitung: Sorgeberechtigungen verwalten.
async function gsAdmin(tenantId){
  const {body}=gsModal('Sorgeberechtigungen');
  async function render(){
    let d,u;
    try{[d,u]=await Promise.all([gsApi(`/api/tenant/guardianships?tenant_id=${encodeURIComponent(tenantId)}`),gsApi(`/api/tenant/users?tenant_id=${encodeURIComponent(tenantId)}`)]);}
    catch(e){body.innerHTML=`<div class="notice bad">${GS(gsText(e.message))}</div>`;return;}
    const rows=d.guardianships||[],alle=u.users||[];
    const personen=[...new Map(alle.map(x=>[x.id,x])).values()];
    const opt=xs=>xs.map(x=>`<option value="${GS(x.id)}">${GS(x.display_name)}${x.email?` (${GS(x.email)})`:''}</option>`).join('');
    body.innerHTML=`<p class="muted">Ein Elternzugang ist kein Rang, sondern eine Verknüpfung zu genau einer teilnehmenden Person. Ohne Eintrag sieht ein Elternteil nichts. Mit der Volljährigkeit endet der Zugang von selbst – danach entscheidet die junge Person selbst, ob er weiterläuft.</p>`
      +`<form id="gs-new"><div class="row"><label class="field">Sorgeberechtigte Person<select name="guardian_user_id" required><option value="">– wählen –</option>${opt(personen)}</select></label>`
      +`<label class="field">Teilnehmende Person<select name="participant_user_id" required><option value="">– wählen –</option>${opt(personen.filter(x=>x.role==='participant'))}</select></label></div>`
      +`<div class="row"><label class="field">Verhältnis<select name="verhaeltnis">${Object.entries(GS_VERHAELTNIS).map(([k,v])=>`<option value="${GS(k)}">${GS(v)}</option>`).join('')}</select></label>`
      +`<label class="field">Gültig bis<input name="gueltig_bis" type="date"><span class="muted">In der Regel der Tag der Volljährigkeit. Bei Vormundschaft oder rechtlicher Betreuung darf das Feld leer bleiben.</span></label></div>`
      +`<button class="btn">Eintragen</button></form><div id="gs-new-err"></div>`
      +`<h4>Eingetragene Sorgeberechtigungen</h4>`
      +(rows.length?rows.map(g=>`<div class="item"><strong>${GS(g.guardian_name)}</strong> für <strong>${GS(g.participant_name)}</strong> <span class="pill">${g.status==='aktiv'?'aktiv':'beendet'}</span>`
        +`<div class="muted">${GS(GS_VERHAELTNIS[g.verhaeltnis]||g.verhaeltnis)} · ${g.gueltig_bis?`gültig bis ${GS(String(g.gueltig_bis).slice(0,10))}`:'ohne festes Ende'}${g.einwilligung_der_person_am?' · von der teilnehmenden Person verlängert':''}${g.beendet_am?` · beendet am ${GS(String(g.beendet_am).slice(0,10))}`:''}</div>`
        +(g.status==='aktiv'?`<button class="btn secondary gs-end" data-id="${GS(g.id)}">Beenden</button>`:'')+`</div>`).join(''):'<p class="muted">Es ist keine Sorgeberechtigung eingetragen.</p>');
    body.querySelector('#gs-new').onsubmit=async e=>{e.preventDefault();const f=Object.fromEntries(new FormData(e.currentTarget));
      try{await gsApi(`/api/tenant/guardianships?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(f)});await render();}
      catch(err){body.querySelector('#gs-new-err').innerHTML=`<div class="notice bad">${GS(gsText(err.message))}</div>`;}};
    body.querySelectorAll('.gs-end').forEach(b=>b.onclick=async()=>{
      if(!confirm('Sorgeberechtigung beenden? Der Einblick endet sofort; der Eintrag bleibt nachvollziehbar stehen.'))return;
      try{await gsApi(`/api/tenant/guardianships/${encodeURIComponent(b.dataset.id)}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'DELETE'});await render();}
      catch(err){alert(gsText(err.message));}});
  }
  await render();
}

// 2. Elternteil: die Sicht auf das eigene Kind.
async function gsWards(tenantId,courseId){
  const {body}=gsModal('Mein Kind');
  const d=await gsApi(`/api/guardian/wards?tenant_id=${encodeURIComponent(tenantId)}`).catch(()=>({}));
  const wards=d.wards||[];
  if(!wards.length){body.innerHTML='<p class="muted">Für Sie ist derzeit kein Elternzugang eingetragen.</p>';return;}
  async function zeige(kindId){
    body.innerHTML='Lädt …';
    let v;try{v=await gsApi(`/api/guardian/wards/${encodeURIComponent(kindId)}?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${GS(gsText(e.message))}</div>`;return;}
    const zaehler={};for(const a of v.anwesenheit||[])zaehler[a.status]=(zaehler[a.status]||0)+Number(a.n||0);
    body.innerHTML=(wards.length>1?`<label class="field">Kind<select id="gs-pick">${wards.map(w=>`<option value="${GS(w.participant_user_id)}" ${w.participant_user_id===kindId?'selected':''}>${GS(w.display_name)}</option>`).join('')}</select></label>`:'')
      +`<h4>${GS(v.kind.display_name)}</h4><p class="muted">Sie sehen Anwesenheit, veröffentlichte Noten und gemeldete Abwesenheiten. Abgaben, Forenbeiträge und Nachrichten sind die eigenen Äußerungen Ihres Kindes und gehören nicht dazu.</p>`
      +`<h4>Anwesenheit</h4>${Object.keys(zaehler).length?`<div class="row">${Object.entries(zaehler).map(([k,n])=>`<span class="pill">${GS(k)}: ${GS(n)}</span>`).join('')}</div>`:'<p class="muted">Noch nichts erfasst.</p>'}`
      +`<h4>Veröffentlichte Noten</h4>${(v.noten||[]).length?(v.noten||[]).map(n=>`<div class="item"><strong>${GS(n.title)}</strong><div class="muted">${n.grade_value?GS(n.grade_value):`${GS(n.points)}${n.max_points!==null&&n.max_points!==undefined?` / ${GS(n.max_points)}`:''} Punkte`} · ${GS(String(n.published_at||'').slice(0,10))}</div></div>`).join(''):'<p class="muted">Noch keine veröffentlichte Note.</p>'}`
      +`<h4>Abwesenheiten</h4>${(v.abwesenheiten||[]).length?(v.abwesenheiten||[]).map(a=>`<div class="item">${GS(String(a.starts_on))} – ${GS(String(a.ends_on))} <span class="pill">${GS(a.status)}</span><div class="muted">${a.kind==='leave'?'Freistellung':'Krankmeldung'}${a.eingereicht_von&&a.eingereicht_von!==kindId?' · von Ihnen gemeldet':''}</div></div>`).join(''):'<p class="muted">Keine Meldung.</p>'}`
      +(courseId?`<h4>Krankmeldung einreichen</h4><form id="gs-abs"><div class="row"><label class="field">Von<input name="starts_on" type="date" required></label><label class="field">Bis<input name="ends_on" type="date" required></label></div><p class="muted">Eine Krankmeldung nimmt bewusst keinen Grund auf – für die Entschuldigung genügt, dass Ihr Kind krank war.</p><button class="btn">Krankmeldung einreichen</button></form><div id="gs-abs-err"></div>`:'');
    const pick=body.querySelector('#gs-pick');if(pick)pick.onchange=()=>zeige(pick.value);
    const form=body.querySelector('#gs-abs');
    if(form)form.onsubmit=async e=>{e.preventDefault();const f=Object.fromEntries(new FormData(e.currentTarget));
      try{await gsApi(`/api/guardian/wards/${encodeURIComponent(kindId)}/absence-notices?tenant_id=${encodeURIComponent(tenantId)}&course_id=${encodeURIComponent(courseId)}`,{method:'POST',body:JSON.stringify({...f,kind:'sick'})});await zeige(kindId);}
      catch(err){body.querySelector('#gs-abs-err').innerHTML=`<div class="notice bad">${GS(gsText(err.message))}</div>`;}};
  }
  await zeige(wards[0].participant_user_id);
}

// 3. Teilnehmende Person: wer sieht meine Daten - und der Schalter, den nur sie bedienen darf.
async function gsMine(tenantId){
  const {body}=gsModal('Wer sieht meine Daten',' min(680px,96vw)');
  async function render(){
    let d;try{d=await gsApi(`/api/personal/guardians?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${GS(gsText(e.message))}</div>`;return;}
    const rows=(d.guardians||[]).filter(x=>x.status==='aktiv');
    body.innerHTML=`<p class="muted">Solange Sie minderjährig sind, haben Ihre Sorgeberechtigten Einblick in Anwesenheit, veröffentlichte Noten und Abwesenheitsmeldungen. Danach entscheiden Sie selbst – und nur Sie können das hier ändern.</p>`
      +(rows.length?rows.map(g=>`<div class="item"><strong>${GS(g.guardian_name)}</strong><div class="muted">${GS(GS_VERHAELTNIS[g.verhaeltnis]||g.verhaeltnis)}${g.gueltig_bis?` · eingetragen bis ${GS(String(g.gueltig_bis).slice(0,10))}`:' · ohne festes Ende'}</div>`
        +`<label style="display:block;margin:.4rem 0"><input type="checkbox" class="gs-consent" data-id="${GS(g.id)}" ${g.einwilligung_der_person_am?'checked':''}> Einblick auch nach dem eingetragenen Ende erlauben</label></div>`).join(''):'<p class="muted">Niemand hat über einen Elternzugang Einblick in Ihre Daten.</p>');
    body.querySelectorAll('.gs-consent').forEach(c=>c.onchange=async()=>{
      try{await gsApi(`/api/personal/guardians/${encodeURIComponent(c.dataset.id)}/consent?tenant_id=${encodeURIComponent(tenantId)}`,{method:'PUT',body:JSON.stringify({consent:c.checked})});await render();}
      catch(err){alert(gsText(err.message));c.checked=!c.checked;}});
  }
  await render();
}

// 4. Die eigenen Einwilligungen: wozu habe ich zugestimmt, und was gilt heute noch.
//
// Eine Einwilligung, die man nicht einsehen und nicht widerrufen kann, ist keine. Deshalb steht
// sie hier neben "Wer sieht meine Daten" und nicht in einer Verwaltungsmaske.
const GS_ENTSCHEIDUNG={erteilt:'erteilt',abgelehnt:'abgelehnt',widerrufen:'widerrufen'};
async function gsConsents(tenantId){
  const {body}=gsModal('Meine Einwilligungen',' min(760px,96vw)');
  async function render(){
    let d;try{d=await gsApi(`/api/personal/consents?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${GS(gsText(e.message))}</div>`;return;}
    const rows=d.consents||[];
    body.innerHTML=`<p class="muted">Hier steht, wozu Sie zugestimmt haben und was davon heute noch gilt. Ändert der Träger den Text einer Einwilligung, entsteht eine neue Fassung – Ihre frühere Zustimmung gilt dafür <strong>nicht</strong> und wird erneut erfragt.</p>`
      +(rows.length?rows.map(c=>`<div class="item"><strong>${GS(c.titel)}</strong> ${Number(c.pflicht)?'<span class="pill">für die Teilnahme nötig</span>':'<span class="pill">freiwillig</span>'}`
        +`<div class="muted">${GS(c.zweck)}</div>`
        +(c.entscheidung
          ?`<div class="muted">${GS(GS_ENTSCHEIDUNG[c.entscheidung]||c.entscheidung)} am ${GS(String(c.erklaert_am).slice(0,10))}${c.erklaert_als==='sorgeberechtigt'?' (durch eine sorgeberechtigte Person)':''}`
            +`${c.abgelaufen?' · abgelaufen':''}${c.fassung_veraltet?' · der Text wurde seitdem geändert':''}</div>`
          :'<div class="muted">Noch nicht beantwortet.</div>')
        +`<div class="row">${c.wirksam
            ?`<button class="btn secondary gs-widerruf" data-id="${GS(c.definition_id)}">Widerrufen</button>`
            :`<button class="btn secondary gs-erteilen" data-id="${GS(c.definition_id)}">Einwilligen</button><button class="btn secondary gs-ablehnen" data-id="${GS(c.definition_id)}">Ablehnen</button>`}</div></div>`).join('')
        :'<p class="muted">Für Sie ist keine Einwilligung hinterlegt.</p>');
    const erklaeren=async(id,entscheidung)=>{
      try{await gsApi(`/api/personal/consents?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({definition_id:id,entscheidung})});await render();}
      catch(err){alert(gsText(err.message));}
    };
    body.querySelectorAll('.gs-erteilen').forEach(b=>b.onclick=()=>erklaeren(b.dataset.id,'erteilt'));
    body.querySelectorAll('.gs-ablehnen').forEach(b=>b.onclick=()=>erklaeren(b.dataset.id,'abgelehnt'));
    body.querySelectorAll('.gs-widerruf').forEach(b=>b.onclick=()=>{
      if(!confirm('Einwilligung widerrufen? Sie gilt ab sofort nicht mehr; bereits Geschehenes bleibt davon unberührt.'))return;
      erklaeren(b.dataset.id,'widerrufen');});
  }
  await render();
}


// 4. Leitung: Zugriffssperren und Haushalte.
//
// Der Fall, den das System bisher nicht kannte: Sorgerecht ja, Einblick beschränkt. Und getrennte
// Haushalte, die dieselbe Information bekommen müssen, ohne die Anschrift des anderen zu erfahren.
const GS_BEREICHE=[['anwesenheit','Anwesenheit'],['noten','Noten'],['abwesenheiten','Abwesenheiten'],['kontaktdaten','Kontaktdaten'],['stundenplan','Stundenplan'],['dokumente','Dokumente'],['kommunikation','Kommunikation']];
const GS_ARTEN=[['sorgerechtsbeschraenkung','Sorgerechtsbeschränkung'],['auskunftssperre','Auskunftssperre'],['kontaktverbot','Kontaktverbot']];
async function gsRestrictions(tenantId){
  const {body}=gsModal('Zugriffssperren und Haushalte');
  async function render(){
    let d,u,g;
    try{[d,u,g]=await Promise.all([
      gsApi(`/api/tenant/access-restrictions?tenant_id=${encodeURIComponent(tenantId)}`),
      gsApi(`/api/tenant/users?tenant_id=${encodeURIComponent(tenantId)}`),
      gsApi(`/api/tenant/guardianships?tenant_id=${encodeURIComponent(tenantId)}`)]);}
    catch(e){body.innerHTML=`<div class="notice bad">${GS(gsText(e.message))}</div>`;return;}
    const personen=[...new Map((u.users||[]).map(x=>[x.id,x])).values()];
    const opt=xs=>xs.map(x=>`<option value="${GS(x.id)}">${GS(x.display_name)}</option>`).join('');
    const zeilen=(d.restrictions||[]).map(r=>`<tr><th scope="row">${GS(r.betroffene_name)}</th><td>${GS((GS_ARTEN.find(a=>a[0]===r.art)||[,r.art])[1])}</td><td>${GS(r.gegen_name||'alle Dritten')}</td><td>${GS(r.umfang)}</td><td>${GS(r.gueltig_bis||'unbefristet')}</td><td>${GS(r.status)}</td><td>${r.status==='aktiv'?`<button class="btn secondary gs-lift" type="button" data-id="${GS(r.id)}">Aufheben</button>`:''}</td></tr>`).join('')
      ||'<tr><td colspan="7">Keine Sperren eingetragen.</td></tr>';
    const haushalte=(g.guardianships||[]).filter(x=>x.status==='aktiv').map(x=>`<tr><th scope="row">${GS(x.guardian_name||x.guardian_user_id)}</th><td>${GS(x.participant_name||x.participant_user_id)}</td><td><input id="hh-${GS(x.id)}" class="gs-haus" data-id="${GS(x.id)}" value="${GS(x.haushalt||'')}" placeholder="z. B. haushalt_1" aria-label="Haushalt dieser Sorgeverknüpfung"></td></tr>`).join('')
      ||'<tr><td colspan="3">Keine aktiven Sorgeverknüpfungen.</td></tr>';
    body.innerHTML=`<p class="muted">Eine Sperre greift serverseitig. Sie braucht eine Rechtsgrundlage – Beschluss, Aktenzeichen oder behördliche Anordnung – und wird protokolliert.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Eingetragene Sperren</caption><thead><tr><th scope="col">Geschützte Person</th><th scope="col">Art</th><th scope="col">Gegen</th><th scope="col">Umfang</th><th scope="col">Bis</th><th scope="col">Stand</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<h3>Neue Sperre</h3><form id="gs-asp"><div class="row">`
      +`<label class="field">Geschützte Person<select name="betroffene_person" required><option value="">– wählen –</option>${opt(personen)}</select></label>`
      +`<label class="field">Art<select name="art" required>${GS_ARTEN.map(a=>`<option value="${a[0]}">${a[1]}</option>`).join('')}</select></label>`
      +`<label class="field">Gegen (leer = alle Dritten)<select name="gegen_user_id"><option value="">– alle Dritten –</option>${opt(personen)}</select></label>`
      +`</div><fieldset><legend>Umfang (nichts gewählt = alle Bereiche)</legend>${GS_BEREICHE.map(b=>`<label class="field inline"><input type="checkbox" name="bereich" value="${b[0]}"> ${b[1]}</label>`).join('')}</fieldset>`
      +`<div class="row"><label class="field">Rechtsgrundlage<input name="rechtsgrundlage" required minlength="10" placeholder="Beschluss des Amtsgerichts …"></label>`
      +`<label class="field">Aktenzeichen<input name="aktenzeichen"></label>`
      +`<label class="field">Gültig bis<input name="gueltig_bis" type="date"></label></div>`
      +`<div class="toolbar"><button class="btn" type="submit">Sperre verhängen</button></div><p class="error" id="gs-asp-err" role="alert"></p></form>`
      +`<h3>Haushalte</h3><p class="muted">Zwei Haushalte heißen: zwei getrennte Wege. Meldungen gehen dann einzeln an jede Person, nie über einen gemeinsamen Verteiler.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Haushalt je Sorgeverknüpfung</caption><thead><tr><th scope="col">Sorgeberechtigt</th><th scope="col">Kind</th><th scope="col">Haushalt</th></tr></thead><tbody>${haushalte}</tbody></table></div>`;
    body.querySelector('#gs-asp').onsubmit=async ev=>{
      ev.preventDefault();
      const f=new FormData(ev.target),bereiche=[...ev.target.querySelectorAll('input[name="bereich"]:checked')].map(x=>x.value);
      const nutzlast={betroffene_person:f.get('betroffene_person'),art:f.get('art'),gegen_user_id:f.get('gegen_user_id')||null,
        umfang:bereiche.length?bereiche.join(','):'alle',rechtsgrundlage:f.get('rechtsgrundlage'),aktenzeichen:f.get('aktenzeichen')||null,
        gueltig_bis:f.get('gueltig_bis')||null};
      try{await gsApi(`/api/tenant/access-restrictions?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify(nutzlast)});await render();}
      catch(e){body.querySelector('#gs-asp-err').textContent=gsText(e.message);}
    };
    body.querySelectorAll('.gs-lift').forEach(b=>b.onclick=async()=>{
      const grund=prompt('Warum wird die Sperre aufgehoben? (mindestens 10 Zeichen)');
      if(grund===null)return;
      try{await gsApi(`/api/tenant/access-restrictions/${encodeURIComponent(b.dataset.id)}/lift?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({grund})});await render();}
      catch(e){alert(gsText(e.message));}
    });
    body.querySelectorAll('.gs-haus').forEach(i=>i.onchange=async()=>{
      try{await gsApi(`/api/tenant/guardianships/${encodeURIComponent(i.dataset.id)}/household?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({haushalt:i.value})});}
      catch(e){alert(gsText(e.message));}
    });
  }
  await render();
}

(async()=>{
  let me=null;try{me=(await gsApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const kursOf=()=>new URLSearchParams(location.search).get('course_id')||roles.find(x=>x.course_id)?.course_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.className=klasse;b.textContent=text;b.onclick=()=>klick().catch(e=>alert(gsText(e.message)));ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId)return;
    const seite=document.querySelector('.side');
    if(seite&&(me.isPlatformAdmin||roles.some(x=>x.role==='tenant_admin'))){
      const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
      knopf('gs-admin-launch','Sorgeberechtigungen',()=>gsAdmin(tenantId),anker,'nav');
      knopf('gs-asp-launch','Zugriffssperren',()=>gsRestrictions(tenantId).catch(e=>alert(gsText(e.message))),anker,'nav');
    }
    const portal=document.querySelector('.portal-main');
    if(portal&&!document.querySelector('#gs-portal-row')){
      const zeile=document.createElement('div');zeile.id='gs-portal-row';zeile.className='portal-section';
      zeile.innerHTML='<div class="portal-section-head"><h2>Meine Daten</h2></div><div class="row" id="gs-portal-buttons"></div>';
      portal.append(zeile);
      const halter=zeile.querySelector('#gs-portal-buttons');
      const kind=document.createElement('button');kind.className='portal-btn secondary';kind.textContent='Mein Kind';
      kind.onclick=()=>gsWards(tenantId,kursOf()).catch(e=>alert(gsText(e.message)));
      const meine=document.createElement('button');meine.className='portal-btn secondary';meine.textContent='Wer sieht meine Daten';
      meine.onclick=()=>gsMine(tenantId).catch(e=>alert(gsText(e.message)));
      const einw=document.createElement('button');einw.className='portal-btn secondary';einw.textContent='Meine Einwilligungen';
      einw.onclick=()=>gsConsents(tenantId).catch(e=>alert(gsText(e.message)));
      halter.append(kind,meine,einw);
    }
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

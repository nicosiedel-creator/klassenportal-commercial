// Kommunikations- und Layout-Editor.
//
// Gestaltung entsteht durch Bausteine, nicht durch eingefügtes HTML. Und die Vorschau sagt
// ausdrücklich, dass sie Beispieldaten zeigt — sonst hält jemand sie für den Versand.
const KE=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const KE_KANAL=[['email','E-Mail'],['portal','Portalmeldung'],['aushang','Aushang'],['brief','Brief']];
const KE_BLOCK=[['ueberschrift','Überschrift'],['absatz','Absatz'],['liste','Liste'],['hinweis','Hinweiskasten'],['bild','Bild'],['knopf','Knopf'],['trenner','Trenner']];
const KE_PLATZ={email:['anrede','vorname','nachname','kurs','traeger','datum','termin','frist','link'],
  portal:['anrede','vorname','kurs','traeger','datum','termin','frist'],
  aushang:['kurs','traeger','datum','termin','raum'],
  brief:['anrede','vorname','nachname','kurs','traeger','datum','termin','frist','adresse']};
async function keApi(url,opt={}){const r=await fetch(url,{credentials:'same-origin',cache:'no-store',...opt,headers:{...(opt.body?{'content-type':'application/json'}:{}),...(opt.headers||{})}});let d={};try{d=await r.clone().json();}catch{}if(!r.ok)throw new Error(d.error||`HTTP_${r.status}`);return d;}
const keText=m=>window.KP_ERROR_TEXT?window.KP_ERROR_TEXT(m):m;
function keModal(titel){
  const opener=document.activeElement,w=document.createElement('div');w.className='modal-back';
  w.innerHTML=`<div class="modal" role="dialog" aria-modal="true" aria-labelledby="ke-titel" style="width:min(1000px,96vw);max-height:92vh;overflow:auto"><div class="top"><h3 id="ke-titel" style="margin:0">${KE(titel)}</h3><button class="btn secondary" type="button" data-close aria-label="Schließen">×</button></div><div id="ke-body">Lädt …</div></div>`;
  document.body.append(w);
  const zu=()=>{w.remove();opener?.focus?.();};
  w.querySelector('[data-close]').onclick=zu;w.onclick=e=>{if(e.target===w)zu();};
  document.addEventListener('keydown',function esc(e){if(e.key==='Escape'){zu();document.removeEventListener('keydown',esc);}});
  w.querySelector('[data-close]').focus();
  return{body:w.querySelector('#ke-body'),zu};
}

async function keVorlagen(tenantId){
  const {body}=keModal('Anschreiben und Aushänge');
  async function render(){
    let d;try{d=await keApi(`/api/communication-templates?tenant_id=${encodeURIComponent(tenantId)}`);}
    catch(e){body.innerHTML=`<div class="notice bad">${KE(keText(e.message))}</div>`;return;}
    const zeilen=(d.vorlagen||[]).map(v=>`<tr><th scope="row">${KE(v.titel)}</th><td>${KE(v.schluessel)}</td><td>${KE(v.kanal)}</td><td>${KE(v.status)}</td><td>${KE(String(v.fassung))}</td>`
      +`<td><button class="btn secondary ke-bau" type="button" data-id="${KE(v.id)}" data-k="${KE(v.kanal)}">Bausteine</button> <button class="btn secondary ke-vor" type="button" data-id="${KE(v.id)}">Vorschau</button>`
      +`${v.status!=='veroeffentlicht'?` <button class="btn ke-pub" type="button" data-id="${KE(v.id)}">Veröffentlichen</button>`:''}`
      +` <button class="btn secondary ke-fas" type="button" data-id="${KE(v.id)}">Fassungen</button></td></tr>`).join('')
      ||'<tr><td colspan="6">Noch keine Vorlage.</td></tr>';
    body.innerHTML=`<p class="muted">Gestaltung entsteht durch Bausteine. Platzhalter stehen je Kanal fest; alles, was aus Daten kommt, wird beim Rendern maskiert.</p>`
      +`<div style="overflow-x:auto"><table class="table"><caption>Vorlagen</caption><thead><tr><th scope="col">Titel</th><th scope="col">Kennung</th><th scope="col">Kanal</th><th scope="col">Stand</th><th scope="col">Fassung</th><th scope="col">Aktion</th></tr></thead><tbody>${zeilen}</tbody></table></div>`
      +`<form id="ke-neu"><h4>Vorlage anlegen</h4><label class="field">Kurzkennung<input name="schluessel" required></label>`
      +`<label class="field">Titel<input name="titel" required></label>`
      +`<label class="field">Kanal<select name="kanal">${KE_KANAL.map(([k,t])=>`<option value="${KE(k)}">${KE(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Betreff (E-Mail)<input name="betreff"></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Anlegen</button></div></form><p class="error" id="ke-err" role="alert"></p><div id="ke-out"></div>`;
    const fehler=e=>{body.querySelector('#ke-err').textContent=keText(e.message);};
    body.querySelector('#ke-neu').onsubmit=async ev=>{
      ev.preventDefault();const f=new FormData(ev.target);
      try{await keApi(`/api/communication-templates?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:JSON.stringify({
        schluessel:String(f.get('schluessel')),titel:String(f.get('titel')),kanal:String(f.get('kanal')),
        betreff:String(f.get('betreff')||''),bloecke:[{art:'absatz',text:'Bitte hier den Text eintragen.'}]})});await render();}
      catch(e){fehler(e);}
    };
    body.querySelectorAll('.ke-bau').forEach(b=>b.onclick=()=>keBausteine(tenantId,b.dataset.id,b.dataset.k,render));
    body.querySelectorAll('.ke-vor').forEach(b=>b.onclick=async()=>{
      try{const r=await keApi(`/api/communication-templates/${encodeURIComponent(b.dataset.id)}/preview?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
        body.querySelector('#ke-out').innerHTML=(r.beispieldaten?'<div class="notice">Vorschau mit <strong>Beispieldaten</strong> — das ist nicht der Versand.</div>':'')
          +(r.betreff?`<p><strong>Betreff:</strong> ${KE(r.betreff)}</p>`:'')
          +((r.fehlende_werte||[]).length?`<div class="notice bad">Ohne Wert: ${KE(r.fehlende_werte.join(', '))}</div>`:'')
          +`<div class="card">${r.html}</div>`;}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.ke-pub').forEach(b=>b.onclick=async()=>{
      try{await keApi(`/api/communication-templates/${encodeURIComponent(b.dataset.id)}/publish?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});await render();}
      catch(e){fehler(e);}
    });
    body.querySelectorAll('.ke-fas').forEach(b=>b.onclick=async()=>{
      try{const r=await keApi(`/api/communication-templates/${encodeURIComponent(b.dataset.id)}/versions?tenant_id=${encodeURIComponent(tenantId)}`);
        body.querySelector('#ke-out').innerHTML=`<ul>`+((r.fassungen||[]).map(f=>`<li>Fassung ${KE(String(f.fassung))} — ${KE(f.titel)} (${KE(f.veroeffentlicht_am)})</li>`).join('')||'<li>Noch keine veröffentlichte Fassung.</li>')+`</ul>`;}
      catch(e){fehler(e);}
    });
  }
  await render();
}

async function keBausteine(tenantId,vorlageId,kanal,zurueck){
  const {body}=keModal('Bausteine');
  let bloecke=[];
  const platz=KE_PLATZ[kanal]||[];
  function zeichne(){
    const liste=bloecke.map((b,i)=>`<li><strong>${KE(b.art)}</strong> ${KE(b.text||(b.punkte||[]).join(' · ')||b.alt||'')} `
      +`<button class="btn secondary ke-weg" type="button" data-i="${i}">Entfernen</button></li>`).join('')||'<li>Noch kein Baustein.</li>';
    body.innerHTML=`<p class="muted">Erlaubte Platzhalter in diesem Kanal: ${KE(platz.map(p=>`{{${p}}}`).join(' '))}</p>`
      +`<ol id="ke-liste">${liste}</ol>`
      +`<form id="ke-add"><label class="field">Baustein<select name="art">${KE_BLOCK.map(([k,t])=>`<option value="${KE(k)}">${KE(t)}</option>`).join('')}</select></label>`
      +`<label class="field">Text (oder Listenpunkte durch | getrennt)<textarea name="text" rows="3"></textarea></label>`
      +`<label class="field">Bildkennung (nur Baustein Bild)<input name="asset_id"></label>`
      +`<label class="field">Alternativtext (nur Bild)<input name="alt"></label>`
      +`<label class="field">Ziel (nur Knopf, z. B. /portal)<input name="ziel" value="/portal"></label>`
      +`<label class="field">Überschriftstufe<input name="stufe" type="number" min="2" max="4" value="2"></label>`
      +`<div class="toolbar"><button class="btn" type="submit">Hinzufügen</button> <button class="btn secondary" type="button" id="ke-save">Speichern</button></div></form>`
      +`<p class="error" id="ke-berr" role="alert"></p>`;
    body.querySelector('#ke-add').onsubmit=ev=>{
      ev.preventDefault();const f=new FormData(ev.target),art=String(f.get('art')),text=String(f.get('text')||'');
      const b={art};
      if(art==='liste')b.punkte=text.split('|').map(s=>s.trim()).filter(Boolean);
      else if(art==='bild'){b.asset_id=String(f.get('asset_id')||'');b.alt=String(f.get('alt')||'');}
      else if(art==='knopf'){b.text=text;b.ziel=String(f.get('ziel')||'/portal');}
      else if(art==='trenner'){}
      else{b.text=text;if(art==='ueberschrift')b.stufe=Number(f.get('stufe')||2);}
      bloecke.push(b);zeichne();
    };
    body.querySelectorAll('.ke-weg').forEach(b=>b.onclick=()=>{bloecke.splice(Number(b.dataset.i),1);zeichne();});
    body.querySelector('#ke-save').onclick=async()=>{
      try{await keApi(`/api/communication-templates/${encodeURIComponent(vorlageId)}?tenant_id=${encodeURIComponent(tenantId)}`,{method:'PATCH',body:JSON.stringify({bloecke})});
        zurueck?.();body.querySelector('#ke-berr').textContent='';}
      catch(e){body.querySelector('#ke-berr').textContent=keText(e.message);}
    };
  }
  try{
    const r=await keApi(`/api/communication-templates/${encodeURIComponent(vorlageId)}/preview?tenant_id=${encodeURIComponent(tenantId)}`,{method:'POST',body:'{}'});
    void r;
  }catch{}
  zeichne();
}

(async()=>{
  let me=null;try{me=(await keApi('/api/auth/me')).user||null;}catch{}
  if(!me)return;
  const roles=me.tenantRoles||[];
  const verwaltung=me.isPlatformAdmin||roles.some(x=>['tenant_admin','class_admin'].includes(x.role));
  const tenantOf=()=>document.querySelector('#tenantPick')?.value||new URLSearchParams(location.search).get('tenant_id')||roles[0]?.tenant_id||'';
  const knopf=(id,text,klick,ziel,klasse)=>{if(!ziel||document.querySelector(`#${id}`))return;const b=document.createElement('button');b.id=id;b.type='button';b.className=klasse;b.textContent=text;b.onclick=klick;ziel.after(b);};
  function mount(){
    const tenantId=tenantOf();if(!tenantId||!verwaltung)return;
    const seite=document.querySelector('.side');if(!seite)return;
    const anker=seite.querySelector('[data-v="users"]')||seite.querySelector('[data-v="overview"]');
    knopf('ke-vorlagen-launch','Anschreiben',()=>keVorlagen(tenantId),anker,'nav');
  }
  new MutationObserver(()=>{try{mount();}catch{}}).observe(document.documentElement,{subtree:true,childList:true});
  mount();
})();

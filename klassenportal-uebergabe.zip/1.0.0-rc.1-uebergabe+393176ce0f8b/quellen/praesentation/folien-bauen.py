# -*- coding: utf-8 -*-
import io,os
B='project/slides'
NAVY='#0b2545'; NAVY2='#12305a'; NAVY3='#1e3a6d'
GOLD='#d4af37'; GOLDH='#e8cf7a'; GOLDT='#f5efdc'
LIGHT='#f8fafc'; WHITE='#ffffff'; DARK='#1f2937'
MUT='#4a5568'; MUTD='#a9b7ce'; LINIE='#dce5f5'
F="Inter, Arial, sans-serif"

def w(i,h): io.open('%s/%s.html'%(B,i),'w',encoding='utf-8').write(h)

# ---------- Bausteine ----------
def badge(icon,bg=NAVY,fg=GOLD,size=64,ic=34,r=16):
    return ('<div style="width:%dpx; height:%dpx; border-radius:%dpx; background:%s; display:flex; align-items:center; justify-content:center">'
            '<x-icon name="%s" style="color:%s; width:%dpx; height:%dpx"></x-icon></div>')%(size,size,r,bg,icon,fg,ic,ic)

def karte(icon,titel,text,breite='flex:1',grund=WHITE,rand=LINIE,tf=NAVY,xf=MUT,bg=GOLDT,fg='#8a6d1f'):
    return ('    <div style="%s; display:flex; flex-direction:column; gap:18px; background:%s; padding:36px; border:1px solid %s; border-radius:18px">\n'
            '      %s\n'
            '      <h3 style="font-size:30px; font-weight:700; line-height:1.2; color:%s">%s</h3>\n'
            '      <p style="font-size:25px; line-height:1.45; color:%s">%s</p>\n    </div>\n')%(breite,grund,rand,badge(icon,bg,fg),tf,titel,xf,text)

def kartenreihe(items,**kw):
    return '  <div style="display:flex; gap:26px">\n'+''.join(karte(*i,**kw) for i in items)+'  </div>'

def kartengitter(items,spalten=4,**kw):
    zellen=''.join(karte(*i,breite='',**kw) for i in items)
    return '  <div style="display:grid; grid-template-columns:repeat(%d, 1fr); gap:26px">\n%s  </div>'%(spalten,zellen)

def haken(text,fg=NAVY,size=29):
    return ('    <div style="display:flex; gap:20px; align-items:center">%s'
            '<p style="font-size:%dpx; line-height:1.4; color:%s">%s</p></div>\n')%(badge('Check',GOLD,NAVY,44,24,999),size,fg,text)

def hakenliste(items,fg=NAVY,size=29):
    return '  <div style="display:flex; flex-direction:column; gap:22px">\n'+''.join(haken(t,fg,size) for t in items)+'  </div>'

def eyebrow(t,c=GOLD):
    return '  <p style="font-size:23px; font-weight:700; letter-spacing:3px; text-transform:uppercase; color:%s">%s</p>'%(c,t)

def h2(t,c=NAVY,s=68):
    return '  <h2 style="font-size:%dpx; font-weight:700; line-height:1.12; color:%s">%s</h2>'%(s,c,t)

def unter(t,c=MUT,s=30):
    return '  <p style="font-size:%dpx; line-height:1.45; color:%s">%s</p>'%(s,c,t)

def fuss(t,c=MUT):
    return '  <p style="position:absolute; left:128px; bottom:64px; font-size:23px; color:%s">%s</p>'%(c,t)

def marke_klein(c=MUTD):
    return ('  <div style="position:absolute; right:128px; bottom:64px; display:flex; gap:14px; align-items:center">'
            '%s<p style="font-size:22px; letter-spacing:2px; text-transform:uppercase; color:%s">Klassenportal</p></div>')%(mono(34),c)

def hell(i,inner,notes=None,extra=''):
    return ('<section id="%s"%s style="background:%s; color:%s; font-family:%s; padding:104px 128px 160px; display:flex; flex-direction:column; gap:38px">\n%s\n'%(i,extra,LIGHT,DARK,F,inner))+(('  <aside>%s</aside>\n'%notes) if notes else '')+'</section>\n'

def dunkel(i,inner,notes=None,extra='',bg=NAVY):
    return ('<section id="%s"%s style="background:%s; color:%s; font-family:%s; padding:104px 128px 160px; display:flex; flex-direction:column; gap:38px">\n%s\n'%(i,extra,bg,LIGHT,F,inner))+(('  <aside>%s</aside>\n'%notes) if notes else '')+'</section>\n'

# ---------- Monogramm ----------
def mono(s=120,gold=GOLD,hell_=LIGHT):
    return ('<svg aria-label="Monogramm K" width="%d" height="%d" viewBox="0 0 100 100">'
      '<rect x="0" y="0" width="100" height="100" rx="18" fill="none"/>'
      '<rect x="14" y="14" width="13" height="72" fill="%s"/>'
      '<path d="M33 50 L72 14 L90 14 L51 50 Z" fill="%s"/>'
      '<path d="M33 50 L72 86 L90 86 L51 50 Z" fill="%s"/>'
      '<rect x="14" y="44" width="13" height="12" fill="%s"/>'
      '</svg>')%(s,s,hell_,gold,hell_,gold)

# ---------- Illustrationen ----------
def kunst_architektur(w_=760,h_=824):
    return ('<svg aria-label="Grafische Darstellung eines Gebäudes aus geneigten Flächen" width="%d" height="%d" viewBox="0 0 760 824">'
      '<defs><linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">'
      '<stop offset="0" stop-color="#1e3a6d"/><stop offset="1" stop-color="#0b2545"/></linearGradient>'
      '<linearGradient id="g2" x1="0" y1="1" x2="1" y2="0">'
      '<stop offset="0" stop-color="#d4af37" stop-opacity="0.95"/><stop offset="1" stop-color="#e8cf7a" stop-opacity="0.35"/></linearGradient></defs>'
      '<rect width="760" height="824" fill="#0b2545"/>'
      '<path d="M0 560 L300 300 L300 824 L0 824 Z" fill="url(#g1)"/>'
      '<path d="M300 300 L620 120 L620 824 L300 824 Z" fill="#12305a"/>'
      '<path d="M620 120 L760 200 L760 824 L620 824 Z" fill="#183a6b"/>'
      '<path d="M300 300 L620 120 L620 190 L300 370 Z" fill="url(#g2)"/>'
      +''.join('<rect x="%d" y="%d" width="26" height="14" fill="#d4af37" opacity="%s"/>'%(330+c*54,400+r*60,['0.75','0.35','0.55','0.2','0.65'][(r+c)%5]) for r in range(7) for c in range(5))
      +''.join('<rect x="%d" y="%d" width="22" height="12" fill="#e8cf7a" opacity="0.25"/>'%(40+c*60,600+r*58) for r in range(4) for c in range(4))
      +'<rect x="0" y="0" width="760" height="824" fill="none" stroke="#d4af37" stroke-width="0"/></svg>')%(w_,h_)

def kunst_ui(w_=900,h_=520):
    return ('<svg aria-label="Skizze der Portaloberfläche mit Seitenleiste und Kacheln" width="%d" height="%d" viewBox="0 0 900 520">'
      '<rect x="0" y="0" width="900" height="520" rx="20" fill="#0b2545"/>'
      '<rect x="14" y="14" width="872" height="44" rx="10" fill="#12305a"/>'
      '<circle cx="42" cy="36" r="7" fill="#d4af37"/><circle cx="66" cy="36" r="7" fill="#2f4a78"/><circle cx="90" cy="36" r="7" fill="#2f4a78"/>'
      '<rect x="120" y="26" width="360" height="20" rx="10" fill="#0b2545"/>'
      '<rect x="14" y="72" width="210" height="434" rx="14" fill="#12305a"/>'
      +''.join('<g><rect x="34" y="%d" width="22" height="22" rx="6" fill="%s"/><rect x="68" y="%d" width="%d" height="12" rx="6" fill="#2f4a78"/></g>'%(96+i*54,GOLD if i==0 else '#2f4a78',101+i*54,[120,96,110,84,104,92][i]) for i in range(6))
      +'<rect x="244" y="72" width="642" height="120" rx="14" fill="#12305a"/>'
      '<rect x="276" y="104" width="300" height="22" rx="11" fill="#d4af37" opacity="0.9"/>'
      '<rect x="276" y="140" width="460" height="14" rx="7" fill="#2f4a78"/>'
      +''.join('<g><rect x="%d" y="212" width="196" height="134" rx="14" fill="#12305a"/><rect x="%d" y="238" width="44" height="44" rx="12" fill="#183a6b"/><rect x="%d" y="240" width="18" height="18" rx="5" fill="#d4af37"/><rect x="%d" y="300" width="130" height="12" rx="6" fill="#2f4a78"/><rect x="%d" y="322" width="90" height="10" rx="5" fill="#1e3a6d"/></g>'%(244+i*221,270+i*221,283+i*221,270+i*221,270+i*221) for i in range(3))
      +'<rect x="244" y="366" width="642" height="140" rx="14" fill="#12305a"/>'
      +''.join('<rect x="%d" y="%d" width="%d" height="14" rx="7" fill="#2f4a78"/>'%(276,392+i*32,[520,430,480][i]) for i in range(3))
      +''.join('<rect x="%d" y="%d" width="44" height="14" rx="7" fill="#d4af37" opacity="0.7"/>'%(820,392+i*32) for i in range(3))
      +'</svg>')%(w_,h_)

def kunst_telefon(w_=230,h_=440):
    return ('<svg aria-label="Skizze der Ansicht auf einem Telefon" width="%d" height="%d" viewBox="0 0 230 440">'
      '<rect x="0" y="0" width="230" height="440" rx="30" fill="#0b2545" stroke="#1e3a6d" stroke-width="4"/>'
      '<rect x="86" y="16" width="58" height="10" rx="5" fill="#12305a"/>'
      '<rect x="20" y="46" width="120" height="16" rx="8" fill="#d4af37" opacity="0.9"/>'
      '<rect x="20" y="74" width="170" height="10" rx="5" fill="#2f4a78"/>'
      +''.join('<g><rect x="20" y="%d" width="190" height="62" rx="12" fill="#12305a"/><rect x="36" y="%d" width="30" height="30" rx="9" fill="#183a6b"/><rect x="44" y="%d" width="14" height="14" rx="4" fill="#d4af37"/><rect x="80" y="%d" width="104" height="10" rx="5" fill="#2f4a78"/><rect x="80" y="%d" width="70" height="8" rx="4" fill="#1e3a6d"/></g>'%(102+i*74,118+i*74,126+i*74,116+i*74,134+i*74) for i in range(4))
      +'<rect x="60" y="406" width="110" height="8" rx="4" fill="#2f4a78"/></svg>')%(w_,h_)

def kunst_kette(w_=1400,h_=300):
    g=['<rect x="0" y="0" width="1400" height="300" fill="none"/>']
    for i in range(5):
        x=40+i*280
        g.append('<rect x="%d" y="60" width="200" height="180" rx="18" fill="#ffffff" stroke="#dce5f5" stroke-width="3"/>'%x)
        g.append('<rect x="%d" y="86" width="150" height="16" rx="8" fill="#0b2545"/>'%(x+25))
        g.append('<rect x="%d" y="116" width="110" height="12" rx="6" fill="#8fa3c4"/>'%(x+25))
        g.append('<rect x="%d" y="140" width="130" height="12" rx="6" fill="#8fa3c4"/>'%(x+25))
        g.append('<rect x="%d" y="180" width="150" height="34" rx="10" fill="#f5efdc"/>'%(x+25))
        g.append('<rect x="%d" y="192" width="88" height="10" rx="5" fill="#d4af37"/>'%(x+40))
        if i<4:
            g.append('<path d="M%d 150 L%d 150" stroke="#d4af37" stroke-width="5"/>'%(x+200,x+280))
            g.append('<path d="M%d 140 L%d 150 L%d 160 Z" fill="#d4af37"/>'%(x+268,x+282,x+268))
    return '<svg aria-label="Kette aus fünf Einträgen, jeder mit der Prüfsumme seines Vorgängers verbunden" width="%d" height="%d" viewBox="0 0 1400 300">%s</svg>'%(w_,h_,''.join(g))

def kunst_netz(w_=620,h_=620):
    import math
    g=['<circle cx="310" cy="310" r="300" fill="#12305a"/>','<circle cx="310" cy="310" r="220" fill="none" stroke="#1e3a6d" stroke-width="3"/>','<circle cx="310" cy="310" r="140" fill="none" stroke="#1e3a6d" stroke-width="3"/>']
    pts=[]
    for i in range(10):
        a=i*36*math.pi/180.0; r=140 if i%2 else 220
        pts.append((310+r*math.cos(a),310+r*math.sin(a)))
    for i,(x,y) in enumerate(pts):
        g.append('<path d="M310 310 L%.0f %.0f" stroke="#2f4a78" stroke-width="3"/>'%(x,y))
        g.append('<circle cx="%.0f" cy="%.0f" r="%d" fill="%s"/>'%(x,y,16 if i%2 else 11,GOLD if i%4==0 else '#3f5d8f'))
    g.append('<circle cx="310" cy="310" r="58" fill="#0b2545" stroke="#d4af37" stroke-width="4"/>')
    g.append('<rect x="286" y="286" width="48" height="48" rx="12" fill="#d4af37" opacity="0.18"/>')
    return '<svg aria-label="Netz aus Knoten um einen Kern" width="%d" height="%d" viewBox="0 0 620 620">%s</svg>'%(w_,h_,''.join(g))

def kunst_schild(w_=520,h_=560):
    return ('<svg aria-label="Schild mit Schloss als Zeichen für Datenschutz" width="%d" height="%d" viewBox="0 0 520 560">'
      '<path d="M260 20 L480 100 L480 300 C480 430 380 510 260 540 C140 510 40 430 40 300 L40 100 Z" fill="#12305a" stroke="#1e3a6d" stroke-width="6"/>'
      '<path d="M260 60 L440 126 L440 300 C440 408 358 476 260 502 Z" fill="#0b2545"/>'
      '<rect x="190" y="250" width="140" height="120" rx="18" fill="#d4af37"/>'
      '<path d="M215 250 L215 210 C215 185 235 165 260 165 C285 165 305 185 305 210 L305 250" fill="none" stroke="#d4af37" stroke-width="18"/>'
      '<circle cx="260" cy="302" r="16" fill="#0b2545"/><rect x="252" y="306" width="16" height="34" rx="8" fill="#0b2545"/>'
      +''.join('<circle cx="%d" cy="%d" r="4" fill="#e8cf7a" opacity="0.5"/>'%(90+c*62,120+r*58) for r in range(3) for c in range(2))
      +'</svg>')%(w_,h_)

def kunst_weg(items,w_=1660,h_=250):
    g=[]; n=len(items); schritt=(1660-160)//(n-1)
    g.append('<path d="M80 125 L%d 125" stroke="#dce5f5" stroke-width="6"/>'%(80+schritt*(n-1)))
    for i in range(n):
        x=80+i*schritt
        g.append('<circle cx="%d" cy="125" r="46" fill="%s" stroke="%s" stroke-width="6"/>'%(x,NAVY if i<n-1 else GOLD,GOLD if i<n-1 else NAVY))
        g.append('<circle cx="%d" cy="125" r="14" fill="%s"/>'%(x,GOLD if i<n-1 else NAVY))
        if i<n-1:
            g.append('<path d="M%d 115 L%d 125 L%d 135 Z" fill="#d4af37"/>'%(x+schritt-58,x+schritt-44,x+schritt-58))
    return '<svg aria-label="Ablauf in %d Schritten" width="%d" height="%d" viewBox="0 0 1660 250">%s</svg>'%(n,w_,h_,''.join(g))

def kunst_balken(werte,w_=760,h_=420,farben=None):
    g=['<rect x="0" y="0" width="760" height="420" fill="none"/>']
    g.append('<path d="M60 360 L740 360" stroke="#2f4a78" stroke-width="3"/>')
    bw=90; luecke=(680-len(werte)*bw)//(len(werte)+1)
    for i,v in enumerate(werte):
        x=60+luecke+i*(bw+luecke); hh=int(300*v)
        g.append('<rect x="%d" y="%d" width="%d" height="%d" rx="10" fill="%s"/>'%(x,360-hh,bw,hh,(farben or [GOLD]*len(werte))[i]))
    return '<svg aria-label="Balkenbild" width="%d" height="%d" viewBox="0 0 760 420">%s</svg>'%(w_,h_,''.join(g))

def kunst_berg(w_=760,h_=824):
    return ('<svg aria-label="Berglandschaft mit Fahne auf dem Gipfel" width="%d" height="%d" viewBox="0 0 760 824">'
      '<rect width="760" height="824" fill="#0b2545"/>'
      '<circle cx="580" cy="190" r="90" fill="#12305a"/>'
      '<path d="M0 824 L250 420 L430 640 L560 500 L760 824 Z" fill="#12305a"/>'
      '<path d="M180 824 L430 380 L680 824 Z" fill="#183a6b"/>'
      '<path d="M430 380 L500 500 L430 470 L360 500 Z" fill="#e8f0ff" opacity="0.9"/>'
      '<path d="M430 380 L430 250" stroke="#d4af37" stroke-width="7"/>'
      '<path d="M430 250 L520 278 L430 306 Z" fill="#d4af37"/>'
      +''.join('<circle cx="%d" cy="%d" r="3" fill="#e8cf7a" opacity="0.45"/>'%(60+c*84,90+r*70) for r in range(3) for c in range(4))
      +'</svg>')%(w_,h_)

# ============================ FOLIEN ============================

# 1 Titel
w('cover','<section id="cover" style="background:%s; color:%s; font-family:%s; padding:0; display:flex; flex-direction:column">\n'
 '  <div style="position:absolute; right:0px; top:0px; width:760px; height:824px">%s</div>\n'
 '  <div style="position:absolute; left:0px; top:0px; width:14px; height:1080px; background:%s"></div>\n'
 '  <div style="position:absolute; left:128px; top:120px; width:940px; display:flex; flex-direction:column; gap:34px">\n'
 '    <div style="display:flex; gap:26px; align-items:center">%s'
 '      <div style="display:flex; flex-direction:column; gap:6px">'
 '        <p style="font-size:64px; font-weight:700; line-height:1; color:%s">Klassenportal</p>'
 '        <p style="font-size:22px; font-weight:600; letter-spacing:4px; text-transform:uppercase; color:%s">Verwaltung für Bildungsträger</p>'
 '      </div>\n    </div>\n'
 '    <h1 style="font-size:104px; font-weight:700; line-height:1.05; color:%s">Bildung organisieren.<br>Nachweis führen.<br>Frist halten.</h1>\n'
 '    <p style="font-size:32px; line-height:1.45; color:%s; width:860px">Von der Bewerbung bis zum Zeugnis — ein System, das den Beleg führt, den Kostenträger, Aufsicht und fachkundige Stelle sehen wollen.</p>\n'
 '  </div>\n'
 '  <div style="position:absolute; left:128px; bottom:96px; display:flex; gap:40px; align-items:center">\n'
 '    <p style="font-size:24px; font-weight:600; letter-spacing:2px; text-transform:uppercase; color:%s">Offen</p>\n'
 '    <p style="font-size:24px; color:%s">·</p>\n'
 '    <p style="font-size:24px; font-weight:600; letter-spacing:2px; text-transform:uppercase; color:%s">Prüfbar</p>\n'
 '    <p style="font-size:24px; color:%s">·</p>\n'
 '    <p style="font-size:24px; font-weight:600; letter-spacing:2px; text-transform:uppercase; color:%s">In der EU betrieben</p>\n'
 '  </div>\n'
 '  <p style="position:absolute; right:128px; bottom:96px; font-size:24px; color:%s">klassenportal.app</p>\n'
 '  <aside>Der Titel nennt das Versprechen in drei Worten: organisieren, nachweisen, Frist halten.</aside>\n'
 '</section>\n'%(NAVY,LIGHT,F,kunst_architektur(),GOLD,mono(96),LIGHT,GOLD,LIGHT,MUTD,GOLD,MUTD,GOLD,MUTD,GOLD,MUTD))

# 2 Problem
w('problem',hell('problem',
  eyebrow('Der Ausgangspunkt')+'\n'+h2('Neun Werkzeuge, ein Träger')+'\n'+
  kartenreihe([('Chart','Excel und Outlook','Teilnehmerlisten, Bewerbungen, Wiedervorlagen — bis die Person geht, in deren Postfach alles lag.'),
               ('Book','Papier und Ordner','Klassenbuch, Anwesenheit, Unterweisungen: im Prüfungsfall vorhanden, aber nicht auffindbar.'),
               ('Tool','Insellösungen','Ein Werkzeug für den Stundenplan, eins für Rechnungen — und keins, das beide kennt.')])+'\n'+
  '  <div style="display:flex; gap:26px; background:%s; padding:34px 40px; border-radius:18px; align-items:center">%s'
  '<p style="font-size:29px; line-height:1.45; color:%s">Jede Lücke zwischen zwei Werkzeugen ist eine Stelle, an der etwas verloren geht — und die Prüfung fragt genau danach.</p></div>'%(NAVY,badge('Warning',GOLD,NAVY,52,28),LIGHT),
  'Nicht die fehlende Software ist das Problem, sondern die Übergänge.'))

# 3 Kosten
w('kosten',dunkel('kosten',
  eyebrow('Was das kostet')+'\n'+h2('Nicht in Lizenzen. In Fristen.',LIGHT)+'\n'+
  '  <div style="display:flex; gap:26px">\n'+
  ''.join('    <div style="flex:1; display:flex; flex-direction:column; gap:16px; background:%s; padding:38px; border-radius:18px">%s'
          '<p style="font-size:76px; font-weight:700; line-height:1; color:%s">%s</p>'
          '<p style="font-size:25px; line-height:1.45; color:%s">%s</p></div>\n'%(NAVY2,badge(ic,NAVY,GOLD,56,30),GOLD,z,MUTD,t)
     for ic,z,t in [('Clock','6 Monate','Frist des § 15 AGG. Wer sie verpasst, hat Bewerberdaten zu lange — oder zu früh gelöscht.'),
                    ('Warning','72 Stunden','für die Meldung eines Datenschutzvorfalls. Ab Kenntnis, nicht ab Erfassung.'),
                    ('Lock','1 Tag','nach Ablauf gilt eine übersehene Befristung als unbefristet fortgesetzt.')])+
  '  </div>\n'+
  unter('Keine dieser Fristen steht in einem Kalender. Sie stehen in Gesetzen — und fallen auf, wenn es zu spät ist.',MUTD,29)))

# 4 Für wen
w('was',hell('was',
  eyebrow('Für wen')+'\n'+h2('Ein System. Der ganze Weg.')+'\n'+
  kartengitter([('GraduationCap','Bildungsträger','AZAV-zugelassen, mit Kostenträgern und Maßnahmen'),
                ('Users','Umschulung','Lange Maßnahmen mit Förderfällen und Nachweispflicht'),
                ('Activity','Weiterbildung','Kurze Kurse, viele Teilnehmende, schnelle Abrechnung'),
                ('Home','Berufsfachschulen','Klassen, Stundenplan, Zeugnisse')],4)+'\n'+
  '  <div style="display:flex; gap:26px; align-items:stretch">\n'
  '    <div style="flex:1; background:%s; padding:36px; border-radius:18px; display:flex; flex-direction:column; gap:16px">%s'
  '<h3 style="font-size:30px; font-weight:700; color:%s">Betrieben in der EU</h3>'
  '<p style="font-size:25px; line-height:1.45; color:%s">Ohne eigenen Server, ohne Wartungsfenster. Personenbezogene Daten verlassen die EU nicht — auch nicht als letzte Rettung.</p></div>\n'
  '    <div style="flex:1; background:%s; padding:36px; border:1px solid %s; border-radius:18px; display:flex; flex-direction:column; gap:16px">%s'
  '<h3 style="font-size:30px; font-weight:700; color:%s">Ihre Daten bleiben Ihre</h3>'
  '<p style="font-size:25px; line-height:1.45; color:%s">Der vollständige Export ist ein Knopf, kein Antrag — mit Prüfsummen und Zeilenzahlen.</p></div>\n'
  '  </div>'%(NAVY,badge('Globe',NAVY2,GOLD,56,30),GOLD,MUTD,WHITE,LINIE,badge('Key',GOLDT,'#8a6d1f',56,30),NAVY,MUT)))

# 5 Bewerberpfad
w('bewerbung',hell('bewerbung',
  eyebrow('1 — Eintritt')+'\n'+h2('Der Bewerberpfad, ohne privates Postfach')+'\n'+
  '  <div style="position:absolute; left:128px; top:300px; width:1660px; height:250px">%s</div>\n'%kunst_weg(range(5))+
  '  <div style="position:absolute; left:128px; top:560px; width:1660px; display:flex; gap:26px">\n'+
  ''.join('    <div style="flex:1; display:flex; flex-direction:column; gap:10px">'
          '<h3 style="font-size:27px; font-weight:700; color:%s">%s</h3>'
          '<p style="font-size:23px; line-height:1.4; color:%s">%s</p></div>\n'%(NAVY,t,MUT,b)
     for t,b in [('Formular','Öffentlich erreichbar, Vorgangsnummer sofort'),
                 ('Eingang','Bestätigung automatisch, Unterlagen im Vorgang'),
                 ('Nachforderung','Mit Frist und Einmal-Link, Erinnerung inklusive'),
                 ('Entscheidung','Zusage, Absage, Warteliste — nachweisbar'),
                 ('Teilnahme','Ohne zweites Abtippen')])+
  '  </div>\n'+
  '  <div style="position:absolute; left:128px; top:790px; width:1660px; display:flex; gap:24px; background:%s; padding:30px 36px; border-radius:18px; align-items:center">%s'
  '<p style="font-size:28px; line-height:1.4; color:%s">Die interne Entscheidungsnotiz geht <b>nie</b> mit hinaus. Eine durchgereichte Absagenotiz ist der kürzeste Weg in ein AGG-Verfahren.</p></div>'%(NAVY,badge('Lock',NAVY2,GOLD,50,26),LIGHT)))

# 6 Oberfläche
w('unterricht','<section id="unterricht" style="background:%s; color:%s; font-family:%s; padding:104px 128px 160px; display:flex; flex-direction:column; gap:30px">\n'
 '%s\n%s\n'
 '  <div style="display:flex; gap:40px; align-items:center">\n'
 '    <div style="width:900px; height:520px">%s</div>\n'
 '    <div style="display:flex; flex-direction:column; gap:26px">\n'
 '      <div style="width:230px; height:440px">%s</div>\n'
 '    </div>\n'
 '    <div style="flex:1; display:flex; flex-direction:column; gap:20px">%s</div>\n'
 '  </div>\n'
 '  <aside>Dieselbe Oberfläche am Schreibtisch und unterwegs.</aside>\n</section>\n'%(
   LIGHT,DARK,F,eyebrow('2 — Betrieb'),h2('Stundenplan, Klassenbuch, Anwesenheit'),
   kunst_ui(),kunst_telefon(),
   hakenliste(['Planung mit Raum und Lehrkraft','Klassenbuch führt sich mit','Regeln melden Auffälliges','Berichtsheft aus der Anwesenheit'],NAVY,25)[2:]))

# 7 Nachweis
w('nachweis',dunkel('nachweis',
  eyebrow('3 — Nachweis')+'\n'+h2('Was der Kostenträger sehen will',LIGHT)+'\n'+
  kartenreihe([('Database','Förderfälle','Kostenträger, Maßnahmenummer, Eintritt, Austritt, Austrittsgrund — je Person, je Kurs.'),
               ('Chart','Abrechnung','Teilnahmetage aus der erfassten Anwesenheit. Keine zweite Zahlenpflege.'),
               ('PaperPlane','Meldungen','KURSNET-Katalog und eM@w-Dateien aus demselben Bestand.')],
              grund=NAVY2,rand=NAVY2,tf=GOLD,xf=MUTD,bg=NAVY,fg=GOLD)+'\n'+
  unter('Der Träger meldet, was er ohnehin führt. Das ist der Unterschied zwischen einer Meldung und einer Meldungsvorbereitung.',MUTD,29)))

# 8 Prüfungen
w('pruefung',hell('pruefung',
  eyebrow('4 — Abschluss')+'\n'+h2('Prüfungen und Zeugnisse')+'\n'+
  kartenreihe([('Verified','Prüfung','Termine, Räume, Nachteilsausgleich, Varianten — mit einer Verwahrkette, die eine versiegelte Prüfung zulässt.'),
               ('Star','Bewertung','Rubriken und Zweitkorrektur; der Einspruch hat seinen eigenen Weg.'),
               ('Trust','Zeugnis','Selbsttragender Nachweis: prüfbar, auch wenn es den Träger in zehn Jahren nicht mehr gibt.')])+'\n'+
  unter('Ein Zeugnis wird Jahrzehnte später gebraucht. Deshalb hängt seine Prüfbarkeit nicht am Fortbestand des Ausstellers.',MUT,29)))

# 9 Personal
w('personal',hell('personal',
  eyebrow('5 — Personal')+'\n'+h2('Die Personalakte, die der Prüfung standhält')+'\n'+
  '  <div style="display:flex; gap:32px; align-items:stretch">\n'
  '    <div style="flex:1; display:flex; flex-direction:column; gap:20px">%s</div>\n'
  '    <div style="flex:1; background:%s; padding:40px; border-radius:18px; display:flex; flex-direction:column; gap:20px">%s'
  '      <h3 style="font-size:32px; font-weight:700; color:%s">Der Austritt entzieht den Zugang</h3>'
  '      <p style="font-size:26px; line-height:1.45; color:%s">Verträge beendet, Anträge storniert, Konto gesperrt, laufende Sitzungen gelöscht — in einem Zug.</p>'
  '      <p style="font-size:26px; line-height:1.45; color:%s">Was noch offen ist, kommt aus dem Bestand: das ausgegebene Notebook, der laufende Kurs.</p>'
  '    </div>\n  </div>'%(
    hakenliste(['Vertrag, Beschäftigungszeitraum, Probezeit','Urlaubsanspruch, Übertrag, Rest — gerechnet','Krankheit mit Nachweis ab dem vierten Tag','Unterweisungen mit Frist und Erinnerung','Auslaufende Befristungen melden sich selbst'],NAVY,27)[2:],
    NAVY,badge('Key',NAVY2,GOLD,60,32),GOLD,MUTD,MUTD),
  'Der häufigste Befund in der Praxis: die Lehrkraft ist weg, der Zugang ist geblieben.'))

# 10 QM
w('qm',hell('qm',
  eyebrow('6 — Qualität')+'\n'+h2('AZAV ist kein Ordner, sondern ein System')+'\n'+
  kartengitter([('Star','Ziele','Mit Messgröße und Zielwert. Der Istwert wird gerechnet, nicht gepflegt.'),
                ('Settings','Prozesse','Prozessregister mit eigenem Prüfintervall — wonach die fachkundige Stelle zuerst fragt.'),
                ('Search','Audits','Eine Abweichung erzeugt eine Maßnahme mit Frist. Ohne Erledigung schließt das Audit nicht.'),
                ('CheckCircle','Bewertung','Die Managementbewertung zieht ihre Eingaben selbst und friert sie ein.')],4)+'\n'+
  '  <div style="display:flex; gap:24px; background:%s; padding:30px 36px; border-radius:18px; align-items:center">%s'
  '<p style="font-size:28px; line-height:1.4; color:%s">Zulassungen laufen ab. Das Portal meldet sich 90 Tage vorher — und führt ein abgelaufenes danach auch als abgelaufen.</p></div>'%(NAVY,badge('Clock',NAVY2,GOLD,50,26),LIGHT)))

# 11 Vertrieb
w('vertrieb',hell('vertrieb',
  eyebrow('7 — Vertrieb')+'\n'+h2('Vom Interessenten bis zum Vertrag')+'\n'+
  kartenreihe([('Chat','Vorgang','Organisation, Ansprechpartner, Kontakthistorie — mit nächstem Schritt und Wiedervorlage als Pflicht.'),
               ('PaperPlane','Angebot','Maßnahmeplan abgeleitet statt abgetippt; Pflichtanlagen werden vor dem Versand geprüft.'),
               ('Book','Verhandlung','Eine neue Fassung ersetzt die alte nicht. Was ursprünglich angeboten wurde, bleibt lesbar.')])+'\n'+
  '  <div style="display:flex; gap:24px; background:%s; padding:30px 36px; border-radius:18px; align-items:center">%s'
  '<p style="font-size:28px; line-height:1.4; color:%s"><b>„Gewonnen"</b> heißt: es gibt ein angenommenes Angebot. Wer den Stand selbst setzen darf, misst die Zuversicht des Vertriebs.</p></div>'%(NAVY,badge('Verified',NAVY2,GOLD,50,26),LIGHT)))

# 12 Inventar
w('inventar',hell('inventar',
  eyebrow('8 — Ausstattung')+'\n'+h2('Inventar, Beschaffung, Bibliothek')+'\n'+
  kartenreihe([('Tool','Inventar','Wer hat was, seit wann. Beim Abgang die Frage, die sonst niemand stellt.'),
               ('Users','Beschaffung','Über einer Betragsgrenze zwei Personen — und zwei heißt zwei, nicht dieselbe zweimal.'),
               ('Wrench','Wartung','Ein sicherheitsrelevanter Mangel sperrt den Raum wirklich, statt eine Notiz zu sein.')])+'\n'+
  unter('Die Bibliothek vergibt Exemplare in der Reihenfolge der Vormerkung — entschieden nach Zeitpunkt, nicht nach Zufall.',MUT,29)))

# 13 Meldewesen
w('melden',dunkel('melden',
  eyebrow('9 — Schnittstellen')+'\n'+h2('Melden, ohne zweimal zu erfassen',LIGHT)+'\n'+
  '  <div style="display:flex; gap:40px; align-items:center">\n'
  '    <div style="flex:1; display:flex; flex-direction:column; gap:22px">%s</div>\n'
  '    <div style="width:620px; height:620px">%s</div>\n  </div>\n'%(
     ''.join('      <div style="display:flex; gap:22px; align-items:center; background:%s; padding:26px 30px; border-radius:16px">%s'
             '<div style="display:flex; flex-direction:column; gap:6px">'
             '<h3 style="font-size:28px; font-weight:700; color:%s">%s</h3>'
             '<p style="font-size:24px; line-height:1.35; color:%s">%s</p></div></div>\n'%(NAVY2,badge(ic,NAVY,GOLD,50,26),GOLD,t,MUTD,b)
        for ic,t,b in [('PaperPlane','KURSNET','Kurskatalog im open-Qcat-Format, von der Bundesagentur selbst abgeholt'),
                       ('Database','eM@w','Ereignisdateien nach dem amtlichen Schema, Richtung geprüft'),
                       ('Users','SCIM / OIDC','Benutzerverwaltung des Trägers, je Mandant abschaltbar'),
                       ('Cloud','Mail und Speicher','EU-Anbieter, über Adapterketten austauschbar')]),
     kunst_netz()),
  'Vier Schnittstellen, eine Quelle.'))

# 14 Regel: gerechnet
w('gerechnet',dunkel('gerechnet',
  eyebrow('Die erste Regel')+'\n'+
  '  <h2 style="font-size:88px; font-weight:700; line-height:1.1; color:%s; width:1350px">Eine Zahl, die jemand eintippt,<br>ist keine Kennzahl.</h2>\n'%GOLD+
  '  <div style="position:absolute; right:128px; top:180px; width:760px; height:420px">%s</div>\n'%kunst_balken([0.34,0.67,0.33,0.86],farben=[GOLD,GOLD,GOLD,GOLDH])+
  '  <div style="position:absolute; left:128px; top:470px; width:1180px; display:flex; flex-direction:column; gap:22px">%s</div>\n'%(
     hakenliste(['Abbruchquote aus den Förderfällen','Erfolgsquote aus den Austrittsgründen','Vermittlungsquote auf die Beendeten','Anwesenheitsquote aus dem Klassenbuch'],MUTD,27)[2:])+
  '  <p style="position:absolute; left:128px; bottom:150px; width:1400px; font-size:28px; line-height:1.45; color:%s">Ein Ziel mit gerechneter Messgröße nimmt gar keinen getippten Istwert an — zwei Zahlen für dieselbe Sache sind genau das, wonach die fachkundige Stelle fragt.</p>'%MUTD,
  'Dieselbe Regel gilt im Vertrieb, in der Abrechnung und im Maßnahmeplan eines Angebots.'))

# 15 fail closed
w('failclosed',hell('failclosed',
  eyebrow('Die zweite Regel')+'\n'+h2('Im Zweifel: nicht ausführen')+'\n'+
  kartenreihe([('Lock','Datenklasse','Ohne Einstufung geht keine Eingabe an ein KI-Modell. Eine Vorgabe wäre die Regel, die sich beim ersten Zeitdruck selbst aushebelt.'),
               ('Search','Auskunft','Eine Tabelle mit Personenspalte, die nicht im Register steht, lässt den Vertragstest scheitern.'),
               ('Warning','Löschung','Eine aktive Löschsperre schlägt jede Frist — ohne Ausnahme und ohne Abwägung.')])+'\n'+
  '  <div style="display:flex; gap:24px; background:%s; padding:30px 36px; border-radius:18px; align-items:center">%s'
  '<p style="font-size:30px; line-height:1.4; color:%s">Fail closed ist unbequem. Genau deshalb wirkt es.</p></div>'%(NAVY,badge('Trust',NAVY2,GOLD,50,26),LIGHT)))

# 16 Protokoll
w('protokoll',hell('protokoll',
  eyebrow('Nachweis')+'\n'+h2('Ein Protokoll, das sich nicht ändern lässt')+'\n'+
  '  <div style="width:1400px; height:300px">%s</div>\n'%kunst_kette()+
  '  <div style="display:flex; gap:26px">\n'+
  ''.join('    <div style="flex:1; display:flex; flex-direction:column; gap:14px">%s'
          '<h3 style="font-size:28px; font-weight:700; color:%s">%s</h3>'
          '<p style="font-size:24px; line-height:1.4; color:%s">%s</p></div>\n'%(badge(ic,GOLDT,'#8a6d1f',50,26),NAVY,t,MUT,b)
     for ic,t,b in [('Warning','Ändern fällt auf','Die Prüfsumme der Zeile passt nicht mehr zu ihrem Inhalt.'),
                    ('Warning','Löschen fällt auf','Die Position fehlt, der Nachfolger nennt einen fremden Vorgänger.'),
                    ('Verified','Neu aufbauen fällt auf','Das Siegel belegt, dass es Position 4711 mit genau diesem Hash gab.')])+
  '  </div>\n'+
  unter('Der tägliche Lauf prüft — und siegelt erst danach. Ein Siegel auf eine gebrochene Kette schriebe den gefälschten Stand als geprüft fest.',MUT,27)))

# 17 Datenschutz
w('datenschutz',dunkel('datenschutz',
  eyebrow('Datenschutz')+'\n'+h2('Auskunft, Löschung, Sperre',LIGHT)+'\n'+
  '  <div style="position:absolute; right:150px; top:210px; width:520px; height:560px">%s</div>\n'%kunst_schild()+
  '  <div style="position:absolute; left:128px; top:300px; width:1080px; display:flex; flex-direction:column; gap:24px">\n'+
  ''.join('    <div style="display:flex; gap:24px; align-items:center; background:%s; padding:28px 32px; border-radius:16px">%s'
          '<div style="display:flex; flex-direction:column; gap:6px">'
          '<p style="font-size:38px; font-weight:700; line-height:1.1; color:%s">%s</p>'
          '<p style="font-size:24px; line-height:1.35; color:%s">%s</p></div></div>\n'%(NAVY2,badge(ic,NAVY,GOLD,52,28),GOLD,z,MUTD,t)
     for ic,z,t in [('Database','295 Verarbeitungen','im Verzeichnis nach Art. 30 — erzeugt aus dem Quelltext, nicht abgetippt'),
                    ('Key','Ein Knopf','für die vollständige Auskunft. Kein Antrag, keine Wartezeit.'),
                    ('Lock','Keine Zahlungsdaten','die produktive Zahlungsabwicklung ist ausdrücklich abgeschaltet')])+
  '  </div>\n'+
  '  <p style="position:absolute; left:128px; bottom:150px; width:1080px; font-size:27px; line-height:1.45; color:%s">Anonymisierte Zeilen bleiben stehen: eine gelöschte Bewerbung wäre später nicht von einer nie eingegangenen zu unterscheiden.</p>'%MUTD))

# 18 KI
w('ki',hell('ki',
  eyebrow('Künstliche Intelligenz')+'\n'+h2('Eingestuft, wiederverwendet, im Hintergrund')+'\n'+
  kartenreihe([('Settings','Eingestuft','Jeder Zweck trägt Verarbeitungsart, Datenklasse und Kostengrenze. Was nicht eingestuft ist, läuft nicht.'),
               ('Lightning','Wiederverwendet','Dieselbe Frage zur selben Grundlage kostet kein zweites Mal — und liefert dasselbe Ergebnis, nicht ein ähnliches.'),
               ('Clock','Im Hintergrund','Erzeugung läuft als Auftrag mit Fortschritt und Wiederaufnahme. Niemand sitzt vor dem Ladebalken.')])+'\n'+
  '  <div style="display:flex; gap:24px; background:%s; padding:30px 36px; border-radius:18px; align-items:center">%s'
  '<p style="font-size:28px; line-height:1.4; color:%s">Die Datenklasse kommt aus dem Register, nicht aus der Anfrage. Wer „öffentlich" behaupten kann, schickt irgendwann Namen außer Landes.</p></div>'%(NAVY,badge('Lock',NAVY2,GOLD,50,26),LIGHT)))

# 19 Betrieb
w('betrieb',hell('betrieb',
  eyebrow('Betrieb')+'\n'+h2('Kein Server, keine Wartungsfenster')+'\n'+
  kartenreihe([('Globe','In der EU','Datenbank und Dateien in der EU. Personenbezogene Daten gehen nicht in andere Regionen — auch nicht als letzte Rettung.'),
               ('Activity','Gedeckelt','Jeder Lauf hat eine Grenze. Eine Schleife, die mit den Daten wächst, wird im Test benannt und begrenzt.'),
               ('Chart','Sichtbar','Betriebszustand, Zielwerte und Verbrauch in einer Ansicht — bevor die Rechnung kommt.')])+'\n'+
  unter('Die tägliche Speicherstichprobe ergibt die Messreihe, aus der sich die Restzeit bis zur harten Speichergrenze ablesen lässt. Ohne sie fällt die Wand ohne Vorwarnung.',MUT,28)))

# 20 Umzug
w('umzug',dunkel('umzug',
  eyebrow('Unabhängigkeit')+'\n'+
  '  <h2 style="font-size:82px; font-weight:700; line-height:1.1; color:%s; width:1200px">Ein Wechsel ist keine Neuentwicklung.</h2>\n'%LIGHT+
  '  <div style="position:absolute; right:128px; top:150px; width:620px; height:620px">%s</div>\n'%kunst_netz()+
  '  <div style="position:absolute; left:128px; top:420px; width:1080px; display:flex; flex-direction:column; gap:22px">\n'+
  ''.join('    <div style="display:flex; gap:22px; align-items:center; background:%s; padding:26px 30px; border-radius:16px">%s'
          '<div style="display:flex; flex-direction:column; gap:6px">'
          '<h3 style="font-size:28px; font-weight:700; color:%s">%s</h3>'
          '<p style="font-size:24px; line-height:1.35; color:%s">%s</p></div></div>\n'%(NAVY2,badge(ic,NAVY,GOLD,50,26),GOLD,t,MUTD,b)
     for ic,t,b in [('Database','Export','Der vollständige Export eines Trägers ist ein Knopf — mit Prüfsummen und Zeilenzahlen.'),
                    ('Link','Anbieter','Mail, Speicher und KI laufen über Adapterketten. Ein Wechsel ist ein Eintrag, keine Programmänderung.'),
                    ('Users','Rechtsnachfolge','Ein Mandant lässt sich übergeben, nicht nur löschen.')])+
  '  </div>',
  'Der Punkt, an dem sich ein Träger von einem Anbieter unterscheidet, der ihn festhält.'))

# 21 Sicherheit
w('sicherheit',hell('sicherheit',
  eyebrow('Zugriff')+'\n'+h2('Wer was sieht — und wer nicht')+'\n'+
  kartenreihe([('Lock','Mandantentrennung','Die Mandantenkennung kommt aus dem angemeldeten Zugriff, nie aus der Anfrage.'),
               ('Clock','Support nur auf Freigabe','Höchstens 72 Stunden, nur lesend, jederzeit widerrufbar, jeder Zugriff im Protokoll.'),
               ('Warning','Notfallzugriff','Die Ausnahme für den Störfall: befristet, lesend, der Leitung gemeldet.')])+'\n'+
  '  <div style="display:flex; gap:24px; background:%s; padding:30px 36px; border-radius:18px; align-items:center">%s'
  '<p style="font-size:28px; line-height:1.4; color:%s">Geprüft wird immer auf dem Server. Die Oberfläche blendet nur aus, was ohnehin abgewiesen würde.</p></div>'%(NAVY,badge('Trust',NAVY2,GOLD,50,26),LIGHT)))

# 22 Einführung
w('einfuehrung',hell('einfuehrung',
  eyebrow('Einführung')+'\n'+h2('Vier Wochen, nicht vier Monate')+'\n'+
  '  <div style="width:1660px; height:250px">%s</div>\n'%kunst_weg(range(4))+
  '  <div style="display:flex; gap:26px">\n'+
  ''.join('    <div style="flex:1; display:flex; flex-direction:column; gap:12px; background:%s; padding:32px; border:1px solid %s; border-radius:18px">'
          '<p style="font-size:24px; font-weight:700; letter-spacing:2px; text-transform:uppercase; color:#8a6d1f">Woche %d</p>'
          '<h3 style="font-size:29px; font-weight:700; color:%s">%s</h3>'
          '<p style="font-size:24px; line-height:1.4; color:%s">%s</p></div>\n'%(WHITE,LINIE,i+1,NAVY,t,MUT,b)
     for i,(t,b) in enumerate([('Fundament','Stammdaten, zwei bis drei Leitungsrollen, Fristen bestätigen.'),
                               ('Menschen und Kurse','Listen einspielen, Lehrkräfte anlegen, Stundenplan.'),
                               ('Betrieb','Anwesenheit führen, Bewerbungsformular, Beschwerdeweg.'),
                               ('Nachweis','Qualitätsziele, Zulassungen, erstes internes Audit.')]))+
  '  </div>\n'+
  unter('Eine Stunde Schulung für die Leitung, eine für die Lehrkräfte, eine halbe für die Verwaltung. Mehr braucht es nicht, wenn die Rollen eng geschnitten sind.',MUT,27)))

# 23 Grenzen
w('grenzen',hell('grenzen',
  eyebrow('Ehrlichkeit')+'\n'+h2('Was das Portal nicht tut')+'\n'+
  '  <table style="font-family:%s; font-size:27px; color:%s">\n'
  '    <tr style="background:%s"><th style="width:32%%; color:%s; text-align:left; padding:20px 24px">Punkt</th>'
  '<th style="width:30%%; color:%s; text-align:left">Stand</th><th style="width:38%%; color:%s; text-align:left">Grund</th></tr>\n'
  '    <tr><td>Produktive Zahlungsabwicklung</td><td>abgeschaltet</td><td>bleibt es, bis sie ausdrücklich freigegeben wird</td></tr>\n'
  '    <tr style="background:%s"><td>XBildung-Meldungen</td><td>vorbereitet</td><td>wartet auf die Freigabe der Codelisten</td></tr>\n'
  '    <tr><td>eM@w-Versand</td><td>Datei, kein Versand</td><td>der Träger sendet über seinen eigenen Zugang</td></tr>\n'
  '    <tr style="background:%s"><td>Lohnbuchhaltung</td><td>nicht enthalten</td><td>Personalakte ja, Abrechnung beim Steuerbüro</td></tr>\n'
  '  </table>\n'%(F,DARK,NAVY,GOLD,GOLD,GOLD,'#eef3fb','#eef3fb')+
  '  <div style="display:flex; gap:24px; background:%s; padding:30px 36px; border-radius:18px; align-items:center">%s'
  '<p style="font-size:28px; line-height:1.4; color:%s">Was nicht geht, steht dabei. Eine Zusage, die im Betrieb nicht hält, kostet mehr als eine fehlende Funktion.</p></div>'%(NAVY,badge('Check',NAVY2,GOLD,50,26),LIGHT)))

# 24 Stand
w('stand',dunkel('stand',
  eyebrow('Stand heute')+'\n'+h2('Was gebaut und geprüft ist',LIGHT)+'\n'+
  '  <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:26px">\n'+
  ''.join('    <div style="display:flex; gap:22px; align-items:center; background:%s; padding:30px; border-radius:18px">%s'
          '<div style="display:flex; flex-direction:column; gap:4px">'
          '<p style="font-size:52px; font-weight:700; line-height:1; color:%s">%s</p>'
          '<p style="font-size:23px; line-height:1.35; color:%s">%s</p></div></div>\n'%(NAVY2,badge(ic,NAVY,GOLD,52,28),GOLD,z,MUTD,t)
     for ic,z,t in [('CheckCircle','234','Prüfläufe, vor jeder Auslieferung grün'),
                    ('Link','474','Wege, jeder bedienbar oder begründet'),
                    ('Chat','577','Fehlerfälle mit deutschem Klartext'),
                    ('Users','0','maschinell prüfbare WCAG-Verstöße'),
                    ('Database','147','Datenbankschritte, einzeln nachvollziehbar'),
                    ('Book','8','Übergabedokumente, vier erzeugt')])+
  '  </div>\n'+
  unter('Gemessen, nicht gerundet — dieselbe Regel wie im Produkt. Wer die Präsentation später zeigt, hält sie gegen den dann aktuellen Stand.',MUTD,27)))

# 25 Abschluss
w('schluss','<section id="schluss" style="background:%s; color:%s; font-family:%s; padding:0; display:flex; flex-direction:column">\n'
 '  <div style="position:absolute; right:0px; top:0px; width:760px; height:824px">%s</div>\n'
 '  <div style="position:absolute; left:0px; top:0px; width:14px; height:1080px; background:%s"></div>\n'
 '  <div style="position:absolute; left:128px; top:150px; width:980px; display:flex; flex-direction:column; gap:30px">\n'
 '    <div style="display:flex; gap:24px; align-items:center">%s'
 '      <p style="font-size:44px; font-weight:700; color:%s">Klassenportal</p></div>\n'
 '    <h2 style="font-size:92px; font-weight:700; line-height:1.08; color:%s">Der Nachweis ist das Produkt.</h2>\n'
 '    <p style="font-size:30px; line-height:1.5; color:%s; width:900px">Die Software verwaltet nicht nur den Betrieb eines Bildungsträgers. Sie führt den Beleg, dass er ihn geführt hat — gegenüber Kostenträger, Aufsicht und fachkundiger Stelle.</p>\n'
 '    <div style="display:flex; flex-direction:column; gap:18px">%s</div>\n'
 '  </div>\n'
 '  <p style="position:absolute; left:128px; bottom:96px; font-size:24px; color:%s">klassenportal.app</p>\n'
 '  <aside>Der Satz, mit dem man aus dem Raum geht.</aside>\n</section>\n'%(
   NAVY,LIGHT,F,kunst_berg(),GOLD,mono(64),LIGHT,LIGHT,MUTD,
   ''.join('      <div style="display:flex; gap:20px; align-items:center">%s<p style="font-size:27px; color:%s">%s</p></div>\n'%(badge(ic,NAVY2,GOLD,46,24),MUTD,t)
      for ic,t in [('Chat','Persönliche Beratung und Demo am echten Bestand'),
                   ('Book','Übergabepaket mit acht Unterlagen, prüfbar'),
                   ('Check','Einführung in vier Wochen')]),
   MUTD))

print('geschrieben:',len(os.listdir(B)))

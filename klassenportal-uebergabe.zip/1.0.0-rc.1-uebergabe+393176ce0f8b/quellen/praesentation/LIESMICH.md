# Produktpräsentation

27 Folien, verbindlich im Markenbild des Produkts: Navy #0B2545 trägt, Gold #D4AF37 markiert,
Inter durchgehend. Dieselben Werte stehen in `public/design-tokens.css` und werden von
`tests/design-system.mjs` festgehalten — die Präsentation und das Portal können nicht
auseinanderlaufen, ohne dass es auffällt.

## Aufbau

| Folien | Abschnitt |
| --- | --- |
| 1–4 | Wofür das Portal gebaut ist und was ein Träger heute ohne es zahlt |
| 5–8 | Der Weg durch das Haus: Bewerbung, Unterricht, Nachweis, Abschluss |
| 9–13 | Personal, Qualität, Vertrieb, Ausstattung, Meldewesen |
| 14–18 | Die Regeln: gerechnet statt getippt, fail closed, nachweisbar, Datenschutz, KI |
| 19–22 | Betrieb, Unabhängigkeit, Zugriff, Einführung |
| 23–24 | Ausblick: was geplant ist und heute ausdrücklich nicht geht |
| 25–27 | Grenzen, Stand, Abschluss |

## Die Zahlen auf Folie 26

Sie sind gemessen, nicht geschätzt, und stammen aus dem Stand dieses Pakets:

- 234 Prüfläufe (`npm test`)
- 474 Wege im Portal (`tests/feature-reachable.mjs`)
- 577 Fehlerfälle mit deutschem Klartext (`tests/error-text-coverage.mjs`)
- 0 maschinell prüfbare WCAG-Verstöße (`tests/accessibility-wcag.mjs`)
- 147 Datenbankschritte (`migrations/`)
- 9 Übergabedokumente (`docs/uebergabe/`)

Wer die Präsentation später zeigt, sollte sie vorher gegen den dann aktuellen Stand halten.

## Bildsprache

Die Folien tragen heute eigene Grafiken (Monogramm, Gebäudemotiv, Zeitstrahl, Ketten- und
Netzmotiv) als SVG direkt in der Folie. Sie bleiben in jeder Größe scharf und behaupten nichts,
was es nicht gibt.

Für den hochwertigen Auftritt sind sie als Platzhalter gedacht: `bild-prompts.md` enthält für
jede der 27 Folien einen fertigen Bild-Prompt im Markenbild (Navy, Gold, Inter, Fotostil,
erwachsene Lernende, keine Schrift im Bild). Wer die Bilder erzeugt oder eigene Fotos hat,
legt sie als `bild-<kennung>.jpg` ab; sie treten dann an die Stelle der Grafiken.

Oberflächen-Ansichten (Laptop, Telefon) werden nicht als Bild erzeugt, sondern aus der echten
Oberfläche gerendert — ein Bildmodell schreibt unleserliche Beschriftungen.

`folien-bauen.py` erzeugt alle Folien neu — dort stehen Farben, Bausteine und Grafiken an einer
Stelle.

## Dateien

`deck.json` ist das Verzeichnis (Reihenfolge, Abschnitte, Schrift), `slides/<kennung>.html` je
eine Folie. Jede Folie ist eigenständiges HTML auf einer festen Fläche von 1920 × 1080 Punkten;
die Sprechernotizen stehen als `<aside>` am Ende der Folie.

## Ausblick-Folien

Folie 23 und 24 nennen Mobile App, Anbindung an Schulsysteme, digitalen Zwilling und Marktplatz.
Alle vier sind **nicht gebaut**. Sie stehen ausdrücklich als Planung ohne Datum auf den Folien,
damit die Präsentation das Thema abdeckt, ohne eine Funktion zu behaupten, die im Code nicht
existiert. Wird eines davon gebaut, wandert es auf die Folien davor und verschwindet hier.

# Bild-Prompts für die Produktpräsentation

**Stilzeile** — einmal kopieren und vor jeden Prompt setzen:

```
Photorealistic editorial photography, German adult vocational training centre,
natural light, muted deep navy and warm gold on off-white, shallow depth of
field, no text, no logos, no children --ar 16:9 --style raw
```

Dann je Folie eine Zeile. Ergebnis speichern als `bild-<kennung>.jpg`, alle
Dateien hier in den Chat legen — ich schneide zu und baue sie ein.

| Kennung | Prompt (an die Stilzeile anhängen) |
| --- | --- |
| `cover` | modern education building facade at blue hour, dark glass, warm light in the windows, low angle |
| `problem` | cluttered desk from above, nine ring binders and two mismatched laptops, fragmented, cold light |
| `kosten` | stack of archive folders bound with tape, one red marker tab, hard side light, deep shadow |
| `was` | long bright corridor, one continuous path to a lit doorway, symmetrical, empty |
| `bewerbung` | adult applicant hands a document folder across a reception counter, seen from behind |
| `unterricht` | adult seminar room during a lesson, ten learners aged 25–50, instructor at a whiteboard, from the back |
| `nachweis` | two pairs of hands across a table, one slides a bound report over, the other holds a pen |
| `pruefung` | examination hall, single desks in strict rows, adults writing, high vantage point |
| `personal` | two people at a small round table, a closed personnel folder between them, soft window light |
| `qm` | auditor with a clipboard glancing into a room from the doorway, bright corridor |
| `vertrieb` | a hand signing a multi-page contract at a bright meeting table, second person's hands nearby |
| `inventar` | ordered equipment store room, metal shelving with stacked laptops, cases and tool kits |
| `melden` | one document drawn from a dense archive shelf, surroundings in soft focus, warm light on the sheet |
| `gerechnet` | macro of a steel vernier caliper on a deep navy surface, one thin gold highlight, studio light |
| `failclosed` | heavy closed steel door in a dim corridor, brass bolt thrown across, one hard shaft of light |
| `protokoll` | macro of three interlocking brass chain links on matte navy, centre link tack sharp |
| `datenschutz` | tall steel filing cabinet, one drawer open and the rest locked, brass lock plate catching light |
| `ki` | daylight through frosted glass panels forming a precise grid of light on a navy floor, abstract |
| `betrieb` | empty immaculate machine room at night, closed cabinets, faint indicator lights, no people |
| `umzug` | trolley of sealed archive boxes ready in a bright empty corridor, open doorway at the end |
| `sicherheit` | macro of a wall-mounted access reader, one gold indicator lit, a hand approaching at frame edge |
| `einfuehrung` | four adults around a table, one standing and pointing at an open laptop, quick and collegial |
| `ausblick` | architect's table, white scale model of a building beside rolled drawings, low afternoon light |
| `anschluss` | macro of a network patch panel, cables dressed in parallel, every connector seated straight |
| `grenzen` | almost empty desk, one closed folder exactly centred, long clean shadow, generous empty space |
| `stand` | finished education building interior at handover, one person checking a detail in the distance |
| `schluss` | education building facade at dusk from across an empty forecourt, warm light in the windows |

## Wenn ein Bild nicht sitzt

- Zu bunt → `muted, desaturated, one warm accent only`
- Zu gestellt → `candid, unposed, natural imperfection`
- Schrift im Bild → `no writing, letters, numbers or symbols` und neu erzeugen

Oberflächen-Ansichten (Laptop, Telefon) **nicht** erzeugen lassen — Bildmodelle
schreiben unleserliche Beschriftungen. Die baue ich aus der echten Oberfläche.

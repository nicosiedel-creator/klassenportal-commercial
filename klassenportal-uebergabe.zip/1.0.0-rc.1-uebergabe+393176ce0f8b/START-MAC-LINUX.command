#!/bin/sh
cd "$(dirname "$0")/quellen" || {
  echo "Bitte das ZIP zuerst vollstaendig entpacken und diese Datei aus dem entpackten Ordner starten."
  printf 'Eingabetaste zum Schliessen. '
  read _
  exit 1
}
npm run inbetriebnahme
# Ohne das schliesst sich das Fenster auf dem Mac, bevor das Kennwort abgeschrieben ist.
printf 'Fertig. Eingabetaste zum Schliessen. '
read _

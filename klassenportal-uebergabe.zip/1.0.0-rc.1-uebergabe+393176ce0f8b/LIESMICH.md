# Klassenportal — Übergabepaket 1.0.0-rc.1-uebergabe+393176ce0f8b

Erzeugt am 2026-09-21T12:48:51.128Z. 1232 Quelldateien, Release 1.0.0-rc.1+5c5690f75f93.

## Einfach loslegen

1. Node 22 oder neuer installieren: https://nodejs.org (großer grüner Knopf, alles bestätigen)
2. Diesen Ordner auspacken
3. Doppelklick auf **START-WINDOWS.bat** (Windows) oder **START-MAC-LINUX.command** (Mac, Linux)

## Kennwort verloren?

Doppelklick auf **KENNWORT-NEU-WINDOWS.bat** bzw. **KENNWORT-NEU-MAC-LINUX.command**.

„Passwort vergessen" auf der Anmeldeseite funktioniert für Plattform-Konten absichtlich nicht —
ein gekapertes Postfach soll nicht die ganze Plattform öffnen. Stattdessen weist dieser Weg den
Zugriff über Ihr Cloudflare-Konto nach.

Es öffnet sich ein Fenster und fragt nach Domain, E-Mail und Namen. Alles andere passiert von
selbst. Am Ende stehen Adresse, Benutzername und Kennwort im Fenster.

Auf dem Mac beim ersten Mal: Rechtsklick auf die Datei → "Öffnen" → "Öffnen" bestätigen.

Alles darunter ist für den technischen Betrieb und nicht nötig, um anzufangen.

**Dieses Paket braucht kein Git und kein GitHub.** Es braucht Node v22.22.2 oder neuer und —
nur zum Ausliefern — ein Cloudflare-API-Token.

## Prüfen, dass nichts verändert wurde

    node quellen/scripts/deliver.mjs pruefen .

Vergleicht jede Datei gegen `MANIFEST.json`. Meldet geänderte, fehlende **und zusätzliche**
Dateien — was nicht im Manifest steht, wurde nicht geprüft.

**Nach der Inbetriebnahme meldet diese Prüfung `quellen/wrangler.jsonc: Inhalt geändert`.**
Das ist richtig so: dort stehen jetzt Ihre Domain, Ihre Datenbank und Ihre Absenderadresse.
Prüfen Sie also am besten vor dem ersten Start.

## Bauen und testen

    cd quellen
    npm ci
    npm test

## Ausliefern

Das fertige Release liegt bereits bei und muss nicht neu gebaut werden:

    cd quellen
    node scripts/release-deploy.mjs deploy 1.0.0-rc.1+5c5690f75f93

Das Cloudflare-Token gehört vorher in die Umgebung — unter Windows in einer eigenen Zeile
(`set CLOUDFLARE_API_TOKEN=…`), unter macOS und Linux mit `export CLOUDFLARE_API_TOKEN=…`.

Vorher nur prüfen, ohne auszuliefern:

    node scripts/release-deploy.mjs deploy 1.0.0-rc.1+5c5690f75f93 --trocken

Zurückrollen auf den vorherigen Stand:

    node scripts/release-deploy.mjs rollback

Voraussetzung dafür: der Ordner `release/` aus diesem Paket liegt in `quellen/release/`.
Das Paket legt ihn bereits dorthin.

## Stand weiterführen

Es gibt keine Versionsverwaltung im Paket. Wer den Stand weiterführen will, hat zwei Wege:

1. **Ohne Versionsverwaltung:** den Ordner `quellen/` als Arbeitsstand nehmen. Jedes neue Paket
   ersetzt ihn; `PAKETE.md` in diesem Paket hält fest, welche Pakete es bisher gab.
2. **Mit einer Versionsverwaltung eigener Wahl:** `quellen/` in ein leeres Verzeichnis legen und
   dort initialisieren — Git, Mercurial, Fossil oder was auch immer. Das ist eine freie
   Entscheidung, keine Voraussetzung dieses Pakets.

## Was NICHT im Paket ist

- `node_modules/` — wird mit `npm ci` aus `package-lock.json` hergestellt
- `dist/` — wird mit `npm run build` erzeugt und liegt außerdem fertig im Release
- Zugangsdaten jeder Art — Token, Schlüssel und Geheimnisse gehören nicht in ein Paket, das
  weitergereicht wird

## Inhalt

| Bereich | Dateien | Größe |
|---|---|---|
| Quellen | 1232 | 15.7 MB |
| Release | 855 | 12.6 MB |

Gesamtprüfsumme: `393176ce0f8be1318a7933f8cbd5a8243d7b6d4329a29cd1b8be29679821061b`

@echo off
cd /d "%~dp0quellen" 2>nul
if errorlevel 1 (
  echo.
  echo Bitte das ZIP zuerst vollstaendig entpacken und diese Datei aus dem
  echo entpackten Ordner starten - nicht aus dem ZIP heraus.
  echo.
  pause
  exit /b 1
)
call npm run inbetriebnahme
pause
